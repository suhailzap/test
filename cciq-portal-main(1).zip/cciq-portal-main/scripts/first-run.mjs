import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

/**
 * Prepares a fresh copy of the portal on a church computer.
 *
 * Everything a person would otherwise have to do by hand: write the settings
 * file with a secret nobody has to invent, create the database, and hand over
 * the first sign-in details. It is safe to run again — an existing database and
 * an existing settings file are left alone.
 */

const root = process.cwd();
const envPath = path.join(root, '.env');

function say(line = '') {
  console.log(line);
}

/**
 * The settings this computer needs. Written out here rather than copied from
 * another file, so the folder cannot arrive missing the one thing setup
 * depends on.
 */
function settingsFile(secret) {
  return [
    '# CCIQ Portal settings for this computer.',
    '# Written when the portal was set up. Keep this file: the key below is what',
    '# keeps people signed in, and changing it signs everyone out.',
    '',
    'NODE_ENV=production',
    '',
    '# Which machines may reach the portal.',
    '#   127.0.0.1  this computer only',
    '#   0.0.0.0    this computer and anything on the church WiFi',
    'HOST=127.0.0.1',
    'PORT=3000',
    '',
    `SESSION_SECRET=${secret}`,
    '# Minutes of inactivity before a signed-in person is signed out again.',
    'SESSION_IDLE_TIMEOUT_MINUTES=60',
    '',
    '# Set this to true only when the portal is reached over https://',
    '# On this computer it is opened over http://localhost, where an',
    '# https-only cookie would stop anyone signing in.',
    'SECURE_COOKIES=false',
    '',
    'DATABASE_FILE=data/cciq.sqlite',
    'STORAGE_DIR=storage',
    '',
    'TZ_NAME=Asia/Qatar',
    '',
    '# The first account, created once when the portal was set up.',
    'BOOTSTRAP_ADMIN_EMAIL=admin@cciq.local',
    'BOOTSTRAP_ADMIN_NAME=Church Administrator',
    'BOOTSTRAP_ADMIN_PASSWORD=',
    ''
  ].join('\n');
}

function ensureEnv() {
  if (fs.existsSync(envPath)) return { created: false };

  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(envPath, settingsFile(secret), { mode: 0o600 });
  return { created: true };
}

async function run() {
  say();
  say('  Setting up the CCIQ Portal on this computer.');
  say();

  const env = ensureEnv();
  say(env.created
    ? '  Settings file created, with a security key unique to this computer.'
    : '  Settings file already present, left as it is.');

  if (!process.env.BOOTSTRAP_ADMIN_EMAIL) {
    process.env.BOOTSTRAP_ADMIN_EMAIL = 'admin@cciq.local';
  }
  if (!process.env.BOOTSTRAP_ADMIN_NAME) {
    process.env.BOOTSTRAP_ADMIN_NAME = 'Church Administrator';
  }

  // Loaded only now, so it reads the settings file just written.
  const { bootstrapIfNewOrEnsureCompatible } = await import('../src/db/migrate.js');
  const { default: db, queryOne } = await import('../src/db/index.js');
  const { seedAll } = await import('../src/db/seed.js');
  const { canPresentGeneratedCredential } = await import('../src/lib/credential-output.js');

  // Migration execution safety (Codex/independent verification): "safe to
  // run again" (this file's own opening comment) has always meant safe to
  // run again against an existing, already-current database - never a way
  // to silently upgrade one that is behind. A genuinely new, empty
  // database is still bootstrapped directly here (there is nothing to
  // protect for something that never existed); an existing database that
  // is behind now refuses instead, pointing at the explicit
  // `npm run db:migrate` step. See bootstrapIfNewOrEnsureCompatible() in
  // src/db/migrate.js.
  bootstrapIfNewOrEnsureCompatible();
  const hadUsers = queryOne('SELECT COUNT(*) AS n FROM users').n > 0;

  // R02 (Codex/independent verification): a freshly generated administrator
  // password can only ever be shown safely once, in a terminal a person is
  // actually watching - never written to a file, printed to a log, or
  // otherwise persisted in the clear. seedAll() refuses to generate one
  // unless it is told there is such a channel; that rule lives in the shared
  // seed code (not here) so `npm run db:seed` is held to it too. If nothing
  // needs generating (an account already exists, or BOOTSTRAP_ADMIN_PASSWORD
  // was supplied), this runs exactly as before.
  const result = await seedAll({ interactiveOutput: canPresentGeneratedCredential() });

  // A setup that did not create the administrator it exists to create must
  // not claim success. "An account already exists" is the normal re-run case
  // and is not a failure; anything else is. The reason never contains a
  // password.
  if (!result.admin.created && result.admin.code !== 'users_exist') {
    db.close();
    throw new Error(result.admin.reason);
  }
  say('  Database ready.');

  if (result.admin.created && result.admin.password) {
    // Shown here, once, and nowhere else - never written to a file or a log.
    say();
    say('  ------------------------------------------------------');
    say('   Your first sign-in');
    say('');
    say(`   Username: ${result.admin.username}`);
    say(`   Password: ${result.admin.password}`);
    say('');
    say('   Sign in with either the username or the email address.');
    say('   You will be asked to choose your own password straight away.');
    say('');
    say('   This password is shown once, right here. Write it down or sign in');
    say('   now, before closing this window - it cannot be shown again.');
    say('  ------------------------------------------------------');
  } else if (result.admin.created) {
    say(`  Administrator account created (${result.admin.username}) with the password from BOOTSTRAP_ADMIN_PASSWORD.`);
    say('  You will be asked to choose your own password at first sign-in.');
  } else if (hadUsers) {
    say('  Accounts already exist, so no new password was created.');
    say('  If nobody can sign in, run `npm run account:password` from a console window.');
  }

  say();
  say('  Setup finished. Start the portal with `npm start`.');
  say();
  db.close();
}

run().catch((err) => {
  say();
  say(`  Setup could not finish: ${err.message}`);
  say();
  say('  Nothing was damaged. Try running this again, and if it keeps failing,');
  say('  send this message to whoever looks after the portal.');
  process.exitCode = 1;
});
