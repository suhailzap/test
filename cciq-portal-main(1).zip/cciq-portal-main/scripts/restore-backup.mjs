import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { restoreFromArchive, RestoreError, REPLACE_PHRASE } from '../src/lib/restore-archive.js';
import { describeMissing } from '../src/lib/storage-references.js';
import { askHidden } from '../src/lib/prompt.js';

/*
 * Restore a full CCIQ backup onto a computer with no running portal (a replacement PC). Runs from the approved release with its bundled runtime; needs no database, no running
 * portal and no signed-in user. It never starts CCIQ and never migrates a database. Read src/lib/restore-archive.js for the safety model.
 *
 *   restore-backup.mjs --archive <backup.tar.gz | backup.tar.gz.ccenc> --env <full path of the configuration file> [--sha256 <64 hex>] [--state <runtime-state folder>]
 *                      [--dry-run] [--strict-references] [--passphrase-file <file>] [--replace --confirm "REPLACE CCIQ DATA"] [--json]
 *
 * Exit codes: 0 restored (or a dry run passed)   1 failed or refused, nothing changed   2 bad usage   3 refused to overwrite existing data or a running portal
 */

const here = path.dirname(fileURLToPath(import.meta.url));
const releaseRoot = path.resolve(here, '..');
const USAGE = `Usage: restore-backup.mjs --archive <file> --env <full path of the configuration file> [--sha256 <hex>] [--state <folder>] [--dry-run] [--strict-references]
                         [--passphrase-file <file>] [--replace --confirm "${REPLACE_PHRASE}"] [--json]`;
const args = process.argv.slice(2);
const flags = new Set(['--dry-run', '--strict-references', '--replace', '--json', '--help', '-h']);
const withValue = new Set(['--archive', '--env', '--sha256', '--state', '--confirm', '--passphrase-file']);
const opt = {};
for (let i = 0; i < args.length; i += 1) {
  const a = args[i];
  if (flags.has(a)) opt[a.replace(/^-+/, '')] = true;
  else if (withValue.has(a)) { opt[a.slice(2)] = args[i + 1]; i += 1; }
  else { console.error(`Unknown option ${a}\n${USAGE}`); process.exit(2); }
}
if (opt.help || opt.h) { console.log(USAGE); process.exit(0); }
if (!opt.archive || !opt.env || !path.isAbsolute(opt.env)) { console.error(`--archive and --env (a full path) are required.\n${USAGE}`); process.exit(2); }
if (!fs.existsSync(opt.env)) { console.error(`The configuration file was not found: ${opt.env}`); process.exit(1); }

// Only the settings this tool needs are taken from the configuration file; the rest of it (including the session secret) is never read into anything.
const parsed = dotenv.parse(fs.readFileSync(opt.env));
const env = { DATABASE_FILE: parsed.DATABASE_FILE, STORAGE_DIR: parsed.STORAGE_DIR, BACKUP_DIR: parsed.BACKUP_DIR, HOST: parsed.HOST, PORT: parsed.PORT };
const stateDir = opt.state ? path.resolve(opt.state) : path.join(path.dirname(path.dirname(path.resolve(opt.env))), 'runtime-state');

const say = (line) => { if (!opt.json) console.log(`  ${line}`); };
try {
  let passphrase = null;
  if (/\.ccenc$/i.test(opt.archive)) passphrase = opt['passphrase-file'] ? fs.readFileSync(opt['passphrase-file'], 'utf8').replace(/\r?\n$/, '') : await askHidden('  Passphrase for this encrypted backup: ');
  const result = await restoreFromArchive({
    archive: path.resolve(opt.archive), sha256: opt.sha256, env, stateDir, releaseRoot, replace: Boolean(opt.replace), confirm: opt.confirm, dryRun: Boolean(opt['dry-run']),
    strictReferences: Boolean(opt['strict-references']), passphrase, log: say
  });
  if (opt.json) { console.log(JSON.stringify({ ok: true, ...result, evidence: undefined })); }
  else {
    console.log('');
    console.log(result.dryRun ? '  DRY RUN PASSED. The backup is complete and this release accepts it. Nothing was restored.' : `  RESTORED. ${result.members ?? '?'} members, ${result.storageFiles} stored file(s), schema ${result.schema}.`);
    if (result.replacedDataMovedTo) console.log(`  The data that was here before was moved to: ${result.replacedDataMovedTo}`);
    for (const w of result.warnings || []) console.log(`  WARNING: ${w}`);
    if ((result.missingReferences || []).length) console.log(`  (The backup is faithful: ${describeMissing(result.missingReferences, 2)}. This was already so when the backup was made.)`);
    if (result.evidenceFile) console.log(`  Record of this restore: ${result.evidenceFile}`);
    if (!result.dryRun) console.log('  Next: start CCIQ and sign in with the account that existed when the backup was made.');
    console.log('');
  }
  process.exit(0);
} catch (err) {
  const exit = err instanceof RestoreError ? err.exit : 1;
  if (opt.json) console.log(JSON.stringify({ ok: false, code: err.code || 'error', message: err.message, evidenceFile: err.evidenceFile || null }));
  else { console.error(`\n  NOT RESTORED: ${err.message}\n${err.evidenceFile ? `  Record: ${err.evidenceFile}\n` : ''}`); }
  process.exit(exit);
}
