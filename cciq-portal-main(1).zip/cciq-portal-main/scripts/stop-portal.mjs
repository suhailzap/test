import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

function readEnvValue(key, fallback) {
  const envPath = path.join(root, '.env');
  if (!fs.existsSync(envPath)) return fallback;
  const line = fs.readFileSync(envPath, 'utf8').split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim() : fallback;
}

const PORT = Number(readEnvValue('PORT', '3000'));

/*
 * A console-attached CCIQ (`npm start`) responds to Ctrl+C / closing its
 * window. A copy started unattended (Task Scheduler → run-service.mjs) has
 * no window to close, so this finds whatever process owns the configured
 * port and stops it directly. Graceful shutdown was tried and found not to
 * apply here: Windows refuses a non-forceful stop on a console-less Node
 * process ("can only be terminated forcefully"), so this goes straight to a
 * forceful stop rather than pretending a gentler one will work — data is
 * unaffected either way, since better-sqlite3/WAL is crash-consistent.
 *
 * run-service.mjs now auto-restarts its child after an unexpected exit (see
 * that file). Once a supervisor is in play, killing only the port's owner
 * (the child) would look exactly like a crash and be respawned automatically
 * — so this checks for the supervisor's PID file first and, if it's still
 * alive, forcefully kills its whole process tree (supervisor + child)
 * together instead. A console-attached, unsupervised CCIQ has no such file
 * and falls through to the original port-based behaviour unchanged.
 */
const pidFile = path.join(root, 'logs', 'run-service.pid');
if (fs.existsSync(pidFile)) {
  const supervisorPid = fs.readFileSync(pidFile, 'utf8').trim();
  let alive = false;
  try {
    const out = execSync(`tasklist /FI "PID eq ${supervisorPid}" /NH`, { encoding: 'utf8' });
    alive = /node\.exe/i.test(out);
  } catch { /* tasklist failing means we cannot confirm it's alive — fall through below */ }

  if (alive) {
    try {
      execSync(`taskkill /F /T /PID ${supervisorPid}`, { stdio: 'pipe' });
      console.log(`  Stopped the supervisor and its child (process ${supervisorPid}). Nothing has been lost.`);
      process.exit(0);
    } catch (err) {
      console.log(`  Could not stop the supervisor (process ${supervisorPid}): ${err.message}`);
      process.exitCode = 1;
      process.exit();
    }
  } else {
    // Stale file from a previous run that didn't clean up after itself —
    // harmless, but worth removing so a future stale PID is never confused
    // with a real one.
    try { fs.rmSync(pidFile, { force: true }); } catch { /* best effort */ }
  }
}

let pid;
try {
  const out = execSync(`netstat -ano -p tcp`, { encoding: 'utf8' });
  const line = out.split(/\r?\n/).find((l) => l.includes(`:${PORT} `) && l.includes('LISTENING'));
  pid = line ? line.trim().split(/\s+/).pop() : null;
} catch (err) {
  console.log(`  Could not check what is running: ${err.message}`);
  process.exit(1);
}

if (!pid) {
  console.log(`  Nothing is listening on port ${PORT} — CCIQ does not appear to be running.`);
  process.exit(0);
}

try {
  execSync(`taskkill /F /PID ${pid}`, { stdio: 'pipe' });
  console.log(`  Stopped (process ${pid}). Nothing has been lost.`);
} catch (err) {
  console.log(`  Could not stop process ${pid}: ${err.message}`);
  process.exitCode = 1;
}
