import fs from 'node:fs';
import path from 'node:path';
import db, { execute } from '../src/db/index.js';
import { checkSchemaCompatibility } from '../src/db/migrate.js';
import { createBackup, deepVerifyBackup, pruneBackups, formatBytes } from '../src/services/backups.js';
import config from '../src/config/env.js';

/**
 * Meant to be run unattended (Task Scheduler or similar), once a day. Unlike
 * scripts/backup-now.mjs (a person pressing a button and reading the result),
 * this must never assume anyone is watching: every outcome is logged clearly,
 * a corrupt-but-created archive is caught by deepVerifyBackup() rather than
 * trusted, and a concurrent run of this same script is refused rather than
 * allowed to race the one already in progress.
 */

// 60 daily backups is roughly two months of history at current data size
// (a few MB each) - comfortably enough to recover from something noticed
// weeks late, trivial relative to available disk space. See
// docs/RUN-ON-ONE-PC.md ("Automatic daily backups") for the plain-language
// explanation, and CCIQ_DECISIONS.md for the go-live readiness review this
// number was confirmed against.
const RETAIN = 60;

function log(line) {
  console.log(`[${new Date().toISOString()}] ${line}`);
}

function lockPath() {
  return path.join(config.backupDir, '.scheduled-backup.lock');
}

/** True if a lock exists and the PID it names is still a running process. */
function lockHeldByLiveProcess(file) {
  let pid;
  try {
    pid = Number(fs.readFileSync(file, 'utf8').trim());
  } catch {
    return false;
  }
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0); // signal 0: existence check only, never actually sent
    return true;
  } catch {
    return false; // ESRCH — no such process; a stale lock from a crashed run
  }
}

async function run() {
  fs.mkdirSync(config.backupDir, { recursive: true, mode: 0o700 });
  const lock = lockPath();

  if (fs.existsSync(lock) && lockHeldByLiveProcess(lock)) {
    log('another scheduled backup is already running — skipping this run, not starting a second one');
    return;
  }
  if (fs.existsSync(lock)) {
    log('found a stale lock from a run that did not exit cleanly — removing it and continuing');
    fs.rmSync(lock, { force: true });
  }
  fs.writeFileSync(lock, String(process.pid), { mode: 0o600 });

  try {
    // Migration execution safety (Codex/independent verification): this
    // used to call migrate() directly - a daily, unattended, unrelated
    // task silently advancing the schema on its own schedule is exactly
    // how migration 0028 was applied without an intentional deployment.
    // A backup must never mutate schema_migrations; it now only checks
    // compatibility and refuses (without attempting the backup) if the
    // schema is not exactly what this code expects. The explicit
    // `npm run db:migrate` command is the only sanctioned way forward.
    const compatibility = checkSchemaCompatibility();
    if (!compatibility.ok) {
      log(`refusing to back up: ${compatibility.reason === 'uninitialized'
        ? 'the database has not been initialized'
        : compatibility.reason === 'behind'
          ? `the database is behind what this code requires (missing: ${compatibility.missing.join(', ')})`
          : `the database has migration(s) this code does not recognize (${compatibility.unexpected.join(', ')})`}`
        + ' - run "npm run db:migrate" before the next scheduled run, or investigate before proceeding.');
      process.exitCode = 1;
      return;
    }

    // A warning only, never a reason to skip the attempt: a backup that
    // fails on a full disk is still caught cleanly by createBackup()'s own
    // error handling below, but a low-space warning ahead of time is the
    // difference between noticing this in a log file and only finding out
    // when a restore is actually needed.
    try {
      const stats = await fs.promises.statfs(config.backupDir);
      const freeBytes = stats.bavail * stats.bsize;
      const LOW_SPACE_WARNING_BYTES = 1024 * 1024 * 1024; // 1 GB
      if (freeBytes < LOW_SPACE_WARNING_BYTES) {
        log(`WARNING: only ${formatBytes(freeBytes)} free on the backup drive — investigate before this becomes a failed backup`);
      }
    } catch (err) {
      log(`could not check free disk space (continuing anyway): ${err.message}`);
    }

    log('starting scheduled backup...');
    const result = await createBackup({ kind: 'scheduled', note: 'Automatic scheduled backup' });

    if (!result.ok) {
      log(`FAILED to create backup: ${result.reason || 'unknown reason'}`);
      process.exitCode = 1;
      return;
    }
    log(`created ${result.backup.filename} (${formatBytes(result.backup.file_size)})`);

    log('verifying the archive (extract, integrity check, migration, storage folders)...');
    const verification = await deepVerifyBackup(result.backup);
    if (!verification.ok) {
      log(`FAILED verification: ${verification.reason} — the archive file is being kept for inspection, not deleted`);
      execute(
        "UPDATE backups SET notes = notes || ' — WARNING: automated post-creation verification failed: ' || @reason WHERE id = @id",
        { id: result.backup.id, reason: verification.reason }
      );
      process.exitCode = 1;
      return;
    }
    log(`verification ok — migration ${verification.migrationVersion}, storage folders: ${verification.storageFolders.join(', ') || '(none)'}, ${verification.referencedFiles} stored file(s) referenced by the database`);
    // Never silent: a stored file the database points at that is not in storage is reported on every run until someone fixes it.
    for (const warning of verification.warnings || []) log(`WARNING: ${warning}`);

    const removed = pruneBackups({ keep: RETAIN });
    log(removed.length
      ? `retention: removed ${removed.length} backup(s) beyond the newest ${RETAIN}: ${removed.join(', ')}`
      : `retention: ${RETAIN}-backup limit not yet reached, nothing removed`);

    log('scheduled backup complete.');
  } catch (err) {
    log(`FAILED with an unexpected error: ${err.message}`);
    process.exitCode = 1;
  } finally {
    fs.rmSync(lock, { force: true });
  }
}

run().finally(() => db.close());
