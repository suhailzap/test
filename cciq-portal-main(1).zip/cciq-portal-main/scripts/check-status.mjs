import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

function readEnvValue(key, fallback) {
  const envPath = path.join(root, '.env');
  if (!fs.existsSync(envPath)) return fallback;
  const line = fs.readFileSync(envPath, 'utf8').split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim() : fallback;
}

const PORT = Number(readEnvValue('PORT', '3000'));
const HOST = readEnvValue('HOST', '0.0.0.0');
const connectHost = HOST === '0.0.0.0' ? '127.0.0.1' : HOST;

function isPortInUse(port, host) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ port, host, timeout: 1500 });
    socket.once('connect', () => { socket.destroy(); resolve(true); });
    socket.once('timeout', () => { socket.destroy(); resolve(false); });
    socket.once('error', () => resolve(false));
  });
}

const running = await isPortInUse(PORT, connectHost);

if (!running) {
  console.log('  CCIQ does not appear to be running.');
  console.log(`  Nothing is listening on port ${PORT}.`);
  console.log('  Use `npm start` from the project folder to start it.');
  process.exit(0);
}

console.log(`  Something is listening on port ${PORT} — checking it is actually CCIQ...`);
try {
  const res = await fetch(`http://${connectHost}:${PORT}/healthz`, { signal: AbortSignal.timeout(3000) });
  if (!res.ok) throw new Error(`unexpected response: ${res.status}`);
  const body = await res.json();
  console.log('');
  console.log('  CCIQ is running.');
  console.log(`  Started:  ${body.startedAt}`);
  console.log(`  Open:     http://localhost:${PORT}`);
} catch (err) {
  console.log('');
  console.log('  Something is using that port, but it did not answer like CCIQ normally does.');
  console.log(`  (${err.message})`);
  console.log('  If this is unexpected, check the log files in the "logs" folder.');
  process.exitCode = 1;
}
