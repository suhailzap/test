import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { acquirePidLock } from './lib/pid-lock.mjs';

/*
 * A supervised way to start the portal — meant for Windows Task Scheduler
 * ("At startup"), not for a person to double-click. A person should keep
 * using `npm start` in a console window, which shows the portal's
 * own output directly.
 *
 * Unlike `npm start`, this never assumes a console is attached: output is
 * captured to a dated log file (Task Scheduler runs with no console at all),
 * and it refuses to start a second copy if one is already listening on the
 * configured port — the two must never run at once against the same
 * database file.
 *
 * This process respawns its own child after an unexpected exit, rather than
 * relying on Task Scheduler's own "restart on failure" setting. A controlled
 * crash-recovery test found that setting did not reliably engage for this
 * task even with Task Scheduler correctly recording the failed exit code
 * (see CCIQ_DECISIONS.md, "Crash-recovery: Task Scheduler restart-on-failure
 * did not engage") — so Task Scheduler is now only the outer boot/start
 * safety net, and this process is the one actually responsible for keeping
 * the portal running once started.
 */

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
process.chdir(root);

// Read the same .env the application itself would, without importing any
// application module here — this script's only job is to launch that
// process, cleanly, so it must not depend on anything the app depends on.
function readEnvValue(key, fallback) {
  const envPath = path.join(root, '.env');
  if (!fs.existsSync(envPath)) return fallback;
  const line = fs.readFileSync(envPath, 'utf8')
    .split(/\r?\n/)
    .find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim() : fallback;
}

const PORT = Number(readEnvValue('PORT', '3000'));
const HOST = readEnvValue('HOST', '0.0.0.0');
const connectHost = HOST === '0.0.0.0' ? '127.0.0.1' : HOST;

function isPortInUse(port, host) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ port, host, timeout: 1500 });
    socket.once('connect', () => { socket.destroy(); resolve(true); });
    socket.once('timeout', () => { socket.destroy(); resolve(false); });
    socket.once('error', () => resolve(false));
  });
}

const logsDir = path.join(root, 'logs');
fs.mkdirSync(logsDir, { recursive: true });

// One file per calendar day, so a single run never grows without bound and
// nothing needs a separate rotation job. Old files are pruned lightly below.
const stamp = new Date().toISOString().slice(0, 10);
const logFile = path.join(logsDir, `portal-${stamp}.log`);
const logStream = fs.createWriteStream(logFile, { flags: 'a' });

function log(line) {
  const entry = `[service ${new Date().toISOString()}] ${line}`;
  logStream.write(entry + '\n');
  console.log(entry);
}

// Keep roughly the last month of daily logs — same reasoning as backup
// retention: sizes here are trivial, this is only tidiness, not a real
// disk-space concern.
try {
  const cutoff = Date.now() - 35 * 24 * 60 * 60 * 1000;
  for (const name of fs.readdirSync(logsDir)) {
    if (!/^portal-\d{4}-\d{2}-\d{2}\.log$/.test(name)) continue;
    const full = path.join(logsDir, name);
    if (fs.statSync(full).mtimeMs < cutoff) fs.rmSync(full, { force: true });
  }
} catch { /* log pruning is best-effort; never block a real startup on it */ }

const alreadyRunning = await isPortInUse(PORT, connectHost);
if (alreadyRunning) {
  log(`port ${PORT} is already in use — CCIQ appears to be running already. Not starting a second instance.`);
  logStream.end();
  process.exit(0);
}

const nodeExe = path.join(root, 'runtime', 'node.exe');
if (!fs.existsSync(nodeExe)) {
  log(`the bundled runtime was not found at ${nodeExe} — has Setup CCIQ.bat been run on this computer?`);
  logStream.end();
  process.exit(1);
}

// So stop-portal.mjs can find and stop THIS supervisor (and therefore its
// child, together) instead of only killing whatever is listening on the
// port — killing the child alone would otherwise now look like an
// unexpected crash and be respawned automatically below.
//
// Ownership is taken through acquirePidLock() (scripts/lib/pid-lock.mjs), not
// a blind write or a bare exclusive create: a file left by a process that
// died is set aside as evidence and start-up proceeds; a file naming a live
// CCIQ service refuses a second instance; anything ambiguous or malformed
// refuses to start rather than risk two instances on one database.
const pidFile = path.join(logsDir, 'run-service.pid');
const pidLock = acquirePidLock(pidFile, { log });
if (!pidLock.ok) {
  log(`not starting: ${pidLock.reason}`);
  logStream.end();
  process.exit(pidLock.code === 'already_running' ? 0 : 1);
}
function cleanupPidFile() {
  pidLock.release();
}
// Also on any other way this process ends normally (release() only ever
// removes a file that still names this process); a hard kill cannot run this,
// which is exactly the stale-file case acquirePidLock() recovers from.
process.on('exit', cleanupPidFile);

let shuttingDown = false;
let child = null;
let childStartedAt = null;
let restartCount = 0;
const MAX_RESTARTS = 5;
const BASE_DELAY_MS = 2000;
const MAX_DELAY_MS = 30000;
// A child that ran this long before exiting was genuinely healthy, not
// crash-looping — a later, unrelated failure gets a fresh set of restart
// attempts rather than being penalised by an old, unrelated one.
const STABLE_MS = 60000;

function spawnChild() {
  log(`starting CCIQ (${nodeExe} src/server.js, cwd ${root})`);
  childStartedAt = Date.now();
  child = spawn(nodeExe, ['src/server.js'], { cwd: root, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  child.stdout.pipe(logStream, { end: false });
  child.stderr.pipe(logStream, { end: false });

  // Without this, a spawn failure (e.g. the runtime binary disappearing
  // mid-operation) would throw as an uncaught exception on the unhandled
  // 'error' event and kill the supervisor outright — exactly the failure
  // mode this whole change exists to avoid. 'exit' still fires afterward
  // and drives the normal restart-or-give-up logic below.
  child.on('error', (err) => log(`CCIQ process failed to start: ${err.message}`));

  child.on('exit', (code, signal) => {
    if (shuttingDown) {
      log(`CCIQ process exited during controlled shutdown (code=${code ?? 'null'}, signal=${signal ?? 'null'})`);
      cleanupPidFile();
      logStream.end(() => process.exit(0));
      return;
    }

    log(`CCIQ process exited unexpectedly (code=${code ?? 'null'}, signal=${signal ?? 'null'})`);
    if (childStartedAt && Date.now() - childStartedAt > STABLE_MS) restartCount = 0;
    restartCount += 1;

    if (restartCount > MAX_RESTARTS) {
      log(`giving up after ${MAX_RESTARTS} restart attempts in a short period — not retrying again`);
      cleanupPidFile();
      logStream.end(() => process.exit(1));
      return;
    }

    const delay = Math.min(BASE_DELAY_MS * 2 ** (restartCount - 1), MAX_DELAY_MS);
    log(`restarting in ${delay}ms (attempt ${restartCount} of ${MAX_RESTARTS})`);
    setTimeout(spawnChild, delay);
  });
}

// A stop of this wrapper (however Task Scheduler delivers it) should stop
// the child too, rather than leaving an orphaned server process behind —
// and must not be mistaken for the unexpected exit above, or the very act
// of stopping would trigger a restart.
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    shuttingDown = true;
    log(`supervisor received ${sig} — stopping the child, not restarting it`);
    if (child && !child.killed) child.kill(sig);
  });
}

spawnChild();
