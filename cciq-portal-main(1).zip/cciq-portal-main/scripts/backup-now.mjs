import path from 'node:path';
import db from '../src/db/index.js';
import { checkSchemaCompatibility } from '../src/db/migrate.js';
import { createBackup, formatBytes } from '../src/services/backups.js';
import config from '../src/config/env.js';

/**
 * A backup taken from the folder itself, without signing in. For the person
 * who has been told "take a backup every week" and would rather press one
 * thing than remember where the button is.
 */
async function run() {
  // Migration execution safety (Codex/independent verification): this
  // pressed-a-button-and-reads-the-result backup must never silently
  // advance the schema either, for the same reason the scheduled one must
  // not - see scripts/scheduled-backup.mjs. Checks compatibility only;
  // never applies anything.
  const compatibility = checkSchemaCompatibility();
  if (!compatibility.ok) {
    console.log('');
    console.log(compatibility.reason === 'uninitialized'
      ? '  This database has not been initialized yet. Run "Setup CCIQ.bat" first.'
      : compatibility.reason === 'behind'
        ? `  This database needs an update before it can be backed up (missing: ${compatibility.missing.join(', ')}).`
        : `  This database has changes this copy of the portal does not recognize (${compatibility.unexpected.join(', ')}).`);
    console.log('  Nothing was changed. Run "npm run db:migrate" (or contact your technical person) before trying again.');
    process.exitCode = 1;
    return;
  }

  const result = await createBackup({ note: 'Taken from the church computer', kind: 'manual' });

  if (!result.ok) {
    console.log('');
    console.log(`  The backup did not finish: ${result.message || result.reason || 'unknown reason'}`);
    console.log('  Nothing was changed. Try again, or take one from Administration → Backups.');
    process.exitCode = 1;
    return;
  }

  const folder = path.resolve(config.storageDir, 'backups');
  console.log('');
  console.log('  Backup complete.');
  console.log('');
  console.log(`  File:   ${result.backup.filename}`);
  console.log(`  Size:   ${formatBytes(result.backup.file_size)}`);
  console.log(`  Folder: ${folder}`);
  console.log('');
  console.log('  This contains the records and every uploaded file.');
  if (/WARNING:/.test(result.backup.notes || '')) {
    console.log('');
    console.log(`  ${String(result.backup.notes).slice(String(result.backup.notes).indexOf('WARNING:'))}`);
    console.log('  The backup is complete and faithful, but the portal was already missing that file.');
  }
}

run()
  .catch((err) => {
    console.log('');
    console.log(`  The backup could not be taken: ${err.message}`);
    process.exitCode = 1;
  })
  .finally(() => db.close());
