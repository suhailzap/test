import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { checkInvariants, INVARIANTS } from '../src/lib/db-invariants.js';

/*
 * READ-ONLY data-integrity check (see src/lib/db-invariants.js for every rule).
 *
 * It runs SELECTs only, on a connection opened read-only with query_only set, and never repairs anything. It has NO default
 * database: the path must be given and it must be a COPY (a backup restored to a scratch folder). Refused (exit 1): a path
 * inside a folder named "cciq-production", and a database with a non-empty "-wal" file beside it (an in-use database).
 * Output lists ids and codes only, never names.
 */

const USAGE = `Usage:
  node tools/check-db-invariants.mjs <database-file> [--json]
  node tools/check-db-invariants.mjs --list
  node tools/check-db-invariants.mjs --help

READ-ONLY. Point it at a COPY of a database, never the live one. No default path, no discovery.

Exit codes:
  0 = no "error" findings (review findings may exist; they are for a person to look at)
  3 = at least one "error" finding
  1 = the tool could not run (unopenable file, refused path)
  2 = bad usage`;

function fail(code, message) {
  console.error(message);
  process.exit(code);
}

const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) { console.log(USAGE); process.exit(0); }
if (args.includes('--list')) {
  for (const inv of INVARIANTS) console.log(`${inv.severity.padEnd(6)} ${inv.code}  ${inv.title}`);
  process.exit(0);
}
let json = false;
let target = null;
for (const a of args) {
  if (a === '--json') json = true;
  else if (a.startsWith('--')) fail(2, `Unknown option ${a}.\n\n${USAGE}`);
  else if (target === null) target = a;
  else fail(2, `Only one database file may be given.\n\n${USAGE}`);
}
if (!target) fail(2, `A database file path is required (there is no default).\n\n${USAGE}`);

const resolved = path.resolve(target);
if (resolved.split(/[\\/]/).some((segment) => segment.toLowerCase() === 'cciq-production')) {
  fail(1, `Refusing ${resolved}: it is inside a "cciq-production" folder. This tool is for a restored COPY of a database, never the live one.`);
}
try {
  if (fs.statSync(`${resolved}-wal`).size > 0) {
    fail(1, `Refusing ${resolved}: a non-empty "-wal" file sits beside it, which means it is an in-use database. Restore a backup to a scratch folder and point at that copy.`);
  }
} catch { /* no sidecar: fine */ }

let db;
try {
  db = new Database(resolved, { readonly: true, fileMustExist: true });
  db.pragma('query_only = ON');
} catch (err) {
  fail(1, `Could not open ${target} read-only: ${err.message}`);
}

let report;
try {
  report = checkInvariants(db);
} catch (err) {
  fail(1, `Could not check ${target}: ${err.message}`);
} finally {
  db.close();
}

const errors = report.findings.filter((f) => f.severity === 'error');
const reviews = report.findings.filter((f) => f.severity === 'review');
const structural = report.integrity.filter((r) => r !== 'ok').length + report.foreignKeys.length;
const exitCode = errors.length || structural ? 3 : 0;

if (json) {
  console.log(JSON.stringify({ exitCode, ...report }, null, 2));
} else {
  console.log(`Database integrity: ${report.integrity.join('; ')}`);
  console.log(`Foreign key violations: ${report.foreignKeys.length}${report.foreignKeys.length ? `\n  ${report.foreignKeys.slice(0, 20).join('\n  ')}` : ''}`);
  for (const [label, list] of [['ERRORS', errors], ['FOR REVIEW', reviews]]) {
    console.log(`\n${label}: ${list.length}`);
    for (const f of list) console.log(`  ${f.code}: ${f.title} - ${f.count} (ids: ${f.ids.join(', ')}${f.count > f.ids.length ? ', ...' : ''})`);
  }
  if (report.skipped.length) console.log(`\nSkipped (not in this database's schema): ${report.skipped.map((s) => s.code).join(', ')}`);
  console.log(`\nChecked ${INVARIANTS.length - report.skipped.length} rules. ${exitCode ? 'Errors found.' : 'No errors.'}`);
}
process.exit(exitCode);
