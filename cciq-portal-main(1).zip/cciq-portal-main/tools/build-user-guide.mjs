import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { buildHandoverEdition } from '../src/lib/user-guide-build.js';

/*
 * Builds the offline, printable HANDOVER EDITION of the User Guide from the one source (src/help):
 *
 *   node tools/build-user-guide.mjs [--out <folder>] [--zip]
 *
 * Default folder: dist/user-guide. With --zip it also writes <folder>.zip (made with Windows' own tar.exe) and a .sha256 beside it. Nothing is read from, or written to, portal data.
 */

const repo = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const value = (flag) => { const i = args.indexOf(flag); return i >= 0 ? args[i + 1] : null; };
const out = path.resolve(value('--out') || path.join(repo, 'dist', 'user-guide'));

let built;
try { built = buildHandoverEdition(out); } catch (err) { console.error(`STOPPED: ${err.message}`); process.exit(1); }
console.log(`Built the handover edition of the User Guide (edition ${built.edition}): ${built.chapters} chapters, ${built.screenshots} screenshots`);
console.log(`  ${path.join(built.out, 'index.html')}`);

if (args.includes('--zip')) {
  const zip = `${built.out}.zip`;
  fs.rmSync(zip, { force: true });
  const tarExe = process.platform === 'win32' ? path.join(process.env.SystemRoot || 'C:/Windows', 'System32', 'tar.exe') : 'tar';
  const z = spawnSync(tarExe, ['-a', '-c', '-f', zip, '-C', path.dirname(built.out), path.basename(built.out)], { encoding: 'utf8' });
  if (z.status !== 0) { console.error(`STOPPED: the zip could not be made: ${(z.stderr || '').slice(0, 200)}`); process.exit(1); }
  fs.writeFileSync(`${zip}.sha256`, `${crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex')}  ${path.basename(zip)}\n`);
  console.log(`  ${zip} (${(fs.statSync(zip).size / 1e6).toFixed(1)} MB)`);
}
