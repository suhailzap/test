import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { checkHistoryChain, evaluateExpectation } from '../src/lib/status-as-of.js';
import { addDays, isValidDate, nextFridayOnOrAfter, today } from '../src/lib/dates.js';

/*
 * READ-ONLY pre-Go-Live diagnostic: is member_status_history complete and coherent
 * enough to say who was EXPECTED at a Friday?
 *
 * Attendance finalization snapshots who was expected at a Friday from each member's
 * recorded status changes (src/lib/status-as-of.js). That is only trustworthy if every
 * change was recorded. A member whose history contradicts itself, or does not tell what
 * their status was on a given Friday, is "ambiguous": finalization REFUSES to guess and
 * lists them. This tool finds them BEFORE Go-Live so they can be fixed through the portal.
 *
 * This tool is READ-ONLY. It never writes to the database, its schema, its settings or
 * its WAL. It runs SELECTs only, on a connection opened read-only with query_only set.
 * It does not read the application's configuration and has NO default database: the path
 * must be given, and it must be a COPY (a backup restored to a scratch folder).
 *
 * Refused on purpose (exit 1): a path inside a folder named "cciq-production", and a
 * database that has a non-empty "-wal" file beside it (that is an in-use database, not a
 * restored copy). It never searches for a database.
 */

/** Mirrors MEMBER_STATUSES in src/services/members.js (a test keeps them identical): this tool never imports application code that opens a database. */
export const MEMBER_STATUS_CATALOGUE = [
  'active', 'inactive', 'pending', 'archived',
  'temporarily_away', 'returned_home', 'migrated', 'transferred', 'other',
  'attendee', 'bonafide'
];

const USAGE = `Usage:
  node tools/check-status-history.mjs <database-file> [--go-live YYYY-MM-DD] [--through YYYY-MM-DD] [--json]
  node tools/check-status-history.mjs --help

READ-ONLY. Point it at a COPY of a database (a backup restored to a scratch folder), never at the
live one. There is no default path and no discovery.

  <database-file>        REQUIRED. The SQLite file to inspect.
  --go-live YYYY-MM-DD   Also classify every member for each Friday from this date (the first Friday on
                         or after it) as EXACT, INFERRED or AMBIGUOUS, exactly as finalization would.
  --through YYYY-MM-DD   Last Friday to classify (default: today).
  --json                 Machine-readable output (member IDs and codes only).
  --human-review         Also list each member who needs a person to look at their record (contradictory or
                         ambiguous): member ID, name, current status, the recorded status sequence and why it
                         is flagged. Names appear ONLY in this section, so the default output stays free of them.
                         It suggests a category of review; it never suggests what the correct status was.

Exit codes:  0 = every member coherent and (with --go-live) none ambiguous
             3 = at least one member needs attention before Go-Live
             1 = the tool could not run (unopenable file, wrong database, refused path)
             2 = bad usage`;

function fail(code, message) {
  console.error(message);
  process.exit(code);
}

// ---- arguments ------------------------------------------------------------
const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) {
  console.log(USAGE);
  process.exit(0);
}
const options = { json: false, goLive: null, through: null, humanReview: false };
let target = null;
for (let i = 0; i < args.length; i += 1) {
  const a = args[i];
  if (a === '--json') options.json = true;
  else if (a === '--human-review') options.humanReview = true;
  else if (a === '--go-live' || a === '--through') {
    const value = args[i + 1];
    if (!value || value.startsWith('--')) fail(2, `${a} needs a date (YYYY-MM-DD).\n\n${USAGE}`);
    options[a === '--go-live' ? 'goLive' : 'through'] = value;
    i += 1;
  } else if (a.startsWith('--')) fail(2, `Unknown option ${a}.\n\n${USAGE}`);
  else if (target === null) target = a;
  else fail(2, `Only one database file may be given.\n\n${USAGE}`);
}
if (!target) fail(2, `A database file path is required (there is no default).\n\n${USAGE}`);
for (const [name, value] of [['--go-live', options.goLive], ['--through', options.through]]) {
  if (value !== null && !isValidDate(value)) fail(2, `${name} must be a real date such as 2026-11-06 (got "${value}").`);
}

// ---- safety: never a production folder, never an in-use database ----------
const resolved = path.resolve(target);
if (resolved.split(/[\\/]/).some((segment) => segment.toLowerCase() === 'cciq-production')) {
  fail(1, `Refusing ${resolved}: it is inside a "cciq-production" folder. This tool is for a restored COPY of a database, never the live one.`);
}
for (const sidecar of [`${resolved}-wal`]) {
  try {
    if (fs.statSync(sidecar).size > 0) {
      fail(1, `Refusing ${resolved}: a non-empty "${path.basename(sidecar)}" sits beside it, which means it is an in-use database. Restore a backup to a scratch folder and point at that copy.`);
    }
  } catch { /* no sidecar: fine */ }
}

let db;
try {
  db = new Database(resolved, { readonly: true, fileMustExist: true });
  db.pragma('query_only = ON');
} catch (err) {
  fail(1, `Could not open ${target} read-only: ${err.message}`);
}

const tableExists = (name) => Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?").get(name));
let exitCode = 0;
try {
  for (const table of ['members', 'member_status_history']) {
    if (!tableExists(table)) fail(1, `${target} does not look like a CCIQ database (no "${table}" table).`);
  }
  const migration = tableExists('schema_migrations')
    ? db.prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1').get()?.version || null
    : null;

  const members = db.prepare('SELECT id, member_code, status, created_at, date_joined FROM members ORDER BY id').all();
  const byMember = new Map();
  for (const row of db.prepare('SELECT id, member_id, previous_status, new_status, changed_at FROM member_status_history').all()) {
    if (!byMember.has(row.member_id)) byMember.set(row.member_id, []);
    byMember.get(row.member_id).push(row);
  }
  const chronological = (list) => [...list].sort((a, b) => a.changed_at.localeCompare(b.changed_at) || a.id - b.id);
  const label = (m) => m.member_code || `#${m.id}`;

  // 0. Is the raw history usable at all? (Independent of the chain check below.)
  const quality = {
    statusesOutsideCatalogue: [], invalidTimestamps: [], noopTransitions: [], duplicateTransitions: [],
    predatesRecord: [], futureDated: [], chainBreaks: 0, tailMismatches: 0
  };
  const isIso = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(v) && !Number.isNaN(Date.parse(v));
  const memberById = new Map(members.map((m) => [m.id, m]));
  const seenTransitions = new Map();
  const nowIso = new Date().toISOString();
  for (const m of members) if (!MEMBER_STATUS_CATALOGUE.includes(m.status)) quality.statusesOutsideCatalogue.push({ memberId: m.id, where: 'members.status', value: m.status });
  for (const [memberId, rows] of byMember) {
    const owner = memberById.get(memberId);
    for (const r of rows) {
      for (const field of ['previous_status', 'new_status']) {
        if (r[field] !== null && !MEMBER_STATUS_CATALOGUE.includes(r[field])) quality.statusesOutsideCatalogue.push({ memberId, where: `history.${field}`, value: r[field] });
      }
      if (r.new_status === null) quality.statusesOutsideCatalogue.push({ memberId, where: 'history.new_status', value: null });
      if (!isIso(r.changed_at)) { quality.invalidTimestamps.push({ memberId, historyId: r.id, value: r.changed_at ?? null }); continue; }
      if (r.previous_status !== null && r.previous_status === r.new_status) quality.noopTransitions.push({ memberId, historyId: r.id, status: r.new_status, at: r.changed_at });
      const key = [memberId, r.previous_status, r.new_status, r.changed_at].join('|');
      if (seenTransitions.has(key)) quality.duplicateTransitions.push({ memberId, historyIds: [seenTransitions.get(key), r.id], at: r.changed_at });
      else seenTransitions.set(key, r.id);
      if (owner && isIso(owner.created_at) && Date.parse(r.changed_at) < Date.parse(owner.created_at) - 60000) {
        quality.predatesRecord.push({ memberId, historyId: r.id, at: r.changed_at, recordCreated: owner.created_at });
      }
      if (r.changed_at > nowIso) quality.futureDated.push({ memberId, historyId: r.id, at: r.changed_at });
    }
  }

  // 1. Is each member's own history coherent?
  const noHistory = [];
  const contradictions = [];
  let coherent = 0;
  for (const member of members) {
    const history = byMember.get(member.id) || [];
    if (history.length === 0) { noHistory.push(member); continue; }
    const check = checkHistoryChain(history, member.status);
    if (check.consistent) coherent += 1;
    else contradictions.push({ member, issues: check.issues });
    for (const issue of check.issues) {
      if (issue.code === 'chain_break') quality.chainBreaks += 1;
      else quality.tailMismatches += 1;
    }
  }
  const qualityCount = quality.statusesOutsideCatalogue.length + quality.invalidTimestamps.length + quality.noopTransitions.length
    + quality.duplicateTransitions.length + quality.predatesRecord.length + quality.futureDated.length;
  if (contradictions.length || qualityCount) exitCode = 3;

  // 2. With a proposed Go-Live: classify every member for every Friday, as finalization would.
  let analysis = null;
  if (options.goLive) {
    const first = nextFridayOnOrAfter(options.goLive);
    const last = options.through || today();
    const fridays = [];
    for (let d = first; d <= last; d = addDays(d, 7)) fridays.push(d);
    const totals = { exact: 0, inferred: 0, ambiguous: 0 };
    const basisTotals = {};
    const perMember = new Map();
    for (const member of members) {
      const history = byMember.get(member.id) || [];
      for (const friday of fridays) {
        const result = evaluateExpectation({
          history, currentStatus: member.status, createdAt: member.created_at, dateJoined: member.date_joined, serviceDate: friday
        });
        totals[result.certainty] += 1;
        basisTotals[`${result.certainty}:${result.basis}`] = (basisTotals[`${result.certainty}:${result.basis}`] || 0) + 1;
        if (result.certainty === 'ambiguous') {
          if (!perMember.has(member.id)) perMember.set(member.id, { member, fridays: [], bases: new Set() });
          const entry = perMember.get(member.id);
          entry.fridays.push(friday);
          entry.bases.add(result.basis);
        }
      }
    }
    const ambiguousMembers = [...perMember.values()].map((e) => {
      const history = chronological(byMember.get(e.member.id) || []);
      return {
        member: e.member.member_code || null,
        memberId: e.member.id,
        currentStatus: e.member.status,
        basis: [...e.bases].sort(),
        ambiguousFridays: e.fridays.length,
        firstAmbiguousFriday: e.fridays[0],
        lastAmbiguousFriday: e.fridays[e.fridays.length - 1],
        historyEntries: history.length,
        firstHistoryAt: history[0]?.changed_at || null,
        lastHistoryAt: history[history.length - 1]?.changed_at || null,
        createdAt: e.member.created_at
      };
    });
    analysis = {
      goLive: options.goLive, firstFriday: first, throughFriday: last, fridays: fridays.length,
      classifications: totals, basisTotals, membersWithAmbiguity: ambiguousMembers.length, ambiguousMembers
    };
    if (ambiguousMembers.length) exitCode = 3;
  }

  // Human-review section: who to look at, never what the answer is.
  let humanReview = null;
  if (options.humanReview) {
    const suggest = (codes) => {
      const categories = new Set();
      for (const code of codes) {
        if (code === 'chain_break') categories.add('a status change is missing or was recorded against the wrong previous status - check the member\'s status history');
        else if (code === 'tail_mismatch') categories.add('the current status differs from the last recorded change - the status was changed outside the portal, or a record is missing');
        else if (code === 'created_after_service') categories.add('the earliest evidence of this member is later than the service date - check the record\'s created and joined dates');
        else if (code === 'history_inconsistent') categories.add('the recorded history contradicts itself - review it end to end');
        else categories.add('review the record');
      }
      return [...categories];
    };
    const ids = new Set(contradictions.map((c) => c.member.id));
    if (analysis) for (const m of analysis.ambiguousMembers) ids.add(m.memberId);
    humanReview = [...ids].sort((a, b) => a - b).map((id) => {
      const m = db.prepare('SELECT id, member_code, first_name, last_name, status, created_at, date_joined FROM members WHERE id = ?').get(id);
      const contradiction = contradictions.find((c) => c.member.id === id);
      const ambiguity = analysis ? analysis.ambiguousMembers.find((a) => a.memberId === id) : null;
      const codes = [...(contradiction ? contradiction.issues.map((i) => i.code) : []), ...(ambiguity ? ambiguity.basis : [])];
      return {
        memberId: m.id, memberCode: m.member_code, name: `${m.first_name} ${m.last_name}`.trim(), currentStatus: m.status,
        recordCreated: m.created_at, dateJoined: m.date_joined,
        statusSequence: chronological(byMember.get(id) || []).map((h) => ({ at: h.changed_at, from: h.previous_status, to: h.new_status })),
        reasons: [...new Set(codes)], suggestedReview: suggest(codes)
      };
    });
  }

  const report = {
    database: path.basename(resolved),
    readOnly: true,
    migrationLevel: migration,
    members: members.length,
    history: {
      coherent,
      withHistory: members.length - noHistory.length,
      noHistory: noHistory.length,
      totalEntries: [...byMember.values()].reduce((n, rows) => n + rows.length, 0),
      chainBreaks: quality.chainBreaks,
      tailMismatches: quality.tailMismatches,
      contradictory: contradictions.map((c) => ({
        member: c.member.member_code || null,
        memberId: c.member.id,
        currentStatus: c.member.status,
        issues: c.issues.map((i) => (i.code === 'chain_break'
          ? { code: 'chain_break', at: i.at, expectedPrevious: i.expectedPrevious, recordedPrevious: i.recordedPrevious }
          : { code: i.code, lastRecorded: i.lastRecorded, current: i.current }))
      }))
    },
    dataQuality: {
      statusesOutsideCatalogue: quality.statusesOutsideCatalogue.length,
      invalidTimestamps: quality.invalidTimestamps.length,
      noopTransitions: quality.noopTransitions.length,
      duplicateTransitions: quality.duplicateTransitions.length,
      historyPredatesRecord: quality.predatesRecord.length,
      futureDated: quality.futureDated.length,
      detail: options.json ? quality : undefined
    },
    analysis,
    humanReview,
    exitCode
  };

  if (options.json) {
    console.log(JSON.stringify(report, null, 2));
  } else {
    const lines = [];
    lines.push('READ-ONLY status-history diagnostic - nothing in the database was changed.');
    lines.push(`Database: ${report.database}   migration level: ${migration || 'unknown'}`);
    lines.push(`Members: ${members.length}`);
    lines.push(`  coherent history:                     ${coherent}`);
    lines.push(`  no history at all:                    ${noHistory.length}`);
    lines.push('    (inferred to have held their current status throughout - acceptable only if every status change');
    lines.push('     was recorded, which the application guarantees for changes made through it)');
    lines.push(`  history contradicts itself/current:   ${contradictions.length}   (chain breaks ${quality.chainBreaks}, last-recorded vs current mismatches ${quality.tailMismatches})`);
    lines.push(`Data quality of the raw history (${report.history.totalEntries} entries):`);
    lines.push(`  unsupported status values:            ${quality.statusesOutsideCatalogue.length}`);
    lines.push(`  missing or invalid timestamps:        ${quality.invalidTimestamps.length}`);
    lines.push(`  no-op transitions (from = to):        ${quality.noopTransitions.length}`);
    lines.push(`  duplicate transitions:                ${quality.duplicateTransitions.length}`);
    lines.push(`  history dated before the record:      ${quality.predatesRecord.length}`);
    lines.push(`  history dated in the future:          ${quality.futureDated.length}`);
    for (const c of contradictions.slice(0, 25)) {
      lines.push(`    ${label(c.member)} (now ${c.member.status}): ` + c.issues.map((i) => (i.code === 'chain_break'
        ? `chain break at ${i.at} (expected previous "${i.expectedPrevious}", recorded "${i.recordedPrevious}")`
        : `last recorded "${i.lastRecorded}" but current is "${i.current}"`)).join('; '));
    }
    if (contradictions.length > 25) lines.push(`    ... and ${contradictions.length - 25} more (use --json for all)`);
    if (analysis) {
      lines.push('');
      lines.push(`Go-Live analysis: ${analysis.fridays} Friday(s), ${analysis.firstFriday} to ${analysis.throughFriday}`);
      lines.push(`  exact:      ${analysis.classifications.exact}   (a history entry directly establishes the status)`);
      lines.push(`  inferred:   ${analysis.classifications.inferred}   (history is silent but consistent with one answer)`);
      lines.push(`  ambiguous:  ${analysis.classifications.ambiguous}   (finalization would REFUSE these - fix before Go-Live)`);
      lines.push(`  members with any ambiguity: ${analysis.membersWithAmbiguity}`);
      for (const m of analysis.ambiguousMembers.slice(0, 50)) {
        lines.push(`    ${m.member || `#${m.memberId}`} (now ${m.currentStatus}): ${m.basis.join(', ')}; ambiguous on ${m.ambiguousFridays} Friday(s) `
          + `from ${m.firstAmbiguousFriday}; ${m.historyEntries} history entr${m.historyEntries === 1 ? 'y' : 'ies'}`
          + (m.firstHistoryAt ? ` (${m.firstHistoryAt.slice(0, 10)} to ${m.lastHistoryAt.slice(0, 10)})` : '')
          + `; record created ${String(m.createdAt).slice(0, 10)}`);
      }
      if (analysis.ambiguousMembers.length > 50) lines.push(`    ... and ${analysis.ambiguousMembers.length - 50} more (use --json for all)`);
      lines.push('  By basis: ' + (Object.keys(analysis.basisTotals).sort().map((k) => k + ' ' + analysis.basisTotals[k]).join('; ') || 'none'));
      lines.push('  Basis codes: history_inconsistent = the recorded changes contradict each other or the current status;');
      lines.push('               created_after_service = the earliest evidence of the member is after that Friday.');
    } else {
      lines.push('');
      lines.push('Tip: add --go-live <Friday> to classify every member for each Friday from the proposed Go-Live.');
    }
    if (humanReview) {
      lines.push('');
      lines.push(`Human review (${humanReview.length} member${humanReview.length === 1 ? '' : 's'}) - nothing here is a proposed correction:`);
      for (const h of humanReview) {
        lines.push(`  #${h.memberId} ${h.memberCode || ''} ${h.name} (now ${h.currentStatus}; record created ${String(h.recordCreated).slice(0, 10)}; joined ${h.dateJoined || 'not recorded'})`);
        lines.push(`    sequence: ${h.statusSequence.map((s) => `${s.at} ${s.from || '(start)'} -> ${s.to}`).join(' | ') || '(no entries)'}`);
        lines.push(`    reasons: ${h.reasons.join(', ')}; suggested review: ${h.suggestedReview.join('; ')}`);
      }
    }
    lines.push('');
    lines.push(exitCode === 0 ? 'Result: nothing needs attention.' : 'Result: at least one member needs attention (exit 3).');
    console.log(lines.join('\n'));
  }
} catch (err) {
  console.error(`Check failed: ${err.message}`);
  exitCode = 1;
} finally {
  db.close();
}
process.exit(exitCode);
