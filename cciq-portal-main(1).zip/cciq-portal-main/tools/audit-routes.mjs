/**
 * Reads every route file and reports the guards on each route, so a route that
 * is protected only by hiding its link in the interface shows up here.
 */
import fs from 'node:fs';
import path from 'node:path';

import { fileURLToPath } from 'node:url';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'routes');

// Routes that are deliberately open, with the reason they are safe.
const PUBLIC = {
  'GET /healthz': 'liveness check, no data',
  'GET /login': 'sign-in form',
  'POST /login': 'sign-in, rate limited',
  'GET /logout': 'ends a session',
  'POST /logout': 'ends a session',
  // There is no self-service reset flow (no email sending) — this route
  // only renders a static page telling the visitor to contact an admin.
  // Resets happen via an admin-mediated route (admin.users permission) or
  // the account:password CLI script run on the church PC.
  'GET /forgot-password': 'static page, tells the visitor to contact an administrator',

  /*
   * The About page is deliberately open to visitors, controlled by the
   * church.public_about setting. It carries the church's own information only:
   * no member names, no contact details, and no cell group meeting addresses.
   */
  'GET /about': 'public church page when enabled, otherwise redirects to sign in',
  'GET /about/cell-groups/:id(\\\\d+)/quick': 'cell group name and meeting day only, no address or members',
  'GET /about/ministries/:id(\\\\d+)/quick': 'ministry name and description only, no members',
  'GET /about/leaders/:id(\\\\d+)/photo': 'leadership photo already shown on the public page',
  'GET /about/cell-groups/:id(\\\\d+)/photo': 'cell group photo already shown on the public page',
  'GET /about/ministries/:id(\\\\d+)/photo': 'ministry photo already shown on the public page',

  /*
   * Quick Access exists so nobody has to find/read out/type this computer's
   * LAN IP address — reachable without signing in on purpose, and contains
   * nothing but that address (no credentials, session, or member data).
   * Scanning it only opens the ordinary login page. See quick-access.js and
   * CCIQ_DECISIONS.md.
   */
  'GET /quick-access/info': 'public portal URL only, no credentials or member data',
  'GET /quick-access/card.png': 'a printable card of the same public portal URL, no credentials or member data'
};

// Routes for any signed-in user, where the handler scopes the data itself.
const SELF_SCOPED = {
  'GET /': 'dashboard, branches by permission',
  'GET /account/password': 'own password',
  'POST /account/password': 'own password',
  'GET /my/profile': 'own record',
  'POST /my/profile': 'own record',
  'POST /my/profile/photo': 'own record',
  'GET /about': 'the church\'s own mission and leadership, readable by any signed-in member',
  'GET /search': 'each source inside search applies its own permission rules',
  'GET /media/leaders/:id(\\\\d+)': 'leadership photos, shown to anyone signed in, as the About page is',
  'GET /media/groups/:id(\\\\d+)/photo': 'cell group photo, shown to anyone signed in, as the group name is',
  'GET /media/ministries/:id(\\\\d+)/photo': 'ministry photo, shown to anyone signed in, as the ministry name is',
  'GET /help': 'the User Guide: the page itself holds only the chapters, steps and pictures for the signed-in person\'s roles (src/lib/user-guide.js)',
  'GET /help/assets/:name': 'the guide\'s stylesheet, script and logo, from an exact allow-list, for any signed-in person',
  'GET /help/screenshots/:name': 'a guide picture, sent only if its figure is on the signed-in person\'s own guide page (the same role check)',
  'GET /notifications': 'own notifications only',
  'POST /notifications/:id(\\\\d+)/read': 'own notifications only',
  'POST /notifications/read-all': 'own notifications only',
  'GET /media/members/:id(\\\\d+)/photo': 'permission checked inside the handler',
  'GET /media/activity/:id(\\\\d+)': 'visibility checked inside the handler'
};

const rows = [];
for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.js'))) {
  const source = fs.readFileSync(path.join(dir, file), 'utf8');
  // Find each router.<method>('<path>' and read forward to where the handler
  // begins, so middleware spread over several lines is still captured.
  const starts = [...source.matchAll(/router\.(get|post|put|patch|delete)\(\s*'([^']+)'/g)];
  for (const start of starts) {
    const from = start.index + start[0].length;
    const handlerAt = source.slice(from).search(/(?:async\s*)?\((?:req|_req)\b/);
    const middlewareBlob = handlerAt === -1 ? '' : source.slice(from, from + handlerAt);
    rows.push({
      file,
      method: start[1].toUpperCase(),
      route: start[2],
      auth: /requireAuth/.test(middlewareBlob),
      // checkinAccess (src/middleware/auth.js) is a permission (attendance.record or attendance.checkin) AND a kind-of-sign-in check (Kiosk account, Church Admin, Super Admin).
      permission: [...[...middlewareBlob.matchAll(/require(?:Any)?Permission\(([^)]*)\)/g)].map((m) => m[1].replace(/['\s]/g, '')),
        ...(/\bcheckinAccess\b/.test(middlewareBlob) ? ['attendance.record|attendance.checkin'] : [])].join(' | '),
      role: [...[...middlewareBlob.matchAll(/requireRole\(([^)]*)\)/g)].map((m) => m[1].replace(/['\s]/g, '')),
        ...(/\bcheckinAccess\b/.test(middlewareBlob) ? ['kiosk,church_admin,super_admin'] : [])].join(' | ')
    });
  }
}

console.log(`Routes found: ${rows.length}\n`);

const problems = [];
for (const row of rows) {
  const key = `${row.method} ${row.route}`;
  if (PUBLIC[key]) continue;

  if (!row.auth) {
    problems.push(`UNAUTHENTICATED  ${key}  (${row.file})`);
    continue;
  }
  if (!row.permission && !row.role) {
    if (!SELF_SCOPED[key]) {
      problems.push(`NO PERMISSION    ${key}  (${row.file})`);
    }
  }
}

console.log('--- guarded routes ---');
for (const row of rows.filter((r) => r.permission || r.role)) {
  console.log(`  ${row.method.padEnd(4)} ${row.route.padEnd(52)} ${row.permission}${row.role ? ` +role:${row.role}` : ''}`);
}

console.log('\n--- open by design ---');
for (const row of rows) {
  const key = `${row.method} ${row.route}`;
  if (PUBLIC[key]) console.log(`  ${key.padEnd(58)} ${PUBLIC[key]}`);
}

console.log('\n--- signed in, scoped in the handler ---');
for (const row of rows) {
  const key = `${row.method} ${row.route}`;
  if (SELF_SCOPED[key] && !row.permission) console.log(`  ${key.padEnd(58)} ${SELF_SCOPED[key]}`);
}

console.log('\n--- findings ---');
if (problems.length === 0) {
  console.log('  Every route is either authenticated with a permission, or accounted for above.');
} else {
  problems.forEach((p) => console.log(`  ${p}`));
}

// Restore must be Super Admin by role, not only by permission.
const restore = rows.find((r) => r.route.includes('/restore'));
console.log('\n--- backup restore ---');
if (!restore) {
  console.log('  NOT FOUND');
} else {
  console.log(`  permission: ${restore.permission || 'none'}`);
  console.log(`  role:       ${restore.role || 'none'}`);
  console.log(`  ${restore.permission.includes('admin.backups.restore') && restore.role.includes('super_admin')
    ? 'Restricted to Super Admin by both permission and role.'
    : 'PROBLEM: not restricted to Super Admin.'}`);
}

process.exit(problems.length === 0 ? 0 : 1);
