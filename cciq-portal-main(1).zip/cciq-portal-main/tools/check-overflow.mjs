/**
 * Signs in against a running copy of the portal and checks a fixed list of
 * critical pages, at a fixed list of viewport widths, for unexpected
 * page-level horizontal overflow — the same class of bug a real phone found
 * on the authenticated header (see CCIQ_DECISIONS.md, "Portal-wide
 * responsive UI/UX hardening"). Never run against a production database;
 * point BASE_URL at a disposable test server.
 *
 * Usage:
 *   node tools/check-overflow.mjs
 *   BASE_URL=http://localhost:3050 CCIQ_TEST_USER=... CCIQ_TEST_PASSWORD=... node tools/check-overflow.mjs
 *
 * A deliberately horizontally-scrollable element (a wide table's own
 * `.table-wrap`, or anything else marked `data-scroll-x`) is allowed to have
 * content wider than itself — that is its job — so it is excluded rather
 * than flagged. Only genuine page-level overflow (the whole document
 * becoming wider than the viewport) is reported.
 */
import { chromium } from 'playwright';
import { pathToFileURL } from 'node:url';

const BASE_URL = process.env.BASE_URL || 'http://localhost:3050';
const USERNAME = process.env.CCIQ_TEST_USER || 'system.administrator';
const PASSWORD = process.env.CCIQ_TEST_PASSWORD || '';

export const BREAKPOINTS = [320, 360, 375, 390, 412, 430, 600, 768, 820, 1024, 1280, 1440];

export const CRITICAL_PAGES = [
  '/',
  '/members',
  '/members/new',
  '/attendance',
  '/attendance/checkin',
  '/kiosk',
  '/family-groups',
  '/family-groups/new',
  '/cell-groups',
  '/ministries',
  '/ministries/serving',
  '/visitors/follow-up',
  '/reports',
  '/admin/audit',
  '/admin/users',
  '/admin/settings',
  '/documents',
  '/announcements',
  '/reminders',
  '/about',
  '/calendar',
  '/activities'
];

/** Injected into the page; see the file header for what counts as a real bug. */
export const OVERFLOW_CHECK_SCRIPT = () => {
  const vw = document.documentElement.clientWidth;
  const scrollWidth = document.documentElement.scrollWidth;
  if (scrollWidth <= vw + 1) return { overflow: false, scrollWidth, clientWidth: vw, offenders: [] };

  const offenders = [];
  document.querySelectorAll('body *').forEach((el) => {
    if (el.closest('.table-wrap, .chart-scroll, [data-scroll-x]')) return;
    if (el.closest('.sidenav') && !document.body.classList.contains('drawer-open')) return;
    const r = el.getBoundingClientRect();
    if (r.right > vw + 1 || r.left < -1) {
      const cls = el.className && el.className.toString ? el.className.toString().trim() : '';
      offenders.push({
        selector: el.tagName.toLowerCase() + (cls ? '.' + cls.split(/\s+/).join('.') : ''),
        left: Math.round(r.left), right: Math.round(r.right), width: Math.round(r.width)
      });
    }
  });
  return { overflow: true, scrollWidth, clientWidth: vw, offenders: offenders.slice(0, 10) };
};

async function main() {
  if (!PASSWORD) {
    console.error('Set CCIQ_TEST_PASSWORD to a throwaway test account\'s password before running this.');
    process.exit(1);
  }

  const browser = await chromium.launch();
  const page = await browser.newPage();

  await page.goto(`${BASE_URL}/login`);
  await page.fill('#email', USERNAME);
  await page.fill('#password', PASSWORD);
  await Promise.all([page.waitForNavigation(), page.click('button[type="submit"]')]);

  let failures = 0;
  let checks = 0;
  let skipped = 0;

  for (const path of CRITICAL_PAGES) {
    for (const width of BREAKPOINTS) {
      // Paced well under the portal's own rate limiter (300 requests/minute,
      // shared by every route including static assets) rather than asking
      // for that protection to be loosened just to run this test faster.
      await page.waitForTimeout(300);
      await page.setViewportSize({ width, height: 900 });

      let res = await page.goto(`${BASE_URL}${path}`, { waitUntil: 'load', timeout: 15000 }).catch(() => null);
      if (res && res.status() === 429) {
        // The limiter's window is fixed, not sliding — once tripped, every
        // request fails instantly until it resets, so retrying immediately
        // would just burn through the rest of the run the same way. One
        // wait-and-retry is worth it; a page still rate-limited after that
        // is worth knowing about, not worth stalling the whole run over.
        console.log(`  (rate limited on ${path} @ ${width}px — waiting 65s for the window to reset)`);
        await page.waitForTimeout(65000);
        res = await page.goto(`${BASE_URL}${path}`, { waitUntil: 'load', timeout: 15000 }).catch(() => null);
      }

      if (!res || !res.ok()) {
        console.log(`SKIP  ${path} @ ${width}px  (${res ? 'status ' + res.status() : 'navigation error'})`);
        skipped++;
        continue;
      }
      checks++;
      const result = await page.evaluate(OVERFLOW_CHECK_SCRIPT);
      if (result.overflow) {
        failures++;
        console.log(`OVERFLOW  ${path} @ ${width}px  (scrollWidth ${result.scrollWidth} > clientWidth ${result.clientWidth})`);
        result.offenders.forEach((o) => console.log(`    ${o.selector}  left=${o.left} right=${o.right} width=${o.width}`));
      }
    }
  }

  await browser.close();
  console.log(`\n${checks} page/width combinations checked, ${skipped} skipped (unreachable page), ${failures} with unexpected overflow.`);
  // Not process.exit(): when stdout is redirected to a file rather than a
  // terminal, an immediate exit can beat Node's own buffered stdout flush,
  // silently truncating exactly the summary line this script exists to
  // print. Setting exitCode and letting the event loop drain naturally
  // (nothing else is pending once the browser is closed) exits just as
  // promptly without that race.
  process.exitCode = failures > 0 ? 1 : 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main();
}
