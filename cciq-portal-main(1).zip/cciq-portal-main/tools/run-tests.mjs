import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

/*
 * The one documented way to get a meaningful regression result: runs every
 * test in src/tests/ as its own process (so a fixed port or a leftover
 * Playwright browser in one suite can never affect another), in a fixed
 * order — fast/isolation checks first, so a real isolation bug is caught
 * before any heavier suite spends minutes proving something on top of it.
 *
 * Every suite already builds its own throwaway database via
 * src/tests/lib/test-env.mjs, which fails closed if a path is not
 * demonstrably outside the real project — this runner adds no isolation of
 * its own beyond running each suite as a separate process; it is not what
 * makes this safe, the suites themselves are.
 */
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const testsDir = path.join(root, 'src', 'tests');

const ORDER = [
  'test-env-isolation.mjs',
  'quick-access-public.mjs',
  'test-env-order-guard.mjs',
  'no-store-headers.mjs',
  'healthz-db-check.mjs',
  'attendance-tracking-foundation.mjs',
  'attendance-finalization-lifecycle.mjs',
  'attendance-outcomes-consumers.mjs',
  'attendance-followup-hardening.mjs',
  'status-history-diagnostic.mjs',
  'users-admin-list.mjs',
  'attendance-landing-ux.mjs',
  'ministries-serving-list.mjs',
  'cell-groups-list.mjs',
  'reports-screen-paging.mjs',
  'settings-sections.mjs',
  'about-editor-ux.mjs',
  'profile-photo-ux.mjs',
  'family-relationship-identity.mjs',
  'members-population-default.mjs',
  'physical-review-corrections.mjs',
  'list-paging-boundaries.mjs',
  'first-timer-workflow.mjs',
  'kiosk-visitor-search.mjs',
  'kiosk-red-team.mjs',
  'express-registration-safety.mjs',
  'first-timer-validation-ux.mjs',
  'first-timer-status-display.mjs',
  'first-timer-browser.mjs',
  'form-validation-ux.mjs',
  'input-boundary-torture.mjs',
  'browser-role-crawl.mjs',
  'rbac-idor-redteam.mjs',
  'security-headers.mjs',
  'kiosk-red-team-round2.mjs',
  'kiosk-authorization.mjs',
  'initial-password.mjs',
  'login-page.mjs',
  'attendance-report-terms.mjs',
  'race-attendance-finalize.mjs',
  'concurrency-http-extra.mjs',
  'audit-failure-atomicity.mjs',
  'atomic-response-after-commit.mjs',
  'attendance-model-torture.mjs',
  'qatar-clock-sweep.mjs',
  'report-reconciliation.mjs',
  'file-attack-round2.mjs',
  'backup-restore-round2.mjs',
  'search-round2.mjs',
  'ecaq-amount-boundaries.mjs',
  'operational-failures.mjs',
  'friday-simulation.mjs',
  'service-headcount.mjs',
  'faith-promise-integrity.mjs',
  'cell-group-add-member-layout.mjs',
  'bonafide-presentation.mjs',
  'sanitized-artwork.mjs',
  'kiosk-select-all.mjs',
  'verse-of-the-day.mjs',
  'attendance-drill-down.mjs',
  'membership-review.mjs',
  'membership-review-model.mjs',
  'membership-review-explained.mjs',
  'first-timer-routes-render.mjs',
  'occasions-pdf.mjs',
  'kiosk-phone-search.mjs',
  'faith-promise-access.mjs',
  'faith-promise-amendments.mjs',
  'member-cell-group.mjs',
  'search-by-role.mjs',
  'member-status-chips.mjs',
  'responsive-sweep-overnight.mjs',
  'race-torture.mjs',
  'first-timer-scale.mjs',
  'first-timer-review-routes.mjs',
  'first-timer-report-math.mjs',
  'member-creation-parity.mjs',
  'migration-0030.mjs',
  'migration-0030-torture.mjs',
  'first-timer-headcount-characterization.mjs',
  'css-design-tokens.mjs',
  'ux-accessibility-sweep.mjs',
  'route-hygiene.mjs',
  'rbac-route-matrix.mjs',
  'idor-object-scope.mjs',
  'mutation-atomicity.mjs',
  'double-submit.mjs',
  'db-invariants.mjs',
  'qatar-date-boundaries.mjs',
  'first-timer-qatar-clock.mjs',
  'ecaq-money-integrity.mjs',
  'ecaq-campaign-ledger.mjs',
  'giving-board-detail.mjs',
  'kiosk-already-checked-in.mjs',
  'returning-first-timer.mjs',
  'giving-board-months.mjs',
  'giving-board-admin-workflow.mjs',
  'giving-board-church-admin-chain.mjs',
  'ministries-nav-avatar.mjs',
  'ecaq-admin-forms.mjs',
  'search-consistency.mjs',
  'paging-torture.mjs',
  'navigation-integrity.mjs',
  'error-handling.mjs',
  'upload-download-safety.mjs',
  'file-handling-extra.mjs',
  'env-settings-consistency.mjs',
  'session-auth-regression.mjs',
  'audit-completeness.mjs',
  'privacy-exposure.mjs',
  'report-consistency.mjs',
  'pdf-structure.mjs',
  'ui-a11y-responsive-deep.mjs',
  'keyboard-a11y.mjs',
  'css-contrast.mjs',
  'static-asset-policy.mjs',
  'xss-reflection.mjs',
  'template-hygiene.mjs',
  'css-hygiene.mjs',
  'first-timer-integrity.mjs',
  'backup-archive-hostile.mjs',
  'performance-smoke.mjs',
  'test-harness-hygiene.mjs',
  'attendance-torture.mjs',
  'query-count.mjs',
  'hostile-post-fuzz.mjs',
  'form-and-query-audit.mjs',
  'browser-flows.mjs',
  'navigation-audit.mjs',
  'chaos-faults.mjs',
  'log-hygiene.mjs',
  'responsive-stress.mjs',
  'ui-responsive-layout.mjs',
  'password-security.mjs',
  'credential-secrecy.mjs',
  'bootstrap-credential-safety.mjs',
  'session-versioning.mjs',
  'reports-service.mjs',
  'reports-refinement.mjs',
  'attendance-status-population-consistency.mjs',
  'attendance-scope-authorization.mjs',
  'attendance-mutation-invariants.mjs',
  'temporarily-away-auto-return-scope.mjs',
  'import-integrity.mjs',
  'import-date-integrity.mjs',
  'document-audience-security.mjs',
  'document-uploader-escalation.mjs',
  'documents-audience.mjs',
  'migration-0031.mjs',
  'migration-0032.mjs',
  'migration-0033.mjs',
  'faith-promise-received-by.mjs',
  'campaign-report-boundaries.mjs',
  'report-launcher-spacing.mjs',
  'reports-sweep.mjs',
  'attendance-tracking-start-control.mjs',
  'finalization-blocked-wording.mjs',
  'dob-quality.mjs',
  'storage-references.mjs',
  'backup-crypt.mjs',
  'restore-backup.mjs',
  'weekday-determinism.mjs',
  'kiosk-scan-vs-search.mjs',
  'user-guide-help.mjs',
  'announcement-audience-security.mjs',
  'delegated-admin-super-admin-protection.mjs',
  'backup-disk-preflight.mjs',
  'backup-restore-extra.mjs',
  'backup-integrity.mjs',
  'restore-failure-safety.mjs',
  'restore-compat-and-lifecycle.mjs',
  'pid-lock.mjs',
  'supervisor-crash-recovery.mjs',
  'user-deactivation.mjs',
  'post-activation.mjs',
  'kiosk-session.mjs'
];

function run(file) {
  return new Promise((resolve) => {
    const started = Date.now();
    const child = spawn(process.execPath, [path.join(testsDir, file)], { stdio: 'inherit' });
    child.on('exit', (code) => resolve({ file, code, seconds: Math.round((Date.now() - started) / 1000) }));
  });
}

console.log(`Running ${ORDER.length} test suites, one at a time, each in its own isolated throwaway database.\n`);

// --keep-going runs every suite even after one fails (to see every failure in one run); the default still stops at the first.
const keepGoing = process.argv.includes('--keep-going');
const results = [];
for (const file of ORDER) {
  console.log(`\n--- ${file} ---`);
  const result = await run(file);
  results.push(result);
  if (result.code !== 0) {
    console.log(`\n${file} FAILED (exit ${result.code}) after ${result.seconds}s${keepGoing ? '' : ' — stopping here.'}`);
    if (!keepGoing) break;
  }
}

console.log('\n=== Summary ===');
for (const r of results) {
  console.log(`  ${r.code === 0 ? 'PASS' : 'FAIL'}  ${r.file}  (${r.seconds}s)`);
}
const ran = results.length;
const allPassed = results.every((r) => r.code === 0);
if (ran < ORDER.length) {
  console.log(`\n${ORDER.length - ran} suite(s) not run: a suite above failed first.`);
}
console.log(allPassed && ran === ORDER.length ? '\nAll suites passed.' : '\nNot all suites passed.');
process.exit(allPassed && ran === ORDER.length ? 0 : 1);
