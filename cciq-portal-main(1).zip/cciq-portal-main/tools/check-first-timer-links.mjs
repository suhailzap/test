import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { findFirstTimerLinkProblems, describeFirstTimerLinkProblems } from '../src/lib/first-timer-links.js';

/*
 * READ-ONLY pre-migration gate for migration 0030 (First Timer lifecycle). Reports First Timer records that break the rule
 * "a First Timer is 'joined' if and only if it is linked to a member, and a member belongs to at most one First Timer":
 *   A  joined without a member       B  linked to a member but not joined       C  one member linked from several First Timers
 * It never repairs anything and never guesses a member match. Point it at a COPY of a database (a verified backup restored to a
 * scratch folder), never the live one: it refuses a path inside a "cciq-production" folder and a database with a non-empty "-wal".
 * Output is ids only. Exit 0 = clean (0030 may proceed), 3 = rows need an administrator's decision first, 1 = could not run, 2 = usage.
 */

const USAGE = `Usage:
  node tools/check-first-timer-links.mjs <database-file> [--json]
  node tools/check-first-timer-links.mjs --help

READ-ONLY. Point it at a COPY of a database. There is no default path and no discovery.`;

const fail = (code, message) => { console.error(message); process.exit(code); };
const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) { console.log(USAGE); process.exit(0); }
let json = false; let target = null;
for (const a of args) {
  if (a === '--json') json = true;
  else if (a.startsWith('--')) fail(2, `Unknown option ${a}.\n\n${USAGE}`);
  else if (target === null) target = a;
  else fail(2, `Only one database file may be given.\n\n${USAGE}`);
}
if (!target) fail(2, `A database file path is required (there is no default).\n\n${USAGE}`);

const resolved = path.resolve(target);
if (resolved.split(/[\\/]/).some((s) => s.toLowerCase() === 'cciq-production')) {
  fail(1, `Refusing ${resolved}: it is inside a "cciq-production" folder. Use a restored COPY of a backup, never the live database.`);
}
try {
  if (fs.statSync(`${resolved}-wal`).size > 0) fail(1, `Refusing ${resolved}: a non-empty "-wal" file sits beside it, so it is an in-use database. Restore a backup to a scratch folder instead.`);
} catch { /* no sidecar: fine */ }

let db;
try { db = new Database(resolved, { readonly: true, fileMustExist: true }); db.pragma('query_only = ON'); } catch (err) { fail(1, `Could not open ${target} read-only: ${err.message}`); }
let problems;
try { problems = findFirstTimerLinkProblems(db); } catch (err) { fail(1, `Could not check ${target}: ${err.message}`); } finally { db.close(); }

if (json) console.log(JSON.stringify(problems, null, 2));
else if (problems.total === 0) console.log('First Timer links are consistent. Migration 0030 may proceed.');
else console.log(`First Timer links need an administrator's decision BEFORE migration 0030 (it will refuse to run):\n${describeFirstTimerLinkProblems(problems)}\nNothing was changed. No automatic repair exists, by design.`);
process.exit(problems.total === 0 ? 0 : 3);
