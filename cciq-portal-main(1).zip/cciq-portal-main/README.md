# CCIQ Portal

Private source for the CCIQ church management portal.

## Development

- Requires Node.js 20 or newer.
- Install dependencies with npm ci.
- Copy .env.example to .env and set local development values. Never use production secrets or production data in development.
- Run npm test to execute the automated checks.
- Run npm start to start a local instance.

The local database, uploads, and backups belong outside source control. The project ignore rules exclude common runtime paths and secret files. No production database or uploaded member files are included. Automated tests use isolated sample data.
