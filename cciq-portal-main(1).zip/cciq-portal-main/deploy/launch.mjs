import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { acquirePidLock } from '../scripts/lib/pid-lock.mjs';

/*
 * The production release launcher. AUTHORITATIVE SOURCE: this file, in Git.
 * It is copied into every assembled release as deploy/launch.mjs by
 * tools/assemble-release.mjs and is not edited inside a release.
 *
 * Usage: launch.mjs serve|backup|status|stop <absolute env file> <absolute runtime-state directory>
 *
 * How it differs from scripts/run-service.mjs (the older, single-checkout
 * supervisor) - all of it deliberate, none of it to be "simplified" away:
 *   - It lives inside an immutable release and runs THAT release only; the
 *     release is fixed for the life of the process.
 *   - Configuration is an explicit external env file, and mutable state (PID
 *     record, logs) lives in an explicit external runtime-state directory;
 *     both must be outside the release. Nothing is read from the release's
 *     own .env or written under it.
 *   - It verifies the release against release-manifest.json (sha256 of every
 *     listed file) before starting, refuses to start with a recovery
 *     interlock present, requires an explicit absolute database/storage/
 *     backup location that already exists, and never creates or migrates a
 *     database.
 *   - The child gets a minimal, explicit environment (no inherited app
 *     settings, no NODE_OPTIONS/NODE_PATH); the external file is
 *     authoritative.
 *   - It refuses to start on an occupied port rather than exiting quietly.
 *   - It runs a token-protected control channel (a named pipe on Windows) so
 *     `status` and `stop` act on THIS supervisor and its child together,
 *     instead of killing whatever owns a port.
 *   - The PID record is JSON ({ pid, token, release }), not a bare PID.
 *
 * PID ownership is taken through scripts/lib/pid-lock.mjs, the shared and
 * separately tested primitive (a bare exclusive create here once turned a
 * single unexpected process death into a permanent EEXIST that stopped the
 * scheduled task from ever starting the service again):
 *   no record                         -> take it and start
 *   record naming a live CCIQ service -> refuse: no duplicate instance
 *   record naming a dead process, or a PID reused by something else
 *                                     -> kept as evidence (quarantined), then start
 *   malformed / unidentifiable record -> refuse to start
 *   two launchers at once             -> exactly one takes ownership
 * On exit only this process's own record is removed.
 */
const release = fs.realpathSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'));
const [command, configArg, stateArg] = process.argv.slice(2);
if (!['serve', 'backup', 'status', 'stop'].includes(command) || !path.isAbsolute(configArg || '') || !path.isAbsolute(stateArg || '')) {
  throw new Error('Usage: launch.mjs serve|backup|status|stop <absolute env file> <absolute runtime-state directory>');
}
const configFile = fs.realpathSync(configArg);
const state = fs.realpathSync(stateArg);
const inside = (parent, target) => { const r = path.relative(parent, target); return r === '' || (!r.startsWith('..') && !path.isAbsolute(r)); };
if (inside(release, configFile) || inside(release, state)) throw new Error('Configuration and runtime state must be outside the release');
const recordFile = path.join(state, 'run-service.pid');
const pipe = process.platform === 'win32'
  ? `\\\\.\\pipe\\cciq-${crypto.createHash('sha256').update(state.toLowerCase()).digest('hex').slice(0, 24)}`
  : path.join(state, 'control.sock');

async function control(action) {
  const record = JSON.parse(fs.readFileSync(recordFile, 'utf8'));
  return new Promise((resolve, reject) => {
    const socket = net.connect(pipe);
    let response = '';
    socket.setTimeout(10000, () => socket.destroy(new Error('Supervisor control timed out')));
    socket.on('connect', () => socket.end(JSON.stringify({ action, token: record.token }) + '\n'));
    socket.on('data', chunk => { response += chunk; });
    socket.on('error', reject);
    socket.on('end', () => { try { resolve(JSON.parse(response)); } catch { reject(new Error('Invalid supervisor response')); } });
  });
}
if (command === 'stop' || command === 'status') {
  const result = await control(command);
  console.log(JSON.stringify(result));
  if (result.error) process.exitCode = 1;
} else {
  const values = dotenv.parse(fs.readFileSync(configFile));
  if (values.NODE_ENV === 'production' || fs.existsSync(path.join(release, 'release-manifest.json'))) {
    const manifest = JSON.parse(fs.readFileSync(path.join(release, 'release-manifest.json'), 'utf8'));
    if (!manifest.commit || !manifest.files?.length) throw new Error('Invalid release manifest');
    for (const entry of manifest.files) {
      const file = path.resolve(release, entry.path);
      if (!inside(release, file) || !inside(release, fs.realpathSync(file))) throw new Error('Manifest path escapes release');
      if (crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== entry.sha256) throw new Error(`Release hash mismatch: ${entry.path}`);
    }
  }
  for (const key of ['DATABASE_FILE', 'STORAGE_DIR', 'BACKUP_DIR']) {
    if (!path.isAbsolute(values[key] || '')) throw new Error(`${key} must be explicitly absolute`);
    const real = fs.realpathSync(values[key]); // missing database is a hard refusal
    if (inside(release, real)) throw new Error(`${key} must be outside the release`);
    values[key] = real;
  }
  if (!fs.statSync(values.DATABASE_FILE).isFile()) throw new Error('Database must be an existing file');
  for (const key of ['STORAGE_DIR', 'BACKUP_DIR']) if (!fs.statSync(values[key]).isDirectory()) throw new Error(`${key} must be a directory`);
  if (fs.existsSync(`${values.DATABASE_FILE}.RECOVERY_REQUIRED.json`)) throw new Error('Recovery interlock present; launch refused');
  if (!values.SESSION_SECRET || !values.HOST || !/^\d+$/.test(values.PORT || '') || Number(values.PORT) < 1 || Number(values.PORT) > 65535) throw new Error('Explicit session secret, host and valid port required');
  if (values.NODE_ENV !== 'production' && values.NODE_ENV !== 'test') throw new Error('Explicit production or test environment required');
  // Keep only OS launch essentials, excluding inherited application settings and
  // Node injection flags. The selected external file is authoritative.
  const env = {};
  for (const key of ['SystemRoot', 'WINDIR', 'PATH', 'Path', 'TEMP', 'TMP', 'USERPROFILE', 'HOME', 'COMSPEC']) if (process.env[key]) env[key] = process.env[key];
  Object.assign(env, values, { DOTENV_CONFIG_PATH: configFile });
  delete env.NODE_OPTIONS;
  delete env.NODE_PATH;
  const runtime = path.join(release, 'runtime', 'node.exe');
  if (!fs.existsSync(runtime)) throw new Error('Bundled runtime missing');
  const logs = path.join(state, 'logs');
  fs.mkdirSync(logs, { recursive: true });
  if (command === 'backup') {
    const out = fs.openSync(path.join(logs, 'backup.log'), 'a');
    const child = spawn(runtime, [path.join(release, 'scripts', 'scheduled-backup.mjs')], { cwd: release, env, windowsHide: true, stdio: ['ignore', out, out] });
    fs.closeSync(out);
    child.on('error', err => { console.error(err.message); process.exitCode = 1; });
    child.on('exit', code => { process.exitCode = code ?? 1; });
  } else {
    // Launcher decisions (a stale record set aside, a refused duplicate) are
    // recorded here so an unattended Task Scheduler start leaves evidence.
    const note = message => {
      const line = `${new Date().toISOString()} [launcher ${process.pid}] ${message}\n`;
      try { fs.appendFileSync(path.join(logs, 'launcher.log'), line); } catch { /* best effort */ }
      console.error(line.trimEnd());
    };
    // Ownership through the shared, tested primitive. Atomic: two supervisors
    // can never both take it before either child binds. See the header for
    // the full stale / live / reused / malformed decision table.
    const token = crypto.randomBytes(32).toString('hex');
    const lock = acquirePidLock(recordFile, {
      content: JSON.stringify({ pid: process.pid, token, release }),
      // Only a live `launch.mjs ... serve` counts as "the service": a live
      // `launch.mjs backup` (or anything else that happens to reuse the PID)
      // is not a running instance.
      isService: commandLine => /launch\.mjs["']?\s+serve(\s|$)/.test(commandLine),
      log: note
    });
    if (!lock.ok) {
      note(`not starting (${lock.code}): ${lock.reason}`);
      process.exit(1);
    }
    process.on('exit', () => lock.release());
    const cleanup = () => lock.release();
    // A control socket file left by a dead POSIX supervisor would block listen();
    // we now own the record, so it is ours to clear. (A Windows pipe vanishes with its process.)
    if (process.platform !== 'win32') fs.rmSync(pipe, { force: true });
    const busy = await new Promise(resolve => {
      const socket = net.connect({ host: values.HOST === '0.0.0.0' ? '127.0.0.1' : values.HOST, port: Number(values.PORT) });
      socket.setTimeout(1500);
      socket.once('connect', () => { socket.destroy(); resolve(true); });
      socket.once('error', error => resolve(error.code !== 'ECONNREFUSED'));
      socket.once('timeout', () => { socket.destroy(); resolve(true); });
    });
    if (busy) throw new Error('Configured port is occupied or cannot be safely checked');
    const out = fs.openSync(path.join(logs, `portal-${new Date().toISOString().slice(0, 10)}.log`), 'a');
    let child = null, timer = null, stopping = false, restarts = 0, started = 0;
    const log = message => fs.writeSync(out, `${new Date().toISOString()} ${message}\n`);
    const stop = async () => {
      stopping = true;
      clearTimeout(timer);
      if (child && child.exitCode === null && child.signalCode === null) {
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('Child did not exit; supervisor retained')), 8000);
          child.once('exit', () => { clearTimeout(timeout); resolve(); });
          child.kill();
        });
      }
      cleanup();
    };
    const server = net.createServer({ allowHalfOpen: true }, socket => {
      let input = '';
      socket.setTimeout(3000, () => socket.destroy());
      socket.on('error', () => {});
      socket.on('data', async chunk => {
        input += chunk;
        if (input.length > 1024) { socket.destroy(); return; }
        if (!input.includes('\n')) return;
        socket.removeAllListeners('data');
        try {
          const request = JSON.parse(input);
          if (request.token !== token) throw new Error('Unauthorized control request');
          if (request.action === 'status') socket.end(JSON.stringify({ pid: process.pid, childPid: child?.pid, release, database: values.DATABASE_FILE, storage: values.STORAGE_DIR, backups: values.BACKUP_DIR, stopping }));
          else if (request.action === 'stop') {
            await stop();
            socket.end(JSON.stringify({ stopped: true }));
            server.close(() => { fs.closeSync(out); });
          } else throw new Error('Unknown action');
        } catch (error) { socket.end(JSON.stringify({ error: error.message })); }
      });
    });
    server.on('error', error => { console.error(error.message); process.exitCode = 1; });
    function start() {
      started = Date.now();
      log(`Starting release ${release}`);
      child = spawn(runtime, [path.join(release, 'src', 'server.js')], { cwd: release, env, windowsHide: true, stdio: ['ignore', out, out] });
      child.on('error', error => {
        log(error.message);
        stopping = true;
        server.close(() => fs.closeSync(out));
        process.exitCode = 1;
      });
      child.on('exit', code => {
        log(`Child exit ${code}`);
        if (stopping) return;
        if (Date.now() - started > 60000) restarts = 0;
        if (++restarts > 5) { server.close(); fs.closeSync(out); process.exitCode = 1; return; }
        timer = setTimeout(start, Math.min(2000 * 2 ** (restarts - 1), 30000));
      });
    }
    server.listen(pipe, start);
    for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { stop().then(() => server.close(() => fs.closeSync(out))).catch(error => console.error(error.message)); });
  }
}
