import config from './config/env.js';
import { checkRecoveryInterlock } from './lib/recovery-interlock.js';

/*
 * This file's only job is the recovery-interlock check itself, run before
 * ANYTHING that could open or create the configured database is imported -
 * not even db/index.js, which enforces the same check but only once it is
 * itself imported. Everything else that makes up the real portal (routes,
 * services, the database connection) lives in server-app.js, imported
 * dynamically below only once the interlock is confirmed clear. See
 * lib/recovery-interlock.js and services/backups.js (restoreBackup()'s
 * fatal_unrecovered paths, which write this interlock).
 */
const interlock = checkRecoveryInterlock();

if (interlock) {
  const express = (await import('express')).default;
  const app = express();
  app.disable('x-powered-by');

  app.get('/healthz', (req, res) => {
    res.status(503).json({ status: 'recovery_required', kind: interlock.kind, createdAt: interlock.createdAt });
  });

  app.use((req, res) => {
    res.status(503).type('text/plain').send(
      'CCIQ Portal — recovery required\n'
      + '================================\n\n'
      + `A restore attempt on ${interlock.createdAt} failed in a way that could not be safely undone `
      + 'automatically. The portal will not start normally until this is resolved.\n\n'
      + interlock.instructions
    );
  });

  app.listen(config.port, config.host, () => {
    console.error('');
    console.error('  CCIQ Portal is NOT running normally — a recovery interlock is active.');
    console.error('');
    console.error(`  Kind: ${interlock.kind}`);
    console.error(`  Since: ${interlock.createdAt}`);
    console.error('');
    console.error(interlock.instructions);
    console.error('');
    console.error(`  This message is also shown at http://localhost:${config.port} while the interlock is active.`);
    console.error('');
  });
} else {
  await import('./server-app.js');
}
