import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import Database from 'better-sqlite3';
import { buildPortalFixture } from './lib/portal-fixture.mjs';
import { checkInvariants, INVARIANTS } from '../lib/db-invariants.js';

/*
 * The data-integrity rules (src/lib/db-invariants.js, tools/check-db-invariants.mjs):
 *  1. a database built only through the application's own services has no "error" finding;
 *  2. every rule actually fires when its condition is planted in a disposable copy (a rule that cannot fire protects nothing);
 *  3. the tool is read-only and refuses production folders and in-use databases.
 */

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const f = await buildPortalFixture('cciq-db-invariants-');
const { db, ids, users, mods } = f;

// 1. clean through the application ------------------------------------------------------------------------------------------
const clean = checkInvariants(db);
assert.deepEqual(clean.integrity, ['ok']);
assert.deepEqual(clean.foreignKeys, []);
assert.deepEqual(clean.findings.filter((x) => x.severity === 'error'), [], 'data written through the services breaks no invariant');
assert.deepEqual(clean.skipped, [], 'every rule applies to the current schema');
console.log(`PASS (clean) the fixture (built only through the services) breaks none of the ${INVARIANTS.length} rules; review findings: ${clean.findings.map((x) => x.code).join(', ') || 'none'}`);

// 2. every rule fires ---------------------------------------------------------------------------------------------------------
const copyPath = path.join(os.tmpdir(), `cciq-inv-copy-${process.pid}.sqlite`);
db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
await db.backup(copyPath);
const mem = (n) => ids.member[n];
const plant = {
  'member.self_reference': (bad) => bad.prepare('UPDATE members SET spouse_member_id = id WHERE id = ?').run(mem('a3')),
  'member.spouse_not_reciprocal': (bad) => bad.prepare('UPDATE members SET spouse_member_id = ? WHERE id = ?').run(mem('a2'), mem('free')),
  'member.duplicate_code': (bad) => bad.prepare("UPDATE members SET member_code = (SELECT lower(member_code) FROM members WHERE id = ?) WHERE id = ?").run(mem('a2'), mem('a3')),
  'member.status_outside_catalogue': (bad) => { bad.exec('PRAGMA ignore_check_constraints = ON'); bad.prepare("UPDATE members SET status = 'ghost' WHERE id = ?").run(mem('a3')); bad.exec('PRAGMA ignore_check_constraints = OFF'); },
  'member.status_differs_from_history': (bad) => {
    bad.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, changed_at) VALUES (?, 'active', 'migrated', '2999-01-01T00:00:00.000Z')").run(mem('a2'));
  },
  'member.dates_in_future_or_reversed': (bad) => bad.prepare("UPDATE members SET date_of_birth = '2999-01-01' WHERE id = ?").run(mem('a3')),
  'member.malformed_dates': (bad) => bad.prepare("UPDATE members SET date_joined = '12/05/2020' WHERE id = ?").run(mem('a3')),
  'member.impossible_dates': (bad) => bad.prepare("UPDATE members SET date_of_birth = '1976-26-07' WHERE id = ?").run(mem('a3')),
  'member.dob_review_inconsistent': (bad) => bad.prepare("UPDATE members SET dob_review = 'verified', dob_reviewed_at = NULL WHERE id = ?").run(mem('a2')),
  'cellgroup.member_group_without_membership': (bad) => bad.prepare('UPDATE members SET cell_group_id = ? WHERE id = ?').run(ids.groupB, mem('free')),
  'cellgroup.open_membership_without_pointer': (bad) => bad.prepare("INSERT OR REPLACE INTO cell_group_members (cell_group_id, member_id, role_in_group, joined_at) VALUES (?, ?, 'member', '2026-01-01')").run(ids.groupB, mem('free')),
  'cellgroup.member_open_in_two_groups': (bad) => {
    bad.prepare("INSERT OR REPLACE INTO cell_group_members (cell_group_id, member_id, role_in_group, joined_at, left_at) VALUES (?, ?, 'member', '2026-01-01', NULL)").run(ids.groupA, mem('a3'));
    bad.prepare("INSERT OR REPLACE INTO cell_group_members (cell_group_id, member_id, role_in_group, joined_at, left_at) VALUES (?, ?, 'member', '2026-01-01', NULL)").run(ids.groupB, mem('a3'));
  },
  'cellgroup.left_before_joined': (bad) => bad.prepare("INSERT OR REPLACE INTO ministry_members (ministry_id, member_id, role, joined_at, left_at) VALUES (?, ?, 'member', '2026-05-01', '2026-01-01')").run(ids.ministry, mem('a3')),
  'family.primary_not_in_group': (bad) => bad.prepare('UPDATE family_groups SET primary_member_id = ? WHERE id = ?').run(mem('free'), ids.family),
  'family.empty_group': (bad) => bad.prepare("INSERT INTO family_groups (name, created_at, updated_at) VALUES ('Nobody Family', '2026-01-01', '2026-01-01')").run(),
  'attendance.finalized_without_timestamp': (bad) => bad.prepare("UPDATE attendance_sessions SET finalization_state = 'finalized', finalized_at = NULL WHERE id = ?").run(ids.session),
  'attendance.timestamp_without_state': (bad) => bad.prepare("UPDATE attendance_sessions SET finalization_state = NULL, finalized_at = '2026-01-01T00:00:00Z' WHERE id = ?").run(ids.session),
  'attendance.finalized_without_expected_roster': (bad) => bad.prepare("UPDATE attendance_sessions SET finalization_state = 'finalized', finalized_at = '2026-01-01T00:00:00Z' WHERE id = ?").run(ids.session),
  'attendance.not_taken_with_records': (bad) => {
    bad.prepare("INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at) VALUES (?, ?, 'present', '2026-01-01')").run(ids.session, mem('a2'));
    bad.prepare("UPDATE attendance_sessions SET finalization_state = 'not_taken', finalized_at = '2026-01-01T00:00:00Z' WHERE id = ?").run(ids.session);
  },
  'attendance.cancelled_with_records': (bad) => {
    bad.prepare("INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at) VALUES (?, ?, 'present', '2026-01-01')").run(ids.session, mem('a2'));
    bad.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(ids.session);
  },
  'attendance.malformed_service_date': (bad) => bad.prepare("UPDATE attendance_sessions SET service_date = 'Friday' WHERE id = ?").run(ids.session),
  'attendance.cell_group_session_without_group': (bad) => bad.prepare("INSERT INTO attendance_sessions (service_date, service_type, cell_group_id, created_at) VALUES ('2026-02-06', 'cell_group', 0, '2026-01-01')").run(),
  'attendance.non_group_session_with_group': (bad) => bad.prepare('UPDATE attendance_sessions SET cell_group_id = ? WHERE id = ?').run(ids.groupA, ids.session),
  'visitor.converted_without_member': (bad) => bad.prepare("INSERT INTO visitors (first_name, first_visit_date, state, created_at, updated_at) VALUES ('Orphan', '2026-01-02', 'joined', '2026-01-02', '2026-01-02')").run(),
  'visitor.member_link_without_converted_state': (bad) => bad.prepare("INSERT INTO visitors (first_name, first_visit_date, state, member_id, created_at, updated_at) VALUES ('Linked', '2026-01-02', 'new', ?, '2026-01-02', '2026-01-02')").run(mem('a2')),
  'visitor.two_visitors_one_member': (bad) => {
    for (const name of ['One', 'Two']) bad.prepare("INSERT INTO visitors (first_name, first_visit_date, state, member_id, created_at, updated_at) VALUES (?, '2026-01-02', 'joined', ?, '2026-01-02', '2026-01-02')").run(name, mem('a2'));
  },
  'visitor.first_visit_after_a_visit': (bad) => {
    const v = bad.prepare("INSERT INTO visitors (first_name, first_visit_date, created_at, updated_at) VALUES ('Early', '2026-03-01', '2026-03-01', '2026-03-01')").run().lastInsertRowid;
    bad.prepare("INSERT INTO visitor_visits (visitor_id, visit_date, recorded_at) VALUES (?, '2026-02-01', '2026-02-01')").run(v);
  },
  'visitor.status_disagrees_with_visits': (bad) => bad.prepare("UPDATE visitors SET state = 'returning' WHERE id = ? AND (SELECT COUNT(*) FROM visitor_visits WHERE visitor_id = ?) < 2").run(ids.visitor, ids.visitor),
  'visitor.malformed_dates': (bad) => bad.prepare("INSERT INTO visitors (first_name, first_visit_date, created_at, updated_at) VALUES ('Badday', 'yesterday', '2026-01-02', '2026-01-02')").run(),
  'user.no_active_super_admin': (bad) => bad.prepare("UPDATE users SET status = 'disabled' WHERE id IN (SELECT user_id FROM user_roles WHERE role_id = (SELECT id FROM roles WHERE key = 'super_admin'))").run(),
  'user.without_role': (bad) => bad.prepare('DELETE FROM user_roles WHERE user_id = ?').run(users.memberA.id),
  'user.duplicate_login_name': (bad) => bad.prepare("INSERT INTO users (email, password_hash, display_name, created_at, updated_at) SELECT upper(email) || '.x', password_hash, 'Dup', created_at, updated_at FROM users WHERE id = ?").run(users.memberA.id) && bad.prepare("UPDATE users SET email = upper(email) WHERE email LIKE '%.X'").run() && bad.prepare("UPDATE users SET email = replace(email, '.X', '') WHERE email LIKE '%.X'").run(),
  'user.two_accounts_one_member': (bad) => bad.prepare("INSERT INTO users (member_id, email, password_hash, display_name, created_at, updated_at) SELECT member_id, 'second@fixture.invalid', password_hash, 'Second', created_at, updated_at FROM users WHERE id = ?").run(users.memberA.id),
  'user.password_not_hashed': (bad) => bad.prepare("UPDATE users SET password_hash = 'plaintext' WHERE id = ?").run(users.memberA.id),
  'user.kiosk_with_other_roles': (bad) => {
    const kiosk = bad.prepare("SELECT id FROM roles WHERE key = 'kiosk'").get().id;
    bad.prepare('INSERT OR IGNORE INTO user_roles (user_id, role_id, assigned_at) VALUES (?, ?, ?)').run(users.memberA.id, kiosk, '2026-01-01');
  },
  'ecaq.claim_total_differs_from_payments': (bad) => bad.prepare('UPDATE ecaq_giving_board_claims SET amount_collected = 999, payment_status = \'partially_paid\' WHERE id = ?').run(ids.claim),
  'ecaq.claim_status_contradicts_arithmetic': (bad) => bad.prepare("UPDATE ecaq_giving_board_claims SET payment_status = 'paid', amount_collected = 0 WHERE id = ?").run(ids.claim),
  'ecaq.claim_year_differs_from_campaign': (bad) => bad.prepare('UPDATE ecaq_giving_board_claims SET year = year + 1 WHERE id = ?').run(ids.claim),
  'ecaq.promise_total_differs_from_payments': (bad) => bad.prepare('UPDATE ecaq_faith_promise_commitments SET amount_collected = 12345 WHERE id = (SELECT MIN(id) FROM ecaq_faith_promise_commitments)').run(),
  'member.circular_parentage': (bad) => { bad.prepare('UPDATE members SET father_member_id = ? WHERE id = ?').run(mem('a3'), mem('a2')); bad.prepare('UPDATE members SET father_member_id = ? WHERE id = ?').run(mem('a2'), mem('a3')); },
  'history.chain_break': (bad) => {
    bad.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, changed_at) VALUES (?, 'active', 'inactive', '2030-01-01T00:00:00.000Z')").run(mem('a3'));
    bad.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, changed_at) VALUES (?, 'pending', 'active', '2030-02-01T00:00:00.000Z')").run(mem('a3'));
  },
  'history.time_goes_backwards': (bad) => {
    bad.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, changed_at) VALUES (?, 'active', 'inactive', '2031-01-01T00:00:00.000Z')").run(mem('a3'));
    bad.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, changed_at) VALUES (?, 'inactive', 'active', '2020-01-01T00:00:00.000Z')").run(mem('a3'));
  },
  'faith.duplicate_commitment': (bad) => bad.prepare("INSERT INTO ecaq_faith_promise_commitments (campaign_id, member_id, name, commitment_amount, frequency, expected_total, submitted_at, created_at, updated_at) SELECT campaign_id, member_id, name, commitment_amount, frequency, expected_total, submitted_at, created_at, updated_at FROM ecaq_faith_promise_commitments WHERE id = ?").run(ids.commitment),
  'review.open_for_member_visitor': (bad) => {
    bad.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01', '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(ids.visitor);
    bad.prepare("UPDATE visitors SET member_id = ?, state = 'joined' WHERE id = ?").run(mem('a3'), ids.visitor);
  },
  'review.closed_member_mismatch': (bad) => bad.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, closed_at, trigger_service_date, window_json) VALUES (?, 'converted', '2026-01-01', '2026-01-03', '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(ids.visitor),
  'review.continued_without_suppression': (bad) => { bad.exec('PRAGMA ignore_check_constraints = ON'); bad.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, closed_at, trigger_service_date, window_json) VALUES (?, 'continued', '2026-01-01', '2026-01-03', '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(ids.visitor); bad.exec('PRAGMA ignore_check_constraints = OFF'); },
  'visitor.visit_date_differs_from_session': (bad) => bad.prepare("INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, '2001-01-01', ?, 'x')").run(ids.visitor, ids.session),
  'review.trigger_session_missing': (bad) => bad.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_session_id, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01', NULL, '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(ids.visitor),
  'review.malformed_window': (bad) => bad.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01', '2026-01-02', 'not json')").run(ids.visitor),
  'ecaq.non_positive_payment': (bad) => bad.prepare("INSERT INTO ecaq_payments (claim_id, amount, paid_on, created_at) VALUES (?, -5, '2026-01-01', '2026-01-01')").run(ids.claim),
  'reminder.handled_without_handler_time': (bad) => bad.prepare("UPDATE reminders SET state = 'completed', handled_at = NULL WHERE id = ?").run(ids.reminder),
  'audit.blank_action': (bad) => bad.prepare("INSERT INTO audit_logs (action, created_at) VALUES ('  ', '2026-01-01')").run(),
  'audit.id_gaps_hint': (bad) => {
    bad.prepare("INSERT INTO audit_logs (action, created_at) VALUES ('one', '2026-01-01')").run();
    bad.prepare("INSERT INTO audit_logs (action, created_at) VALUES ('two', '2026-01-01')").run();
    bad.prepare("INSERT INTO audit_logs (action, created_at) VALUES ('three', '2026-01-01')").run();
    bad.prepare("DELETE FROM audit_logs WHERE id = (SELECT MAX(id) - 1 FROM audit_logs)").run();
  },
  'document.file_pointer_escapes_storage': (bad) => bad.prepare("UPDATE documents SET stored_path = '../../etc/passwd' WHERE id = (SELECT MIN(id) FROM documents)").run(),
  'document.current_version_row_differs': (bad) => bad.prepare("UPDATE documents SET stored_path = stored_path || 'x' WHERE id = (SELECT MIN(id) FROM documents)").run(),
  'document.versions_not_contiguous': (bad) => bad.prepare("UPDATE documents SET version = version + 2 WHERE id = (SELECT MIN(id) FROM documents)").run(),
  'schema.migration_versions_not_numbered': (bad) => bad.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES ('oops', '2026-01-01')").run()
};

const unplanted = INVARIANTS.map((i) => i.code).filter((c) => !plant[c]);
assert.deepEqual(unplanted, [], 'every invariant has a planted-violation case in this test');

let fired = 0;
for (const inv of INVARIANTS) {
  // One fresh copy per rule so one planted problem cannot mask another.
  fs.copyFileSync(copyPath, `${copyPath}.case`);
  const caseDb = new Database(`${copyPath}.case`);
  caseDb.pragma('foreign_keys = OFF');
  // The database now refuses these rows itself (migration 0030). A legacy database that predates it could still hold them, so each case
  // is planted on a copy WITHOUT those guards, which is exactly what the checker exists to find.
  for (const guard of ['trg_visitors_joined_iff_member_insert', 'trg_visitors_joined_iff_member_update', 'trg_members_delete_has_visitor']) caseDb.exec(`DROP TRIGGER IF EXISTS ${guard}`);
  caseDb.exec('DROP INDEX IF EXISTS idx_visitors_member_unique');
  plant[inv.code](caseDb);
  const result = checkInvariants(caseDb);
  const hit = result.findings.find((x) => x.code === inv.code);
  assert.ok(hit, `${inv.code} fires when its condition is planted`);
  assert.equal(hit.severity, inv.severity);
  assert.ok(hit.count >= 1 && hit.ids.length >= 1);
  caseDb.close();
  fs.rmSync(`${copyPath}.case`, { force: true });
  fired += 1;
}
console.log(`PASS (rules fire) all ${fired} rules detect their planted violation (each on a fresh disposable copy)`);

// 3. the tool ---------------------------------------------------------------------------------------------------------------------
const node = process.execPath;
const tool = path.join(root, 'tools', 'check-db-invariants.mjs');
const run = (...args) => spawnSync(node, [tool, ...args], { encoding: 'utf8' });

const cleanCopy = `${copyPath}.clean.sqlite`;
await db.backup(cleanCopy);
const before = fs.readFileSync(cleanCopy);
let r = run(cleanCopy);
assert.equal(r.status, 0, r.stdout + r.stderr);
assert.match(r.stdout, /Database integrity: ok/);
assert.match(r.stdout, /ERRORS: 0/);
assert.deepEqual(fs.readFileSync(cleanCopy), before, 'the tool leaves the database file byte-for-byte unchanged');
assert.ok(!fs.existsSync(`${cleanCopy}-wal`) || fs.statSync(`${cleanCopy}-wal`).size === 0, 'and leaves no write-ahead log');

r = run(cleanCopy, '--json');
const parsed = JSON.parse(r.stdout);
assert.equal(parsed.exitCode, 0);
assert.ok(Array.isArray(parsed.findings));
assert.doesNotMatch(r.stdout, /Anna|MemberA|@fixture\.invalid/, 'output carries ids and codes, never names or emails');

assert.equal(run().status, 2, 'a database path is required');
assert.equal(run('--bogus').status, 2);
assert.equal(run(path.join(os.tmpdir(), 'does-not-exist.sqlite')).status, 1);
assert.equal(run('--list').status, 0);
const prodLike = path.join(os.tmpdir(), 'cciq-production', 'data');
fs.mkdirSync(prodLike, { recursive: true });
const prodCopy = path.join(prodLike, 'copy.sqlite');
fs.copyFileSync(cleanCopy, prodCopy);
r = run(prodCopy);
assert.equal(r.status, 1);
assert.match(r.stderr, /cciq-production/);
fs.rmSync(path.join(os.tmpdir(), 'cciq-production'), { recursive: true, force: true });

// an error finding makes the tool exit 3
const broken = `${copyPath}.broken.sqlite`;
fs.copyFileSync(cleanCopy, broken);
const b = new Database(broken);
b.prepare("UPDATE members SET spouse_member_id = id WHERE id = ?").run(mem('a3'));
b.close();
r = run(broken);
assert.equal(r.status, 3);
assert.match(r.stdout, /member\.self_reference/);
console.log('PASS (tool) read-only (file unchanged), ids only, refuses a production folder and a missing file, exits 3 on an error finding');

for (const p of [copyPath, cleanCopy, broken]) for (const s of ['', '-wal', '-shm']) fs.rmSync(p + s, { force: true });
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
