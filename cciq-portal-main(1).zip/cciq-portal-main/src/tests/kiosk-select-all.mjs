import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Attendance Kiosk, physical-review corrections:
 *   1. "Look up" (the QR scanner's action) reads as a real secondary button: a visible edge and tinted face, a minimum width, a touch-sized height, distinct hover / pressed /
 *      keyboard-focus states, level with the scanner field at every width, and weaker than the solid primary buttons. What it DOES is unchanged.
 *   2. "Select all (N)" above the people a search found: ticks only the people on screen, never checks anybody in by itself ("Review selected" is still required), shows a mixed
 *      state when only some are ticked, and is cleared by unticking. First Timers, duplicate protection and the review step are exactly as before.
 *   3. Attendance stays PERSON-BASED: a Family Group is never selected, reviewed or checked in because one of its members was.
 */

const f = await buildPortalFixture('cciq-kiosk-select-all-');
const { db, ids, users, mods } = f;
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const people = ['One', 'Two', 'Three', 'Four', 'Five'].map((n) => mods.members.createMember({ first_name: n, last_name: 'Selectall' }, { status: 'active' }));
const guest = mods.visitors.createVisitor({ first_name: 'Guesty', last_name: 'Selectall', phone: '+974 5550 7001', first_visit_date: mods.dates.addDays(mods.dates.today(), -30) }, { userId: users.churchAdmin.id });
const family = mods.family.createFamilyGroup({ name: 'Selectall Household' });
mods.family.addMemberToFamilyGroup(family.id, people[0].id);
mods.family.addMemberToFamilyGroup(family.id, people[1].id);
const { ensureQrToken } = await import('../services/qr-checkin.js');
const token = ensureQrToken(people[2].id);
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const marksNow = () => count('SELECT COUNT(*) n FROM attendance_records') + count('SELECT COUNT(*) n FROM visitor_visits');
try {
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const cookies = kiosk.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const context = await browser.newContext();
  await context.addCookies(cookies);
  const open = async (width = 1280, url = '/kiosk') => {
    const page = await context.newPage();
    await page.setViewportSize({ width, height: 900 });
    await page.goto(portal.base + url, { waitUntil: 'load' });
    return page;
  };
  const search = async (page, term) => {
    await page.fill('#checkin-search-input', term);
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.keyboard.press('Enter')]);
  };

  // ---- Look up ---------------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const problems = [];
    for (const width of [320, 360, 390, 430, 600, 768, 820, 1024, 1280, 1440, 1920]) {
      const page = await open(width);
      const m = await page.evaluate(() => {
        const b = document.querySelector('#checkin-lookup'); const i = document.querySelector('#checkin-input'); const s = getComputedStyle(b);
        const search = document.querySelector('.kiosk__search-form button[type=submit]');
        const r = (el) => el.getBoundingClientRect(); const p = getComputedStyle(search);
        return { b: { x: r(b).x, y: r(b).y, w: r(b).width, h: r(b).height, right: r(b).right }, i: { y: r(i).y, h: r(i).height, right: r(i).right }, border: parseFloat(s.borderTopWidth), bg: s.backgroundColor, search: p.backgroundColor,
          overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, text: b.textContent.trim(), cursor: s.cursor, card: document.querySelector('.checkin-card').getBoundingClientRect() };
      });
      const label = `${width}px`;
      if (m.text !== 'Look up') problems.push(`${label}: label is "${m.text}"`);
      if (m.border < 2) problems.push(`${label}: no visible edge (${m.border}px)`);
      if (m.b.w < 100) problems.push(`${label}: only ${Math.round(m.b.w)}px wide`);
      if (m.b.h < 44) problems.push(`${label}: only ${Math.round(m.b.h)}px high`);
      if (Math.abs(m.b.y - m.i.y) > 2 || Math.abs(m.b.h - m.i.h) > 2) problems.push(`${label}: not level with the scanner field (${Math.round(m.b.y - m.i.y)}px, ${Math.round(m.b.h - m.i.h)}px)`);
      if (m.b.right > m.card.right + 1) problems.push(`${label}: leaves the card`);
      if (m.overflow > 0) problems.push(`${label}: sideways scroll ${m.overflow}px`);
      if (m.bg === m.search) problems.push(`${label}: looks the same as the primary Search button`);
      if (m.cursor !== 'pointer') problems.push(`${label}: cursor is ${m.cursor}`);
      await page.close();
    }
    assert.deepEqual(problems, [], problems.join('\n'));

    const page = await open(1280);
    const button = page.locator('#checkin-lookup');
    const rest = await button.evaluate((el) => getComputedStyle(el).backgroundColor);
    await button.hover();
    await page.waitForTimeout(150);
    const hover = await button.evaluate((el) => getComputedStyle(el).backgroundColor);
    assert.notEqual(hover, rest, 'hover changes the face');
    await page.mouse.move(0, 0);
    // keyboard: Tab from the scanner field reaches it with a visible focus ring
    await page.focus('#checkin-input');
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'checkin-lookup', 'Tab from the scan field reaches Look up');
    const ring = await button.evaluate((el) => { const s = getComputedStyle(el); return { style: s.outlineStyle, width: parseFloat(s.outlineWidth) }; });
    assert.ok(ring.style !== 'none' && ring.width >= 2, `a visible keyboard focus ring (${ring.style} ${ring.width}px)`);
    // behaviour unchanged: an unknown code is refused in place; a real code opens the confirmation; Enter in the field does the same as the button
    await page.fill('#checkin-input', 'not-a-real-code');
    await button.click();
    await page.waitForSelector('#checkin-error:not(.is-hidden)', { timeout: 5000 });
    assert.match(await page.locator('#checkin-error').innerText(), /does not match/i);
    const before = marksNow();
    await page.fill('#checkin-input', token);
    await button.click();
    await page.waitForSelector('#checkin-family-view:not(.is-hidden), #checkin-confirm-view:not(.is-hidden)', { timeout: 5000 });
    assert.equal(marksNow(), before, 'a lookup writes nothing: confirmation is still required');
    await page.close();
    console.log('PASS (Look up) 11 widths from 320 to 1920 px: a 2px edge, tinted face, at least 100px wide and 44px high, level with the scanner field, not like the primary Search button, no overflow; hover and a visible keyboard focus ring; an unknown code and a real code behave as before and a lookup writes nothing');
  }

  // ---- Select all -------------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const page = await open(1280);
    await search(page, 'Selectall');
    const results = await page.locator('form[action="/attendance/checkin/review"] input[name=person]').count();
    assert.equal(results, 6, 'five members and one First Timer are listed');
    const master = page.locator('[data-select-all]');
    assert.equal(await page.locator('.select-all__label').innerText(), 'Select all (6)', 'the label says how many people are shown');
    assert.equal(await master.isChecked(), false);
    const before = marksNow();

    await master.check();
    assert.equal(await page.locator('form[action="/attendance/checkin/review"] input[name=person]:checked').count(), 6, 'Select all ticks every person shown');
    assert.equal(page.url().includes('/review'), false, 'and goes nowhere');
    assert.equal(marksNow(), before, 'and checks nobody in');
    assert.match(await page.locator('[data-select-all-status]').innerText(), /6 of 6 selected/);

    await page.locator('form[action="/attendance/checkin/review"] input[name=person]').nth(3).uncheck();
    assert.equal(await master.evaluate((el) => el.indeterminate), true, 'one person unticked: the box is mixed');
    assert.equal(await master.getAttribute('aria-checked'), 'mixed');
    assert.equal(await master.isChecked(), false);
    assert.match(await page.locator('[data-select-all-status]').innerText(), /5 of 6 selected/);
    await page.locator('form[action="/attendance/checkin/review"] input[name=person]').nth(3).check();
    assert.equal(await master.evaluate((el) => el.indeterminate), false);
    assert.equal(await master.isChecked(), true, 'ticking the last one again restores the checked state');

    await master.uncheck();
    assert.equal(await page.locator('form[action="/attendance/checkin/review"] input[name=person]:checked').count(), 0, 'unticking Select all clears them');
    assert.equal(await master.evaluate((el) => el.indeterminate), false);
    // the keyboard: Space on the focused box does the same
    await master.focus();
    await page.keyboard.press('Space');
    assert.equal(await page.locator('form[action="/attendance/checkin/review"] input[name=person]:checked').count(), 6, 'Space on Select all ticks everyone');
    await page.keyboard.press('Space');
    assert.equal(await page.locator('form[action="/attendance/checkin/review"] input[name=person]:checked').count(), 0);

    // it selects only what is on screen: a narrower search lists fewer people and the count follows
    await search(page, 'One Selectall');
    assert.equal(await page.locator('.select-all__label').innerText(), 'Select all (1)');
    await page.locator('[data-select-all]').check();
    assert.equal(await page.locator('input[name=person]:checked').count(), 1, 'only the person shown is selected, never an unrelated one from a wider search');

    // Review selected is still required, and shows exactly who was ticked
    await search(page, 'Selectall');
    await page.locator('[data-select-all]').check();
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.getByRole('button', { name: 'Review selected' }).click()]);
    const reviewText = await page.locator('main').innerText();
    for (const p of people) assert.ok(reviewText.includes(p.first_name), `${p.first_name} is on the review step`);
    assert.ok(reviewText.includes('Guesty'), 'and so is the First Timer');
    assert.equal(marksNow(), before, 'still nobody is checked in until the review is confirmed');
    await page.close();
    console.log('PASS (Select all) "Select all (N)" counts and ticks only the people shown; it goes nowhere and checks nobody in; one unticked gives the mixed state, re-ticking restores it, unticking clears; Space works; a narrower search changes N; Review selected is still the step that shows who was ticked');
  }

  // ---- the confirmation flow, duplicates and First Timers are as before ---------------------------------------------------------------------------------------------------
  {
    const page = await open(1280);
    await search(page, 'Selectall');
    await page.locator('[data-select-all]').check();
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.getByRole('button', { name: 'Review selected' }).click()]);
    const before = marksNow();
    await Promise.all([page.waitForResponse((r) => r.url().includes('/attendance/checkin/record')), page.getByRole('button', { name: /Confirm|Record/ }).first().click()]);
    await page.waitForTimeout(500);
    assert.equal(count("SELECT COUNT(*) n FROM attendance_records WHERE status = 'present' AND member_id IN (?, ?, ?, ?, ?)", ...people.map((p) => p.id)), 5, 'five members were checked in');
    assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ? AND session_id IS NOT NULL', guest.id), 1, 'the First Timer got one visit tied to the Friday');
    assert.equal(marksNow(), before + 6);
    // doing it all again records nothing new (duplicate protection), and says so
    const second = await open(1280);
    await search(second, 'Selectall');
    await second.locator('[data-select-all]').check();
    await Promise.all([second.waitForNavigation({ waitUntil: 'load' }), second.getByRole('button', { name: 'Review selected' }).click()]);
    // everyone is already in: the review says so and offers no Confirm, only the way back to the scanner
    assert.equal(await second.getByRole('button', { name: /Confirm|Record/ }).count(), 0, 'nothing to confirm for people already checked in');
    assert.ok(/Already checked in/.test(await second.locator('main').innerText()));
    await second.getByRole('link', { name: 'Next check-in' }).waitFor({ state: 'visible' });
    await second.waitForTimeout(500);
    assert.equal(marksNow(), before + 6, 'a second time adds nothing');
    assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', guest.id), 2, 'the First Timer still has exactly the earlier visit and today\'s one');
    await second.close();
    await page.close();
    console.log('PASS (flow) confirming after Select all records five members and one First Timer visit; doing it again records nothing');
  }

  // ---- families are never attended as a unit ---------------------------------------------------------------------------------------------------------------------------------
  {
    const lone = mods.members.createMember({ first_name: 'Solo', last_name: 'Houseone' }, { status: 'active' });
    const kin = mods.members.createMember({ first_name: 'Kin', last_name: 'Houseone' }, { status: 'active' });
    const hh = mods.family.createFamilyGroup({ name: 'Houseone Family' });
    mods.family.addMemberToFamilyGroup(hh.id, lone.id);
    mods.family.addMemberToFamilyGroup(hh.id, kin.id);
    const page = await open(1280);
    await search(page, 'Solo');
    assert.equal(await page.locator('input[name=person]').count(), 1, 'searching for one family member lists only that person');
    assert.equal(await page.locator('.select-all__label').innerText(), 'Select all (1)', 'Select all counts people, never a household');
    await page.locator('[data-select-all]').check();
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.getByRole('button', { name: 'Review selected' }).click()]);
    const text = await page.locator('main').innerText();
    const [selectedPart, suggestedPart = ''] = text.split('Also from the same household');
    assert.ok(selectedPart.includes('Solo') && !selectedPart.includes('Kin Houseone'), 'the people to be recorded are only the selected person, not their household');
    assert.ok(suggestedPart.includes('Kin Houseone') && /not automatically recorded/.test(text), 'a relative is only OFFERED, with the words "not automatically recorded", and must be added by an explicit click');
    await Promise.all([page.waitForResponse((r) => r.url().includes('/attendance/checkin/record')), page.getByRole('button', { name: /Confirm|Record/ }).first().click()]);
    await page.waitForTimeout(500);
    assert.equal(count("SELECT COUNT(*) n FROM attendance_records WHERE member_id = ?", lone.id), 1);
    assert.equal(count("SELECT COUNT(*) n FROM attendance_records WHERE member_id = ?", kin.id), 0, 'a family member nobody ticked is not checked in');
    assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE member_id = ? OR member_id = ?', people[0].id, people[1].id) >= 2, true);
    await page.close();
    console.log('PASS (families) searching for one family member lists and selects only that person; the review names only them; a relative nobody ticked is not checked in');
  }

  // ---- layout of the Select all row on narrow screens ---------------------------------------------------------------------------------------------------------------------------
  {
    const problems = [];
    for (const width of [320, 390, 768, 1280, 1920]) {
      const page = await open(width);
      await search(page, 'Selectall');
      const m = await page.evaluate(() => {
        const row = document.querySelector('.select-all'); const box = document.querySelector('[data-select-all]'); const r = row.getBoundingClientRect(); const b = box.getBoundingClientRect();
        return { w: r.width, boxH: b.height, boxW: b.width, overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, labelH: document.querySelector('.select-all__label').getBoundingClientRect().height };
      });
      if (m.overflow > 0) problems.push(`${width}px: sideways scroll`);
      if (m.labelH < 40) problems.push(`${width}px: the Select all row is only ${Math.round(m.labelH)}px high to touch`);
      if (m.boxW < 20) problems.push(`${width}px: the box is ${Math.round(m.boxW)}px wide`);
      await page.close();
    }
    assert.deepEqual(problems, [], problems.join('\n'));
    console.log('PASS (layout) the Select all row has no overflow and a touch-sized target at 320, 390, 768, 1280 and 1920 px');
  }
} finally {
  await browser.close();
  await portal.stop();
}
db.close();
f.env.cleanup();
void ids;
console.log('ALL PASS');
