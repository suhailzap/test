import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Migration 0033 (a person's date-of-birth review decision): additive, nullable, nothing backfilled.
 *   - a fresh database has the three columns, all nullable, with no default, and the decision column refuses any value but the three states;
 *   - a database taken back to 0032 with members (valid, impossible, suspicious and empty dates of birth) upgrades with every stored date, every member row and every other column untouched,
 *     all three new columns NULL for everyone, and re-running changes nothing;
 *   - nothing is marked verified or unverified by the migration, and the automatic assessment is unchanged by it;
 *   - the schema check calls the 0032 database behind and the migrated one compatible.
 */

createIsolatedTestEnv('cciq-migration-0033-');
const { migrate, EXPECTED_MIGRATIONS, checkSchemaCompatibility } = await import('../db/migrate.js');
migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const members = await import('../services/members.js');
const dq = await import('../services/dob-quality.js');
const { default: db } = await import('../db/index.js');
const columns = () => db.prepare('PRAGMA table_info(members)').all();

{ // 1. fresh
  assert.ok(EXPECTED_MIGRATIONS.includes('0033_member_dob_review'));
  for (const [name, type] of [['dob_review', 'TEXT'], ['dob_reviewed_at', 'TEXT'], ['dob_reviewed_by', 'INTEGER']]) {
    const col = columns().find((c) => c.name === name);
    assert.ok(col, `${name} exists`); assert.equal(col.type, type); assert.equal(col.notnull, 0, `${name} is nullable`); assert.equal(col.dflt_value, null, `${name} has no default`);
  }
  const m = members.createMember({ first_name: 'Fresh', last_name: 'Member', date_of_birth: '1990-05-17' }, { status: 'active' });
  assert.deepEqual(db.prepare('SELECT dob_review, dob_reviewed_at, dob_reviewed_by FROM members WHERE id = ?').get(m.id), { dob_review: null, dob_reviewed_at: null, dob_reviewed_by: null }, 'a new member has no decision');
  for (const ok of ['verified', 'unverified', 'month_day_only', null]) db.prepare('UPDATE members SET dob_review = ? WHERE id = ?').run(ok, m.id);
  for (const bad of ['Verified', 'maybe', '', 'yes']) assert.throws(() => db.prepare('UPDATE members SET dob_review = ? WHERE id = ?').run(bad, m.id), /CHECK constraint/, `refuses "${bad}"`);
  db.prepare('UPDATE members SET dob_review = NULL WHERE id = ?').run(m.id);
  console.log('PASS (1) a fresh database has dob_review (three states only), dob_reviewed_at and dob_reviewed_by: nullable, no default');
}

const make = (first, last, extra = {}) => members.createMember({ first_name: first, last_name: last, ...extra }, { status: 'active' });
const valid = make('Valid', 'Adult', { date_of_birth: '1990-05-17' });
const suspicious = make('Suspicious', 'Child', { date_of_birth: '2023-10-27', marital_status: 'married' });
const impossible = make('Impossible', 'Date'); db.prepare("UPDATE members SET date_of_birth = '1976-26-07' WHERE id = ?").run(impossible.id);
const none = make('No', 'Date');

function rewindTo0032() {
  db.pragma('foreign_keys = OFF');
  db.exec('ALTER TABLE members DROP COLUMN dob_reviewed_by; ALTER TABLE members DROP COLUMN dob_reviewed_at; ALTER TABLE members DROP COLUMN dob_review;'
    + " DELETE FROM schema_migrations WHERE version = '0033_member_dob_review';");
  db.pragma('foreign_keys = ON');
}
const rows = () => JSON.stringify(db.prepare('SELECT id, member_code, first_name, last_name, date_of_birth, marital_status, status, notes, created_at, updated_at FROM members ORDER BY id').all());

{ // 2. a 0032 database with members
  const assessBefore = JSON.stringify([...dq.assessments()].map(([id, a]) => [id, a.state, a.category, a.reasons]));
  const before = rows();
  rewindTo0032();
  assert.equal(columns().some((c) => c.name.startsWith('dob_review')), false, 'sanity: the copy is at 0032');
  assert.equal(checkSchemaCompatibility(db).reason, 'behind', 'the 0032 database is reported as behind');
  assert.deepEqual(checkSchemaCompatibility(db).missing, ['0033_member_dob_review']);
  assert.equal(rows(), before, 'removing the columns changed no member data');
  migrate(); migrate();
  assert.equal(rows(), before, 'every member row, stored date of birth included, is exactly as it was');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members WHERE dob_review IS NOT NULL OR dob_reviewed_at IS NOT NULL OR dob_reviewed_by IS NOT NULL').get().n, 0, 'nobody is marked anything by the migration');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get('0033_member_dob_review').n, 1, 'recorded once');
  assert.equal(checkSchemaCompatibility(db).ok, true);
  const assessAfter = JSON.stringify([...dq.assessments()].map(([id, a]) => [id, a.state, a.category, a.reasons]));
  assert.equal(assessAfter, assessBefore, 'the automatic assessment of every member is unchanged by the migration');
  assert.equal(dq.dobAssessment(valid.id).state, 'ok'); assert.equal(dq.dobAssessment(suspicious.id).state, 'unverified'); assert.equal(dq.dobAssessment(impossible.id).state, 'invalid'); assert.equal(dq.dobAssessment(none.id).state, 'none');
  console.log('PASS (2) a 0032 database upgrades with every member and stored date untouched, nobody marked, the assessment identical, and a second run changes nothing');
}

{ // 3. a decision survives deleting the deciding user
  const user = db.prepare("INSERT INTO users (email, password_hash, display_name, created_at, updated_at) VALUES ('mig33@fixture.invalid', 'x', 'Mig', 'x', 'x')").run().lastInsertRowid;
  db.prepare("UPDATE members SET dob_review = 'verified', dob_reviewed_at = '2026-10-08T00:00:00.000Z', dob_reviewed_by = ? WHERE id = ?").run(user, valid.id);
  db.prepare('DELETE FROM users WHERE id = ?').run(user);
  assert.deepEqual(db.prepare('SELECT dob_review, dob_reviewed_by FROM members WHERE id = ?').get(valid.id), { dob_review: 'verified', dob_reviewed_by: null }, 'the decision stays when the account is removed (the name is simply gone)');
  console.log('PASS (3) a decision outlives the account that made it');
}
console.log('PASS migration-0033');
