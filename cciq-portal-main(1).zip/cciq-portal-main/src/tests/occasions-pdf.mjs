import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Reports > Birthdays and anniversaries, fetched as the real PDF over HTTP (a status-200 HTML error page cannot pass: the body must be a PDF, ending properly).
 *
 * History: the owner's range 06 Oct 2026 to 04 Jan 2027 answered "Something went wrong". Cause: imported records held dates that are not calendar dates
 * ("1976-26-07", day and month swapped). Compared as text, month 26 sorts between October and January, so it fell inside the range and the month-name lookup for
 * the chart threw. A stored date that is not a real date can never be an occasion; it is skipped and COUNTED, and the report says so.
 * Also pinned: a range that crosses the new year is recognised as such (the flag was never true), 29 February is listed on 28 February in a common year, an empty
 * range says so, birthdays-only / anniversaries-only / both, missing optional dates, and who may open it.
 */

const f = await buildPortalFixture('cciq-occasions-pdf-');
const { db, users, mods } = f;
const make = (first, extra, status = 'active') => mods.members.createMember({ first_name: first, last_name: 'Occa', ...extra }, { status }).id;
const born = {
  oct: make('Octa', { date_of_birth: '1985-10-20' }), dec: make('Deca', { date_of_birth: '1990-12-25' }), jan: make('Jana', { date_of_birth: '1992-01-02' }),
  feb: make('Feba', { date_of_birth: '1995-02-10' }), leap: make('Leapa', { date_of_birth: '2000-02-29' }), edgeStart: make('Startedge', { date_of_birth: '1980-10-06' }), edgeEnd: make('Endedge', { date_of_birth: '1981-01-04' })
};
const wed = { nov: make('Novwed', { anniversary_date: '2010-11-14' }), jan4: make('Janwed', { anniversary_date: '2012-01-04' }), summer: make('Sumwed', { anniversary_date: '2015-07-01' }) };
make('Nodates', {}); // missing optional dates
make('Bothdates', { date_of_birth: '1979-11-30', anniversary_date: '2005-12-02' });
make('Gonebirth', { date_of_birth: '1984-11-11' }, 'archived'); // not "still with us"
// records an import left with dates that are not calendar dates (written directly: the form refuses them)
const bad1 = make('Swapped', { date_of_birth: '1990-01-01' }); db.prepare("UPDATE members SET date_of_birth = '1976-26-07' WHERE id = ?").run(bad1);
const bad2 = make('Monthzero', { date_of_birth: '1990-01-01' }, 'inactive'); db.prepare("UPDATE members SET date_of_birth = '1991-00-15' WHERE id = ?").run(bad2);
const bad3 = make('Badwed', { anniversary_date: '2001-01-01' }); db.prepare("UPDATE members SET anniversary_date = '2001-13-05' WHERE id = ?").run(bad3);
const bad4 = make('Febthirty', { date_of_birth: '1990-01-01' }); db.prepare("UPDATE members SET date_of_birth = '1990-02-30' WHERE id = ?").run(bad4);

function pdfText(buffer) {
  const raw = buffer.toString('latin1'); let text = '';
  for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) {
    let content; try { content = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; }
    for (const hex of content.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(hex[1], 'hex').toString('latin1');
    for (const lit of content.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += lit[1];
    text += '\n';
  }
  return text;
}

const portal = await startPortal();
try {
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const superAdmin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const pdf = async (client, query) => {
    const r = await client.get(`/reports/occasions/pdf?${query}`); const buf = Buffer.from(await r.arrayBuffer());
    return { status: r.status, type: r.headers.get('content-type') || '', buf, text: r.status === 200 ? pdfText(buf) : '' };
  };
  const assertPdf = (r, label) => {
    assert.equal(r.status, 200, `${label}: status ${r.status}`);
    assert.match(r.type, /application\/pdf/, `${label}: content type`);
    assert.equal(r.buf.slice(0, 5).toString('latin1'), '%PDF-', `${label}: a PDF signature`);
    assert.match(r.buf.slice(-32).toString('latin1'), /%%EOF\s*$/, `${label}: a complete PDF`);
    assert.ok(!r.buf.includes('Something went wrong'), `${label}: not an error page`);
  };

  // ---- the owner's range ----------------------------------------------------------------------------------------------------------------------------------------------------
  const exact = await pdf(church, 'from=2026-10-06&to=2027-01-04&include=both&status=connected');
  assertPdf(exact, 'the exact physical range');
  for (const name of ['Octa', 'Deca', 'Jana', 'Startedge', 'Endedge', 'Novwed', 'Janwed', 'Bothdates']) assert.match(exact.text, new RegExp(name), `${name} falls in 6 Oct - 4 Jan`);
  for (const name of ['Feba', 'Leapa', 'Sumwed', 'Gonebirth', 'Nodates', 'Swapped', 'Monthzero', 'Badwed', 'Febthirty']) assert.doesNotMatch(exact.text, new RegExp(name), `${name} is not listed`);
  assert.match(exact.text, /crosses the new year/, 'a range across the new year says so');
  assert.match(exact.text, /4 stored dates are not a real calendar date/, 'the unusable stored dates are counted, not hidden: 3 birth dates and 1 wedding date');
  assert.match(exact.text, /Birthdays/); assert.match(exact.text, /Wedding anniversaries/);
  console.log('PASS (exact range) 06 Oct 2026 to 04 Jan 2027 is a real PDF listing the right people, the unusable dates counted');

  // ---- same year, cross year, only birthdays, only anniversaries, empty, the leap day ----------------------------------------------------------------------------------------
  const sameYear = await pdf(church, 'from=2026-10-06&to=2026-12-31&include=both&status=connected');
  assertPdf(sameYear, 'same year'); assert.match(sameYear.text, /Octa/); assert.doesNotMatch(sameYear.text, /Jana/); assert.doesNotMatch(sameYear.text, /crosses the new year/);
  const birthdaysOnly = await pdf(church, 'from=2026-10-06&to=2027-01-04&include=birthdays&status=connected');
  assertPdf(birthdaysOnly, 'birthdays only'); assert.match(birthdaysOnly.text, /Octa/); assert.doesNotMatch(birthdaysOnly.text, /Novwed/); assert.doesNotMatch(birthdaysOnly.text, /Wedding anniversaries/);
  assert.match(birthdaysOnly.text, /3 stored dates are not a real calendar date/, 'only the birth dates are counted in a birthdays-only report');
  const annivOnly = await pdf(church, 'from=2026-10-06&to=2027-01-04&include=anniversaries&status=connected');
  assertPdf(annivOnly, 'anniversaries only'); assert.match(annivOnly.text, /Novwed/); assert.doesNotMatch(annivOnly.text, /Octa/);
  assert.match(annivOnly.text, /1 stored date is not a real calendar date/);
  const empty = await pdf(church, 'from=2026-06-02&to=2026-06-05&include=both&status=connected');
  assertPdf(empty, 'empty range'); assert.match(empty.text, /No birthdays fall in this range/); assert.match(empty.text, /No anniversaries fall in this range/);
  const leap = await pdf(church, 'from=2027-02-20&to=2027-03-05&include=birthdays&status=connected');
  assertPdf(leap, 'leap day in a common year'); assert.match(leap.text, /Leapa/, 'born 29 Feb is listed (on 28 Feb) in a year without one');
  const leapYear = await pdf(church, 'from=2028-02-20&to=2028-03-05&include=birthdays&status=connected');
  assertPdf(leapYear, 'leap day in a leap year'); assert.match(leapYear.text, /Leapa/);
  const archived = await pdf(church, 'from=2026-11-01&to=2026-11-30&include=birthdays&status=all');
  assertPdf(archived, 'every status'); assert.match(archived.text, /Gonebirth/, 'All statuses includes the archived member the "still with us" report leaves out');
  const justInactive = await pdf(church, 'from=2026-10-06&to=2027-01-04&include=both&status=inactive');
  assertPdf(justInactive, 'one status');
  console.log('PASS (variants) same year, cross-year, birthdays only, anniversaries only, empty, 29 February in a common and a leap year, all statuses');

  // ---- odd input and who may open it -------------------------------------------------------------------------------------------------------------------------------------------
  for (const q of ['from=2026-02-30&include=x&status=x', 'from=nope&to=nope', 'from=2027-01-04&to=2026-10-06', 'from=2026-10-06&to=2027-01-04&include[]=both&status[]=all', 'from=0000-00-00&to=9999-99-99', '']) assertPdf(await pdf(church, q), `odd query "${q}"`);
  assertPdf(await pdf(superAdmin, 'from=2026-10-06&to=2027-01-04&include=both&status=connected'), 'Super Admin');
  for (const [who, client] of [['member', member], ['leader', leader]]) { const r = await pdf(client, 'from=2026-10-06&to=2027-01-04&include=both&status=connected'); assert.ok(r.status === 403 || r.status === 302, `${who} is refused (${r.status})`); assert.notEqual(r.status, 200); }
  const launcher = await church.get('/reports'); assert.equal(launcher.status, 200); assert.match(await launcher.text(), /Birthdays and anniversaries/);
  console.log('PASS (input and access) odd and reversed ranges still give a PDF, Super Admin and Church Admin may open it, a Member and a Cell Group leader may not');

  // ---- the data rule itself --------------------------------------------------------------------------------------------------------------------------------------------------------
  const { occasionsInRange } = mods.members;
  const r = occasionsInRange({ from: '2026-10-06', to: '2027-01-04', statuses: ['active', 'inactive'] });
  assert.equal(r.spansNewYear, true); assert.equal(r.unusable.birthdays, 3); assert.equal(r.unusable.anniversaries, 1);
  assert.ok(r.birthdays.every((b) => /^\d{4}-(0[1-9]|1[0-2])-\d{2}$/.test(b.date)), 'every listed date is a real calendar month');
  assert.equal(occasionsInRange({ from: '2026-03-01', to: '2026-10-31', statuses: ['active'] }).spansNewYear, false);
  console.log('PASS (rule) unusable dates are skipped and counted; a cross-year range is flagged; a same-year range is not');
  console.log('PASS occasions-pdf');
} finally {
  await portal.stop();
}
