import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * For every kind of signed-in person: start at the dashboard and follow every same-site link the portal offers them, two
 * hops deep. A link the portal shows a person must open for that person - no 403 (shown something they may not use), no 404
 * (dead link), no 5xx. Forms and downloads are reached by GET only; nothing here posts.
 */

const f = await buildPortalFixture('cciq-navigation-');
const { users } = f;
const portal = await startPortal();

const MAX_PAGES = 400;
const SKIP = [/^\/logout/, /^\/media\//, /^\/uploads\//, /\.(png|jpe?g|gif|webp|svg|ico|css|js|woff2?)(\?|$)/i, /^\/healthz?/];

function linksOf(html) {
  const out = new Set();
  for (const m of html.matchAll(/<a [^>]*href="([^"#][^"]*)"/g)) {
    const href = m[1].replace(/&amp;/g, '&');
    if (!href.startsWith('/') || href.startsWith('//')) continue;
    if (SKIP.some((re) => re.test(href))) continue;
    out.add(href);
  }
  return [...out];
}

const principals = [
  ['Super Administrator', users.superAdmin],
  ['Church Administrator', users.churchAdmin],
  ['Cell Group Leader', users.leaderA],
  ['Member', users.memberA]
];

const report = [];
try {
  for (const [label, account] of principals) {
    const session = await signIn(portal.base, account.email, f.PASSWORD);
    const seen = new Map(); // href -> { status, from }
    let frontier = [{ href: '/', from: '(start)' }];
    for (let depth = 0; depth < 3 && frontier.length && seen.size < MAX_PAGES; depth += 1) {
      const next = [];
      for (const { href, from } of frontier) {
        if (seen.has(href) || seen.size >= MAX_PAGES) continue;
        const res = await session.get(href);
        const body = await res.text();
        seen.set(href, { status: res.status, from });
        if (res.status === 200 && /text\/html/.test(res.headers.get('content-type') || '')) {
          for (const link of linksOf(body)) if (!seen.has(link)) next.push({ href: link, from: href });
        }
      }
      frontier = next;
    }
    const broken = [...seen].filter(([, v]) => v.status >= 400).map(([href, v]) => `${v.status} ${href}  (linked from ${v.from})`);
    report.push({ label, pages: seen.size, broken });
  }

  // Kiosk: sign-in lands on /kiosk; nothing else is offered and everything else is closed.
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const kioskHome = await kiosk.get('/kiosk');
  const kioskBody = await kioskHome.text();
  assert.equal(kioskHome.status, 200);
  const kioskLinks = linksOf(kioskBody);
  const kioskBroken = [];
  for (const href of kioskLinks) {
    const res = await kiosk.get(href);
    await res.arrayBuffer();
    if (res.status >= 400) kioskBroken.push(`${res.status} ${href}`);
  }
  report.push({ label: 'Kiosk', pages: 1 + kioskLinks.length, broken: kioskBroken });

  for (const r of report) console.log(`INFO ${r.label}: ${r.pages} pages reached, ${r.broken.length} broken${r.broken.length ? '\n   ' + r.broken.join('\n   ') : ''}`);
  for (const r of report) assert.deepEqual(r.broken, [], `${r.label}: every link the portal offers opens`);
  console.log('PASS (navigation) every same-site link offered to a Super Administrator, Church Administrator, Cell Group Leader, Member and Kiosk opens (no 403 / 404 / 5xx), two hops from the dashboard');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
