import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Physical-test correction: a refused First Timer form must say WHICH field is wrong and WHY, beside the field and in a summary that links to
 * it, with the control marked invalid and described by its message, every typed value kept, and the summary taking focus.
 *
 * The case that failed in the owner's hands: First name Isaiah, Last name Thomas, Contact 88971231231, Email 21323@asdasda, Teens Church,
 * first visit 7 Aug 2026, an inviter chosen. The contact number, congregation, date and inviter are all acceptable. The ONLY failing rule is
 * the Email: an address needs a dot after the @ ("name@example.com"). The old form showed an error under First name only (it had a place for
 * no other field's message) and a banner that said "Check the highlighted fields and save again." That is what is pinned below.
 */

const f = await buildPortalFixture('cciq-ft-validation-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
const today = mods.dates.today();
const past = (days) => mods.dates.addDays(today, -days);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const decode = (s) => s.replace(/&#34;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

const VALID = () => ({ first_name: 'Isaiah', last_name: 'Thomas', phone: '88971231231', email: '', age_group: 'teen', first_visit_date: past(30), invited_by_member_id: String(ids.member.a2) });
const submit = (fields, url = '/visitors', from = '/visitors/new') => admin.post(url, fields, { csrfFrom: from });

/** The control element for `id` (input / select / textarea). */
const control = (html, id) => new RegExp(`<(?:input|select|textarea)\\b[^>]*\\bid="${id}"[^>]*>`).exec(html)?.[0] || null;

/** Everything a person needs, for one failing field. */
function assertFieldReported(html, { field, controlId, message, label }, why) {
  assert.match(html, /data-error-summary/, `${why}: the summary is present and takes focus`);
  assert.match(html, /<div class="alert alert--error" role="alert" tabindex="-1" data-error-summary/, `${why}: it is an alert that can be focused`);
  const summary = /<div class="alert alert--error"[^>]*data-error-summary[\s\S]*?<\/ul>/.exec(html)?.[0] || '';
  assert.ok(summary.includes(`href="#${controlId}"`), `${why}: the summary links to #${controlId}`);
  if (message) assert.ok(decode(summary).includes(message), `${why}: the summary states the actual problem (${message})`);
  if (label) assert.ok(summary.includes(label), `${why}: and names the field (${label})`);
  assert.doesNotMatch(html, /Check the highlighted fields/, `${why}: the vague banner is gone`);
  const el = control(html, controlId);
  assert.ok(el, `${why}: control #${controlId} exists`);
  assert.match(el, /aria-invalid="true"/, `${why}: #${controlId} is marked invalid`);
  assert.match(el, new RegExp(`aria-describedby="${field}-error"|aria-describedby="[^"]*${controlId.replace('-search', '')}-error[^"]*"`), `${why}: #${controlId} is described by its message`);
  assert.match(html, new RegExp(`id="${controlId.replace('-search', '')}-error"[^>]*>[^<]*${message ? message.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').slice(0, 30) : ''}`), `${why}: the message sits beside the field`);
}

try {
  // ---- 1. the exact case from the physical test ------------------------------------------------------------------------------------------
  {
    const res = await submit({ ...VALID(), email: '21323@asdasda', invited_by_name: '', how_heard: '', notes: '' });
    const html = await res.text();
    assert.equal(res.status, 400, 'the owner\'s example is refused');
    assertFieldReported(html, { field: 'email', controlId: 'email', message: 'Email needs a dot after the @, such as name@example.com.', label: 'Email' }, 'owner example');
    // it is the ONLY failure: nothing else is flagged
    for (const other of ['first_name', 'last_name', 'phone', 'age_group', 'first_visit_date', 'invited_by_name', 'how_heard', 'notes']) {
      assert.match(control(html, other) || '', /aria-invalid="false"/, `${other} is accepted`);
      assert.doesNotMatch(html, new RegExp(`id="${other}-error"`), `${other} has no message`);
    }
    assert.match(html, /<input type="hidden" name="invited_by_member_id" value="\d+"/, 'the chosen inviter is still selected');
    assert.equal((/<div class="alert alert--error"[^>]*data-error-summary[\s\S]*?<\/ul>/.exec(html)[0].match(/<li>/g) || []).length, 1, 'exactly one problem is listed');
    // every typed value is kept
    assert.match(html, /name="first_name" value="Isaiah"/); assert.match(html, /name="last_name" value="Thomas"/);
    assert.match(html, /name="phone" value="88971231231"/); assert.match(html, /name="email" value="21323@asdasda"/);
    assert.match(html, /<option value="teen" selected>/); assert.match(html, new RegExp(`name="first_visit_date" value="${past(30)}"`));
    assert.match(html, new RegExp(`<span class="list__name" data-picker-selected-name>&#10003; Anna MemberA</span>`), 'the inviter is shown as chosen');
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Isaiah'"), 0, 'and nothing was saved');
    // corrected, the same form goes through
    const ok = await submit({ ...VALID(), email: '21323@asdasda.com' });
    assert.equal(ok.status, 302); await ok.text();
    assert.equal(db.prepare("SELECT invited_by_member_id FROM visitors WHERE first_name = 'Isaiah'").get().invited_by_member_id, ids.member.a2);
    console.log('PASS (1) the owner\'s example fails on the Email only (no dot after the @), says so beside the field and in the summary, keeps everything typed, and saves once corrected');
  }

  // ---- 2. every field, every way it can fail ---------------------------------------------------------------------------------------------
  const long = (n) => 'x'.repeat(n);
  const CASES = [
    // [field, controlId, label, bad value(s), expected message fragment]
    ['first_name', 'first_name', 'First name', ['', '   '], 'First name is required.'],
    ['first_name', 'first_name', 'First name', [long(81)], 'First name must be 80 characters or fewer.'],
    ['last_name', 'last_name', 'Last name', [long(81)], 'Last name must be 80 characters or fewer.'],
    ['phone', 'phone', 'Contact number', ['abc', 'phone 8897', '12345', '++', '(((((((', '- - - - - -', '+ + + + + +'], 'Contact number'],
    ['phone', 'phone', 'Contact number', ['1'.repeat(33)], 'must be 6 to 32 characters long'],
    ['email', 'email', 'Email', ['no-at-sign', 'a@b', '@example.com', 'a@@b.com', 'a b@example.com', 'name@example'], 'email'],
    ['email', 'email', 'Email', [`${long(250)}@a.com`], '254 characters'],
    ['age_group', 'age_group', 'Congregation', ['senior', 'ADULT', '<script>'], 'Congregation is not a valid choice.'],
    ['first_visit_date', 'first_visit_date', 'Date of their first visit', ['', '2026-13-45', 'tomorrow', '07/08/2026', '2026-02-30'], 'Date of their first visit'],
    ['first_visit_date', 'first_visit_date', 'Date of their first visit', [mods.dates.addDays(today, 1), mods.dates.addDays(today, 400)], 'cannot be in the future'],
    ['invited_by_member_id', 'invited_by_member_id-search', 'Invited by a member', ['abc', '12abc', '1.5', '0', '-5', '1e3', '9'.repeat(20)], 'Invited by a member'],
    ['invited_by_member_id', 'invited_by_member_id-search', 'Invited by a member', ['99999999', '314159'], 'That member could not be found'],
    ['invited_by_name', 'invited_by_name', 'Invited by (a name not on our records)', [long(121)], 'must be 120 characters or fewer'],
    ['how_heard', 'how_heard', 'How they heard about the church', [long(201)], 'must be 200 characters or fewer'],
    ['notes', 'notes', 'Notes', [long(2001)], 'must be 2000 characters or fewer']
  ];
  let checked = 0;
  for (const [field, controlId, label, values, fragment] of CASES) {
    for (const bad of values) {
      const res = await submit({ ...VALID(), email: '', [field]: bad });
      const html = await res.text();
      const why = `${field} = ${JSON.stringify(String(bad).slice(0, 24))}`;
      assert.equal(res.status, 400, `${why} is refused`);
      assertFieldReported(html, { field, controlId, message: null, label }, why);
      assert.match(decode(html), new RegExp(`id="${field}-error"[^>]*>[^<]*${fragment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i'), `${why}: the message beside the field says "${fragment}"`);
      assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Isaiah' AND first_visit_date = ? AND invited_by_name IS NULL", past(30)), 1, `${why}: nothing new was saved`);
      // a value typed into any OTHER field is still there
      if (field !== 'last_name') assert.match(html, /name="last_name" value="Thomas"/, `${why}: the rest of the form is kept`);
      checked += 1;
    }
  }
  // the empty / whitespace first name must not become a valid-looking record, and a number must not be reinterpreted ("12abc" is not 12)
  assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name IS NULL OR TRIM(first_name) = ''"), 0, 'no blank-named First Timer exists');
  assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE invited_by_member_id IS NOT NULL AND invited_by_member_id <> ?", ids.member.a2), 0, 'no inviter was invented from a malformed number');
  // an inviter that does not exist is refused with its own message (it used to be a database error)
  {
    const res = await submit({ ...VALID(), invited_by_member_id: '987654' }); const html = await res.text();
    assert.equal(res.status, 400);
    assert.match(decode(html), /Choose the member from the search results\. That member could not be found\./);
  }
  console.log(`PASS (2) ${checked} bad values across all ${new Set(CASES.map((c) => c[0])).size} fields: each is refused, named, explained beside its field, linked from the summary, aria-invalid + aria-describedby correct, nothing saved`);

  // ---- 3. several problems at once, and the edit form ------------------------------------------------------------------------------------
  {
    const res = await submit({ first_name: '', last_name: long(90), phone: 'abc', email: 'x@y', age_group: 'nope', first_visit_date: 'soon', invited_by_member_id: 'zz', invited_by_name: long(130), how_heard: long(250), notes: long(2100) });
    const html = await res.text();
    const summary = /<div class="alert alert--error"[^>]*data-error-summary[\s\S]*?<\/ul>/.exec(html)[0];
    assert.equal((summary.match(/<li>/g) || []).length, 10, 'all ten problems are listed, not just the first');
    for (const id of ['first_name', 'last_name', 'phone', 'email', 'age_group', 'first_visit_date', 'invited_by_member_id-search', 'invited_by_name', 'how_heard', 'notes']) {
      assert.ok(summary.includes(`href="#${id}"`), `the summary links to #${id}`);
      assert.ok(control(html, id), `and #${id} exists to receive the link`);
      assert.match(control(html, id), /aria-invalid="true"/);
    }
    assert.match(summary, /There are 10 things to fix/);
    // focus: the page script moves focus to the summary
    const js = await (await fetch(`${portal.base}/js/app.js`)).text();
    assert.match(js, /querySelector\('\[data-error-summary\]'\)[\s\S]{0,200}summary\.focus\(\)/, 'the page script moves focus to the summary');
  }
  {
    const target = db.prepare("SELECT id FROM visitors WHERE first_name = 'Isaiah'").get().id;
    const res = await submit({ ...VALID(), first_name: 'Isaiah', email: 'bad@host' }, `/visitors/${target}`, `/visitors/${target}/edit`);
    const html = await res.text();
    assert.equal(res.status, 400);
    assertFieldReported(html, { field: 'email', controlId: 'email', message: 'Email needs a dot after the @', label: 'Email' }, 'edit form');
    assert.match(html, /<h1>Edit First Timer<\/h1>/);
    console.log('PASS (3) ten simultaneous problems are all listed and linked; the edit form reports the same way; the page script focuses the summary');
  }

  // ---- 4. copy ---------------------------------------------------------------------------------------------------------------------------
  {
    const html = await (await admin.get('/visitors/new')).text();
    assert.doesNotMatch(html, /Leave blank if you only caught/, 'the helper sentence under Last name is gone');
    assert.match(html, /<label for="last_name">Last name \(optional\)<\/label>/);
    assert.match(html, /First Timers are kept separate from member records until they are converted or linked to a member record\./);
    assert.doesNotMatch(html, /until they settle/);
    for (const url of ['/visitors', '/visitors/new', '/visitors/follow-up', `/visitors/${ids.visitor}`, `/visitors/${ids.visitor}/edit`, '/visitors/reviews']) {
      const page = decode(await (await admin.get(url)).text()).replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ');
      assert.doesNotMatch(page, /\b[Ff]irst timers?\b/, `${url}: "First Timer" is capitalised throughout the First Timer screens`);
    }
    console.log('PASS (4) copy: "Last name (optional)", the accurate heading sentence, "First Timer" capitalised consistently');
  }

  // ---- 5. Express Registration: errors, Invited by -------------------------------------------------------------------------------------
  {
    const reg = (who, fields, from) => who.post('/attendance/checkin/first-timer', { ...fields, ...(who === kiosk ? { kiosk: '1' } : {}) }, { csrfFrom: from });
    // errors are named and linked on the Express form too
    const bad = await reg(kiosk, { first_name: '', phone: 'abc', invited_by_member_id: 'zzz' }, '/kiosk');
    const html = await bad.text();
    assert.equal(bad.status, 400);
    const summary = /<div class="alert alert--error"[^>]*data-error-summary[\s\S]*?<\/ul>/.exec(html)?.[0] || '';
    for (const id of ['ft-first-name', 'ft-phone', 'invited_by_member_id-search']) assert.ok(summary.includes(`href="#${id}"`), `the Express summary links to #${id}`);
    assert.match(control(html, 'ft-first-name'), /aria-invalid="true"/); assert.match(control(html, 'ft-phone'), /aria-invalid="true"/);
    assert.match(control(html, 'invited_by_member_id-search'), /aria-invalid="true"/);
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = '' OR phone = 'abc'"), 0);

    // with and without an inviter
    const before = count('SELECT COUNT(*) n FROM members');
    const withInviter = await reg(kiosk, { first_name: 'Zadok', last_name: 'Withinviter', invited_by_member_id: String(ids.member.b1) }, '/kiosk');
    assert.equal(withInviter.status, 302); await withInviter.text();
    const zadok = db.prepare("SELECT id, invited_by_member_id, invited_by_name FROM visitors WHERE first_name = 'Zadok'").get();
    assert.equal(zadok.invited_by_member_id, ids.member.b1, 'the chosen member is the inviter');
    assert.equal(zadok.invited_by_name, null, 'no name text is stored beside it');
    assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', zadok.id), 1, 'registered and checked in together');
    const audit = JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'visitor.express_registered' AND entity_id = ?").get(String(zadok.id)).detail);
    assert.equal(audit.invited_by, ids.member.b1, 'the audit row records the inviter');

    const alone = await reg(kiosk, { first_name: 'Naomi', last_name: 'Alone' }, '/kiosk');
    assert.equal(alone.status, 302); await alone.text();
    const naomi = db.prepare("SELECT id, invited_by_member_id, invited_by_name FROM visitors WHERE first_name = 'Naomi'").get();
    assert.deepEqual([naomi.invited_by_member_id, naomi.invited_by_name], [null, null], 'no inviter selected is NULL: no fake member, no placeholder text');
    assert.equal(count('SELECT COUNT(*) n FROM members'), before, 'and no member record was created by either registration');

    // a forged inviter id, a forged name field, a list: refused or ignored, never stored
    const ghost = await reg(kiosk, { first_name: 'Ghosty', invited_by_member_id: '55555555' }, '/kiosk'); const ghostHtml = await ghost.text();
    assert.equal(ghost.status, 400); assert.match(decode(ghostHtml), /That member could not be found/);
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Ghosty'"), 0, 'a nonexistent inviter creates nothing');
    const forgedName = await reg(kiosk, { first_name: 'Forger', invited_by_name: 'Pastor Someone', how_heard: 'x', email: 'a@b.com', notes: 'n' }, '/kiosk'); await forgedName.text();
    assert.deepEqual(db.prepare("SELECT invited_by_name, how_heard, email, notes FROM visitors WHERE first_name = 'Forger'").get(), { invited_by_name: null, how_heard: null, email: null, notes: null }, 'Express stores only what it asks for');

    // a possible duplicate still stops the Kiosk, whatever inviter is chosen; the administrative desk is unchanged
    const dup = await reg(kiosk, { first_name: 'Zadok', last_name: 'Withinviter', invited_by_member_id: String(ids.member.a2) }, '/kiosk');
    assert.equal(dup.status, 409); await dup.text();
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Zadok'"), 1, 'the Kiosk cannot override a duplicate warning');

    // both Kiosk accounts behave identically (role-based), and the administrator gets the clean "done" page
    const kioskB = (db.prepare("SELECT username FROM users WHERE username LIKE '%kiosk%'").all());
    assert.ok(kioskB.length >= 1);
    const adminReg = await reg(admin, { first_name: 'Adminreg', invited_by_member_id: String(ids.member.a3) }, '/attendance/checkin/first-timer');
    assert.equal(adminReg.status, 302); assert.equal(adminReg.headers.get('location'), '/attendance/checkin/first-timer/done'); await adminReg.text();
    const done = await (await admin.get('/attendance/checkin/first-timer/done')).text();
    assert.match(done, /Welcome, Adminreg! You are checked in\./); assert.match(done, /Close this tab/); assert.match(done, /Register another First Timer/);
    assert.equal(db.prepare("SELECT invited_by_member_id FROM visitors WHERE first_name = 'Adminreg'").get().invited_by_member_id, ids.member.a3);
    { const res = await kiosk.get('/attendance/checkin/first-timer/done'); const body = await res.text(); assert.equal(res.status, 200, 'a Kiosk that just registered someone sees its own done page (the registration opened in its own tab)'); assert.match(body, /Welcome, /); assert.match(body, /<body class="kiosk">/, 'in the Kiosk layout'); assert.match(body, /href="\/kiosk"[^>]*>Back to check-in/, 'whose way back is the kiosk home'); }
    console.log('PASS (5) Express Registration: named and linked errors; optional Invited by stored as the member or NULL; nothing invented; no override for the Kiosk; audit records the inviter; administrators get a clean done page');
  }

  // ---- 6. the desk's inviter search ------------------------------------------------------------------------------------------------------
  {
    const search = async (who, q) => { const res = await who.get(`/attendance/checkin/inviter-search?q=${encodeURIComponent(q)}`); return { status: res.status, body: res.status === 200 ? await res.json() : await res.text() }; };
    assert.deepEqual((await search(kiosk, 'An')).body, [], 'fewer than three characters returns nothing');
    const hits = await search(kiosk, 'Anna');
    assert.equal(hits.status, 200);
    assert.ok(hits.body.length >= 1 && hits.body.every((h) => Object.keys(h).sort().join() === 'id,name'), 'a result is an id and a name, nothing else');
    assert.ok(hits.body.some((h) => h.id === ids.member.a2 && h.name.includes('Anna')));
    const raw = JSON.stringify(hits.body);
    assert.doesNotMatch(raw, /5550|CCIQ-|@fixture|Alpha|photo|alpha street/i, 'no phone, Member ID, email, cell group, address or photo');
    for (let i = 0; i < 12; i += 1) mods.members.createMember({ first_name: 'Crowd', last_name: `Person${i}` }, { status: 'active' });
    assert.equal((await search(kiosk, 'Crowd')).body.length, 8, 'at most eight names come back');
    assert.equal((await search(admin, 'Anna')).status, 200, 'the administrative desk uses the same search');
    const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
    assert.equal((await search(leader, 'Anna')).status, 403, 'it needs the narrow Express permission');
    const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
    assert.equal((await search(member, 'Anna')).status, 403);
    const anon = await fetch(`${portal.base}/attendance/checkin/inviter-search?q=Anna`, { redirect: 'manual' }); assert.equal(anon.status, 302);
    assert.equal((await kiosk.get('/members/picker-search?q=Anna')).status, 302, 'and the Kiosk still cannot reach the full member picker');
    // the service refuses an inviter removed between the form check and the write, and leaves nothing behind
    const express = await import('../services/express-registration.js');
    const gone = mods.members.createMember({ first_name: 'Vanishing', last_name: 'Inviter' }, { status: 'active' });
    const visitorsBefore = count('SELECT COUNT(*) n FROM visitors'); const visitsBefore = count('SELECT COUNT(*) n FROM visitor_visits');
    db.pragma('foreign_keys = OFF'); db.prepare('DELETE FROM members WHERE id = ?').run(gone.id); db.pragma('foreign_keys = ON');
    const result = express.registerFirstTimerAtDesk({ first_name: 'Orphan', invited_by_member_id: gone.id }, { userId: users.kiosk.id });
    assert.deepEqual([result.ok, result.reason], [false, 'inviter_not_found']);
    assert.deepEqual([count('SELECT COUNT(*) n FROM visitors'), count('SELECT COUNT(*) n FROM visitor_visits')], [visitorsBefore, visitsBefore], 'no First Timer, no visit');
    console.log('PASS (6) the desk\'s inviter search returns names only (3+ characters, 8 at most), needs the narrow permission, and the write refuses an inviter that vanished with nothing saved');
  }
  console.log('ALL PASS');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
