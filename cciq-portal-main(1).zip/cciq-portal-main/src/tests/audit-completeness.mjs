import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * The audit log answers "who did what, to which record, and did it work". This suite checks that
 *  1. every state-changing route writes an audit row, except a short list that is explained here (read-only or staged, or audited
 *     by the service they call) - so a new unaudited route fails this test until someone decides;
 *  2. a set of real workflows each leave one row naming the signed-in person, the action and the record;
 *  3. a refused action leaves no "success" row, and a failed sign-in leaves a failure row;
 *  4. nothing secret ever reaches the log (passwords, hashes, tokens, CSRF values), and there is no route that edits or deletes it.
 */

const EXPLAINED = {
  'POST /admin/attendance/tracking-start': 'audited inside setTrackingStartDate() (attendance.tracking_start_changed / _overridden)',
  'POST /attendance/checkin/lookup': 'read-only lookup of a QR token or name',
  'POST /attendance/checkin/review': 'read-only preview before a check-in is confirmed',
  'POST /attendance/sessions/:id(\\\\d+)/status': 'audited inside the lifecycle service (attendance.session_status_changed)',
  'POST /attendance/sessions/:id(\\\\d+)/finalize': 'audited inside the lifecycle service (attendance.finalized)',
  'POST /attendance/sessions/:id(\\\\d+)/not-taken': 'audited inside the lifecycle service (attendance.not_taken)',
  'POST /attendance/sessions/:id(\\\\d+)/reopen': 'audited inside the lifecycle service (attendance.reopened)',
  'POST /attendance/sessions/:id(\\\\d+)/corrections': 'audited inside the lifecycle service (attendance.corrected)',
  'POST /admin/import': 'stages an uploaded spreadsheet; nothing is written to members until commit (which is audited)',
  'POST /admin/import/:token([a-f0-9]{32})/preview': 'read-only preview of a staged import',
  'POST /admin/import/:token([a-f0-9]{32})/discard': 'deletes a staged, uncommitted upload only',
  'POST /documents/suggest': 'read-only suggestion list',
  'POST /visitors/:id(\\\\d+)/convert': 'audited inside convertToMember() (visitor.became_member), in the same transaction as the member it creates',
  'POST /visitors/:id(\\\\d+)/link': 'audited inside linkVisitorToMember() (visitor.linked_to_member), in the same transaction as the link',
  'POST /visitors/reviews/:id(\\\\d+)/continue': 'audited inside continueAsVisitor() (visitor.membership_review_continued)',
  'POST /attendance/checkin/search': 'read-only search (a POST only so a typed mobile number never sits in a URL)',
  'POST /attendance/checkin/first-timer': 'audited inside registerFirstTimerAtDesk() (visitor.express_registered)',
  'POST /members/:id(\\\\d+)/dob-review': 'audited inside applyDobDecision() (member.dob_review, or member.dob_corrected for a correction), in the same transaction as the decision; the first (confirmation) step writes nothing',
  'POST /notifications/:id(\\\\d+)/read': 'a person marking their own notification read',
  'POST /notifications/read-all': 'a person marking their own notifications read'
};

// ---- 1. every mutation route is audited or explained -------------------------------------------------------------------------------
const unaudited = catalogue().filter((r) => r.method !== 'GET' && !r.audits).map((r) => `${r.method} ${r.path}`);
const unexplained = unaudited.filter((k) => !EXPLAINED[k]);
assert.deepEqual(unexplained, [], 'every state-changing route writes an audit row or is listed (with a reason) in this test');
const staleExplanations = Object.keys(EXPLAINED).filter((k) => !unaudited.includes(k));
assert.deepEqual(staleExplanations, [], 'and the explained list has no route that has since gained an audit call');
for (const [key, why] of Object.entries(EXPLAINED)) {
  if (/audited inside/.test(why)) {
    // the service named in the reason really does record the audit row
    const action = why.match(/\(([a-z_.]+)/)[1];
    const fs = await import('node:fs');
    const services = ['attendance-lifecycle.js', 'visitors.js', 'membership-review.js', 'express-registration.js', 'dob-review.js'].filter((f) => fs.existsSync(new URL(`../services/${f}`, import.meta.url))).map((f) => fs.readFileSync(new URL(`../services/${f}`, import.meta.url), 'utf8')).join('\n');
    assert.ok(services.includes(`'${action}'`), `${key}: the service records ${action}`);
  }
}
const nothingEditsAudit = catalogue().filter((r) => /audit/.test(r.path) && r.method !== 'GET');
assert.deepEqual(nothingEditsAudit.map((r) => `${r.method} ${r.path}`), [], 'no route edits or deletes audit rows');
console.log(`PASS (coverage) ${catalogue().filter((r) => r.method !== 'GET').length - unaudited.length} of ${catalogue().filter((r) => r.method !== 'GET').length} state-changing routes audit directly; the other ${unaudited.length} are explained; none can edit the log`);

// ---- 2. real workflows ---------------------------------------------------------------------------------------------------------------
const f = await buildPortalFixture('cciq-audit-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const memberA = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const csrfOf = {};
  const post = async (who, name, url, fields = {}) => {
    csrfOf[name] = csrfOf[name] || await who.csrf('/');
    const res = await who.post(url, fields, { csrf: csrfOf[name] });
    await res.arrayBuffer();
    return res;
  };
  const rowsSince = (id) => db.prepare('SELECT * FROM audit_logs WHERE id > ? ORDER BY id').all(id);
  const last = () => db.prepare('SELECT COALESCE(MAX(id), 0) id FROM audit_logs').get().id;
  const flows = [];
  const flow = async (label, expectAction, run, { entityType, user = users.superAdmin } = {}) => {
    const mark = last();
    await run();
    const rows = rowsSince(mark).filter((r) => r.action === expectAction);
    assert.equal(rows.length, 1, `${label}: exactly one "${expectAction}" row (found ${rowsSince(mark).map((r) => r.action).join(', ') || 'none'})`);
    const row = rows[0];
    assert.equal(row.user_id, user.id, `${label}: names the signed-in person`);
    assert.equal(row.result, 'success', `${label}: result is success`);
    assert.ok(row.created_at && !Number.isNaN(Date.parse(row.created_at)), `${label}: has a timestamp`);
    if (entityType) assert.equal(row.entity_type, entityType, `${label}: names the kind of record`);
    assert.ok(row.entity_id, `${label}: names the record`);
    flows.push(label);
  };


  await flow('announcement', 'announcement.created', () => post(admin, 'a', '/announcements', { title: 'Audit notice', body: 'x', audience: 'all', priority: 'normal', status: 'published' }), { entityType: 'announcement' });
  await flow('activity', 'activity.created', () => post(admin, 'a', '/activities', { title: 'Audit activity', scope: 'church', status: 'draft' }), { entityType: 'activity' });
  await flow('family group', 'family.created', () => post(admin, 'a', '/family-groups', { name: 'Audit Family', first_member_id: String(ids.member.free) }));
  await flow('ministry', 'ministry.created', () => post(admin, 'a', '/ministries', { name: 'Audit Ministry' }));
  await flow('cell group', 'cellgroup.created', () => post(admin, 'a', '/cell-groups', { name: 'Audit Group', status: 'active' }));
  await flow('first timer', 'visitor.created', () => post(admin, 'a', '/visitors', { first_name: 'Audit', last_name: 'Guest', first_visit_date: mods.dates.today() }));
  const visitor = db.prepare("SELECT id FROM visitors WHERE first_name = 'Audit'").get().id;
  await flow('first timer visit', 'visitor.visit_recorded', () => post(admin, 'a', `/visitors/${visitor}/visits`, { visit_date: mods.dates.addDays(mods.dates.today(), -7) }));
  await flow('first timer becomes member', 'visitor.became_member', () => post(admin, 'a', `/visitors/${visitor}/convert`, { first_name: 'Audit', last_name: 'Guest', date_joined: mods.dates.today() }));
  await flow('member status', 'member.status_changed', () => post(admin, 'a', `/members/${ids.member.a3}/status`, { status: 'inactive', reason: 'audit test' }), { entityType: 'member' });
  await flow('attendance marks', 'attendance.recorded', () => post(admin, 'a', `/attendance/sessions/${ids.session}/records`, { [`status_${ids.member.a2}`]: 'present' }));
  await flow('reminder state', 'reminder.state_changed', () => post(admin, 'a', `/reminders/${ids.reminder}/state`, { state: 'acknowledged', current_state: 'new' }));
  await flow('giving board claim', 'giving.claim_created', () => post(memberA, 'm', '/projects/ecaq/board/claim', { date: mods.ecaq.boardDates(Number(mods.dates.today().slice(0, 4)))[3] }), { user: users.memberA });
  const claim = db.prepare('SELECT id FROM ecaq_giving_board_claims ORDER BY id DESC').get().id;
  await flow('payment', 'giving.payment_recorded', () => post(admin, 'a', `/admin/ecaq/claims/${claim}/payments`, { amount: '25', paid_on: mods.dates.today(), method: 'cash' }));
  await flow('backup', 'admin.backup_created', () => post(admin, 'a', '/admin/backups', {}));
  await flow('user created', 'admin.user_created', () => post(admin, 'a', '/admin/users', { email: 'audit.user@fixture.invalid', display_name: 'Audit User', username: 'audit_user', roles: 'member' }));
  const auditUser = db.prepare("SELECT id FROM users WHERE username = 'audit_user'").get().id;
  await flow('password reset', 'admin.user_password_reset', () => post(admin, 'a', `/admin/users/${auditUser}/password`, {}));
  await flow('user deactivated', 'admin.user_status_changed', () => post(admin, 'a', `/admin/users/${auditUser}/status`, { status: 'disabled' }));
  console.log(`PASS (workflows) ${flows.length} real workflows each leave exactly one successful row naming the person, the action and the record`);

  // ---- 3. refusals and failures --------------------------------------------------------------------------------------------------------
  const mark = last();
  csrfOf.m2 = await memberA.csrf('/');
  const denied = await memberA.post('/announcements', { title: 'Sneaky', body: 'x', audience: 'all', priority: 'normal', status: 'published' }, { csrf: csrfOf.m2 });
  await denied.arrayBuffer();
  assert.equal(denied.status, 403);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM announcements WHERE title = 'Sneaky'").get().n, 0);
  assert.equal(rowsSince(mark).filter((r) => r.action === 'announcement.created' && r.result === 'success').length, 0, 'a refused action leaves no success row');
  const bad = await signIn(portal.base, users.memberB.email, 'not-the-password-1!');
  assert.equal(bad.loginStatus, 401);
  const probe = await memberA.get('/admin/users?q=' + encodeURIComponent('+974 5550 0011'));
  await probe.arrayBuffer();
  assert.equal(probe.status, 403);
  const deniedRow = db.prepare("SELECT * FROM audit_logs WHERE result = 'denied' ORDER BY id DESC").get();
  assert.equal(deniedRow.entity_id, '/admin/users', 'a denied request is logged by path only');
  assert.ok(!JSON.stringify(deniedRow).includes('5550'), 'never with what was typed into its query string');
  const failure = db.prepare("SELECT * FROM audit_logs WHERE action = 'auth.login_failed' ORDER BY id DESC").get();
  assert.ok(failure && failure.result !== 'success', 'a failed sign-in is logged as a failure');
  console.log('PASS (refusals) a refused action leaves no success row; a failed sign-in is logged as a failure');

  // ---- 4. nothing secret in the log ------------------------------------------------------------------------------------------------------
  const everything = JSON.stringify(db.prepare('SELECT action, actor_label, detail, user_agent FROM audit_logs').all());
  const secrets = [f.PASSWORD, 'not-the-password-1!', 'scrypt$', 'password_hash', 'passwordHash', 'session_secret', '_csrf', 'csrfToken', 'Set-Cookie', 'cciq.sid'];
  for (const s of secrets) assert.ok(!everything.includes(s), `the audit log never contains "${s.slice(0, 18)}"`);
  const generated = db.prepare("SELECT detail FROM audit_logs WHERE action = 'admin.user_password_reset'").all();
  for (const r of generated) assert.ok(!/password"\s*:/i.test(r.detail || ''), 'a password reset records the method, not the password');
  const created = db.prepare("SELECT detail FROM audit_logs WHERE action = 'admin.user_created'").all();
  for (const r of created) assert.ok(!/password/i.test(r.detail || ''), 'an account creation records the roles, not the starting password');
  console.log('PASS (secrets) no password, hash, token, cookie or CSRF value appears anywhere in the audit log');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
