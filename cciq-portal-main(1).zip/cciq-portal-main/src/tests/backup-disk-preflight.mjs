import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Free-disk preflight for backup and restore (lib/disk-space.js). A nearly full disk is refused up front with a clear message and NOTHING
 * is changed: no staging folder, no partial archive, no safety backup, no database swap. An unmeasurable disk never blocks.
 * The refusal is forced without touching a real disk by raising the safety margin (BACKUP_MIN_FREE_MB), which the operator can also set.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-backup-disk-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const space = await import('../lib/disk-space.js');
const backups = await import('../services/backups.js');
const { default: config } = await import('../config/env.js');
const { default: db } = await import('../db/index.js');

// ---- 1. the helpers ---------------------------------------------------------------------------------------------------------------------
{
  const free = space.freeBytesAt(os.tmpdir());
  assert.ok(Number.isFinite(free) && free > 0, 'free space is reported for a real folder');
  assert.equal(space.freeBytesAt(path.join(os.tmpdir(), 'does', 'not', 'exist', 'yet')), space.freeBytesAt(os.tmpdir()), 'a folder that does not exist yet is measured at its nearest existing parent');
  const tree = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-tree-'));
  fs.mkdirSync(path.join(tree, 'a', 'b'), { recursive: true });
  fs.writeFileSync(path.join(tree, 'one.bin'), Buffer.alloc(1000)); fs.writeFileSync(path.join(tree, 'a', 'two.bin'), Buffer.alloc(2000)); fs.writeFileSync(path.join(tree, 'a', 'b', 'three.bin'), Buffer.alloc(300));
  assert.equal(space.treeBytes(tree), 3300, 'a folder tree is summed');
  assert.equal(space.treeBytes(path.join(tree, 'one.bin')), 1000, 'a single file is its own size');
  assert.equal(space.treeBytes(path.join(tree, 'missing')), 0, 'a missing path counts as nothing');
  fs.rmSync(tree, { recursive: true, force: true });

  delete process.env.BACKUP_MIN_FREE_MB;
  assert.equal(space.marginBytes(), 64 * 1024 * 1024, 'the default margin is 64 MB');
  process.env.BACKUP_MIN_FREE_MB = '5'; assert.equal(space.marginBytes(), 5 * 1024 * 1024);
  for (const bad of ['abc', '-3', '']) { process.env.BACKUP_MIN_FREE_MB = bad; assert.equal(space.marginBytes(), 64 * 1024 * 1024, `"${bad}" falls back to the default`); }
  delete process.env.BACKUP_MIN_FREE_MB;

  assert.equal(space.checkFreeSpace(os.tmpdir(), 1024).ok, true, 'a small need is fine');
  const tooBig = space.checkFreeSpace(os.tmpdir(), free + 1024 * 1024 * 1024 * 1024);
  assert.equal(tooBig.ok, false, 'a need larger than the free space is refused'); assert.ok(tooBig.needed > tooBig.free);
  const edge = space.checkFreeSpace(os.tmpdir(), free - space.marginBytes());
  assert.ok(edge.ok === true || edge.needed - edge.free < 1024 * 1024, 'right at the boundary it is allowed (within what changes while measuring)');
  assert.match(space.describeSpace(tooBig), /is needed and .* is free/);
  console.log('PASS (1) free space is measured at the nearest existing folder, folder sizes add up, the margin is configurable with a safe default, and the check refuses only when it knows');
}

// ---- 2. a backup refuses on a full disk and changes nothing ------------------------------------------------------------------------------
const listDir = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir).sort() : []);
{
  const first = await backups.createBackup({ note: 'fine' });
  assert.equal(first.ok, true, 'a normal backup still works');
  const archives = () => listDir(config.backupDir).filter((n) => n.endsWith('.tar.gz'));
  const stagingLeft = () => listDir(config.backupDir).filter((n) => n.endsWith('.staging') || n === '.restore-extract');
  assert.equal(archives().length, 1);

  process.env.BACKUP_MIN_FREE_MB = '999999999999';
  const refused = await backups.createBackup({ note: 'too big' });
  assert.equal(refused.ok, false); assert.equal(refused.reason, 'insufficient_disk_space');
  assert.match(refused.message, /not enough free disk space/i); assert.match(refused.message, /is needed and .* is free/);
  assert.equal(archives().length, 1, 'no partial archive was left');
  assert.deepEqual(stagingLeft(), [], 'no staging folder was left');
  const row = db.prepare('SELECT status, notes FROM backups WHERE id = ?').get(refused.backup.id);
  assert.equal(row.status, 'failed'); assert.match(row.notes, /free disk space/i, 'the attempt is recorded in the backup history with the reason');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM backups WHERE status = 'pending'").get().n, 0, 'nothing is left pending');
  delete process.env.BACKUP_MIN_FREE_MB;
  assert.equal((await backups.createBackup({ note: 'after' })).ok, true, 'and once there is room it works again');
  console.log('PASS (2) a backup on a full disk is refused with a clear message, recorded, and leaves no archive, staging folder or pending row');
}

// ---- 3. a restore refuses before taking a safety backup or touching anything --------------------------------------------------------------------
{
  const target = backups.listBackups().find((b) => b.status === 'completed');
  const dbBefore = crypto.createHash('sha256').update(fs.readFileSync(config.databaseFile)).digest('hex');
  const completed = db.prepare("SELECT COUNT(*) n FROM backups WHERE status = 'completed'").get().n;
  const preRestore = () => db.prepare("SELECT COUNT(*) n FROM backups WHERE kind = 'pre_restore'").get().n;
  const preBefore = preRestore();
  process.env.BACKUP_MIN_FREE_MB = '999999999999';
  const result = await backups.restoreBackup(target.id, { userId: null, reason: 'test' });
  delete process.env.BACKUP_MIN_FREE_MB;
  assert.equal(result.ok, false); assert.equal(result.reason, 'insufficient_disk_space');
  assert.equal(preRestore(), preBefore, 'no safety backup was started (so none can be left half written)');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM backups WHERE status = 'completed'").get().n, completed);
  assert.equal(db.prepare("SELECT status FROM backup_restores ORDER BY id DESC LIMIT 1").get().status, 'failed', 'the refusal is in the restore history');
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(config.databaseFile)).digest('hex'), dbBefore, 'the database file is byte-for-byte unchanged');
  const leftovers = fs.readdirSync(path.dirname(config.databaseFile)).filter((n) => /restore-staged|\.shadow|\.bak/.test(n));
  assert.deepEqual(leftovers, [], 'no staged or shadow files');
  assert.deepEqual(listDir(config.backupDir).filter((n) => n === '.restore-extract'), [], 'no extraction folder');
  console.log('PASS (3) a restore on a full disk is refused before the safety backup, recorded, and changes nothing (the database file is byte-identical, no shadow or staging files)');
}

// ---- 4. the admin screen explains it -----------------------------------------------------------------------------------------------------------
{
  const PASSWORD = `Bd${crypto.randomBytes(12).toString('base64url')}9!`;
  await createUser({ username: 'bd_admin', email: 'bd.admin@fixture.invalid', password: PASSWORD, displayName: 'BD Admin', roleKeys: ['super_admin'], mustChangePassword: false });
  const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port), BACKUP_MIN_FREE_MB: '999999999999' } });
  try {
    await waitForServerReady(base, server);
    const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
    const page = await fetch(`${base}/login`); const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1]; const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ email: 'bd.admin@fixture.invalid', password: PASSWORD, _csrf: csrf }) });
    const cookie = cookieOf(login, pre);
    const list = await fetch(`${base}/admin/backups`, { headers: { Cookie: cookie } });
    const token = (await list.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const created = await fetch(`${base}/admin/backups`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie }, body: new URLSearchParams({ _csrf: token, note: 'x' }) });
    assert.equal(created.status, 302);
    const after = await (await fetch(`${base}/admin/backups`, { headers: { Cookie: cookie } })).text();
    assert.match(after, /free disk space/i, 'the screen says the disk is too full');
    assert.doesNotMatch(after, /ENOSPC|SqliteError|at \w+ \(|node_modules/, 'and shows no internals');
    assert.ok(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'admin.backup_created' AND result = 'failure'").get().n >= 1, 'and the refusal is audited');
  } finally { await terminateAndWait(server); }
  console.log('PASS (4) the Backups screen tells an administrator the disk is too full (no internals) and the refusal is audited');
}

console.log('ALL PASS');
