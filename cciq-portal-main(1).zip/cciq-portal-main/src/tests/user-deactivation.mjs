import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-deactivate-test-');
process.env.SESSION_IDLE_TIMEOUT_MINUTES = '45';

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser, setUserStatus, rolesForUser } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

const created = await createUser({
  email: 'deactivate.subject@fixture.invalid',
  password: 'TestPassw0rd!2026',
  displayName: 'Deactivate Test Subject',
  roleKeys: ['church_admin'],
  mustChangePassword: false
});

const browser = await chromium.launch();
const page = await browser.newPage();

await page.goto(`${base}/login`);
await page.locator("#email").fill('deactivate.subject@fixture.invalid');
await page.locator('#password').fill('TestPassw0rd!2026');
await page.getByRole('button', { name: 'Sign in' }).click();
await page.waitForURL(/\/(dashboard)?$/, { timeout: 10000 }).catch(() => {});
const dashboardOk = (await page.goto(`${base}/members`)).status();
assert.equal(dashboardOk, 200, `subject should be able to reach /members while active (got ${dashboardOk})`);
console.log('PASS: normal (non-kiosk) subject is signed in and can reach an authenticated page');

// Now deactivate the account via the SAME service function the route uses —
// this is exactly what a Super Admin clicking "Deactivate portal access" does.
setUserStatus(created, 'disabled');

// The subject's existing browser session, with no new login, must be
// rejected on its very next request — not merely blocked from a future login.
const afterDeactivate = await page.goto(`${base}/members`);
const finalUrl = page.url();
assert.ok(finalUrl.includes('/login'), `an already-logged-in normal session must be redirected to /login immediately after deactivation, got ${finalUrl}`);
console.log('PASS: an active session for a normal (non-kiosk) user is invalidated on the very next request after deactivation, not just at next login');

// Direct, unauthenticated request to the status-change route itself — server-
// side authorization must reject this regardless of any UI control being
// hidden. A fresh request context carries no session cookie at all.
const anon = await browser.newContext();
const anonPage = await anon.newPage();
const directPost = await anonPage.request.post(`${base}/admin/users/${created}/status`, {
  form: { status: 'active' }, maxRedirects: 0
}).catch((e) => e);
const directStatus = directPost.status ? directPost.status() : null;
assert.ok(directStatus === 302 || directStatus === 401 || directStatus === 403,
  `an unauthenticated POST to /admin/users/:id/status must not succeed, got ${directStatus}`);
await anon.close();
console.log('PASS: an unauthenticated direct POST to the status-change route is rejected, not just hidden in the UI');

// A subsequent login attempt with the correct password must now fail cleanly.
await page.goto(`${base}/login`);
await page.locator("#email").fill('deactivate.subject@fixture.invalid');
await page.locator('#password').fill('TestPassw0rd!2026');
await page.getByRole('button', { name: 'Sign in' }).click();
await page.waitForTimeout(500);
assert.ok(page.url().includes('/login'), 'login must fail for a deactivated account even with the correct password');
console.log('PASS: login is refused for a deactivated account even with the correct password');

// Reactivate and confirm login now succeeds again, with roles preserved.
setUserStatus(created, 'active');
await page.goto(`${base}/login`);
await page.locator("#email").fill('deactivate.subject@fixture.invalid');
await page.locator('#password').fill('TestPassw0rd!2026');
await page.getByRole('button', { name: 'Sign in' }).click();
await page.waitForURL((u) => !u.pathname.startsWith('/login'), { timeout: 10000 });
assert.deepEqual(rolesForUser(created).map((r) => r.key), ['church_admin'], 'role assignment must survive a deactivate/reactivate cycle unchanged');
console.log('PASS: reactivation restores login and preserves the original role assignment');

await browser.close();
await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
