import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { crawl } from './lib/crawl.mjs';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * Who can see whose personal details. Fixture people have distinctive phone numbers, emails, addresses, birth dates and private
 * notes; each kind of signed-in person (and a signed-out visitor, and the Kiosk) then opens every page reachable from their
 * dashboard, and the suite looks for details they must not see. Private notes, addresses and birth dates of people outside a
 * person's own scope never appear; contact details appear only with the contact permission; pages that carry personal data are
 * not cached and never put it in a URL.
 */

const f = await buildPortalFixture('cciq-privacy-');
const { users } = f;
const portal = await startPortal();
let log = '';
portal.server.stdout?.on('data', (d) => { log += d; });
portal.server.stderr?.on('data', (d) => { log += d; });

const person = {
  a1: { phone: '+974 5550 0001', email: 'alice@fixture.invalid', address: '1 Alpha Street', dob: [/1985-03-04/, /4 Mar(ch)? 1985/, /04\/03\/1985/], notes: 'private note a1' },
  a2: { phone: '+974 5550 0002', email: 'anna@fixture.invalid', address: '2 Alpha Street', dob: [/1990-05-06/, /6 May 1990/, /06\/05\/1990/], notes: null },
  b1: { phone: '+974 5550 0011', email: 'bella@fixture.invalid', address: '3 Beta Street', dob: [/1992-07-08/, /8 Jul(y)? 1992/, /08\/07\/1992/], notes: 'private note b1' }
};
const digits = (s) => s.replace(/\D/g, '');
function found(body, who, what) {
  const p = person[who];
  if (what === 'phone') return body.includes(p.phone) || body.includes(digits(p.phone)) || body.includes(p.phone.replace(/ /g, ''));
  if (what === 'email') return body.includes(p.email);
  if (what === 'address') return body.includes(p.address);
  if (what === 'notes') return Boolean(p.notes) && body.includes(p.notes);
  if (what === 'dob') return p.dob.some((re) => re.test(body));
  return false;
}
function exposures(pages, who, fields) {
  const hits = [];
  for (const [href, page] of pages) {
    if (page.status !== 200) continue;
    for (const what of fields) if (found(page.body, who, what)) hits.push(`${who}.${what} on ${href}`);
  }
  return hits;
}

try {
  // ---- a signed-out visitor -------------------------------------------------------------------------------------------------------------
  const publicGets = catalogue().filter((r) => r.method === 'GET' && !r.requiresAuth && !r.path.includes(':'));
  const publicPages = new Map();
  for (const r of [{ path: '/login' }, { path: '/about' }, { path: '/quick-access/info' }, ...publicGets]) {
    const res = await fetch(portal.base + r.path, { redirect: 'manual' });
    publicPages.set(r.path, { status: res.status, body: /text|json/.test(res.headers.get('content-type') || '') ? await res.text() : '' });
  }
  const publicHits = [];
  for (const who of Object.keys(person)) publicHits.push(...exposures(publicPages, who, ['phone', 'email', 'address', 'notes', 'dob']));
  assert.deepEqual(publicHits, [], 'a signed-out visitor sees nothing about any member');
  console.log(`PASS (public) ${publicPages.size} signed-out pages show no member's phone, email, address, birth date or notes`);

  // ---- each kind of signed-in person ----------------------------------------------------------------------------------------------------
  const view = {};
  for (const [label, account] of [['memberA', users.memberA], ['memberB', users.memberB], ['leaderA', users.leaderA], ['leaderB', users.leaderB], ['churchAdmin', users.churchAdmin]]) {
    const session = await signIn(portal.base, account.email, f.PASSWORD);
    view[label] = { session, pages: await crawl(session, { depth: 3, max: 250 }) };
  }

  // A member sees no other member's private fields, anywhere.
  const memberRules = [
    ['memberA', [['a1', ['notes', 'address', 'dob']], ['b1', ['phone', 'email', 'address', 'dob', 'notes']]]],
    ['memberB', [['a1', ['notes', 'address', 'dob']], ['a2', ['phone', 'email', 'address', 'dob']], ['b1', ['notes']]]]
  ];
  for (const [label, rules] of memberRules) {
    const hits = rules.flatMap(([who, fields]) => exposures(view[label].pages, who, fields));
    assert.deepEqual(hits, [], `${label}: no other member's private details on any of ${view[label].pages.size} reachable pages`);
  }
  // A leader sees their own group's people, never the other group's private details.
  const allLeaderHits = [
    ...exposures(view.leaderA.pages, 'b1', ['phone', 'email', 'address', 'dob', 'notes']),
    ...exposures(view.leaderB.pages, 'a1', ['phone', 'email', 'address', 'dob', 'notes']),
    ...exposures(view.leaderB.pages, 'a2', ['phone', 'email', 'address', 'dob'])
  ];
  // OWNER DECISION (docs/WORKFLOW-INTEGRITY-AUDIT.md): the ministry page lists everyone serving in a ministry with their phone number to
  // anyone holding members.view_contact, whatever cell group they belong to (ministries are church-wide). Recorded, not changed.
  const ministryPages = allLeaderHits.filter((h) => h.includes(' on /ministries/'));
  const leaderHits = allLeaderHits.filter((h) => !h.includes(' on /ministries/'));
  if (ministryPages.length) console.log(`INFO leaders see ministry members' phone numbers across cell groups on the ministry page: ${ministryPages.join('; ')}`);
  assert.deepEqual(leaderHits, [], 'a cell group leader sees no private details of people in another group (outside the ministry page, see INFO)');
  // The administrator can see them (the positive control that the crawl really reaches member pages).
  const adminSees = exposures(view.churchAdmin.pages, 'b1', ['phone', 'email', 'address']);
  assert.ok(adminSees.length >= 1, 'control: the church administrator does reach member details, so the crawl would have found a leak');
  console.log('PASS (scope) members see no one else\'s private details; leaders see none from the other group; the administrator control shows the crawl reaches member pages');

  // INFO: what a leader sees of their OWN group (documented, not asserted as wrong)
  const leaderOwn = exposures(view.leaderA.pages, 'a2', ['phone', 'email', 'address', 'dob']);
  console.log(`INFO leader A sees of their own group's member Anna: ${leaderOwn.map((h) => h.split(' on ')[0]).filter((v, i, a) => a.indexOf(v) === i).join(', ') || 'nothing'}`);
  const memberSeesLeader = exposures(view.memberA.pages, 'a1', ['phone', 'email']);
  console.log(`INFO member A sees of their leader Alice: ${memberSeesLeader.map((h) => h.split(' on ')[0]).filter((v, i, a) => a.indexOf(v) === i).join(', ') || 'no phone or email'}`);

  // ---- the member picker and global search carry minimal fields --------------------------------------------------------------------------
  for (const label of ['memberA', 'leaderA']) {
    for (const url of ['/members/picker-search?q=Bella', '/search?q=Bella', '/search?q=Beta']) {
      const res = await view[label].session.get(url);
      const body = await res.text();
      for (const what of ['phone', 'email', 'address', 'dob', 'notes']) {
        assert.ok(!found(body, 'b1', what), `${label}: ${url} does not expose Bella's ${what}`);
      }
    }
  }
  console.log('PASS (search) the picker and global search never expose another group\'s phone, email, address, birth date or notes');

  // ---- personal data is not cached and not put in a URL -----------------------------------------------------------------------------------
  const all = [...view.churchAdmin.pages.entries(), ...view.leaderA.pages.entries()];
  const cached = all.filter(([, p]) => p.status === 200 && /text\/html/.test(p.type));
  const sensitive = [/\+974[ \d]{8,}/, /@fixture\.invalid/];
  const inUrls = [];
  for (const [href, p] of all) {
    const query = decodeURIComponent(href.split('?')[1] || '');
    if (sensitive.some((re) => re.test(query))) inUrls.push(href);
    for (const link of [...p.body.matchAll(/href="([^"]*\?[^"]*)"/g)].map((m) => m[1])) {
      const q = decodeURIComponent(link.split('?')[1] || '').replace(/&amp;/g, '&');
      if (sensitive.some((re) => re.test(q))) inUrls.push(`${link} (on ${href})`);
    }
  }
  assert.deepEqual([...new Set(inUrls)], [], 'no link or URL carries a phone number or email address');
  for (const label of ['memberA', 'churchAdmin']) {
    const res = await view[label].session.get('/members');
    await res.arrayBuffer();
    assert.match(res.headers.get('cache-control') || '', /no-store/, `${label}: member pages are served no-store`);
  }
  assert.ok(cached.length > 30, 'enough pages were examined');
  console.log(`PASS (urls + cache) ${cached.length} pages examined: personal data is in no URL, and member pages are no-store`);

  // ---- the Kiosk --------------------------------------------------------------------------------------------------------------------------
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const kioskSearch = await (await kiosk.get('/kiosk?q=Anna')).text();
  for (const what of ['phone', 'email', 'address', 'dob', 'notes']) assert.ok(!found(kioskSearch, 'a2', what), `the Kiosk search result does not show Anna's ${what}`);
  const count = await kiosk.get('/kiosk/count');
  const countJson = await count.json();
  assert.ok(!JSON.stringify(countJson).includes('@'), 'the Kiosk count carries no names or emails');
  console.log('PASS (kiosk) the Kiosk shows names to tap, never phone, email, address, birth date or notes');

  // ---- the server log ----------------------------------------------------------------------------------------------------------------------
  for (const s of [f.PASSWORD, '+974 5550', '@fixture.invalid', 'private note']) assert.ok(!log.includes(s), `the server log carries no "${s}"`);
  console.log('PASS (log) the server log holds no password, phone number, email address or private note');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
