import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';
import { OVERFLOW_CHECK_SCRIPT } from '../../tools/check-overflow.mjs';

/*
 * Portal-wide responsive and accessibility sweep, on a fixture large enough that every pager, filter row and table is
 * really on the page. For each representative screen, at phone / tablet / laptop / desktop widths:
 *   - no page-level horizontal overflow (accepted breakpoints: drawer <= 860, desktop >= 861);
 *   - every visible form control has an accessible name;
 *   - every data table has a caption and scoped column headings;
 *   - the density standard is what the browser actually computes (desktop ~14.5px / 38px, phone roomier);
 *   - phone touch targets are usable, and the keyboard focus ring is visible on the top bar;
 *   - the shared pager stays inside the screen.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-ux-sweep-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const { createFamilyGroup, addMemberToFamilyGroup } = await import('../services/family-groups.js');
const { createVisitor } = await import('../services/visitors.js');
const { today, addDays } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ux${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'ux_admin', email: 'ux.admin@fixture.invalid', password: PASSWORD, displayName: 'UX Admin', roleKeys: ['super_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'ux_admin'").get().id;
const pad = (n) => String(n).padStart(3, '0');
const members = [];
for (let n = 1; n <= 60; n += 1) {
  const d = new Date(`${today()}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + 1 + (n % 40));
  members.push(createMember({
    first_name: `UxMember${pad(n)}`, last_name: 'Sweepfixture', phone: `+974 5550 ${pad(n)}0`,
    date_of_birth: `1990-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`
  }, { status: 'active' }));
}
const family = createFamilyGroup({ name: 'Ux Sweep Family' });
for (const m of members.slice(0, 4)) addMemberToFamilyGroup(family.id, m.id);
for (let n = 1; n <= 30; n += 1) createFamilyGroup({ name: `Ux Family ${pad(n)}` });
const visitorIds = [];
for (let n = 1; n <= 30; n += 1) visitorIds.push(createVisitor({ first_name: `UxVisitor${pad(n)}`, last_name: 'Guest', phone: `+974 5551 ${pad(n)}0`, first_visit_date: addDays(today(), -40) }).id);
for (let n = 1; n <= 30; n += 1) {
  db.prepare("INSERT INTO reminders (reminder_type, member_id, title, state, dedupe_key, created_at, updated_at) VALUES ('birthday', ?, ?, 'new', ?, ?, ?)").run(members[n].id, `Ux reminder ${pad(n)}`, `ux-${n}`, '2026-01-01T00:00:00.000Z', '2026-01-01T00:00:00.000Z');
  db.prepare("INSERT INTO notifications (user_id, title, created_at) VALUES (?, ?, ?)").run(adminId, `Ux notification ${pad(n)}`, '2026-01-01T00:00:00.000Z');
  db.prepare("INSERT INTO announcements (title, body, priority, audience, status, created_at, updated_at) VALUES (?, 'A longer announcement body that wraps across a few lines on a small screen to exercise wrapping.', 'normal', 'all', 'published', ?, ?)").run(`Ux announcement ${pad(n)}`, '2026-01-01T00:00:00.000Z', '2026-01-01T00:00:00.000Z');
  db.prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, result, detail, created_at) VALUES (?, 'ux.sweep', 'ux', ?, 'success', 'A long audit detail that has to wrap inside the table cell without widening the page', ?)").run(adminId, String(n), '2026-01-01T00:00:00.000Z');
}
for (let n = 1; n <= 30; n += 1) {
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'special_service', ?, 'held', 0, 0, ?)").run(addDays('2026-01-01', -n), `Ux session ${pad(n)}`, '2026-01-01T00:00:00.000Z');
}

const PAGES = [
  '/', '/members', `/members/${members[0].id}`, '/members/new', `/members/${members[0].id}/edit`, '/members/birthdays', '/members/congregations',
  '/family-groups', `/family-groups/${family.id}`, '/family-groups/new', `/family-groups/${family.id}/edit`,
  '/visitors', '/visitors/new', `/visitors/${visitorIds[0]}`, '/visitors/follow-up',
  '/reminders', '/notifications', '/announcements', '/activities', '/documents', '/cell-groups', '/ministries', '/ministries/serving',
  '/admin/users', '/admin/audit?action=ux.sweep', '/admin/settings?section=friday_service', '/admin/settings?section=attendance', '/admin/about', '/my/profile',
  '/attendance', '/attendance/history', '/attendance/follow-up', '/attendance/long-absence', '/attendance/reports', '/reports'
];
const WIDTHS = [320, 375, 430, 768, 861, 1024, 1440];

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
let browser;
try {
  await waitForServerReady(base, server);
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}/login`);
  await page.fill('#email', 'ux.admin@fixture.invalid');
  await page.fill('#password', PASSWORD);
  await Promise.all([page.waitForNavigation(), page.click('button[type="submit"]')]);

  const inspect = () => page.evaluate(() => {
    const visible = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
    const nameOf = (el) => {
      if (el.getAttribute('aria-label') || el.getAttribute('aria-labelledby') || el.getAttribute('title')) return true;
      if (el.id && document.querySelector(`label[for="${CSS.escape(el.id)}"]`)) return true;
      if (el.closest('label')) return true;
      if (el.tagName === 'BUTTON' || el.tagName === 'SUMMARY') return (el.textContent || '').trim().length > 0;
      return false;
    };
    const unnamed = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]), select, textarea'))
      .filter(visible).filter((el) => !nameOf(el)).map((el) => `${el.tagName.toLowerCase()}#${el.id || el.name || '?'}`);
    const tables = Array.from(document.querySelectorAll('table.data')).filter(visible);
    const badTables = tables.filter((t) => !t.querySelector('caption') || Array.from(t.querySelectorAll('thead th')).some((th) => !th.hasAttribute('scope') && th.textContent.trim())).length;
    const small = Array.from(document.querySelectorAll('.main button, .main a.btn, .main input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="file"]), .main select, .main textarea'))
      .filter(visible).map((el) => ({ el, h: el.getBoundingClientRect().height }))
      .filter(({ el, h }) => (el.matches('input, select, textarea') ? h < 38 : h < 30))
      .map(({ el, h }) => `${el.tagName.toLowerCase()}.${(el.className || "").toString().split(" ")[0]}[${el.type || ""} ${el.name || el.id || ""}] ${Math.round(h)}px`);
    const pager = document.querySelector('.pager');
    const pagerOverflow = pager ? pager.getBoundingClientRect().right > window.innerWidth + 1 || pager.scrollWidth > pager.clientWidth + 1 : false;
    return { unnamed, badTables, small, pagerOverflow };
  });

  const reports = [];
  for (const url of PAGES) {
    const res = await page.goto(`${base}${url}`);
    assert.equal(res.status(), 200, `${url} loads`);
    for (const width of WIDTHS) {
      await page.setViewportSize({ width, height: 900 });
      const overflow = await page.evaluate(OVERFLOW_CHECK_SCRIPT);
      assert.equal(overflow.overflow, false, `${url} overflows at ${width}px: ${JSON.stringify(overflow).slice(0, 200)}`);
    }
    await page.setViewportSize({ width: 1440, height: 900 });
    const desktop = await inspect();
    assert.deepEqual(desktop.unnamed, [], `${url}: every form control has an accessible name`);
    assert.equal(desktop.badTables, 0, `${url}: every data table has a caption and scoped headings`);
    assert.equal(desktop.pagerOverflow, false, `${url}: the pager stays inside the page (desktop)`);
    await page.setViewportSize({ width: 390, height: 844 });
    const phone = await inspect();
    assert.equal(phone.pagerOverflow, false, `${url}: the pager stays inside the page (phone)`);
    assert.deepEqual(phone.small, [], `${url}: phone touch targets are usable (${phone.small.join('; ')})`);
    reports.push(url);
  }
  console.log(`PASS (${reports.length} screens) no horizontal overflow at 320/375/430/768/861/1024/1440; every control named; tables captioned with scoped headings; pagers inside the page; phone touch targets >= 30px (inputs >= 38px)`);

  // The density standard is what the browser computes.
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(`${base}/members`);
  const dense = await page.evaluate(() => {
    const px = (el, prop) => parseFloat(getComputedStyle(el)[prop]);
    const body = document.body; const input = document.querySelector('#q'); const nav = document.querySelector('.nav__link'); const cell = document.querySelector('table.data td');
    const btn = document.querySelector('.page-head .btn');
    return { body: px(body, 'fontSize'), input: px(input, 'fontSize'), inputH: input.getBoundingClientRect().height, nav: px(nav, 'fontSize'), cell: px(cell, 'fontSize'), btnH: btn.getBoundingClientRect().height, h1: px(document.querySelector('h1'), 'fontSize') };
  });
  assert.ok(dense.body >= 14 && dense.body <= 15, `desktop body text ${dense.body}px`);
  assert.ok(dense.input >= 14 && dense.input <= 15, `desktop control text ${dense.input}px`);
  assert.ok(dense.inputH >= 36 && dense.inputH <= 40, `desktop control height ${dense.inputH}px`);
  assert.ok(dense.nav >= 13.5 && dense.nav <= 15.5, `desktop navigation text ${dense.nav}px`);
  assert.ok(dense.cell >= 13.5 && dense.cell <= 15.5, `desktop table text ${dense.cell}px`);
  assert.ok(dense.btnH >= 36 && dense.btnH <= 40, `desktop button height ${dense.btnH}px`);
  assert.ok(dense.h1 >= 28 && dense.h1 <= 32, `desktop page title ${dense.h1}px`);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${base}/members`);
  const roomy = await page.evaluate(() => ({ body: parseFloat(getComputedStyle(document.body).fontSize), inputH: document.querySelector('#q').getBoundingClientRect().height }));
  assert.ok(roomy.body >= 15, `phone body text stays roomy (${roomy.body}px)`);
  assert.ok(roomy.inputH >= 42, `phone controls stay tall (${roomy.inputH}px)`);
  console.log(`PASS (density) desktop: body ${dense.body}px, control ${dense.input}px / ${Math.round(dense.inputH)}px tall, nav ${dense.nav}px, table ${dense.cell}px, title ${dense.h1}px; phone: body ${roomy.body}px, controls ${Math.round(roomy.inputH)}px`);

  // Keyboard focus is visible where it used to vanish (an undefined design token voided the outline).
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(`${base}/`);
  const focus = await page.evaluate(() => {
    const bell = document.querySelector('.topbar__bell');
    bell.focus();
    const s = getComputedStyle(bell);
    return { style: s.outlineStyle, width: parseFloat(s.outlineWidth), focusVisible: bell.matches(':focus-visible') };
  });
  assert.ok(focus.style !== 'none' && focus.width >= 2, 'the notification bell shows a focus ring');
  await page.keyboard.press('Tab');
  const tabbed = await page.evaluate(() => { const a = document.activeElement; const s = getComputedStyle(a); return { tag: a.tagName, outline: s.outlineStyle, w: parseFloat(s.outlineWidth) }; });
  assert.ok(tabbed.outline !== 'none' && tabbed.w >= 2, `the next focused element (${tabbed.tag}) shows a focus ring`);
  console.log('PASS (keyboard) focus rings are visible on the top bar and on the next tab stop');
  assert.deepEqual(errors, [], 'no script errors on any screen');
} finally {
  if (browser) await browser.close();
  await terminateAndWait(server);
}
db.close();
console.log('ALL PASS');
