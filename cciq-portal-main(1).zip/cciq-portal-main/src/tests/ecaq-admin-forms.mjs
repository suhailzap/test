import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The ECAQ administration forms and action bars, measured in a real browser at 320 to 1920 px:
 *   - Claim for a member (choose the member; review) and the Faith Promise "Record for a member" form keep clear vertical space between the member area, Notes / the next field and the buttons,
 *     the buttons wrap cleanly and are never clipped, and nothing scrolls sideways;
 *   - choosing a member works by touch-sized controls on a phone;
 *   - "Claim a date for a member" (Giving Board) and "Record for a member" (Faith Promise) are the same kind of action and look the same: the primary button, first in the bar.
 */

const f = await buildPortalFixture('cciq-ecaq-forms-');
const { db, ids, users } = f;
const board = db.prepare("SELECT id, year FROM ecaq_campaigns WHERE type = 'giving_board' LIMIT 1").get();
const promise = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'faith_promise' LIMIT 1").get();
db.prepare('UPDATE ecaq_campaigns SET amount_per_date = 300 WHERE id = ?').run(board.id); // the real Giving Board commitment
const FREE_DATE = `${board.year}-03-18`;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const problems = [];
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const cookies = admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const measure = (page) => page.evaluate(() => {
    const r = (el) => { const b = el.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height, right: b.right, bottom: b.bottom }; };
    const form = document.querySelector('main form.form');
    const buttons = form ? [...form.querySelectorAll('.form__actions .btn')].map(r) : [];
    const actions = form ? form.querySelector('.form__actions') : null;
    const fields = form ? [...form.querySelectorAll(':scope > .field, :scope > .field-grid')].map(r) : [];
    const lastField = fields[fields.length - 1] || null;
    const notes = document.getElementById('notes');
    const picker = form ? form.querySelector('.member-picker') : null;
    return {
      overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      buttons, actions: actions ? r(actions) : null, lastField, fields,
      notes: notes ? r(notes) : null, picker: picker ? r(picker) : null, vw: document.documentElement.clientWidth
    };
  });

  for (const width of [320, 375, 430, 768, 1024, 1280, 1440, 1920]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } });
    await context.addCookies(cookies);
    const page = await context.newPage();
    const tag = `${width}px`;

    for (const [label, url] of [
      ['claim (choose the member)', `/admin/ecaq/claims/new?date=${FREE_DATE}`],
      ['Faith Promise form', `/admin/ecaq/faith-promise/new?campaign=${promise.id}`]
    ]) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const m = await measure(page);
      if (m.overflow > 0) problems.push(`${tag} ${label}: sideways scroll ${m.overflow}px`);
      if (!m.actions || m.buttons.length < 2) { problems.push(`${tag} ${label}: no action bar`); continue; }
      // the action bar is clearly below the last field (the space the owner found missing)
      const gapAbove = m.actions.y - m.lastField.bottom;
      if (gapAbove < 14) problems.push(`${tag} ${label}: only ${Math.round(gapAbove)}px between the last field and the buttons`);
      // consecutive fields are separated
      for (let i = 1; i < m.fields.length; i += 1) {
        const gap = m.fields[i].y - m.fields[i - 1].bottom;
        if (m.fields[i].y > m.fields[i - 1].y + 5 && gap < 10) problems.push(`${tag} ${label}: field ${i + 1} is only ${Math.round(gap)}px below field ${i}`);
      }
      for (const b of m.buttons) {
        if (b.right > m.vw + 1 || b.x < -1) problems.push(`${tag} ${label}: a button is clipped (${Math.round(b.x)}..${Math.round(b.right)} of ${m.vw})`);
        if (b.h < 36) problems.push(`${tag} ${label}: a button is only ${Math.round(b.h)}px high`);
        if (b.w < 70) problems.push(`${tag} ${label}: a button is squeezed to ${Math.round(b.w)}px`);
      }
    }

    // the claim form: the member picker and Notes
    await page.goto(`${portal.base}/admin/ecaq/claims/new?date=${FREE_DATE}`, { waitUntil: 'load' });
    const claim = await measure(page);
    if (claim.notes && claim.picker && claim.notes.y - claim.picker.bottom < 12) problems.push(`${tag} claim: Notes is only ${Math.round(claim.notes.y - claim.picker.bottom)}px under the member area`);
    const labelGap = await page.evaluate(() => { const label = document.querySelector('label[for="notes"]').getBoundingClientRect(); const picker = document.querySelector('.member-picker').getBoundingClientRect(); const input = document.getElementById('notes').getBoundingClientRect(); return { aboveLabel: label.top - picker.bottom, labelToInput: input.top - label.bottom }; });
    if (labelGap.aboveLabel < 12) problems.push(`${tag} claim: the Notes label is only ${Math.round(labelGap.aboveLabel)}px below the member area`);
    if (labelGap.labelToInput > labelGap.aboveLabel) problems.push(`${tag} claim: the Notes label sits closer to the field above than to its own input`);
    if (await page.locator('main').innerText().then((t) => /QAR/.test(t))) problems.push(`${tag} claim: the choose-the-member step shows an amount`);

    // choose a member with the picker (touch-sized controls), then Review shows the amount
    await page.locator('#member_id-search').fill('Anna');
    await page.locator('[data-picker-results] [role="option"], [data-picker-results] button, [data-picker-results] li').first().waitFor({ state: 'visible', timeout: 8000 });
    const option = await page.locator('[data-picker-results] [role="option"], [data-picker-results] button, [data-picker-results] li').first().boundingBox();
    if (option && (option.height < 36 || option.x + option.width > width + 1)) problems.push(`${tag} claim: a search result is ${Math.round(option.height)}px high / clipped`);
    await page.locator('[data-picker-results] [role="option"], [data-picker-results] button, [data-picker-results] li').first().click();
    await page.locator('[data-picker-selected]').waitFor({ state: 'visible' });
    const selectedText = await page.locator('[data-picker-selected]').innerText();
    if (!/Anna/.test(selectedText) || !/CCIQ-/.test(selectedText)) problems.push(`${tag} claim: the selected-member card shows "${selectedText.replace(/\s+/g, ' ')}"`);
    await page.locator('#notes').fill('by phone');
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.getByRole('button', { name: 'Review' }).click()]);
    const reviewText = await page.locator('main').innerText();
    if (!/QAR 300/.test(reviewText) || !/[A-Z][a-z]+day 18 March/.test(reviewText) || !/Anna/.test(reviewText)) problems.push(`${tag} review: "${reviewText.replace(/\s+/g, ' ').slice(0, 160)}"`);
    const review = await page.evaluate(() => { const btns = [...document.querySelectorAll('.form__actions .btn')].map((b) => { const r = b.getBoundingClientRect(); return { right: r.right, w: r.width, h: r.height }; }); const dl = document.querySelector('dl.definition').getBoundingClientRect(); return { btns, formTop: document.querySelector('.form__actions').getBoundingClientRect().top, dlBottom: dl.bottom, overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, vw: document.documentElement.clientWidth }; });
    if (review.overflow > 0) problems.push(`${tag} review: sideways scroll`);
    if (review.btns.some((b) => b.right > review.vw + 1)) problems.push(`${tag} review: a button is clipped`);
    if (review.formTop - review.dlBottom < 14) problems.push(`${tag} review: the buttons are glued to the details`);

    // the action bars: same hierarchy on both pages, wrapping cleanly
    const bars = {};
    for (const [label, url] of [['Giving Board', `/admin/ecaq?campaign=${board.id}`], ['Faith Promise', `/admin/ecaq/faith-promise?campaign=${promise.id}`]]) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      bars[label] = await page.evaluate(() => {
        const bar = document.querySelector('.page-head__actions'); const btns = [...bar.querySelectorAll('.btn')];
        const cs = (el) => getComputedStyle(el);
        return {
          overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, vw: document.documentElement.clientWidth,
          primary: btns.filter((b) => !b.classList.contains('btn--secondary')).map((b) => ({ text: b.textContent.trim(), bg: cs(b).backgroundColor, color: cs(b).color, first: b === btns[0] })),
          secondary: btns.filter((b) => b.classList.contains('btn--secondary')).map((b) => ({ bg: cs(b).backgroundColor })),
          clipped: btns.filter((b) => { const r = b.getBoundingClientRect(); return r.right > document.documentElement.clientWidth + 1 || r.x < -1; }).length,
          narrow: btns.filter((b) => b.getBoundingClientRect().width < 60).map((b) => b.textContent.trim())
        };
      });
      const b = bars[label];
      if (b.overflow > 0) problems.push(`${tag} ${label}: sideways scroll ${b.overflow}px`);
      if (b.clipped) problems.push(`${tag} ${label}: ${b.clipped} action button(s) clipped`);
      if (b.narrow.length) problems.push(`${tag} ${label}: squeezed buttons ${b.narrow.join(', ')}`);
      if (b.primary.length !== 1 || !b.primary[0].first) problems.push(`${tag} ${label}: expected exactly one primary action, first in the bar (${JSON.stringify(b.primary.map((p) => p.text))})`);
    }
    const gb = bars['Giving Board'].primary[0]; const fp = bars['Faith Promise'].primary[0];
    if (gb && fp && (gb.bg !== fp.bg || gb.color !== fp.color)) problems.push(`${tag}: the two equivalent actions look different (${gb.bg} vs ${fp.bg})`);
    if (gb && bars['Giving Board'].secondary[0] && gb.bg === bars['Giving Board'].secondary[0].bg) problems.push(`${tag}: the primary action does not stand out from the secondary ones`);
    await context.close();
  }
} finally {
  await portal.stop();
  await browser.close();
}
f.db.close();
f.env.cleanup();
assert.deepEqual(problems, [], problems.join('\n'));
console.log('PASS (forms) the claim-for-a-member form (choose, review) and the Faith Promise form at 320 to 1920 px: clear space between the member area, Notes and the buttons, buttons wrap and are never clipped or squeezed, nothing scrolls sideways; the member is chosen with touch-sized controls and the review shows the QAR 300');
console.log('PASS (hierarchy) "Claim a date for a member" and "Record for a member" are the same primary button, first in their bars, with the management actions secondary');
console.log('ALL PASS');
