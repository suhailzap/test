import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Faith Promise payments: "Received by" (the person who physically received the money) is a different fact from "Recorded by" (the signed-in administrator who entered it).
 *   - required on every NEW payment (blank, spaces only, over 120 characters and hand-built field shapes are refused with nothing stored); free text, kept as written (spaces tidied);
 *   - payments from before the field existed keep NULL and show "Not recorded"; nothing is invented from the administrator;
 *   - the payment history, the ledger report (screen and print) and its CSV show it, separately from Recorded by; the Giving Board ledger does not;
 *   - a correction audits the old and new value, who, when and why; a recorded value cannot be erased by a correction (a blank, legacy one may be filled); a request that does
 *     not send the field leaves it alone; removal keeps it in the audit snapshot;
 *   - nothing about who may record, correct or remove a payment changed.
 */

const f = await buildPortalFixture('cciq-fp-received-by-');
const { db, ids, users, mods } = f;
const one = (sql, ...p) => db.prepare(sql).get(...p);
const count = (sql, ...p) => one(sql, ...p).n;
const world = () => JSON.stringify([db.prepare('SELECT * FROM ecaq_faith_promise_payments ORDER BY id').all(), count("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'ecaq.faith_promise_payment%'")]);
// a payment from before the field existed (written raw: the service now refuses a blank one)
const legacyId = Number(db.prepare("INSERT INTO ecaq_faith_promise_payments (commitment_id, amount, paid_on, method, created_at, created_by) VALUES (?, 20, '2026-01-05', 'cash', '2026-01-05T09:00:00.000Z', ?)").run(ids.commitment, users.churchAdmin.id).lastInsertRowid);
mods.faith.recalculateCommitment(ids.commitment);

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const c = { church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD), super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD),
    member: await signIn(portal.base, users.memberA.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD) };
  const text = async (client, url) => { const r = await client.get(url); return { status: r.status, body: await r.text() }; };
  const flat = (body) => ((/<main[\s\S]*?<\/main>/.exec(body) || [body])[0]).replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');
  const payUrl = `/admin/ecaq/faith-promise/commitments/${ids.commitment}/payments`;
  const pageUrl = `/admin/ecaq/faith-promise/commitments/${ids.commitment}`;
  const raw = async (client, url, pairs) => { // urlencoded with repeated / bracketed keys when needed
    const token = await client.csrf('/account/password'); const body = new URLSearchParams({ _csrf: token }); for (const [k, v] of pairs) body.append(k, v);
    const r = await fetch(`${portal.base}${url}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: client.cookie }, body }); await r.text(); return r;
  };
  const record = (client, fields) => client.post(payUrl, { amount: '100', paid_on: mods.dates.today(), method: 'cash', ...fields }, { csrfFrom: pageUrl }).then(async (r) => { await r.text(); return r; });

  // ---- 1. required on a new payment; refused input stores nothing --------------------------------------------------------------------------------------------------------------------
  { const before = world();
    for (const bad of [{}, { received_by: '' }, { received_by: '   ' }, { received_by: 'x'.repeat(121) }, { received_by: '\t\n' }]) { const r = await record(c.church, bad); assert.ok(r.status < 500, JSON.stringify(bad).slice(0, 40)); assert.equal(world(), before, `refused: ${JSON.stringify(bad).slice(0, 40)}`); }
    for (const pairs of [[['amount', '100'], ['paid_on', mods.dates.today()], ['method', 'cash'], ['received_by[x]', 'Someone']], [['amount', '100'], ['paid_on', mods.dates.today()], ['method', 'cash'], ['received_by', 'A'], ['received_by', 'B']]]) {
      const r = await raw(c.church, payUrl, pairs); assert.ok(r.status < 500, `shape ${JSON.stringify(pairs.at(-1))} -> ${r.status}`); assert.equal((await fetch(`${portal.base}/healthz`)).status, 200);
    }
    // the service itself refuses too
    const direct = mods.faith.addPayment(ids.commitment, { amount: 5, paid_on: mods.dates.today(), method: 'cash' }, { userId: users.churchAdmin.id }); assert.equal(direct.ok, false); assert.equal(direct.reason, 'received_by_required');
    console.log('PASS (required) a new payment without Received by (missing, blank, spaces, over 120 characters, hand-built shapes) is refused by the route and by the service, and stores nothing'); }

  // ---- 2. recorded, kept as written, separate from Recorded by -------------------------------------------------------------------------------------------------------------------------------
  const ok = await record(c.church, { amount: '100', received_by: '  Bro.   Juan  Dela Cruz ', reference: 'RCPT-7' });
  assert.equal(ok.status, 302);
  const row = one("SELECT * FROM ecaq_faith_promise_payments WHERE reference = 'RCPT-7'");
  assert.equal(row.received_by, 'Bro. Juan Dela Cruz', 'spaces tidied, the name otherwise kept exactly'); assert.equal(Number(row.amount), 100);
  assert.equal(row.created_by, users.churchAdmin.id, 'Recorded by is the signed-in administrator'); assert.notEqual(row.received_by, 'fx_church');
  { const audit = one("SELECT * FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_recorded' ORDER BY id DESC"); assert.equal(JSON.parse(audit.detail).received_by, 'Bro. Juan Dela Cruz'); assert.equal(audit.user_id, users.churchAdmin.id, 'the audit row names the administrator as the actor'); }
  { const page = await text(c.church, pageUrl); const body = flat(page.body);
    assert.match(page.body, /<label for="new-received-by">Received by<\/label>\s*<input[^>]*name="received_by"[^>]*required/, 'a required, labelled field on the form');
    assert.match(body, /Who physically received the payment\. This is not the person recording it in the portal\./);
    assert.match(page.body, /<th scope="col">Received by<\/th>\s*<th scope="col">Recorded in the portal<\/th>/, 'two separate columns');
    assert.match(body, /Bro\. Juan Dela Cruz\s+\S+ \S+ \S+,? [\d:]+ [ap]m by fx_church/, 'Received by and Recorded in the portal / by are separate facts'); assert.match(body, /Not recorded/, 'the payment from before the field says so, never a guess');
    assert.match(page.body, /<option value="Bro\. Juan Dela Cruz">/, 'names already used are offered as suggestions'); }
  console.log('PASS (recorded) Received by is kept as written (spaces tidied), is not the administrator, is audited, and the history shows Received by and Recorded by as separate columns; a payment without a value shows "Not recorded"');

  // ---- 3. corrections ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  const fix = (client, id, fields) => client.post(`/admin/ecaq/faith-promise/payments/${id}`, { amount: '100', paid_on: mods.dates.today(), method: 'cash', reason: 'Wrong name entered', ...fields }, { csrfFrom: pageUrl }).then(async (r) => { await r.text(); return r; });
  { const r = await fix(c.super, row.id, { received_by: 'Sis. Maria Santos' }); assert.equal(r.status, 302);
    assert.equal(one('SELECT received_by FROM ecaq_faith_promise_payments WHERE id = ?', row.id).received_by, 'Sis. Maria Santos');
    const audit = one("SELECT * FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_corrected' ORDER BY id DESC"); const d = JSON.parse(audit.detail);
    assert.equal(d.before.received_by, 'Bro. Juan Dela Cruz', 'the old value is kept'); assert.equal(d.after.received_by, 'Sis. Maria Santos', 'and the new one'); assert.equal(d.reason, 'Wrong name entered');
    assert.equal(audit.user_id, users.superAdmin.id, 'who corrected it'); assert.ok(audit.created_at, 'when');
    assert.equal(one('SELECT created_by FROM ecaq_faith_promise_payments WHERE id = ?', row.id).created_by, users.churchAdmin.id, 'Recorded by is unchanged by a correction'); assert.equal(one('SELECT updated_by FROM ecaq_faith_promise_payments WHERE id = ?', row.id).updated_by, users.superAdmin.id);
    // a recorded value cannot be erased
    const before = world(); const blank = await fix(c.church, row.id, { received_by: '   ' }); assert.ok(blank.status < 500); assert.equal(world(), before, 'blanking a recorded Received by changes nothing');
    // a request that does not send the field leaves it alone (the amount is still corrected)
    const keep = await fix(c.church, row.id, { amount: '110' }); assert.equal(keep.status, 302); const kept = one('SELECT * FROM ecaq_faith_promise_payments WHERE id = ?', row.id); assert.equal(Number(kept.amount), 110); assert.equal(kept.received_by, 'Sis. Maria Santos');
    // no reason, no correction
    const noReason = await fix(c.church, row.id, { reason: '', received_by: 'Someone Else' }); assert.ok(noReason.status < 500); assert.equal(one('SELECT received_by FROM ecaq_faith_promise_payments WHERE id = ?', row.id).received_by, 'Sis. Maria Santos'); }
  { // a payment from before the field existed: may stay blank, may be filled, is never invented
    const stay = await fix(c.church, legacyId, { amount: '20', paid_on: '2026-01-05', received_by: '' }); assert.equal(stay.status, 302); assert.equal(one('SELECT received_by FROM ecaq_faith_promise_payments WHERE id = ?', legacyId).received_by, null, 'still not recorded: nothing invented');
    const fill = await fix(c.church, legacyId, { amount: '20', paid_on: '2026-01-05', received_by: 'Treasurer Reyes', reason: 'Receiver remembered' }); assert.equal(fill.status, 302); assert.equal(one('SELECT received_by FROM ecaq_faith_promise_payments WHERE id = ?', legacyId).received_by, 'Treasurer Reyes');
    const d = JSON.parse(one("SELECT * FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_corrected' ORDER BY id DESC").detail); assert.equal(d.before.received_by, null); assert.equal(d.after.received_by, 'Treasurer Reyes'); }
  console.log('PASS (corrections) a correction audits the old and new Received by with who, when and why; Recorded by does not change; a recorded value cannot be blanked; an omitted field is left alone; a legacy blank may stay blank or be filled');

  // ---- 4. the ledger report, its print view and CSV ---------------------------------------------------------------------------------------------------------------------------------------------
  { const ledgerUrl = `/admin/ecaq/campaigns/${ids.promise}/ledger`; const page = await text(c.church, ledgerUrl); assert.equal(page.status, 200);
    assert.match(page.body, /<th scope="col">Received by<\/th>/, 'the payment table has the column'); assert.match(flat(page.body), /Sis\. Maria Santos/); assert.match(flat(page.body), /Not recorded|Treasurer Reyes/);
    assert.match(page.body, /<th>Received by<\/th>/, 'and so does the printed table');
    const csv = await c.church.get(`${ledgerUrl}.csv?view=payments`); const body = await csv.text(); const header = body.split('\r\n')[0];
    assert.match(header, /"Reference","Received by","Recorded at","Recorded by"/, 'the CSV has Received by and Recorded by as separate columns'); assert.match(body, /Sis\. Maria Santos/); assert.ok(body.split('\r\n').some((l) => /Treasurer Reyes/.test(l)));
    const summary = await c.church.get(`${ledgerUrl}.csv`); assert.ok(!/Received by/.test((await summary.text()).split('\r\n')[0]), 'the member summary CSV is not cluttered with it');
    // the Giving Board ledger is unchanged
    const board = mods.ecaq.createCampaign({ name: 'Ledger board', year: 2025, type: 'giving_board', status: 'active', start_date: '2025-01-01', end_date: '2025-12-31' });
    const b = await text(c.church, `/admin/ecaq/campaigns/${board.id}/ledger`); assert.ok(!/Received by/.test(b.body), 'the Giving Board ledger has no Received by');
    const bcsv = await (await c.church.get(`/admin/ecaq/campaigns/${board.id}/ledger.csv?view=payments`)).text(); assert.ok(!/Received by/.test(bcsv.split('\r\n')[0])); }
  console.log('PASS (reports) the Faith Promise ledger (screen, print, payments CSV) shows Received by next to, and separate from, Recorded by; the summary CSV and the Giving Board ledger are not cluttered');

  // ---- 5. removal keeps it in the audit; authority unchanged ---------------------------------------------------------------------------------------------------------------------------------
  { const r = await c.church.post(`/admin/ecaq/faith-promise/payments/${row.id}/delete`, { reason: 'Duplicate entry' }, { csrfFrom: pageUrl }); await r.text(); assert.equal(r.status, 302);
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE id = ?', row.id), 0); const d = JSON.parse(one("SELECT * FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_deleted' ORDER BY id DESC").detail);
    assert.equal(d.removed.received_by, 'Sis. Maria Santos', 'the removed payment is in the audit row with who received it'); assert.equal(d.reason, 'Duplicate entry'); }
  { const before = world();
    for (const who of ['leader', 'member', 'kiosk']) {
      for (const [url, fields] of [[payUrl, { amount: '5', paid_on: mods.dates.today(), method: 'cash', received_by: 'Intruder' }], [`/admin/ecaq/faith-promise/payments/${legacyId}`, { amount: '5', paid_on: '2026-01-05', method: 'cash', reason: 'x', received_by: 'Intruder' }], [`/admin/ecaq/faith-promise/payments/${legacyId}/delete`, { reason: 'x' }]]) {
        const r = await c[who].post(url, fields, { csrfFrom: '/account/password' }); await r.text(); assert.ok(r.status === 403 || (r.status === 302 && !/\/admin\/ecaq/.test(r.headers.get('location') || '')), `${who} ${url} -> ${r.status}`);
      }
    }
    assert.equal(world(), before, 'a leader, a Member and the Kiosk still cannot record, correct or remove a payment'); }
  console.log('PASS (removal, authority) a removed payment keeps Received by in its audit row; a leader, a Member and the Kiosk are still refused');

  // ---- 6. widths -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  const problems = []; const cookies = c.church.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  for (const width of [320, 375, 430, 768, 1024, 1280, 1440]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookies); const page = await context.newPage();
    for (const url of [pageUrl, `/admin/ecaq/campaigns/${ids.promise}/ledger`]) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const m = await page.evaluate(() => { const i = document.getElementById('new-received-by'); const r = i ? i.getBoundingClientRect() : null; return { overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, field: r ? { right: r.right, h: r.height } : null }; });
      if (m.overflow > 0) problems.push(`${width}px ${url}: sideways scroll ${m.overflow}px`); if (url === pageUrl && (!m.field || m.field.right > width + 1 || m.field.h < 30)) problems.push(`${width}px: the Received by field is missing, off screen or too small`);
    }
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('; '));
  console.log('PASS (widths) the Record payment form and payment history with Received by, and the ledger, at 320 to 1440 px: no sideways scroll');
  console.log('PASS faith-promise-received-by');
} finally {
  await browser.close();
  await portal.stop();
}
