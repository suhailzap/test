import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import Database from 'better-sqlite3';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * tools/check-status-history.mjs - the pre-Go-Live, READ-ONLY status-history diagnostic.
 * Everything here uses disposable database COPIES built under the OS temp directory.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-status-diagnostic-');
const tool = path.join(root, 'tools/check-status-history.mjs');
const sha = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

const { migrate } = await import('../db/migrate.js'); migrate();
const { createMember } = await import('../services/members.js');
const { DEFAULT_ROSTER_STATUSES } = await import('../services/members.js');
const { EXPECTED_STATUSES } = await import('../lib/status-as-of.js');
const tracking = await import('../services/attendance-tracking.js');
const { addDays, lastFridayOnOrBefore, today } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const SERVICE = lastFridayOnOrBefore(today());
const GO_LIVE = addDays(SERVICE, -14);
const atNoon = (date) => `${date}T09:00:00.000Z`;

// One expected list, two files: the diagnostic must classify exactly as finalization does.
assert.deepEqual([...EXPECTED_STATUSES], [...DEFAULT_ROSTER_STATUSES], 'the pure list equals the application roster statuses');

function plant(member, { created, changes = [] }) {
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(member.id);
  db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(created.at, member.id);
  const insert = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
  insert.run(member.id, null, created.status, 'planted', created.at);
  let current = created.status;
  for (const change of changes) { insert.run(member.id, current, change.status, 'planted', change.at); current = change.status; }
  db.prepare('UPDATE members SET status = ? WHERE id = ?').run(current, member.id);
}
const old = atNoon(addDays(SERVICE, -400));
const mk = (name) => createMember({ first_name: name, last_name: 'Diag' }, { status: 'active' });

// Coherent, exact history.
const good = mk('Good'); plant(good, { created: { at: old, status: 'active' } });
const changed = mk('Changed'); plant(changed, { created: { at: old, status: 'active' }, changes: [{ at: atNoon(addDays(GO_LIVE, 2)), status: 'inactive' }] });
// No history at all (a legacy member): inferred, not ambiguous.
const legacy = mk('Legacy'); db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(legacy.id);
db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(old, legacy.id);
// Ambiguous: created after the proposed Go-Live Friday with no earlier evidence.
const lateCreated = mk('LateCreated'); plant(lateCreated, { created: { at: atNoon(addDays(GO_LIVE, 3)), status: 'active' } });
// Ambiguous: status changed with no history entry (history does not reach the current status).
const contradictory = mk('Contradictory'); plant(contradictory, { created: { at: old, status: 'active' } });
db.prepare("UPDATE members SET status = 'inactive' WHERE id = ?").run(contradictory.id);

/** A single-file copy (no WAL), like a restored backup. */
function copyOfDatabase(name) {
  const dir = path.join(env.root, name);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'restored.sqlite');
  db.exec(`VACUUM INTO '${file.replaceAll("'", "''")}'`);
  return file;
}
const run = (...args) => spawnSync(process.execPath, [tool, ...args], { encoding: 'utf8' });
const copy = copyOfDatabase('copy-a');

// --- usage, help and refusals ------------------------------------------------
{
  const help = run('--help');
  assert.equal(help.status, 0);
  assert.match(help.stdout, /READ-ONLY/);
  assert.match(help.stdout, /no default path/i);
  assert.match(help.stdout, /--go-live/);
  assert.equal(run().status, 2, 'no path: a usage error, and no default database is ever used');
  assert.match(run().stderr, /path is required/);
  assert.equal(run(copy, '--nonsense').status, 2);
  assert.equal(run(copy, copy).status, 2, 'only one database');
  assert.equal(run(copy, '--go-live').status, 2);
  assert.equal(run(copy, '--go-live', '2026-13-45').status, 2, 'a real date is required');
  const missing = path.join(env.root, 'nothing-here.sqlite');
  assert.equal(run(missing).status, 1);
  assert.ok(!fs.existsSync(missing), 'it never creates a database');

  const productionLike = path.join(env.root, 'cciq-production', 'data');
  fs.mkdirSync(productionLike, { recursive: true });
  const inside = path.join(productionLike, 'cciq.sqlite');
  fs.copyFileSync(copy, inside);
  const refused = run(inside);
  assert.equal(refused.status, 1);
  assert.match(refused.stderr, /cciq-production/, 'a path inside a production folder is refused outright');
  assert.ok(!fs.existsSync(`${inside}-wal`) && !fs.existsSync(`${inside}-shm`));

  const inUse = path.join(env.root, 'in-use.sqlite');
  fs.copyFileSync(copy, inUse);
  fs.writeFileSync(`${inUse}-wal`, Buffer.from('not empty'));
  const wal = run(inUse);
  assert.equal(wal.status, 1);
  assert.match(wal.stderr, /in-use database/);

  const notCciq = path.join(env.root, 'other.sqlite');
  const other = new Database(notCciq); other.exec('CREATE TABLE unrelated (id INTEGER)'); other.close();
  const wrong = run(notCciq);
  assert.equal(wrong.status, 1);
  assert.match(wrong.stderr, /does not look like a CCIQ database/);
  console.log('PASS (usage/refusals): help states READ-ONLY; no default path; bad usage exits 2; missing, production-folder, in-use and non-CCIQ files exit 1 and nothing is created');
}

// --- classification ---------------------------------------------------------
{
  const before = sha(copy);
  const listing = fs.readdirSync(path.dirname(copy)).sort();
  const text = run(copy, '--go-live', GO_LIVE);
  assert.equal(text.status, 3, `ambiguity exists: ${text.stdout}${text.stderr}`);
  assert.match(text.stdout, /READ-ONLY status-history diagnostic - nothing in the database was changed/);
  assert.match(text.stdout, /exact:\s+\d+/);
  assert.match(text.stdout, /inferred:\s+\d+/);
  assert.match(text.stdout, /ambiguous:\s+[1-9]\d*/);
  assert.match(text.stdout, /history contradicts itself\/current:\s+1/);
  assert.match(text.stdout, /no history at all:\s+1/);
  assert.equal(sha(copy), before, 'the database file is byte-for-byte unchanged');
  assert.deepEqual(fs.readdirSync(path.dirname(copy)).sort(), listing, 'no -wal, -shm or any other file was created');

  const json = JSON.parse(run(copy, '--go-live', GO_LIVE, '--json').stdout);
  assert.equal(json.readOnly, true);
  assert.equal(json.exitCode, 3);
  assert.ok(json.migrationLevel, 'the migration level is reported');
  const ids = new Set(json.analysis.ambiguousMembers.map((m) => m.memberId));
  assert.ok(ids.has(lateCreated.id), 'created after the Go-Live Friday -> ambiguous');
  assert.ok(ids.has(contradictory.id), 'a status change with no history entry -> ambiguous');
  assert.ok(!ids.has(good.id) && !ids.has(changed.id) && !ids.has(legacy.id), 'coherent, exact and inferred members are not listed as ambiguous');
  const late = json.analysis.ambiguousMembers.find((m) => m.memberId === lateCreated.id);
  assert.deepEqual(late.basis, ['created_after_service']);
  assert.equal(late.firstAmbiguousFriday, GO_LIVE);
  const contra = json.analysis.ambiguousMembers.find((m) => m.memberId === contradictory.id);
  assert.deepEqual(contra.basis, ['history_inconsistent']);
  assert.equal(json.history.contradictory.length, 1);
  assert.ok(json.analysis.classifications.exact > 0 && json.analysis.classifications.inferred > 0);
  assert.equal(json.analysis.fridays, 3, 'GO_LIVE, +7 and the current Friday');
  const everything = JSON.stringify(json) + text.stdout;
  assert.ok(!/Diag|first_name|Contradictory|LateCreated/.test(everything), 'only member IDs and codes are shown - no names');

  // The diagnostic classifies exactly as finalization would.
  const friday = GO_LIVE;
  const app = tracking.resolveExpectedRoster(friday);
  const firstFridayAmbiguous = json.analysis.ambiguousMembers.filter((m) => m.firstAmbiguousFriday <= friday).map((m) => m.memberId).sort();
  assert.deepEqual(app.ambiguous.map((a) => a.memberId).sort(), firstFridayAmbiguous, 'same ambiguous members as the application computes for that Friday');
  console.log('PASS (classification): exact / inferred / ambiguous counts, the members and reasons to fix, no names, exit 3, read-only byte-for-byte, and identical to the application\'s own roster logic');
}

// --- a clean copy passes ----------------------------------------------------
{
  for (const member of [lateCreated, contradictory]) {
    plant(member, { created: { at: old, status: 'active' } });
  }
  const clean = copyOfDatabase('copy-b');
  const before = sha(clean);
  const result = run(clean, '--go-live', GO_LIVE);
  assert.equal(result.status, 0, `${result.stdout}${result.stderr}`);
  assert.match(result.stdout, /ambiguous:\s+0/);
  assert.match(result.stdout, /nothing needs attention/);
  assert.equal(JSON.parse(run(clean, '--go-live', GO_LIVE, '--json').stdout).analysis.membersWithAmbiguity, 0);
  assert.equal(sha(clean), before);
  // Without --go-live only history coherence is reported (and it still passes).
  assert.equal(run(clean).status, 0);
  assert.match(run(clean).stdout, /Tip: add --go-live/);
  console.log('PASS (clean copy) a coherent database exits 0, with and without --go-live');
}

// --- data quality of the raw history, human-review section, catalogue ------------------------------
{
  const { MEMBER_STATUSES } = await import('../services/members.js');
  // (The tool is a CLI script: read its source rather than importing - importing would run it.)
  const toolSource = fs.readFileSync(tool, 'utf8');
  const listed = toolSource.match(/MEMBER_STATUS_CATALOGUE = \[([\s\S]*?)\];/)[1].match(/'([a-z_]+)'/g).map((s) => s.slice(1, -1));
  assert.deepEqual([...listed].sort(), [...MEMBER_STATUSES].sort(), "the tool's status catalogue is exactly the application's MEMBER_STATUSES");

  // A clean baseline first.
  for (const member of [good, changed, legacy, lateCreated, contradictory]) plant(member, { created: { at: old, status: 'active' } });
  db.prepare("UPDATE members SET status = 'active'").run();
  const clean = copyOfDatabase('quality-clean');
  const cleanJson = JSON.parse(run(clean, '--json').stdout);
  assert.equal(cleanJson.history.chainBreaks, 0);
  for (const key of ['statusesOutsideCatalogue', 'invalidTimestamps', 'noopTransitions', 'duplicateTransitions', 'historyPredatesRecord', 'futureDated']) {
    assert.equal(cleanJson.dataQuality[key], 0, `clean: ${key}`);
  }

  // Now plant each kind of problem in a copy (never the source).
  const ins = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
  ins.run(good.id, 'active', 'active', 'noop', atNoon(addDays(SERVICE, -30)));                   // no-op transition
  ins.run(good.id, 'active', 'active', 'noop', atNoon(addDays(SERVICE, -30)));                   // duplicate of that
  ins.run(changed.id, 'active', 'retired_status', 'odd', atNoon(addDays(SERVICE, -20)));         // outside the catalogue
  ins.run(legacy.id, null, 'active', 'bad time', 'not a date');                                   // invalid timestamp
  ins.run(lateCreated.id, null, 'active', 'early', atNoon(addDays(SERVICE, -900)));               // dated long before the record was created
  ins.run(contradictory.id, 'active', 'inactive', 'future', `${addDays(today(), 40)}T09:00:00.000Z`); // future-dated
  const dirty = copyOfDatabase('quality-dirty');
  const before = sha(dirty);
  const result = run(dirty, '--go-live', GO_LIVE, '--through', SERVICE, '--json');
  assert.equal(result.status, 3, result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(sha(dirty), before, 'still read-only byte for byte');
  assert.equal(report.dataQuality.noopTransitions >= 2, true, 'no-op transitions are found');
  assert.equal(report.dataQuality.duplicateTransitions, 1, 'an identical repeated transition is found');
  assert.ok(report.dataQuality.statusesOutsideCatalogue >= 1, 'an unsupported status is found');
  assert.equal(report.dataQuality.invalidTimestamps, 1, 'a timestamp that is not a date is found');
  assert.ok(report.dataQuality.historyPredatesRecord >= 1, 'history older than the record is found');
  assert.equal(report.dataQuality.futureDated, 1, 'a future-dated entry is found');
  assert.ok(report.history.chainBreaks + report.history.tailMismatches >= 1);
  assert.equal(report.analysis.basisTotals !== undefined, true, 'the analysis breaks certainty down by basis');
  assert.equal(report.humanReview, null, 'names and sequences appear only when asked for');
  assert.doesNotMatch(result.stdout, /Diag/, 'the default output carries no member names');

  const review = JSON.parse(run(dirty, '--go-live', GO_LIVE, '--through', SERVICE, '--human-review', '--json').stdout);
  assert.ok(review.humanReview.length >= 1);
  const row = review.humanReview.find((h) => h.memberId === contradictory.id);
  assert.ok(row, 'a contradictory member is listed for a person to look at');
  assert.equal(row.name, 'Contradictory Diag');
  assert.ok(row.statusSequence.length >= 1 && row.reasons.length >= 1 && row.suggestedReview.length >= 1);
  assert.ok(!('suggestedStatus' in row) && !('correctStatus' in row), 'it never proposes what the status should have been');
  const text = run(dirty, '--go-live', GO_LIVE, '--through', SERVICE, '--human-review');
  assert.match(text.stdout, /Human review \(/);
  assert.match(text.stdout, /nothing here is a proposed correction/);
  assert.equal(sha(dirty), before, 'the human-review run is read-only too');
  console.log('PASS (data quality / human review): unsupported statuses, bad timestamps, no-op and duplicate transitions, history before the record and future-dated history are reported; names only with --human-review; no correction is ever proposed; catalogue equals MEMBER_STATUSES');
}

db.close();
env.cleanup();
console.log('ALL PASS');
