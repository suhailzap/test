import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Migration 0032 ("Received by" on a Faith Promise payment): additive, nullable, nothing backfilled.
 *   - a fresh database has the column (nullable text); the service refuses a NEW payment without it and records it when given;
 *   - a database taken back to 0031 with historical payments upgrades with every payment untouched, its Received by NULL, the commitment totals and statuses unchanged,
 *     and re-running changes nothing;
 *   - a historical payment can still be corrected (the application keeps NULL valid), and removed;
 *   - the schema check calls the 0031 database behind and the migrated one compatible.
 */

createIsolatedTestEnv('cciq-migration-0032-');
const { migrate, EXPECTED_MIGRATIONS, checkSchemaCompatibility } = await import('../db/migrate.js');
migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const faith = await import('../services/faith-promise.js');
const ecaq = await import('../services/ecaq.js');
const members = await import('../services/members.js');
const { default: db } = await import('../db/index.js');
const columns = () => db.prepare('PRAGMA table_info(ecaq_faith_promise_payments)').all();

{ // 1. fresh
  assert.ok(EXPECTED_MIGRATIONS.includes('0032_faith_promise_received_by'));
  const col = columns().find((c) => c.name === 'received_by');
  assert.ok(col, 'the column exists'); assert.equal(col.type, 'TEXT'); assert.equal(col.notnull, 0, 'nullable, so history stays valid'); assert.equal(col.dflt_value, null);
  console.log('PASS (1) a fresh database has payments.received_by: nullable text, no default');
}

await users.createUser({ username: 'mig32', email: 'mig32@fixture.invalid', password: 'Mig-Fixture-Passw0rd!x', displayName: 'Mig', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'mig32'").get().id;
const year = Number(new Date().toISOString().slice(0, 4));
const campaign = ecaq.createCampaign({ name: 'Mig promise', year, type: 'faith_promise', status: 'active', start_date: `${year}-01-01`, end_date: `${year}-12-31` });
const member = members.createMember({ first_name: 'Mig', last_name: 'Member' }, { status: 'active' });
const commitment = faith.submitCommitment(campaign.id, { member_id: member.id, name: 'Mig Member', amount: 10, frequency: 'monthly' }, { userId: adminId }).commitment;

{ // 2. new payments need it; the service stores it
  assert.equal(faith.addPayment(commitment.id, { amount: 10, paid_on: '2026-01-10' }, { userId: adminId }).reason, 'received_by_required');
  assert.equal(faith.addPayment(commitment.id, { amount: 10, paid_on: '2026-01-10', received_by: '   ' }, { userId: adminId }).reason, 'received_by_required');
  const ok = faith.addPayment(commitment.id, { amount: 10, paid_on: '2026-01-10', received_by: 'Bro. Receiver' }, { userId: adminId });
  assert.ok(ok.ok); assert.equal(ok.payment.received_by, 'Bro. Receiver'); assert.equal(ok.payment.created_by, adminId, 'recorded by is the administrator, a separate fact');
  db.prepare('DELETE FROM ecaq_faith_promise_payments').run(); faith.recalculateCommitment(commitment.id);
  console.log('PASS (2) a new payment needs Received by (blank and spaces refused) and the service keeps it apart from who recorded it');
}

function rewindTo0031() {
  db.pragma('foreign_keys = OFF');
  db.exec("ALTER TABLE ecaq_faith_promise_payments DROP COLUMN received_by; DELETE FROM schema_migrations WHERE version = '0032_faith_promise_received_by';");
  db.pragma('foreign_keys = ON');
}
const payments = () => JSON.stringify(db.prepare('SELECT id, commitment_id, amount, paid_on, method, reference, notes, created_at, created_by, updated_at, updated_by FROM ecaq_faith_promise_payments ORDER BY id').all());
const commitments = () => JSON.stringify(db.prepare('SELECT * FROM ecaq_faith_promise_commitments ORDER BY id').all());

{ // 3. a 0031 database with historical payments
  rewindTo0031();
  assert.equal(columns().some((c) => c.name === 'received_by'), false, 'sanity: the copy is at 0031');
  assert.equal(checkSchemaCompatibility(db).reason, 'behind', 'the 0031 database is reported as behind');
  assert.deepEqual(checkSchemaCompatibility(db).missing, ['0032_faith_promise_received_by']);
  const raw = db.prepare("INSERT INTO ecaq_faith_promise_payments (commitment_id, amount, paid_on, method, reference, notes, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  raw.run(commitment.id, 10, '2026-01-10', 'cash', 'R-1', null, '2026-01-10T09:00:00.000Z', adminId);
  raw.run(commitment.id, 25.5, '2026-02-12', 'bank_transfer', null, 'note', '2026-02-12T09:00:00.000Z', adminId);
  faith.recalculateCommitment(commitment.id);
  const pBefore = payments(); const cBefore = commitments();
  migrate(); migrate();
  assert.equal(payments(), pBefore, 'every historical payment is exactly as it was'); assert.equal(commitments(), cBefore, 'and so are the commitment, its received total and its status');
  assert.deepEqual(db.prepare('SELECT received_by FROM ecaq_faith_promise_payments ORDER BY id').all().map((r) => r.received_by), [null, null], 'Received by is NULL for history: nothing invented');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get('0032_faith_promise_received_by').n, 1, 'recorded once');
  assert.equal(checkSchemaCompatibility(db).ok, true);
  console.log('PASS (3) a 0031 database with historical payments upgrades with every payment, total and status untouched, Received by NULL, and a second run changes nothing');
}

{ // 4. history stays usable
  const first = db.prepare('SELECT * FROM ecaq_faith_promise_payments ORDER BY id').get();
  const fixed = faith.updatePayment(first.id, { amount: 12, paid_on: first.paid_on, method: first.method, reference: first.reference }, { userId: adminId });
  assert.ok(fixed.ok, 'a historical payment can be corrected without inventing a receiver'); assert.equal(fixed.payment.received_by, null);
  const filled = faith.updatePayment(first.id, { received_by: 'Treasurer' }, { userId: adminId }); assert.ok(filled.ok); assert.equal(filled.payment.received_by, 'Treasurer');
  assert.equal(faith.updatePayment(first.id, { received_by: '' }, { userId: adminId }).reason, 'received_by_required', 'once recorded it cannot be erased');
  const removed = faith.deletePayment(first.id); assert.ok(removed); assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments').get().n, 1);
  console.log('PASS (4) a historical payment can be corrected (still blank, or filled once, never erased) and removed');
}
console.log('PASS migration-0032');
