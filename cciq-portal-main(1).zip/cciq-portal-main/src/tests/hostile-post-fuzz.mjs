import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * Every state-changing form route is sent hostile values in every field it might read: empty, 20,000 characters, non-Latin text, NUL,
 * negative and absurd numbers, NaN, markup, SQL, impossible dates, and the same field twice (a list where text is expected). None may
 * be a server error, and the data that results must still satisfy the integrity rules. Complements the forged-id checks in
 * error-handling.mjs and the validation matrix in first-timer-integrity.mjs. (Sign-out, password, backup, upload and delete routes
 * are covered by their own suites.)
 */

const f = await buildPortalFixture('cciq-fuzz-');
// A new member's code comes from the highest number in use, so an older, higher code (an import, a legacy record) can never be handed out twice.
{
  const { db, mods } = f;
  db.prepare("UPDATE members SET member_code = 'CCIQ-9001' WHERE id = (SELECT MIN(id) FROM members)").run();
  const fresh = [];
  for (let i = 0; i < 4; i += 1) fresh.push(mods.members.createMember({ first_name: `Code${i}`, last_name: 'Test' }, { status: 'active' }).member_code);
  assert.equal(new Set(fresh).size, 4, 'four new members get four different codes');
  const high = mods.members.createMember({ first_name: 'High', last_name: 'Code' }, { status: 'active' });
  db.prepare("UPDATE members SET member_code = 'CCIQ-0101' WHERE id = ?").run(high.id);
  const low = mods.members.createMember({ first_name: 'Low', last_name: 'Code' }, { status: 'active' });
  db.prepare("UPDATE members SET member_code = 'CCIQ-0100' WHERE id = ?").run(low.id); // the newest row now carries 0100 while 0101 exists
  const after = mods.members.createMember({ first_name: 'After', last_name: 'Both' }, { status: 'active' });
  assert.equal(after.member_code, 'CCIQ-0102', 'the next code skips one that is already taken (it used to propose 0101 and fail)');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM (SELECT member_code FROM members GROUP BY member_code HAVING COUNT(*) > 1)').get().n, 0, 'no member code is ever issued twice');
}
const portal = await startPortal();
const admin = await signIn(portal.base, f.users.superAdmin.email, f.PASSWORD);
const { ids } = f;
const values = {
  empty: '', long: 'x'.repeat(20000), unicode: 'Ünï 😀 أحمد 中文', nul: 'a\u0000b', neg: '-1', big: '99999999999999999999', float: '1.5', nan: 'NaN', html: '<b>"x"</b>', sql: "'; DROP TABLE members; --", date: '2026-02-30', arr: ['a', 'b']
};
const fieldNames = ['first_name', 'last_name', 'name', 'title', 'body', 'description', 'notes', 'reason', 'phone', 'email', 'display_name', 'username', 'status', 'state', 'audience', 'priority', 'scope', 'role', 'roles', 'password', 'amount', 'paid_on', 'date', 'visit_date', 'first_visit_date', 'meeting_date', 'start_date', 'end_date', 'year', 'month', 'member_id', 'cell_group_id', 'campaign', 'key', 'value', 'label', 'frequency', 'method', 'confirm', 'text', 'caption', 'sort_order', 'age_group', 'gender', 'marital_status', 'date_of_birth', 'address', 'company', 'occupation', 'meets', 'contact', 'note', 'service_type', 'service_date', 'time', 'start_time', 'location', 'category_id', 'tags', 'version', 'to', 'from'];
const skip = /logout|login|\/password|\/account\/password|backups|restore|import|photo|media|background|upload|\/documents\/?$|replace|delete/;
const posts = catalogue().filter((r) => r.method === 'POST' && !skip.test(r.path));
const sub = (p) => p.replace(/:[A-Za-z]+\((?:[^()]|\([^()]*\))*\)/g, (m) => (m.startsWith(':memberId') ? String(ids.member.a3) : m.startsWith(':token') ? 'a'.repeat(32) : m.startsWith(':id') ? '1' : '1'));
const found = new Map();
let n = 0;
for (const r of posts) {
  const url = sub(r.path);
  if (url.includes(':')) continue;
  for (const [label, v] of Object.entries(values)) {
    const token = await admin.csrf('/');
    const body = new URLSearchParams(); body.set('_csrf', token);
    for (const name of fieldNames) { if (Array.isArray(v)) v.forEach((x) => body.append(name, x)); else body.set(name, v); }
    const res = await fetch(`${portal.base}${url}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: admin.cookie }, body });
    await res.arrayBuffer();
    n += 1;
    if (res.status >= 500) found.set(`${res.status} POST ${r.path}`, [...(found.get(`${res.status} POST ${r.path}`) || []), label]);
  }
}
assert.deepEqual([...found].map(([k, v]) => `${k} <- ${v.join(',')}`), [], 'no form route answers a hostile value with a server error');
assert.ok(n >= 900, `enough hostile posts were sent (${n})`);
assert.deepEqual(checkInvariants(f.db).findings.filter((x) => x.severity === 'error'), [], 'and the data left behind still satisfies every integrity rule');
console.log(`PASS (hostile posts) ${n} hostile form submissions across ${posts.length} routes: no server error, data still consistent`);
await portal.stop(); f.db.close(); f.env.cleanup();
console.log('ALL PASS');
