import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What a person sees when something goes wrong: always a complete, styled page in plain words (or a small JSON object when
 * the caller asked for JSON) - never a bare fragment, a stack trace, a file path, SQL or an echo of hostile input - and the
 * server keeps running. A failure on the server side carries a reference code that also appears in the server log.
 */

const f = await buildPortalFixture('cciq-errors-');
const { db, users } = f;
const portal = await startPortal();
let log = '';
portal.server.stdout?.on('data', (d) => { log += d; });
portal.server.stderr?.on('data', (d) => { log += d; });

const LEAKS = [/node_modules/i, /\bat (?:Object|Function|async|Module|process)\b/, /[A-Z]:\\[\w\\]+/, /\/(?:home|usr|var)\/\w+/, /SQLITE_|better-sqlite3|SqliteError|stack trace/i, /\.js:\d+:\d+/];
function noLeak(body, what) {
  for (const re of LEAKS) assert.doesNotMatch(body, re, `${what}: the page leaks internals (${re})`);
}
function isFullPage(body, what) {
  assert.match(body, /^\s*<!doctype html>/i, `${what}: a complete HTML document, not a fragment`);
  assert.match(body, /<link[^>]+cciq\.css/, `${what}: styled`);
  assert.match(body, /<title>[^<]+<\/title>/, `${what}: has a title`);
}

try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const anon = async (method, path, init = {}) => fetch(portal.base + path, { method, redirect: 'manual', ...init });
  const signedIn = async (method, path, init = {}) => fetch(portal.base + path, { method, redirect: 'manual', ...init, headers: { cookie: admin.cookie, ...(init.headers || {}) } });

  // ---- not found, in every spelling -------------------------------------------------------------------------------------------------
  for (const path of ['/nope', '/members/abc', '/members/99999999', '/members/0', '/members/-1', '/members%00', '/%', '/%E0%A4%A', '/..%2f..%2fpackage.json', '/css/..%2f..%2fpackage.json', '//', '/favicon.ico', '/robots.txt']) {
    const res = await signedIn('GET', path);
    const body = await res.text();
    assert.ok(res.status === 404 || res.status === 400, `${path} is a 404/400, not ${res.status}`);
    isFullPage(body, path); noLeak(body, path);
  }
  const hostileRes = await signedIn('GET', '/' + encodeURIComponent('<script>alert(1)</script>'));
  const hostileBody = await hostileRes.text();
  assert.doesNotMatch(hostileBody, /<script>alert\(1\)<\/script>/, 'the requested path is never echoed unescaped');
  const signedOutNotFound = await anon('GET', '/nope');
  assert.equal(signedOutNotFound.status, 404, 'a signed-out visitor gets the same plain 404 (no redirect loop, no crash)');
  isFullPage(await signedOutNotFound.text(), 'signed-out 404');
  console.log('PASS (404) unknown, malformed, traversal and hostile paths give a complete, styled, leak-free page; signed out too');

  // ---- forbidden / expired form ----------------------------------------------------------------------------------------------------
  for (const [who, fetcher] of [['signed in', signedIn], ['signed out', anon]]) {
    const res = await fetcher('POST', '/members', { headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'first_name=X' });
    const body = await res.text();
    assert.equal(res.status, 403, `a POST without a token is refused (${who})`);
    isFullPage(body, `CSRF refusal (${who})`); noLeak(body, `CSRF refusal (${who})`);
    assert.match(body, /session expired|Sign in again/i, 'and says why in plain words');
  }
  const memberSession = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const forbidden = await memberSession.get('/admin/users');
  const forbiddenBody = await forbidden.text();
  assert.equal(forbidden.status, 403);
  isFullPage(forbiddenBody, 'role refusal'); noLeak(forbiddenBody, 'role refusal');
  console.log('PASS (403) a missing token and a missing permission each give a complete page in plain words');

  // ---- asked for JSON ---------------------------------------------------------------------------------------------------------------
  const json = await signedIn('GET', '/nope', { headers: { accept: 'application/json' } });
  assert.match(json.headers.get('content-type'), /json/);
  const payload = await json.json();
  assert.ok(payload.error && !('stack' in payload), 'a JSON caller gets { error } and no stack');
  console.log('PASS (json) a caller that asks for JSON gets a small JSON error without internals');

  // ---- hostile request bodies and headers -------------------------------------------------------------------------------------------
  const bad = [
    ['invalid JSON', 'POST', '/members', { 'content-type': 'application/json' }, '{bad'],
    ['oversized form', 'POST', '/members', { 'content-type': 'application/x-www-form-urlencoded' }, 'a=' + 'x'.repeat(400000)],
    ['oversized JSON', 'POST', '/members', { 'content-type': 'application/json' }, JSON.stringify({ a: 'x'.repeat(400000) })],
    ['broken multipart', 'POST', '/my/profile/photo', { 'content-type': 'multipart/form-data; boundary=zzz' }, '--zzz\r\nbroken'],
    ['unknown content type', 'POST', '/members', { 'content-type': 'application/x-weird' }, 'hello']
  ];
  for (const [what, method, path, headers, body] of bad) {
    const res = await signedIn(method, path, { headers, body });
    const text = await res.text();
    assert.ok(res.status >= 300 && res.status < 500, `${what}: a redirect or 4xx answer, not ${res.status}`);
    noLeak(text, what);
  }
  const longUrl = await signedIn('GET', '/' + 'a'.repeat(20000));
  assert.ok([414, 431, 404].includes(longUrl.status), `an absurdly long URL is refused (${longUrl.status})`);
  for (const q of ['/members?q=%E0%A4%A', '/members?q[]=1&q[]=2', '/members?' + 'a=1&'.repeat(2000), '/search?q=%00', '/members?page=%FF']) {
    const res = await signedIn('GET', q);
    await res.text();
    assert.ok(res.status < 500, `${q.slice(0, 40)} is not a server error (${res.status})`);
  }
  const still = await anon('GET', '/healthz');
  assert.equal(still.status, 200, 'the server is still up after all of that');
  console.log('PASS (hostile input) bad JSON, oversized bodies, broken multipart, odd content types, long URLs and malformed queries are refused cleanly and the server keeps running');

  // ---- forged or stale ids: a bad request, never a server fault, and nothing half-written --------------------------------------------------
  const ghostForms = [
    ['/members', 'members', { first_name: 'Ghost', last_name: 'Ref', status: 'active', spouse_member_id: '99999999', guardian_member_id: '99999999', father_member_id: '99999999', mother_member_id: '99999999', cell_group_id: '99999999' }],
    ['/cell-groups', 'cell_groups', { name: 'Ghost Group', status: 'active', leader_member_id: '99999999', assistant_member_id: '99999999' }],
    ['/ministries', 'ministries', { name: 'Ghost Ministry', leader_member_id: '99999999' }],
    ['/family-groups', 'family_groups', { name: 'Ghost Family', first_member_id: '99999999' }],
    ['/visitors', 'visitors', { first_name: 'Ghost', last_name: 'Ref', first_visit_date: '2026-01-01', invited_by_member_id: '99999999', duplicate_override: '1' }]
  ];
  const ghostToken = await admin.csrf('/');
  for (const [url, table, fields] of ghostForms) {
    const before = db.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n;
    const res = await admin.post(url, fields, { csrf: ghostToken });
    const body = await res.text();
    assert.ok(res.status >= 400 && res.status < 500, `${url}: a record that does not exist is a 4xx, not ${res.status}`);
    isFullPage(body, `${url} with a forged id`); noLeak(body, `${url} with a forged id`);
    assert.equal(db.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n, before, `${url}: nothing was saved`);
    if (table === 'members') assert.equal(db.prepare("SELECT COUNT(*) n FROM member_status_history WHERE member_id NOT IN (SELECT id FROM members)").get().n, 0, 'and no orphan history row');
  }
  console.log('PASS (forged ids) five create forms given ids that do not exist answer 4xx with the normal page and save nothing');

  // ---- a real server-side failure ---------------------------------------------------------------------------------------------------
  db.exec("CREATE TRIGGER inject_500 BEFORE INSERT ON announcements BEGIN SELECT RAISE(ABORT, 'secret-sql-detail-xyz'); END");
  const token = await admin.csrf('/announcements/new');
  const boom = await admin.post('/announcements?note=PIIQUERYMARKER', { title: 'Will fail', body: 'x', audience: 'all', priority: 'normal', status: 'published' }, { csrf: token });
  const boomBody = await boom.text();
  db.exec('DROP TRIGGER inject_500');
  assert.equal(boom.status, 500);
  isFullPage(boomBody, '500'); noLeak(boomBody, '500');
  assert.doesNotMatch(boomBody, /secret-sql-detail-xyz/, 'the database message is not shown to the person');
  const reference = (boomBody.match(/Reference\s+([0-9a-f]{8})/) || [])[1];
  assert.ok(reference, 'the page shows a reference code');
  await new Promise((r) => setTimeout(r, 300));
  assert.ok(log.includes(`[error ${reference}]`), 'and the same code is in the server log, where the detail is');
  assert.ok(!log.includes('PIIQUERYMARKER'), 'the log records the path of the failing request, never its query string');
  assert.match(log, /secret-sql-detail-xyz/, 'with the real message for whoever investigates');
  assert.equal((await anon('GET', '/healthz')).status, 200, 'the server carries on');
  console.log('PASS (500) a database failure gives a plain page with a reference code; the detail is only in the server log; the server keeps running');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
