import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * Colour contrast of the design tokens, computed from the stylesheet itself so a future colour change cannot quietly drop below
 * WCAG 2.x AA: 4.5:1 for normal text, 3:1 for a keyboard focus indicator. Reads the :root tokens; nothing is hard-coded except
 * the pairs worth checking (which colour is used on which surface).
 */

const css = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public', 'css', 'cciq.css'), 'utf8');
const root = css.slice(css.indexOf(':root {'), css.indexOf('}', css.indexOf(':root {')));
const token = (name) => { const m = root.match(new RegExp(`--${name}:\\s*(#[0-9a-fA-F]{6})`)); assert.ok(m, `token --${name} is a 6-digit hex in :root`); return m[1].toLowerCase(); };

const rgb = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
const lin = (c) => { const s = c / 255; return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4; };
const luminance = (hex) => { const [r, g, b] = rgb(hex).map(lin); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const ratio = (a, b) => { const x = luminance(a); const y = luminance(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
const blend = (fg, bg, alpha) => `#${rgb(fg).map((c, i) => Math.round(c * alpha + rgb(bg)[i] * (1 - alpha)).toString(16).padStart(2, '0')).join('')}`;

const T = Object.fromEntries(['navy-900', 'navy-800', 'navy-700', 'navy-500', 'sky-400', 'sky-100', 'red-600', 'red-100', 'gold-100', 'green-600', 'green-100', 'paper', 'surface', 'surface-sunk', 'surface-muted', 'ink', 'ink-soft', 'muted', 'line-strong'].map((n) => [n, token(n)]));

const text = [
  ['body text on cards', T.ink, T.surface], ['body text on the page', T.ink, T.paper], ['soft text', T['ink-soft'], T.surface],
  ['secondary text on cards', T.muted, T.surface], ['secondary text on the page', T.muted, T.paper], ['secondary text on sunk panels', T.muted, T['surface-sunk']], ['secondary text on muted panels', T.muted, T['surface-muted']], ['secondary text on a status pill', T.muted, '#eef1f5'], ['secondary text on a sky pill', T.muted, T['sky-100']],
  ['links', T['navy-700'], T.surface], ['links on the page', T['navy-700'], T.paper], ['link hover', T['navy-500'], T.surface],
  ['active pill', T['green-600'], T['green-100']], ['pending pill', T['navy-700'], T['sky-100']], ['absent pill', T['red-600'], T['red-100']], ['inactive pill', '#8a6210', T['gold-100']], ['Bonafide pill', '#3b2a06', '#f4ebcf'],
  ['white on the navigation', '#ffffff', T['navy-900']], ['white on dark buttons', '#ffffff', T['navy-700']], ['white on danger buttons', '#ffffff', T['red-600']], ['white on success', '#ffffff', T['green-600']],
  ['navigation footer links', blend('#ffffff', T['navy-900'], 0.72), T['navy-900']], ['error text', T['red-600'], T.surface]
];
const failures = [];
for (const [what, fg, bg] of text) {
  const r = ratio(fg, bg);
  if (r < 4.5) failures.push(`${what}: ${r.toFixed(2)}:1 (${fg} on ${bg})`);
}
assert.deepEqual(failures, [], 'every text colour pair reaches 4.5:1');

const focus = [['focus ring on cards', T['navy-500'], T.surface], ['focus ring on the page', T['navy-500'], T.paper], ['focus ring on the navigation', T['sky-400'], T['navy-900']], ['focus ring on the header', T['sky-400'], T['navy-900']]];
for (const [what, fg, bg] of focus) assert.ok(ratio(fg, bg) >= 3, `${what}: ${ratio(fg, bg).toFixed(2)}:1 reaches 3:1`);
assert.match(css, /:focus-visible\s*\{[^}]*outline:\s*3px solid var\(--navy-500\)/, 'the default focus ring uses the dark blue');
assert.match(css, /\.sidenav :focus-visible[^{]*\{[^}]*outline-color:\s*var\(--sky-400\)/, 'and the light blue only on the dark navigation');

for (const [what, bg] of [['on cards', T.surface], ['on the page', T.paper]]) {
  assert.ok(ratio(token('control-border'), bg) >= 3, `the edge of a text input, select or textarea ${what} reaches 3:1 (WCAG 1.4.11): ${ratio(token('control-border'), bg).toFixed(2)}:1`);
}
assert.match(css, /input\[type="search"\][^{]*\{[^}]*border: 1px solid var\(--control-border\)/, 'text controls use the 3:1 border token');

console.log(`PASS (contrast) ${text.length} text pairs reach 4.5:1 and the focus ring reaches 3:1 on every surface`);
console.log(`INFO text inputs, selects and textareas now use --control-border (${ratio(token('control-border'), T.surface).toFixed(2)}:1 on white); decorative card and table borders (--line-strong, ${ratio(T['line-strong'], T.surface).toFixed(2)}:1) are unchanged.`);
console.log('ALL PASS');
