import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The Attendance Tracking Start Date, managed from System Settings -> Attendance by a Super Admin (the same mechanism UAT and production use).
 *
 * A hand-checkable world: ten past Fridays W(-10)..W(-1), tracking starts at W(-10).
 *   W(-10) W(-9) W(-8) W(-5) W(-4) W(-3) W(-2)   finalized (7)       W(-6) "Attendance not taken"       W(-7) cancelled       W(-1) past, NOT finalized
 *   Alice present at every finalized service.  Bob absent at every finalized service (7 absences in a row at W(-10); fewer as the start moves later).
 *
 * Proved: blank start = nothing evaluated; only a Friday is accepted; pre-start Fridays are excluded and the start Friday itself is included; a finalized post-start Friday counts and an
 * unfinalized one never becomes an absence; moving the start (earlier or later) changes the derived figures WITHOUT touching one attendance row, finalization state or expected snapshot;
 * consecutive absence, Long Absence Review, Membership Review and the attendance report all follow the date; only a Super Admin can change it (crafted requests refused for everyone
 * else); every change is audited with old date, new date, actor and time; the readiness panel and the preview are derived from the real sessions.
 */

const f = await buildPortalFixture('cciq-tracking-control-');
const { db, ids, users, mods } = f;
const lifecycle = await import('../services/attendance-lifecycle.js');
const consumers = await import('../services/attendance-consumers.js');
const review = await import('../services/membership-review.js');
const tracking = await import('../services/attendance-tracking.js');
const { today, addDays, lastFridayOnOrBefore, isFriday } = mods.dates;
const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const atNoon = (d) => `${d}T09:00:00.000Z`;
const OLD = addDays(SERVICE, -400);
const setting = () => db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get()?.value ?? '';

for (const m of db.prepare('SELECT id, status FROM members').all()) { // long-standing members, so finalizing past Fridays is never ambiguous
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, m.status, 'planted', atNoon(OLD));
}
db.exec('DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions;');
mods.setSetting('attendance.excused_counts', false);
mods.setSetting('attendance.tracking_start_date', '');

// ---- 1. blank = tracking has not started: nothing is evaluated -----------------------------------------------------------------------------------------------------------
const alice = ids.member.a2; const bob = ids.member.a3;
const session = new Map();
for (let n = -10; n <= -1; n += 1) {
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
  session.set(n, db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)).id);
}
const mark = (n, memberId, status) => mods.attendance.recordAttendance(session.get(n), [{ memberId, status }], { userId: users.churchAdmin.id });
for (const n of [-10, -9, -8, -5, -4, -3, -2]) { mark(n, alice, 'present'); mark(n, bob, 'absent'); }
{
  const r = lifecycle.trackingReadiness();
  assert.deepEqual([r.configured, r.start, r.eligibleFinalized, r.latestFinalized], [false, null, 0, null], 'blank: not configured, nothing eligible');
  assert.equal(consumers.consecutiveMissedFridays(bob).streak, 0, 'blank: no absence run is derived');
  assert.equal(consumers.consecutiveMissedFridays(bob).endedBy, 'not_started');
  assert.equal(consumers.trackedFridayContexts().length, 0, 'blank: no tracked Fridays');
  assert.equal(consumers.longAbsenceReview().status, 'not_started', 'blank: Long Absence Review has not started');
  assert.equal(review.eligibleFridayWindow().status, 'tracking_not_started', 'blank: Membership Review has no eligible Fridays');
  assert.equal(consumers.followUpList().length, 0, 'blank: the follow-up list is empty');
  assert.equal(tracking.classifySession(db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(session.get(-2))).phase, 'not_started');
  console.log('PASS (blank) with no start date nothing is evaluated: no absence run, no follow-up, no Long Absence Review, no Membership Review window, every Friday "not started"');
}

// ---- 2. only a Friday ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
{
  for (const bad of ['', 'nonsense', '2026-02-30', addDays(W(-10), 1), addDays(W(-10), -1), addDays(W(-10), 3)]) {
    if (bad === '') continue;
    const reason = lifecycle.setTrackingStartDate(bad, { userId: users.superAdmin.id }).reason;
    assert.ok(['invalid_date', 'not_friday'].includes(reason), `"${bad}" refused (${reason})`);
    assert.equal(lifecycle.previewTrackingStart(bad).ok, false, `"${bad}" has no preview`);
  }
  assert.equal(lifecycle.setTrackingStartDate(addDays(W(-10), 1), { userId: users.superAdmin.id }).reason, 'not_friday');
  assert.equal(setting(), '', 'nothing was saved');
  assert.equal(isFriday(W(-10)), true);
  console.log('PASS (Friday only) a date that is not a real calendar date or not a Friday is refused and nothing is saved');
}

// ---- 3. set it (nothing finalized yet, so unlocked), finalize the services ----------------------------------------------------------------------------------------------
{
  const set = lifecycle.setTrackingStartDate(W(-10), { userId: users.superAdmin.id });
  assert.equal(set.ok, true); assert.equal(set.changed, true); assert.equal(setting(), W(-10));
  db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(session.get(-7));
  for (const n of [-10, -9, -8, -5, -4, -3, -2]) assert.equal(lifecycle.finalizeAttendance(session.get(n), { userId: null, confirmNoAttendance: true }).ok, true, `finalize W(${n})`);
  assert.equal(lifecycle.markAttendanceNotTaken(session.get(-6), { userId: null, note: 'Power cut' }).ok, true);
}
const world = () => {
  const rows = (sql) => crypto.createHash('sha256').update(JSON.stringify(db.prepare(sql).all())).digest('hex');
  return [rows('SELECT * FROM attendance_records ORDER BY id'), rows('SELECT * FROM attendance_sessions ORDER BY id'), rows('SELECT * FROM attendance_expected ORDER BY session_id, member_id')].join('|');
};
const baseline = world();
const figures = () => {
  const range = { from: W(-10), to: W(0) };
  const report = consumers.attendanceReport(range);
  const rowOf = (id) => report.rows.find((r) => r.member.id === id);
  return {
    bobRun: consumers.consecutiveMissedFridays(bob).streak,
    bobCounted: rowOf(bob).eligible, bobAbsent: rowOf(bob).absent, bobPending: rowOf(bob).not_recorded, aliceCounted: rowOf(alice).eligible,
    finalizedInReport: report.lifecycle.finalized,
    longAbsence: consumers.longAbsenceReview().status,
    membership: review.eligibleFridayWindow().status, membershipFridays: review.eligibleFridayWindow().window.map((c) => c.date),
    readiness: lifecycle.trackingReadiness()
  };
};

// ---- 4. the start date drives every derived figure ----------------------------------------------------------------------------------------------------------------------
const move = (start, why) => { const r = lifecycle.setTrackingStartDate(start, { userId: users.superAdmin.id, override: true, reason: why || `UAT window ${start}` }); assert.equal(r.ok, true, `moved to ${start}: ${r.reason}`); return r; };
{
  // Phase A: W(-1) is a past Friday nobody has finalized yet.
  const a = figures();
  assert.deepEqual([a.readiness.configured, a.readiness.eligibleFinalized, a.readiness.notTaken, a.readiness.awaitingFinalization, a.readiness.latestFinalized], [true, 7, 1, 1, W(-2)], 'readiness at W(-10)');
  assert.deepEqual([a.bobCounted, a.bobAbsent, a.aliceCounted, a.finalizedInReport], [7, 7, 7, 7], 'start W(-10): 7 finalized services counted');
  assert.equal(a.bobPending, 1, 'the past unfinalized Friday is Pending, not an absence');
  assert.equal(consumers.consecutiveMissedFridays(bob).streak, 0, 'an unsettled past Friday is a barrier: the run waits, it is never skipped over and never counted as an absence');
  assert.equal(consumers.consecutiveMissedFridays(bob).blocked, true);
  assert.equal(a.longAbsence, 'ready'); assert.equal(a.membership, 'ready'); assert.deepEqual(a.membershipFridays, [W(-2), W(-3), W(-4), W(-5)]);
  for (const [start, counted, longAbsence, membership] of [[W(-4), 3, 'insufficient_history', 'insufficient'], [W(-5), 4, 'insufficient_history', 'ready'], [W(-2), 1, 'insufficient_history', 'insufficient']]) {
    move(start);
    const x = figures();
    assert.deepEqual([x.bobCounted, x.bobAbsent, x.aliceCounted, x.finalizedInReport, x.readiness.eligibleFinalized], [counted, counted, counted, counted, counted], `start ${start}: the report and the readiness count the same ${counted} finalized services`);
    assert.equal(x.longAbsence, longAbsence, `start ${start}: Long Absence Review`); assert.equal(x.membership, membership, `start ${start}: Membership Review`);
    assert.equal(world(), baseline, `start ${start}: no attendance row, finalization state or expected snapshot changed`);
  }
  move(W(-1), 'only the unfinalized Friday');
  const only = figures();
  assert.deepEqual([only.bobCounted, only.bobAbsent, only.bobPending, only.readiness.eligibleFinalized, only.readiness.awaitingFinalization], [0, 0, 1, 0, 1], 'start W(-1), not finalized: Pending - not counted and not an absence');
  assert.equal(consumers.consecutiveMissedFridays(bob).streak, 0);
  move(W(0), 'start in the present week (every finalized Friday becomes history only)');
  assert.equal(figures().bobCounted, 0); assert.equal(world(), baseline);
  move(W(-10), 'back to the first Friday');
  assert.deepEqual(figures().readiness, a.readiness, 'back at W(-10) the figures are exactly what they were: nothing was lost');
  assert.equal(world(), baseline);

  // Phase B: W(-1) is finalized too (Bob absent, Alice present), so the absence run is measurable.
  mark(-1, alice, 'present'); mark(-1, bob, 'absent');
  assert.equal(lifecycle.finalizeAttendance(session.get(-1), { userId: null, confirmNoAttendance: true }).ok, true);
  const baseline2 = world();
  const run = () => consumers.consecutiveMissedFridays(bob).streak;
  assert.equal(run(), 8, 'start W(-10): all 8 finalized services are absences (not-taken and cancelled are neutral)');
  assert.deepEqual(figures().membershipFridays, [W(-1), W(-2), W(-3), W(-4)]);
  for (const [start, expectedRun, membership] of [[W(-4), 4, 'ready'], [W(-3), 3, 'insufficient'], [W(-5), 5, 'ready'], [W(-2), 2, 'insufficient'], [W(-1), 1, 'insufficient'], [W(0), 0, 'insufficient']]) {
    move(start);
    assert.equal(run(), expectedRun, `start ${start}: consecutive absence counts only finalized Fridays on or after it (the start Friday itself included)`);
    assert.equal(figures().membership, membership, `start ${start}: Membership Review`);
    assert.equal(figures().bobCounted, expectedRun, `start ${start}: the attendance report counts the same services`);
    assert.equal(world(), baseline2, `start ${start}: attendance data untouched`);
  }
  move(W(-10), 'back to the first Friday');
  assert.equal(run(), 8); assert.equal(world(), baseline2);
  console.log('PASS (derived, never rewritten) pre-start Fridays excluded, the start Friday included, finalized post-start Fridays counted, an unfinalized Friday never an absence; consecutive absence, Long Absence, Membership Review, the report and the readiness all follow the date; the attendance data is byte-identical after every move');
}

// ---- 5. the lock rules and the audit trail -----------------------------------------------------------------------------------------------------------------------------------------
{
  assert.equal(lifecycle.trackingStartLock().locked, true);
  assert.equal(lifecycle.setTrackingStartDate(W(-9), { userId: users.superAdmin.id }).reason, 'locked', 'a plain change is refused once attendance is finalized');
  assert.equal(lifecycle.setTrackingStartDate(W(-9), { userId: users.superAdmin.id, override: true, reason: '' }).reason, 'reason_required');
  assert.equal(lifecycle.setTrackingStartDate('', { userId: users.superAdmin.id, override: true, reason: 'x' }).reason, 'cannot_clear_when_locked');
  assert.equal(setting(), W(-10));
  const rows = db.prepare("SELECT * FROM audit_logs WHERE action IN ('attendance.tracking_start_overridden','attendance.tracking_start_changed') ORDER BY id").all();
  assert.ok(rows.length >= 8, 'every change left an audit row');
  const changed = db.prepare("SELECT * FROM audit_logs WHERE action = 'attendance.tracking_start_changed' ORDER BY id").all();
  assert.equal(changed.length, 1, 'the first (unlocked) setting is audited too');
  const first = JSON.parse(changed[0].detail); assert.deepEqual([first.from, first.to], [null, W(-10)]);
  const last = rows.at(-1); const d = JSON.parse(last.detail);
  assert.deepEqual([d.from, d.to, d.reason, last.user_id], [W(0), W(-10), 'back to the first Friday', users.superAdmin.id], 'old date, new date, reason and actor');
  assert.ok(last.created_at && !Number.isNaN(Date.parse(last.created_at)), 'and a timestamp');
  // moving straight from the first Friday to the present week records how many finalized Fridays stopped counting; moving back records how many started again
  const there = lifecycle.setTrackingStartDate(W(0), { userId: users.superAdmin.id, override: true, reason: 'check the audit counts' });
  assert.equal(there.newlyHistoricalFridays, 9, 'W(-10)..W(-1): 8 finalized and 1 not taken Fridays became history only');
  const backAgain = lifecycle.setTrackingStartDate(W(-10), { userId: users.superAdmin.id, override: true, reason: 'and back' });
  assert.equal(backAgain.newlyTrackedPastFridays, 9, 'and 9 Fridays are tracked again (the cancelled one is never counted)');
  const lastTwo = db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.tracking_start_overridden' ORDER BY id DESC LIMIT 2").all().map((r) => JSON.parse(r.detail));
  assert.equal(lastTwo[1].finalized_fridays_now_historical_only, 9, 'the audit row keeps the count');
  assert.equal(lastTwo[0].newly_tracked_past_fridays, 9);
  console.log('PASS (lock and audit) a change after finalization needs a Super Admin override with a reason and can never clear the date; every change is audited with old and new date, reason, actor and time');
}

// ---- 6. over HTTP: the screen, the preview, authority ------------------------------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const roles = {};
  for (const [name, user] of Object.entries({ super: users.superAdmin, church: users.churchAdmin, leader: users.leaderA, member: users.memberA, kiosk: users.kiosk })) roles[name] = await signIn(portal.base, user.email, f.PASSWORD);
  const flat = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&ldquo;|&rdquo;/g, '"').replace(/\s+/g, ' ');
  const current = setting();
  assert.equal(current, W(-10));
  const baselineNow = world();

  // the settings screen: readiness panel, wording, read-only
  const screen = flat(await (await roles.super.get('/admin/settings?section=attendance')).text());
  assert.match(screen, /Attendance Tracking Start Date/);
  assert.match(screen, /The first Friday that counts toward attendance, absence and follow-up calculations\. Earlier attendance remains available for historical reference but does not affect absence or follow-up\./);
  assert.match(screen, /Eligible finalized Fridays since start 8/); assert.match(screen, /Latest finalized Friday/);
  assert.match(screen, /"Attendance not taken" Fridays since start 1/); assert.match(screen, /Change the Attendance Tracking Start Date/);
  const raw = await (await roles.super.get('/admin/settings?section=attendance')).text();
  assert.doesNotMatch(raw, /name="attendance__tracking_start_date"/, 'no field in the form: one path, one audit trail');
  const churchScreen = flat(await (await roles.church.get('/admin/settings?section=attendance')).text());
  assert.match(churchScreen, /Eligible finalized Fridays since start 8/, 'a Church Admin sees the same readiness');
  assert.match(churchScreen, /Only a Super Admin can change this date|Ask a Super Admin/); assert.doesNotMatch(churchScreen, /Change the Attendance Tracking Start Date/);

  // the preview writes nothing and is derived from the sessions
  const before = world();
  const preview = flat(await (await roles.super.get(`/admin/attendance/tracking-start?date=${W(-4)}`)).text());
  assert.match(preview, new RegExp(`Proposed tracking start:`)); assert.match(preview, /Eligible finalized Fridays currently available 4/);
  assert.match(preview, /Earlier services remain historical only/); assert.match(preview, /Earlier Fridays kept as history only \d+ \(5 already finalized\)/);
  assert.equal(world(), before); assert.equal(setting(), current, 'previewing changes nothing');
  assert.match(flat(await (await roles.super.get(`/admin/attendance/tracking-start?date=${addDays(W(-4), 1)}`)).text()), /not a Friday/);

  // crafted requests from everyone else are refused and change nothing
  for (const name of ['church', 'leader', 'member', 'kiosk']) {
    const page = await roles[name].get('/admin/attendance/tracking-start'); await page.text();
    assert.ok([302, 403, 404].includes(page.status) && page.status !== 200, `${name}: the change page is not available (${page.status})`);
    const post = await roles[name].post('/admin/attendance/tracking-start', { tracking_start_date: W(-3), reason: 'crafted' }); await post.text();
    assert.ok(post.status !== 200, `${name}: crafted change refused (${post.status})`);
    const viaSettings = await roles[name].post('/admin/settings', { section: 'attendance', attendance__tracking_start_date: W(-3) }, { csrfFrom: '/admin/settings' }); await viaSettings.text();
    assert.equal(setting(), current, `${name}: the date is unchanged after crafted requests`);
  }
  // a Church Admin posting the settings form (who may open it) is told it is a Super Admin control
  const churchSave = await roles.church.post('/admin/settings', { section: 'attendance', attendance__tracking_start_date: W(-3), attendance__followup_threshold: '3' }, { csrfFrom: '/admin/settings?section=attendance' }); await churchSave.text();
  assert.equal(setting(), current, 'a Church Admin cannot change it through the settings form either');
  // the Super Admin: a non-Friday through the form is refused
  const bad = await roles.super.post('/admin/settings', { section: 'attendance', attendance__tracking_start_date: addDays(W(-3), 1) }, { csrfFrom: '/admin/settings?section=attendance' }); await bad.text();
  assert.equal(setting(), current, 'a non-Friday posted by a Super Admin is refused');
  // the Super Admin override: reason required, then applied and audited, then visible on the screen
  const noReason = await roles.super.post('/admin/attendance/tracking-start', { tracking_start_date: W(-4), reason: '' }, { csrfFrom: `/admin/attendance/tracking-start?date=${W(-4)}` }); await noReason.text();
  assert.equal(setting(), current, 'no reason, no change');
  const auditBefore = db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.tracking_start_overridden'").get().n;
  const done = await roles.super.post('/admin/attendance/tracking-start', { tracking_start_date: W(-4), reason: 'UAT: test a four-week window' }, { csrfFrom: `/admin/attendance/tracking-start?date=${W(-4)}` }); await done.text();
  assert.equal(done.headers.get('location'), '/admin/settings?section=attendance');
  assert.equal(setting(), W(-4));
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.tracking_start_overridden'").get().n, auditBefore + 1, 'audited');
  const audit = JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.tracking_start_overridden' ORDER BY id DESC LIMIT 1").get().detail);
  assert.deepEqual([audit.from, audit.to, audit.reason], [W(-10), W(-4), 'UAT: test a four-week window']);
  assert.match(flat(await (await roles.super.get('/admin/settings?section=attendance')).text()), /Eligible finalized Fridays since start 4/, 'the readiness panel follows the new date');
  assert.equal(world(), baselineNow, 'and still no attendance data was touched');
  // The role guard on its own: with nothing finalized the date is not locked, so only authority stands between a Church Admin's hand-built post and the setting
  // (this block runs last and empties the disposable fixture's finalization marks to reach that state).
  db.exec('UPDATE attendance_sessions SET finalization_state = NULL; DELETE FROM attendance_expected;');
  assert.equal(lifecycle.trackingStartLock().locked, false);
  const unlockedBefore = setting();
  const churchTry = await roles.church.post('/admin/settings', { section: 'attendance', attendance__tracking_start_date: W(-3) }, { csrfFrom: '/admin/settings?section=attendance' }); await churchTry.text();
  assert.equal(setting(), unlockedBefore, 'unlocked, a Church Admin still cannot change the date through the settings form');
  const superTry = await roles.super.post('/admin/settings', { section: 'attendance', attendance__tracking_start_date: W(-3) }, { csrfFrom: '/admin/settings?section=attendance' }); await superTry.text();
  assert.equal(setting(), W(-3), 'unlocked, a Super Admin sets a Friday through the same form handler');
  assert.equal(JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.tracking_start_changed' ORDER BY id DESC LIMIT 1").get().detail).to, W(-3), 'and it is audited');
  console.log('PASS (HTTP) readiness panel and wording; a preview that writes nothing; only a Super Admin can change the date (crafted requests refused for Church Admin, leader, Member and Kiosk); a reason is required, the change is audited and the panel follows');
} finally {
  await portal.stop();
}
console.log('PASS attendance-tracking-start-control');
