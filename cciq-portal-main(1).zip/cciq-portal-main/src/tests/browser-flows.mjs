import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The real forms, driven the way a person drives them, in a real browser. The fetch-based suites post exactly what they choose to post;
 * only a browser sends what the page's own markup tells it to. (A Documents upload form whose enctype had been entity-encoded passed every
 * fetch test and sent no file at all from a real browser.) Each flow below ends by checking the database, not just the page:
 *   Documents upload, member photo upload, spreadsheet import, record a First Timer, Membership Review -> Continue as Visitor,
 *   Convert to member, Link to an existing member through the member picker, Kiosk search -> review -> confirm, Express Registration.
 */

const f = await buildPortalFixture('cciq-browser-flows-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
// The Friday the Kiosk operates on is the last Friday on or before today, WHATEVER day the suite runs (see isOperationalFridaySession). Every date below is derived from it, never from the real weekday.
const K = mods.dates.lastFridayOnOrBefore(mods.dates.today());
const EARLIER = mods.dates.addDays(K, -3); // a Tuesday before that Friday: a first visit that is never the Friday itself
const contextFor = async (account) => {
  const session = await signIn(portal.base, account.email, f.PASSWORD);
  const context = await browser.newContext();
  // When the suite is run under the test clock (src/tests/lib/fake-clock.mjs) the BROWSER must agree with the server about what day it is.
  if (process.env.CCIQ_TEST_FAKE_DATE) await context.clock.install({ time: new Date(`${process.env.CCIQ_TEST_FAKE_DATE}T09:00:00Z`) });
  await context.addCookies(session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  return context;
};
const go = async (page, locatorAction) => { await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), locatorAction()]); };
const text = async (page) => (await page.textContent('main')).replace(/\s+/g, ' ');

try {
  const admin = await contextFor(users.churchAdmin);
  const kiosk = await contextFor(users.kiosk);

  // ---- Documents: choose a file, submit ---------------------------------------------------------------------------------------------------------
  {
    const page = await admin.newPage();
    await page.goto(`${portal.base}/documents/new`, { waitUntil: 'load' });
    assert.equal(await page.evaluate(() => document.querySelector('form[action="/documents"]').enctype), 'multipart/form-data', 'the form posts as multipart');
    await page.fill('input[name=title]', 'Browser flow document');
    await page.selectOption('select[name=category_id]', { index: 1 });
    await page.setInputFiles('input[type=file]', { name: 'flow.pdf', mimeType: 'application/pdf', buffer: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(300, 32)]) });
    await go(page, () => page.click('form[action="/documents"] button[type=submit]'));
    assert.match(page.url(), /\/documents\/\d+$/, `redirected to the new document (${page.url()})`);
    assert.equal(count("SELECT COUNT(*) n FROM documents WHERE title = 'Browser flow document'"), 1, 'the document row exists');
    const stored = db.prepare("SELECT stored_path FROM documents WHERE title = 'Browser flow document'").get().stored_path;
    assert.ok(fs.existsSync(path.join((await import('../config/env.js')).default.storageDir, stored)), 'and its file is on disk');
    await page.close();
    console.log('PASS (documents) a document chosen and submitted in a real browser is stored with its file');
  }

  // ---- member photo ----------------------------------------------------------------------------------------------------------------------------------
  {
    const page = await admin.newPage();
    await page.goto(`${portal.base}/members/${ids.member.a2}/edit`, { waitUntil: 'load' });
    await page.setInputFiles(`form[action="/members/${ids.member.a2}/photo"] input[type=file]`, { name: 'me.png', mimeType: 'image/png', buffer: PNG });
    await go(page, () => page.click(`form[action="/members/${ids.member.a2}/photo"] button[type=submit]`));
    assert.ok(db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(ids.member.a2).p, 'the photo is stored');
    await page.close();
    console.log('PASS (photo) a member photo chosen in a real browser is stored');
  }

  // ---- spreadsheet import ------------------------------------------------------------------------------------------------------------------------------
  {
    const XLSX = (await import('xlsx')).default;
    const buffer = XLSX.write({ SheetNames: ['S'], Sheets: { S: { A1: { t: 's', v: 'First name' }, B1: { t: 's', v: 'Last name' }, A2: { t: 's', v: 'Ivy' }, B2: { t: 's', v: 'Import' }, '!ref': 'A1:B2' } } }, { type: 'buffer', bookType: 'xlsx' });
    const page = await admin.newPage();
    await page.goto(`${portal.base}/admin/import`, { waitUntil: 'load' });
    await page.setInputFiles('form[action="/admin/import"] input[type=file] >> nth=0', { name: 'people.xlsx', mimeType: 'application/octet-stream', buffer });
    await go(page, () => page.click('form[action="/admin/import"] button[type=submit] >> nth=0'));
    assert.match(page.url(), /\/admin\/import\/[a-f0-9]{32}$/, `a staged preview is shown (${page.url()})`);
    await page.close();
    console.log('PASS (import) a spreadsheet chosen in a real browser is staged for preview');
  }

  // ---- record a First Timer ----------------------------------------------------------------------------------------------------------------------------------
  let visitorId;
  {
    const page = await admin.newPage();
    await page.goto(`${portal.base}/visitors/new`, { waitUntil: 'load' });
    await page.fill('input[name=first_name]', 'Browser'); await page.fill('input[name=last_name]', 'Visitor'); await page.fill('input[name=phone]', '+974 5566 7788');
    // Their first visit is a fixed earlier day, not the form's default of today: on a Friday today IS the Kiosk's Friday and they would already be checked in (covered separately below), so the confirm path would differ by weekday.
    await page.fill('input[name=first_visit_date]', EARLIER);
    await go(page, () => page.click('main form[method=post] button[type=submit] >> text=Record First Timer'));
    assert.match(page.url(), /\/visitors\/\d+$/, `redirected to the First Timer (${page.url()})`);
    visitorId = Number(page.url().split('/').pop());
    assert.equal(db.prepare('SELECT first_name FROM visitors WHERE id = ?').get(visitorId).first_name, 'Browser');
    // the same person again is a possible duplicate: the warning page appears, then "Record anyway" works
    await page.goto(`${portal.base}/visitors/new`, { waitUntil: 'load' });
    await page.fill('input[name=first_name]', 'Browser'); await page.fill('input[name=last_name]', 'Visitor');
    await go(page, () => page.click('main form[method=post] button[type=submit] >> text=Record First Timer'));
    assert.match(await text(page), /already|possible|same/i, 'a possible duplicate is warned about');
    await page.close();
    console.log('PASS (record) a First Timer recorded in a real browser; a duplicate raises the warning');
  }

  // ---- Membership Review: Continue as Visitor (native confirm dialog), then Convert and Link -----------------------------------------------------------------
  {
    const reviewVisitors = ['Continue', 'Convert', 'Link'].map((n) => mods.visitors.createVisitor({ first_name: `Rv${n}`, last_name: 'Flow', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id }).id);
    const insert = db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', ?)");
    const evidence = JSON.stringify({ rule: '3 of the last 4 eligible Fridays', visits: 3, fridays: [4, 3, 2, 1].map((n, i) => ({ session_id: n, service_date: `2026-01-0${n}`, visited: i !== 1 })) });
    for (const id of reviewVisitors) insert.run(id, evidence);
    const reviewOf = (id) => db.prepare('SELECT * FROM visitor_membership_reviews WHERE visitor_id = ?').get(id);

    const page = await admin.newPage();
    page.on('dialog', (dialog) => dialog.accept());
    await page.goto(`${portal.base}/visitors/reviews`, { waitUntil: 'load' });
    assert.match(await text(page), /RvContinue Flow/, 'the list shows them');
    // Review later = leave the page: nothing changes
    await page.goto(`${portal.base}/visitors/reviews/${reviewOf(reviewVisitors[0]).id}`, { waitUntil: 'load' });
    await page.goto(`${portal.base}/visitors/reviews`, { waitUntil: 'load' });
    assert.equal(reviewOf(reviewVisitors[0]).status, 'open', 'Review later changes nothing');
    // Continue as visitor
    await page.goto(`${portal.base}/visitors/reviews/${reviewOf(reviewVisitors[0]).id}`, { waitUntil: 'load' });
    await page.fill('#note', 'Still deciding');
    // One unmistakable action: no tick-box that looks like a choice, one button, and the plain explanation beside it.
    assert.equal(await page.locator('form[action$="/continue"] input[type=checkbox]').count(), 0, 'no tick-box in the Continue as visitor section');
    assert.equal(await page.locator('form[action$="/continue"] button[type=submit]').count(), 1);
    assert.match(await page.locator('form[action$="/continue"]').textContent(), /This closes the current membership review\. If they continue attending, they may be suggested again after another four finalized Friday Services\./);
    assert.doesNotMatch(await page.locator('form[action$="/continue"]').textContent(), /Yes, they continue/);
    await go(page, () => page.click('form[action$="/continue"] button[type=submit]'));
    assert.equal(reviewOf(reviewVisitors[0]).status, 'continued', 'Continue as visitor closed the review');
    assert.equal(reviewOf(reviewVisitors[0]).note, 'Still deciding');

    // Convert: from the review, through the pre-filled member form
    await page.goto(`${portal.base}/visitors/reviews/${reviewOf(reviewVisitors[1]).id}`, { waitUntil: 'load' });
    await go(page, () => page.click('a:has-text("Make them a new member")'));
    assert.equal(await page.inputValue('input[name=first_name]'), 'RvConvert', 'the form is pre-filled');
    assert.equal(await page.inputValue('input[name=date_joined]'), mods.dates.today(), 'with today as the join date');
    await go(page, () => page.click('main form[method=post] button[type=submit]'));
    assert.match(page.url(), /\/members\/\d+/, `redirected to the new member (${page.url()})`);
    assert.equal(reviewOf(reviewVisitors[1]).status, 'converted');
    assert.match(await text(page), /Before membership/, 'the member page shows the Before membership card');

    // Link: pick the member with the picker, confirm, submit
    await page.goto(`${portal.base}/visitors/${reviewVisitors[2]}/link`, { waitUntil: 'load' });
    await page.fill('#link-member-search', 'Alice');
    await page.waitForSelector('[data-picker-results] button, [data-picker-results] [role=option]', { timeout: 10000 });
    await page.click('[data-picker-results] button >> nth=0');
    assert.match(await page.textContent('[data-picker-selected]'), /Alice/, 'the chosen member is shown');
    await page.check('input[name=confirm]');
    await go(page, () => page.click('main form[method=post] button[type=submit]'));
    assert.equal(db.prepare('SELECT member_id FROM visitors WHERE id = ?').get(reviewVisitors[2]).member_id, ids.member.a1, 'linked to the member that was picked');
    assert.equal(reviewOf(reviewVisitors[2]).status, 'linked');
    await page.close();
    console.log('PASS (review) Review later, Continue as visitor (with its confirmation), Convert (pre-filled) and Link (through the picker) all work as a person uses them, and the database agrees');
  }

  // ---- the Kiosk: search, choose, review, confirm; Express Registration; a mobile-number search -------------------------------------------------------
  {
    const page = await kiosk.newPage();
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    await page.fill('#checkin-search-input', 'Browser Visitor');
    await go(page, () => page.keyboard.press('Enter'));
    assert.match(await text(page), /Browser Visitor/, 'the search finds the First Timer');
    assert.match(await text(page), /•••• 7788/, 'showing only the last four digits');
    assert.doesNotMatch(await page.content(), /5566[\s-]*7788|\+974 5566/, 'and the full number appears nowhere in the page source');
    await page.check('input[name=person] >> nth=0');
    await go(page, () => page.getByRole('button', { name: 'Review selected' }).click());
    assert.match(await text(page), /Browser Visitor/, 'the review step names them');
    const before = count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', visitorId);
    await Promise.all([page.waitForResponse((r) => r.url().includes('/attendance/checkin/record')), page.getByRole('button', { name: /Confirm|Record/ }).first().click()]);
    await page.waitForTimeout(300);
    assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', visitorId), before + 1, 'confirming records the visit');
    assert.ok(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ? AND session_id IS NOT NULL', visitorId) >= 1, 'and the visit is tied to the Friday');

    // The same-day case, on EVERY weekday: a First Timer whose visit is already on the Friday the Kiosk operates on is "already checked in" and there is nothing to confirm.
    {
      const sameday = mods.visitors.createVisitor({ first_name: 'Sameday', last_name: 'Visitor', phone: '+974 5566 1212', first_visit_date: K }, { userId: users.churchAdmin.id });
      const sameId = (sameday.visitor || sameday).id;
      const visitsBefore = count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', sameId);
      await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
      await page.fill('#checkin-search-input', 'Sameday Visitor');
      await go(page, () => page.keyboard.press('Enter'));
      await page.check('input[name=person] >> nth=0');
      await go(page, () => page.getByRole('button', { name: 'Review selected' }).click());
      const review = await text(page);
      assert.match(review, /Already checked in/, 'a visit already on the Friday says so');
      assert.match(review, /nothing more to confirm/i, 'and offers nothing to confirm');
      assert.equal(await page.getByRole('button', { name: /Confirm|Record/ }).count(), 0, 'there is no Confirm button');
      assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', sameId), visitsBefore, 'and no second visit is made');
    }

    // search by the whole number
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    await page.fill('#checkin-search-input', '+974 5566 7788');
    await go(page, () => page.keyboard.press('Enter'));
    assert.match(await text(page), /Browser Visitor/, 'the whole mobile number finds them');
    assert.equal(await page.inputValue('#checkin-search-input'), '', 'and the number is not left in the search box');
    assert.doesNotMatch(page.url(), /5566|7788/, 'nor in the address bar');

    // Express Registration (it opens in its own tab and ends on a done page; the kiosk tab stays as it was)
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    const [reg] = await Promise.all([page.context().waitForEvent('page'), page.click('a:has-text("First time here")')]);
    await reg.waitForLoadState('load');
    await reg.fill('#ft-first-name', 'Express'); await reg.fill('#ft-last-name', 'Browser');
    await Promise.all([reg.waitForNavigation({ waitUntil: 'load' }), reg.getByRole('button', { name: /Register and check in/ }).click()]);
    assert.equal(new URL(reg.url()).pathname, '/attendance/checkin/first-timer/done', 'the registration tab shows its done page');
    assert.match(await text(reg), /Welcome, Express/, 'with a welcome message');
    assert.equal(new URL(page.url()).pathname, '/kiosk', 'and the kiosk tab stayed at the kiosk');
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Express' AND last_name = 'Browser'"), 1);
    // a duplicate is refused without naming anyone (the number makes it a different submission from the first, so the double-tap guard is not what answers)
    await go(reg, () => reg.click('a:has-text("Register another First Timer")'));
    await reg.fill('#ft-first-name', 'Express'); await reg.fill('#ft-last-name', 'Browser'); await reg.fill('#ft-phone', '+974 5500 9999');
    await go(reg, () => reg.getByRole('button', { name: /Register and check in/ }).click());
    assert.match(await text(reg), /may already be on file/);
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Express' AND last_name = 'Browser'"), 1, 'and creates no second person');
    await reg.close();
    await page.close();
    console.log('PASS (kiosk) search by name and by whole number (masked, never echoed), review, confirm and Express Registration all work from the real screens');
  }
  console.log('ALL PASS');
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
