import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const assets = [
  'cell-group-cover-default.webp', 'cell-group-cover-default-1000.webp',
  'dashboard-hero.webp', 'dashboard-hero-1000.webp',
  'ecaq-worship-centre.jpg', 'ecaq-worship-centre-small.jpg',
  'login-worship.webp', 'login-worship-1000.webp',
  'ministries-cover-default.webp', 'ministries-cover-default-1000.webp'
];
for (const name of assets) assert.equal(fs.existsSync(path.join(root, 'src/public/branding', name)), false, `${name} excluded`);

const runtime = path.join(root, 'src');
const readTree = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
  const file = path.join(dir, entry.name);
  if (entry.isDirectory()) return entry.name === 'tests' ? [] : readTree(file);
  if (/\.(?:js|ejs|css)$/.test(entry.name)) return [fs.readFileSync(file, 'utf8')];
  return [];
});
const source = readTree(runtime).join('\n');
for (const name of assets) assert.ok(!source.includes(name), `runtime source does not refer to ${name}`);

const css = fs.readFileSync(path.join(root, 'src/public/css/cciq.css'), 'utf8');
assert.match(css, /--login-backdrop: linear-gradient\(/);
assert.match(css, /\.dashboard-hero \{ background: linear-gradient\(/);
assert.match(css, /\.group-cover \{[^}]*background: linear-gradient\(/s);
assert.match(css, /\.project-hero \{[^}]*min-height: 220px/s);
console.log('PASS (sanitized artwork): all 10 unverified images absent; runtime references removed; neutral CSS surfaces retained.');
