import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { encryptFile, decryptFile, isEncryptedFile, checkPassphrase, ENCRYPTED_SUFFIX, CryptError } from '../lib/backup-crypt.js';

/*
 * Encrypted copies of a backup (for USB drives and cloud folders).
 *   - round trip: what comes out is byte-identical to what went in, including an archive larger than one stream chunk;
 *   - the copy is not the archive: no plaintext, different every time (random salt and nonce), recognisable only by its header;
 *   - the wrong passphrase, one flipped byte anywhere (header, body, tag), a truncated file and a file that is not encrypted all FAIL, write nothing and leave no partial file;
 *   - a weak passphrase is refused up front; the passphrase appears nowhere in the file.
 */

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-crypt-'));
const plain = path.join(dir, 'archive.tar.gz');
const body = Buffer.concat([Buffer.from('CCIQ secret member list: Jane Doe 1980-05-17\n'), crypto.randomBytes(300 * 1024)]);
fs.writeFileSync(plain, body);
const PASS = 'a long sentence for the church';
const enc = path.join(dir, `archive.tar.gz${ENCRYPTED_SUFFIX}`);

{
  const made = await encryptFile(plain, enc, PASS);
  assert.ok(made.bytes > body.length && made.bytes <= body.length + 8 + 16 + 12 + 16);
  assert.equal(isEncryptedFile(enc), true); assert.equal(isEncryptedFile(plain), false);
  const raw = fs.readFileSync(enc);
  assert.ok(!raw.includes(Buffer.from('Jane Doe')) && !raw.includes(Buffer.from(PASS)), 'neither the content nor the passphrase is in the copy');
  const back = path.join(dir, 'back.tar.gz'); await decryptFile(enc, back, PASS);
  assert.ok(fs.readFileSync(back).equals(body), 'byte-identical after the round trip');
  const second = path.join(dir, 'second.ccenc'); await encryptFile(plain, second, PASS);
  assert.ok(!fs.readFileSync(second).equals(raw), 'a fresh salt and nonce every time');
  console.log('PASS (round trip) byte-identical; the copy holds neither the content nor the passphrase; two copies differ');
}
{
  const out = path.join(dir, 'never.tar.gz');
  await assert.rejects(decryptFile(enc, out, 'the wrong passphrase!'), (e) => e instanceof CryptError && e.code === 'bad_passphrase_or_damaged');
  assert.ok(!fs.existsSync(out) && !fs.existsSync(`${out}.partial`), 'a wrong passphrase writes nothing');
  const raw = fs.readFileSync(enc);
  for (const [name, at] of [['the header', 10], ['the salt', 12], ['the nonce', 30], ['the body', 1000], ['the tag', raw.length - 3]]) {
    const copy = Buffer.from(raw); copy[at] ^= 0x01; const bad = path.join(dir, `bad-${name.replace(' ', '-')}.ccenc`); fs.writeFileSync(bad, copy);
    await assert.rejects(decryptFile(bad, out, PASS), CryptError, `a flipped byte in ${name} is refused`);
    assert.ok(!fs.existsSync(out) && !fs.existsSync(`${out}.partial`));
  }
  const cut = path.join(dir, 'cut.ccenc'); fs.writeFileSync(cut, raw.subarray(0, raw.length - 40)); await assert.rejects(decryptFile(cut, out, PASS), CryptError);
  const tiny = path.join(dir, 'tiny.ccenc'); fs.writeFileSync(tiny, raw.subarray(0, 20)); await assert.rejects(decryptFile(tiny, out, PASS), (e) => e.code === 'truncated');
  await assert.rejects(decryptFile(plain, out, PASS), (e) => e.code === 'not_encrypted');
  assert.ok(!fs.existsSync(out) && !fs.existsSync(`${out}.partial`), 'nothing written by any refusal');
  console.log('PASS (refusals) the wrong passphrase, a flipped byte in the header, salt, nonce, body or tag, a truncated file and a plain file are all refused; nothing is written');
}
{
  assert.match(checkPassphrase('short'), /at least 12/); assert.match(checkPassphrase('aaaaaaaaaaaaaaaa'), /repetitive/); assert.equal(checkPassphrase(PASS), null);
  await assert.rejects(encryptFile(plain, path.join(dir, 'weak.ccenc'), 'short'), (e) => e.code === 'weak_passphrase');
  assert.ok(!fs.existsSync(path.join(dir, 'weak.ccenc')) && !fs.existsSync(path.join(dir, 'weak.ccenc.partial')));
  console.log('PASS (passphrase) a weak passphrase is refused before anything is written');
}
fs.rmSync(dir, { recursive: true, force: true });
console.log('PASS backup-crypt');
