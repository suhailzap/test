import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Migration 0030 (First Timer membership review + the "joined means linked" rule).
 *   - additive and idempotent; stacks on a 0029 database without touching existing rows;
 *   - the database itself refuses a First Timer that is "joined" without a member (and the reverse), and a second First Timer on one member;
 *   - a legacy database that already holds such rows is REFUSED, never repaired, and left exactly as it was;
 *   - the pre-migration gate (tools/check-first-timer-links.mjs and the same check inside the migration) agree.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-migration-0030-');
const migrateModule = await import('../db/migrate.js');
const { migrate, EXPECTED_MIGRATIONS, MigrationRefusedError, checkSchemaCompatibility } = migrateModule;
migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const { findFirstTimerLinkProblems } = await import('../lib/first-timer-links.js');
const { default: db } = await import('../db/index.js');

const objects = (type) => db.prepare('SELECT name FROM sqlite_master WHERE type = ? ORDER BY name').all(type).map((r) => r.name);
const SCHEMA_0030 = {
  table: 'visitor_membership_reviews',
  indexes: ['idx_membership_reviews_status', 'idx_membership_reviews_visitor', 'idx_visitors_member_unique', 'uniq_open_review_per_visitor'],
  triggers: ['trg_members_delete_has_visitor', 'trg_visitors_joined_iff_member_insert', 'trg_visitors_joined_iff_member_update']
};

// ---- 1. a fresh database ends at 0030 with everything in place ----------------------------------------------------------------------------
{
  assert.ok(EXPECTED_MIGRATIONS.includes('0030_first_timer_membership_review'), '0030 is a migration the source knows');
  assert.ok(db.prepare("SELECT 1 FROM schema_migrations WHERE version = '0030_first_timer_membership_review'").get(), '0030 is recorded');
  assert.deepEqual(checkSchemaCompatibility(db).missing ?? [], [], 'a fresh database is compatible');
  assert.ok(objects('table').includes(SCHEMA_0030.table));
  for (const name of SCHEMA_0030.indexes) assert.ok(objects('index').includes(name), `index ${name}`);
  for (const name of SCHEMA_0030.triggers) assert.ok(objects('trigger').includes(name), `trigger ${name}`);
  const grants = (role) => db.prepare(`SELECT p.key FROM roles r JOIN role_permissions rp ON rp.role_id = r.id JOIN permissions p ON p.id = rp.permission_id
                                        WHERE r.key = ? AND p.key = 'visitors.express_register'`).all(role).length;
  for (const role of ['super_admin', 'church_admin', 'kiosk']) assert.equal(grants(role), 1, `${role} holds visitors.express_register`);
  for (const role of ['member', 'cell_group_leader', 'pastor']) {
    if (db.prepare('SELECT 1 FROM roles WHERE key = ?').get(role)) assert.equal(grants(role), 0, `${role} does not`);
  }
  const kiosk = db.prepare("SELECT p.key FROM roles r JOIN role_permissions rp ON rp.role_id = r.id JOIN permissions p ON p.id = rp.permission_id WHERE r.key = 'kiosk' ORDER BY p.key").all().map((r) => r.key);
  assert.deepEqual(kiosk, ['attendance.checkin', 'visitors.express_register'], 'the Kiosk gains exactly one narrow permission');
  console.log('PASS (1) a fresh database reaches 0030: the review table, its indexes, the three guard triggers and the one new permission');
}

// ---- 2. the database enforces the rules itself -------------------------------------------------------------------------------------------
{
  const v = (name, extra = {}) => visitors.createVisitor({ first_name: name, last_name: 'T', first_visit_date: '2026-01-02', ...extra }, { userId: null });
  const m = createMember({ first_name: 'Anchor', last_name: 'Member' }, { status: 'active' });
  const insertVisitor = (state, memberId) => db.prepare(
    "INSERT INTO visitors (first_name, state, member_id, follow_up_state, first_visit_date, created_at, updated_at) VALUES ('Raw', ?, ?, 'new', '2026-01-02', 'x', 'x')").run(state, memberId);
  assert.throws(() => insertVisitor('joined', null), /joined.*if and only if/i, 'cannot insert joined without a member');
  assert.throws(() => insertVisitor('new', m.id), /joined.*if and only if/i, 'cannot insert a member link without joined');
  assert.doesNotThrow(() => insertVisitor('joined', m.id), 'joined with a member is fine');
  assert.throws(() => insertVisitor('joined', m.id), /UNIQUE/, 'a member can have only one First Timer');

  const plain = v('Plain');
  assert.throws(() => db.prepare("UPDATE visitors SET state = 'joined' WHERE id = ?").run(plain.id), /joined.*if and only if/i, 'cannot set joined by hand');
  const other = createMember({ first_name: 'Other', last_name: 'Member' }, { status: 'active' });
  assert.throws(() => db.prepare('UPDATE visitors SET member_id = ? WHERE id = ?').run(other.id, plain.id), /joined.*if and only if/i, 'cannot link without joined');
  assert.doesNotThrow(() => db.prepare("UPDATE visitors SET state = 'joined', member_id = ? WHERE id = ?").run(other.id, plain.id), 'the two together are allowed (that is what convert and link do)');
  assert.throws(() => db.prepare("UPDATE visitors SET state = 'returning' WHERE id = ?").run(plain.id), /joined.*if and only if/i, 'cannot leave joined while linked');
  assert.throws(() => db.prepare('DELETE FROM members WHERE id = ?').run(other.id), /cannot be deleted/, 'a member linked from a First Timer cannot be deleted from underneath it');
  assert.doesNotThrow(() => db.prepare("UPDATE visitors SET follow_up_state = 'contacted', updated_at = 'y', notes = 'n' WHERE id = ?").run(plain.id), 'ordinary columns of a joined visitor update freely');
  const free = v('Free');
  assert.doesNotThrow(() => db.prepare("UPDATE visitors SET state = 'returning' WHERE id = ?").run(free.id), 'ordinary state changes are untouched');
  console.log('PASS (2) the database refuses joined-without-member, member-without-joined and two First Timers on one member, and protects a linked member from deletion; ordinary updates are untouched');
  db.exec('DELETE FROM visitors; DELETE FROM members');
}

// ---- helpers to take a copy back to a "0029" state ----------------------------------------------------------------------------------------
function rewindTo0029() {
  db.pragma('foreign_keys = OFF');
  db.exec(`
    ${SCHEMA_0030.triggers.map((t) => `DROP TRIGGER IF EXISTS ${t};`).join('\n')}
    ${SCHEMA_0030.indexes.map((i) => `DROP INDEX IF EXISTS ${i};`).join('\n')}
    DROP TABLE IF EXISTS ${SCHEMA_0030.table};
    DELETE FROM role_permissions WHERE permission_id = (SELECT id FROM permissions WHERE key = 'visitors.express_register');
    DELETE FROM permissions WHERE key = 'visitors.express_register';
    DELETE FROM schema_migrations WHERE version = '0030_first_timer_membership_review';
  `);
  db.pragma('foreign_keys = ON');
}
const has0030 = () => objects('table').includes(SCHEMA_0030.table)
  || SCHEMA_0030.indexes.some((i) => objects('index').includes(i)) || SCHEMA_0030.triggers.some((t) => objects('trigger').includes(t))
  || Boolean(db.prepare("SELECT 1 FROM permissions WHERE key = 'visitors.express_register'").get())
  || Boolean(db.prepare("SELECT 1 FROM schema_migrations WHERE version = '0030_first_timer_membership_review'").get());
const dataSnapshot = () => JSON.stringify({
  visitors: db.prepare('SELECT * FROM visitors ORDER BY id').all(), members: db.prepare('SELECT * FROM members ORDER BY id').all(),
  visits: db.prepare('SELECT * FROM visitor_visits ORDER BY id').all(), sessions: db.prepare('SELECT * FROM attendance_sessions ORDER BY id').all(),
  records: db.prepare('SELECT * FROM attendance_records ORDER BY id').all(), history: db.prepare('SELECT * FROM member_status_history ORDER BY id').all(),
  migrations: db.prepare('SELECT version FROM schema_migrations ORDER BY version').all(), perms: db.prepare('SELECT key FROM permissions ORDER BY key').all()
});
function plantLegacyVisitors() {
  const raw = db.prepare("INSERT INTO visitors (first_name, last_name, state, member_id, follow_up_state, first_visit_date, created_at, updated_at) VALUES (?, 'Legacy', ?, ?, 'new', '2025-12-05', 'x', 'x')");
  const a = createMember({ first_name: 'Joined', last_name: 'Member' }, { status: 'active' });
  raw.run('Ok-New', 'new', null); raw.run('Ok-Returning', 'returning', null); raw.run('Ok-Declined', 'declined', null);
  raw.run('Ok-Joined', 'joined', a.id);
  db.prepare("INSERT INTO visitor_visits (visitor_id, visit_date, recorded_at) SELECT id, first_visit_date, 'x' FROM visitors").run();
  return { a };
}

// ---- 3. a clean 0029-state database upgrades, unchanged, and a second run changes nothing ----------------------------------------------------
{
  rewindTo0029(); db.exec('DELETE FROM visitor_visits; DELETE FROM visitors; DELETE FROM members');
  plantLegacyVisitors();
  assert.equal(has0030(), false, 'sanity: the copy is at 0029');
  assert.deepEqual(checkSchemaCompatibility(db).missing, ['0030_first_timer_membership_review'], 'exactly one migration behind');
  assert.equal(findFirstTimerLinkProblems(db).total, 0, 'the gate finds nothing');
  const before = JSON.parse(dataSnapshot());
  migrate();
  const after = JSON.parse(dataSnapshot());
  for (const key of ['visitors', 'members', 'visits', 'sessions', 'records', 'history']) assert.deepEqual(after[key], before[key], `${key} are untouched by the migration`);
  assert.ok(has0030()); assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_membership_reviews').get().n, 0, 'the review table starts empty');
  const snapshotAfterFirst = dataSnapshot();
  migrate(); migrate();
  assert.equal(dataSnapshot(), snapshotAfterFirst, 'running it again changes nothing (idempotent)');
  assert.deepEqual(checkSchemaCompatibility(db).missing ?? [], []);
  console.log('PASS (3) a clean 0029 database upgrades without touching any existing row, and re-running is a no-op');
}

// ---- 4. every kind of unsafe legacy row makes the migration refuse, change nothing, and name the rows ----------------------------------------------
const planters = {
  'joined without a member': () => db.prepare("INSERT INTO visitors (first_name, state, follow_up_state, first_visit_date, created_at, updated_at) VALUES ('Bad-A', 'joined', 'new', '2025-12-05', 'x', 'x')").run().lastInsertRowid,
  'linked to a member but not joined': () => {
    const m = createMember({ first_name: 'Linked', last_name: 'Bad' }, { status: 'active' });
    return db.prepare("INSERT INTO visitors (first_name, state, member_id, follow_up_state, first_visit_date, created_at, updated_at) VALUES ('Bad-B', 'returning', ?, 'new', '2025-12-05', 'x', 'x')").run(m.id).lastInsertRowid;
  },
  'two First Timers on one member': () => {
    const m = createMember({ first_name: 'Shared', last_name: 'Bad' }, { status: 'active' });
    const ins = db.prepare("INSERT INTO visitors (first_name, state, member_id, follow_up_state, first_visit_date, created_at, updated_at) VALUES (?, 'joined', ?, 'new', '2025-12-05', 'x', 'x')");
    ins.run('Bad-C1', m.id); return ins.run('Bad-C2', m.id).lastInsertRowid;
  }
};
for (const [label, plant] of Object.entries(planters)) {
  rewindTo0029(); db.exec('DELETE FROM visitor_visits; DELETE FROM visitors; DELETE FROM members');
  plantLegacyVisitors();
  const badId = Number(plant());
  const before = dataSnapshot();
  assert.ok(findFirstTimerLinkProblems(db).total > 0, `${label}: the gate sees it`);
  let refusal = null;
  try { migrate(); } catch (err) { refusal = err; }
  assert.ok(refusal instanceof MigrationRefusedError, `${label}: the migration refuses`);
  assert.equal(refusal.version, '0030_first_timer_membership_review');
  assert.match(refusal.diagnostic, /does not repair|nothing was changed/i); assert.match(refusal.diagnostic, new RegExp(`\\b${badId}\\b`), `${label}: the diagnostic names the record (${badId})`);
  assert.doesNotMatch(refusal.diagnostic, /phone|email|@/i, 'and no personal details');
  assert.equal(has0030(), false, `${label}: nothing from 0030 was created, not even the permission or the migration row`);
  assert.equal(dataSnapshot(), before, `${label}: no data changed (nothing was repaired or guessed)`);
  assert.deepEqual(checkSchemaCompatibility(db).missing, ['0030_first_timer_membership_review'], 'the database is still exactly one behind');
}
console.log('PASS (4) joined-without-member, member-without-joined and two-First-Timers-on-one-member each refuse the migration with the rows named, and leave the database exactly as it was');

// ---- 5. the CLI gate and the migration CLI agree, and neither repairs -----------------------------------------------------------------------------
{
  // the data from the last loop iteration is still unsafe
  const copy = path.join(env.root ?? path.dirname(process.env.DATABASE_FILE), 'gate-copy.sqlite');
  fs.rmSync(copy, { force: true });
  db.exec(`VACUUM INTO '${copy.replace(/'/g, "''")}'`);
  const gate = spawnSync(process.execPath, [path.join(root, 'tools/check-first-timer-links.mjs'), copy], { encoding: 'utf8' });
  assert.equal(gate.status, 3, 'the read-only gate exits 3 when rows need a decision');
  assert.match(gate.stdout + gate.stderr, /Bad-|visitor|#?\d+/i);
  const json = spawnSync(process.execPath, [path.join(root, 'tools/check-first-timer-links.mjs'), copy, '--json'], { encoding: 'utf8' });
  assert.ok(JSON.parse(json.stdout).total > 0, 'machine-readable output');
  const cli = spawnSync(process.execPath, [path.join(root, 'src/db/migrate.js')], { encoding: 'utf8', env: process.env });
  assert.equal(cli.status, 1, 'the db:migrate command exits 1 when it refuses');
  assert.match(cli.stderr, /REFUSED\. Nothing was changed/); assert.equal(has0030(), false, 'and changed nothing');
  assert.equal(spawnSync(process.execPath, [path.join(root, 'tools/check-first-timer-links.mjs')], { encoding: 'utf8' }).status, 2, 'no default database path');
  const prodLike = path.join(path.dirname(copy), 'cciq-production', 'x.sqlite'); fs.mkdirSync(path.dirname(prodLike), { recursive: true }); fs.copyFileSync(copy, prodLike);
  assert.equal(spawnSync(process.execPath, [path.join(root, 'tools/check-first-timer-links.mjs'), prodLike], { encoding: 'utf8' }).status, 1, 'refuses a path inside a cciq-production folder');
  // repair is the administrators' decision: after they fix the rows by hand, the very same migration proceeds
  db.exec("DELETE FROM visitor_visits; DELETE FROM visitors WHERE first_name LIKE 'Bad-%'");
  assert.equal(findFirstTimerLinkProblems(db).total, 0);
  migrate();
  assert.ok(has0030(), 'once the records are corrected by a person, the migration applies');
  const cliOk = spawnSync(process.execPath, [path.join(root, 'src/db/migrate.js')], { encoding: 'utf8', env: process.env });
  assert.equal(cliOk.status, 0); assert.match(cliOk.stdout, /Schema up to date/);
  console.log('PASS (5) the read-only gate and the migration CLI refuse the same rows (exit 3 / exit 1), never repair, refuse a production-looking path, and the migration proceeds once a person corrects the records');
}

// ---- 6. a partly-applied 0030 (interrupted elsewhere) re-runs safely ------------------------------------------------------------------------------
{
  db.exec('DROP TRIGGER trg_members_delete_has_visitor; DELETE FROM schema_migrations WHERE version = \'0030_first_timer_membership_review\'');
  assert.doesNotThrow(() => migrate(), 'IF NOT EXISTS everywhere: a half-applied state completes');
  assert.ok(objects('trigger').includes('trg_members_delete_has_visitor'));
  console.log('PASS (6) re-running over a partly applied 0030 completes it without error');
}

console.log('ALL PASS');
