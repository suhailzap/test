import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Search, round two. search-consistency.mjs proves the nine main lists treat what was typed literally. This covers the searches it does not:
 * cell groups, ECAQ boards and Faith Promise, the ministry serving list, the check-in desk, the follow-up lists, a session page and the people
 * pickers; and it pins down what the search does with accented and non-Latin letters, which is a behaviour people notice with Filipino, Spanish and
 * Arabic names. Every case also has to avoid a server error for hostile input.
 */

const f = await buildPortalFixture('cciq-search2-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();

mods.groups.createGroup({ name: 'Zed50% Group', leader_member_id: ids.member.a1, meeting_day: 'Friday' });
const zed = mods.members.createMember({ first_name: 'Zoe', last_name: 'Zed50%' }, { status: 'active' });
const jose = mods.members.createMember({ first_name: 'José', last_name: 'Ñandú' }, { status: 'active' });
const arabic = mods.members.createMember({ first_name: 'أحمد', last_name: 'المصري' }, { status: 'active' });
const board = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'giving_board' LIMIT 1").get();
const promise = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'faith_promise' LIMIT 1").get();
mods.faith.submitCommitment(promise.id, { member_id: zed.id, name: 'Zoe Zed50%', amount: 20, frequency: 'monthly' }, { userId: users.churchAdmin.id });

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const get = async (url, q, extra = '') => {
    const res = await admin.get(`${url}?q=${encodeURIComponent(q)}${extra}`);
    const body = await res.text();
    assert.ok(res.status < 500, `${url}?q=${q} must not be a server error (got ${res.status})`);
    return body;
  };

  const rowsFor = (body, needle) => body.includes(needle);

  // 1. literal matching in the lists this file adds
  const lists = [
    { url: '/cell-groups', special: 'Zed50% Group', control: 'Group Alpha' },
    { url: '/admin/ecaq/faith-promise', special: 'Zoe Zed50%', control: 'Anna MemberA', extra: `&campaign=${promise.id}` },
    { url: '/ministries/serving', special: 'Zoe', control: 'Anna', optional: true },
    { url: '/attendance/checkin', special: 'Zed50%', control: 'MemberB', optional: true }
  ];
  for (const { url, special, control, extra = '', optional } of lists) {
    const base = await get(url, '', extra);
    const hasControl = base.includes(control);
    if (!hasControl && !optional) assert.fail(`${url}: the control "${control}" is listed with no search`);
    for (const wildcard of ['%', '%%', '__', '_%_']) {
      const r = await get(url, wildcard, extra);
      if (hasControl) assert.ok(!r.includes(control), `${url}?q=${wildcard}: a bare wildcard must not list everything`);
    }
    const literal = await get(url, 'd50%', extra);
    if (!optional || literal.includes(special)) {
      assert.ok(literal.includes(special), `${url}?q=d50%: the literal term finds "${special}"`);
    }
    if (hasControl) assert.ok(!literal.includes(control), `${url}?q=d50%: and only it`);
    for (const odd of ["x' OR 1=1 --", '\\', 'a\\', '\\%', 'x'.repeat(5000), 'Ünïcödé ✓', 'أحمد', '<script>alert(1)</script>', '😀'.repeat(40), 'a\u0000b']) {
      const r = await get(url, odd, extra);
      assert.ok(!r.includes('<script>alert(1)</script>'), `${url}: the typed term is escaped on the page`);
    }
  }
  console.log(`PASS (literal) ${lists.length} more searches treat % and _ as characters, ignore spaces' wildcards, refuse SQL text and never error`);

  // 2. the other searching screens never fail on hostile input
  const meeting = db.prepare('SELECT id FROM attendance_sessions ORDER BY id DESC LIMIT 1').get();
  const screens = ['/attendance/follow-up', '/attendance/long-absence', `/attendance/sessions/${meeting.id}`, '/members/picker-search', '/search', '/admin/audit', '/reminders'];
  for (const url of screens) {
    for (const q of ['%', '_', String.fromCharCode(92), "'", '"', ';--', String.fromCodePoint(0x1f600).repeat(60), 'x'.repeat(10000), String.fromCharCode(0x202e), 'LONE']) {
      const enc = q === 'LONE' ? '%ED%A0%80' : encodeURIComponent(q); // a lone surrogate cannot be encoded; send the invalid bytes a hostile client would
      const res = await admin.get(`${url}?q=${enc}&action=${enc}`);
      await res.text();
      assert.ok(res.status < 500, `${url} with q=${JSON.stringify(q).slice(0, 20)} is not a server error (got ${res.status})`);
    }
  }
  console.log(`PASS (robust) ${screens.length} more screens survive %, _, backslash, quotes, SQL text, emoji, bidi and lone-surrogate input without a server error`);

  // 3. accents and other scripts: what the search does, written down
  const probes = [
    ['José', true], ['jose', false], ['JOSÉ', true], ['josé', true], ['Ñandú', true], ['ñandú', true], ['ÑANDÚ', true], ['nandu', false],
    ['أحمد', true], ['المصري', true], ['José Ñandú', true]
  ];
  const found = {};
  for (const [term] of probes) {
    const body = await get('/members', term);
    found[term] = body.includes(`/members/${term.includes('أ') || term.includes('ا') ? arabic.id : jose.id}`);
  }
  // NFD input (the way some keyboards and phones send an accented letter) must find the NFC-stored name.
  const decomposed = 'José'.normalize('NFD');
  const nfd = await get('/members', decomposed);
  assert.ok(nfd.includes(`/members/${jose.id}`), 'an accent typed as a letter plus a combining mark finds the stored name');
  assert.ok(found['José'] && found['أحمد'] && found['المصري'] && found['José Ñandú'], 'exact accented and Arabic names are found');
  const accentBlind = found['jose'];
  const caseBlindNonAscii = found['josé'] && found['ñandú'] && found['ÑANDÚ'];
  console.log(`PASS (accents) exact accented / Arabic names and an NFD-typed accent are found. Characterised: "jose" for "José" ${accentBlind ? 'finds' : 'does not find'} them; "josé"/"ñandú"/"ÑANDÚ" ${caseBlindNonAscii ? 'ignore' : 'do NOT ignore'} case for non-ASCII letters`);
  assert.ok(rowsFor('', ''));
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
