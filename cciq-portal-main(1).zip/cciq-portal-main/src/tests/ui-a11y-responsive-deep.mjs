import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { crawl } from './lib/crawl.mjs';
import { OVERFLOW_CHECK_SCRIPT } from '../../tools/check-overflow.mjs';

/*
 * Deep accessibility and responsive pass in a real browser. Every distinct screen each kind of person can reach (found by following
 * links, deduplicated by route shape) is opened at the widths the portal is designed around (320, 360, 390, 430, 768, 820, 860,
 * 861, 1024, 1280, 1440) and checked for:
 *   responsive  - no page-level horizontal overflow; nothing of the main content is clipped off the left edge;
 *   accessible  - language, one main landmark, exactly one h1, no skipped heading levels, names on every control and link, alt text
 *                 on every image, no duplicate ids, valid label/aria references, table captions and column scopes, safe target=_blank,
 *                 zoom not disabled, visible focus, touch targets of a usable size on phones.
 * The Kiosk is checked for overflow only - its large-target layout is deliberately not compacted.
 */

const WIDTHS = [320, 360, 390, 430, 768, 820, 860, 861, 1024, 1280, 1440, 1920];
const f = await buildPortalFixture('cciq-a11y-deep-');
const { users } = f;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });

const shape = (href) => href.replace(/\/\d+/g, '/#').replace(/([?&])(?!tab=)[^=&]+=[^&]*/g, '').replace(/[?&]$/, '').replace(/\?&/, '?') || '/';
const dedupe = (pages, limit) => {
  const picked = new Map();
  for (const [href, page] of pages) {
    if (page.status !== 200 || !/text\/html/.test(page.type)) continue;
    if (/\/(export|pdf|print)|\.csv|\/file|\/card\.|\/photo|\/qr\b/.test(href)) continue;
    const key = shape(href.split('#')[0]);
    if (!picked.has(key)) picked.set(key, href);
    if (picked.size >= limit) break;
  }
  return [...picked.values()];
};

/** Runs in the page. Returns a list of { rule, detail } problems. */
const A11Y_SCRIPT = () => {
  const problems = [];
  const add = (rule, detail) => problems.push({ rule, detail: String(detail).slice(0, 120) });
  const visible = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const nameOf = (el) => {
    const labelled = el.getAttribute('aria-labelledby');
    if (labelled) return labelled.split(/\s+/).map((id) => document.getElementById(id)?.textContent || '').join(' ').trim();
    return (el.getAttribute('aria-label') || '').trim()
      || (el.labels && [...el.labels].map((l) => l.textContent).join(' ').trim())
      || (el.textContent || '').trim()
      || (el.getAttribute('title') || '').trim()
      || (el.getAttribute('alt') || '').trim()
      || (el.querySelector('img[alt]')?.getAttribute('alt') || '').trim()
      || (el.querySelector('.sr-only')?.textContent || '').trim();
  };

  if (!document.documentElement.lang) add('lang', 'missing <html lang>');
  const viewport = document.querySelector('meta[name=viewport]')?.content || '';
  if (!viewport) add('viewport', 'no viewport meta');
  if (/user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*1(\.0)?\b/.test(viewport)) add('zoom', `zoom disabled: ${viewport}`);
  if (!document.title.trim()) add('title', 'empty <title>');
  if (document.querySelectorAll('main, [role=main]').length !== 1) add('main', `${document.querySelectorAll('main, [role=main]').length} main landmarks`);

  const headings = [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(visible);
  const h1 = headings.filter((h) => h.tagName === 'H1');
  if (h1.length !== 1 && !document.body.classList.contains('kiosk')) add('h1', `${h1.length} visible h1`);
  let previous = 0;
  for (const h of headings) {
    const level = Number(h.tagName[1]);
    if (previous && level > previous + 1) add('heading-order', `${h.tagName} "${h.textContent.trim().slice(0, 30)}" follows h${previous}`);
    previous = level;
  }

  const ids = new Map();
  document.querySelectorAll('[id]').forEach((el) => ids.set(el.id, (ids.get(el.id) || 0) + 1));
  for (const [id, n] of ids) if (n > 1) add('duplicate-id', `#${id} x${n}`);
  for (const attr of ['aria-labelledby', 'aria-describedby', 'aria-controls']) {
    document.querySelectorAll(`[${attr}]`).forEach((el) => {
      for (const ref of el.getAttribute(attr).split(/\s+/)) if (ref && !document.getElementById(ref)) add('dangling-ref', `${attr}="${ref}" on <${el.tagName.toLowerCase()}>`);
    });
  }
  document.querySelectorAll('label[for]').forEach((l) => { if (!document.getElementById(l.htmlFor)) add('label-for', `label for="${l.htmlFor}" has no control`); });

  document.querySelectorAll('img').forEach((img) => { if (!img.hasAttribute('alt')) add('img-alt', img.getAttribute('src')); });
  document.querySelectorAll('svg[role=img]').forEach((svg) => { if (!nameOf(svg)) add('svg-name', 'svg role=img without a name'); });

  document.querySelectorAll('input, select, textarea').forEach((el) => {
    if (el.type === 'hidden' || el.type === 'submit' || el.type === 'button' || !visible(el)) return;
    if (!nameOf(el)) add('control-name', `<${el.tagName.toLowerCase()} name="${el.name}" type="${el.type}">`);
    if (el.type === 'password' && !el.autocomplete) add('autocomplete', `password field "${el.name}" lacks autocomplete`);
  });
  document.querySelectorAll('button, [role=button], input[type=submit]').forEach((el) => {
    if (!visible(el)) return;
    const n = el.tagName === 'INPUT' ? (el.value || el.getAttribute('aria-label')) : nameOf(el);
    if (!n) add('button-name', el.outerHTML.slice(0, 90));
  });
  document.querySelectorAll('a[href]').forEach((a) => {
    if (!visible(a)) return;
    if (a.getAttribute('aria-hidden') === 'true' && a.tabIndex === -1) return; // a redundant duplicate link, out of the tab order and the accessibility tree
    if (!nameOf(a)) add('link-name', a.outerHTML.slice(0, 90));
    if (a.target === '_blank' && !/noopener/.test(a.rel)) add('noopener', a.getAttribute('href'));
  });
  document.querySelectorAll('[tabindex]').forEach((el) => { if (Number(el.getAttribute('tabindex')) > 0) add('tabindex', `tabindex=${el.getAttribute('tabindex')}`); });
  document.querySelectorAll('iframe').forEach((el) => { if (!el.title) add('iframe-title', el.src); });

  document.querySelectorAll('table').forEach((t) => {
    if (!visible(t)) return;
    if (!t.querySelector('caption') && !t.getAttribute('aria-label') && !t.getAttribute('aria-labelledby')) add('table-caption', 'table without a caption or name');
    t.querySelectorAll('thead th').forEach((th) => { if (!th.getAttribute('scope') && !th.getAttribute('colspan')) add('th-scope', `<th>${th.textContent.trim().slice(0, 20)}</th>`); });
  });

  // An attribute whose value begins or ends with a quote character was built through escaped output (&#34;): it is not the value the page meant
  // (this once left the Documents upload form without its multipart encoding, so a real browser sent no file, and left invalid fields unmarked).
  document.querySelectorAll('*').forEach((el) => {
    for (const attr of el.attributes) if (/^["']|["']$|&#34;|&quot;/.test(attr.value)) add('attribute-quotes', `<${el.tagName.toLowerCase()} ${attr.name}=${attr.value}>`);
  });
  document.querySelectorAll('form').forEach((form) => {
    if (form.querySelector('input[type=file]') && form.enctype !== 'multipart/form-data') add('file-form-enctype', `a form with a file field posts as ${form.enctype}: ${form.getAttribute('action')}`);
  });

  const skip = document.querySelector('a.skip-link, a[href="#main"]');
  if (skip && !document.querySelector(skip.getAttribute('href'))) add('skip-target', 'skip link points nowhere');
  return problems;
};

/** Phone touch targets: visible controls smaller than 24x24 CSS px (the WCAG 2.2 minimum), excluding inline text links. */
const TARGET_SCRIPT = () => {
  const small = [];
  document.querySelectorAll('button, input:not([type=hidden]), select, textarea, a.btn, .btn, nav a, .nav__link, [role=button]').forEach((el) => {
    const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
    if (r.width === 0 || r.height === 0 || s.visibility === 'hidden' || s.display === 'none') return;
    if (el.closest('.sidenav') && !document.body.classList.contains('drawer-open')) return;
    if (el.type === 'checkbox' || el.type === 'radio') return; // the label is the target
    if (el.disabled) return;
    // The Giving Board wall is 365 slips in one grid by design; on a phone each slip is ~11px wide. Recorded as an owner decision
    // in docs/ECAQ-PROJECTS-TECHNICAL-AUDIT.md (pinch-zoom works; a redesign is not an overnight call).
    if (el.closest('.board-wall__months')) return;
    if (r.width < 24 || r.height < 24) small.push(`${el.tagName.toLowerCase()}.${String(el.className).trim().split(/\s+/).join('.')} ${Math.round(r.width)}x${Math.round(r.height)}`);
  });
  return small;
};

// Screens a link crawl cannot be relied on to reach: the First Timer lifecycle (Membership Review list and detail, Convert, Link) and the
// Express Registration form. A review is planted for the fixture's First Timer so the detail screen has something to show.
const firstTimer = f.db.prepare('SELECT id FROM visitors WHERE member_id IS NULL ORDER BY id LIMIT 1').get();
let reviewPages = [];
if (firstTimer) {
  const reviewId = Number(f.db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', ?)")
    .run(firstTimer.id, JSON.stringify({ rule: '3 of the last 4 eligible Fridays', visits: 3, fridays: [4, 3, 2, 1].map((n, i) => ({ session_id: n, service_date: `2026-01-0${n}`, visited: i !== 1 })) })).lastInsertRowid);
  reviewPages = ['/visitors/reviews', `/visitors/reviews/${reviewId}`, `/visitors/${firstTimer.id}/convert`, `/visitors/${firstTimer.id}/link`, '/attendance/checkin/first-timer'];
}
const report = { overflow: [], a11y: [], targets: [], clipped: [], runtime: [] };
const pagesChecked = new Set();
try {
  const roles = [
    ['Super Administrator', users.superAdmin, 45, WIDTHS],
    ['Church Administrator', users.churchAdmin, 30, [320, 390, 768, 861, 1280]],
    ['Cell Group Leader', users.leaderA, 25, [320, 390, 768, 861, 1280]],
    ['Member', users.memberA, 20, [320, 390, 768, 861, 1280]]
  ];
  for (const [label, account, limit, widths] of roles) {
    const session = await signIn(portal.base, account.email, f.PASSWORD);
    const pages = dedupe(await crawl(session, { depth: 3, max: 300 }), limit);
    if (label === 'Church Administrator') pages.push(...reviewPages.filter((p) => !pages.includes(p)));
    const cookies = session.cookie.split('; ').map((c) => { const [name, ...rest] = c.split('='); return { name, value: rest.join('='), url: portal.base }; });
    const context = await browser.newContext();
    await context.addCookies(cookies);
    const page = await context.newPage();
    let where = '';
    // Script errors, refused inline code (a Content-Security-Policy violation is a console error) and failed sub-resources.
    page.on('pageerror', (e) => report.runtime.push(`${where}: script error: ${e.message}`));
    page.on('console', (m) => { if (m.type() === 'error') report.runtime.push(`${where}: console error: ${m.text().slice(0, 140)}`); });
    page.on('requestfailed', (r) => report.runtime.push(`${where}: request failed: ${r.url().replace(portal.base, '')}`));
    page.on('response', (r) => { if (r.status() >= 400 && r.request().resourceType() !== 'document') report.runtime.push(`${where}: ${r.status()} for ${r.url().replace(portal.base, '')}`); });
    for (const href of pages) {
      pagesChecked.add(`${label} ${shape(href)}`);
      for (const width of widths) {
        await page.setViewportSize({ width, height: width < 700 ? 800 : 900 });
        where = `${label} ${href} @${width}`;
        const response = await page.goto(portal.base + href, { waitUntil: 'load' });
        assert.ok(response.status() < 400, `${label} ${href} @${width} opens (${response.status()})`);
        const over = await page.evaluate(OVERFLOW_CHECK_SCRIPT);
        if (over.overflow) report.overflow.push(`${label} ${href} @${width}: ${over.scrollWidth}>${over.clientWidth} ${over.offenders.slice(0, 3).map((o) => o.selector).join(' | ')}`);
        if (width === 1280 || width === 390) {
          for (const p of await page.evaluate(A11Y_SCRIPT)) report.a11y.push(`${label} ${href} @${width}: [${p.rule}] ${p.detail}`);
        }
        if (width <= 430 && width >= 390) {
          for (const t of await page.evaluate(TARGET_SCRIPT)) report.targets.push(`${label} ${href} @${width}: ${t}`);
        }
        const clipped = await page.evaluate(() => {
          const main = document.querySelector('main'); if (!main) return null;
          const r = main.getBoundingClientRect();
          return r.left < -1 ? Math.round(r.left) : null;
        });
        if (clipped !== null) report.clipped.push(`${label} ${href} @${width}: main starts at ${clipped}px`);
      }
    }
    await context.close();
  }

  // the Kiosk: overflow only
  const kioskSession = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const kctx = await browser.newContext();
  await kctx.addCookies(kioskSession.cookie.split('; ').map((c) => { const [name, ...rest] = c.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  const kpage = await kctx.newPage();
  for (const width of WIDTHS) {
    await kpage.setViewportSize({ width, height: 800 });
    for (const url of ['/kiosk', '/attendance/checkin/first-timer']) {
      await kpage.goto(`${portal.base}${url}`, { waitUntil: 'domcontentloaded' });
      const over = await kpage.evaluate(OVERFLOW_CHECK_SCRIPT);
      if (over.overflow) report.overflow.push(`Kiosk ${url} @${width}: ${over.scrollWidth}>${over.clientWidth}`);
    }
  }
  await kctx.close();

  const show = (title, list) => console.log(`INFO ${title}: ${list.length}${list.length ? '\n   ' + [...new Set(list)].slice(0, 25).join('\n   ') : ''}`);
  console.log(`INFO ${pagesChecked.size} screens opened across the roles`);
  show('browser errors (script errors, CSP violations, failed or missing files)', report.runtime);
  show('horizontal overflow', report.overflow);
  show('clipped main content', report.clipped);
  show('accessibility problems', report.a11y);
  show('touch targets under 24px on phones', report.targets);
  assert.deepEqual([...new Set(report.runtime)], [], 'no screen raises a script error, a CSP violation or a missing file');
  assert.deepEqual(report.overflow, [], 'no page overflows horizontally at any width');
  assert.deepEqual(report.clipped, [], 'no main content is clipped off the left edge');
  assert.deepEqual(report.a11y, [], 'no accessibility problem on any screen');
  assert.deepEqual(report.targets, [], 'no phone control is smaller than the WCAG 2.2 24px minimum');
  console.log('PASS (deep pass) every reachable screen is free of overflow and of the accessibility problems above, at every design width (320 to 1920)');
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
