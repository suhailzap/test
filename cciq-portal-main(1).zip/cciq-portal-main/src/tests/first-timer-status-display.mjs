import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Physical-test corrections on the First Timer screens (no policy is decided here):
 *   - "Came on their own" is DISPLAY TEXT for a NULL inviter. It is never a member, never a stored name, never searchable as a name, never a row
 *     in an inviter table or a report.
 *   - First visit / Came back is DERIVED from the recorded visits. The manual "Outcome / What happened" control is gone; what remains is an
 *     explicit administrative decision (Has not returned, Not continuing, or Active = back to the visits). Becoming a member happens only
 *     through Convert or Link, never from the number of visits.
 *   - The detail page has a Back to the list (with the list's search / filter / sort / page) that can never be turned into an open redirect.
 *   - The "Who is inviting people" table is one real table: headings and numbers share columns and alignment.
 */

const f = await buildPortalFixture('cciq-ft-display-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const today = mods.dates.today();
const past = (n) => mods.dates.addDays(today, -n);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const text = async (url, who = admin) => (await who.get(url)).text();
const strip = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&#39;/g, "'").replace(/\s+/g, ' ');
const make = (first, last, extra = {}) => mods.visitors.createVisitor({ first_name: first, last_name: last, first_visit_date: past(21), ...extra }, { userId: users.churchAdmin.id });

try {
  // ---- 1. NULL inviter, "Came on their own" ----------------------------------------------------------------------------------------------
  const solo = make('Solo', 'Walker');
  const invited = make('Invited', 'Guest', { invited_by_member_id: ids.member.a2 });
  const named = make('Named', 'Guest', { invited_by_name: 'Pastor Elsewhere' });
  assert.equal(db.prepare('SELECT invited_by_member_id, invited_by_name FROM visitors WHERE id = ?').get(solo.id).invited_by_member_id, null, 'NULL is what is stored');
  const membersBefore = count('SELECT COUNT(*) n FROM members');
  {
    const list = strip(await text('/visitors?q=Walker'));
    assert.match(list, /Solo Walker/); assert.match(list, /Came on their own/, 'the list prints a NULL inviter as "Came on their own"');
    const detail = strip(await text(`/visitors/${solo.id}`));
    assert.match(detail, /Invited by Came on their own/, 'the detail page prints it too');
    assert.doesNotMatch(strip(await text(`/visitors/${invited.id}`)), /Came on their own/, 'someone with an inviter is not shown it');
    assert.doesNotMatch(strip(await text(`/visitors/${named.id}`)), /Came on their own/, 'nor someone with a written inviter name');
    assert.match(strip(await text(`/visitors/${named.id}`)), /Pastor Elsewhere/);
    // it is not a member, a stored name or a search term
    assert.equal(count('SELECT COUNT(*) n FROM members'), membersBefore, 'no member was invented');
    assert.equal(count("SELECT COUNT(*) n FROM members WHERE first_name LIKE '%own%' AND last_name LIKE '%their%'"), 0);
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE invited_by_name LIKE '%Came on%'"), 0, 'the phrase is never stored as a name');
    for (const q of ['Came on their own', 'came on', 'on their own']) {
      const found = strip(await text(`/visitors?q=${encodeURIComponent(q)}`));
      assert.doesNotMatch(found, /Solo Walker|Invited Guest/, `searching "${q}" does not return everyone who came on their own`);
    }
    assert.equal(mods.visitors.listVisitors({ search: 'own' }).rows.filter((r) => r.id === solo.id).length, 0, 'the service search does not match the display phrase either');
    // reports and inviter tables list real members only
    const summary = mods.visitors.inviterSummary({ pageSize: 100 });
    assert.ok(summary.rows.every((r) => db.prepare('SELECT 1 FROM members WHERE id = ?').get(r.id)), 'every inviter row is a real member');
    const followUp = strip(await text('/visitors/follow-up'));
    assert.doesNotMatch(followUp, /Came on their own/, 'the inviter table has no "Came on their own" row');
    const report = mods.visitors.firstTimersReportData({});
    assert.ok(report.inviters.every((r) => typeof r.id === 'number' && db.prepare('SELECT 1 FROM members WHERE id = ?').get(r.id)), 'the report\'s inviter list holds only members');
    const pdf = await admin.get('/reports/first-timers/pdf'); assert.equal(pdf.status, 200); assert.doesNotMatch(Buffer.from(await pdf.arrayBuffer()).toString('latin1'), /Came on their own/, 'nor does the PDF');
    // Express Registration: no inviter chosen is NULL as well
    const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
    const reg = await kiosk.post('/attendance/checkin/first-timer', { first_name: 'Express', last_name: 'Alone', kiosk: '1' }, { csrfFrom: '/kiosk' }); await reg.text();
    assert.equal(reg.status, 302);
    const expressAlone = db.prepare("SELECT id, invited_by_member_id, invited_by_name FROM visitors WHERE first_name = 'Express'").get();
    assert.deepEqual([expressAlone.invited_by_member_id, expressAlone.invited_by_name], [null, null]);
    assert.match(strip(await text(`/visitors/${expressAlone.id}`)), /Came on their own/, 'and the administrative page prints it as such');
    console.log('PASS (1) "Came on their own" is display text for NULL: list, detail and mobile list show it; it is never a member, a stored name, a search match, an inviter row, a report row or in the PDF');
  }

  // ---- 2. First visit / Came back are derived; the Outcome control is gone --------------------------------------------------------------
  {
    const person = make('Derived', 'Status');
    const pill = async () => /pill pill--\w+">\s*([^<]+?)\s*<\/span>\s*·\s*first visited/.exec(await text(`/visitors/${person.id}`))?.[1];
    assert.equal(await pill(), 'First visit', 'one visit: First visit');
    let page = await text(`/visitors/${person.id}`);
    assert.doesNotMatch(page, /What happened/); assert.doesNotMatch(page, /<h2>Outcome<\/h2>/); assert.doesNotMatch(page, /Save outcome/, 'the old Outcome card is gone');
    const select = /<select id="state"[\s\S]*?<\/select>/.exec(page)[0];
    assert.deepEqual([...select.matchAll(/<option value="([^"]*)"/g)].map((m) => m[1]), ['active', 'not_returned', 'declined'], 'only explicit decisions are offered');
    assert.match(page, /First visit and Came back follow the recorded visits/);
    const visit = await admin.post(`/visitors/${person.id}/visits`, { visit_date: past(14) }, { csrfFrom: `/visitors/${person.id}` }); await visit.text();
    assert.equal(await pill(), 'Came back', 'a second recorded visit: Came back');
    page = await text(`/visitors/${person.id}`);
    assert.match(page, /<strong>Came back<\/strong>/, 'the timeline says Came back for the later visit');
    const list = strip(await text('/visitors?q=Derived')); assert.match(list, /Came back/); assert.match(list, /Derived Status/);
    assert.match(strip(await text('/visitors?state=returning')), /Derived Status/, 'filtering by Came back finds them');
    assert.doesNotMatch(strip(await text('/visitors?state=new')), /Derived Status/);
    // a hand-chosen derived value is refused; a decision is recorded and can be handed back to the visits
    for (const forged of ['new', 'returning', 'joined', 'nonsense']) {
      const res = await admin.post(`/visitors/${person.id}/state`, { state: forged }, { csrfFrom: `/visitors/${person.id}` }); await res.text();
      assert.equal(res.status, 400, `"${forged}" cannot be chosen`);
    }
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(person.id).state, 'returning');
    await (await admin.post(`/visitors/${person.id}/state`, { state: 'declined' }, { csrfFrom: `/visitors/${person.id}` })).text();
    assert.equal(await pill(), 'Not continuing', 'an explicit decision is shown as itself');
    // more visits do not silently override the decision (the owner decides what a Not-continuing person who attends means)
    await (await admin.post(`/visitors/${person.id}/visits`, { visit_date: past(7) }, { csrfFrom: `/visitors/${person.id}` })).text();
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(person.id).state, 'declined', 'current behaviour unchanged: a decision stands until someone changes it');
    await (await admin.post(`/visitors/${person.id}/state`, { state: 'active' }, { csrfFrom: `/visitors/${person.id}` })).text();
    assert.equal(await pill(), 'Came back', 'Active hands the status back to the visits (three visits: Came back)');
    const states = db.prepare("SELECT detail FROM audit_logs WHERE action = 'visitor.state_changed' AND entity_id = ? ORDER BY id").all(String(person.id)).map((r) => JSON.parse(r.detail));
    assert.deepEqual(states.map((s) => [s.to, s.chosen]), [['declined', 'declined'], ['returning', 'active']], 'each decision is audited, with what was chosen and what it became');
    // a person who lapsed and then visits is Came back (unchanged)
    const lapsed = make('Lapsed', 'Visitor'); db.prepare("UPDATE visitors SET state = 'not_returned' WHERE id = ?").run(lapsed.id);
    await (await admin.post(`/visitors/${lapsed.id}/visits`, { visit_date: past(3) }, { csrfFrom: `/visitors/${lapsed.id}` })).text();
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(lapsed.id).state, 'returning');
    // many visits never make anyone a member
    const regular = make('Regular', 'Attender');
    for (const n of [70, 63, 56, 49, 42, 35, 28]) await (await admin.post(`/visitors/${regular.id}/visits`, { visit_date: past(n) }, { csrfFrom: `/visitors/${regular.id}` })).text();
    const afterMany = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(regular.id);
    assert.deepEqual(afterMany, { state: 'returning', member_id: null }, 'eight visits: still a First Timer, not a member');
    assert.ok(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', regular.id) >= 8);
    assert.match(await text(`/visitors/${regular.id}`), /Make them a member/, 'becoming a member is still the explicit Convert action');
    assert.match(await text(`/visitors/${regular.id}`), /Link to an existing member/, 'or the explicit Link action');
    // Convert is the only way in; the status control stays read-only afterwards
    const conv = await admin.post(`/visitors/${regular.id}/convert`, { first_name: 'Regular', last_name: 'Attender', date_joined: today }, { csrfFrom: `/visitors/${regular.id}/convert` }); await conv.text();
    assert.equal(conv.status, 302);
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(regular.id).state, 'joined');
    const settled = await admin.post(`/visitors/${regular.id}/state`, { state: 'declined' }, { csrfFrom: `/visitors/${regular.id}` }); await settled.text();
    assert.equal(settled.status, 409, 'a member\'s status cannot be changed by hand');
    assert.equal(mods.visitors.getVisitor(regular.id).display_state, 'joined');
    console.log('PASS (2) First visit / Came back follow the recorded visits; the Outcome control is gone; only explicit decisions can be recorded and handed back; many visits never make a member; Convert and Link stay the only way');
  }

  // ---- 3. Back to First Timers ------------------------------------------------------------------------------------------------------------
  {
    const target = make('Back', 'Navigator');
    const backOf = (html) => /<a class="btn btn--secondary" href="([^"]*)" data-back-to-list>/.exec(html)?.[1];
    const fresh = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
    assert.equal(backOf(await text(`/visitors/${target.id}`, fresh)), '/visitors', 'with no list visited, Back goes to the list');
    const listUrl = '/visitors?q=Navigator&state=new&sort=name&dir=asc&page_size=50';
    await (await fresh.get(listUrl)).text();
    const detailHtml = await text(`/visitors/${target.id}`, fresh);
    assert.equal(backOf(detailHtml)?.replace(/&amp;/g, '&'), listUrl, 'Back returns to the list as it was left: search, filter, sort and page size');
    assert.match(detailHtml, /<li><a href="\/visitors">First Timers<\/a><\/li>/, 'the breadcrumb is unchanged');
    // it survives saving something on the page
    await (await fresh.post(`/visitors/${target.id}/follow-up`, { follow_up_state: 'contacted' }, { csrfFrom: `/visitors/${target.id}` })).text();
    assert.equal(backOf(await text(`/visitors/${target.id}`, fresh))?.replace(/&amp;/g, '&'), listUrl, 'and still points there after a save');
    // a forged address can neither be stored nor followed
    for (const evil of ['//evil.example/x', '/visitors/../../admin', '/\\evil.example', 'https://evil.example', '/members?x=1', '/visitors?q=<script>']) {
      await (await fresh.get(`/visitors?back=${encodeURIComponent(evil)}`)).text();
      await (await fresh.get(`/visitors/${target.id}?back=${encodeURIComponent(evil)}`)).text();
      const href = backOf(await text(`/visitors/${target.id}`, fresh))?.replace(/&amp;/g, '&');
      assert.match(href, /^\/visitors(\?[A-Za-z0-9_=&%.+~*-]*)?$/, `a forged back value (${evil}) leaves Back pointing inside /visitors`);
      assert.doesNotMatch(href, /evil|admin|<script|members/);
    }
    // only the list itself can set it: a detail, edit or search page visit never rewrites it
    await (await fresh.get('/visitors?q=Zzz%3Cb%3E')).text();
    const markup = backOf(await text(`/visitors/${target.id}`, fresh)) || '';
    assert.equal(markup, '/visitors?q=Zzz%3Cb%3E', 'a search containing markup is kept only in its percent-encoded form');
    assert.doesNotMatch(markup, /<b>/);
    console.log('PASS (3) Back to First Timers keeps the list\'s search/filter/sort/page, survives a save, leaves the breadcrumb alone and cannot be turned into an open redirect');
  }

  // ---- 4. the detail page is compact and complete ---------------------------------------------------------------------------------------
  {
    const html = await text(`/visitors/${invited.id}`);
    assert.match(html, /<div class="ft-detail">/, 'cards sit in one compact grid');
    const cards = [...html.matchAll(/<div class="card__head">\s*<h2>([^<]+)<\/h2>/g)].map((m) => m[1]);
    assert.deepEqual(cards, ['Contact and background', 'Visits', 'Follow-up', 'Administrative status'], 'the same information, one fewer manual control');
    assert.doesNotMatch(html, /u-mt-18/, 'no extra stacked card rows');
    console.log('PASS (4) the detail page keeps Contact, Visits, Follow-up and the explicit administrative status in one compact grid');
  }

  // ---- 5. the inviter table is one real table ------------------------------------------------------------------------------------------
  {
    for (const [first, n] of [['Alpha', 1], ['Beta', 12], ['Gamma', 0]]) {
      const inviter = mods.members.createMember({ first_name: `Inviter${first}`, last_name: 'Table' }, { status: 'active' });
      for (let i = 0; i < n; i += 1) make(`Guest${first}${i}`, 'Of', { invited_by_member_id: inviter.id });
      if (n === 0) { const g = make(`Guest${first}`, 'Joined', { invited_by_member_id: inviter.id }); db.prepare("UPDATE visitors SET state = 'declined' WHERE id = ?").run(g.id); }
    }
    const html = await text('/visitors/follow-up?isize=100');
    const table = /<table class="data inviter-table">[\s\S]*?<\/table>\s*<\/div>\s*<div class="pager|<table class="data inviter-table">[\s\S]*<\/table>/.exec(html)[0];
    assert.doesNotMatch(table, /<details/, 'no details/summary layout trick: ordinary table rows');
    const headRow = /<thead>\s*<tr>([\s\S]*?)<\/tr>/.exec(table)[1];
    const heads = [...headRow.matchAll(/<th scope="col"( class="numeric")?/g)].map((m) => Boolean(m[1]));
    assert.deepEqual(heads, [false, true, true, true, true], 'the four number headings are numeric (right-aligned) like their cells');
    const mainRows = [...table.matchAll(/<tr class="inviter-main">([\s\S]*?)<\/tr>/g)].map((m) => m[1]);
    assert.ok(mainRows.length >= 3);
    for (const row of mainRows) {
      const cells = [...row.matchAll(/<td( class="numeric")?/g)].map((m) => Boolean(m[1]));
      assert.deepEqual(cells, [false, true, true, true, true], 'every row has the same five columns, four numeric');
    }
    assert.match(table, /<colgroup>/, 'the columns are declared once, for the heading and every row');
    assert.match(table, /<span class="sort-arrow" aria-hidden="true">/, 'the sort arrow is a slot of its own');
    const details = [...table.matchAll(/<tr class="inviter-detail" id="invitees-(\d+)">/g)];
    assert.equal(details.length, mainRows.length, 'each inviter has an invitee row, open without scripting');
    assert.ok(!/<tr class="inviter-detail"[^>]*hidden/.test(table), 'and it is not hidden by the server (scripting folds it)');
    assert.match(table, /data-inviter-toggle[^>]*aria-expanded="true"[^>]*aria-controls="invitees-\d+" hidden/, 'the toggle appears only when scripting is on');
    console.log('PASS (5) the inviter table is one ordinary table: five declared columns, four numeric in heading and cell, the arrow in its own slot, invitees open without scripting');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
