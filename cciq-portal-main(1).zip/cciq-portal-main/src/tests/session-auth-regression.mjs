import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal } from './lib/portal-fixture.mjs';

/*
 * Sign-in, session and sign-out regression: a fresh session id at every sign-in (no fixation), HttpOnly SameSite cookies, sign-out
 * that really ends the session on the server, no open redirect through ?next=, one wording for "no such user" and "wrong
 * password", lock-out after repeated failures, and a forced password change that really confines the account.
 * (Deeper cases - security generation races, deactivation, kiosk lifetimes - live in their own suites.)
 */

const f = await buildPortalFixture('cciq-session-auth-');
const { db, users } = f;
let portal = await startPortal();
let base = portal.base;
const setCookies = (res) => res.headers.getSetCookie();
const jar = (res, prior = '') => { const fresh = setCookies(res).map((c) => c.split(';')[0]); return fresh.length ? fresh.join('; ') : prior; };

async function loginPage(cookie = '') {
  const page = await fetch(`${base}/login`, { headers: { cookie } });
  const html = await page.text();
  return { csrf: (html.match(/name="_csrf" value="([^"]+)"/) || [])[1], cookie: jar(page, cookie), res: page };
}
async function attempt(email, password, { next = '', cookie = '', csrf } = {}) {
  const page = csrf ? { csrf, cookie } : await loginPage(cookie);
  const body = new URLSearchParams({ email, password, _csrf: page.csrf });
  if (next) body.set('next', next);
  const res = await fetch(`${base}/login`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded', cookie: page.cookie }, body });
  return { res, text: res.status === 401 ? await res.text() : (await res.arrayBuffer(), ''), cookie: jar(res, page.cookie), pre: page.cookie };
}

try {
  // ---- cookie flags and session fixation -------------------------------------------------------------------------------------
  const first = await loginPage();
  const cookieHeader = setCookies(first.res).join('\n');
  assert.match(cookieHeader, /HttpOnly/i, 'the session cookie is HttpOnly');
  assert.match(cookieHeader, /SameSite=(Lax|Strict)/i, 'and SameSite');
  assert.doesNotMatch(cookieHeader, /;\s*Secure/i, 'not Secure while SECURE_COOKIES is off (http://localhost must keep working)');
  const before = first.cookie;
  const ok = await attempt(users.memberA.email, f.PASSWORD, { cookie: before, csrf: first.csrf });
  assert.equal(ok.res.status, 302);
  assert.notEqual(ok.cookie, before, 'signing in issues a new session id');
  const old = await fetch(`${base}/`, { headers: { cookie: before }, redirect: 'manual' }); await old.arrayBuffer();
  assert.equal(old.status, 302, 'the pre-login session id does not become a signed-in session');
  assert.match(old.headers.get('location'), /^\/login/);
  const inside = await fetch(`${base}/`, { headers: { cookie: ok.cookie }, redirect: 'manual' }); const insideBody = await inside.text();
  assert.equal(inside.status, 200);
  assert.match(inside.headers.get('cache-control') || '', /no-store/, 'signed-in pages are not cached (Back after sign-out shows nothing)');
  console.log('PASS (session) HttpOnly + SameSite cookie; a new id at sign-in; the old id stays signed out; signed-in pages are no-store');

  // ---- sign-out -----------------------------------------------------------------------------------------------------------------
  const getLogout = await fetch(`${base}/logout`, { headers: { cookie: ok.cookie }, redirect: 'manual' }); await getLogout.arrayBuffer();
  assert.ok(getLogout.status === 404 || getLogout.status === 405, `GET /logout does not sign anyone out (${getLogout.status})`);
  const tokenless = await fetch(`${base}/logout`, { method: 'POST', headers: { cookie: ok.cookie, 'content-type': 'application/x-www-form-urlencoded' }, body: '', redirect: 'manual' }); await tokenless.arrayBuffer();
  assert.equal(tokenless.status, 403, 'a cross-site POST cannot sign someone out (token required)');
  const csrf = insideBody.match(/name="_csrf" value="([^"]+)"/)[1];
  const out = await fetch(`${base}/logout`, { method: 'POST', headers: { cookie: ok.cookie, 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: csrf }), redirect: 'manual' }); await out.arrayBuffer();
  assert.equal(out.status, 302); assert.match(out.headers.get('location'), /\/login/);
  const replay = await fetch(`${base}/`, { headers: { cookie: ok.cookie }, redirect: 'manual' }); await replay.arrayBuffer();
  assert.equal(replay.status, 302, 'the cookie from before sign-out no longer works');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM sessions WHERE sess LIKE ?").get(`%"userId":${users.memberA.id}%`).n, 0, 'and the server-side session row is gone');
  assert.ok(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE '%logout%'").get().n >= 1, 'sign-out is audited');
  console.log('PASS (sign-out) GET does nothing, a tokenless POST is refused, a real sign-out destroys the server-side session and is audited');

  // ---- open redirect through next ---------------------------------------------------------------------------------------------------
  for (const evil of ['//evil.example', '/\\evil.example', 'https://evil.example', 'javascript:alert(1)', '/\t/evil.example', ' //evil.example', '///evil.example', 'http:evil.example', '/%0d%0aSet-Cookie:x=1']) {
    const r = await attempt(users.memberB.email, f.PASSWORD, { next: evil });
    assert.equal(r.res.status, 302, `sign-in works with next=${JSON.stringify(evil)}`);
    const location = r.res.headers.get('location');
    assert.ok(location === '/' || (location.startsWith('/') && !location.startsWith('//') && !/evil/.test(location)), `next=${JSON.stringify(evil)} does not leave the site (went to ${location})`);
  }
  const good = await attempt(users.memberB.email, f.PASSWORD, { next: '/members/birthdays?x=1' });
  assert.equal(good.res.headers.get('location'), '/members/birthdays?x=1', 'a genuine deep link is honoured');
  const page = await fetch(`${base}/login?next=${encodeURIComponent('//evil.example')}`); const pageHtml = await page.text();
  assert.doesNotMatch(pageHtml, /value="\/\/evil\.example"/, 'and an unsafe next is not even carried into the form');
  console.log('PASS (redirect) nine hostile ?next= values never leave the site; a real deep link is honoured');

  // ---- the per-device sign-in limiter answers plainly -------------------------------------------------------------------------------------
  let limited = null;
  for (let i = 0; i < 30 && !limited; i += 1) {
    const r = await attempt('nobody@fixture.invalid', 'whatever-password-1!');
    if (r.res.status === 429) limited = r;
  }
  assert.ok(limited, 'repeated sign-in attempts from one device are eventually limited (429)');
  const lp = await loginPage();
  const limitedPage = await fetch(`${base}/login`, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded', cookie: lp.cookie }, body: new URLSearchParams({ email: 'a', password: 'b', _csrf: lp.csrf }) });
  const limitedBody = await limitedPage.text();
  assert.equal(limitedPage.status, 429);
  assert.match(limitedBody, /Too many sign-in attempts/i, 'in plain words');
  assert.doesNotMatch(limitedBody, /node_modules|at Object|stack/i);
  console.log('PASS (limiter) repeated sign-in attempts from one device get a plain 429');
  await portal.stop();
  portal = await startPortal();
  base = portal.base; // a fresh server, and a fresh limiter, for the lock-out checks

  // ---- wording, lock-out ---------------------------------------------------------------------------------------------------------------
  const unknown = await attempt('nobody@fixture.invalid', 'whatever-password-1!');
  const wrong = await attempt(users.memberA.email, 'definitely-the-wrong-one-1!');
  assert.equal(unknown.res.status, 401); assert.equal(wrong.res.status, 401);
  const message = (t) => (t.match(/class="[^"]*(?:alert|error|notice)[^"]*"[^>]*>([\s\S]*?)<\//) || [])[1]?.trim();
  assert.equal(message(unknown.text), message(wrong.text), 'an unknown user and a wrong password get the same message');
  assert.ok(message(wrong.text), 'and a message is shown');
  assert.ok(!/password.{0,30}incorrect|no such user|not found|unknown/i.test(unknown.text + wrong.text), 'neither says which half was wrong');

  for (let i = 0; i < 8; i += 1) await attempt(users.memberB.email, `wrong-${i}-password-xx!`);
  const locked = await attempt(users.memberB.email, f.PASSWORD);
  assert.equal(locked.res.status, 401, 'after repeated failures even the right password is refused for a while');
  assert.match(locked.text, /Too many failed attempts/i);
  assert.equal(db.prepare('SELECT failed_attempts n FROM users WHERE id = ?').get(users.memberB.id).n >= 8, true);
  const audits = db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE '%login%fail%' OR action = 'auth.login_failed'").get().n;
  assert.ok(audits >= 9, `failed sign-ins are audited (${audits})`);
  assert.ok(!/wrong-\d-password/.test(JSON.stringify(db.prepare('SELECT detail FROM audit_logs').all())), 'and the audit log never contains the password that was tried');
  console.log('PASS (wording + lock-out) one message for unknown user / wrong password; the 9th attempt is locked out even with the right password; failures are audited without the password');

  // ---- forced password change confines the account ---------------------------------------------------------------------------------------
  db.prepare('UPDATE users SET must_change_password = 1 WHERE id = ?').run(users.leaderB.id);
  const forced = await attempt(users.leaderB.email, f.PASSWORD);
  assert.equal(forced.res.headers.get('location'), '/account/password', 'the account is sent straight to the password page');
  for (const p of ['/', '/members', '/attendance', '/admin/users', '/documents']) {
    const r = await fetch(`${base}${p}`, { headers: { cookie: forced.cookie }, redirect: 'manual' }); await r.arrayBuffer();
    assert.ok(r.status === 302 && /account\/password/.test(r.headers.get('location') || ''), `${p} is closed until the password is changed (${r.status} ${r.headers.get('location')})`);
  }
  const allowed = await fetch(`${base}/account/password`, { headers: { cookie: forced.cookie }, redirect: 'manual' }); await allowed.arrayBuffer();
  assert.equal(allowed.status, 200, 'but the password page itself opens');
  console.log('PASS (forced change) an account that must change its password is sent there and cannot open anything else until it does');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
