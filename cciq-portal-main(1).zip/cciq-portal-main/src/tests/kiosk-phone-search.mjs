import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The Attendance Kiosk (and the desk) say "Name or mobile number". A whole mobile number must find the people who have it, whichever shape either side was written in.
 *
 * History: the number search only ever looked at First Timers, so typing a member's whole number (+97477017992) answered "No one found" while the portal's own search
 * found them. Now:
 *   - ONE canonical phone key (lib/phone.js): digits only, a leading 00 dropped, Qatar's 974 dropped before an eight-digit number, so +974 7701 7992, +97477017992,
 *     97477017992, 0097477017992 and 77017992 are the same number; a stored field holding two numbers ("7788 9900 / +974 6600 1100") counts both;
 *   - members of ANY status and First Timers not yet linked to a member are found; a number shared by a household returns EVERYONE who has it;
 *   - still the WHOLE number only (a fragment finds nothing), the stored number is never shown (only its last four digits), the typed number is never echoed back
 *     or placed in an address, and nothing about status or standing is shown.
 */

const f = await buildPortalFixture('cciq-kiosk-phone-');
const { db, ids, users, mods } = f;
const attendance = await import('../services/attendance.js');
const make = (first, phone, status = 'active') => mods.members.createMember({ first_name: first, last_name: 'Phonetest', phone }, { status }).id;
const marcus = make('Marcus', '+97477017992');
const reginald = make('Reginald', '+97477017992');
const spaced = make('Spaced', '+974 5500 1122');
const twoNumbers = make('Twonum', '7788 9900 / +974 6600 1100');
const gone = make('Gonemover', '+974 3300 4400', 'inactive');
const away = make('Awayfar', '+974 3300 5511', 'migrated');
const foreign = make('Foreigner', '+63 917 123 4567');
const nobody = make('Nophone', null);
const visitor = mods.visitors.createVisitor({ first_name: 'Vivian', last_name: 'Visitphone', phone: '+974 5551 9999', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
const linkedVisitor = mods.visitors.createVisitor({ first_name: 'Linkedv', last_name: 'Visitphone', phone: '+974 5552 0000', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
mods.visitors.linkVisitorToMember(linkedVisitor.id, ids.member.free, { userId: users.churchAdmin.id });

const names = (rows) => rows.map((r) => r.name.split(' ')[0]).sort();
const FULL_NUMBERS = ['97477017992', '77017992', '7701 7992', '5500 1122', '55001122', '66001100', '77889900', '33004400', '33005511', '5551 9999'];

// ---- 1. the canonical key, at the service ----------------------------------------------------------------------------------------------------------------------------------------
for (const typed of ['+97477017992', '97477017992', '77017992', '+974 7701 7992', '0097477017992', '7701-7992', '(974) 7701 7992', '+974-7701-7992', ' 77017992 ']) {
  assert.deepEqual(names(attendance.searchPeopleForAttendance(typed)), ['Marcus', 'Reginald'], `"${typed}" finds exactly the two people who share it`);
}
assert.deepEqual(names(attendance.searchPeopleForAttendance('55001122')), ['Spaced'], 'a stored number written with spaces is found by the plain digits');
assert.deepEqual(names(attendance.searchPeopleForAttendance('+974 5500 1122')), ['Spaced']);
assert.deepEqual(names(attendance.searchPeopleForAttendance('77889900')), ['Twonum'], 'the first of two numbers in one field');
assert.deepEqual(names(attendance.searchPeopleForAttendance('+97466001100')), ['Twonum'], 'and the second');
assert.deepEqual(names(attendance.searchPeopleForAttendance('33004400')), ['Gonemover'], 'status-blind: an inactive member who returns can be found');
assert.deepEqual(names(attendance.searchPeopleForAttendance('+974 3300 5511')), ['Awayfar'], 'and one who has migrated');
assert.deepEqual(names(attendance.searchPeopleForAttendance('639171234567')), ['Foreigner'], 'a foreign number is compared as written');
assert.deepEqual(names(attendance.searchPeopleForAttendance('9171234567')), [], 'and is not guessed at from its local part');
assert.deepEqual(names(attendance.searchPeopleForAttendance('55519999')), ['Vivian'], 'a First Timer is found the same way, as before');
assert.deepEqual(names(attendance.searchPeopleForAttendance('+974 5552 0000')), [], 'a First Timer already linked to a member is found as the member, not as a visitor');
for (const unrelated of ['+974 1234 5678', '12345678', '00000000']) assert.deepEqual(attendance.searchPeopleForAttendance(unrelated), [], `an unrelated number "${unrelated}" finds no one`);
for (const fragment of ['7701799', '701799', '+974 7701 799', '7701', '974770']) assert.deepEqual(attendance.searchPeopleForAttendance(fragment), [], `a fragment "${fragment}" is never a number`);
assert.deepEqual(names(attendance.searchPeopleForAttendance('Marcus')), ['Marcus'], 'a name still finds by name');
assert.deepEqual(attendance.searchPeopleForAttendance('Nophone Phonetest').map((r) => r.id), [nobody], 'and a member with no number is still found by name');
console.log('PASS (service) +97477017992, 97477017992, 77017992 and every other written form give the same people; shared numbers return everyone; any member status; whole number only');

// ---- 2. what the result carries ---------------------------------------------------------------------------------------------------------------------------------------------------
{
  const rows = attendance.searchPeopleForAttendance('77017992');
  assert.equal(rows.length, 2); assert.ok(rows.every((r) => r.type === 'member'));
  for (const row of rows) {
    assert.match(row.detail, /•••• 7992$/, 'the last four digits only');
    assert.ok(!/77017992|97477017992/.test(JSON.stringify(row)), 'never the number');
    assert.deepEqual(Object.keys(row).sort(), ['detail', 'id', 'name', 'photoUrl', 'type'], 'no status, phone, email or address field');
  }
  console.log('PASS (privacy, service) a result carries a name, the member code and group, and the last four digits; never the number or the status');
}

// ---- 3. the Kiosk, over HTTP ----------------------------------------------------------------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const csrf = await kiosk.csrf('/kiosk');
  const search = async (client, q, path = '/attendance/checkin/search', from = '/kiosk') => { const res = await client.post(path, { q, kiosk: '1' }, { csrf: client === kiosk ? csrf : undefined, csrfFrom: from }); return { status: res.status, body: await res.text(), location: res.headers.get('location') }; };
  const people = (html) => ['Marcus', 'Reginald', 'Spaced', 'Twonum', 'Gonemover', 'Awayfar', 'Foreigner', 'Vivian', 'Nophone'].filter((n) => new RegExp(`${n} (?:[A-Z]\\w+ )?(?:Phonetest|Visitphone)`).test(html));
  for (const typed of ['+97477017992', '97477017992', '77017992', '+974 7701 7992']) {
    const r = await search(kiosk, typed);
    assert.equal(r.status, 200, `"${typed}" -> ${r.status}`);
    assert.deepEqual(people(r.body), ['Marcus', 'Reginald'], `Kiosk: "${typed}" shows both people who share it`);
    assert.match(r.body, /•••• 7992/, 'masked');
    assert.ok(!/77017992|97477017992/.test(r.body), `Kiosk: the number "${typed}" is nowhere on the page`);
    assert.ok(!new RegExp(`value="[^"]*7701`).test(r.body), 'and is not echoed back into the search box');
    assert.ok(!/(inactive|migrated|bonafide|attendee)/i.test(r.body.replace(/<script[\s\S]*?<\/script>/g, '')), 'no status is shown');
    assert.ok(!/(email|address|date of birth)/i.test(/<main[\s\S]*?<\/main>/.exec(r.body)[0]), 'no other personal field is shown');
  }
  { const r = await search(kiosk, '33004400'); assert.deepEqual(people(r.body), ['Gonemover'], 'Kiosk finds an inactive member'); }
  { const r = await search(kiosk, '5551 9999'); assert.deepEqual(people(r.body), ['Vivian'], 'Kiosk finds a First Timer'); assert.match(r.body, /First Timer/); }
  { const r = await search(kiosk, '+974 1234 5678'); assert.match(r.body, /No one found/); assert.deepEqual(people(r.body), []); assert.ok(!/1234 5678|12345678/.test(r.body), 'an unmatched number is not echoed'); }
  { const r = await search(kiosk, '7701799'); assert.match(r.body, /No one found/, 'a fragment finds no one'); }
  { const r = await search(kiosk, 'Marcus'); assert.deepEqual(people(r.body), ['Marcus']); }
  // the number never travels in an address
  { const res = await kiosk.get('/kiosk?q=%2B97477017992'); const body = await res.text(); assert.ok(res.status === 302 || !/Marcus/.test(body), 'a number in the address is not searched'); }
  // the desk screen (Church Admin) behaves the same
  { const r = await search(church, '+97477017992', '/attendance/checkin/search', '/attendance/checkin'); assert.equal(r.status, 200); assert.deepEqual(people(r.body), ['Marcus', 'Reginald'], 'the desk finds them too'); assert.ok(!/97477017992/.test(r.body)); }
  // choosing from a phone result goes through the ordinary review: the person is recorded exactly as from a name search
  { const res = await kiosk.post('/attendance/checkin/review', { kiosk: '1', person: [`member:${marcus}`] }, { csrf }); const body = await res.text(); assert.equal(res.status, 200); assert.match(body, /Marcus/); assert.ok(!/97477017992|77017992/.test(body)); }
  console.log('PASS (kiosk http) the Kiosk and the desk find the people who share the number, show only the last four digits, no status, never echo the number, and a fragment finds no one');
} finally {
  await portal.stop();
}

// ---- 4. the same rule in the other places that compare phone numbers -----------------------------------------------------------------------------------------------------------
{
  const dup = mods.visitors.findPossibleDuplicates({ first_name: 'Someone', last_name: 'Else', phone: '77017992' });
  assert.deepEqual(dup.map((d) => d.name.split(' ')[0]).sort(), ['Marcus', 'Reginald'], 'First Timer duplicate warnings use the same number rule');
  assert.ok(dup.every((d) => /same phone number/.test(d.reason)));
  const list = mods.members.listMembers({ search: '7701 7992', scope: { type: 'all' }, pageSize: 50 });
  assert.deepEqual(list.rows.map((m) => m.first_name).sort(), ['Marcus', 'Reginald'], 'the Members search finds a number written with spaces by its digits');
  const visitors = mods.visitors.listVisitors({ search: '5551 9999' });
  assert.equal(visitors.rows.length, 1, 'and the First Timers search');
  console.log('PASS (shared rule) First Timer duplicate warnings, the Members search and the First Timers search use the same number rule');
}
console.log('PASS kiosk-phone-search');
