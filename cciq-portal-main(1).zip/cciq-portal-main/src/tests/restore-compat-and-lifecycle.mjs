import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as tar from 'tar';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Pre-go-live batch, items B and C (backup/restore).
 *
 * C. Restore validated a staged backup for SQLite integrity and a users
 *    table, but never asked whether its MIGRATION HISTORY matches what this
 *    version of the application expects. An older (or newer/unrecognised)
 *    backup was therefore accepted, replaced the live database, and the
 *    application then refused to start against it - a restore that ends the
 *    portal. The staged copy is now checked with the same exact-set
 *    compatibility check the application uses at startup, before anything
 *    live is touched, and is never migrated as a side effect.
 *
 * B. After a successful replacement the shared connection is closed. A
 *    failure while merely REPORTING (counting restored files) threw into the
 *    outer catch, which tried to log a failure through the closed connection
 *    and lost the one result that mattered - "restored, restart required".
 *    Once replacement has happened, reporting/cleanup problems can no longer
 *    change the outcome, and nothing logs through the closed connection.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-restore-compat-');

const { migrate, EXPECTED_MIGRATIONS } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember } = await import('../services/members.js');
const { createBackup, restoreBackup } = await import('../services/backups.js');
const { default: db } = await import('../db/index.js');
const { default: Database } = await import('better-sqlite3');
const config = (await import('../config/env.js')).default;

const storageBase = path.resolve(config.storageDir);
fs.mkdirSync(path.join(storageBase, 'members'), { recursive: true });
fs.writeFileSync(path.join(storageBase, 'members', 'marker.txt'), 'version-A');

createMember({ first_name: 'Before', last_name: 'Backup' }, { status: 'active' });

/** Takes a real backup, then rewrites the archived database with `mutate`, keeping the backup row's checksum honest. */
async function makeTamperedBackup(label, mutate) {
  const made = await createBackup({ kind: 'manual', note: `tampered: ${label}` });
  assert.ok(made.ok);
  const archive = path.join(config.backupDir, made.backup.filename);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-tamper-'));
  try {
    await tar.extract({ file: archive, cwd: work });
    const conn = new Database(path.join(work, 'database.sqlite'));
    try { mutate(conn); } finally { conn.close(); }
    for (const suffix of ['-wal', '-shm']) fs.rmSync(path.join(work, `database.sqlite${suffix}`), { force: true });
    const entries = ['manifest.json', 'database.sqlite', ...(fs.existsSync(path.join(work, 'storage')) ? ['storage'] : [])];
    await tar.create({ gzip: true, file: archive, cwd: work, portable: true }, entries);
  } finally {
    fs.rmSync(work, { recursive: true, force: true });
  }
  const bytes = fs.readFileSync(archive);
  db.prepare('UPDATE backups SET checksum = ?, file_size = ? WHERE id = ?')
    .run(crypto.createHash('sha256').update(bytes).digest('hex'), bytes.length, made.backup.id);
  return made.backup.id;
}

function liveState() {
  return {
    members: db.prepare('SELECT COUNT(*) AS n FROM members').get().n,
    migrations: db.prepare('SELECT version FROM schema_migrations ORDER BY version').all().map((r) => r.version),
    marker: fs.readFileSync(path.join(storageBase, 'members', 'marker.txt'), 'utf8')
  };
}
function assertNothingLeftBehind(label) {
  assert.ok(db.open, `${label}: the shared connection must still be open - nothing live was touched`);
  for (const p of [
    `${config.databaseFile}.restore-staged`, `${config.databaseFile}.pre-restore-original`,
    `${config.databaseFile}-wal.pre-restore-original`, path.join(config.backupDir, '.restore-extract'),
    path.join(storageBase, 'members.pre-restore-original')
  ]) {
    assert.ok(!fs.existsSync(p), `${label}: ${p} must not exist after a refused restore`);
  }
}

// A compatible backup taken now, BEFORE the drift below - the one restored
// (successfully) in the item B scenario at the end.
const goodBackup = await createBackup({ kind: 'manual', note: 'compatible fixture' });
assert.ok(goodBackup.ok);

// Drift the live state so "untouched" is distinguishable from "restored".
createMember({ first_name: 'Drifted', last_name: 'AfterBackup' }, { status: 'active' });
fs.writeFileSync(path.join(storageBase, 'members', 'marker.txt'), 'version-B-live');

// --- C. An OLDER backup (missing the newest migration) is refused before
//     anything live is touched. ---
{
  const newest = EXPECTED_MIGRATIONS[EXPECTED_MIGRATIONS.length - 1];
  const id = await makeTamperedBackup('behind', (conn) => {
    conn.prepare('DELETE FROM schema_migrations WHERE version = ?').run(newest);
  });
  const before = liveState();
  const result = await restoreBackup(id, {});
  assert.equal(result.ok, false, 'ITEM C: an older backup must not be restored');
  assert.equal(result.reason, 'incompatible_backup_schema');
  assert.equal(result.schemaReason, 'behind');
  assert.deepEqual(result.missing, [newest], 'the refusal must name exactly what is missing');
  assert.deepEqual(liveState(), before, 'ITEM C: the live database and storage must be untouched');
  assertNothingLeftBehind('behind');
  const logged = db.prepare("SELECT notes FROM backup_restores WHERE status = 'failed' ORDER BY id DESC LIMIT 1").get();
  assert.match(logged.notes, /not compatible/i, 'the refusal is logged through the still-open connection');
  console.log('PASS (Item C): an older backup is refused before replacement, naming the missing migration, with live state untouched');
}

// --- C. A backup with migrations this version does not recognise, and one
//     with no migration history at all, are refused too. ---
{
  const aheadId = await makeTamperedBackup('ahead', (conn) => {
    conn.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES ('9999_from_a_newer_release', ?)").run(new Date().toISOString());
  });
  const before = liveState();
  const ahead = await restoreBackup(aheadId, {});
  assert.equal(ahead.ok, false);
  assert.equal(ahead.reason, 'incompatible_backup_schema');
  assert.equal(ahead.schemaReason, 'ahead');
  assert.deepEqual(ahead.unexpected, ['9999_from_a_newer_release']);
  assert.deepEqual(liveState(), before);
  assertNothingLeftBehind('ahead');

  const emptyId = await makeTamperedBackup('no history', (conn) => {
    conn.prepare('DELETE FROM schema_migrations').run();
  });
  const empty = await restoreBackup(emptyId, {});
  assert.equal(empty.ok, false);
  assert.equal(empty.reason, 'incompatible_backup_schema');
  assert.equal(empty.schemaReason, 'behind', 'an empty history is missing every migration');
  assert.deepEqual(liveState(), before);
  assertNothingLeftBehind('no history');
  console.log('PASS (Item C): unrecognised-newer and history-less backups are refused too, with nothing changed');
}

// --- C. The refused backup was never migrated as a side effect: its archived
//     database still has exactly the history it was made with. ---
{
  const newest = EXPECTED_MIGRATIONS[EXPECTED_MIGRATIONS.length - 1];
  const id = await makeTamperedBackup('behind-again', (conn) => {
    conn.prepare('DELETE FROM schema_migrations WHERE version = ?').run(newest);
  });
  await restoreBackup(id, {});
  const archive = path.join(config.backupDir, db.prepare('SELECT filename FROM backups WHERE id = ?').get(id).filename);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-verify-'));
  try {
    await tar.extract({ file: archive, cwd: work });
    const conn = new Database(path.join(work, 'database.sqlite'), { readonly: true });
    try {
      const has = conn.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = ?').get(newest).n;
      assert.equal(has, 0, 'ITEM C: restore must never silently migrate the backup');
    } finally { conn.close(); }
  } finally { fs.rmSync(work, { recursive: true, force: true }); }
  console.log('PASS (Item C): a refused backup is never migrated by the restore');
}

// --- B. A restore whose post-replacement REPORTING fails (counting restored
//     files) must still report success + restart-required. Runs in a child:
//     a successful restore closes the shared connection for good. ---
db.close();

{
  const script = `
    import fs from 'node:fs';
    import path from 'node:path';
    const { default: db } = await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/db/index.js')).href)});
    const config = (await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/config/env.js')).href)})).default;
    const storageBase = path.resolve(config.storageDir);
    const realReaddirSync = fs.readdirSync;
    let injected = 0;
    // Only AFTER the shared connection is closed (i.e. after replacement)
    // does counting the restored files fail.
    fs.readdirSync = (dir, ...rest) => {
      if (!db.open && String(dir).startsWith(storageBase)) { injected += 1; throw new Error('injected count failure'); }
      return realReaddirSync(dir, ...rest);
    };
    const { restoreBackup } = await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/services/backups.js')).href)});
    let result;
    try { result = await restoreBackup(${goodBackup.backup.id}, {}); } catch (e) { result = { threw: e.message }; }
    process.stdout.write('RESULT_JSON:' + JSON.stringify({ ...result, injected }) + '\\n');
  `;
  const scriptPath = path.join(env.root, 'restore-count-failure-child.mjs');
  fs.writeFileSync(scriptPath, script);
  const proc = spawnSync(process.execPath, [scriptPath], { env: process.env, encoding: 'utf8' });
  const line = proc.stdout.split('\n').find((l) => l.startsWith('RESULT_JSON:'));
  assert.ok(line, `the child must produce a result:\n${proc.stdout}\n${proc.stderr}`);
  const result = JSON.parse(line.slice('RESULT_JSON:'.length));

  assert.equal(result.threw, undefined, `ITEM B: restoreBackup() must not throw after replacement (${result.threw})`);
  assert.ok(result.injected >= 1, 'sanity: the injected reporting failure must actually have been hit');
  assert.equal(result.ok, true, 'ITEM B: a completed replacement is a success even if reporting failed');
  assert.equal(result.processRestartRequired, true, 'ITEM B: restart-required must be preserved');
  assert.equal(result.filesRestored, null, 'the count is reported as unavailable rather than invented');
  assert.ok(result.postReplacementWarnings.some((w) => /file count unavailable/.test(w)), 'the problem stays diagnosable');
  assert.match(proc.stderr, /restored file count could not be determined/, 'and is written to the process log, not the closed database');

  const { checkRecoveryInterlock } = await import('../lib/recovery-interlock.js');
  assert.equal(checkRecoveryInterlock(), null, 'a successful replacement must not raise the recovery interlock');

  const conn = new Database(config.databaseFile, { readonly: true, fileMustExist: true });
  try {
    assert.equal(conn.prepare("SELECT COUNT(*) AS n FROM members WHERE last_name = 'AfterBackup'").get().n, 0,
      'the restored database really is the live one (the post-backup drift is gone)');
    assert.equal(conn.prepare("SELECT COUNT(*) AS n FROM backup_restores WHERE status = 'failed' AND notes LIKE '%injected count failure%'").get().n, 0,
      'no failure was logged for a restore that succeeded');
    assert.ok(conn.prepare("SELECT COUNT(*) AS n FROM backup_restores WHERE status = 'complete'").get().n >= 1,
      'the restored database carries its own record of the restore');
  } finally { conn.close(); }
  assert.equal(fs.readFileSync(path.join(storageBase, 'members', 'marker.txt'), 'utf8'), 'version-A', 'storage was restored too');
  console.log('PASS (Item B): a reporting failure after a completed replacement still yields ok + restart-required, logs nothing through the closed connection, and raises no interlock');
}

env.cleanup();
console.log('ALL PASS');
