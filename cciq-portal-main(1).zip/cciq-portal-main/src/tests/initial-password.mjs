import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * An explicitly configured temporary starting password for NEW ordinary accounts, and everything around it.
 *   - a new Member / Cell Group leader account gets it (hashed like every password), is created "must change", and the first sign-in can do nothing but change it, to a password
 *     that is not the temporary one (nor the one just used);
 *   - administrators (Super Admin, Church Admin), the dedicated Kiosk account, an account with any administrative role, a password RESET, the bootstrap account and every EXISTING
 *     account are untouched: no shared, known password for them;
 *   - the literal is never in the audit log, the sessions table or a page other than the one-time hand-over to the administrator creating the account, and never twice.
 */

const TEMP = `F${crypto.randomBytes(18).toString('base64url').replace(/[x]/gi, 'a')}9!`;
const f = await buildPortalFixture('cciq-initial-pw-', { INITIAL_ACCOUNT_PASSWORD: TEMP });
const { db, ids, users, mods } = f;
const { default: config } = await import('../config/env.js');
const { verifyPassword } = await import('../lib/passwords.js');
const usersService = await import('../services/users.js');
assert.equal(TEMP, config.auth.initialPassword, 'the test-only temporary password is explicitly configured');
const hashOf = (email) => db.prepare('SELECT password_hash FROM users WHERE LOWER(email) = ?').get(email.toLowerCase())?.password_hash;
const row = (email) => db.prepare('SELECT * FROM users WHERE LOWER(email) = ?').get(email.toLowerCase());
const before = JSON.stringify(db.prepare('SELECT id, password_hash, must_change_password, status FROM users ORDER BY id').all());

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const create = async (client, fields, roles) => {
    const token = await client.csrf('/admin/users/new'); const body = new URLSearchParams({ _csrf: token, ...fields }); for (const r of roles) body.append('roles', r);
    const r = await fetch(`${portal.base}/admin/users`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: client.cookie }, body });
    const html = await r.text(); return { status: r.status, location: r.headers.get('location'), html };
  };

  // ---- 1. an ordinary account gets the temporary password and must change it --------------------------------------------------------------------------------------------------------------------
  const made = await create(admin, { email: 'new.member@fixture.invalid', display_name: 'New Member', member_id: String(ids.member.free) }, ['member']);
  assert.equal(made.status, 302, `account created (${made.status})`);
  assert.ok(await verifyPassword(TEMP, hashOf('new.member@fixture.invalid')), 'its password hash is the temporary password');
  assert.equal(row('new.member@fixture.invalid').must_change_password, 1, 'created must-change');
  const leaderMade = await create(admin, { email: 'new.leader@fixture.invalid', display_name: 'New Leader' }, ['cell_group_leader', 'member']);
  assert.equal(leaderMade.status, 302); assert.ok(await verifyPassword(TEMP, hashOf('new.leader@fixture.invalid')), 'a Cell Group leader account too');
  assert.ok(hashOf('new.member@fixture.invalid').length > 40 && !hashOf('new.member@fixture.invalid').includes(TEMP), 'stored only as a hash');
  // the hand-over: shown once to the administrator who created it, never again
  { const reveal = /\/admin\/users\/\d+\?reveal=[\w-]+/.exec(made.location || ''); assert.ok(reveal, 'the creation redirects to a one-time hand-over'); const first = await admin.get(made.location); const page = await first.text(); const second = await admin.get(made.location); const again = await second.text();
    assert.ok(page.includes(TEMP), 'the administrator is shown it once, to pass on'); assert.ok(!again.includes(TEMP), 'and never a second time'); const other = await church.get(made.location); assert.ok(!(await other.text()).includes(TEMP), 'nor to another administrator'); }

  // first sign-in: nothing but the change
  const fresh = await signIn(portal.base, 'new.member@fixture.invalid', TEMP);
  { const home = await fresh.get('/'); await home.text(); assert.equal(home.status, 302); assert.equal(home.headers.get('location'), '/account/password', 'every page sends them to change the password first');
    for (const url of ['/my/profile', '/projects/ecaq', '/documents', '/ministries']) { const r = await fresh.get(url); await r.text(); assert.equal(r.status, 302); assert.equal(r.headers.get('location'), '/account/password', url); }
    const change = (fields) => fresh.post('/account/password', { current_password: TEMP, ...fields }, { csrfFrom: '/account/password' }).then(async (r) => ({ status: r.status, body: await r.text(), location: r.headers.get('location') }));
    let r = await change({ password: TEMP, confirm_password: TEMP }); assert.equal(r.status, 400); assert.match(r.body, /different from the temporary one/, 'the temporary password cannot be kept');
    r = await change({ password: 'short1', confirm_password: 'short1' }); assert.equal(r.status, 400, 'the usual policy still applies');
    r = await change({ password: 'My-Own-Passw0rd!', confirm_password: 'Mismatch-Passw0rd!' }); assert.equal(r.status, 400);
    assert.equal(row('new.member@fixture.invalid').must_change_password, 1, 'still must change after the refusals');
    r = await change({ password: 'My-Own-Passw0rd!', confirm_password: 'My-Own-Passw0rd!' }); assert.equal(r.status, 302, 'a password of their own is accepted');
    assert.equal(row('new.member@fixture.invalid').must_change_password, 0); assert.equal(await verifyPassword(TEMP, hashOf('new.member@fixture.invalid')), false, 'the temporary password no longer works');
    const home2 = await fresh.get('/'); await home2.text(); assert.equal(home2.status, 200, 'and the portal opens'); }
  { const again = await fetch(`${portal.base}/login`); const html = await again.text(); const csrf = html.match(/name="_csrf" value="([^"]+)"/)[1]; const pre = again.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
    const r = await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ email: 'new.member@fixture.invalid', password: TEMP, _csrf: csrf }) }); await r.text(); assert.equal(r.status, 401, 'signing in with the temporary password after the change fails'); }
  console.log('PASS (ordinary accounts) a new Member and a new Cell Group leader start with the temporary password, are created must-change, can only change it at first sign-in (not to the temporary or current one), and it stops working afterwards; it is handed over once, to the creating administrator only');

  // ---- 2. who does NOT get it -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  const notDefault = async (email, roles, label, creator = admin) => { const r = await create(creator, { email, display_name: label }, roles); assert.equal(r.status, 302, `${label} created (${r.status})`); assert.equal(await verifyPassword(TEMP, hashOf(email)), false, `${label} does NOT get the temporary password`); assert.equal(row(email).must_change_password, 1); };
  await notDefault('new.church@fixture.invalid', ['church_admin'], 'Church Admin');
  await notDefault('new.super@fixture.invalid', ['super_admin'], 'Super Admin');
  await notDefault('new.kiosk@fixture.invalid', ['kiosk'], 'Kiosk');
  await notDefault('new.mixed@fixture.invalid', ['member', 'church_admin'], 'Member who is also Church Admin');
  { // the creating form with nothing chosen is refused (no account, no password)
    const none = await create(admin, { email: 'new.none@fixture.invalid', display_name: 'No role' }, []); assert.equal(none.status, 400); assert.equal(row('new.none@fixture.invalid'), undefined); }
  { // a password RESET keeps its own behaviour: generated or typed, never the temporary one
    const target = row('new.leader@fixture.invalid'); const token = await admin.csrf('/account/password');
    const reset = await admin.post(`/admin/users/${target.id}/password`, {}, { csrf: token }); await reset.text(); assert.equal(reset.status, 302);
    assert.equal(await verifyPassword(TEMP, hashOf('new.leader@fixture.invalid')), false, 'a generated reset is random, not the temporary password'); assert.equal(row('new.leader@fixture.invalid').must_change_password, 1); }
  { // the service: administrators, the Kiosk and "no role" are random; an email that contains the password falls back to random (the policy)
    for (const roles of [['super_admin'], ['church_admin'], ['kiosk'], [], ['member', 'kiosk']]) assert.notEqual(usersService.initialPasswordFor(roles, { email: 'x@y.org' }), TEMP, `roles [${roles}] are never given it`);
    assert.equal(usersService.initialPasswordFor(['member'], { email: 'x@y.org' }), TEMP); assert.equal(usersService.initialPasswordFor(['member', 'cell_group_leader'], { email: 'x@y.org' }), TEMP);
    assert.notEqual(usersService.initialPasswordFor(['member'], { email: `${TEMP}@y.org` }), TEMP, 'a value the account\'s own policy rejects is replaced by a random one'); }
  console.log('PASS (exclusions) Church Admin, Super Admin, Kiosk and any account holding an administrative role get a random password; an account with no role is refused; a password reset is unchanged; a value the policy rejects falls back to random');

  // ---- 3. member accounts provisioned from a member record --------------------------------------------------------------------------------------------------------------------------------------------
  { const member = mods.members.getMember(ids.member.a3); const result = await usersService.provisionMemberAccount(member, { createdBy: users.churchAdmin.id });
    assert.equal(result.created, true); assert.equal(result.password, TEMP, 'the account created from a member record starts with it too'); assert.ok(await verifyPassword(TEMP, result.user.password_hash)); assert.equal(result.user.must_change_password, 1);
    const again = await usersService.provisionMemberAccount(member, { createdBy: users.churchAdmin.id }); assert.equal(again.created, false, 'a member who already has an account is not given another'); assert.equal(again.password, null); }

  // ---- 4. existing accounts, bootstrap and Kiosk credentials are untouched ------------------------------------------------------------------------------------------------------------------------------
  { const after = JSON.stringify(db.prepare('SELECT id, password_hash, must_change_password, status FROM users WHERE id IN (' + Object.values(users).map((u) => u.id).join(',') + ') ORDER BY id').all());
    const wasThere = JSON.parse(before).filter((u) => Object.values(users).some((x) => x.id === u.id)); assert.equal(after, JSON.stringify(wasThere), 'every account that existed before is byte-for-byte unchanged (hash, must-change, status)');
    for (const u of Object.values(users)) assert.equal(await verifyPassword(TEMP, hashOf(u.email)), false, `${u.username} does not accept the temporary password`);
    const kiosk = row(users.kiosk.email); assert.equal(kiosk.must_change_password, 0, 'the dedicated Kiosk account still signs in as before'); }
  { // the bootstrap path: createUser itself applies no default (seed and first-run pass their own credential)
    const direct = await usersService.createUser({ username: 'boot_admin', email: 'boot.admin@fixture.invalid', password: 'Bootstrap-Own-Passw0rd!x', displayName: 'Boot', roleKeys: ['super_admin'], mustChangePassword: true });
    assert.ok(direct); assert.equal(await verifyPassword(TEMP, hashOf('boot.admin@fixture.invalid')), false); assert.ok(await verifyPassword('Bootstrap-Own-Passw0rd!x', hashOf('boot.admin@fixture.invalid')), 'a credential supplied to createUser is used exactly as given'); }
  console.log('PASS (untouched) every existing account, the bootstrap/Super Admin path and the Kiosk credentials are exactly as they were; a member who already has an account is not given another');

  // ---- 5. secrecy ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const dump = JSON.stringify(db.prepare('SELECT action, actor_label, entity_id, detail, user_agent FROM audit_logs').all());
    assert.ok(!dump.includes(TEMP), 'the temporary password is nowhere in the audit log');
    const sessions = JSON.stringify(db.prepare("SELECT * FROM sqlite_master WHERE name = 'sessions'").all()) + JSON.stringify(db.prepare('SELECT sess FROM sessions').all().map((r) => r.sess));
    assert.ok(!sessions.includes(TEMP), 'nor in the sessions table');
    const created = db.prepare("SELECT detail FROM audit_logs WHERE action = 'admin.user_created' ORDER BY id DESC").get(); assert.ok(!/password/i.test(created.detail), 'the creation audit row carries no password field'); }
  console.log('PASS (secrecy) the temporary password is never in the audit log or the sessions table, and is shown only once, to the creating administrator');
  console.log('PASS initial-password');
} finally {
  await portal.stop();
}
