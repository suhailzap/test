import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Admin -> Users: server-side pagination (25 default, 25/50/100), search, Role / account status /
 * password-change-due / linked filters, sort, result count and query persistence. The Super Admin
 * protections on these accounts are covered by delegated-admin-super-admin-protection and are
 * not touched by this UX work.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-users-list-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ul${crypto.randomBytes(12).toString('base64url')}9!`;
await users.createUser({ username: 'list_admin', email: 'list.admin@fixture.invalid', password: PASSWORD, displayName: 'AAA List Admin', roleKeys: ['super_admin'], mustChangePassword: false });
const linkedMember = createMember({ first_name: 'Linked', last_name: 'Person' }, { status: 'active' });
for (let i = 1; i <= 62; i += 1) {
  await users.createUser({
    username: `list_user_${i}`, email: `list.user${i}@fixture.invalid`, password: PASSWORD,
    displayName: `List User ${String(i).padStart(2, '0')}`,
    roleKeys: [i % 5 === 0 ? 'cell_group_leader' : 'member'],
    mustChangePassword: i % 7 === 0,
    memberId: i === 3 ? linkedMember.id : null
  });
}
// A disabled account and a temporarily locked-out one.
db.prepare("UPDATE users SET status = 'disabled' WHERE username = 'list_user_10'").run();
db.prepare("UPDATE users SET locked_until = ? WHERE username = 'list_user_11'").run(new Date(Date.now() + 3600_000).toISOString());
const total = db.prepare('SELECT COUNT(*) n FROM users').get().n; // 63

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'list.admin@fixture.invalid', password: PASSWORD, _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const get = async (query = '') => {
    const res = await fetch(`${base}/admin/users${query ? `?${query}` : ''}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, `GET /admin/users?${query}`);
    return res.text();
  };
  const rowsIn = (html) => (html.match(/<tbody>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 1;
  const cardsIn = (html) => (html.match(/class="record-list__item"/g) || []).length;
  const names = (html) => [...html.matchAll(/<td data-label="Account">\s*<a href="\/admin\/users\/\d+">([^<]+)<\/a>/g)].map((m) => m[1]);

  // Pagination: 25 by default, and a result count.
  let html = await get();
  assert.equal(rowsIn(html), 25, 'default page size is 25');
  assert.equal(cardsIn(html), 25, 'and the mobile cards match');
  assert.match(html, new RegExp(`Showing 1&ndash;25 of ${total}`));
  assert.match(html, new RegExp(`${total} accounts`));
  assert.match(html, /rel="next"/);
  assert.doesNotMatch(html, /rel="prev"/);
  html = await get('page=3');
  assert.equal(rowsIn(html), total - 50, 'the last page holds the remainder');
  assert.match(html, /rel="prev"/);
  assert.doesNotMatch(html, /rel="next"/);
  assert.equal(rowsIn(await get('page=99')), total - 50, 'an out-of-range page is clamped to the last page');
  assert.equal(rowsIn(await get('page=abc')), 25, 'a junk page falls back to page 1');
  assert.equal(rowsIn(await get('page_size=50')), 50);
  assert.equal(rowsIn(await get('page_size=100')), total);
  assert.equal(rowsIn(await get('page_size=7')), 25, 'only 25 / 50 / 100 are accepted');
  console.log('PASS (paging) 25 by default; 50 and 100 on request; junk sizes and pages fall back; the count and the last page are right');

  // Filters.
  const names1 = names(await get('q=List+User+07'));
  assert.deepEqual(names1, ['List User 07'], 'search by name');
  assert.equal(names(await get('q=list.user12@fixture')).length, 1, 'search by email');
  assert.equal(names(await get('q=list_user_13')).length, 1, 'search by username');
  const leaders = db.prepare("SELECT COUNT(*) n FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.key = 'cell_group_leader'").get().n;
  html = await get('role=cell_group_leader');
  assert.match(html, new RegExp(`Showing 1&ndash;${leaders} of ${leaders}`), 'role filter');
  assert.equal(rowsIn(await get('role=not_a_role')), 25, 'an unknown role is ignored, not a crash');
  assert.deepEqual(names(await get('status=disabled')), ['List User 10'], 'account status: disabled');
  assert.deepEqual(names(await get('status=locked')), ['List User 11'], 'account status: locked out');
  assert.ok(!names(await get('status=active&page_size=100')).includes('List User 11'), 'a locked-out account is not "active"');
  const due = db.prepare('SELECT COUNT(*) n FROM users WHERE must_change_password = 1').get().n;
  assert.match(await get('password_due=1'), new RegExp(`of ${due}`), 'password change due');
  assert.deepEqual(names(await get('linked=linked')), ['List User 03'], 'linked to a member record');
  assert.match(await get('linked=unlinked'), new RegExp(`of ${total - 1}`), 'not linked');
  assert.match(await get('role=member&status=active&linked=unlinked'), /of \d+/, 'filters combine');
  console.log('PASS (filters) search, role, account status (active/disabled/locked), password change due and linked/unlinked, combinable and safe with junk values');

  // Sorting.
  const asc = names(await get('sort=name&page_size=100'));
  const desc = names(await get('sort=name&dir=desc&page_size=100'));
  assert.equal(asc[0], 'AAA List Admin');
  assert.equal(desc[0], 'List User 62');
  assert.deepEqual([...asc].reverse(), desc, 'descending is the exact reverse');
  assert.equal(names(await get('sort=email&page_size=100')).length, total);
  assert.equal(names(await get('sort=last_login&page_size=100')).length, total, 'sort by last sign-in, never-signed-in last');
  assert.equal(names(await get('sort=DROP+TABLE')).length, 25, 'an unknown sort key falls back safely');
  console.log('PASS (sort) name / email / status / role / last sign-in, both directions; unknown keys are ignored');

  // Query persistence: links and the page-size form carry every choice.
  html = await get('role=member&status=active&sort=email&dir=desc&q=List');
  assert.match(html, /href="\/admin\/users\?[^"]*role=member[^"]*page=2/, 'the Next link keeps the role filter');
  const next = html.match(/href="(\/admin\/users\?[^"]*page=2[^"]*)"/)[1].replaceAll('&amp;', '&');
  for (const part of ['role=member', 'status=active', 'sort=email', 'dir=desc', 'q=List']) assert.ok(next.includes(part), `Next keeps ${part}`);
  assert.match(html, /<input type="hidden" name="role" value="member">/, 'the rows-per-page form keeps the filters');
  assert.match(html, /<input type="hidden" name="sort" value="email">/);
  assert.match(html, /href="\/admin\/users\?[^"]*sort=name[^"]*"/, 'column links keep the filters and re-sort');
  const second = await get(next.replace('/admin/users?', ''));
  assert.match(second, /page 2 of/);
  console.log('PASS (query state) Next, column sorting and rows-per-page all preserve the search, filters, sort and size');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
