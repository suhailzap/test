import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { crawl } from './lib/crawl.mjs';
import { catalogue } from './lib/route-catalogue.mjs';
import { DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions.js';

/*
 * Navigation, from each kind of person's own point of view. Every link a screen offers to a signed-in person is followed (a few hops deep,
 * GET only), and for each role:
 *   - no offered link ends in a 403 (the portal offered something it then refused), a 404 (a dead end) or a server error;
 *   - no link silently bounces back (a redirect to somewhere else than a normal flow): the Kiosk's only screens are its own;
 *   - every state-changing form on any screen the role sees posts to a route the role actually holds the permission for (a control is
 *     never shown that can only fail);
 *   - the new Membership Review and First Timer links appear only for those who may use them.
 */

const f = await buildPortalFixture('cciq-navigation-audit-');
const { db, ids, users, mods } = f;
// give every screen something to link to: a First Timer with an open review, and a few of everything the fixture already holds
const visitor = mods.visitors.createVisitor({ first_name: 'Nav', last_name: 'Walker', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', ?)").run(visitor.id, JSON.stringify({ rule: 'r', visits: 3, fridays: [] }));
const portal = await startPortal();

const toRe = (p) => new RegExp('^' + p.replace(/\\\\/g, '\\').replace(/:\w+(\((?:[^()]|\([^()]*\))*\))?/g, (m, g) => (g || '[^/]+')).replace(/\//g, '\\/') + '$');
const routes = catalogue().map((r) => ({ ...r, re: toRe(r.path) }));
const permsOf = (user) => new Set(user.roleKeys.flatMap((r) => DEFAULT_ROLE_PERMISSIONS[r] || []));
const rolesOf = (user) => new Set(user.roleKeys);
const allowed = (user, route) => {
  const held = permsOf(user);
  if (route.roles.length && !route.roles.some((r) => rolesOf(user).has(r))) return false;
  if (route.all.length && !route.all.every((p) => held.has(p))) return false;
  if (route.any.length && !route.any.some((p) => held.has(p))) return false;
  return true;
};

const problems = [];
let linksFollowed = 0; let formsChecked = 0;
try {
  const cast = [['Super Administrator', users.superAdmin], ['Church Administrator', users.churchAdmin], ['Cell Group Leader', users.leaderA], ['Member', users.memberA], ['Kiosk', users.kiosk]];
  const seenByRole = {};
  for (const [label, user] of cast) {
    const session = await signIn(portal.base, user.email, f.PASSWORD);
    const start = label === 'Kiosk' ? '/kiosk' : '/';
    const pages = await crawl(session, { start, depth: 4, max: 700 });
    seenByRole[label] = pages;
    for (const [href, page] of pages) {
      linksFollowed += 1;
      if (page.status === 403 || page.status === 404 || page.status >= 500) problems.push(`${label}: the link ${href} (offered on ${page.from}) ends in ${page.status}`);
      if (page.status === 302 && !/^\/(logout|login)/.test(href)) {
        // a redirect is only normal for a handful of "entry" links that choose a destination
        const res = await session.get(href); await res.arrayBuffer();
        const to = res.headers.get('location') || '';
        if (label === 'Kiosk' && to === '/kiosk') problems.push(`${label}: the link ${href} (offered on ${page.from}) bounces back to the kiosk: it was offered but is not one of its screens`);
        else if (!/^\/[^/]/.test(to) && to !== '/') problems.push(`${label}: the link ${href} redirects somewhere unexpected (${to})`);
        else if (to === '/' && label !== 'Super Administrator') problems.push(`${label}: the link ${href} (offered on ${page.from}) sends the person to the dashboard instead of where it says`);
      }
      if (page.status !== 200 || !/text\/html/.test(page.type)) continue;
      // forms: each state-changing form posts somewhere this role may post
      for (const form of page.body.matchAll(/<form\b[^>]*method\s*=\s*["']post["'][^>]*>/gi)) {
        const action = (/action\s*=\s*["']([^"']+)["']/.exec(form[0]) || [])[1];
        if (!action || !action.startsWith('/')) continue;
        const target = action.replace(/&amp;/g, '&').split('?')[0];
        if (/^\/(logout|account\/password)/.test(target)) continue;
        const route = routes.find((r) => r.method === 'POST' && r.re.test(target));
        formsChecked += 1;
        if (!route) { problems.push(`${label}: a form on ${href} posts to ${target}, which is not a route`); continue; }
        if (!allowed(user, route)) problems.push(`${label}: ${href} shows a form that posts to ${target}, which this role may not use`);
      }
    }
  }
  // the new links are permissioned: Membership Review only for those who may edit members; First Timer pages only for those who may view them
  const carries = (label, needle, urls) => urls.some((u) => { const p = seenByRole[label].get(u); return p && p.body && p.body.includes(needle); });
  for (const [label, user] of cast) {
    const mayReview = permsOf(user).has('members.edit');
    const offers = [...seenByRole[label].values()].some((p) => p.body && p.body.includes('href="/visitors/reviews"'));
    if (offers !== mayReview) problems.push(`${label}: Membership review is ${offers ? 'offered' : 'not offered'} but the role ${mayReview ? 'may' : 'may not'} use it`);
    const offersExpress = [...seenByRole[label].values()].some((p) => p.body && p.body.includes('/attendance/checkin/first-timer'));
    const mayExpress = permsOf(user).has('visitors.express_register');
    if (offersExpress && !mayExpress) problems.push(`${label}: Express Registration is offered but not permitted`);
    void carries;
  }
  assert.ok(seenByRole['Kiosk'].size <= 12, `the Kiosk is shown only its own handful of screens (${seenByRole['Kiosk'].size})`);
  const adminReviewLink = [...seenByRole['Church Administrator'].values()].some((p) => p.body && p.body.includes('href="/visitors/reviews"'));
  assert.ok(adminReviewLink, 'a Church Administrator is offered the Membership review');
  assert.ok(seenByRole['Super Administrator'].size > 60, `the walk was broad (${seenByRole['Super Administrator'].size} screens for the Super Administrator)`);

  console.log(`INFO ${linksFollowed} links followed and ${formsChecked} state-changing forms checked across five roles (${cast.map(([l]) => `${l}: ${seenByRole[l].size} screens`).join(', ')})`);
  console.log(`INFO ${problems.length} navigation problem(s)${problems.length ? '\n   ' + [...new Set(problems)].slice(0, 40).join('\n   ') : ''}`);
  assert.deepEqual([...new Set(problems)], [], 'no role is offered a link that ends in 403, 404, an error or an unexpected bounce, nor a form it cannot use');
  console.log('PASS (navigation) every link and every form each role is offered works for that role, and the new First Timer links are permissioned correctly');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
