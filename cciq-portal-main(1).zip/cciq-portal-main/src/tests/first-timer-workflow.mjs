import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * The First Timer module as it exists (docs/FIRST-TIMER-WORKFLOW-AUDIT.md) plus the one behaviour added with that audit:
 * a WARN-ONLY duplicate check when registering. Also pins what must NOT exist: no repeat-visit threshold, no automatic
 * promotion, no notification after repeated visits, no kiosk registration, and two role-equivalent Kiosk accounts.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-first-timer-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const attendance = await import('../services/attendance.js');
const { generateReminders } = await import('../services/reminders.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ft${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'ft_admin', email: 'ft.admin@fixture.invalid', password: PASSWORD, displayName: 'FT Admin', roleKeys: ['church_admin'], mustChangePassword: false });
await createUser({ username: 'ft_kiosk_a', email: 'ft.kiosk.a@fixture.invalid', password: PASSWORD, displayName: 'Kiosk A', roleKeys: ['kiosk'], mustChangePassword: false });
await createUser({ username: 'ft_kiosk_b', email: 'ft.kiosk.b@fixture.invalid', password: PASSWORD, displayName: 'Kiosk B', roleKeys: ['kiosk'], mustChangePassword: false });
await createUser({ username: 'ft_member', email: 'ft.member@fixture.invalid', password: PASSWORD, displayName: 'FT Member', roleKeys: ['member'], mustChangePassword: false });
const existingMember = createMember({ first_name: 'Marian', last_name: 'Existing', phone: '+974 5550 1234' }, { status: 'active' });

const FRIDAY = lastFridayOnOrBefore(today());
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(FRIDAY, new Date().toISOString());
const session = db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(FRIDAY);

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function sessionFor(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const admin = await sessionFor('ft.admin@fixture.invalid');
  const kioskA = await sessionFor('ft.kiosk.a@fixture.invalid');
  const kioskB = await sessionFor('ft.kiosk.b@fixture.invalid');
  const plain = await sessionFor('ft.member@fixture.invalid');
  const get = (url, cookie = admin) => fetch(`${base}${url}`, { headers: { Cookie: cookie }, redirect: 'manual' });
  const csrfOf = async (url, cookie = admin) => (await (await get(url, cookie)).text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const post = async (url, fields, { cookie = admin, csrfFrom = '/visitors/new' } = {}) => fetch(`${base}${url}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ _csrf: await csrfOf(csrfFrom, cookie === admin ? admin : admin), ...fields })
  });
  const visitorCount = () => db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
  const memberCount = () => db.prepare('SELECT COUNT(*) n FROM members').get().n;

  // ---- both Kiosk accounts are role-equivalent and cannot register a first timer ----------------
  const permsOf = (username) => db.prepare(`SELECT DISTINCT p.key FROM users u JOIN user_roles ur ON ur.user_id = u.id JOIN role_permissions rp ON rp.role_id = ur.role_id
      JOIN permissions p ON p.id = rp.permission_id WHERE u.username = ? ORDER BY p.key`).all(username).map((r) => r.key);
  const rolesOf = (username) => db.prepare('SELECT r.key FROM users u JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id WHERE u.username = ? ORDER BY r.key').all(username).map((r) => r.key);
  assert.deepEqual(rolesOf('ft_kiosk_a'), rolesOf('ft_kiosk_b'), 'the two Kiosk accounts hold the same roles');
  assert.deepEqual(permsOf('ft_kiosk_a'), permsOf('ft_kiosk_b'), 'and therefore exactly the same permissions');
  assert.deepEqual(permsOf('ft_kiosk_a'), ['attendance.checkin', 'visitors.express_register'], 'which is the check-in permission plus the one narrow Express Registration permission: no member lists, no First Timer administration, no members.create');
  for (const cookie of [kioskA, kioskB]) {
    assert.equal((await get('/kiosk', cookie)).status, 200, 'both reach the kiosk');
    for (const denied of ['/visitors', '/visitors/new', '/visitors/follow-up', '/members']) {
      const res = await get(denied, cookie);
      assert.ok([302, 403].includes(res.status), `${denied} is not open to a Kiosk account (${res.status})`);
      if (res.status === 302) assert.match(res.headers.get('location'), /^\/kiosk/, 'a Kiosk account is sent back to the kiosk');
    }
  }
  const kioskBefore = visitorCount();
  const kioskPost = await fetch(`${base}/visitors`, { method: 'POST', redirect: 'manual', headers: { Cookie: kioskA, 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ first_name: 'Nope' }) });
  assert.ok([302, 403].includes(kioskPost.status));
  assert.equal(visitorCount(), kioskBefore, 'a Kiosk account cannot register a first timer');
  assert.equal((await get('/visitors/new', plain)).status, 403, 'nor can a plain member');
  console.log('PASS (kiosk) both Kiosk accounts are role-equivalent (check-in + express registration only), reach the kiosk, and are refused every First Timer and member screen and the administrative registration route');

  // ---- registering, and the warn-only duplicate check ----------------------------------------------
  const memberBefore = memberCount();
  let res = await post('/visitors', { first_name: 'Grace', last_name: 'Newcomer', phone: '+974 5551 9999', first_visit_date: today() });
  assert.equal(res.status, 302, 'a first timer is recorded');
  const grace = db.prepare("SELECT * FROM visitors WHERE first_name = 'Grace'").get();
  assert.ok(grace);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(grace.id).n, 1, 'with their first visit');
  assert.equal(memberCount(), memberBefore, 'registering creates no member');
  assert.ok(db.prepare("SELECT 1 FROM audit_logs WHERE action = 'visitor.created' AND entity_id = ?").get(String(grace.id)));

  let before = visitorCount();
  res = await post('/visitors', { first_name: 'grace', last_name: 'NEWCOMER', first_visit_date: today() });
  assert.equal(res.status, 200, 'the same name is stopped for a look, not refused');
  let page = await res.text();
  assert.match(page, /id="possible-duplicates"/);
  assert.match(page, /same name/);
  assert.match(page, new RegExp(`href="/visitors/${grace.id}"`), 'it links to the person already on file');
  assert.match(page, />Record anyway</);
  assert.equal(visitorCount(), before, 'nothing is recorded by the warning');

  res = await post('/visitors', { first_name: 'Someone', last_name: 'Else', phone: '974-555-19999', first_visit_date: today() });
  assert.equal(res.status, 200, 'the same phone number is a match even when written differently');
  page = await res.text();
  assert.match(page, /same phone number/);
  assert.equal(visitorCount(), before);

  res = await post('/visitors', { first_name: 'Marian', last_name: 'Existing', first_visit_date: today() });
  assert.equal(res.status, 200);
  page = await res.text();
  assert.match(page, new RegExp(`href="/members/${existingMember.id}"`), 'a member with the same name is offered too');
  assert.match(page, /Member CCIQ-/);
  assert.equal(visitorCount(), before);

  res = await post('/visitors', { first_name: 'Marian', last_name: 'Existing', first_visit_date: today(), duplicate_override: '1' });
  assert.equal(res.status, 302, '"Record anyway" records them');
  assert.equal(visitorCount(), before + 1);
  const overridden = db.prepare("SELECT id FROM visitors WHERE first_name = 'Marian'").get();
  assert.match(db.prepare("SELECT detail FROM audit_logs WHERE action = 'visitor.created' AND entity_id = ?").get(String(overridden.id)).detail, /"duplicate_warning_overridden":true/, 'the override is audited');

  res = await post('/visitors', { first_name: 'Unique', last_name: 'Person', phone: '+974 5550 0001', first_visit_date: today() });
  assert.equal(res.status, 302, 'a person who matches nobody is recorded straight away');
  const nothing = findNone();
  function findNone() { return visitors.findPossibleDuplicates({ first_name: 'Zed', last_name: 'Nobody', phone: '' }); }
  assert.deepEqual(nothing, []);
  assert.deepEqual(visitors.findPossibleDuplicates({ first_name: '', last_name: 'X' }), [], 'no name, no match');
  console.log('PASS (duplicates) the same name or phone (written any way) against other first timers and members is warned about with links, never blocked; Record anyway records and is audited; unmatched people are recorded at once');

  // ---- kiosk search finds them by name (not by phone); check-in uses a visit, not a member ----------------
  const byName = attendance.searchPeopleForAttendance('Grace Newcomer');
  assert.ok(byName.some((p) => p.type === 'visitor' && p.id === grace.id && /^First Timer( · •••• \d{4})?$/.test(p.detail)), 'found by first and last name, tagged First Timer (with at most the masked last four digits)');
  assert.ok(attendance.searchPeopleForAttendance('Newcomer').some((p) => p.type === 'visitor' && p.id === grace.id));
  assert.equal(attendance.searchPeopleForAttendance('5551 999').some((p) => p.type === 'visitor'), false, 'a partial mobile number finds no one: only the whole number matches');
  assert.equal(attendance.searchPeopleForAttendance('+974 5551 9999').some((p) => p.type === 'visitor' && p.id === grace.id), true, 'the whole mobile number finds the First Timer');
  const kioskPage = await (await get('/kiosk?q=Newcomer', kioskA)).text();
  assert.match(kioskPage, /Grace Newcomer/);
  assert.match(kioskPage, /First Timer/);
  assert.match(await (await get('/kiosk', kioskB)).text(), /marked &ldquo;Returning &middot; Review pending&rdquo;/);

  const recordsBefore = db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n;
  const first = attendance.recordAttendanceForPeople(session.id, [{ type: 'visitor', id: grace.id }], { userId: null });
  assert.equal(first.ok, true);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ? AND session_id = ?').get(grace.id, session.id).n, 1, 'the visit is tied to the Friday session');
  const again = attendance.recordAttendanceForPeople(session.id, [{ type: 'visitor', id: grace.id }], { userId: null });
  assert.equal(again.already.length, 1, 'a second check-in the same day is reported as already recorded');
  // Grace was recorded by hand today. On an ordinary day that is a different date from the Friday, so she now has two visits; when today IS the Friday the
  // two are the same date, there is one visit, and the check-in ties it to the Friday (this suite used to fail on a real Friday).
  const sameDay = db.prepare('SELECT 1 FROM visitor_visits WHERE visitor_id = ? AND visit_date = ?').get(grace.id, session.service_date) && db.prepare('SELECT first_visit_date d FROM visitors WHERE id = ?').get(grace.id).d === session.service_date;
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(grace.id).n, sameDay ? 1 : 2, 'one visit per date, never a duplicate');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n, recordsBefore, 'a first timer never writes an attendance record or a member');
  console.log('PASS (check-in) a registered first timer is found by name (not by phone), checked in as a visit on that Friday, never twice, never as a member record');

  // ---- what must NOT happen: no threshold, no automatic promotion, no notification ------------------------
  const repeat = visitors.createVisitor({ first_name: 'Regular', last_name: 'Guest', first_visit_date: addDays(FRIDAY, -28) });
  for (const week of [21, 14, 7, 0]) visitors.recordVisit(repeat.id, { date: addDays(FRIDAY, -week) });
  const after = visitors.getVisitor(repeat.id);
  assert.equal(after.visits.length, 5, 'five consecutive Fridays are recorded');
  assert.equal(after.state, 'returning', 'they are "Came back" and nothing more');
  assert.equal(after.member_id, null, 'repeated attendance never makes someone a member');
  const reminderBefore = db.prepare('SELECT COUNT(*) n FROM reminders').get().n;
  generateReminders({ asOf: today() });
  assert.equal(db.prepare("SELECT COUNT(*) n FROM reminders WHERE title LIKE '%Guest%' OR detail LIKE '%Guest%'").get().n, 0, 'no reminder is raised about repeat visits');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM reminders').get().n >= reminderBefore, true);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM notifications WHERE title LIKE '%Guest%' OR body LIKE '%Guest%'").get().n, 0, 'and no notification');
  console.log('PASS (no invented rule) five consecutive visits: still "Came back", no member, no reminder, no notification - there is no repeat-visit threshold');

  // ---- conversion keeps history and ends the duplicate identity --------------------------------------------
  const converted = visitors.convertToMember(grace.id, { userId: null });
  assert.equal(converted.member.date_joined, today(), 'the join date is the day they were made a member, not the day they first visited');
  assert.equal(converted.ok, true);
  const member = converted.member;
  const reread = visitors.getVisitor(grace.id);
  assert.equal(reread.member_id, member.id);
  assert.equal(reread.state, 'joined');
  assert.equal(reread.visits.length, sameDay ? 1 : 2, 'the visit history is kept');
  assert.equal(visitors.convertToMember(grace.id, { userId: null }).reason, 'already_a_member', 'a second conversion is refused');
  const search = attendance.searchPeopleForAttendance('Grace Newcomer');
  assert.equal(search.filter((p) => p.type === 'visitor' && p.id === grace.id).length, 0, 'once converted they are no longer offered as a first timer');
  assert.equal(search.filter((p) => p.type === 'member' && p.id === member.id).length, 1, 'they are found once, as a member');
  assert.equal(db.prepare('SELECT qr_token FROM members WHERE id = ?').get(member.id).qr_token, null, 'no QR exists until a member QR is issued');
  console.log('PASS (conversion) converting creates one member linked to the first timer, keeps the visits, refuses a second conversion, and the person is offered once, as a member');
} finally {
  await terminateAndWait(server);
}
db.close();
console.log('ALL PASS');
