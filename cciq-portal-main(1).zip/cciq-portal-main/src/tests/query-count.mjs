import assert from 'node:assert/strict';
import { buildPortalFixture } from './lib/portal-fixture.mjs';

/*
 * The N+1 check (follow-up and long-absence are the two known exceptions: see below): a list that runs one extra query per row it shows gets slower with every row. For each list the same screen is
 * built for 10 rows and for 100 rows; the number of SQL statements must not grow with the number of rows shown. (Counted by wrapping
 * db.prepare in this process - every data-access helper prepares one statement per call.)
 */

const f = await buildPortalFixture('cciq-query-count-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const now = new Date().toISOString();

db.transaction(() => {
  const insertMember = db.prepare("INSERT INTO members (member_code, first_name, last_name, status, phone, email, cell_group_id, date_of_birth, date_joined, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '2020-01-01', ?, ?)");
  const groups = db.prepare('SELECT id FROM cell_groups').all().map((g) => g.id);
  for (let i = 0; i < 300; i += 1) {
    insertMember.run(`QCN-${String(i).padStart(4, "0")}`, `Query${i}`, `Person${i % 40}`, i % 9 === 0 ? 'inactive' : 'active', `+974 7000 ${String(i).padStart(4, '0')}`, `q${i}@fixture.invalid`, groups[i % groups.length], `19${60 + (i % 40)}-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`, now, now);
  }
  const insertVisitor = db.prepare("INSERT INTO visitors (first_name, last_name, first_visit_date, state, follow_up_state, invited_by_member_id, created_at, updated_at) VALUES (?, ?, ?, 'new', 'new', ?, ?, ?)");
  const someMembers = db.prepare('SELECT id FROM members LIMIT 50').all();
  for (let i = 0; i < 200; i += 1) insertVisitor.run(`Guest${i}`, `V${i}`, mods.dates.addDays(today, -(i % 40)), someMembers[i % someMembers.length].id, now, now);
  const fam = db.prepare("INSERT INTO family_groups (name, created_at, updated_at) VALUES (?, ?, ?)");
  for (let i = 0; i < 150; i += 1) fam.run(`Family ${i}`, now, now);
  const reminder = db.prepare("INSERT INTO reminders (reminder_type, member_id, title, due_date, state, dedupe_key, created_at, updated_at) VALUES ('birthday', ?, ?, ?, 'new', ?, ?, ?)");
  db.prepare('SELECT id FROM members LIMIT 150').all().forEach((m, i) => reminder.run(m.id, `Reminder ${i}`, mods.dates.addDays(today, i % 60), `qc-${i}`, now, now));
  const friday = mods.dates.lastFridayOnOrBefore(today);
  const session = db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)");
  for (let w = 0; w < 20; w += 1) session.run(mods.dates.addDays(friday, -7 * w), now);
  db.exec(`INSERT OR IGNORE INTO attendance_records (session_id, member_id, status, recorded_at, source)
           SELECT s.id, m.id, CASE WHEN ((m.id * 7 + s.id * 13) % 10) < 6 THEN 'present' ELSE 'absent' END, '${now}', 'manual'
             FROM attendance_sessions s CROSS JOIN members m WHERE s.service_type = 'friday_service' AND m.status = 'active'`);
})();

// Giving Board claims, and a tracked, finalized year of Fridays so the follow-up and long-absence lists have rows to show.
for (let i = 0; i < 120; i += 1) mods.ecaq.createClaim({ campaignId: ids.board, date: mods.ecaq.boardDates(Number(today.slice(0, 4)))[20 + i], memberId: ids.member.a3, userId: users.churchAdmin.id });
const lifecycle = await import('../services/attendance-lifecycle.js');
// The follow-up list steps aside for people whose last attendance is older than the engagement window (56 days); the tracked members here went quiet 16 weeks ago on purpose,
// so the window is switched off for this measurement (it is the number of statements that is measured, not who qualifies). Without this the list was empty on a real Friday.
await (await import('../lib/settings.js')).setSetting('attendance.recent_engagement_days', 0);
const tracked = [];
for (let i = 0; i < 40; i += 1) tracked.push(mods.members.createMember({ first_name: `Track${i}`, last_name: `Streak${i}` }, { status: 'active' }).id);
db.prepare("UPDATE members SET created_at = '2020-01-01T00:00:00.000Z'").run();
db.prepare("UPDATE member_status_history SET changed_at = '2020-01-01T00:00:00.000Z'").run();
const fridays = db.prepare("SELECT id, service_date FROM attendance_sessions WHERE service_type = 'friday_service' AND service_date < ? ORDER BY service_date").all(today);
assert.ok(lifecycle.setTrackingStartDate(fridays[0].service_date, { userId: users.superAdmin.id }).ok);
for (const session of fridays) {
  db.prepare("UPDATE attendance_sessions SET created_at = '2020-01-01T00:00:00.000Z' WHERE id = ?").run(session.id);
  // the tracked members attend only the first few Fridays, so they have long absence streaks
  if (fridays.indexOf(session) < 3) for (const id of tracked) db.prepare("INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, 'present', ?, 'manual')").run(session.id, id, now);
  lifecycle.finalizeAttendance(session.id, { userId: users.superAdmin.id, confirmNoAttendance: true });
}

let statements = 0;
const originalPrepare = db.prepare.bind(db);
db.prepare = (sql) => {
  const statement = originalPrepare(sql);
  for (const method of ['all', 'get', 'run']) {
    const original = statement[method].bind(statement);
    statement[method] = (...args) => { statements += 1; return original(...args); };
  }
  return statement;
};
const count = (fn) => { statements = 0; const result = fn(); return { statements, result }; };

const lib = {
  members: (n) => mods.members.listMembers({ scope: { type: 'all' }, page: 1, pageSize: n }),
  visitors: (n) => mods.visitors.listVisitors({ page: 1, pageSize: n }),
  claims: (n) => mods.ecaq.listClaims({ campaignId: ids.board, page: 1, pageSize: n }),
  familyGroups: (n) => mods.family.listFamilyGroups({ page: 1, pageSize: n }),
  reminders: (n) => mods.reminders.listReminders({ state: 'all', page: 1, pageSize: n }),
  birthdays: (n) => mods.members.upcomingBirthdays({ withinDays: 365, limit: n }),
  picker: (n) => mods.members.searchMembersForPicker('Query', { limit: n })
};
// the attendance lists live in other modules
const consumers = await import('../services/attendance-consumers.js');
const outcomes = await import('../services/attendance-tracking.js');
void outcomes;
const extra = {
  followUp: (n) => consumers.followUpList({ limit: n }),
  longAbsence: (n) => consumers.longAbsenceReview({ limit: n })
};

const PER_MEMBER = new Set(['followUp', 'longAbsence']); // these evaluate each member on the roster (limit = members examined, not rows shown); the Attendance rules they implement are approved and untouched
const rows = [];
const offenders = [];
for (const [name, run] of Object.entries({ ...lib, ...extra })) {
  if (name === 'followUp' && !extra.followUp) continue;
  let small; let large;
  const [lo, hi] = PER_MEMBER.has(name) ? [40, 400] : [10, 100];
  try { small = count(() => run(lo)); large = count(() => run(hi)); } catch (err) { offenders.push(`${name}: threw ${err.message}`); continue; }
  const shown = (r) => (Array.isArray(r) ? r.length : (r?.rows?.length ?? r?.length ?? '?'));
  rows.push(`${name}: ${small.statements} statements for ${shown(small.result)} rows, ${large.statements} for ${shown(large.result)}`);
  if (PER_MEMBER.has(name)) {
    // bounded and linear: at most a few statements per member examined, never per pair of member and Friday
    if (large.statements > 4 * hi + 10) offenders.push(`${name}: ${large.statements} statements for ${hi} members examined`);
    continue;
  }
  if (large.statements > small.statements + 3) offenders.push(`${name}: ${small.statements} -> ${large.statements} statements as the rows shown go from 10 to 100 (one query per row?)`);
}
console.log(`INFO ${rows.join('\n     ')}`);
assert.deepEqual(offenders, [], 'no list runs a query per row (follow-up and long-absence stay within a few statements per member examined)');
console.log('INFO follow-up and long-absence evaluate every rostered member with a few statements each (about 1 to 4 per member): linear in the roster, not in the Fridays. A set-based rewrite would touch approved Attendance logic, so it is recorded (docs/WORKFLOW-INTEGRITY-AUDIT.md) rather than done; performance-smoke.mjs times them at 1,000 members and a year of finalized Fridays.');
assert.ok(rows.length >= 8, `enough lists were measured (${rows.length})`);
for (const name of ['claims', 'followUp', 'longAbsence']) {
  const big = count(() => ({ ...lib, ...extra })[name](PER_MEMBER.has(name) ? 400 : 100)).result;
  const n = Array.isArray(big) ? big.length : (big?.rows?.length ?? big?.length ?? 0);
  assert.ok(n >= (PER_MEMBER.has(name) ? 5 : 25), `the ${name} measurement is meaningful: it really showed ${n} rows`);
}
console.log(`PASS (queries) ${rows.length} lists run the same number of statements for 10 rows as for 100 - no N+1`);
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
