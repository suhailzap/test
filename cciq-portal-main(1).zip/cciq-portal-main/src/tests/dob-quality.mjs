import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Date of birth data quality. A date of birth that is not a real date, is in the future, or looks wrong against the rest of the record is NOT USED: no age, no congregation, no birthday
 * list, reminder, dashboard entry or report line comes from it. Nothing is ever corrected automatically; the review page says why each one is flagged.
 *   - the rules (pure): impossible and future dates, a child's age with adult details, birth year = first-visit year, the day-first sheet; a genuine child is never flagged for being young;
 *   - every consumer: birthday list, dashboard window, calendar, reminders, the birthday PDF, congregation, profile and edit screens;
 *   - the review page: who may open it, what it lists, filters and the suggested (never applied) reading;
 *   - the data check now catches an impossible calendar date, and the spreadsheet import refuses a guessed century and a future birth date;
 *   - the stored values are byte-identical afterwards.
 */

const f = await buildPortalFixture('cciq-dob-quality-');
const { db, users, mods } = f;
const dq = await import('../services/dob-quality.js');
const cong = await import('../services/congregations.js');
const reminders = await import('../services/reminders.js');
const imports = await import('../services/imports.js');
const pdfs = await import('../services/reports-pdf.js');
const { today, addDays } = mods.dates;
const T = today();

// ---- 1. the rules, on their own -----------------------------------------------------------------------------------------------------------------------------------------------
const rule = (m, options = {}) => dq.assessDob({ id: 1, ...m }, { asOf: '2026-10-08', ...options });
assert.equal(rule({}).state, 'none');
assert.deepEqual([rule({ date_of_birth: '1990-05-17' }).state, rule({ date_of_birth: '1990-05-17' }).age], ['ok', 36], 'an ordinary adult date is used, with its age');
for (const bad of ['1976-26-07', '2023-02-30', '1990-13-01', 'not a date', '17/05/1990']) { const a = rule({ date_of_birth: bad }); assert.deepEqual([a.state, a.suppressed, a.category, a.age], ['invalid', true, 'A', null], bad); }
assert.equal(rule({ date_of_birth: '1976-26-07' }).suggested, '1976-07-26', 'the day-first reading is only SUGGESTED');
assert.equal(rule({ date_of_birth: '2027-01-01' }).reasons[0], 'future'); assert.equal(rule({ date_of_birth: '2027-01-01' }).suppressed, true);
// adult details on a child's age
for (const marital_status of ['married', 'widowed', 'separated']) assert.deepEqual(rule({ date_of_birth: '2023-10-27', marital_status }).reasons, ['child_age_adult_details'], marital_status);
assert.deepEqual(rule({ date_of_birth: '2023-10-27', anniversary_date: '2020-01-01' }).reasons, ['child_age_adult_details'], 'a wedding date');
assert.deepEqual(rule({ date_of_birth: '2023-10-27', spouse_name: 'Someone' }).reasons, ['child_age_adult_details'], 'a spouse');
// a genuine child is never flagged for being young, nor for a civil status of "single" on its own (the source records some real children that way)
assert.equal(rule({ date_of_birth: '2023-11-01' }).state, 'ok', 'a child with no adult details');
assert.equal(rule({ date_of_birth: '2023-11-01', marital_status: 'single', status: 'active' }).state, 'ok', 'a child recorded as single is NOT flagged on that alone');
assert.deepEqual(rule({ date_of_birth: '2023-11-01', marital_status: 'single', status: 'bonafide' }).reasons, ['child_age_adult_details'], 'single + bonafide membership points to an adult');
assert.deepEqual(rule({ date_of_birth: '2023-11-01', marital_status: 'single', cell_group_id: 4 }).reasons, ['child_age_adult_details'], 'single + a cell group points to an adult');
assert.deepEqual(rule({ date_of_birth: '2024-09-14', marital_status: 'single', notes: 'Imported.\nDate of first visit: 2024-06-21' }).reasons, ['child_age_adult_details', 'dob_after_first_visit'], 'single + born the year they first visited, and after the day they first came');
assert.deepEqual(rule({ date_of_birth: '2024-02-14', marital_status: 'single', notes: 'Imported.\nDate of first visit: 2024-06-21' }).reasons, ['child_age_adult_details'], 'born the same year but BEFORE the first visit: only the adult-details reason');
assert.equal(rule({ date_of_birth: '2024-09-14', notes: 'Date of first visit: 2024-12-27' }).state, 'ok', 'a baby brought along the year it was born, with no adult details, is fine');
assert.equal(rule({ date_of_birth: '2012-03-04', marital_status: 'married' }).state, 'ok', 'a 14 year old (born 2012) is outside the child range (the rule is for a child’s age)');
assert.deepEqual(rule({ date_of_birth: '2011-03-04', marital_status: 'married', notes: 'Date of first visit: 2011-05-01' }).reasons, ['birth_year_is_first_visit_year'], 'a teenage age with the first-visit year and adult details');
// the day-first sheet
const swap = new Set([1]);
assert.deepEqual(rule({ date_of_birth: '1991-05-07' }, { swapBlock: swap }).reasons, ['possible_day_month_swap']);
assert.equal(rule({ date_of_birth: '1991-05-07' }, { swapBlock: swap }).suggested, '1991-07-05'); assert.equal(rule({ date_of_birth: '1991-05-07' }, { swapBlock: swap }).suppressed, true);
assert.equal(rule({ date_of_birth: '1990-10-10' }, { swapBlock: swap }).state, 'ok', 'day = month reads the same either way round');
const odd = rule({ date_of_birth: '1982-04-27' }, { swapBlock: swap }); assert.deepEqual([odd.state, odd.suppressed, odd.category, odd.reasons], ['ok', false, 'C', ['import_block_check']], 'cannot be a swap: shown for checking, still used');
console.log('PASS (rules) impossible and future dates, adult details on a child’s age, the first-visit year and the day-first sheet are flagged; a genuine child, a baby and a plain "single" are not');

// ---- 2. the real database: members, the day-first sheet found from the data, and the consumers -------------------------------------------------------------------------------------
const stamp = () => db.prepare('UPDATE members SET updated_at = updated_at').run();
const make = (first, last, extra = {}, status = 'active') => mods.members.createMember({ first_name: first, last_name: last, ...extra }, { status });
const setRaw = (id, columns) => { for (const [k, v] of Object.entries(columns)) db.prepare(`UPDATE members SET ${k} = ? WHERE id = ?`).run(v, id); };
const soon = (days, year = 1990) => `${year}-${addDays(T, days).slice(5)}`;             // a birthday `days` from now

const trusted = make('Trusty', 'Adult', { date_of_birth: soon(3) });                      // a birthday in 3 days: the one that SHOULD appear
const impossible = make('Impossible', 'Date'); setRaw(impossible.id, { date_of_birth: '1976-26-07' });  // month 26: a day-first date read the wrong way round
const wrongChild = make('Wrongchild', 'Married', { marital_status: 'married', date_of_birth: `2023-${addDays(T, 3).slice(5)}` });   // 2 years old and married
const future = make('Future', 'Born'); setRaw(future.id, { date_of_birth: `${Number(T.slice(0, 4)) + 1}-${addDays(T, 3).slice(5)}` });
const child = make('Real', 'Child', { date_of_birth: `2021-${addDays(T, 3).slice(5)}` });  // a genuine child: no adult details
const dayFirstIds = [];
// the day-first sheet: consecutive inactive imports whose legacy number restarts, containing a date that is impossible month-first
const imported = (first, last, legacy, dob) => { const m = make(first, last, {}, 'inactive'); setRaw(m.id, { legacy_reference: legacy, date_of_birth: dob }); return m; };
imported('Main', 'Sheet', 'SEQ 713 / #713', '1980-04-02');
const swapOne = imported('Swap', 'Candidate', 'SEQ 2', '1991-05-07'); dayFirstIds.push(swapOne.id);
const swapSame = imported('Same', 'Either', 'SEQ 3', '1990-10-10');
const swapOdd = imported('Odd', 'Stored', 'SEQ 4', '1982-04-27');
const swapBad = imported('Plain', 'Impossible', 'SEQ 5', '1976-26-07');
stamp();

const a = (m) => dq.dobAssessment(m.id);
assert.deepEqual([a(trusted).state, a(impossible).state, a(wrongChild).state, a(future).state, a(child).state], ['ok', 'invalid', 'unverified', 'unverified', 'ok']);
assert.equal(a(swapOne).state, 'unverified'); assert.deepEqual(a(swapOne).reasons, ['possible_day_month_swap']);
assert.equal(a(swapSame).state, 'ok'); assert.equal(a(swapOdd).reasons[0], 'import_block_check'); assert.equal(a(swapBad).state, 'invalid');
assert.equal(dq.dobAssessment(db.prepare("SELECT id FROM members WHERE first_name = 'Main'").get().id).reasons.length, 0, 'the main sheet person before the restart is not part of the day-first sheet');
const beforeRaw = JSON.stringify(db.prepare('SELECT id, date_of_birth FROM members ORDER BY id').all());

// birthday list, dashboard window, calendar, reminders
const upcoming = mods.members.upcomingBirthdays({ withinDays: 30, limit: 1000 });
const names = upcoming.map((m) => m.first_name);
assert.ok(names.includes('Trusty') && names.includes('Real'), 'trusted dates are listed');
for (const hidden of ['Impossible', 'Wrongchild', 'Future', 'Swap']) assert.ok(!names.includes(hidden), `${hidden} is not on the upcoming birthday list`);
assert.ok(!mods.members.upcomingBirthdays({ withinDays: 400, limit: 100000 }).some((m) => ['Impossible', 'Wrongchild', 'Future', 'Swap'].includes(m.first_name)), 'nor anywhere in the next year');
const made = reminders.generateReminders({ asOf: T });
assert.ok(made.birthday >= 1, 'a reminder is made for the trusted birthday');
const reminded = db.prepare("SELECT m.first_name n FROM reminders r JOIN members m ON m.id = r.member_id WHERE r.reminder_type = 'birthday'").all().map((r) => r.n);
assert.ok(reminded.includes('Trusty')); for (const hidden of ['Impossible', 'Wrongchild', 'Future', 'Swap']) assert.ok(!reminded.includes(hidden), `no birthday reminder for ${hidden}`);
// a birthday reminder made earlier, before the date was found to need verification, stays on record but is neither listed nor counted
db.prepare("INSERT INTO reminders (reminder_type, member_id, title, detail, due_date, state, dedupe_key, created_at, updated_at) VALUES ('birthday', ?, 'Wrongchild Married has a birthday today', 'x', ?, 'new', 'dq-old', ?, ?)").run(wrongChild.id, T, new Date().toISOString(), new Date().toISOString());
const openBefore = reminders.reminderCounts().open;
assert.ok(!reminders.listReminders({ state: 'open', pageSize: 100 }).rows.some((r) => r.member_id === wrongChild.id), 'an older birthday reminder about an unverified date is not listed');
assert.ok(!reminders.remindersForMember(wrongChild.id).some((r) => r.reminder_type === 'birthday'), 'nor on the member profile');
assert.equal(db.prepare("SELECT COUNT(*) n FROM reminders WHERE dedupe_key = 'dq-old'").get().n, 1, 'but nothing is deleted');
assert.ok(reminders.reminderCounts().open <= openBefore && reminders.reminderCounts().open === reminders.listReminders({ state: 'open', pageSize: 1 }).total, 'and the count agrees with the list');
const cal = await import('../services/calendar.js');
const everything = { id: 0, can: () => true, hasRole: () => true, roles: ['super_admin'], ledCellGroupIds: [], memberId: null };
const calendarText = JSON.stringify(cal.eventsInRange(everything, { from: T, to: addDays(T, 60) }));
assert.ok(calendarText.includes('Trusty'), 'the calendar does list the trusted birthday');
for (const hidden of ['Impossible', 'Wrongchild', 'Future', 'Swap']) assert.ok(!calendarText.includes(hidden), `${hidden} is not on the calendar`);

// congregation and age
assert.equal(cong.congregationFor(mods.members.getMember(wrongChild.id)), null, 'no Kids Church from an untrusted date'); assert.equal(cong.congregationFor(mods.members.getMember(child.id)), 'child', 'a genuine child is still Kids Church');
const described = cong.describeCongregation(mods.members.getMember(wrongChild.id));
assert.deepEqual([described.group, described.age, described.label], [null, null, 'Not set']); assert.equal(described.dobNotice.headline, 'Date of birth needs verification');
assert.equal(cong.describeCongregation(mods.members.getMember(trusted.id)).age, 35, 'turning 36 in three days');
assert.ok(cong.describeCongregation(mods.members.getMember(impossible.id)).dobNotice, 'an invalid date gets the same notice');
assert.equal(cong.reviewCongregations().upcoming.some((u) => u.member.id === wrongChild.id), false, 'no age-transition from an untrusted date');
setRaw(wrongChild.id, { age_group: 'adult' });
assert.equal(cong.congregationFor(mods.members.getMember(wrongChild.id)), 'adult', 'a congregation set by hand still wins');
setRaw(wrongChild.id, { age_group: null });

// the birthday report
const range = { from: T, to: addDays(T, 20), statuses: ['active', 'inactive'] };
const occasions = mods.members.occasionsInRange(range);
assert.ok(occasions.birthdays.some((b) => b.member.first_name === 'Trusty')); assert.ok(!occasions.birthdays.some((b) => ['Wrongchild', 'Future', 'Swap'].includes(b.member.first_name)));
assert.ok(occasions.unusable.birthdays >= 2, 'impossible dates are counted'); assert.ok(occasions.unverified.birthdays >= 3, 'unverified dates are counted');
const pdfText = async (doc) => { const chunks = []; doc.on('data', (c) => chunks.push(c)); await new Promise((r) => doc.on('end', r)); const raw = Buffer.concat(chunks).toString('latin1'); let t = ''; for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) { let c; try { c = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; } for (const h of c.matchAll(/<([0-9a-fA-F]+)>/g)) t += Buffer.from(h[1], 'hex').toString('latin1'); for (const l of c.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) t += l[1]; t += '\n'; } return t; };
const pdf = await pdfText(pdfs.occasionsPdf({ from: T, to: addDays(T, 20), include: 'birthdays', status: 'all' }));
assert.match(pdf, /dates? of birth needs? verification/); assert.match(pdf, /not a real calendar date/); assert.ok(!/Wrongchild|Impossible Date/.test(pdf), 'the report lists none of them');
assert.equal(JSON.stringify(db.prepare('SELECT id, date_of_birth FROM members ORDER BY id').all()), beforeRaw, 'not one stored date of birth was changed by any of this');
console.log('PASS (consumers) the birthday list, the next-year list, reminders, the calendar, congregation and age, age transitions and the birthday PDF all leave out an invalid or unverified date; stored values untouched');

// ---- 3. the screens ------------------------------------------------------------------------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const flat = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&rsquo;|&#39;/g, "'").replace(/&middot;/g, '·').replace(/\s+/g, ' ');

  const show = await (await admin.get(`/members/${wrongChild.id}`)).text();
  assert.match(flat(show), /Date of birth needs verification/); assert.match(flat(show), /Not set: the date of birth needs verification/);
  assert.match(flat(show), new RegExp(`Stored: 2023-${addDays(T, 3).slice(5)}`)); assert.ok(!/Age 2/.test(flat(show)), 'no age is shown for it');
  const okShow = flat(await (await admin.get(`/members/${trusted.id}`)).text()); assert.ok(!/needs verification/.test(okShow), 'a trusted date has no notice'); assert.match(okShow, /Age 35/);
  const edit = flat(await (await admin.get(`/members/${wrongChild.id}/edit`)).text()); assert.match(edit, /Date of birth needs verification\./); assert.match(edit, /not used for age, congregation, birthdays or reminders/);
  const bday = flat(await (await admin.get('/members/birthdays?days=365')).text()); assert.match(bday, /dates? of birth needs? verification and (is|are) not listed here/); assert.ok(!/Wrongchild/.test(bday));
  assert.match(flat(await (await church.get('/members/birthdays')).text()), /See which and why/); assert.ok(!/See which and why/.test(flat(await (await member.get('/members/birthdays')).text())), 'a Member is not pointed at the review page');

  // who may open the review
  for (const [who, client] of [['super admin', admin], ['church admin', church]]) assert.equal((await client.get('/members/dob-review')).status, 200, who);
  for (const [who, client] of [['leader', leader], ['member', member]]) assert.equal((await client.get('/members/dob-review')).status, 403, `${who} is refused`);
  const anon = await fetch(`${portal.base}/members/dob-review`, { redirect: 'manual' }); assert.equal(anon.status, 302); assert.match(anon.headers.get('location'), /^\/login/);
  const review = flat(await (await admin.get('/members/dob-review')).text());
  for (const col of ['Member ID', 'Member \u00b7 status', 'Stored date of birth', 'Age', 'Why it is flagged', 'Congregation \u00b7 group', 'Decision']) assert.match(review, new RegExp(col));
  for (const n of ['Wrongchild Married', 'Impossible Date', 'Future Born', 'Swap Candidate']) assert.match(review, new RegExp(n.split(' ')[0]), `${n} is listed`);
  assert.ok(!/Real Child|Trusty Adult/.test(review), 'a genuine child and a trusted date are not listed');
  assert.match(review, /Not a real calendar date/); assert.match(review, /Read day-first it would be/); assert.match(review, /Not reviewed yet/); assert.match(review, /Not used/); assert.match(review, /Used: please check/);
  const rawReview = await (await admin.get("/members/dob-review")).text();
  assert.ok(rawReview.includes(`href="/members/${wrongChild.id}"`), "each row links to the member record");
  assert.ok(!/created_after|child_age_adult_details|possible_day_month_swap|not_a_real_date|birth_year_is_first_visit_year|import_block_check/.test(rawReview), "no internal code is shown");
  const onlyA = flat(await (await admin.get('/members/dob-review?category=A')).text()); assert.match(onlyA, /Impossible/); assert.ok(!/Wrongchild/.test(onlyA), 'the category filter works');
  const found = flat(await (await admin.get('/members/dob-review?q=Swap')).text()); assert.match(found, /Swap/); assert.ok(!/Wrongchild/.test(found), 'search works');
  console.log('PASS (screens) the profile and edit form say the date needs verification and show no age; the birthday page says how many are not listed; the review page is for Church Admin and Super Admin, lists the flagged records with plain reasons and never a code, and filters and searches');
} finally { await portal.stop(); }

// ---- 4. the data check and the spreadsheet import --------------------------------------------------------------------------------------------------------------------------------------
{
  const inv = await import('../lib/db-invariants.js');
  const found = inv.checkInvariants(db);
  const finding = found.findings.find((x) => x.code === 'member.impossible_dates');
  assert.ok(finding, 'the data check reports a date with the right shape that is not a real date');
  assert.ok(finding.ids.length >= 2 && finding.severity === 'review', 'it lists them, as a review finding');
  assert.ok(!found.findings.some((x) => x.code === 'member.malformed_dates'), 'the shape check is unchanged');
  const preview = imports.previewMembers({
    headers: ['First', 'Last', 'Born'], mapping: { first_name: 0, last_name: 1, date_of_birth: 2 },
    rows: [['Ann', 'Typed', '17/05/90'], ['Bea', 'Future', `${Number(T.slice(0, 4)) + 2}-01-01`], ['Cy', 'Fine', '1990-05-17'], ['Di', 'Real', '17/05/1990']]
  });
  const by = Object.fromEntries(preview.rows.map((r) => [r.record.first_name, r]));
  assert.equal(by.Ann.outcome, 'skip'); assert.match(by.Ann.problems.join(' '), /two-digit year/);
  assert.equal(by.Bea.outcome, 'skip'); assert.match(by.Bea.problems.join(' '), /in the future/);
  assert.equal(by.Cy.outcome, 'create'); assert.equal(by.Di.outcome, 'create'); assert.equal(by.Di.record.date_of_birth, '1990-05-17', 'a four-digit day-first date is still read as before');
  console.log('PASS (data check, import) the data check names impossible calendar dates; the spreadsheet import refuses a two-digit-year date of birth and a future one, and still reads a four-digit date as before');
}
console.log('PASS dob-quality');
