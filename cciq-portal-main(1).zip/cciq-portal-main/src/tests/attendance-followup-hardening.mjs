import assert from 'node:assert/strict';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Attendance Phase 2C hardening:
 *   1A the strict unfinalized-Friday barrier and its wording;
 *   1B a reminder follows one continuous EPISODE of absence (grows forward or
 *      backward without a duplicate; a genuinely new episode gets its own);
 *   1C follow-up needs no prior tracked Present and no pre-Go-Live attendance
 *      (simulating the legacy records having been cleared).
 * Disposable fixtures only; no schema is involved.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-followup-hardening-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const reminders = await import('../services/reminders.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const oldDate = addDays(SERVICE, -300);
const atNoon = (date, hour = 9) => `${date}T${String(hour).padStart(2, '0')}:00:00.000Z`;

const people = new Map();
const member = (name) => {
  if (!people.has(name)) people.set(name, createMember({ first_name: name, last_name: 'Hard' }, { status: 'active' }));
  return people.get(name);
};
const id = (name) => member(name).id;
function population(spec) {
  for (const name of Object.keys(spec)) member(name);
  for (const [name, m] of people) {
    const entry = spec[name];
    const status = entry === undefined ? 'archived' : (typeof entry === 'string' ? entry : entry.status);
    const changes = entry && typeof entry === 'object' ? entry.changes || [] : [];
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    db.prepare('UPDATE members SET created_at = ?, date_joined = NULL WHERE id = ?').run(atNoon(oldDate), m.id);
    const insert = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
    insert.run(m.id, null, status, 'planted', atNoon(oldDate));
    let current = status;
    for (const change of changes) { insert.run(m.id, current, change.status, 'planted', change.at); current = change.status; }
    db.prepare('UPDATE members SET status = ? WHERE id = ?').run(current, m.id);
  }
}

let sessions = new Map();
const insertSession = db.prepare(
  `INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at)
   VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, 0, @at)`
);
function resetWorld({ goLive, weeks }) {
  db.exec(`DELETE FROM reminders; DELETE FROM qr_checkins; DELETE FROM visitor_visits;
           DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions;`);
  setSetting('attendance.tracking_start_date', goLive);
  sessions = new Map();
  for (const n of weeks) {
    insertSession.run({ date: W(n), at: atNoon(W(n)) });
    sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
  }
}
/** Fridays are settled oldest-first in real use; a NEWER unfinalized Friday is (correctly) a barrier. */
function addWeek(n) {
  insertSession.run({ date: W(n), at: atNoon(W(n)) });
  sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
}
const range = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => from + i);
const S = (n) => sessions.get(n);
const mark = (name, n, status) => db.prepare(
  "INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, ?, ?, 'manual')"
).run(S(n).id, id(name), status, atNoon(W(n), 11));
function fin(n) {
  const result = lifecycle.finalizeAttendance(S(n).id, { userId: null, confirmNoAttendance: true });
  assert.equal(result.ok, true, `finalize W(${n}) -> ${result.reason}`);
}
const finAll = (...ns) => ns.forEach(fin);
const streakOf = (name) => attendance.consecutiveMissedFridays(id(name));
const followUp = () => attendance.followUpList({ limit: 1000 });
const all = (name) => db.prepare("SELECT * FROM reminders WHERE member_id = ? AND reminder_type = 'attendance_followup' ORDER BY id").all(id(name));
const open = (name) => all(name).filter((r) => r.state === 'new' || r.state === 'acknowledged');
const key = (name, n) => reminders.followUpRunKey(id(name), S(n).id);
const audits = (action) => db.prepare('SELECT * FROM audit_logs WHERE action = ? ORDER BY id').all(action);

setSetting('attendance.recent_engagement_days', 56); // the default: must not defeat the threshold rule (1C)
const staff = await createUser({ email: 'handler@fixture.invalid', password: 'HandlerPassw0rd!2026', displayName: 'Handler', roleKeys: ['church_admin'], mustChangePassword: false });

// ===========================================================================
// 1B. One continuous episode = one reminder
// ===========================================================================
{
  population({ Ep: 'active' });
  resetWorld({ goLive: W(-6), weeks: range(-6, 0) });
  // W(-6), W(-5), W(-4) stay awaiting finalization; W(-3), W(-2), W(-1) are finalized absences.
  finAll(-3, -2, -1);
  assert.equal(streakOf('Ep').streak, 3);
  assert.equal(streakOf('Ep').blocked, true, 'W(-4) awaits finalization: a barrier at the old end');
  assert.equal(open('Ep').length, 1, '1B-1: three finalized absences -> one reminder');
  const reminder = open('Ep')[0];
  assert.equal(reminder.dedupe_key, key('Ep', -3));

  // 2. The run grows FORWARD (W(0), the open current Friday, is finalized as absent too).
  fin(0);
  assert.equal(streakOf('Ep').streak, 4);
  assert.equal(all('Ep').length, 1, '1B-2: growing forward keeps the same single reminder');
  assert.equal(open('Ep')[0].id, reminder.id);

  // 3. The run grows BACKWARD: the older awaiting Friday is finalized as Absent.
  fin(-4);
  const extended = streakOf('Ep');
  assert.equal(extended.streak, 5);
  assert.equal(extended.runStart.sessionId, S(-4).id, 'the calculated start moved back to W(-4)');
  assert.equal(all('Ep').length, 1, '1B-3: the same continuous episode - no duplicate reminder although the start moved');
  assert.equal(open('Ep')[0].id, reminder.id);
  assert.equal(open('Ep')[0].dedupe_key, key('Ep', -3), 'the original label is kept; matching is by episode, not by recomputing the key');
  fin(-5);
  fin(-6);
  assert.equal(streakOf('Ep').streak, 7);
  assert.equal(all('Ep').length, 1);
  reminders.reconcileFollowUpReminders({ source: 'test' });
  reminders.generateReminders();
  assert.equal(all('Ep').length, 1, 'and re-running stays idempotent');
  console.log('PASS (1B 1-3) one reminder for a continuous episode: created at the threshold, kept when it grows forward and when it extends backward');
}

// 4. A streak-breaking event, then a new run: a genuinely NEW reminder.
{
  population({
    RemP: 'active', RemV: 'active',
    RemN: { status: 'active', changes: [{ at: atNoon(addDays(W(-5), -2)), status: 'inactive' }, { at: atNoon(addDays(W(-5), 3)), status: 'active' }] }
  });
  resetWorld({ goLive: W(-8), weeks: [-8, -7, -6] });
  finAll(-8, -7, -6);
  for (const name of ['RemP', 'RemV', 'RemN']) assert.equal(open(name).length, 1, `${name}: run 1 qualified`);
  const first = Object.fromEntries(['RemP', 'RemV', 'RemN'].map((name) => [name, open(name)[0]]));
  addWeek(-5);
  mark('RemP', -5, 'present');   // Present breaks
  mark('RemV', -5, 'excused');   // Vacation breaks (attendance.excused_counts is on)
  // RemN: not expected at W(-5) (inactive that Friday) - breaks the eligible run
  fin(-5);
  for (const name of ['RemP', 'RemV', 'RemN']) {
    assert.equal(open(name).length, 0, `${name}: the break closed the reminder (dismissed by the system)`);
    assert.equal(all(name)[0].handled_by, null);
  }
  for (const n of [-4, -3, -2]) { addWeek(n); fin(n); }
  for (const name of ['RemP', 'RemV', 'RemN']) {
    assert.equal(streakOf(name).streak, 3, `${name}: a new run of the SAME length`);
    assert.equal(open(name).length, 1, `1B-4: ${name} - the new run raises a fresh reminder`);
    assert.notEqual(open(name)[0].id, first[name].id);
    assert.equal(open(name)[0].dedupe_key, key(name, -4));
    assert.equal(all(name).length, 2, `${name}: the first episode's reminder is kept as history`);
  }
  console.log('PASS (1B 4) a Present, a Vacation or a not-expected Friday ends the episode; a later run creates a genuinely new reminder and keeps the old one');
}

// 5. A reminder a person handled is never touched; it also stops a duplicate for the same episode.
{
  population({ Human: 'active', Human2: 'active' });
  resetWorld({ goLive: W(-6), weeks: range(-6, 0) });
  finAll(-3, -2, -1);
  for (const [name, state] of [['Human', 'completed'], ['Human2', 'dismissed']]) {
    const r = open(name)[0];
    assert.ok(r, `${name} has a reminder`);
    db.prepare("UPDATE reminders SET state = ?, handled_by = ?, handled_at = ? WHERE id = ?").run(state, staff, new Date().toISOString(), r.id);
  }
  const snapshot = JSON.stringify(all('Human')) + JSON.stringify(all('Human2'));
  fin(0);
  fin(-4);
  fin(-5);
  reminders.reconcileFollowUpReminders({ source: 'test' });
  reminders.generateReminders();
  assert.equal(JSON.stringify(all('Human')) + JSON.stringify(all('Human2')), snapshot, '1B-5: human-handled reminders are byte-for-byte untouched');
  assert.equal(all('Human').length, 1, 'and the same (extended) episode does not raise another one');
  assert.equal(all('Human2').length, 1);
  // ...but a genuinely new episode after a break is a new matter and may raise one.
  assert.equal(lifecycle.correctFinalizedAttendance(S(-1).id, [{ memberId: id('Human'), to: 'present' }], { userId: null, reason: 'Was here' }).ok, true);
  assert.equal(all('Human').length, 1, 'a correction alone raises nothing new');
  assert.equal(all('Human')[0].state, 'completed', 'and still leaves the human decision alone');
  console.log('PASS (1B 5) human-handled reminders are never reopened, rewritten or duplicated');
}

// 6. System-dismissed reminders: reopened for the same episode, left dismissed for a different one.
{
  population({ Sys: 'active' });
  resetWorld({ goLive: W(-6), weeks: range(-6, 0) });
  finAll(-6, -5, -4, -3, -2, -1);
  const reminder = open('Sys')[0];
  assert.equal(reminder.dedupe_key, key('Sys', -6));
  assert.equal(streakOf('Sys').streak, 6);

  // Correct the middle: Present at W(-3) breaks the run; the newer part (-2,-1) is only 2.
  assert.equal(lifecycle.correctFinalizedAttendance(S(-3).id, [{ memberId: id('Sys'), to: 'present' }], { userId: null, reason: 'Here' }).ok, true);
  assert.equal(open('Sys').length, 0, 'the run no longer qualifies: dismissed by the system');
  const dismissed = all('Sys')[0];
  assert.equal(dismissed.state, 'dismissed');
  assert.equal(dismissed.handled_by, null);
  assert.equal(audits('reminder.followup_auto_dismissed').length >= 1, true);

  // Undoing the correction restores the SAME episode: the same reminder reopens (no duplicate).
  assert.equal(lifecycle.correctFinalizedAttendance(S(-3).id, [{ memberId: id('Sys'), to: 'remove' }], { userId: null, reason: 'Mistake' }).ok, true);
  assert.equal(all('Sys').length, 1);
  assert.equal(open('Sys')[0].id, reminder.id, '1B-6: the system-dismissed reminder is reopened for the same episode');
  assert.equal(audits('reminder.followup_reopened').length >= 1, true);

  // Correct W(-3) to Present again, then let the newer part become its own run of 3 (add W(0) absent).
  assert.equal(lifecycle.correctFinalizedAttendance(S(-3).id, [{ memberId: id('Sys'), to: 'present' }], { userId: null, reason: 'Here' }).ok, true);
  fin(0); // W(-2), W(-1), W(0): a NEW episode of 3 after the Present at W(-3)
  assert.equal(streakOf('Sys').streak, 3);
  assert.equal(open('Sys').length, 1);
  assert.notEqual(open('Sys')[0].id, reminder.id, 'a different episode gets a different reminder');
  assert.equal(all('Sys').length, 2);
  assert.equal(all('Sys').find((r) => r.id === reminder.id).state, 'dismissed', 'the old one stays dismissed history');
  console.log('PASS (1B 6) system-dismissed reminders reopen for the same episode and stay closed for a different one');
}

// ===========================================================================
// 1C. Follow-up after an attendance reset: no prior tracked Present, no legacy attendance
// ===========================================================================
{
  population({ Never: 'active', LegacyOnly: 'active', Attends: 'active' });
  resetWorld({ goLive: W(-3), weeks: [-6, -5, -4, ...range(-3, 0)] });
  // Legacy (pre-Go-Live) attendance existed...
  mark('LegacyOnly', -5, 'present'); mark('LegacyOnly', -4, 'present'); mark('Never', -6, 'present');
  mark('Attends', -3, 'present');
  // ...and is then cleared, as the controlled reset will do (sessions stay, records go).
  db.prepare("DELETE FROM attendance_records WHERE session_id IN (?, ?, ?)").run(S(-6).id, S(-5).id, S(-4).id);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id WHERE s.service_date < ?').get(W(-3)).n, 0, 'no pre-Go-Live attendance remains');
  assert.equal(attendance.lastAttendedFriday(id('Never')), null);
  finAll(-3, -2, -1);
  assert.equal(streakOf('Never').streak, 3);
  const flagged = followUp().map((f) => f.member.id);
  assert.equal(flagged.includes(id('Never')), true, '1C: three finalized absences qualify a member who has NEVER checked in since Go-Live');
  assert.equal(flagged.includes(id('LegacyOnly')), true, '1C: and pre-Go-Live attendance being gone is irrelevant');
  assert.equal(flagged.includes(id('Attends')), false, 'a member who attended at W(-3) is not on a run of 3');
  assert.equal(open('Never').length, 1, '1C: a reminder is raised for them too');
  assert.equal(followUp().find((f) => f.member.id === id('Never')).lastAttended, null);
  // The engagement window steps aside only for OLD tracked attendance, never for none.
  setSetting('attendance.recent_engagement_days', 7);
  assert.equal(followUp().some((f) => f.member.id === id('Never')), true, 'a short window does not remove a member with no tracked attendance');
  setSetting('attendance.recent_engagement_days', 56);
  // Long Absence is the separate mechanism: nothing is listed yet (tracking is young).
  assert.equal(attendance.longAbsenceReview().status, 'insufficient_history');
  assert.equal(attendance.longAbsenceReview().rows.length, 0);
  console.log('PASS (1C) follow-up qualifies at the threshold with no prior tracked Present and no legacy attendance; Long Absence stays a separate, conservative mechanism');
}

// ===========================================================================
// 1A. The strict barrier, and the wording that goes with it
// ===========================================================================
{
  population({ Barrier: 'active', Other: 'active' });
  resetWorld({ goLive: W(-6), weeks: range(-6, 0) });
  mark('Other', -1, 'present');
  finAll(-6, -5, -3, -2, -1); // W(-4) is left awaiting finalization
  const run = streakOf('Barrier');
  assert.equal(run.streak, 3, 'W(-1), W(-2), W(-3) are counted; the run is NOT carried across W(-4)');
  assert.equal(run.blocked, true);
  assert.equal(run.blockedOn.sessionId, S(-4).id);
  assert.notEqual(run.streak, 5, 'the earlier absences at W(-5) and W(-6) are not reached across the barrier');
  const status = attendance.followUpStatus();
  assert.equal(status.complete, false);
  assert.deepEqual(status.awaitingFridays.map((f) => f.id), [S(-4).id]);

  // With a shorter threshold than the visible run the member is listed, but never as a definitive count.
  setSetting('attendance.followup_threshold', 5);
  assert.equal(followUp().some((f) => f.member.id === id('Barrier')), false, 'below the threshold once the barrier cuts the run');
  assert.equal(streakOf('Barrier').possiblyUnderstated, true, 'and it is marked as possibly understated');
  setSetting('attendance.followup_threshold', 3);

  // The page says so, in words that do not imply "no concern".
  const port = await new Promise((resolve) => { const srv = net.createServer(); srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); }); });
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
  try {
    await waitForServerReady(base, server);
    const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email: 'handler@fixture.invalid', password: 'HandlerPassw0rd!2026', _csrf: csrf })
    });
    const cookie = cookieOf(login, pre);
    const html = await (await fetch(`${base}/attendance/follow-up`, { headers: { Cookie: cookie } })).text();
    assert.match(html, /Follow-up may be incomplete because attendance for one or more Fridays is awaiting finalization/);
    assert.match(html, /does not mean anyone\s+has no follow-up concern/);
  } finally {
    await terminateAndWait(server);
  }
  setSetting('attendance.followup_threshold', 3);
  console.log('PASS (1A) the barrier is strict and the follow-up page says the calculation is incomplete - never that there is no concern');
}

console.log('ALL PASS');
