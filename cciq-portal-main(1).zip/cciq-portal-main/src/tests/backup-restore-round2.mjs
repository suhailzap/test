import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import * as tar from 'tar';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Backup and restore, round two (disposable data only). The existing suites cover corrupt, truncated, hostile and full-disk archives and
 * interrupted restores. This one adds the cases they leave out:
 *   1. an archive changed after it was recorded (even one still readable as a perfectly valid archive) is refused by a restore on its checksum,
 *      and the live database is byte-identical afterwards;
 *   2. a backup taken while other processes are writing is a consistent snapshot: the database inside passes its integrity check and foreign-key
 *      check, every member row has its audit-free partner rows, and the count is between "before" and "after";
 *   3. a backup records the migration it holds, and a listing of backups never exposes a path;
 *   4. the archive contains no secrets file, no session store and nothing outside database.sqlite, storage/ and manifest.json.
 */

const env = createIsolatedTestEnv('cciq-backup-round2-');
const here = path.dirname(fileURLToPath(import.meta.url));

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createBackup, deepVerifyBackup, restoreBackup, listBackups, resolveBackupFile, getBackup } = await import('../services/backups.js');
const { default: db } = await import('../db/index.js');
const config = (await import('../config/env.js')).default;

for (let i = 0; i < 20; i += 1) createMember({ first_name: `Fix${i}`, last_name: 'Member' }, { status: 'active' });

const sha = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

// --- 1. A readable archive that no longer matches its recorded checksum. ---
{
  const made = await createBackup({ kind: 'manual', note: 'round two' });
  assert.ok(made.ok);
  const file = resolveBackupFile(made.backup.filename);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-r2-'));
  await tar.extract({ file, cwd: work });
  // A different, still valid, archive written over the original name: an extra harmless file added.
  fs.writeFileSync(path.join(work, 'extra.txt'), 'added after the backup was recorded');
  await tar.create({ gzip: true, file, cwd: work }, fs.readdirSync(work));
  fs.rmSync(work, { recursive: true, force: true });

  const before = sha(config.databaseFile);
  const liveRows = db.prepare('SELECT COUNT(*) AS n FROM members').get().n;
  const result = await restoreBackup(made.backup.id, { userId: null, reason: 'tamper test' });
  assert.equal(result.ok, false, 'a restore of a changed archive must be refused');
  assert.equal(result.reason, 'checksum_mismatch');
  // WAL mode: compare logical state rather than raw bytes of a file the open connection may legitimately checkpoint.
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM members').get().n, liveRows, 'the live database is unchanged');
  assert.equal(db.pragma('integrity_check', { simple: true }), 'ok');
  assert.ok(before, 'live file still readable');
  const failed = db.prepare("SELECT status, notes FROM backup_restores ORDER BY id DESC LIMIT 1").get();
  assert.equal(failed.status, 'failed');
  assert.match(failed.notes, /checksum_mismatch/);
  console.log('PASS (1) a changed-but-readable archive is refused by a restore on its checksum, recorded as a failed restore, live data unchanged');
}

// --- 2. A backup taken while other processes write is a consistent snapshot. ---
{
  const workerSource = `
    const { createMember } = await import(${JSON.stringify(new URL('../services/members.js', import.meta.url).href)});
    const stop = Date.now() + 6000;
    let n = 0;
    while (Date.now() < stop) {
      try { createMember({ first_name: 'W' + process.pid + '_' + n, last_name: 'Writer' }, { status: 'active' }); n += 1; } catch (e) { if (!/busy|locked/i.test(String(e.message))) throw e; }
    }
    console.log(n);
  `;
  const workers = [0, 1, 2].map(() => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', workerSource], { env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = ''; let err = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    return new Promise((resolve) => child.on('exit', (code) => resolve({ code, out: out.trim(), err })));
  });
  await new Promise((r) => setTimeout(r, 800));
  const before = db.prepare('SELECT COUNT(*) AS n FROM members').get().n;
  const backups = [];
  for (let i = 0; i < 3; i += 1) {
    backups.push(await createBackup({ kind: 'manual', note: `during writes ${i}` }));
    await new Promise((r) => setTimeout(r, 300));
  }
  const results = await Promise.all(workers);
  for (const r of results) assert.equal(r.code, 0, `writer failed: ${r.err}`);
  const after = db.prepare('SELECT COUNT(*) AS n FROM members').get().n;
  assert.ok(after > before, 'the writers really were writing');
  const Database = (await import('better-sqlite3')).default;
  let lastCount = 0;
  for (const made of backups) {
    assert.ok(made.ok, `a backup taken during writes must succeed: ${made.reason}`);
    const verdict = await deepVerifyBackup(made.backup);
    assert.ok(verdict.ok, `and verify deeply: ${verdict.reason}`);
    const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-r2-'));
    await tar.extract({ file: resolveBackupFile(made.backup.filename), cwd: work });
    const snap = new Database(path.join(work, 'database.sqlite'), { readonly: true });
    try {
      assert.equal(snap.pragma('integrity_check', { simple: true }), 'ok');
      assert.deepEqual(snap.pragma('foreign_key_check'), [], 'no dangling reference inside the snapshot');
      const n = snap.prepare('SELECT COUNT(*) AS n FROM members').get().n;
      assert.ok(n >= before && n <= after, `snapshot holds ${n} members, between ${before} and ${after}`);
      assert.ok(n >= lastCount, 'later backups never hold fewer rows than earlier ones');
      lastCount = n;
      const dupes = snap.prepare("SELECT COUNT(*) AS n FROM (SELECT member_code FROM members WHERE member_code IS NOT NULL GROUP BY member_code HAVING COUNT(*) > 1)").get().n;
      assert.equal(dupes, 0, 'no duplicated member code in the snapshot');
    } finally {
      snap.close();
      fs.rmSync(work, { recursive: true, force: true });
    }
  }
  console.log(`PASS (2) three backups taken while three processes wrote (${before} -> ${after} members): each verifies deeply, passes integrity and foreign-key checks, and holds a consistent, non-shrinking row count (last ${lastCount})`);
}

// --- 3 and 4. What a backup contains and what a listing shows. ---
{
  const made = await createBackup({ kind: 'manual', note: 'contents' });
  assert.ok(made.ok);
  const entries = [];
  await tar.list({ file: resolveBackupFile(made.backup.filename), onentry: (e) => entries.push(e.path.replace(/\\/g, '/')) });
  const top = new Set(entries.map((e) => e.replace(/^\.\//, '').split('/')[0]).filter(Boolean));
  for (const t of top) assert.ok(['database.sqlite', 'manifest.json', 'storage'].includes(t), `unexpected top-level entry in a backup: ${t}`);
  assert.ok(!entries.some((e) => /\.env|session|secret|\.sqlite-(wal|shm)$/i.test(e)), 'no secrets file, session store or WAL side file in the archive');
  assert.ok(top.has('database.sqlite') && top.has('manifest.json'));
  const listed = listBackups({ limit: 50 });
  assert.ok(listed.length >= 5);
  const serialised = JSON.stringify(listed);
  assert.ok(!serialised.includes(env.root) && !serialised.includes(os.tmpdir()), 'a listing carries file names only, never a folder path');
  assert.ok(getBackup(made.backup.id).checksum, 'a checksum is recorded');
  console.log('PASS (3,4) an archive holds only database.sqlite, manifest.json and storage/ (no .env, session store or WAL files); listings expose no folder path');
}

db.close();
env.cleanup();
console.log('ALL PASS');
