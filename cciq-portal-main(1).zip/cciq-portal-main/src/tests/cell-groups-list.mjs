import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Cell groups list: a dense desktop table (cards only on mobile) with search, status and meeting-day
 * filters and sortable columns, choices kept in the query string. Membership semantics and the
 * "a leader only sees their own group" scope are unchanged.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-groups-list-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createGroup } = await import('../services/cell-groups.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Cg${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'groups_admin', email: 'groups.admin@fixture.invalid', password: PASSWORD, displayName: 'Groups Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Saturday'];
const groups = [];
for (let i = 1; i <= 22; i += 1) {
  const leader = createMember({ first_name: `Leader${String(i).padStart(2, '0')}`, last_name: 'Groups' }, { status: 'active' });
  const group = createGroup({
    name: `Group ${String(i).padStart(2, '0')}`, leader_member_id: leader.id, meeting_day: days[i % days.length],
    meeting_time: '19:00', meeting_location: `Home ${i}`, status: i === 21 ? 'inactive' : (i === 22 ? 'archived' : 'active')
  });
  groups.push({ group, leader });
  for (let m = 0; m < (i % 5) + 1; m += 1) {
    const member = createMember({ first_name: `Mem${i}x${m}`, last_name: 'Groups', cell_group_id: group.id }, { status: 'active' });
    void member;
  }
}
// A leader account, scoped to exactly one group.
const scoped = groups[4];
await createUser({ username: 'group_leader', email: 'group.leader@fixture.invalid', password: PASSWORD, displayName: 'Group Leader', roleKeys: ['cell_group_leader'], memberId: scoped.leader.id, mustChangePassword: false });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function session(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const adminCookie = await session('groups.admin@fixture.invalid');
  const leaderCookie = await session('group.leader@fixture.invalid');
  const html = async (cookie, query = '') => {
    const res = await fetch(`${base}/cell-groups${query ? `?${query}` : ''}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, query);
    return res.text();
  };
  const rowsOf = (markup) => (markup.match(/<tbody>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 1;
  const namesOf = (markup) => [...markup.matchAll(/<td data-label="Group">\s*<a href="\/cell-groups\/\d+"[^>]*>([^<]+)<\/a>/g)].map((m) => m[1]);

  let markup = await html(adminCookie);
  assert.equal(rowsOf(markup), 22, 'every group is one compact row');
  assert.match(markup, /data--dense/, 'the dense table');
  assert.match(markup, /<ul class="record-list">/, 'with cards for mobile');
  assert.doesNotMatch(markup, /class="card__foot"/, 'not one tall card per group any more');
  assert.match(markup, /22 groups/);
  assert.deepEqual(namesOf(markup).slice(0, 3), ['Group 01', 'Group 02', 'Group 03'], 'sorted by name by default');

  assert.deepEqual(namesOf(await html(adminCookie, 'q=Group+07')), ['Group 07'], 'search by group name');
  assert.deepEqual(namesOf(await html(adminCookie, 'q=Leader12')), ['Group 12'], 'search by leader');
  assert.deepEqual(namesOf(await html(adminCookie, 'q=Home+9')), ['Group 09'], 'search by meeting place');
  assert.deepEqual(namesOf(await html(adminCookie, 'status=inactive')), ['Group 21']);
  assert.deepEqual(namesOf(await html(adminCookie, 'status=archived')), ['Group 22']);
  const monday = groups.filter((g) => g.group.meeting_day === 'Monday').length;
  assert.equal(rowsOf(await html(adminCookie, 'day=Monday')), monday, 'meeting day filter');
  assert.equal(rowsOf(await html(adminCookie, 'day=Funday')), 22, 'a junk day is ignored');
  const byMembers = namesOf(await html(adminCookie, 'sort=members&direction=desc'));
  const counts = db.prepare("SELECT g.name, (SELECT COUNT(*) FROM members m WHERE m.cell_group_id = g.id AND m.status != 'archived') n FROM cell_groups g").all();
  const countOf = Object.fromEntries(counts.map((c) => [c.name, c.n]));
  for (let i = 1; i < byMembers.length; i += 1) assert.ok(countOf[byMembers[i - 1]] >= countOf[byMembers[i]], 'members, descending');
  assert.deepEqual(namesOf(await html(adminCookie, 'sort=name&direction=desc'))[0], 'Group 22');
  assert.equal(rowsOf(await html(adminCookie, 'sort=nonsense')), 22, 'unknown sort falls back');
  markup = await html(adminCookie, 'q=Group&status=active&sort=leader');
  assert.match(markup, /href="\/cell-groups\?[^"]*q=Group[^"]*"/, 'column links keep the search and filters');
  assert.match(markup, /<input type="hidden" name="sort" value="leader">/);
  assert.match(markup, /No groups match|Group 01/);
  assert.match(await html(adminCookie, 'q=zzzznothing'), /No groups match those filters/);
  console.log('PASS (cell groups list) one dense row per group, search, status and day filters, sortable columns, mobile cards, query state kept');

  // Scope unchanged: a leader sees only their own group.
  markup = await html(leaderCookie);
  assert.deepEqual(namesOf(markup), [scoped.group.name], 'a Cell Group Leader still sees only the group they lead');
  assert.match(markup, /The groups you lead or belong to/);
  console.log('PASS (scope) a Cell Group Leader only sees their own group');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
