import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Per-document "Who can view this?", stricter only: the CATEGORY is the maximum audience and a document can only narrow it.
 * Every document path is tried as every role - library, Recent, My uploads, Expiring, Archived, category counts, tag cloud, search, the detail page, the file, a
 * version of the file, edit, replace, archive and restore, and the pages that list a record's documents - and a document a person may not open must not exist for them:
 * no title, no tag, no count, no file, whatever address they type.
 *
 * Visibility matrix (rows are documents; "cat" = legacy behaviour):
 *   legacy, members category ........ leaders yes, members yes, church yes, super yes
 *   legacy, leaders category ........ leaders yes, members NO
 *   legacy, staff category .......... leaders NO, members NO
 *   narrowed to Church Admin + Super Admin (members category) ...... only those two
 *   narrowed to Cell Group leaders .. leaders yes (and the Super Admin); Church Admin NO
 *   narrowed to Members ............. members yes, leaders yes (a leader is also a member), Super Admin yes, Church Admin NO
 *   narrowed to Super Admin only .... only the Super Admin
 *   a hand-written row that tries to WIDEN a staff document to Members: nobody below its category can open it (the ceiling is in the query)
 */

const f = await buildPortalFixture('cciq-doc-audience-');
const { db, ids, users, mods } = f;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const file = { originalname: 'scan.png', buffer: png, size: png.length };
const cat = (name, audience) => mods.documents.createCategory({ name, audience, description: null }).id;
const staffCat = cat('Staff only', 'staff'); const leadersCat = cat('For leaders', 'leaders'); const membersCat = cat('For everyone', 'members');
const soon = mods.dates.addDays(mods.dates.today(), 10);
const make = (title, categoryId, { audience = null, by = users.churchAdmin.id, tags = [], expiry = null, relations = [] } = {}) =>
  mods.documents.createDocument({ title, category_id: categoryId, description: `${title} text`, tags, expiry_date: expiry, relations, audience: audience ? { mode: 'roles', roles: audience } : undefined }, { userId: by, file });
const D = {
  legacyMembers: make('Legacy members doc', membersCat, { tags: ['legacytag'], expiry: soon }),
  legacyLeaders: make('Legacy leaders doc', leadersCat, { tags: ['leaderstag'] }),
  legacyStaff: make('Legacy staff doc', staffCat, { tags: ['stafftag'] }),
  admins: make('Admins-only narrowed doc', membersCat, { audience: ['super_admin', 'church_admin'], tags: ['adminstag'], expiry: soon }),
  leadersOnly: make('Leaders-only narrowed doc', membersCat, { audience: ['cell_group_leader'], tags: ['leaderonlytag'] }),
  membersOnly: make('Members-only narrowed doc', membersCat, { audience: ['member'], tags: ['membersonlytag'] }),
  superOnly: make('Super-only narrowed doc', membersCat, { audience: ['super_admin'], tags: ['superonlytag'], expiry: soon }),
  churchLeaders: make('Leaders narrowed to Church doc', leadersCat, { audience: ['church_admin'], tags: ['churchleaderstag'] }),
  mixed: make('Members and leaders narrowed doc', membersCat, { audience: ['member', 'cell_group_leader'], tags: ['mixedtag'] }),
  widen: make('Hand-widened staff doc', staffCat, { tags: ['widentag'] }),
  ownByLeader: make('Leader uploaded for admins doc', membersCat, { audience: ['church_admin'], by: users.leaderA.id, tags: ['ownleadertag'] }),
  archivedLegacy: make('Archived admins doc', membersCat, { audience: ['church_admin'], tags: ['archivedtag'] }),
  linked: make('Linked to group Alpha doc', membersCat, { audience: ['church_admin'], relations: [{ type: 'cell_group', id: ids.groupA }] }),
  linkedOpen: make('Linked open doc', membersCat, { relations: [{ type: 'cell_group', id: ids.groupA }] })
};
// the hand-written attempt to widen a staff document (the form refuses this; the database row is written directly)
db.prepare("UPDATE documents SET audience_mode = 'roles' WHERE id = ?").run(D.widen.id);
for (const role of ['member', 'cell_group_leader']) db.prepare('INSERT INTO document_audience_roles (document_id, role_key) VALUES (?, ?)').run(D.widen.id, role);
mods.documents.setStatus(D.archivedLegacy.id, 'archived');

const MATRIX = {
  // [super, church, leader, member]
  legacyMembers: [1, 1, 1, 1], legacyLeaders: [1, 1, 1, 0], legacyStaff: [1, 1, 0, 0], admins: [1, 1, 0, 0], leadersOnly: [1, 0, 1, 0], membersOnly: [1, 0, 1, 1],
  superOnly: [1, 0, 0, 0], churchLeaders: [1, 1, 0, 0], mixed: [1, 0, 1, 1], widen: [1, 0, 0, 0], ownByLeader: [1, 1, 0, 0], archivedLegacy: [1, 1, 0, 0], linked: [1, 1, 0, 0], linkedOpen: [1, 1, 1, 1]
};
const ROLES = ['super', 'church', 'leader', 'member'];
const mayOpen = (key, who) => Boolean(MATRIX[key][ROLES.indexOf(who)]);

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const c = { super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD), leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD),
    member: await signIn(portal.base, users.memberA.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD) };
  const get = async (client, url) => { const r = await client.get(url); return { status: r.status, body: await r.text(), location: r.headers.get('location'), type: r.headers.get('content-type') || '' }; };
  const titleIn = (body, title) => body.includes(title);
  const open = (r) => r.status === 200;

  // ---- 1. every discovery path, every role ---------------------------------------------------------------------------------------------------------------------------------------------------------
  const listPaths = ['/documents', '/documents?view=list', '/documents/recent', '/documents/expiring', '/documents?sort=name_az', '/documents?q=doc', '/documents?q=narrowed', '/documents?kind=image'];
  for (const who of ROLES) {
    for (const path of listPaths) {
      const page = await get(c[who], path); assert.equal(page.status, 200, `${who} ${path}`);
      for (const [key, doc] of Object.entries(D)) {
        if (key === 'archivedLegacy' || key === 'ownByLeader' && path !== '/documents/mine') { /* handled below for archived; ownByLeader is just another document here */ }
        const expected = mayOpen(key, who) && key !== 'archivedLegacy' && (path !== '/documents/expiring' || Boolean(doc.expiry_date)) && (path !== '/documents?q=narrowed' || /narrowed/.test(doc.title));
        if (path === '/documents?q=doc' || path === '/documents?q=narrowed' || path === '/documents/expiring') { if (!expected) assert.ok(!titleIn(page.body, doc.title), `${who} ${path}: "${doc.title}" must not appear`); else assert.ok(titleIn(page.body, doc.title), `${who} ${path}: "${doc.title}" should appear`); }
        else if (!mayOpen(key, who) || key === 'archivedLegacy') assert.ok(!titleIn(page.body, doc.title), `${who} ${path}: "${doc.title}" must not appear`);
        else if (path === '/documents' || path === '/documents?view=list') assert.ok(titleIn(page.body, doc.title), `${who} ${path}: "${doc.title}" should appear`);
      }
    }
    // the tag cloud and the category counts carry nothing from a document the person cannot open
    const lib = await get(c[who], '/documents');
    for (const [key, tag] of Object.entries({ legacyMembers: 'legacytag', legacyLeaders: 'leaderstag', legacyStaff: 'stafftag', admins: 'adminstag', leadersOnly: 'leaderonlytag', membersOnly: 'membersonlytag', superOnly: 'superonlytag', churchLeaders: 'churchleaderstag', mixed: 'mixedtag', widen: 'widentag' })) {
      if (!mayOpen(key, who)) assert.ok(!lib.body.includes(tag), `${who}: the tag "${tag}" of a hidden document does not exist for them`);
    }
    const cats = await get(c[who], '/documents/categories'); assert.equal(cats.status, 200);
  }
  // category counts: the number of documents the person may open (hidden ones are not counted)
  { const numberFor = (body, name) => { const m = new RegExp(`${name}[\\s\\S]{0,600}?data-label="Documents"[^>]*>\\s*(\\d+)`).exec(body); return m ? Number(m[1]) : null; };
    const expectedCount = (who, categoryId) => Object.entries(D).filter(([key, d]) => d.category_id === categoryId && key !== 'archivedLegacy' && mayOpen(key, who)).length;
    for (const who of ROLES) { const body = (await get(c[who], '/documents/categories')).body; for (const [name, id] of [['For everyone', membersCat], ['For leaders', leadersCat], ['Staff only', staffCat]]) { const shown = numberFor(body, name); if (shown !== null) assert.equal(shown, expectedCount(who, id), `${who}: the "${name}" count is what they may open`); } } }
  console.log('PASS (lists) the library (grid and list), Recent, Expiring, search and the tag cloud show each role exactly the documents it may open; nothing from a hidden document (title, tag, count) appears');

  // ---- 2. My uploads and Archived ---------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const mine = await get(c.leader, '/documents/mine'); assert.ok(!titleIn(mine.body, D.ownByLeader.title), 'a document the leader uploaded but narrowed away from themselves is not in My uploads (uploading is not a grant)');
    const adminMine = await get(c.church, '/documents/mine'); assert.ok(!titleIn(adminMine.body, D.ownByLeader.title), 'and it is not the Church Admin\'s upload');
    const archived = { super: await get(c.super, '/documents/archived'), church: await get(c.church, '/documents/archived'), leader: await get(c.leader, '/documents/archived'), member: await get(c.member, '/documents/archived') };
    assert.ok(archived.leader.status === 403 && archived.member.status === 403, 'Archived is for administrators');
    assert.ok(titleIn(archived.super.body, D.archivedLegacy.title) && titleIn(archived.church.body, D.archivedLegacy.title), 'both administrators see a document narrowed to the Church Admin in Archived');
    for (const key of ['superOnly']) assert.ok(true); }
  // archive a Super-only document: the Super Admin sees it in Archived, the Church Admin does not
  { const csrf = await c.super.csrf('/account/password'); const r = await c.super.post(`/documents/${D.superOnly.id}/archive`, {}, { csrf }); await r.text(); assert.ok([302, 303].includes(r.status));
    const sup = await get(c.super, '/documents/archived'); const ch = await get(c.church, '/documents/archived');
    assert.ok(titleIn(sup.body, D.superOnly.title), 'the Super Admin sees it archived'); assert.ok(!titleIn(ch.body, D.superOnly.title), 'the Church Admin does not'); await (await c.super.post(`/documents/${D.superOnly.id}/restore`, {}, { csrf })).text(); }
  console.log('PASS (mine, archived) My uploads and Archived follow the same rule; being the uploader is not a grant');

  // ---- 3. the detail page, the file, a version, edit and replace, by address -----------------------------------------------------------------------------------------------------------
  for (const who of ROLES) {
    for (const [key, doc] of Object.entries(D)) {
      const expectedOpen = mayOpen(key, who);
      const urls = [`/documents/${doc.id}`, `/documents/${doc.id}/file`, `/documents/${doc.id}/file?download=1`, `/documents/${doc.id}/file?version=1`];
      for (const url of urls) {
        const r = await c[who].get(url); const buf = Buffer.from(await r.arrayBuffer());
        if (expectedOpen) { assert.equal(r.status, 200, `${who} ${url} should open`); if (url.includes('/file')) { assert.match(r.headers.get('content-type') || '', /image\/png/); assert.ok(buf.slice(0, 4).toString('hex') === '89504e47', `${who} ${url}: the real file`); } }
        else { assert.ok(r.status === 404 || r.status === 403, `${who} ${url} -> ${r.status}`); assert.ok(!buf.includes(png.slice(0, 16)) || r.status !== 200, `${who} ${url}: no file bytes`); assert.ok(!buf.toString('latin1').includes(doc.title), `${who} ${url}: the refusal does not name the document`); }
      }
      for (const url of [`/documents/${doc.id}/edit`]) { const r = await get(c[who], url); if (!expectedOpen) assert.ok([403, 404].includes(r.status), `${who} ${url} -> ${r.status}`); }
    }
  }
  // the stored file by its path is not reachable at all
  { const stored = db.prepare('SELECT stored_path FROM documents WHERE id = ?').get(D.superOnly.id).stored_path;
    for (const url of [`/${stored}`, `/storage/${stored}`, `/media/${stored}`, `/documents/${D.superOnly.id}/${stored.split('/').pop()}`, `/public/${stored}`]) for (const who of ['member', 'leader', 'church']) { const r = await get(c[who], url); assert.ok(r.status === 404 || r.status === 403 || r.status === 302, `${who} ${url} -> ${r.status}`); assert.ok(r.type.indexOf('image/png') === -1, `${who} ${url}: no file`); } }
  // state-changing requests by address against a document the person may not open
  { const before = JSON.stringify(db.prepare('SELECT id, title, status, audience_mode, category_id FROM documents ORDER BY id').all()); const rolesBefore = JSON.stringify(db.prepare('SELECT * FROM document_audience_roles ORDER BY document_id, role_key').all());
    for (const who of ['church', 'leader', 'member']) {
      const csrf = await c[who].csrf('/account/password');
      for (const [key, doc] of Object.entries(D)) {
        if (mayOpen(key, who)) continue;
        for (const [path, fields] of [[`/documents/${doc.id}`, { title: 'Hijacked', category_id: String(membersCat), audience_all: '1' }], [`/documents/${doc.id}/archive`, {}], [`/documents/${doc.id}/restore`, {}], [`/documents/${doc.id}/delete`, { confirm: doc.title }]]) {
          const r = await c[who].post(path, fields, { csrf }); await r.text(); assert.ok([403, 404].includes(r.status) || (r.status === 302 && /\/(login|documents$|kiosk)/.test(r.headers.get('location') || '')), `${who} POST ${path} -> ${r.status} ${r.headers.get('location') || ''}`);
        }
      }
    }
    assert.equal(JSON.stringify(db.prepare('SELECT id, title, status, audience_mode, category_id FROM documents ORDER BY id').all()), before, 'refused requests changed no document'); assert.equal(JSON.stringify(db.prepare('SELECT * FROM document_audience_roles ORDER BY document_id, role_key').all()), rolesBefore); }
  console.log('PASS (direct addresses) the page, the file, a file version, the edit form and every state-changing request are refused (404/403, naming nothing, sending no bytes) for a person who may not open the document, whatever address they type');

  // ---- 4. the Kiosk gets nothing ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  for (const url of ['/documents', '/documents/recent', `/documents/${D.legacyMembers.id}`, `/documents/${D.legacyMembers.id}/file`, '/documents/new', '/search?q=doc', '/documents/categories']) { const r = await get(c.kiosk, url); assert.ok(r.status === 302 && r.location === '/kiosk' || r.status === 403, `Kiosk ${url} -> ${r.status}`); assert.ok(!r.body.includes('Legacy members doc')); }

  // ---- 5. global search applies the same rule -----------------------------------------------------------------------------------------------------------------------------------------------------
  for (const who of ROLES) {
    const r = await get(c[who], '/search?q=doc'); assert.equal(r.status, 200);
    for (const [key, doc] of Object.entries(D)) { const one = await get(c[who], `/search?q=${encodeURIComponent(doc.title)}`); const shown = one.body.includes(`/documents/${doc.id}"`); const expected = mayOpen(key, who) && key !== 'archivedLegacy'; assert.equal(shown, expected, `${who}: search ${expected ? 'finds' : 'must not find'} "${doc.title}"`); if (!mayOpen(key, who)) assert.ok(!one.body.replace(/<input[^>]*>/g, '').replace(/&ldquo;[^&]*&rdquo;/g, '').includes(`>${doc.title}<`), `${who}: search shows no title of "${doc.title}"`); }
    const count = (/<h2>Documents<\/h2>\s*<span class="list__meta">(\d+)<\/span>/.exec(r.body) || [])[1];
    // the count never exceeds what they may open (the search page is capped at 8 per kind)
    const maxOpen = Object.entries(D).filter(([key, d]) => mayOpen(key, who) && key !== 'archivedLegacy').length; if (count !== undefined) assert.equal(Number(count), Math.min(8, maxOpen), `${who}: the Documents group count is what they may open (capped at 8)`);
  }
  // searching for a hidden document by its tag or its description finds nothing for a person who may not open it
  { for (const [term, key] of [['superonlytag', 'superOnly'], ['Super-only narrowed doc', 'superOnly'], ['adminstag', 'admins'], ['stafftag', 'legacyStaff']]) for (const who of ['leader', 'member']) { const r = await get(c[who], `/search?q=${encodeURIComponent(term)}`); const quiet = (html) => html.replace(/<input[^>]*>/g, '').replace(/&ldquo;[^&]*&rdquo;/g, '').replace(/<title>[^<]*<\/title>/g, ''); assert.ok(!r.body.includes(`/documents/${D[key].id}"`) && !quiet(r.body).includes(D[key].title), `${who} cannot find "${term}"`); const lib = await get(c[who], `/documents?q=${encodeURIComponent(term)}`); assert.ok(!lib.body.includes(`/documents/${D[key].id}"`) && !quiet(lib.body).replace(/value="[^"]*"/g, '').includes(D[key].title), `${who} library search "${term}"`); } }
  console.log('PASS (search) the library search and the portal search find a document only for people who may open it, by title, text or tag; counts and snippets of hidden documents do not exist');

  // ---- 6. a record's documents (cell group page) ----------------------------------------------------------------------------------------------------------------------------------------------
  { const asMember = await get(c.member, `/cell-groups/${ids.groupA}`); const asLeader = await get(c.leader, `/cell-groups/${ids.groupA}`); const asChurch = await get(c.church, `/cell-groups/${ids.groupA}`);
    assert.ok(!asMember.body.includes(D.linked.title) && !asLeader.body.includes(D.linked.title), 'a document narrowed to the Church Admin is not listed on the group page for a member or leader');
    assert.ok(asChurch.body.includes(D.linked.title), 'but it is for the Church Admin'); assert.ok(asMember.body.includes(D.linkedOpen.title), 'and an open linked document is listed for the member'); }

  // ---- 7. the category ceiling is in the query: a later change of category can only narrow ------------------------------------------------------------------------------------
  { db.prepare("UPDATE document_categories SET audience = 'staff' WHERE id = ?").run(membersCat);
    for (const key of ['membersOnly', 'mixed', 'legacyMembers']) { const r = await c.member.get(`/documents/${D[key].id}`); await r.text(); assert.equal(r.status, 404, `member: "${D[key].title}" closes when its category becomes staff-only`); }
    const ch = await get(c.church, `/documents/${D.legacyMembers.id}`); assert.equal(ch.status, 200, 'an administrator still opens a legacy document');
    db.prepare("UPDATE document_categories SET audience = 'members' WHERE id = ?").run(membersCat);
    const back = await get(c.member, `/documents/${D.membersOnly.id}`); assert.equal(back.status, 200, 'and it reopens as soon as the category is a members category again (nothing was rewritten)'); }
  console.log('PASS (ceiling) a document narrowed to Members closes when its category becomes staff-only and reopens when it is widened back: the category is the maximum and is read on every query');

  // ---- 8. the upload form and what it accepts ------------------------------------------------------------------------------------------------------------------------------------------------------
  const main = (body) => ((/<main[\s\S]*?<\/main>/.exec(body) || [body])[0]);
  { const form = await get(c.church, '/documents/new'); assert.equal(form.status, 200); const m = main(form.body);
    assert.match(m, /<h2>Who can view this\?<\/h2>/); assert.match(m, /This document can be restricted further, but it cannot be shared more widely than its category allows\./);
    assert.match(m, /Everyone allowed by this category/);
    for (const label of ['Super Admin', 'Church Admin', 'Cell Group leaders', 'Members']) assert.ok(m.includes(`<span>${label}</span>`), `${label} is offered`);
    assert.ok(!/Kiosk/i.test(/<section class="form-section">\s*<div class="form-section__intro">\s*<h2>Who can view this\?[\s\S]*?<\/section>/.exec(m)[0]), 'the Kiosk is not an audience'); assert.ok(!/System Admin/.test(m), '"System Admin" is not a role here');
    assert.ok(!/internal|documents\.manage|giving\./.test(/<h2>Who can view this\?[\s\S]*?<\/section>/.exec(m)[0]), 'no permission names are exposed');
    const map = JSON.parse(/data-category-roles="([^"]+)"/.exec(m)[1].replace(/&#34;|&quot;/g, '"')); assert.deepEqual(map[staffCat], ['super_admin', 'church_admin']); assert.deepEqual(map[leadersCat], ['super_admin', 'church_admin', 'cell_group_leader']); assert.deepEqual(map[membersCat], ['super_admin', 'church_admin', 'cell_group_leader', 'member']); }
  const cookieOf = (client) => client.cookie;
  const post = async (client, url, fields, withFile = true) => {
    const token = await client.csrf('/account/password'); const body = new FormData(); body.append('_csrf', token);
    for (const [k, v] of Object.entries(fields)) for (const one of [].concat(v)) body.append(k, String(one));
    if (withFile) body.append('file', new Blob([png], { type: 'image/png' }), 'scan.png');
    const r = await fetch(`${portal.base}${url}`, { method: 'POST', redirect: 'manual', headers: { Cookie: cookieOf(client) }, body }); return { status: r.status, body: await r.text(), location: r.headers.get('location') };
  };
  const upload = (client, fields) => post(client, '/documents', { title: 'Upload test', category_id: membersCat, ...fields });
  const stored = (title) => { const d = db.prepare('SELECT * FROM documents WHERE title = ? ORDER BY id DESC').get(title); return d ? { ...d, roles: db.prepare('SELECT role_key FROM document_audience_roles WHERE document_id = ? ORDER BY role_key').all(d.id).map((r) => r.role_key) } : null; };
  { // a narrower choice is stored; "everyone" wins over roles; nothing chosen is the category
    let r = await upload(c.church, { title: 'Narrow ok', audience_roles: ['church_admin', 'super_admin'] }); assert.equal(r.status, 302); let d = stored('Narrow ok'); assert.equal(d.audience_mode, 'roles'); assert.deepEqual(d.roles, ['church_admin', 'super_admin']);
    assert.ok(db.prepare("SELECT 1 FROM audit_logs WHERE action = 'document.uploaded' AND CAST(entity_id AS TEXT) = ? AND detail LIKE '%church_admin%'").get(String(d.id)), 'the upload audit row records the audience');
    r = await upload(c.church, { title: 'Everyone wins', audience_all: '1', audience_roles: ['super_admin'] }); d = stored('Everyone wins'); assert.equal(d.audience_mode, 'category'); assert.deepEqual(d.roles, [], 'a contradictory combination is not stored');
    r = await upload(c.church, { title: 'Nothing chosen' }); d = stored('Nothing chosen'); assert.equal(d.audience_mode, 'category'); assert.deepEqual(d.roles, []);
    // crafted: a role the category does not allow, an unknown role, the Kiosk, an object-shaped value
    for (const [title, fields] of [['Widen staff', { category_id: staffCat, audience_roles: ['member'] }], ['Widen staff leaders', { category_id: staffCat, audience_roles: ['church_admin', 'cell_group_leader'] }], ['Widen leaders', { category_id: leadersCat, audience_roles: ['member'] }], ['Kiosk role', { audience_roles: ['kiosk'] }], ['System admin', { audience_roles: ['system_admin'] }], ['Object', { 'audience_roles[x]': 'super_admin' }], ['Junk', { audience_roles: ['', ' ', '<script>'] }]]) {
      const before = db.prepare('SELECT COUNT(*) n FROM documents').get().n; r = await upload(c.church, { title, ...fields });
      if (title === 'Object') { assert.ok(r.status === 302 || r.status === 400, `${title} -> ${r.status}`); continue; }
      assert.equal(r.status, 400, `${title} is refused (${r.status})`); assert.equal(db.prepare('SELECT COUNT(*) n FROM documents').get().n, before, `${title}: nothing stored`); assert.equal(stored(title), null);
      assert.match(r.body, /cannot be shared with|from the roles offered/, `${title}: says why`);
    }
    // a person cannot narrow a document away from themselves (unless they are the Super Admin, who always sees everything)
    r = await upload(c.church, { title: 'Church excludes self', audience_roles: ['super_admin'] }); assert.equal(r.status, 400); assert.match(r.body, /would not be able to open this document yourself/); assert.equal(stored('Church excludes self'), null);
    r = await upload(c.super, { title: 'Super only ok', audience_roles: ['super_admin'] }); assert.equal(r.status, 302, 'the Super Admin may choose any narrowing'); assert.equal(stored('Super only ok').audience_mode, 'roles');
    // a leader: can narrow within the leaders' reach; cannot reach beyond; cannot exclude themselves
    r = await upload(c.leader, { title: 'Leader narrow', audience_roles: ['cell_group_leader'] }); assert.equal(r.status, 302); assert.deepEqual(stored('Leader narrow').roles, ['cell_group_leader']);
    r = await upload(c.leader, { title: 'Leader to staff cat', category_id: staffCat, audience_roles: ['church_admin'] }); assert.equal(r.status, 400, 'a leader cannot narrow a staff-category document to roles that exclude themselves'); assert.equal(stored('Leader to staff cat'), null);
    r = await upload(c.leader, { title: 'Leader excludes self', audience_roles: ['church_admin'] }); assert.equal(r.status, 400); assert.equal(stored('Leader excludes self'), null);
    r = await upload(c.member, { title: 'Member uploads', audience_roles: ['member'] }); assert.ok([403, 404].includes(r.status), `a Member cannot upload (${r.status})`); assert.equal(stored('Member uploads'), null);
    r = await upload(c.kiosk, { title: 'Kiosk uploads' }); assert.ok(r.status === 302 && r.location === '/kiosk' || r.status === 403); assert.equal(stored('Kiosk uploads'), null); }
  console.log('PASS (upload) a narrower choice is stored and audited; "Everyone allowed" wins over roles; crafted widenings, unknown roles and the Kiosk are refused with nothing stored; nobody can narrow a document away from themselves (the Super Admin always sees everything); Members and the Kiosk cannot upload');

  // hand-built field shapes (objects where text is expected) end as an ordinary refusal or error page, never as a crash of the portal
  { for (const field of ['title', 'category_id', 'description', 'tags', 'document_date', 'expiry_date', 'notes', 'vendor', 'amount', 'audience_all', 'member']) {
      const r = await upload(c.church, { [`${field}[x]`]: 'a' }); assert.ok(r.status < 600, `${field}[x] -> ${r.status}`);
      assert.equal((await fetch(`${portal.base}/healthz`)).status, 200, `the portal is still up after ${field}[x]`);
    }
    }

  // ---- 9. editing: audited, cannot widen, cannot be edited by someone who may not open it ----------------------------------------------------------------------------------------------
  { const target = stored('Narrow ok'); const csrf = await c.church.csrf('/account/password');
    // the edit form is an ordinary (urlencoded) form: repeated fields are repeated pairs
    const edit = async (client, id, fields) => {
      const token = await client.csrf('/account/password'); const body = new URLSearchParams({ _csrf: token });
      for (const [k, v] of Object.entries({ title: 'Narrow ok', category_id: membersCat, ...fields })) for (const one of [].concat(v)) body.append(k, String(one));
      const r = await fetch(`${portal.base}/documents/${id}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: client.cookie }, body });
      return { status: r.status, body: await r.text(), location: r.headers.get('location') };
    };
    let r = await edit(c.church, target.id, { audience_roles: ['church_admin'] }); assert.equal(r.status, 302); let d = stored('Narrow ok'); assert.deepEqual(d.roles, ['church_admin']);
    const a = db.prepare("SELECT * FROM audit_logs WHERE action = 'document.audience_changed' AND CAST(entity_id AS TEXT) = ? ORDER BY id DESC").get(String(target.id)); assert.ok(a, 'an audience change is its own audit row'); const detail = JSON.parse(a.detail);
    assert.deepEqual(detail.before, { mode: 'roles', roles: ['super_admin', 'church_admin'] }); assert.deepEqual(detail.after, { mode: 'roles', roles: ['church_admin'] }); assert.equal(a.user_id, users.churchAdmin.id);
    r = await edit(c.church, target.id, { audience_all: '1' }); d = stored('Narrow ok'); assert.equal(d.audience_mode, 'category'); assert.deepEqual(d.roles, [], 'back to the category');
    r = await edit(c.church, target.id, { audience_roles: ['church_admin'] }); r = await edit(c.church, target.id, { audience_roles: ['church_admin'] }); assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'document.audience_changed' AND CAST(entity_id AS TEXT) = ?").get(String(target.id)).n, 3, 'an unchanged save writes no audience row');
    // moving it to a stricter category while keeping a role that category cannot reach is refused (and nothing changes)
    const snapshot = JSON.stringify(stored('Narrow ok')); r = await edit(c.church, target.id, { category_id: staffCat, audience_roles: ['church_admin', 'member'] }); assert.equal(r.status, 400); assert.equal(JSON.stringify(stored('Narrow ok')), snapshot);
    r = await edit(c.church, target.id, { category_id: staffCat, audience_roles: ['church_admin'] }); assert.equal(r.status, 302, 'narrowing within the new, stricter category is fine');
    // the Church Admin cannot touch a document narrowed to the Super Admin only (it is invisible to them), and the Super Admin can
    const onlySuper = stored('Super only ok'); const attempt = await edit(c.church, onlySuper.id, { title: 'Super only ok', audience_all: '1' }); assert.ok([403, 404].includes(attempt.status), `the Church Admin cannot edit a Super Admin document (${attempt.status})`); assert.equal(stored('Super only ok').audience_mode, 'roles');
    const fixed = await edit(c.super, onlySuper.id, { title: 'Super only ok', audience_all: '1' }); assert.equal(fixed.status, 302); assert.equal(stored('Super only ok').audience_mode, 'category');
    // the edit form shows the stored choice
    const form = await get(c.church, `/documents/${target.id}/edit`); assert.equal(form.status, 200); assert.match(main(form.body), /<summary class="audience__summary"[^>]*>Church Admin<\/summary>/); assert.match(main(form.body), /name="audience_roles" value="church_admin" checked/);
    void csrf; }
  { const show = await get(c.church, `/documents/${D.admins.id}`); assert.match(main(show.body).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '), /Who can view this\s+Super Admin, Church Admin\s+Restricted/); const open = await get(c.church, `/documents/${D.legacyMembers.id}`); assert.match(main(open.body).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '), /Who can view this\s+Everyone allowed by this category/);
    const asLeader = await get(c.leader, `/documents/${D.leadersOnly.id}`); assert.ok(!/Who can view this/.test(main(asLeader.body)), 'a person who cannot edit is not shown the role list'); }
  console.log('PASS (edit) changing who can view a document is audited with before and after, an unchanged save writes nothing, a move to a stricter category refuses a role it cannot reach, and a document narrowed away from an administrator cannot be edited by them');

  // ---- 10. responsive: the upload form and its control -----------------------------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  const cookies = c.church.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  for (const width of [320, 375, 430, 768, 1024, 1280, 1440]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookies); const page = await context.newPage();
    for (const url of ['/documents/new', `/documents/${D.admins.id}/edit`, '/documents', `/documents/${D.admins.id}`, '/documents/categories']) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const m = await page.evaluate(() => ({ overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, error: /Something went wrong/.test(document.body.innerText) }));
      if (m.overflow > 0) problems.push(`${width}px ${url}: sideways scroll ${m.overflow}px`); if (m.error) problems.push(`${width}px ${url}: error page`);
    }
    // the control: collapsed by default, opens to a short list, follows the category, keeps "Everyone" and roles exclusive
    await page.goto(`${portal.base}/documents/new`, { waitUntil: 'load' });
    const summary = page.locator('[data-audience-summary]'); const text0 = (await summary.textContent()).trim(); if (text0 !== 'Everyone allowed by this category') problems.push(`${width}px: summary starts as "${text0}"`);
    const optionsVisible0 = await page.locator('.audience__options').isVisible(); if (optionsVisible0) problems.push(`${width}px: the list is open by default`);
    await summary.click(); if (!(await page.locator('.audience__options').isVisible())) problems.push(`${width}px: the list does not open`);
    await page.selectOption('#category_id', String(staffCat));
    const offered = await page.locator('[data-audience-role]:not([hidden])').evaluateAll((els) => els.map((e) => e.getAttribute('data-audience-role')));
    if (JSON.stringify(offered) !== JSON.stringify(['super_admin', 'church_admin'])) problems.push(`${width}px: a staff category offers ${offered.join(',')}`);
    await page.selectOption('#category_id', String(membersCat));
    await page.locator('[data-audience-role="church_admin"] input').check();
    if ((await page.locator('[data-audience-all]').isChecked())) problems.push(`${width}px: "Everyone" stays ticked beside a role`);
    if ((await summary.textContent()).trim() !== 'Church Admin') problems.push(`${width}px: summary "${(await summary.textContent()).trim()}"`);
    await page.locator('[data-audience-all]').check();
    if (await page.locator('[data-audience-role] input:checked').count()) problems.push(`${width}px: roles stay ticked beside "Everyone"`);
    const box = await page.locator('.audience__summary').boundingBox(); if (!box || box.height < 36) problems.push(`${width}px: the control is too small to tap (${box && box.height})`);
    const optionsBox = await page.locator('.audience__options').boundingBox(); if (optionsBox && optionsBox.x + optionsBox.width > width + 1) problems.push(`${width}px: the list runs off the screen`);
    await page.selectOption('#category_id', String(staffCat)); await summary.click();
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('; '));
  console.log('PASS (widths) the upload and edit forms, the library, the document page and the categories page at 320 to 1440 px: no sideways scroll; the Who can view this control is a compact summary that opens a short list, follows the category, keeps Everyone and roles exclusive and is tappable');
  console.log('PASS documents-audience');
} finally {
  await browser.close();
  await portal.stop();
}
