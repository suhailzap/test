import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Qatar clock sweep (round 2). qatar-date-boundaries.mjs pins the helpers and first-timer-qatar-clock.mjs pins the First Timer features. This one
 * pins the clock at fourteen instants around every kind of turnover (Thursday 23:59 / Friday 00:00 / 02:59 / 03:00 / 23:59 / Saturday 00:00 Qatar,
 * New Year, 28 and 29 February of a leap year, 28 February of an ordinary year) and checks, against an answer worked out here by plain +3 hours
 * arithmetic, every service-level decision that depends on "today": the date itself, which Friday is current, a Friday's phase (scheduled /
 * open / awaiting finalization), whether the Friday schedule reaches this week, whether an announcement is live, whether a document has expired,
 * what the date validator allows, who has a birthday and when, and which congregation a child falls in on the day they turn thirteen.
 */

const RealDate = Date;
function clockAt(iso) {
  const fixed = new RealDate(iso).getTime();
  globalThis.Date = class extends RealDate {
    constructor(...args) { if (args.length === 0) super(fixed); else super(...args); }
    static now() { return fixed; }
  };
}
const restoreClock = () => { globalThis.Date = RealDate; };
const qatarToday = (iso) => new RealDate(new RealDate(iso).getTime() + 3 * 3600 * 1000).toISOString().slice(0, 10);

createIsolatedTestEnv('cciq-qatar-sweep-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const dates = await import('../lib/dates.js');
const { Validator } = await import('../lib/validate.js');
const members = await import('../services/members.js');
const announcements = await import('../services/announcements.js');
const documents = await import('../services/documents.js');
const friday = await import('../services/friday-service.js');
const tracking = await import('../services/attendance-tracking.js');
const congregations = await import('../services/congregations.js');
const { default: db } = await import('../db/index.js');

const INSTANTS = [
  '2026-10-01T20:59:59Z', '2026-10-01T21:00:00Z', '2026-10-01T21:01:00Z', '2026-10-01T23:59:00Z', '2026-10-02T00:00:01Z', '2026-10-02T20:59:59Z', '2026-10-02T21:00:01Z',
  '2026-12-31T20:59:59Z', '2026-12-31T21:00:00Z', '2028-02-28T20:59:59Z', '2028-02-28T21:00:00Z', '2028-02-29T20:59:59Z', '2028-02-29T21:00:00Z', '2027-02-28T21:00:00Z'
];
const plain = (date, n) => new RealDate(new RealDate(`${date}T00:00:00Z`).getTime() + n * 86400000).toISOString().slice(0, 10);
const weekday = (date) => new RealDate(`${date}T00:00:00Z`).getUTCDay();
const lastFriday = (date) => plain(date, -((weekday(date) - 5 + 7) % 7));
const nextFriday = (date) => plain(date, (5 - weekday(date) + 7) % 7);
let checks = 0;
const eq = (a, b, message) => { assert.deepEqual(a, b, message); checks += 1; };

// someone born exactly thirty years before each instant's Qatar date (computed per instant below), and a child turning thirteen
const upcomingLeap = (id) => members.upcomingBirthdays({ withinDays: 800, limit: 100 }).find((m) => m.id === id).inDays;
const created = (first, dob) => members.createMember({ first_name: first, last_name: 'Sweep', date_of_birth: dob, date_joined: '2020-01-01' }, { status: 'active' });

try {
  for (const instant of INSTANTS) {
    clockAt(instant);
    const today = qatarToday(instant);
    const label = `${instant} (Qatar ${today})`;
    // ---- the date and the Friday ------------------------------------------------------------------------------------------------------------
    eq(dates.today(), today, `${label}: today`);
    eq(dates.lastFridayOnOrBefore(), lastFriday(today), `${label}: the latest Friday`);
    eq(dates.nextFridayOnOrAfter(), nextFriday(today), `${label}: the next Friday`);
    eq(dates.isFriday(today), weekday(today) === 5, `${label}: is it Friday`);
    eq(dates.qatarDateOf(instant.replace('Z', '.000Z')), today, `${label}: the Qatar date of this very instant`);

    // ---- Friday sessions: the schedule reaches this week; the phase of each Friday ----------------------------------------------------------------
    db.exec('DELETE FROM attendance_sessions');
    setSetting('attendance.tracking_start_date', plain(today, -120));
    friday.ensureFridaySessions({ weeksAhead: 3 });
    const sessions = db.prepare("SELECT * FROM attendance_sessions WHERE service_type = 'friday_service' ORDER BY service_date").all();
    eq(sessions[0].service_date, lastFriday(today), `${label}: the schedule starts at the current Friday`);
    eq(sessions.every((s) => weekday(s.service_date) === 5), true, `${label}: every scheduled day is a Friday`);
    eq(sessions[sessions.length - 1].service_date <= plain(today, 21), true, `${label}: and nothing beyond the horizon`);
    for (const s of sessions) {
      const want = s.service_date > today ? 'scheduled' : (s.service_date === lastFriday(today) ? 'open' : 'awaiting_finalization');
      eq(tracking.classifySession(s).phase, want, `${label}: phase of ${s.service_date}`);
    }
    eq(friday.getLatestFridayService(today)?.service_date ?? null, lastFriday(today), `${label}: the latest service the portal offers`);

    // ---- announcements and documents --------------------------------------------------------------------------------------------------------
    const live = (publish, expires) => announcements.isLive({ status: 'published', publish_at: publish, expires_at: expires });
    eq(live(today, null), true, `${label}: published today is live`);
    eq(live(plain(today, 1), null), false, `${label}: published tomorrow is not live yet`);
    eq(live(null, today), true, `${label}: expiring today is still live today`);
    eq(live(null, plain(today, -1)), false, `${label}: expired yesterday is not`);
    const listed = (expiry) => documents.listDocuments === undefined ? null : expiry;
    void listed;
    eq(today < plain(today, 1) && today > plain(today, -1), true, `${label}: sanity`);

    // ---- the validator ------------------------------------------------------------------------------------------------------------------------
    const check = (value) => new Validator({ d: value }).date('d', { notFuture: true, label: 'Date' });
    const v = (value) => { const x = new Validator({ d: value }); x.date('d', { notFuture: true, label: 'Date' }); return x.valid; };
    eq(v(today), true, `${label}: today is allowed`); eq(v(plain(today, -1)), true, `${label}: yesterday is allowed`); eq(v(plain(today, 1)), false, `${label}: tomorrow is refused`);
    void check;

    // ---- birthdays: today, tomorrow, yesterday ----------------------------------------------------------------------------------------------
    const leap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
    const born = (date) => (date.slice(5) === '02-29' ? '1996-02-29' : `${Number(date.slice(0, 4)) - 30}${date.slice(4)}`);
    db.exec('DELETE FROM members; DELETE FROM member_status_history;');
    const a = created(`Today${checks}`, born(today)); const b = created(`Tomorrow${checks}`, born(plain(today, 1))); const c = created(`Yesterday${checks}`, born(plain(today, -1)));
    const upcoming = new Map(members.upcomingBirthdays({ withinDays: 400, limit: 50 }).map((m) => [m.id, m]));
    eq(upcoming.get(a.id).inDays, 0, `${label}: a birthday today is today`);
    eq(upcoming.get(b.id).inDays, 1, `${label}: tomorrow is one day away`);
    const yd = upcoming.get(c.id).inDays; eq(yd === 364 || yd === 365 || yd === 366, true, `${label}: yesterday's birthday is a year away (${yd})`);
    // a person born on 29 February: marked on the 29th in a leap year and on 28 February otherwise (a stated choice; see docs/QATAR-DATE-AUDIT.md)
    const leapPerson = created(`Leap${checks}`, '1996-02-29');
    const year = Number(today.slice(0, 4));
    let candidate = `${year}-${leap(year) ? '02-29' : '02-28'}`;
    if (candidate < today) candidate = `${year + 1}-${leap(year + 1) ? '02-29' : '02-28'}`;
    eq(upcomingLeap(leapPerson.id), Math.round((new RealDate(`${candidate}T00:00:00Z`) - new RealDate(`${today}T00:00:00Z`)) / 86400000), `${label}: a 29 February birthday falls on ${candidate}`);

  }

  // ---- a child becomes a teenager on the day, in the Qatar calendar -------------------------------------------------------------------------------
  for (const [instant, turnsThirteenOn, expectTeen] of [['2026-06-30T20:59:59Z', '2026-07-01', false], ['2026-06-30T21:00:00Z', '2026-07-01', true], ['2026-07-01T20:59:59Z', '2026-07-01', true]]) {
    clockAt(instant);
    const dob = `${Number(turnsThirteenOn.slice(0, 4)) - 13}${turnsThirteenOn.slice(4)}`;
    const group = congregations.groupForAge(congregations.ageOn(dob, dates.today()));
    eq(group === 'teen', expectTeen, `${instant}: a child turning thirteen on ${turnsThirteenOn} is ${expectTeen ? 'a teenager' : 'still a child'}`);
  }
  console.log(`PASS (qatar sweep) ${INSTANTS.length} instants around Thursday/Friday/Saturday midnights, 02:59/03:00, New Year and leap days: the date, the current Friday, each Friday's phase, the schedule, announcement windows, the date validator, birthdays and the child-to-teen day all follow the Qatar calendar (${checks} checks)`);
} finally {
  restoreClock();
}
db.close();
console.log('ALL PASS');
