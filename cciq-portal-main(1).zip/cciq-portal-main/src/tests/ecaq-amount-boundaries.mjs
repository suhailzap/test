import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * Money typed into ECAQ and the document register. Found by the overnight hardening run: a 20-digit amount was accepted, after which the claim
 * total lost its cents and every later payment vanished from it silently (a REAL cannot hold that many digits). Amounts are now whole digits with
 * at most two decimals and at most nine digits before the point. This pins the boundary: what is refused leaves no row, no audit entry and no
 * change; what is accepted is exact; and a refused amount never breaks the next payment.
 */

const f = await buildPortalFixture('cciq-ecaq-amounts-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const csrfFrom = async (url) => (await (await admin.get(url)).text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const claimPage = `/admin/ecaq/claims/${ids.claim}`;
  const claim = () => db.prepare('SELECT amount_collected, payment_status FROM ecaq_giving_board_claims WHERE id = ?').get(ids.claim);
  const payments = () => db.prepare('SELECT COUNT(*) n FROM ecaq_payments WHERE claim_id = ?').get(ids.claim).n;
  const audits = () => db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'giving.payment_recorded'").get().n;

  const pay = async (amount) => {
    const csrf = await csrfFrom(claimPage);
    const res = await admin.post(`${claimPage}/payments`, { _csrf: csrf, amount, paid_on: today, method: 'cash' });
    await res.text();
    assert.ok(res.status < 500, `amount ${JSON.stringify(amount)} must not be a server error (${res.status})`);
  };

  const refused = ['99999999999999999999', '123456789012345.67', '1000000000', '1000000000.00', '1e3', '1E3', '-5', '+5', '0', '0.00', '0.005', '5.123',
    '1,000', '1 000', 'NaN', 'Infinity', '0x10', '', '.5', '5.', String.fromCharCode(0x0663, 0x0660), '5\n6', 'a'.repeat(5000)];
  for (const amount of refused) {
    const before = [payments(), audits(), JSON.stringify(claim())];
    await pay(amount);
    assert.deepEqual([payments(), audits(), JSON.stringify(claim())], before, `amount ${JSON.stringify(amount).slice(0, 30)} is refused and changes nothing`);
  }
  console.log(`PASS (refused) ${refused.length} malformed, signed, exponent, over-long, non-ASCII-digit and absurdly large amounts are refused: no payment, no audit row, claim unchanged`);

  const accepted = [['0.10', 0.1], [' 5 ', 5], ['0.01', 0.01], ['999999999.99', 999999999.99]];
  let total = 0;
  for (const [text, value] of accepted) {
    const before = payments();
    await pay(text);
    assert.equal(payments(), before + 1, `${JSON.stringify(text)} is recorded`);
    total = Math.round((total + value) * 100) / 100;
    assert.equal(claim().amount_collected, total, `the claim total is exactly ${total} after ${text}`);
  }
  await pay('0.10');
  assert.equal(claim().amount_collected, Math.round((total + 0.1) * 100) / 100, 'a small payment after the largest allowed one still counts to the cent');
  assert.deepEqual(checkInvariants(db).findings.filter((x) => x.severity === 'error' && x.code.startsWith('ecaq.')), [], 'every total still equals the sum of its payments');
  console.log('PASS (accepted) 0.01, 0.10, a padded 5 and the largest allowed 999,999,999.99 are recorded exactly, and the next small payment still adds to the cent');

  // The other places an amount is typed: all refuse an over-long number rather than storing it.
  const campaignsPage = '/admin/ecaq';
  const csrf = await csrfFrom(campaignsPage);
  const beforeCampaigns = db.prepare('SELECT COUNT(*) n FROM ecaq_campaigns').get().n;
  const year = Number(today.slice(0, 4));
  const res = await admin.post('/admin/ecaq/campaigns', { _csrf: csrf, name: 'Huge board', type: 'giving_board', year, amount_per_date: '99999999999999999999', status: 'draft' });
  await res.text();
  assert.ok(res.status < 500);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_campaigns').get().n, beforeCampaigns, 'a board with a 20-digit amount per date is refused');

  const faithBefore = db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments').get()?.n;
  const faithPage = `/admin/ecaq/faith-promise/commitments/${ids.commitment}`;
  const fres = await admin.post(`${faithPage}/payments`, { _csrf: await csrfFrom('/admin/ecaq/faith-promise'), amount: '99999999999999999999', paid_on: today });
  await fres.text();
  assert.ok(fres.status < 500);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments').get()?.n, faithBefore, 'a Faith Promise payment of 20 digits is refused too');
  const okRes = await admin.post(`${faithPage}/payments`, { _csrf: await csrfFrom('/admin/ecaq/faith-promise'), amount: '12.50', paid_on: today, received_by: 'Treasurer' });
  await okRes.text();
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments').get().n, faithBefore + 1, 'control: a normal amount posted to the same form is recorded, so the refusal above was the amount');
  console.log('PASS (other forms) a 20-digit board amount and a 20-digit Faith Promise payment are refused and store nothing');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
