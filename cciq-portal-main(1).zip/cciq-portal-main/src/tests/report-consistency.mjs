import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Paging is a way of showing a long list, never a way of changing what the list contains. For a dataset larger than any page and
 * larger than the old silent export caps (5,000 rows):
 *   - the total a screen reports is the same on every page and at every page size;
 *   - every CSV export holds every matching row, whatever page or page size was on screen, and filters narrow it exactly as they
 *     narrow the screen;
 *   - formula characters in exported text are neutralised.
 */

function parseCsv(text) {
  const rows = []; let row = []; let cell = ''; let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { cell += '"'; i += 1; } else if (ch === '"') quoted = false; else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(cell); cell = ''; } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell); cell = ''; rows.push(row); row = [];
    } else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

const f = await buildPortalFixture('cciq-report-consistency-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const now = new Date().toISOString();

// 5,200 extra members (more than the old 5,000-row export cap) and 5,200 extra audit rows, inserted directly and quickly.
const insertMember = db.prepare("INSERT INTO members (member_code, first_name, last_name, status, phone, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
const statuses = ['active', 'active', 'active', 'inactive', 'pending', 'archived', 'temporarily_away', 'attendee'];
db.transaction(() => {
  for (let i = 0; i < 5200; i += 1) insertMember.run(`CCIQ-X${String(i).padStart(5, '0')}`, `Bulk${i}`, i % 50 === 0 ? '=cmd|calc' : `Person${i % 97}`, statuses[i % statuses.length], `+974 5000 ${String(i).padStart(4, '0')}`, now, now);
  const audit = db.prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, result, detail, created_at) VALUES (NULL, 'bulk.test', 'member', ?, 'success', NULL, ?)");
  for (let i = 0; i < 5200; i += 1) audit.run(String(i), now);
})();

// 60 more Giving Board claims, each with two payments
const dates = mods.ecaq.boardDates(Number(today.slice(0, 4)));
for (let i = 0; i < 60; i += 1) {
  const made = mods.ecaq.createClaim({ campaignId: ids.board, date: dates[10 + i], memberId: ids.member.a3, commitmentAmount: 100, userId: users.churchAdmin.id });
  assert.ok(made.ok);
  mods.ecaq.addPayment(made.claim.id, { amount: 30 }, { userId: users.churchAdmin.id });
  mods.ecaq.addPayment(made.claim.id, { amount: 20 }, { userId: users.churchAdmin.id });
}

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const page = async (url) => (await admin.get(url)).text();
  const totalOn = (html) => { const m = html.match(/Showing \d+&ndash;\d+ of (\d+)/) || html.match(/of (\d+)\.<\/caption>/); return m ? Number(m[1]) : null; };
  const csv = async (url) => { const res = await admin.get(url); const text = await res.text(); assert.equal(res.status, 200, url); return parseCsv(text).filter((r) => r.length > 1 || r[0] !== ''); };

  // ---- the screen's total never depends on the page or the page size ---------------------------------------------------------------------
  const screens = [
    { url: '/members', param: '', dbCount: db.prepare("SELECT COUNT(*) n FROM members WHERE status IN ('active','pending','attendee','temporarily_away','bonafide')").get().n, flexible: true },
    { url: '/admin/audit', dbCount: null },
    { url: '/admin/ecaq', dbCount: null }
  ];
  for (const s of screens) {
    const totals = new Set();
    for (const q of ['', '?page=2', '?page=3&page_size=50', '?page=999&page_size=100', '?page_size=25&page=40']) totals.add(totalOn(await page(s.url + q)));
    assert.equal(totals.size, 1, `${s.url}: the total is the same on every page and page size (${[...totals].join(', ')})`);
    assert.ok([...totals][0] > 50, `${s.url}: the dataset is larger than a page (${[...totals][0]})`);
    s.total = [...totals][0];
  }
  assert.ok(screens[1].total >= 5200, 'the audit screen counts every row, not one page');
  console.log(`PASS (totals) the reported total is identical at every page and page size: members ${screens[0].total}, audit ${screens[1].total}, claims ${screens[2].total}`);

  // ---- exports hold every row -----------------------------------------------------------------------------------------------------------------
  const memberTotal = db.prepare('SELECT COUNT(*) n FROM members').get().n;
  // the Members list defaults to the church's current people; "all statuses" is asked for explicitly by listing them
  const everyStatus = await csv('/members/export.csv?' + ['active', 'inactive', 'pending', 'archived', 'temporarily_away', 'returned_home', 'migrated', 'transferred', 'other', 'attendee', 'bonafide'].map((s) => `status=${s}`).join('&'));
  assert.equal(everyStatus.length - 1, memberTotal, `the members export holds all ${memberTotal} members (beyond the old 5,000 cap), not one page (${everyStatus.length - 1})`);
  assert.ok(memberTotal > 5000);
  const paged = await csv('/members/export.csv?page=2&page_size=25&' + ['active', 'inactive', 'pending', 'archived', 'temporarily_away', 'returned_home', 'migrated', 'transferred', 'other', 'attendee', 'bonafide'].map((s) => `status=${s}`).join('&'));
  assert.equal(paged.length, everyStatus.length, 'the page and page size on screen do not change the export');
  const inactive = await csv('/members/export.csv?status=inactive');
  assert.equal(inactive.length - 1, db.prepare("SELECT COUNT(*) n FROM members WHERE status = 'inactive'").get().n, 'a status filter narrows the export exactly');
  const statusColumn = everyStatus[0].indexOf('Status');
  assert.ok(inactive.slice(1).every((r) => r[statusColumn] === 'Inactive'), 'and only that status');
  const lastNameColumn = everyStatus[0].indexOf('Last name');
  const formula = everyStatus.slice(1).filter((r) => r[lastNameColumn].includes('cmd|calc'));
  assert.ok(formula.length >= 100 && formula.every((r) => r[lastNameColumn].startsWith("'=")), 'formula-looking text is neutralised with a leading apostrophe');
  console.log(`PASS (members export) all ${memberTotal} members exported regardless of page or page size; a status filter narrows it exactly; formula characters neutralised`);

  const auditTotal = db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n;
  const auditCsv = await csv('/admin/audit.csv');
  assert.equal(auditCsv.length - 1, auditTotal, `the audit export holds all ${auditTotal} rows (beyond the old 5,000 cap), found ${auditCsv.length - 1}`);
  const bulkOnly = await csv('/admin/audit.csv?action=bulk.test');
  assert.equal(bulkOnly.length - 1, 5200, 'and an action filter narrows it exactly');
  const wildcard = await csv('/admin/audit.csv?action=' + encodeURIComponent('bulk_test'));
  assert.equal(wildcard.length - 1, 0, 'an underscore in the filter is a character, not a wildcard');
  console.log(`PASS (audit export) all ${auditTotal} audit rows exported; the action filter is exact`);

  const claimsInDb = db.prepare('SELECT COUNT(*) n FROM ecaq_giving_board_claims WHERE campaign_id = ?').get(ids.board).n;
  const claimsCsv = await csv(`/admin/ecaq/claims.csv?campaign=${ids.board}&page=2&page_size=25`);
  assert.equal(claimsCsv.length - 1, claimsInDb, 'the claims export holds every claim whatever page is on screen');
  const paymentsInDb = db.prepare('SELECT COUNT(*) n FROM ecaq_payments p JOIN ecaq_giving_board_claims k ON k.id = p.claim_id WHERE k.campaign_id = ?').get(ids.board).n;
  const paymentsCsv = await csv(`/admin/ecaq/payments.csv?campaign=${ids.board}&psize=25&ppage=2`);
  assert.equal(paymentsCsv.length - 1, paymentsInDb, 'the payments export holds every payment');
  const paidColumn = claimsCsv[0].findIndex((h) => /collected|paid/i.test(h));
  if (paidColumn >= 0) {
    const sumExport = claimsCsv.slice(1).reduce((t, r) => t + (Number(r[paidColumn]) || 0), 0);
    const sumDb = db.prepare('SELECT COALESCE(SUM(amount_collected), 0) s FROM ecaq_giving_board_claims WHERE campaign_id = ?').get(ids.board).s;
    assert.ok(Math.abs(sumExport - sumDb) < 0.005, `the money column of the export adds up to the database (${sumExport} vs ${sumDb})`);
  }
  console.log(`PASS (giving exports) ${claimsInDb} claims and ${paymentsInDb} payments exported in full; the collected column adds up`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
