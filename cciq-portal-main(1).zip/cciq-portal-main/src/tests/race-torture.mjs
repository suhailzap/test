import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Race torture. Several PROCESSES (not just several calls) hit the same throwaway database at the same instant with every combination of
 * First Timer operations that could interfere, and the result must be one of the legal outcomes with every invariant intact:
 * no duplicate member, visitor or open review, no half-closed review, no double notification, no broken "joined iff linked", and no
 * unhandled SQLITE_BUSY. The portal is a single instance (that assumption is unchanged); this proves that when a second process does
 * touch the database - a maintenance script, a second window of a tool - the architecture fails safely rather than corrupting anything.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
createIsolatedTestEnv('cciq-race-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitorsService = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
await import('../services/membership-review.js');
const { checkInvariants } = await import('../lib/db-invariants.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

await createUser({ username: 'race_admin', email: 'race.admin@fixture.invalid', password: 'Race-Fixture-Passw0rd!x', displayName: 'Race Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'race_admin'").get().id;

const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -500);
const atNoon = (d) => `${d}T09:00:00.000Z`;
const sessionIds = {};

function oldMember(first) {
  const m = createMember({ first_name: first, last_name: 'Race' }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', atNoon(OLD));
  return m.id;
}

let round = 0;
/** A fresh world: six finalized Fridays plus the current open one. `eligible` First Timers have 3 visits in the window but NO review yet. */
function freshWorld({ eligible = 0, withReviews = 0 } = {}) {
  round += 1;
  db.pragma('foreign_keys = OFF');
  db.exec('DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM notifications; DELETE FROM reminders; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors; DELETE FROM audit_logs;');
  db.pragma('foreign_keys = ON');
  setSetting('attendance.tracking_start_date', W(-6));
  for (let n = -6; n <= 0; n += 1) {
    db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
    sessionIds[n] = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)).id;
  }
  const make = (name) => visitorsService.createVisitor({ first_name: `${name}${round}`, last_name: 'Racer', first_visit_date: OLD, phone: `+974 5570 ${String(round).padStart(4, '0')}` }, { userId: null }).id;
  const people = { eligible: [], reviewed: [] };
  for (let i = 0; i < eligible + withReviews; i += 1) {
    const id = make(i < withReviews ? 'Rev' : 'Elig');
    (i < withReviews ? people.reviewed : people.eligible).push(id);
    for (const n of [-4, -3, -2]) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(id, W(n), sessionIds[n], 'x');
  }
  for (let n = -6; n <= -1; n += 1) {
    const result = lifecycle.finalizeAttendance(sessionIds[n], { userId: adminId, confirmNoAttendance: true });
    assert.equal(result.ok, true, `finalize W(${n})`);
  }
  // finalization opened reviews for everyone eligible; keep them only for the `reviewed` group
  const keep = people.reviewed.length ? `(${people.reviewed.join(',')})` : '(0)';
  db.exec(`DELETE FROM visitor_membership_reviews WHERE visitor_id NOT IN ${keep}; DELETE FROM notifications; DELETE FROM audit_logs;`);
  people.make = make;
  return people;
}

/** Runs every job in its own process, released at the same instant; returns each outcome. */
async function race(jobs) {
  const barrier = path.join(os.tmpdir(), `cciq-race-barrier-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const ready = [];
  const children = jobs.map((job) => new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(here, 'lib', 'race-worker.mjs'), barrier, JSON.stringify({ userId: adminId, ...job })], { env: process.env });
    let out = ''; let err = '';
    ready.push(new Promise((ok) => { child.stdout.on('data', (d) => { out += d; if (out.includes('READY')) ok(); }); child.on('exit', ok); }));
    child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (code) => resolve({ code, out: out.replace('READY', '').trim().split('\n').pop(), err: err.trim() }));
  }));
  await Promise.all(ready); // every worker has loaded and is spinning at the barrier (no timed sleep)
  fs.writeFileSync(barrier, 'go');
  const raw = await Promise.all(children);
  fs.rmSync(barrier, { force: true });
  return raw.map((r, index) => {
    assert.equal(r.code, 0, `a worker must not crash: ${r.err.slice(0, 300) || r.out}`);
    const parsed = JSON.parse(r.out);
    if (parsed.error) assert.ok(!/^SQLITE_BUSY/.test(String(parsed.error.code)), `no unhandled SQLITE_BUSY: ${jobs[index].op} -> ${parsed.error.message}`);
    return parsed;
  });
}

const count = (sql, ...params) => db.prepare(sql).get(...params).n;
const noBrokenInvariant = (label) => {
  const bad = checkInvariants(db).findings.filter((f) => f.severity === 'error' && /^(visitor|review|member)\./.test(f.code));
  assert.deepEqual(bad, [], `${label}: no First Timer, review or member invariant is broken`);
  assert.equal(count("SELECT COUNT(*) n FROM (SELECT visitor_id FROM visitor_membership_reviews WHERE status = 'open' GROUP BY visitor_id HAVING COUNT(*) > 1)"), 0, `${label}: never two open reviews for one First Timer`);
  assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE (state = 'joined') <> (member_id IS NOT NULL)"), 0, `${label}: joined iff linked`);
  assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status != 'open' AND closed_at IS NULL"), 0, `${label}: no half-closed review`);
  assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews r JOIN visitors v ON v.id = r.visitor_id WHERE r.status = 'open' AND v.member_id IS NOT NULL"), 0, `${label}: no open review for a linked First Timer`);
  assert.deepEqual(db.pragma('foreign_key_check'), [], `${label}: no foreign key violation`);
};
const REPEAT = 3;
const results = [];
const done = (name) => results.push(name);

// ---- 1. evaluator x evaluator x evaluator ---------------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 10 });
  const out = await race([{ op: 'evaluate' }, { op: 'evaluate' }, { op: 'scheduled' }]);
  assert.equal(out.reduce((s, o) => s + o.result.opened, 0), 10, 'between them exactly ten reviews opened');
  assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'"), 10);
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.membership_review_opened'"), 10, 'one audit row each');
  assert.equal(count("SELECT COUNT(*) n FROM notifications WHERE category = 'membership_review'"), out.filter((o) => o.result.opened > 0).length, 'one courtesy notification per process that opened anything: never a second for the same review');
  assert.ok(count("SELECT COUNT(*) n FROM notifications WHERE category = 'membership_review'") <= 3);
  noBrokenInvariant('evaluator x3'); void w;
}
done('evaluator x evaluator x scheduled');

// ---- 2. evaluator x Continue --------------------------------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 4, withReviews: 3 });
  const reviewId = db.prepare('SELECT id FROM visitor_membership_reviews WHERE visitor_id = ?').get(w.reviewed[0]).id;
  const out = await race([{ op: 'evaluate' }, { op: 'continue', reviewId }, { op: 'evaluate' }]);
  assert.equal(db.prepare('SELECT status FROM visitor_membership_reviews WHERE id = ?').get(reviewId).status, 'continued', 'the review was continued exactly once');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.membership_review_continued'"), 1);
  assert.equal(count('SELECT COUNT(*) n FROM visitor_membership_reviews WHERE visitor_id = ?', w.reviewed[0]), 1, 'continuing then evaluating does not reopen it (suppression)');
  for (const id of w.eligible) assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE visitor_id = ? AND status = 'open'", id), 1);
  noBrokenInvariant('evaluator x continue'); void out;
}
done('evaluator x Continue');

// ---- 3. Continue x Continue (the same review) -------------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ withReviews: 1 });
  const reviewId = db.prepare('SELECT id FROM visitor_membership_reviews WHERE visitor_id = ?').get(w.reviewed[0]).id;
  const out = await race([{ op: 'continue', reviewId }, { op: 'continue', reviewId }, { op: 'continue', reviewId }]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'exactly one Continue wins');
  assert.equal(out.filter((o) => !o.result.ok && o.result.reason === 'not_open').length, 2, 'the others are told it is no longer open');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.membership_review_continued'"), 1, 'audited once');
  noBrokenInvariant('continue x3');
}
done('Continue x Continue');

// ---- 4. evaluator x Convert / evaluator x Link ---------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 2 });
  const [a, b] = w.eligible; const memberId = oldMember(`Target${round}`);
  const membersBefore = count('SELECT COUNT(*) n FROM members');
  const out = await race([{ op: 'evaluate' }, { op: 'convert', visitorId: a }, { op: 'link', visitorId: b, memberId }, { op: 'evaluate' }]);
  assert.equal(count('SELECT COUNT(*) n FROM members'), membersBefore + 1, 'one member created (the conversion), none by the evaluator or the link');
  for (const id of [a, b]) {
    const v = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(id);
    assert.equal(v.state, 'joined'); assert.ok(v.member_id);
    const reviews = db.prepare('SELECT status FROM visitor_membership_reviews WHERE visitor_id = ?').all(id).map((r) => r.status);
    assert.ok(reviews.length === 0 || (reviews.length === 1 && ['converted', 'linked'].includes(reviews[0])), `a joined First Timer has no review or one closed by the action (${reviews})`);
  }
  assert.equal(out[1].result.ok, true); assert.equal(out[2].result.ok, true);
  noBrokenInvariant('evaluator x convert x link');
}
done('evaluator x Convert x Link');

// ---- 5. Convert x Convert, Convert x Link, Link x Link -----------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 1, withReviews: 1 });
  const v = w.reviewed[0]; const membersBefore = count('SELECT COUNT(*) n FROM members');
  const out = await race([{ op: 'convert', visitorId: v }, { op: 'convert', visitorId: v }, { op: 'convert', visitorId: v }]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'one conversion wins');
  assert.equal(count('SELECT COUNT(*) n FROM members'), membersBefore + 1, 'no duplicate member');
  assert.equal(out.filter((o) => !o.result.ok && o.result.reason === 'already_a_member').length, 2);
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.became_member'"), 1);
  assert.equal(db.prepare('SELECT status FROM visitor_membership_reviews WHERE visitor_id = ?').get(v).status, 'converted');
  noBrokenInvariant('convert x3');
}
done('Convert x Convert x Convert');

for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ withReviews: 1 });
  const v = w.reviewed[0]; const target = oldMember(`CL${round}`); const membersBefore = count('SELECT COUNT(*) n FROM members');
  const out = await race([{ op: 'convert', visitorId: v }, { op: 'link', visitorId: v, memberId: target }]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'exactly one of Convert and Link wins');
  const created = count('SELECT COUNT(*) n FROM members') - membersBefore;
  assert.equal(created, out[0].result.ok ? 1 : 0, 'a member exists only if the conversion won (the loser leaves nothing behind)');
  const row = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(v);
  assert.equal(row.state, 'joined'); assert.ok(out[0].result.ok ? row.member_id === out[0].result.memberId : row.member_id === target);
  assert.equal(db.prepare('SELECT status FROM visitor_membership_reviews WHERE visitor_id = ?').get(v).status, out[0].result.ok ? 'converted' : 'linked');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action IN ('visitor.became_member', 'visitor.linked_to_member')"), 1, 'one audit row for the one action that happened');
  noBrokenInvariant('convert x link');
}
done('Convert x Link');

for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ withReviews: 1 });
  const v = w.reviewed[0]; const m1 = oldMember(`LL1${round}`); const m2 = oldMember(`LL2${round}`);
  const out = await race([{ op: 'link', visitorId: v, memberId: m1 }, { op: 'link', visitorId: v, memberId: m2 }]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'the same First Timer is linked once');
  assert.equal(count('SELECT COUNT(*) n FROM visitors WHERE member_id IS NOT NULL'), 1);
  noBrokenInvariant('link x link (one visitor)');
}
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 2 });
  const [a, b] = w.eligible; const m = oldMember(`LS${round}`);
  const out = await race([{ op: 'link', visitorId: a, memberId: m }, { op: 'link', visitorId: b, memberId: m }]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'one member is linked to only one First Timer');
  assert.equal(out.filter((o) => !o.result.ok && o.result.reason === 'member_already_linked').length, 1);
  assert.equal(count('SELECT COUNT(*) n FROM visitors WHERE member_id = ?', m), 1);
  noBrokenInvariant('link x link (one member)');
}
done('Link x Link (same visitor; same member)');

// ---- 6. Express Registration -------------------------------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  freshWorld();
  const sameName = { op: 'express', first_name: `Twin${round}`, last_name: 'Racer', phone: `+974 5580 ${String(round).padStart(4, '0')}` };
  const before = count('SELECT COUNT(*) n FROM visitors');
  const out = await race([sameName, sameName, sameName]);
  assert.equal(out.filter((o) => o.result.ok).length, 1, 'exactly one registration wins');
  assert.equal(out.filter((o) => !o.result.ok && o.result.reason === 'possible_duplicate').length, 2, 'the others see the duplicate');
  assert.equal(count('SELECT COUNT(*) n FROM visitors'), before + 1, 'no duplicate First Timer');
  const winner = out.find((o) => o.result.ok).result.visitorId;
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', winner), 1, 'with exactly one visit, tied to the current service');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.express_registered'"), 1);
  noBrokenInvariant('express x3');
}
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 1 });
  const before = count('SELECT COUNT(*) n FROM visitors');
  const out = await race([{ op: 'express', first_name: `Solo${round}`, last_name: 'Racer' }, { op: 'express', first_name: `Other${round}`, last_name: 'Racer' }, { op: 'express', first_name: `Third${round}`, last_name: 'Racer' }]);
  assert.equal(out.filter((o) => o.result.ok).length, 3, 'three different people are all registered');
  assert.equal(count('SELECT COUNT(*) n FROM visitors'), before + 3);
  noBrokenInvariant('express (different people)'); void w;
}
done('Express x Express (same person; different people)');

// ---- 7. visits and finalization against the evaluator ---------------------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 3 });
  const extra = w.make('Visit');
  const out = await race([
    { op: 'visit', visitorId: extra, date: W(-1), sessionId: sessionIds[-1] },
    { op: 'visit', visitorId: extra, date: W(-2), sessionId: sessionIds[-2] },
    { op: 'visit', visitorId: extra, date: W(-3), sessionId: sessionIds[-3] },
    { op: 'evaluate' }, { op: 'evaluate' }
  ]);
  void out;
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', extra), 4, 'the first visit plus three more, each recorded once');
  const after = await race([{ op: 'evaluate' }]); void after;
  assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE visitor_id = ? AND status = 'open'", extra), 1, 'a later evaluation (the scheduled safety net) catches whatever the race missed');
  noBrokenInvariant('visit x evaluator');
}
done('attendance visit x evaluator');

for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 3 });
  // W(0) is still open: three First Timers visit it, then it is finalized while evaluators run
  for (const id of w.eligible) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(id, W(0), sessionIds[0], 'x');
  const out = await race([{ op: 'finalize', sessionId: sessionIds[0] }, { op: 'evaluate' }, { op: 'finalize', sessionId: sessionIds[0] }, { op: 'scheduled' }]);
  assert.equal(out.filter((o) => o.result.ok === true && o.result.reason === undefined && o.result).length >= 1, true);
  assert.equal(count("SELECT COUNT(*) n FROM attendance_sessions WHERE id = ? AND finalization_state = 'finalized'", sessionIds[0]), 1, 'finalized once');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.finalized' AND entity_id = ?", String(sessionIds[0])), 1, 'one finalization audit row: the second finalize was refused');
  await race([{ op: 'evaluate' }]);
  for (const id of w.eligible) assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE visitor_id = ? AND status = 'open'", id), 1, 'each eligible First Timer ends with exactly one open review');
  noBrokenInvariant('finalize x evaluator');
}
done('finalization x evaluator');

// ---- 8. a Kiosk check-in of a returning First Timer against Convert --------------------------------------------------------------------------------
for (let i = 0; i < REPEAT; i += 1) {
  const w = freshWorld({ eligible: 1 });
  const v = w.eligible[0];
  const out = await race([{ op: 'kioskVisit', sessionId: sessionIds[0], visitorId: v }, { op: 'convert', visitorId: v }]);
  const row = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(v);
  assert.equal(row.state, 'joined');
  assert.ok(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ? AND session_id = ?', v, sessionIds[0]) <= 1, 'at most one visit for the Friday');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?', sessionIds[0]), 0, 'a First Timer check-in never becomes an attendance record');
  noBrokenInvariant('kiosk visit x convert'); void out;
}
done('Kiosk check-in x Convert');

console.log(`PASS (races) ${results.length} combinations x ${REPEAT} rounds, each with 2-5 processes released at the same instant: ${results.join('; ')}`);
console.log('ALL PASS');
