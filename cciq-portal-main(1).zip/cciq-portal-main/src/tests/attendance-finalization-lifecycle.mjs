import assert from 'node:assert/strict';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Attendance Go-Live & Finalization, Phase 2B: the finalization lifecycle and
 * the admin actions around it - preview, finalize, "attendance not taken",
 * reopen, corrections, the central mutability gate on every write path,
 * cancellation, the Go-Live date lock, and authorization.
 *
 * Every database is a disposable fixture (createIsolatedTestEnv). No real
 * Go-Live date is ever set; the dates below exist only in the fixture.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-attendance-lifecycle-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting, getSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember, changeStatus } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createVisitor } = await import('../services/visitors.js');
const tracking = await import('../services/attendance-tracking.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const { confirmCheckin } = await import('../services/qr-checkin.js');
const { commitAttendance, AttendanceImportRefusedError } = await import('../services/imports.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

// ---------------------------------------------------------------------------
// Fixture: nine tracked Fridays, one before Go-Live, and a member population
// whose status history is unambiguous as of every one of them.
// ---------------------------------------------------------------------------

const SERVICE = lastFridayOnOrBefore(today()); // the current operational Friday
const GO_LIVE = addDays(SERVICE, -56);
const atNoon = (date, hourUtc = 9) => `${date}T${String(hourUtc).padStart(2, '0')}:00:00.000Z`;
const oldDate = addDays(SERVICE, -300);

function plant(member, { created, changes = [] }) {
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(member.id);
  db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(created.at, member.id);
  const insert = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
  insert.run(member.id, null, created.status, 'planted', created.at);
  let current = created.status;
  for (const change of changes) {
    insert.run(member.id, current, change.status, 'planted', change.at);
    current = change.status;
  }
  db.prepare('UPDATE members SET status = ? WHERE id = ?').run(current, member.id);
}
const mk = (name, status = 'active') => {
  const m = createMember({ first_name: name, last_name: 'Life' }, { status });
  if (status === 'temporarily_away') {
    plant(m, { created: { at: atNoon(oldDate), status: 'active' }, changes: [{ at: atNoon(addDays(SERVICE, -60)), status: 'temporarily_away' }] });
  } else {
    plant(m, { created: { at: atNoon(oldDate), status } });
  }
  return m;
};

const M1 = mk('Alpha'); const M2 = mk('Bravo'); const M3 = mk('Charlie'); const M4 = mk('Delta');
const M5 = mk('Echo'); const M6 = mk('Foxtrot'); const MV = mk('Victor');
const MX = mk('Xray', 'inactive'); // not expected on any Friday
const MAway = mk('Away', 'temporarily_away'); // not expected; comes back when present on an open Friday
const MAway2 = mk('AwayTwo', 'temporarily_away');
const EXPECTED_IDS = [M1, M2, M3, M4, M5, M6, MV].map((m) => m.id).sort((a, b) => a - b);

const insertSession = db.prepare(
  `INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at)
   VALUES (@date, @type, @title, @status, 1, 0, @at)`
);
function sessionOn(date, { type = 'friday_service', status = 'held' } = {}) {
  insertSession.run({ date, type, title: `${type} ${date}`, status, at: atNoon(date) });
  return db.prepare('SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = ? AND cell_group_id = 0').get(date, type);
}
const fresh = (id) => db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(id);

const TA = sessionOn(addDays(SERVICE, -49)); // finalize vs not-taken race
const TB = sessionOn(addDays(SERVICE, -42)); // ambiguity
const TC = sessionOn(addDays(SERVICE, -35)); // atomicity
const TD = sessionOn(addDays(SERVICE, -28)); // not taken, with existing rows
const TE = sessionOn(addDays(SERVICE, -21)); // not taken, no rows
const TF = sessionOn(addDays(SERVICE, -14)); // the main finalize / correct / reopen scenario
const TG = sessionOn(addDays(SERVICE, -7)); // concurrent finalize, then cancellation
const TH = sessionOn(addDays(SERVICE, -63)); // finalized over HTTP (GO_LIVE - 7 => tracked once GO_LIVE is moved; see below)
const TI = sessionOn(SERVICE, { status: 'scheduled' }); // the current, open Friday
const PRE = sessionOn(addDays(GO_LIVE, -14)); // before Go-Live
const CANCELLED = sessionOn(GO_LIVE, { status: 'cancelled' }); // tracked (the Go-Live Friday itself), but cancelled
const FUTURE = sessionOn(addDays(SERVICE, 7), { status: 'scheduled' });
const SPECIAL = sessionOn(addDays(SERVICE, -2), { type: 'special_service' });
db.prepare("UPDATE attendance_sessions SET status = 'held' WHERE id = ?").run(TI.id);

// TH must be untouched by the tracking start: it is before GO_LIVE, so it is
// "pre-go-live" until an override moves GO_LIVE back over it. It is used only
// for the HTTP finalize test after that override.
const insertRecord = db.prepare(
  "INSERT INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, ?, ?, 'manual')"
);
const put = (session, member, status) => insertRecord.run(session.id, member.id, status, atNoon(session.service_date, 11));

const auditRows = (action, entityId = null) => db.prepare(
  `SELECT * FROM audit_logs WHERE action = ? ${entityId === null ? '' : 'AND entity_id = ?'} ORDER BY id`
).all(...(entityId === null ? [action] : [action, String(entityId)]));
const detailOf = (row) => JSON.parse(row.detail);
const expectedRows = (session) => db.prepare('SELECT member_id, status_at_service FROM attendance_expected WHERE session_id = ? ORDER BY member_id').all(session.id);
const recordRows = (session) => db.prepare('SELECT member_id, status, source FROM attendance_records WHERE session_id = ? ORDER BY member_id').all(session.id);
const stateOf = (session) => fresh(session.id).finalization_state;
const eventLog = [];
lifecycle.onAttendanceLifecycleChange((event) => eventLog.push(event));

// Legacy behaviour first: with tracking not started, nothing is tracked or gated.
{
  assert.equal(tracking.isTrackingConfigured(), false);
  const before = fresh(TF.id);
  assert.equal(tracking.classifySession(before).phase, 'not_started');
  assert.equal(attendance.recordAttendance(TF.id, [{ memberId: M1.id, status: 'present' }], { userId: null }).ok, true,
    'ITEM 12/legacy: with tracking not started, ordinary attendance entry works exactly as before');
  assert.equal(lifecycle.finalizeAttendance(TF.id).reason, 'tracking_not_started', 'ITEM 12: finalizing needs a configured Go-Live date');
  assert.equal(lifecycle.markAttendanceNotTaken(TF.id, { note: 'x' }).reason, 'tracking_not_started');
  db.prepare('DELETE FROM attendance_records WHERE session_id = ?').run(TF.id);
  assert.equal(stateOf(TF), null);
  console.log('PASS (tracking not started): the register behaves as it always did, and finalize / not-taken refuse with "tracking has not started"');
}

setSetting('attendance.tracking_start_date', GO_LIVE);
assert.equal(tracking.trackingStartDate(), GO_LIVE);

// Pre-go-live Friday keeps legacy behaviour.
{
  assert.equal(tracking.classifySession(fresh(PRE.id)).phase, 'pre_go_live');
  assert.equal(attendance.recordAttendance(PRE.id, [{ memberId: M1.id, status: 'present' }], { userId: null }).ok, true,
    'ITEM 52: a pre-go-live Friday can still be edited by the ordinary register');
  assert.equal(lifecycle.finalizeAttendance(PRE.id).reason, 'not_tracked', 'ITEM 11: a pre-go-live Friday cannot be finalized');
  assert.equal(lifecycle.markAttendanceNotTaken(PRE.id, { note: 'x' }).reason, 'not_tracked');
  assert.equal(tracking.hasExpectedSnapshot(PRE.id), false);
  assert.equal(stateOf(PRE), null);
  console.log('PASS (pre-go-live): a Friday before the tracking start date is "not tracked": editable as before, never finalizable, never snapshotted');
}

// Refusals that write nothing: future, cancelled, non-Friday.
{
  const auditBefore = db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n;
  assert.equal(lifecycle.finalizeAttendance(FUTURE.id).reason, 'session_in_future', 'ITEM 9');
  assert.equal(lifecycle.finalizeAttendance(CANCELLED.id).reason, 'session_cancelled', 'ITEM 10');
  assert.equal(lifecycle.finalizeAttendance(SPECIAL.id).reason, 'not_friday_service');
  assert.equal(lifecycle.finalizeAttendance(999999).reason, 'session_not_found');
  assert.equal(lifecycle.markAttendanceNotTaken(FUTURE.id, { note: 'x' }).reason, 'session_in_future');
  assert.equal(lifecycle.markAttendanceNotTaken(CANCELLED.id, { note: 'x' }).reason, 'session_cancelled');
  assert.equal(lifecycle.reopenAttendance(TI.id, { reason: 'x' }).reason, 'not_finalized');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n, auditBefore, 'every refusal wrote no audit row');
  for (const s of [FUTURE, CANCELLED, SPECIAL]) assert.equal(stateOf(s), null);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_expected').get().n, 0, 'and created no snapshot');
  console.log('PASS (refusals): future, cancelled, non-Friday and missing services cannot be finalized or marked not taken, and nothing is written');
}

// ---------------------------------------------------------------------------
// The main scenario on TF: preview, ambiguity, atomicity, finalize.
// ---------------------------------------------------------------------------

put(TF, M1, 'present'); put(TF, M2, 'present'); put(TF, M3, 'excused'); put(TF, M4, 'absent');
put(TF, MV, 'visitor'); // a member-linked visitor row: positive attendance
put(TF, MX, 'present'); // not expected: headcount only
// M5 and M6 have no row at all.
const firstTimer = createVisitor({ first_name: 'Walk', last_name: 'In' }, { userId: null });
db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(firstTimer.id, TF.service_date, TF.id, atNoon(TF.service_date));

const dump = () => JSON.stringify({
  sessions: db.prepare('SELECT * FROM attendance_sessions ORDER BY id').all(),
  records: db.prepare('SELECT * FROM attendance_records ORDER BY id').all(),
  expected: db.prepare('SELECT * FROM attendance_expected ORDER BY session_id, member_id').all(),
  audit: db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n,
  members: db.prepare('SELECT id, status FROM members ORDER BY id').all(),
  visits: db.prepare('SELECT COUNT(*) n FROM visitor_visits').get().n
});

{
  const before = dump();
  const preview = lifecycle.previewFinalization(TF.id);
  assert.equal(dump(), before, 'ITEM 1: the preview changed nothing at all');
  assert.equal(preview.ok, true);
  assert.equal(preview.canFinalize, true);
  assert.equal(preview.phase, 'awaiting_finalization');
  assert.equal(preview.rosterSource, 'live');
  assert.equal(preview.usingPreservedSnapshot, false);
  const s = preview.summary;
  assert.equal(s.expected, 7, 'ITEM 2: expected members');
  assert.equal(s.presentExpected, 3, 'M1, M2 and the member-linked visitor row count as present');
  assert.equal(s.vacation, 1);
  assert.equal(s.absentRecorded, 1);
  assert.equal(s.willBecomeAbsent, 2, 'two expected members have no row and would become derived-absent');
  assert.equal(s.unexpectedAttendees, 1, 'MX attended without being expected');
  assert.equal(s.firstTimeVisitors, 1);
  assert.equal(s.actualHeadcount, 5, 'headcount = 3 expected + 1 unexpected + 1 first-time visitor');
  assert.equal(s.rate, 50, 'rate = 3 / (7 - 1 vacation): unexpected attendees and visitors never enter it');
  assert.deepEqual(preview.ambiguous, []);
  assert.deepEqual(preview.blockers, []);
  console.log('PASS (preview): read-only; reports expected, present, vacation, recorded absent, will-become-absent, unexpected attendees, headcount and rate; member-linked visitor = present');
}

// Ambiguity blocks, fail closed, with no acknowledge/force path.
{
  const amb = mk('Ambiguous');
  db.prepare("UPDATE members SET status = 'inactive' WHERE id = ?").run(amb.id); // changed with no history entry
  const before = dump();
  const preview = lifecycle.previewFinalization(TB.id);
  assert.equal(preview.canFinalize, false);
  assert.ok(preview.blockers.includes('ambiguous_history'));
  assert.ok(preview.ambiguous.some((a) => a.memberId === amb.id && a.name.includes('Ambiguous')), 'the ambiguous member is listed by name');
  const refused = lifecycle.finalizeAttendance(TB.id, { userId: null });
  assert.equal(refused.ok, false);
  assert.equal(refused.reason, 'ambiguous_history');
  const forced = lifecycle.finalizeAttendance(TB.id, { userId: null, acknowledgeAmbiguous: true, force: true, confirmNoAttendance: true });
  assert.equal(forced.reason, 'ambiguous_history', 'ITEM 3: no acknowledge, force or confirmation option bypasses ambiguity');
  assert.equal(dump(), before, 'ITEM 3: a refused finalization leaves no snapshot, no state change and no audit row');
  assert.equal(lifecycle.markAttendanceNotTaken(TB.id, { note: 'because' }).ok, true, 'a service with ambiguous history can still be marked not taken (it needs no roster)');
  assert.equal(lifecycle.reopenAttendance(TB.id, { reason: 'undo' }).ok, true);
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(amb.id);
  db.prepare('DELETE FROM members WHERE id = ?').run(amb.id);
  console.log('PASS (ambiguity): ambiguous status history blocks finalization with the members listed; nothing bypasses it and nothing is written');
}

// Atomicity: a failure part-way leaves nothing behind.
{
  put(TC, M1, 'present');
  db.exec("CREATE TRIGGER fail_snapshot BEFORE INSERT ON attendance_expected BEGIN SELECT RAISE(ABORT, 'simulated failure'); END;");
  const before = dump();
  assert.throws(() => lifecycle.finalizeAttendance(TC.id, { userId: null }), /simulated failure/);
  db.exec('DROP TRIGGER fail_snapshot');
  assert.equal(dump(), before, 'ITEM 4: no state change, no partial snapshot and no audit row after a failure');
  assert.equal(stateOf(TC), null);
  assert.equal(expectedRows(TC).length, 0);
  console.log('PASS (atomicity): a failure while writing the snapshot rolls the whole finalization back');
}

// Finalize TF.
let tfSnapshot;
{
  const recordsBefore = recordRows(TF);
  const events = eventLog.length;
  const admin = await createUser({ email: 'finalizer@fixture.invalid', password: 'FinalizerPassw0rd!2026', displayName: 'Finalizer', roleKeys: ['church_admin'], mustChangePassword: false });
  const result = lifecycle.finalizeAttendance(TF.id, { userId: admin });
  assert.equal(result.ok, true);
  assert.equal(result.snapshotCreated, true);
  const row = fresh(TF.id);
  assert.equal(row.finalization_state, 'finalized', 'ITEM 6');
  assert.equal(row.finalized_by, admin);
  assert.ok(row.finalized_at && Math.abs(Date.now() - Date.parse(row.finalized_at)) < 60000, 'finalized_at is stamped now');
  assert.equal(row.status, 'held', 'finalization does not change the service status');
  tfSnapshot = expectedRows(TF);
  assert.deepEqual(tfSnapshot.map((r) => r.member_id), EXPECTED_IDS, 'ITEM 4: the snapshot holds exactly the expected members');
  assert.deepEqual(recordRows(TF), recordsBefore, 'ITEM 5: no attendance row was inserted, changed or removed - no physical Absent rows');
  assert.equal(recordRows(TF).some((r) => r.member_id === M5.id || r.member_id === M6.id), false);
  assert.equal(lifecycle.outcomeOf({ phase: 'finalized', expected: true, rowStatus: null }), 'absent_derived');
  const audits = auditRows('attendance.finalized', TF.id);
  assert.equal(audits.length, 1, 'ITEM 6: exactly one audit row');
  assert.equal(audits[0].user_id, admin);
  const d = detailOf(audits[0]);
  assert.deepEqual([d.expected, d.present, d.vacation, d.recorded_absent, d.derived_absent, d.unexpected_attendees, d.first_time_visitors, d.snapshot],
    [7, 3, 1, 1, 2, 1, 1, 'created'], 'the audit summary carries the finalization counts');
  assert.equal(eventLog.length, events + 1);
  assert.deepEqual(eventLog.at(-1), { type: 'finalized', sessionId: TF.id, userId: admin }, 'the post-commit hook fires once');

  // ITEM 7: a second finalize is refused and adds nothing.
  const auditCount = db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n;
  const again = lifecycle.finalizeAttendance(TF.id, { userId: admin });
  assert.equal(again.ok, false);
  assert.equal(again.reason, 'already_finalized');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n, auditCount);
  assert.deepEqual(expectedRows(TF), tfSnapshot);
  assert.equal(fresh(TF.id).finalized_at, row.finalized_at, 'the original finalization time is untouched');
  assert.equal(lifecycle.markAttendanceNotTaken(TF.id, { note: 'x' }).reason, 'already_finalized');

  // The preview of a finalized Friday shows the STORED snapshot.
  const shown = lifecycle.previewFinalization(TF.id);
  assert.equal(shown.usingPreservedSnapshot, true);
  assert.equal(shown.canFinalize, false);
  assert.equal(shown.phase, 'finalized');
  assert.equal(shown.summary.expected, 7);
  console.log('PASS (finalize): one transaction creates the snapshot, stamps who/when, audits once and writes no Absent rows; a second attempt is refused with nothing added');
}

// Finalizing with nothing recorded needs an explicit confirmation.
{
  const empty = lifecycle.previewFinalization(TC.id);
  assert.equal(empty.summary.presentExpected, 1);
  db.prepare('DELETE FROM attendance_records WHERE session_id = ?').run(TC.id);
  const preview = lifecycle.previewFinalization(TC.id);
  assert.equal(preview.requiresEmptyConfirmation, true);
  assert.equal(lifecycle.finalizeAttendance(TC.id).reason, 'no_attendance_recorded');
  assert.equal(stateOf(TC), null);
  assert.equal(lifecycle.finalizeAttendance(TC.id, { confirmNoAttendance: true }).ok, true);
  assert.equal(detailOf(auditRows('attendance.finalized', TC.id)[0]).confirmed_no_attendance, true);
  console.log('PASS (empty register): finalizing with no attendance at all is refused unless explicitly confirmed - so an untaken register cannot silently mark everyone absent');
}

// ---------------------------------------------------------------------------
// Concurrency: two separate processes, one database file.
// ---------------------------------------------------------------------------

async function race(script, count = 2) {
  const startAt = Date.now() + 2500;
  const runners = Array.from({ length: count }, (_, i) => new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', script], {
      env: { ...process.env, RACE_START: String(startAt), RACE_INDEX: String(i) }
    });
    let out = ''; let err = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (code) => (code === 0 ? resolve(JSON.parse(out.trim().split('\n').at(-1))) : reject(new Error(`racer ${i} failed: ${err}`))));
  }));
  return Promise.all(runners);
}
const lifecycleUrl = pathToFileURL(path.join(root, 'src/services/attendance-lifecycle.js')).href;
const racerScript = (call) => `
  const lifecycle = await import(${JSON.stringify(lifecycleUrl)});
  while (Date.now() < Number(process.env.RACE_START)) { /* spin until the shared start time */ }
  const result = ${call};
  console.log(JSON.stringify({ ok: result.ok, reason: result.reason || null }));
`;

{
  put(TG, M1, 'present'); put(TG, M2, 'present'); put(TG, M4, 'absent');
  const results = await race(racerScript(`lifecycle.finalizeAttendance(${TG.id}, { userId: null })`), 2);
  const oks = results.filter((r) => r.ok).length;
  assert.equal(oks, 1, `ITEM 8: exactly one of two simultaneous finalizations wins (${JSON.stringify(results)})`);
  assert.deepEqual(results.filter((r) => !r.ok).map((r) => r.reason), ['already_finalized']);
  assert.equal(auditRows('attendance.finalized', TG.id).length, 1, 'ITEM 8: exactly one audit row');
  assert.deepEqual(expectedRows(TG).map((r) => r.member_id), EXPECTED_IDS, 'ITEM 8: one snapshot, no duplicates');
  assert.equal(stateOf(TG), 'finalized');

  put(TA, M1, 'present');
  const mixed = await race(
    `const lifecycle = await import(${JSON.stringify(lifecycleUrl)});
     while (Date.now() < Number(process.env.RACE_START)) {}
     const i = Number(process.env.RACE_INDEX);
     const result = i === 0 ? lifecycle.finalizeAttendance(${TA.id}, { userId: null })
                            : lifecycle.markAttendanceNotTaken(${TA.id}, { userId: null, note: 'race', confirmExistingAttendance: true });
     console.log(JSON.stringify({ ok: result.ok, reason: result.reason || null, i }));`, 2
  );
  assert.equal(mixed.filter((r) => r.ok).length, 1, `a finalize racing a not-taken: exactly one wins (${JSON.stringify(mixed)})`);
  const winner = mixed.find((r) => r.ok).i === 0 ? 'finalized' : 'not_taken';
  assert.equal(stateOf(TA), winner);
  assert.equal(auditRows('attendance.finalized', TA.id).length + auditRows('attendance.not_taken', TA.id).length, 1, 'and exactly one audit row between them');
  assert.equal(expectedRows(TA).length, winner === 'finalized' ? 7 : 0, 'a snapshot exists only if finalize won');
  console.log('PASS (concurrency): two processes racing on one Friday produce exactly one transition, one audit row and one snapshot');
}

// ---------------------------------------------------------------------------
// Attendance not taken.
// ---------------------------------------------------------------------------
{
  // TE: no rows.
  assert.equal(lifecycle.markAttendanceNotTaken(TE.id, { note: '  ' }).reason, 'note_required', 'ITEM 13: a reason is required');
  assert.equal(stateOf(TE), null);
  const ok = lifecycle.markAttendanceNotTaken(TE.id, { userId: null, note: 'Projector broke; the sheet was lost.' });
  assert.equal(ok.ok, true);
  const row = fresh(TE.id);
  assert.equal(row.finalization_state, 'not_taken');
  assert.equal(row.finalization_note, 'Projector broke; the sheet was lost.');
  assert.equal(expectedRows(TE).length, 0, 'ITEM 14: no snapshot for a not-taken Friday');
  assert.equal(auditRows('attendance.not_taken', TE.id).length, 1, 'ITEM 15');
  assert.equal(lifecycle.markAttendanceNotTaken(TE.id, { note: 'again' }).reason, 'already_not_taken', 'ITEM 16: a second attempt is refused');
  assert.equal(auditRows('attendance.not_taken', TE.id).length, 1);
  assert.equal(lifecycle.finalizeAttendance(TE.id).reason, 'already_not_taken');
  assert.equal(tracking.classifySession(row).phase, 'not_taken');
  assert.equal(lifecycle.outcomeOf({ phase: 'not_taken', expected: true, rowStatus: null }), null, 'no absence outcome on a not-taken Friday');

  // TD: rows exist -> a strong confirmation is required, rows are kept.
  put(TD, M1, 'present'); put(TD, M2, 'absent');
  const warn = lifecycle.previewFinalization(TD.id);
  assert.equal(warn.existingAttendanceRecords, 2);
  assert.equal(lifecycle.markAttendanceNotTaken(TD.id, { note: 'Not taken' }).reason, 'existing_attendance_needs_confirmation');
  assert.equal(stateOf(TD), null);
  const kept = lifecycle.markAttendanceNotTaken(TD.id, { userId: null, note: 'Not taken', confirmExistingAttendance: true });
  assert.equal(kept.ok, true);
  assert.equal(kept.existingRecordsKept, 2);
  assert.equal(recordRows(TD).length, 2, 'ITEM 14: existing rows are kept, untouched');
  assert.equal(expectedRows(TD).length, 0);
  assert.equal(detailOf(auditRows('attendance.not_taken', TD.id)[0]).existing_attendance_records_kept, 2);
  console.log('PASS (not taken): a reason is required; no snapshot; existing rows kept behind an explicit confirmation; audited; a second attempt is refused');
}

// ---------------------------------------------------------------------------
// The central mutability gate.
// ---------------------------------------------------------------------------
{
  const finalizedDump = () => JSON.stringify({ r: recordRows(TF), e: expectedRows(TF), s: fresh(TF.id) });
  const before = finalizedDump();

  // ITEM 22: ordinary admin write.
  const w = attendance.recordAttendance(TF.id, [{ memberId: M5.id, status: 'present' }], { userId: null });
  assert.deepEqual([w.ok, w.reason], [false, 'session_finalized'], 'ITEM 22: an ordinary write to a finalized Friday is refused');
  // Search/add, quick/family flow.
  const q = attendance.recordAttendanceForPeople(TF.id, [{ type: 'member', id: M5.id }], {});
  assert.deepEqual([q.ok, q.reason], [false, 'session_finalized'], 'ITEM 27: quick / search / family recording is refused');
  const v = attendance.recordAttendanceForPeople(TF.id, [{ type: 'visitor', id: firstTimer.id }], {});
  assert.deepEqual([v.ok, v.reason], [false, 'session_finalized']);
  // Clearing (Not recorded) is a write too.
  const c = attendance.recordAttendance(TF.id, [{ memberId: M1.id, status: null }], { userId: null });
  assert.equal(c.ok, false);
  assert.equal(finalizedDump(), before, 'and nothing changed');

  // Not taken.
  for (const fn of [
    () => attendance.recordAttendance(TE.id, [{ memberId: M1.id, status: 'present' }], {}),
    () => attendance.recordAttendanceForPeople(TE.id, [{ type: 'member', id: M1.id }], {}),
    () => attendance.recordAttendance(TD.id, [{ memberId: M3.id, status: 'present' }], {})
  ]) {
    const r = fn();
    assert.deepEqual([r.ok, r.reason], [false, 'session_not_taken']);
  }
  // Cancelled and future keep refusing.
  assert.equal(attendance.recordAttendance(CANCELLED.id, [{ memberId: M1.id, status: 'present' }], {}).reason, 'session_cancelled');
  assert.equal(attendance.recordAttendance(FUTURE.id, [{ memberId: M1.id, status: 'present' }], {}).reason, 'session_in_future');

  // The gate itself fails closed on a partial row.
  assert.throws(() => attendance.assertSessionMutable({ id: 1, service_type: 'friday_service', service_date: '2020-01-03', status: 'held' }), /finalization_state is missing/);
  assert.deepEqual(attendance.assertSessionMutable({ id: 1, service_type: 'special_service', service_date: '2020-01-03', status: 'held' }), { ok: true });

  // Import.
  const importPreview = {
    sessions: [{ date: TF.service_date, sessionId: TF.id }],
    people: [{ memberId: M5.id, entries: [{ date: TF.service_date, status: 'present' }] }]
  };
  assert.throws(() => commitAttendance(importPreview, { userId: null, filename: 'late.xlsx', createSessions: false }), AttendanceImportRefusedError);
  assert.equal(finalizedDump(), before, 'ITEM 28/I: an import cannot write into a finalized Friday, and is rolled back whole');
  const notTakenImport = { sessions: [{ date: TE.service_date, sessionId: TE.id }], people: [{ memberId: M1.id, entries: [{ date: TE.service_date, status: 'present' }] }] };
  assert.throws(() => commitAttendance(notTakenImport, { userId: null, filename: 'late.xlsx', createSessions: false }), AttendanceImportRefusedError);
  console.log('PASS (mutability gate): a finalized or not-taken Friday refuses ordinary, search, family, visitor, clearing and import writes - and the gate fails closed on a partial row');
}

// ---------------------------------------------------------------------------
// Corrections to finalized attendance (TF).
// ---------------------------------------------------------------------------
{
  const snapshotBefore = JSON.stringify(expectedRows(TF));
  const stateBefore = fresh(TF.id);
  const auditBefore = auditRows('attendance.corrected').length;
  const before = JSON.stringify(recordRows(TF));

  // Reason required; nothing changes without one.
  assert.equal(lifecycle.correctFinalizedAttendance(TF.id, [{ memberId: M5.id, to: 'present' }], { reason: ' ' }).reason, 'reason_required');
  assert.equal(JSON.stringify(recordRows(TF)), before);
  // Not correctable unless finalized.
  assert.equal(lifecycle.correctFinalizedAttendance(TI.id, [{ memberId: M5.id, to: 'present' }], { reason: 'r' }).reason, 'not_finalized');
  assert.equal(lifecycle.correctFinalizedAttendance(TE.id, [{ memberId: M5.id, to: 'present' }], { reason: 'r' }).reason, 'session_not_taken');
  // Invalid / duplicate / not-expected-to-vacation: all-or-nothing.
  for (const [changes, reason] of [
    [[{ memberId: M5.id, to: 'present' }, { memberId: M5.id, to: 'absent' }], 'duplicate_member'],
    [[{ memberId: M5.id, to: 'present' }, { memberId: MX.id, to: 'excused' }], 'invalid_change'],
    [[{ memberId: M5.id, to: 'visitor' }], 'invalid_change'],
    [[{ memberId: 987654, to: 'present' }], 'invalid_change'],
    [[], 'no_changes']
  ]) {
    assert.equal(lifecycle.correctFinalizedAttendance(TF.id, changes, { reason: 'r' }).reason, reason);
  }
  assert.equal(JSON.stringify(recordRows(TF)), before, 'a refused correction changes nothing (all or nothing)');

  const events = eventLog.length;
  const result = lifecycle.correctFinalizedAttendance(TF.id, [
    { memberId: M5.id, to: 'present' },   // ITEM 29 derived Absent -> Present
    { memberId: M6.id, to: 'excused' },   // ITEM 30 derived Absent -> Vacation
    { memberId: M4.id, to: 'present' },   // ITEM 31 recorded Absent -> Present
    { memberId: M1.id, to: 'excused' },   // ITEM 32 Present -> Vacation
    { memberId: M3.id, to: 'present' },   // ITEM 33 Vacation -> Present
    { memberId: M2.id, to: 'remove' }     // ITEM 34 mistaken Present -> derived Absent
  ], { userId: null, reason: 'Sheet re-checked against the sign-in book' });
  assert.equal(result.ok, true);
  assert.equal(result.changed, 6);
  const rows = new Map(recordRows(TF).map((r) => [r.member_id, r]));
  assert.equal(rows.get(M5.id).status, 'present');
  assert.equal(rows.get(M6.id).status, 'excused');
  assert.equal(rows.get(M4.id).status, 'present');
  assert.equal(rows.get(M1.id).status, 'excused');
  assert.equal(rows.get(M3.id).status, 'present');
  assert.equal(rows.has(M2.id), false, 'the mistaken Present row is removed: the member is derived Absent again');
  assert.equal(rows.get(M5.id).source, 'correction', 'corrections are marked as such on the record');
  assert.equal(JSON.stringify(expectedRows(TF)), snapshotBefore, 'ITEM 35: the expected snapshot never changes');
  const after = fresh(TF.id);
  assert.equal(after.finalization_state, 'finalized', 'no reopen was needed: still finalized');
  assert.equal(after.finalized_at, stateBefore.finalized_at);
  assert.equal(after.finalized_by, stateBefore.finalized_by);

  const audits = auditRows('attendance.corrected', TF.id);
  assert.equal(audits.length, 6, 'ITEM 36: one audit row per member changed');
  const byMember = new Map(audits.map((a) => [detailOf(a).member_id, detailOf(a)]));
  assert.deepEqual([byMember.get(M5.id).from, byMember.get(M5.id).to], ['absent_derived', 'present']);
  assert.deepEqual([byMember.get(M6.id).from, byMember.get(M6.id).to], ['absent_derived', 'vacation']);
  assert.deepEqual([byMember.get(M4.id).from, byMember.get(M4.id).to], ['absent_recorded', 'present']);
  assert.deepEqual([byMember.get(M1.id).from, byMember.get(M1.id).to], ['present', 'vacation']);
  assert.deepEqual([byMember.get(M3.id).from, byMember.get(M3.id).to], ['vacation', 'present']);
  assert.deepEqual([byMember.get(M2.id).from, byMember.get(M2.id).to], ['present', 'absent_derived']);
  assert.ok(audits.every((a) => detailOf(a).reason === 'Sheet re-checked against the sign-in book' && detailOf(a).batch));
  assert.ok(auditRows('attendance.corrected').length === auditBefore + 6);
  assert.deepEqual(eventLog.at(-1), { type: 'corrected', sessionId: TF.id, memberIds: result.memberIds, userId: null }, 'the post-correction hook fires once with the members');
  assert.equal(eventLog.length, events + 1);

  // An unexpected attendee can be removed; someone not expected can be added as Present.
  assert.equal(lifecycle.correctFinalizedAttendance(TF.id, [{ memberId: MX.id, to: 'remove' }, { memberId: MAway.id, to: 'present' }], { reason: 'r2' }).changed, 2);
  assert.equal(tracking.hasExpectedSnapshot(TF.id) && expectedRows(TF).length, 7, 'and still the snapshot is unchanged');
  // No-op corrections write nothing.
  const noop = lifecycle.correctFinalizedAttendance(TF.id, [{ memberId: M5.id, to: 'present' }], { reason: 'r3' });
  assert.equal(noop.changed, 0);
  assert.equal(auditRows('attendance.corrected', TF.id).length, 8);

  // The candidate list used by the UI.
  const list = lifecycle.correctionCandidates(TF.id);
  assert.ok(list.some((c) => c.id === M2.id && c.outcome === 'absent_derived'));
  assert.ok(list.every((c) => c.expected));
  assert.ok(lifecycle.correctionCandidates(TF.id, { q: 'Xray' }).some((c) => c.id === MX.id && c.expected === false));
  console.log('PASS (corrections): every permitted correction works on a finalized Friday without reopening it; reason required; all-or-nothing; per-member audit; snapshot and finalization untouched; hook fires');
}

// ---------------------------------------------------------------------------
// Reopen and re-finalize: the preserved snapshot is reused.
// ---------------------------------------------------------------------------
{
  assert.equal(lifecycle.reopenAttendance(TF.id, { reason: '' }).reason, 'reason_required', 'ITEM 17');
  assert.equal(stateOf(TF), 'finalized');
  const snapshot = JSON.stringify(expectedRows(TF));
  const records = JSON.stringify(recordRows(TF));
  const finalizedRow = fresh(TF.id);
  const events = eventLog.length;

  const reopened = lifecycle.reopenAttendance(TF.id, { userId: null, reason: 'Late sign-in book found' });
  assert.equal(reopened.ok, true);
  const row = fresh(TF.id);
  assert.equal(row.finalization_state, null, 'ITEM 18: back to open');
  assert.equal(row.finalized_at, null, 'ITEM 21: finalized_at / finalized_by describe the current finalization, so they are cleared...');
  assert.equal(row.finalized_by, null);
  const audit = detailOf(auditRows('attendance.reopened', TF.id)[0]);
  assert.equal(audit.previous_finalized_at, finalizedRow.finalized_at, '...and the previous values live on in the audit record');
  assert.equal(audit.reason, 'Late sign-in book found');
  assert.equal(audit.snapshot_preserved, true);
  assert.equal(JSON.stringify(expectedRows(TF)), snapshot, 'ITEM 19: the snapshot is preserved');
  assert.equal(JSON.stringify(recordRows(TF)), records, 'ITEM 19: every attendance record is preserved');
  assert.deepEqual(eventLog.at(-1), { type: 'reopened', sessionId: TF.id, userId: null });
  assert.equal(lifecycle.reopenAttendance(TF.id, { reason: 'again' }).reason, 'not_finalized');

  // While reopened, ordinary entry works again and the preview says a snapshot is preserved.
  assert.equal(attendance.recordAttendance(TF.id, [{ memberId: M6.id, status: 'present' }], { userId: null }).ok, true);
  const preview = lifecycle.previewFinalization(TF.id);
  assert.equal(preview.usingPreservedSnapshot, true, 'ITEM 20: the preview says a preserved snapshot will be reused');
  assert.equal(preview.rosterSource, 'snapshot');
  assert.equal(preview.canFinalize, true);

  // History is rewritten so a FRESH computation would now differ: Delta (in the snapshot) becomes
  // long-inactive and Late (not in the snapshot) becomes long-active. Only a preserved snapshot
  // survives that.
  plant(M4, { created: { at: atNoon(oldDate), status: 'inactive' } });
  const late = mk('Late');
  assert.notDeepEqual(
    tracking.resolveExpectedRoster(TF.service_date).expected.map((e) => e.memberId).sort((a, b) => a - b),
    JSON.parse(snapshot).map((r) => r.member_id), 'sanity: a fresh computation would now produce a different roster');
  changeStatus(M1.id, 'inactive', { reason: 'moved away' });
  const refinal = lifecycle.finalizeAttendance(TF.id, { userId: null });
  assert.equal(refinal.ok, true);
  assert.equal(refinal.snapshotReused, true, 'ITEM 20: re-finalizing reuses the historical snapshot');
  assert.equal(refinal.snapshotCreated, false);
  assert.equal(JSON.stringify(expectedRows(TF)), snapshot, 'ITEM 20: the roster was NOT rebuilt (Delta is inactive in history now, Late is active)');
  assert.ok(!expectedRows(TF).some((r) => r.member_id === late.id));
  assert.equal(auditRows('attendance.finalized', TF.id).length, 2);
  assert.equal(detailOf(auditRows('attendance.finalized', TF.id)[1]).snapshot, 'reused');
  assert.equal(stateOf(TF), 'finalized');

  // Not taken -> reopen.
  const noteRow = fresh(TE.id);
  assert.equal(lifecycle.reopenAttendance(TE.id, { userId: null, reason: 'Sheet turned up' }).ok, true);
  const te = fresh(TE.id);
  assert.deepEqual([te.finalization_state, te.finalization_note, te.finalized_at], [null, null, null]);
  assert.equal(detailOf(auditRows('attendance.reopened', TE.id)[0]).previous_note, noteRow.finalization_note);
  assert.equal(detailOf(auditRows('attendance.reopened', TE.id)[0]).previous_state, 'not_taken');
  assert.equal(attendance.recordAttendance(TE.id, [{ memberId: M1.id, status: 'present' }], {}).ok, true, 'ITEM 21: only a reopen restores entry to a not-taken Friday');
  console.log('PASS (reopen): reason required; records and snapshot preserved; re-finalizing reuses the historical snapshot; current-finalization fields cleared with the previous ones kept in the audit');
}

// ---------------------------------------------------------------------------
// Cancellation and reinstatement of finalized / not-taken services (TG, TD).
// ---------------------------------------------------------------------------
{
  const snapshot = JSON.stringify(expectedRows(TG));
  const records = JSON.stringify(recordRows(TG));
  assert.equal(lifecycle.changeSessionStatus(TG.id, 'scheduled', { userId: null }).reason, 'status_locked_by_finalization', 'a finalized service cannot be casually reverted to Scheduled');
  assert.equal(lifecycle.changeSessionStatus(TG.id, 'cancelled', { userId: null, notes: '' }).reason, 'reason_required', 'ITEM 37: cancelling a finalized service needs a reason');
  assert.equal(fresh(TG.id).status, 'held');
  const cancelled = lifecycle.changeSessionStatus(TG.id, 'cancelled', { userId: null, notes: 'Entered against the wrong Friday' });
  assert.equal(cancelled.ok, true);
  let row = fresh(TG.id);
  assert.equal(row.status, 'cancelled');
  assert.equal(row.finalization_state, 'finalized', 'ITEM 38: status and finalization stay separate columns');
  assert.equal(JSON.stringify(expectedRows(TG)), snapshot, 'the snapshot is preserved');
  assert.equal(JSON.stringify(recordRows(TG)), records, 'the records are preserved');
  assert.equal(tracking.classifySession(row).phase, 'cancelled');
  assert.equal(auditRows('attendance.session_cancelled_after_finalization', TG.id).length, 1);
  assert.equal(detailOf(auditRows('attendance.session_cancelled_after_finalization', TG.id)[0]).snapshot_preserved, true);
  assert.equal(lifecycle.reopenAttendance(TG.id, { reason: 'x' }).reason, 'session_cancelled');
  assert.equal(lifecycle.correctFinalizedAttendance(TG.id, [{ memberId: M5.id, to: 'present' }], { reason: 'x' }).reason, 'session_cancelled');
  assert.equal(attendance.recordAttendance(TG.id, [{ memberId: M5.id, status: 'present' }], {}).reason, 'session_cancelled');

  assert.equal(lifecycle.changeSessionStatus(TG.id, 'scheduled', { userId: null }).reason, 'status_locked_by_finalization', 'reinstating to Scheduled is refused too');
  assert.equal(lifecycle.changeSessionStatus(TG.id, 'held', { userId: null, notes: 'Reinstated' }).ok, true);
  row = fresh(TG.id);
  assert.equal(row.finalization_state, 'finalized', 'ITEM 39: reinstating restores the state exactly as it was');
  assert.equal(tracking.classifySession(row).phase, 'finalized');
  assert.equal(JSON.stringify(expectedRows(TG)), snapshot);
  assert.equal(auditRows('attendance.session_reinstated_after_finalization', TG.id).length, 1);

  // A not-taken service behaves the same; an open Friday is unchanged.
  assert.equal(lifecycle.changeSessionStatus(TD.id, 'cancelled', { notes: '' }).reason, 'reason_required');
  assert.equal(lifecycle.changeSessionStatus(TD.id, 'cancelled', { notes: 'wrong week' }).ok, true);
  assert.equal(fresh(TD.id).finalization_state, 'not_taken');
  assert.equal(lifecycle.changeSessionStatus(TD.id, 'held', {}).ok, true);
  assert.equal(lifecycle.changeSessionStatus(TB.id, 'cancelled', {}).ok, true, 'an open Friday can still be cancelled without a reason, as before');
  assert.equal(lifecycle.changeSessionStatus(TB.id, 'held', {}).ok, true);
  assert.equal(lifecycle.changeSessionStatus(TB.id, 'nonsense', {}).reason, 'invalid_status');

  // Date lock.
  assert.equal(lifecycle.isServiceDateLocked(fresh(TG.id)), true);
  assert.equal(lifecycle.isServiceDateLocked(fresh(TB.id)), false);
  assert.equal(lifecycle.isServiceDateLocked(fresh(TF.id)), true);
  console.log('PASS (cancellation): cancelling a finalized/not-taken service needs a reason and preserves state, snapshot and records; reinstating restores it; it can never be moved back to Scheduled');
}

// ---------------------------------------------------------------------------
// Regression: the open Friday, Temporarily Away return, non-Friday semantics.
// ---------------------------------------------------------------------------
{
  assert.equal(tracking.classifySession(fresh(TI.id)).phase, 'open');
  assert.equal(attendance.recordAttendance(TI.id, [{ memberId: M1.id, status: 'present' }], { userId: null }).ok, true, 'an open tracked Friday takes ordinary writes');
  // ITEM 50: Temporarily Away auto-return still works on an open Friday Present.
  assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(MAway.id).status, 'temporarily_away');
  assert.equal(attendance.recordAttendance(TI.id, [{ memberId: MAway.id, status: 'present' }], { userId: null }).ok, true);
  assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(MAway.id).status, 'active', 'ITEM 50: the member returned to Active');
  // ... and through the QR path (open session allowed).
  assert.equal(confirmCheckin(MAway2.id, TI.id, { userId: null }).ok, true, 'QR check-in works on an open Friday');
  assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(MAway2.id).status, 'active');
  // ITEM 51: non-Friday semantics intact - writable, no lifecycle, no auto-return.
  const away3 = mk('AwayThree', 'temporarily_away');
  assert.equal(tracking.classifySession(fresh(SPECIAL.id)).phase, 'not_applicable');
  assert.equal(attendance.recordAttendance(SPECIAL.id, [{ memberId: away3.id, status: 'present' }], { userId: null }).ok, true);
  assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(away3.id).status, 'temporarily_away', 'ITEM 51: a non-Friday Present never auto-returns anyone');
  assert.equal(lifecycle.finalizeAttendance(SPECIAL.id).reason, 'not_friday_service');
  assert.equal(attendance.recordAttendance(SPECIAL.id, [{ memberId: M1.id, status: null }], { userId: null }).ok, true, 'clearing works there too');
  // ITEM 52: a historical, unfinalized Friday can still be corrected by the ordinary register.
  const awaiting = fresh(TB.id);
  assert.equal(tracking.classifySession(awaiting).phase, 'awaiting_finalization');
  assert.equal(attendance.recordAttendance(TB.id, [{ memberId: M2.id, status: 'present' }], { userId: null }).ok, true, 'ITEM 52: historical admin correction of an unfinalized Friday still works');
  assert.equal(attendance.recordAttendance(TB.id, [{ memberId: M2.id, status: null }], { userId: null }).ok, true);
  console.log('PASS (regression): open Friday writes, Temporarily Away auto-return (manual + QR), non-Friday semantics and historical corrections of unfinalized Fridays are unchanged');
}

// Finalize the current Friday (needed for the kiosk/QR HTTP checks below).
assert.equal(lifecycle.finalizeAttendance(TI.id, { userId: null }).ok, true);
assert.equal(lifecycle.checkinClosure(fresh(TI.id)).reason, 'session_finalized');
assert.equal(lifecycle.checkinClosure(fresh(TB.id)), null);

// ---------------------------------------------------------------------------
// Go-Live lock (service level).
// ---------------------------------------------------------------------------
{
  const lock = lifecycle.trackingStartLock();
  assert.equal(lock.locked, true, 'ITEM 40: finalized Fridays lock the Go-Live date');
  assert.equal(lock.earliestFinalizedFriday, TA.service_date, 'the earliest finalized (or not-taken) Friday is the race Friday, whichever transition won');
  assert.equal(lifecycle.setTrackingStartDate('', { userId: null }).reason, 'locked');
  assert.equal(lifecycle.setTrackingStartDate(addDays(GO_LIVE, 7), { userId: null }).reason, 'locked', 'ITEM 41: an ordinary edit is refused');
  assert.equal(getSetting('attendance.tracking_start_date'), GO_LIVE);
  assert.equal(lifecycle.setTrackingStartDate(GO_LIVE, { userId: null }).changed, false, 'setting the same value is a harmless no-op');
  assert.equal(lifecycle.setTrackingStartDate(addDays(GO_LIVE, -7), { userId: null, override: true, reason: '' }).reason, 'reason_required', 'ITEM 42: an override needs a reason');
  assert.equal(lifecycle.setTrackingStartDate('', { userId: null, override: true, reason: 'r' }).reason, 'cannot_clear_when_locked');
  assert.equal(lifecycle.setTrackingStartDate('nonsense', { userId: null, override: true, reason: 'r' }).reason, 'invalid_date');
  // ITEM 43 (revised by the owner for UAT and production alike): a date later than the finalized history IS allowed to a Super Admin with a reason (those Fridays become historical only);
  // what is never allowed is a day that is not a Friday. The later-date behaviour is proved in attendance-tracking-start-control.mjs.
  assert.equal(lifecycle.setTrackingStartDate(addDays(GO_LIVE, -6), { userId: null, override: true, reason: 'r' }).reason, 'not_friday', 'ITEM 43: only a Friday can be the start date');
  assert.equal(getSetting('attendance.tracking_start_date'), GO_LIVE, 'nothing changed');

  // ITEM 44: a legitimate override, earlier than the finalized Fridays, is applied and audited.
  const moved = lifecycle.setTrackingStartDate(addDays(GO_LIVE, -7), { userId: null, override: true, reason: 'Church started counting a week earlier' });
  assert.equal(moved.ok, true);
  assert.equal(moved.overridden, true);
  assert.equal(getSetting('attendance.tracking_start_date'), addDays(GO_LIVE, -7));
  const audit = auditRows('attendance.tracking_start_overridden')[0];
  assert.equal(detailOf(audit).reason, 'Church started counting a week earlier');
  assert.equal(detailOf(audit).from, GO_LIVE);
  assert.equal(detailOf(audit).to, addDays(GO_LIVE, -7));
  // TH (GO_LIVE - 7) is now tracked; the Friday before it is not.
  assert.equal(tracking.classifySession(fresh(TH.id)).phase, 'awaiting_finalization');

  // With nothing finalized the date is freely editable - proven on a disposable table state.
  console.log('PASS (Go-Live lock): locked once any Friday is finalized; ordinary edits refused; only an override with a reason, to a date not later than a finalized Friday, and never clearing it - audited');
}

// ---------------------------------------------------------------------------
// HTTP: authorization, write paths through routes, kiosk/QR, settings lock.
// ---------------------------------------------------------------------------

const port = await new Promise((resolve) => {
  const srv = net.createServer();
  srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
});
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);

  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function login(email, password) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const res = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password, _csrf: csrf })
    });
    return cookieOf(res, pre);
  }
  async function csrfFor(urlPath, cookie) {
    const page = await fetch(`${base}${urlPath}`, { headers: { Cookie: cookie } });
    return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  }
  async function anyCsrf(cookie) {
    for (const page of ['/dashboard', '/attendance', '/kiosk', '/attendance/checkin']) {
      const res = await fetch(`${base}${page}`, { headers: { Cookie: cookie }, redirect: 'manual' });
      const match = res.status === 200 ? (await res.text()).match(/name="_csrf" value="([^"]+)"/) : null;
      if (match) return match[1];
    }
    return 'no-token-available';
  }
  const post = (urlPath, cookie, csrf, fields, headers = {}) => fetch(`${base}${urlPath}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie, ...headers },
    body: new URLSearchParams({ _csrf: csrf, ...fields })
  });
  const get = (urlPath, cookie) => fetch(`${base}${urlPath}`, { headers: { Cookie: cookie }, redirect: 'manual' });

  const PW = 'LifecyclePassw0rd!2026';
  const people = {};
  for (const [key, role] of [['admin', 'church_admin'], ['super', 'super_admin'], ['leader', 'cell_group_leader'], ['member', 'member'], ['kiosk', 'kiosk']]) {
    await createUser({ email: `${key}.lifecycle@fixture.invalid`, password: PW, displayName: key, roleKeys: [role], mustChangePassword: false });
    people[key] = await login(`${key}.lifecycle@fixture.invalid`, PW);
  }

  // ITEMS 45-49: authorization on every lifecycle route.
  const sid = TI.id;
  const lifecycleRoutes = [
    ['GET', `/attendance/sessions/${sid}/finalize`], ['POST', `/attendance/sessions/${sid}/finalize`],
    ['GET', `/attendance/sessions/${sid}/not-taken`], ['POST', `/attendance/sessions/${sid}/not-taken`],
    ['GET', `/attendance/sessions/${sid}/reopen`], ['POST', `/attendance/sessions/${sid}/reopen`],
    ['GET', `/attendance/sessions/${sid}/correct`], ['POST', `/attendance/sessions/${sid}/corrections`]
  ];
  for (const who of ['leader', 'member', 'kiosk']) {
    const csrf = await anyCsrf(people[who]);
    for (const [method, url] of lifecycleRoutes) {
      const res = method === 'GET' ? await get(url, people[who]) : await post(url, people[who], csrf, { reason: 'x', note: 'x', to_1: 'present' });
      assert.ok([403, 302, 303].includes(res.status) && (res.status === 403 || !/\/attendance\//.test(res.headers.get('location') || '')),
        `${who} must be denied ${method} ${url} (got ${res.status} -> ${res.headers.get('location')})`);
    }
  }
  assert.equal(stateOf(TI), 'finalized');
  const denied = db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'access.denied' AND entity_id LIKE '%/finalize%'").get().n;
  assert.ok(denied >= 1, 'denials are audited');
  for (const who of ['admin', 'super']) {
    for (const url of [`/attendance/sessions/${TH.id}/finalize`, `/attendance/sessions/${TH.id}/not-taken`, `/attendance/sessions/${TF.id}/reopen`, `/attendance/sessions/${TF.id}/correct`]) {
      assert.equal((await get(url, people[who])).status, 200, `ITEM 45/46: ${who} can open ${url}`);
    }
  }
  console.log('PASS (authorization): Church Admin and Super Admin reach every lifecycle screen; Cell Group Leader, Member and Kiosk are denied every lifecycle route (GET and POST)');

  // Finalize over HTTP (Church Admin), including refusal display and the empty-confirmation guard.
  {
    const previewHtml = await (await get(`/attendance/sessions/${TH.id}/finalize`, people.admin)).text();
    assert.match(previewHtml, /Finalize attendance/);
    assert.match(previewHtml, /Nothing has been changed yet/);
    assert.match(previewHtml, /No attendance has been recorded/, 'the empty-register warning is shown');
    let csrf = await csrfFor(`/attendance/sessions/${TH.id}/finalize`, people.admin);
    let res = await post(`/attendance/sessions/${TH.id}/finalize`, people.admin, csrf, {});
    assert.equal(res.status, 302);
    assert.equal(stateOf(TH), null, 'refused without the confirmation');
    res = await post(`/attendance/sessions/${TH.id}/finalize`, people.admin, csrf, { confirm_no_attendance: 'on' });
    assert.equal(res.headers.get('location'), `/attendance/sessions/${TH.id}`);
    assert.equal(stateOf(TH), 'finalized');
    const register = await (await get(`/attendance/sessions/${TH.id}`, people.admin)).text();
    assert.match(register, /Attendance is <strong>finalized<\/strong>/);
    assert.match(register, /Correct attendance/);
    assert.match(register, /Reopen/);
    assert.doesNotMatch(register, /data-register-save/, 'the register has no Save button once finalized');
    res = await post(`/attendance/sessions/${TH.id}/finalize`, people.admin, csrf, { confirm_no_attendance: 'on' });
    assert.equal(auditRows('attendance.finalized', TH.id).length, 1, 'a second POST changes nothing');
    console.log('PASS (finalize UI): preview then confirm; the empty-register guard applies; the register then shows Finalized with Correct / Reopen and no Save');
  }

  // Register / record routes on a finalized Friday: admin and leader refused; corrections only for attendance.finalize.
  {
    const before = JSON.stringify(recordRows(TF));
    for (const who of ['admin', 'leader']) {
      const csrf = await anyCsrf(people[who]);
      assert.notEqual(csrf, 'no-token-available', `${who}: a real CSRF token was obtained, so the refusal below comes from the attendance rules`);
      const res = await post(`/attendance/sessions/${TF.id}/records`, people[who], csrf, { [`status_${M5.id}`]: 'present' }, { Accept: 'application/json' });
      assert.ok([409, 403].includes(res.status), `ITEM 22/23: ${who} write to a finalized register is refused (got ${res.status})`);
      const add = await post(`/attendance/sessions/${TF.id}/add`, people[who], csrf, { person: `member:${M5.id}` });
      assert.ok([302, 403].includes(add.status));
    }
    assert.equal(JSON.stringify(recordRows(TF)), before, 'nothing was written by either');
    const adminCsrf = await csrfFor(`/attendance/sessions/${TF.id}`, people.admin);
    const res = await post(`/attendance/sessions/${TF.id}/records`, people.admin, adminCsrf, { [`status_${M5.id}`]: 'present' }, { Accept: 'application/json' });
    assert.equal(res.status, 409);
    assert.equal((await res.json()).reason, 'session_finalized');

    // Correction through the route, by a Church Admin.
    const csrf = await csrfFor(`/attendance/sessions/${TF.id}/correct`, people.admin);
    const noReason = await post(`/attendance/sessions/${TF.id}/corrections`, people.admin, csrf, { [`to_${M5.id}`]: 'excused', reason: '' });
    assert.equal(noReason.status, 302);
    assert.equal(JSON.stringify(recordRows(TF)), before, 'no reason, no change');
    const good = await post(`/attendance/sessions/${TF.id}/corrections`, people.admin, csrf, { [`to_${M6.id}`]: 'absent', [`to_${M5.id}`]: '', reason: 'Correcting through the screen' });
    assert.equal(good.headers.get('location'), `/attendance/sessions/${TF.id}`);
    assert.equal(recordRows(TF).find((r) => r.member_id === M6.id).status, 'absent');
    assert.equal(stateOf(TF), 'finalized');
    const page = await (await get(`/attendance/sessions/${TF.id}/correct`, people.admin)).text();
    assert.match(page, /Correct attendance/);
    console.log('PASS (finalized register over HTTP): ordinary writes by an admin or a leader are refused with a clear answer; a Church Admin corrects only through the correction screen, with a reason');
  }

  // Kiosk, QR and quick-record on the current (finalized) Friday.
  {
    const before = JSON.stringify(recordRows(TI));
    const kioskPage = await (await get('/kiosk', people.kiosk)).text();
    assert.match(kioskPage, /Check-in is closed/, 'the kiosk says check-in is closed');
    assert.doesNotMatch(kioskPage, /id="checkin-input"/, 'and offers no scan box');
    const adminCheckin = await (await get('/attendance/checkin', people.admin)).text();
    assert.match(adminCheckin, /Check-in is closed/);

    const csrf = await csrfFor('/kiosk', people.kiosk);
    const confirm = await post('/attendance/checkin/confirm', people.kiosk, csrf, { member_id: String(M5.id), session_id: String(TI.id), kiosk: '1' }, { Accept: 'application/json' });
    assert.equal(confirm.status, 409, 'ITEM 24/25: QR confirmation is refused');
    assert.equal((await confirm.json()).ok, false);
    const lookup = await post('/attendance/checkin/lookup', people.kiosk, csrf, { token: 'anything' }, { Accept: 'application/json' });
    assert.ok([404, 409].includes(lookup.status));
    const record = await post('/attendance/checkin/record', people.kiosk, csrf, { person: `member:${M5.id}`, kiosk: '1' }, { Accept: 'application/json' });
    assert.equal(record.status, 409, 'ITEM 26/27: quick / family record is refused');
    const review = await post('/attendance/checkin/review', people.kiosk, csrf, { person: `member:${M5.id}`, kiosk: '1' });
    assert.equal(review.status, 302);
    assert.equal(JSON.stringify(recordRows(TI)), before, 'the kiosk wrote nothing');

    // Kiosk cannot correct.
    const kioskCorrect = await post(`/attendance/sessions/${TI.id}/corrections`, people.kiosk, csrf, { [`to_${M5.id}`]: 'present', reason: 'x' });
    assert.ok([403, 302].includes(kioskCorrect.status));
    assert.equal(JSON.stringify(recordRows(TI)), before);
    console.log('PASS (kiosk / QR): a finalized current Friday shows "check-in closed", and QR confirm, lookup, review and quick-record are all refused server-side');
  }

  // Cancel / status route through HTTP.
  {
    const csrf = await csrfFor(`/attendance/sessions/${TF.id}`, people.admin);
    const res = await post(`/attendance/sessions/${TF.id}/status`, people.admin, csrf, { status: 'scheduled', notes: '' });
    assert.equal(res.status, 302);
    assert.equal(fresh(TF.id).status, 'held');
    const html = await (await get(res.headers.get('location'), people.admin)).text();
    assert.match(html, /cannot be moved back to Scheduled/);
    const noReason = await post(`/attendance/sessions/${TF.id}/status`, people.admin, csrf, { status: 'cancelled', notes: '' });
    assert.equal(fresh(TF.id).status, 'held', 'ITEM 37: cancelling a finalized service over HTTP needs a reason');
    const dateChange = await post(`/attendance/sessions/${TF.id}`, people.admin, csrf, { service_date: addDays(TF.service_date, -7), start_time: '', location: '', notes: '' });
    assert.equal(fresh(TF.id).service_date, TF.service_date, 'the date of a finalized service cannot be edited');
    void noReason; void dateChange;
    console.log('PASS (status route): finalized services cannot be moved to Scheduled, cancelled without a reason, or re-dated');
  }

  // Go-Live lock through the settings screen and the Super Admin override page.
  {
    const html = await (await get('/admin/settings?section=attendance', people.super)).text();
    assert.match(html, /Locked: attendance has been finalized/, 'the settings screen explains the lock');
    assert.match(html, /\/admin\/attendance\/tracking-start/, 'and offers the override to a Super Admin');
    assert.doesNotMatch(html, /name="attendance__tracking_start_date"/, 'the input is not even submitted');
    const current = getSetting('attendance.tracking_start_date');

    const csrf = await csrfFor('/admin/settings', people.super);
    const attempt = await post('/admin/settings', people.super, csrf, { attendance__tracking_start_date: addDays(current, 21) });
    assert.equal(attempt.status, 302);
    assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, current, 'ITEM 41/no raw bypass: posting the setting directly changes nothing');
    const adminHtml = await (await get('/admin/settings?section=attendance', people.admin)).text();
    assert.match(adminHtml, /Ask a Super Admin/);
    assert.doesNotMatch(adminHtml, /tracking-start"/);

    assert.equal((await get('/admin/attendance/tracking-start', people.admin)).status, 403, 'a Church Admin cannot reach the override');
    assert.equal((await post('/admin/attendance/tracking-start', people.admin, csrf, { tracking_start_date: addDays(current, -7), reason: 'x' })).status, 403);
    assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, current);

    const page = await (await get('/admin/attendance/tracking-start', people.super)).text();
    assert.match(page, /Attendance has been finalized/);
    const overrideCsrf = await csrfFor('/admin/attendance/tracking-start', people.super);
    const noReason = await post('/admin/attendance/tracking-start', people.super, overrideCsrf, { tracking_start_date: addDays(current, -7), reason: '' });
    assert.match(noReason.headers.get('location'), /^\/admin\/attendance\/tracking-start/);
    assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, current);
    const applied = await post('/admin/attendance/tracking-start', people.super, overrideCsrf, { tracking_start_date: addDays(current, -7), reason: 'Counting from an earlier week' });
    assert.equal(applied.headers.get('location'), '/admin/settings?section=attendance');
    assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, addDays(current, -7));
    assert.equal(auditRows('attendance.tracking_start_overridden').length, 2);
    console.log('PASS (Go-Live lock over HTTP): the settings form is locked and explains why; a direct post changes nothing; only a Super Admin override with a reason applies and is audited');
  }
} finally {
  await terminateAndWait(server);
}

console.log('ALL PASS');
