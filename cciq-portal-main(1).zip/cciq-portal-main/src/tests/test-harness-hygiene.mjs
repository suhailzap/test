import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * The test suite's own hygiene: every suite file is registered (an unregistered suite never runs and quietly rots), every
 * registered file exists, nothing is left focused or skipped, suites never reach for a real database or a fixed port, and any
 * fixed wait is small or explained. Flaky suites were the one recurring cost of the last phases, so the rules that prevent them
 * are enforced here. (The supervisor-crash-recovery timing fix waits for the child to be gone - waitFor(!isAlive) - instead of
 * sleeping a guessed number of seconds; that pattern is what new process tests should copy.)
 */

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..', '..');
const runner = fs.readFileSync(path.join(root, 'tools', 'run-tests.mjs'), 'utf8');
const registered = [...runner.matchAll(/'([\w.-]+\.mjs)'/g)].map((m) => m[1]);
const files = fs.readdirSync(here).filter((f) => f.endsWith('.mjs'));

assert.equal(new Set(registered).size, registered.length, 'no suite is registered twice');
assert.deepEqual(files.filter((f) => !registered.includes(f) && f !== path.basename(fileURLToPath(import.meta.url)) && !f.startsWith('_')), [], 'every suite file in src/tests is registered in tools/run-tests.mjs');
assert.ok(registered.includes('test-harness-hygiene.mjs'), 'and this suite runs too');
assert.deepEqual(registered.filter((f) => !files.includes(f)), [], 'every registered suite exists');
assert.deepEqual(files.filter((f) => f.includes('.tmp.') || f.startsWith('_')), [], 'no scratch test file is left behind');

const ALLOW_FIXED_PORT = new Set(['start-launcher-port.mjs']); // parses ports out of text; binds nothing
const ALLOW_REAL_NAMES = new Set(['start-launcher-port.mjs', 'release-launcher.mjs', 'release-assembly-audit.mjs', 'attendance-readiness-gate.mjs', 'db-invariants.mjs', 'status-history-diagnostic.mjs']); // name paths only to prove they are refused
const offenders = { focused: [], fixedPort: [], realDb: [], longSleep: [], untidy: [] };
for (const file of files) {
  const text = fs.readFileSync(path.join(here, file), 'utf8');
  if (/\b(it|test|describe)\.(only|skip)\b|\bxit\(|\bxdescribe\(/.test(text)) offenders.focused.push(file);
  const binds = [...text.matchAll(/\.listen\(\s*(\d+)/g)].map((m) => m[1]).filter((p) => p !== '0');
  const envPort = [...text.matchAll(/\bPORT\s*:\s*['"]?(\d{4,5})['"]?/g)].map((m) => m[1]);
  if ((binds.length || envPort.length) && !ALLOW_FIXED_PORT.has(file)) offenders.fixedPort.push(`${file}: ${[...binds, ...envPort].join(',')}`);
  const isolated = /createIsolatedTestEnv|buildPortalFixture|mkdtemp|os\.tmpdir|:memory:/.test(text);
  const touchesRealFiles = /data-dev|storage-dev|['"`]data\/cciq\.sqlite|C:\cciq|cciq-portal[\/]data/.test(text);
  if (touchesRealFiles && !isolated && !ALLOW_REAL_NAMES.has(file)) offenders.realDb.push(file);
  for (const m of text.matchAll(/setTimeout\([^,]+,\s*(\d+)\)/g)) if (Number(m[1]) > 2000 && file !== 'pid-lock.mjs') offenders.longSleep.push(`${file}: ${m[1]}ms`);
  // a suite that starts a server or browser must stop it
  if (/spawn\(process\.execPath[^)]*server\.js|startPortal\(|chromium\.launch\(/.test(text) && !/\.stop\(\)|terminateAndWait|browser\.close\(\)|\.kill\(/.test(text)) offenders.untidy.push(file);
}
assert.deepEqual(offenders.focused, [], 'nothing is focused or skipped');
assert.deepEqual(offenders.fixedPort, [], 'no suite binds a fixed port (a running portal would collide); they ask the OS for one');
assert.deepEqual(offenders.realDb, [], 'no suite names a real database or storage folder without an isolated environment');
assert.deepEqual(offenders.longSleep, [], 'no suite sleeps for more than two seconds (wait for a condition instead)');
assert.deepEqual(offenders.untidy, [], 'every suite that starts a server or a browser stops it');

const timeouts = /timeout\s*[:=]\s*(\d+)/.exec(runner);
assert.ok(/process\.exit\(1\)|\?\s*0\s*:\s*1\)/.test(runner), 'the runner fails the whole run when any suite fails');
console.log(`PASS (harness) ${files.length} suite files, ${registered.length} registered, none focused or skipped; no fixed port, real database or long sleep; every server/browser is stopped${timeouts ? `; runner timeout ${timeouts[1]}` : ''}`);
console.log('ALL PASS');
