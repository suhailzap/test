import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness, R06 from the red-team review, per the owner's explicit
 * decision: document AUDIENCE is the authorization/security boundary. A
 * document_relationships link to a member or cell group may organize/narrow
 * access, but must never override a more restrictive audience. Previously
 * scopeClause() OR'd a relationship link in as an independent grant, so a
 * 'staff'-audience document linked to a cell group or member leaked to that
 * group's leader or that member. Fixed by removing the relationship
 * branches from the visibility clause entirely - documentsFor()'s "documents
 * about this group/member" narrowing already uses its own separate,
 * correctly scope-AND-gated relatedType/relatedId filter in listDocuments(),
 * confirmed unaffected below.
 */

const env = createIsolatedTestEnv('cciq-document-audience-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const {
  createCategory, scopeFor, canSee, documentsFor
} = await import('../services/documents.js');
const { createUser } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

function insertDocument({ categoryId, uploadedBy = null }) {
  const at = new Date().toISOString();
  const result = db.prepare(
    `INSERT INTO documents (title, category_id, original_filename, stored_path, mime_type,
       file_extension, file_size, status, version, uploaded_by, created_at, updated_at)
     VALUES (?, ?, 'fixture.pdf', 'fixture.pdf', 'application/pdf', 'pdf', 100, 'active', 1, ?, ?, ?)`
  ).run('Fixture Document', categoryId, uploadedBy, at, at);
  return Number(result.lastInsertRowid);
}

function linkDocument(documentId, relatedType, relatedId) {
  db.prepare(
    `INSERT INTO document_relationships (document_id, related_type, related_id, created_at)
     VALUES (?, ?, ?, ?)`
  ).run(documentId, relatedType, relatedId, new Date().toISOString());
}

function fakeUser({ id, memberId = null, ledCellGroupIds = [], permissions }) {
  const set = new Set(permissions);
  return { id, memberId, ledCellGroupIds, can: (...perms) => perms.some((p) => set.has(p)) };
}

const group = createGroup({ name: 'Fixture Group' }, {});
const leaderMember = createMember({ first_name: 'Leader', last_name: 'Fixture' }, { status: 'active' });
db.prepare('UPDATE cell_groups SET leader_member_id = ? WHERE id = ?').run(leaderMember.id, group.id);
const plainMember = createMember({ first_name: 'Plain', last_name: 'Fixture' }, { status: 'active' });

// Real user rows (not just JS fixtures) so documents.uploaded_by's foreign
// key resolves — the uploader-visibility test below needs a genuine id.
const leaderUserId = await createUser({
  email: 'leader.docaudience@fixture.invalid', password: 'LeaderPassw0rd!2026',
  displayName: 'Leader Fixture', roleKeys: ['cell_group_leader'], memberId: leaderMember.id, mustChangePassword: false
});
const memberUserId = await createUser({
  email: 'member.docaudience@fixture.invalid', password: 'MemberPassw0rd!2026',
  displayName: 'Member Fixture', roleKeys: ['member'], memberId: plainMember.id, mustChangePassword: false
});

const leaderUser = fakeUser({
  id: leaderUserId, memberId: leaderMember.id, ledCellGroupIds: [group.id],
  permissions: ['documents.view', 'documents.upload', 'cellgroups.manage_own']
});
const memberUser = fakeUser({
  id: memberUserId, memberId: plainMember.id,
  permissions: ['documents.view']
});

const staffCategory = createCategory({ name: 'Financial Records', audience: 'staff' });
const membersCategory = createCategory({ name: 'Church Activities', audience: 'members' });
const leadersCategory = createCategory({ name: 'Ministry', audience: 'leaders' });

// --- 1. staff/admin-only + linked member: must NOT grant that member access. ---
{
  const docId = insertDocument({ categoryId: staffCategory.id });
  linkDocument(docId, 'member', plainMember.id);
  const visible = canSee(memberUser, { id: docId });
  assert.equal(visible, false, 'R06 CONFIRMED FIXED: linking a staff-only document to a member must not grant that member access');
  console.log('PASS: a staff/admin-only document linked to a member remains invisible to that member');
}

// --- 2. staff/admin-only + linked cell group: must NOT grant that leader access. ---
{
  const docId = insertDocument({ categoryId: staffCategory.id });
  linkDocument(docId, 'cell_group', group.id);
  const visible = canSee(leaderUser, { id: docId });
  assert.equal(visible, false, 'R06 CONFIRMED FIXED: linking a staff-only document to a cell group must not grant that leader access');
  console.log('PASS: a staff/admin-only document linked to a cell group remains invisible to that group\'s leader');
}

// --- 3. legitimately member-visible + linked member: still visible (audience alone already grants it). ---
{
  const docId = insertDocument({ categoryId: membersCategory.id });
  linkDocument(docId, 'member', plainMember.id);
  assert.equal(canSee(memberUser, { id: docId }), true, 'a members-audience document must remain visible to a member, linked or not');
  console.log('PASS: a legitimately member-visible document linked to a member is still visible');
}

// --- 4. legitimately leader/group-visible + linked group: still visible. ---
{
  const docId = insertDocument({ categoryId: leadersCategory.id });
  linkDocument(docId, 'cell_group', group.id);
  assert.equal(canSee(leaderUser, { id: docId }), true, 'a leaders-audience document must remain visible to a leader, linked or not');
  console.log('PASS: a legitimately leader/group-visible document linked to that group is still visible');
}

// --- 5. Uploader behavior: audience-appropriate uploads remain visible;
//     a staff-only upload is NOT independently visible to its own
//     uploader (Codex/R06: uploaded_by is no longer an audience bypass -
//     see the replace-escalation test below for exactly why). ---
{
  const ownMembersDoc = insertDocument({ categoryId: membersCategory.id, uploadedBy: leaderUser.id });
  assert.equal(canSee(leaderUser, { id: ownMembersDoc }), true,
    'an uploader must still see their own document when its audience is one they can already see');

  const ownStaffDoc = insertDocument({ categoryId: staffCategory.id, uploadedBy: leaderUser.id });
  assert.equal(canSee(leaderUser, { id: ownStaffDoc }), false,
    'CODEX FINDING CONFIRMED FIXED: uploading a document must not grant audience-independent visibility - a staff-only upload is not visible to its own (non-staff) uploader');
  console.log('PASS: an uploader sees their own audience-appropriate uploads, but uploading does not bypass a stricter audience');
}

// --- 5b. Codex's exact reproduction: a leader uploads a members-visible
//     document; an administrator later replaces its category with a
//     staff-only one (e.g. after discovering it should have been
//     confidential). The original uploader must lose access the moment
//     the audience changes - not retain it because uploaded_by never
//     changes. ---
{
  const docId = insertDocument({ categoryId: membersCategory.id, uploadedBy: leaderUser.id });
  assert.equal(canSee(leaderUser, { id: docId }), true, 'sanity: visible while the category is members-audience');

  db.prepare('UPDATE documents SET category_id = ? WHERE id = ?').run(staffCategory.id, docId);
  assert.equal(canSee(leaderUser, { id: docId }), false,
    'CODEX FINDING CONFIRMED FIXED: the original uploader must lose access once an administrator moves the document to a staff-only category, even though uploaded_by is unchanged');
  console.log('PASS: moving a document to a more restrictive category revokes the original uploader\'s access');
}

// --- 6. Direct document route access is what canSee() protects — proven above via canSee() itself,
//        which is exactly what routes/documents.js calls before serving GET /documents/:id and
//        GET /documents/:id/file (not merely list/UI visibility). ---

// --- documentsFor() narrowing is unaffected: still respects audience AND relatedness together. ---
{
  const staffDocLinkedToGroup = insertDocument({ categoryId: staffCategory.id });
  linkDocument(staffDocLinkedToGroup, 'cell_group', group.id);
  const leaderScope = scopeFor(leaderUser);
  const groupDocs = documentsFor('cell_group', group.id, { scope: leaderScope });
  assert.ok(!groupDocs.some((d) => d.id === staffDocLinkedToGroup),
    'documentsFor() must not surface a staff-only document to a leader just because it is related to their group');

  const leaderDocLinkedToGroup = insertDocument({ categoryId: leadersCategory.id });
  linkDocument(leaderDocLinkedToGroup, 'cell_group', group.id);
  const groupDocs2 = documentsFor('cell_group', group.id, { scope: leaderScope });
  assert.ok(groupDocs2.some((d) => d.id === leaderDocLinkedToGroup),
    'documentsFor() must still surface an audience-appropriate document related to the leader\'s own group');
  console.log('PASS: documentsFor() group/member narrowing still works, still respects audience');
}

db.close();
env.cleanup();
console.log('ALL PASS');
