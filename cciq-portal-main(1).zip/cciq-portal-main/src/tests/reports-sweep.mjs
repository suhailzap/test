import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The reports sweep: concrete defects found by reading every report's PDF, screen and CSV.
 *   - the attendance PDF for dates with no finalized Friday Service says so instead of printing a page of zero rows for every member;
 *   - the Faith Promise PDF names a status filter in its subtitle, and an empty filtered result is not reported as "no commitments have been submitted yet";
 *   - the cell group member CSV and the cell groups overview use the same attendance words as everywhere else (Services counted, Attendance %, Absences in a row);
 *   - no report prints "undefined", "NaN" or "null".
 */

const f = await buildPortalFixture('cciq-reports-sweep-');
const { users, ids, mods } = f;
const pdfs = await import('../services/reports-pdf.js');
const pdfText = async (doc) => {
  const chunks = []; doc.on('data', (c) => chunks.push(c)); await new Promise((r) => doc.on('end', r));
  const raw = Buffer.concat(chunks).toString('latin1'); let text = '';
  for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) {
    let c; try { c = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; }
    for (const h of c.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(h[1], 'hex').toString('latin1');
    for (const l of c.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += l[1];
    text += '\n';
  }
  return text;
};
const JUNK = /undefined|NaN|\bnull\b|\[object|Infinity/;
const portal = await startPortal();
try {
  const { today, addDays } = mods.dates;

  // ---- attendance PDF with nothing finalized in the dates ------------------------------------------------------------------------------------------------------------------------
  {
    const text = await pdfText(pdfs.attendancePdf({ from: addDays(today(), 3000), to: addDays(today(), 3030) }));
    assert.match(text, /No finalized Friday Service falls in these dates/, 'the empty state says why there are no figures');
    assert.doesNotMatch(text, /Services counted\s*Present/, 'no member table of zero rows');
    assert.doesNotMatch(text, JUNK);
    assert.match(text, /Attendance by member/);
  }

  // ---- Faith Promise PDF: status filter named, empty filter not mislabelled -----------------------------------------------------------------------------------------------------
  {
    const text = await pdfText(pdfs.faithPromisePdf({ campaignId: ids.promise, status: 'completed' }));
    assert.match(text, /Completed commitments only/, 'a filtered report says which status it shows');
    assert.match(text, /No completed commitments in this campaign\./, 'an empty filtered result is not "no commitments have been submitted"');
    assert.doesNotMatch(text, /have been submitted yet/);
    const all = await pdfText(pdfs.faithPromisePdf({ campaignId: ids.promise }));
    assert.doesNotMatch(all, /commitments only/, 'the unfiltered report carries no filter note');
    assert.doesNotMatch(all, JUNK);
  }

  // ---- the other PDFs carry no junk values -------------------------------------------------------------------------------------------------------------------------------------------
  for (const [name, make] of Object.entries({
    directory: () => pdfs.directoryPdf({ statuses: ['active'], includeContact: true }),
    occasions: () => pdfs.occasionsPdf({ from: today(), to: addDays(today(), 90) }),
    cellGroups: () => pdfs.cellGroupsPdf({ groupIds: [ids.groupA, ids.groupB] }),
    firstTimers: () => pdfs.firstTimersPdf({}),
    giving: () => pdfs.givingPdf({ campaignId: ids.board }),
    allYears: () => pdfs.allYearsGivingPdf(),
    longAbsence: () => pdfs.longAbsencePdf({})
  })) {
    assert.doesNotMatch(await pdfText(make()), JUNK, `${name} PDF prints no junk values`);
  }

  // ---- CSV headings -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
    const member = (await (await admin.get(`/cell-groups/${ids.groupA}/report.csv`)).text()).split('\n')[0];
    assert.match(member, /"Services counted \(Vacation not counted\)"/); assert.match(member, /"Attendance %"/); assert.match(member, /"Absences in a row"/);
    assert.doesNotMatch(member, /Consecutive finalized|Attendance rate|excluding Vacation\)/, 'the old long headings are gone');
    const overview = (await (await admin.get('/reports/cell-groups/export.csv')).text()).split('\n')[0];
    assert.match(overview, /"Recent attendance %"/);
    const screen = await (await admin.get('/reports/cell-groups')).text();
    assert.match(screen, /Recent attendance %/); assert.doesNotMatch(screen, /Recent attendance rate/);
  }
  console.log('PASS reports-sweep');
} finally { await portal.stop(); }
