import assert from 'node:assert/strict';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait } from './lib/test-env.mjs';

// Never import application modules until a NEW, disposable DB is selected.
const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-kiosk-test-');
const temp = env.root; // kept for the screenshot/profile paths below
Object.assign(process.env, { KIOSK_SESSION_ABSOLUTE_DAYS: '30', SESSION_IDLE_TIMEOUT_MINUTES: '45' });
const { migrate } = await import('../db/migrate.js'); migrate();
const { default: db } = await import('../db/index.js');
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const attendance = await import('../services/attendance.js');
const qr = await import('../services/qr-checkin.js');
const family = await import('../services/family-groups.js');
const members = await import('../services/members.js');
const { safeRedirect } = await import('../lib/validate.js');
const { OVERFLOW_CHECK_SCRIPT } = await import('../../tools/check-overflow.mjs');
const password = () => crypto.randomBytes(24).toString('base64url') + 'a9!';
const credentials = {};
for (const [key, roles] of [['admin',['super_admin']],['k1',['kiosk']],['k2',['kiosk']],['hybrid',['kiosk','church_admin']],['denied',['member']]]) {
  credentials[key] = { password: password() };
  credentials[key].id = await users.createUser({ username: key, email: key+'@fixture.invalid', password: credentials[key].password, displayName:'Fixture '+key, roleKeys:roles });
}
for(let id=1;id<=20;id++) db.prepare(`INSERT INTO members(id,member_code,first_name,last_name,status,qr_token,created_at,updated_at)
 VALUES(?,?,?,?,?,?,?,?)`).run(id,'FIX-'+id,'Person'+id,'Fixture','active',crypto.randomBytes(24).toString('base64url'),'2026-01-01','2026-01-01');
members.changeStatus(1, 'temporarily_away', { userId: credentials.admin.id, reason: 'Isolated return-path fixture' });
// Backdated well before "now" so the auto-return transition-order check
// (go-live session-versioning/R05 fix) treats a Present confirmed on the
// current Friday Service as evidence the member is back, not stale
// evidence from before they left - changeStatus() always stamps "now".
db.prepare("UPDATE member_status_history SET changed_at = '2026-01-02T00:00:00.000Z' WHERE member_id = 1 AND new_status = 'temporarily_away'").run();
const household=family.createFamilyGroup({name:'Fixture Household'});
family.addMemberToFamilyGroup(household.id,3);family.addMemberToFamilyGroup(household.id,4);
let server, browser, stdout='', stderr='';
const reserve=net.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));
const port=reserve.address().port;await new Promise(r=>reserve.close(r));process.env.PORT=String(port);
const base='http://127.0.0.1:'+port;
async function start(){ server=spawn(process.execPath,['src/server.js'],{cwd:root,env:process.env,windowsHide:true,stdio:['ignore','pipe','pipe']});server.stdout.on('data',d=>stdout+=d);server.stderr.on('data',d=>stderr+=d);for(let i=0;i<100;i++){if(server.exitCode!==null)throw new Error('Isolated server exited: '+stderr);try{if((await fetch(base+'/healthz')).ok)return;}catch{}await new Promise(r=>setTimeout(r,100));}throw new Error('Isolated startup timeout'); }
async function stop(){if(server)await terminateAndWait(server);}
const contexts=[];
let resetPassword;
const pageErrors=[];
async function context(){const ctx=await browser.newContext();contexts.push(ctx);return ctx;}
async function profileContext(profile,options={}){const ctx=await chromium.launchPersistentContext(profile,{channel:'chrome',headless:true,timeout:20000,...options});contexts.push(ctx);ctx.setDefaultTimeout(10000);ctx.setDefaultNavigationTimeout(10000);return ctx;}
async function csrf(ctx,url='/kiosk'){const res=await ctx.request.get(base+url);const html=await res.text();const token=html.match(/name="_csrf" value="([^"]+)"/)?.[1];assert(token,'CSRF token available');return token;}
async function login(ctx,key,next='/'){const token=await csrf(ctx,'/login');const res=await ctx.request.post(base+'/login',{form:{_csrf:token,email:key,password:credentials[key].password,next},maxRedirects:0});assert.equal(res.status(),302,'Login succeeds');return res;}
async function browserLogin(ctx,key){const page=ctx.pages()[0];await page.goto(base+'/login');await page.locator('input[name=email]').fill(key);await page.locator('input[name=password]').fill(credentials[key].password);await Promise.all([page.waitForURL(url=>url.pathname!=='/login'),page.getByRole('button',{name:'Sign in',exact:true}).click()]);}
async function getCount(ctx){return (await ctx.request.get(base+'/kiosk/count')).json();}
async function post(ctx,url,form){const body=new URLSearchParams({_csrf:await csrf(ctx)});for(const [name,value] of Object.entries(form))for(const entry of Array.isArray(value)?value:[value])body.append(name,String(entry));return ctx.request.post(base+url,{data:body.toString(),headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded'},maxRedirects:0});}
function age(key,ageMs,loginAge=0){for(const row of db.prepare('SELECT sid,sess FROM sessions').all()){const value=JSON.parse(row.sess);if(value.userId!==credentials[key].id)continue;value.lastSeenAt=Date.now()-ageMs;if(loginAge)value.loginAt=Date.now()-loginAge;db.prepare('UPDATE sessions SET sess=?,expires=? WHERE sid=?').run(JSON.stringify(value),Date.now()+86400000,row.sid);}}
function saved(key){return db.prepare('SELECT sess FROM sessions').all().map(r=>JSON.parse(r.sess)).filter(r=>r.userId===credentials[key].id);}
async function scan(page,id){const token=db.prepare('SELECT qr_token FROM members WHERE id=?').get(id).qr_token;await page.locator('#checkin-input').fill(token);await page.locator('#checkin-lookup').click();}
async function ready(page){if(await page.locator('#checkin-next').isVisible())await page.locator('#checkin-next').click();await page.locator('#checkin-input').waitFor({state:'visible'});}
async function expectedCount(page,n,timeout=22000){await page.waitForFunction(n=>document.querySelector('[data-kiosk-count]')?.textContent===String(n),n,{timeout});}
try {
 await start(); browser=await chromium.launch({channel:'msedge',headless:true});
 const admin=await context(), k1=await context(), k2=await context(), hybrid=await context();
 if(!process.argv.includes('--profiles-only')) {
 const normalLogin=await login(admin,'admin'); assert(!/expires=|max-age=/i.test(normalLogin.headers()['set-cookie']||''));
 const kioskLogin=await login(k1,'k1');assert(/expires=/i.test(kioskLogin.headers()['set-cookie']||''));await login(k2,'k2');
 await login(hybrid,'hybrid');assert.equal((await hybrid.cookies()).find(c=>c.name==='cciq.sid').expires,-1);
 assert.deepEqual([...users.loadUserContext(credentials.k1.id).permissions],['attendance.checkin','visitors.express_register']);
 assert.equal((await admin.cookies()).find(c=>c.name==='cciq.sid').expires,-1);
 assert((await k1.cookies()).find(c=>c.name==='cciq.sid').expires>Date.now()/1000+29*86400);
 for(const ctx of [admin,k1]){const c=(await ctx.cookies()).find(c=>c.name==='cciq.sid');assert(c.httpOnly);assert.equal(c.sameSite,'Lax');}
 for(const url of ['/','/members','/attendance']) assert.equal((await admin.request.get(base+url)).status(),200);
 assert.equal((await k1.request.get(base+'/members',{maxRedirects:0})).headers().location,'/kiosk');
 const bad=await context();await login(bad,'denied');assert.equal((await bad.request.get(base+'/kiosk/count',{maxRedirects:0})).status(),403);
 const page1=await k1.newPage(),page2=await k2.newPage(),adminPage=await admin.newPage();
 for(const page of [page1,page2,adminPage])page.on('pageerror',e=>pageErrors.push(e.message));
 await adminPage.goto(base+'/attendance');const kioskLink=adminPage.getByRole('link',{name:'Attendance Kiosk (opens in a new tab)',exact:true});assert.equal(await kioskLink.getAttribute('target'),'_blank');
 const originalUrl=adminPage.url();const popupPromise=adminPage.waitForEvent('popup');await kioskLink.click();const popup=await popupPromise;await popup.waitForLoadState();assert.equal(new URL(popup.url()).pathname,'/kiosk');assert.equal(adminPage.url(),originalUrl);assert.equal(await popup.locator('.kiosk__identity').innerText(),'Fixture admin');await popup.close();
 await page1.goto(base+'/kiosk');await page2.goto(base+'/kiosk');assert.equal(await page1.locator('.kiosk__identity').innerText(),'Fixture k1');assert.equal(await page1.locator('.sidenav').count(),0);
 const session=qr.checkinSession();assert(session);const sessionId=session.id;await expectedCount(page1,0);
 // Distinct terminals, duplicates, and the existing Temporary Away return rule.
 await scan(page1,1);await page1.locator('#checkin-confirm').click();await expectedCount(page1,1,5000);assert.equal(db.prepare('SELECT status FROM members WHERE id=1').get().status,'active');
 await expectedCount(page2,1);assert.equal(db.prepare('SELECT recorded_by FROM attendance_records WHERE member_id=1').get().recorded_by,credentials.k1.id);
 await ready(page1);await scan(page1,1);/* already checked in: no Confirm is offered, one clear way on, and the scan field has focus again after it */await page1.waitForFunction(()=>document.querySelector('#checkin-success-message').textContent.includes('already'));assert.equal(await page1.locator('#checkin-confirm').isVisible(),false,'nothing to confirm for someone already checked in');await page1.locator('#checkin-next').click();await page1.waitForFunction(()=>document.activeElement&&document.activeElement.id==='checkin-input');assert.equal((await getCount(k1)).count,1);
 await scan(page2,2);await page2.locator('#checkin-confirm').click();await expectedCount(page2,2,5000);await expectedCount(page1,2);
 // Household stays intact while another terminal changes authoritative data.
 await ready(page1);await scan(page1,3);await page1.locator('#checkin-family-view').waitFor({state:'visible'});const familyBefore=await page1.locator('#checkin-family-list').innerHTML();
 await page1.locator('#checkin-family-list input').first().focus();
 attendance.recordAttendance(sessionId,[{memberId:5,status:'present'}],{userId:credentials.admin.id});await expectedCount(page1,3);assert.equal(await page1.locator('#checkin-family-list').innerHTML(),familyBefore);
 assert(await page1.locator('#checkin-family-list input').first().evaluate(el=>el===document.activeElement));
 await page1.locator('#checkin-family-submit').click();await expectedCount(page1,5,5000);assert.equal(new URL(page1.url()).pathname,'/kiosk');
 const familySuccess=await page1.locator('#checkin-success-message').innerText();
 // Input and confirmation state survive count-only refreshes.
 await ready(page2);await page2.locator('#checkin-input').fill('partial-scanner-input');await page2.locator('#checkin-input').focus();
 attendance.recordAttendance(sessionId,[{memberId:6,status:'visitor'},{memberId:7,status:'absent'},{memberId:8,status:'excused'}],{userId:credentials.admin.id});await expectedCount(page2,6);assert.equal(await page2.locator('#checkin-input').inputValue(),'partial-scanner-input');assert.equal(await page2.evaluate(()=>document.activeElement.id),'checkin-input');
 await expectedCount(page1,6);assert.equal(await page1.locator('#checkin-success-message').innerText(),familySuccess);assert(await page1.locator('#checkin-success-view').isVisible());
 await scan(page2,9);await page2.locator('#checkin-confirm-view').waitFor({state:'visible'});const confirmBefore=await page2.locator('#checkin-confirm-view').innerHTML();
 attendance.recordAttendance(sessionId,[{memberId:10,status:'present'}],{userId:credentials.admin.id});await expectedCount(page2,7);assert.equal(await page2.locator('#checkin-confirm-view').innerHTML(),confirmBefore);await page2.locator('#checkin-cancel').click();
 // Search/review remains in kiosk even for a normal administrator, records by AJAX.
 await adminPage.goto(base+'/kiosk');await adminPage.getByRole('searchbox',{name:'Search by name'}).fill('Person11');await adminPage.getByRole('button',{name:'Search',exact:true}).click();await adminPage.locator('input[name=person]').check();
 await adminPage.locator('#checkin-search-input').focus();
 const searchBefore=await adminPage.locator('#checkin-search-input').inputValue();attendance.recordAttendance(sessionId,[{memberId:12,status:'present'}],{userId:credentials.admin.id});await expectedCount(adminPage,8);assert.equal(await adminPage.locator('#checkin-search-input').inputValue(),searchBefore);assert(await adminPage.locator('input[name=person]').isChecked());
 assert.equal(await adminPage.evaluate(()=>document.activeElement.id),'checkin-search-input');
 await adminPage.getByRole('button',{name:'Review selected'}).click();assert.equal(await adminPage.locator('.sidenav').count(),0);await adminPage.getByRole('button',{name:/Confirm attendance for/}).click();await expectedCount(adminPage,9,5000);assert.equal(new URL(adminPage.url()).pathname,'/attendance/checkin/review');assert.equal(db.prepare('SELECT recorded_by FROM attendance_records WHERE member_id=11').get().recorded_by,credentials.admin.id);
 // Simultaneous same member, overlapping family, manual/QR and triple scans.
 const requests=[post(k1,'/attendance/checkin/confirm',{member_id:13,session_id:sessionId}),post(k2,'/attendance/checkin/confirm',{member_id:13,session_id:sessionId}),post(admin,'/attendance/checkin/confirm',{member_id:13,session_id:sessionId})];assert((await Promise.all(requests)).every(r=>r.status()===200));assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=? AND member_id=13').get(sessionId).n,1);
 await Promise.all([post(k1,'/attendance/checkin/record',{person:['member:14','member:15'],kiosk:'1'}),post(k2,'/attendance/checkin/record',{person:['member:15','member:16'],kiosk:'1'})]);
 assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE member_id IN(14,15,16)').get().n,3);
 for(const [key,action] of [['k1','attendance.qr_checkin_confirmed'],['k2','attendance.qr_checkin_confirmed'],['admin','attendance.quick_recorded']])assert(db.prepare('SELECT COUNT(*) n FROM audit_logs WHERE user_id=? AND action=?').get(credentials[key].id,action).n>0);
 // Visitor arrival and converted visitor identity deduplication.
 db.prepare("INSERT INTO visitors(id,first_name,first_visit_date,created_at,updated_at) VALUES(1,'Guest',?,?,?)").run(session.service_date,'2026-01-01','2026-01-01');const beforeVisitor=(await getCount(k1)).count;
 await post(k1,'/attendance/checkin/record',{person:'visitor:1',kiosk:'1'});assert.equal((await getCount(k1)).count,beforeVisitor+1);
 db.prepare("UPDATE visitors SET member_id=17, state='joined' WHERE id=1").run();attendance.recordAttendance(sessionId,[{memberId:17,status:'present'}],{userId:credentials.admin.id});assert.equal((await getCount(k1)).count,beforeVisitor+1);
 // Network failure does not disturb scanning, then recovers on the next poll.
 await page2.route('**/kiosk/count',route=>route.abort());await page2.locator('#checkin-input').fill('still-scanning');await page2.locator('#checkin-input').focus();await page2.waitForFunction(()=>document.querySelector('[data-kiosk-count-note]').textContent.includes('unavailable'),null,{timeout:22000});assert.equal(await page2.locator('#checkin-input').inputValue(),'still-scanning');assert.equal(await page2.evaluate(()=>document.activeElement.id),'checkin-input');await page2.unroute('**/kiosk/count');await expectedCount(page2,(await getCount(k1)).count);
 console.log('PASS counter: local updates, two-way 15s sync, QR/manual/family/visitor, duplicates, attribution, focus/search/confirmation preservation, failure/recovery');
 await page2.locator('#checkin-input').fill('unrecognized-fixture-code');await page2.locator('#checkin-lookup').click();await page2.locator('#checkin-error').waitFor({state:'visible'});const errorBefore=await page2.locator('#checkin-error').innerText();
 await Promise.all([page2.waitForResponse(r=>r.url().endsWith('/kiosk/count')),page2.evaluate(()=>document.dispatchEvent(new CustomEvent('cciq:checkin')))]);assert.equal(await page2.locator('#checkin-error').innerText(),errorBefore);assert(await page2.locator('#checkin-error').isVisible());
 // Responsive tests use the live isolated app, actual Quick Access endpoints.
 await page1.goto(base+'/kiosk');const quick=await (await k1.request.get(base+'/quick-access/info')).json();if(quick.ok){assert.equal(quick.url,'https://portal.cciqonline.com');assert.equal(new URL(quick.url).search,'');const card=await k1.request.get(base+'/quick-access/card.png');assert.equal(card.status(),200);assert.match(card.headers()['content-type'],/image\/png/);}
 for(const width of [320,390,768,820,1024,1280,1440]){
  await page1.setViewportSize({width,height:1000});assert.equal((await page1.evaluate(OVERFLOW_CHECK_SCRIPT)).overflow,false,'Overflow at '+width);
  const layout=await page1.evaluate(()=>{const a=document.querySelector('.kiosk__attendance').getBoundingClientRect(),b=document.querySelector('.kiosk__lobby').getBoundingClientRect();return {side:b.left>a.left+10,stack:b.top>=a.bottom,share:a.width/(a.width+b.width)};});
  assert(width>=820?layout.side:layout.stack);if(width>=1024)assert(layout.share>=.65&&layout.share<=.7);
  for(const selector of ['.kiosk__bar .brand','[data-kiosk-counter]','#checkin-input','#checkin-search-input','.kiosk__lobby'])assert(await page1.locator(selector).isVisible());
  assert(await page1.getByRole('button',{name:'Sign out'}).isVisible());assert.equal(await page1.locator('.kiosk__identity').innerText(),'Fixture k1');
  await page1.screenshot({path:path.join(temp,'kiosk-'+width+'.png'),fullPage:true});console.log('PASS kiosk responsive '+width);
 }
 for(const url of ['/members','/attendance']){await adminPage.goto(base+url);for(const width of [320,390,768,820,1024,1280,1440]){await adminPage.setViewportSize({width,height:1000});assert.equal((await adminPage.evaluate(OVERFLOW_CHECK_SCRIPT)).overflow,false,url+' overflow at '+width);}}console.log('PASS Members/Attendance regression at all seven widths');
 await page1.setViewportSize({width:1280,height:1000});await page1.screenshot({path:path.join(temp,'kiosk-desktop.png')});await page1.setViewportSize({width:390,height:1000});await page1.screenshot({path:path.join(temp,'kiosk-mobile.png'),fullPage:true});
 // Stop polling while testing expiry so background traffic cannot obscure it.
 for(const page of [page1,page2,adminPage])await page.close();
 const admin2=await context();await login(admin2,'admin');assert.equal((await admin.request.get(base+'/members')).status(),200);assert.equal((await admin2.request.get(base+'/members')).status(),200);
 const beforeSeen=saved('admin').map(s=>s.lastSeenAt);await getCount(admin);assert.deepEqual(saved('admin').map(s=>s.lastSeenAt),beforeSeen);
 // Inspect actual SQLite store expiry after repeated express-session requests.
 const adminRows=()=>db.prepare('SELECT sid,sess,expires FROM sessions').all().filter(r=>JSON.parse(r.sess).userId===credentials.admin.id).map(r=>({sid:r.sid,expires:r.expires,lastSeenAt:JSON.parse(r.sess).lastSeenAt}));
 const beforePoll=adminRows();for(let i=0;i<3;i++){await new Promise(r=>setTimeout(r,30));await getCount(admin);assert.deepEqual(adminRows(),beforePoll);}
 for(const row of beforePoll)assert.equal(row.expires,row.lastSeenAt+45*60000);
 const idleBoundary=Date.now()+1500;for(const row of db.prepare('SELECT sid,sess FROM sessions').all()){const s=JSON.parse(row.sess);if(s.userId===credentials.admin.id){s.lastSeenAt=idleBoundary-45*60000;db.prepare('UPDATE sessions SET sess=?,expires=? WHERE sid=?').run(JSON.stringify(s),idleBoundary,row.sid);}}
 assert.equal((await admin.request.get(base+'/kiosk/count',{maxRedirects:0})).status(),200);assert(adminRows().every(r=>r.expires===idleBoundary));await new Promise(r=>setTimeout(r,1550));assert.equal((await admin.request.get(base+'/kiosk/count',{maxRedirects:0})).status(),302);await login(admin,'admin');
 age('admin',46*60000);assert.equal((await admin.request.get(base+'/members',{maxRedirects:0})).headers().location,'/login?timeout=1');await login(admin,'admin');
 age('k1',46*60000);assert.equal((await k1.request.get(base+'/kiosk')).status(),200);
 age('hybrid',46*60000);assert.equal((await hybrid.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,'/login?timeout=1');
 age('k1',0,31*86400000);assert.equal((await k1.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,'/login');await login(k1,'k1');
 users.setUserRoles(credentials.k1.id,['kiosk','church_admin']);await k1.request.get(base+'/kiosk');assert.equal((await k1.cookies()).find(c=>c.name==='cciq.sid').expires,-1);age('k1',46*60000);assert.match((await k1.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,/login/);users.setUserRoles(credentials.k1.id,['kiosk']);
 for(const [ctx,key] of [[admin,'admin'],[k2,'k2']]){users.setUserStatus(credentials[key].id,'disabled');assert.match((await ctx.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,/^\/login/);users.setUserStatus(credentials[key].id,'active');await login(ctx,key);const out=await ctx.request.post(base+'/logout',{form:{_csrf:await csrf(ctx)},maxRedirects:0});assert.equal(out.status(),302);assert.match((await ctx.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,/login/);}
 console.log('PASS normal/kiosk/hybrid cookies, fresh role changes, idle/absolute expiry, disabled users, logout, multiple devices, background polling not activity');
 // Safe redirects and intent, including failed login retaining kiosk intent.
 for(const target of ['https://example.invalid','//example.invalid','/\\example.invalid','/\t/example.invalid',null,{}])assert.equal(safeRedirect(target),'/');assert.equal(safeRedirect('/kiosk'),'/kiosk');
 const guest=await context();const intent=await guest.request.get(base+'/login?next=%2Fkiosk');assert.match(await intent.text(),/Attendance Kiosk Sign In/);const failed=await guest.request.post(base+'/login',{form:{_csrf:await csrf(guest,'/login?next=%2Fkiosk'),email:'k2',password:password(),next:'/kiosk'}});assert.equal(failed.status(),401);assert.match(await failed.text(),/Attendance Kiosk Sign In/);
 // Existing account administration: create -> secure reset -> forced change.
 await login(admin,'admin');const adminCsrf=await csrf(admin,'/admin/users/new');const created=await admin.request.post(base+'/admin/users',{form:{_csrf:adminCsrf,display_name:'Fixture Kiosk 03',email:'kiosk03@fixture.invalid',username:'kiosk_03',roles:'kiosk'},maxRedirects:0});assert.equal(created.status(),302);const createdUser=users.findUserByIdentifier('kiosk_03');assert(createdUser);resetPassword=password();await admin.request.post(base+`/admin/users/${createdUser.id}/password`,{form:{_csrf:await csrf(admin,`/admin/users/${createdUser.id}`),password:resetPassword},maxRedirects:0});credentials.kiosk_03={id:createdUser.id,password:resetPassword};
 const k3=await context();const forced=await login(k3,'kiosk_03','/kiosk');assert.equal(forced.headers().location,'/account/password');const passwordPage=await k3.request.get(base+'/account/password');assert.match(await passwordPage.text(),/body class="kiosk"/);const changed=password();const change=await k3.request.post(base+'/account/password',{form:{_csrf:await csrf(k3,'/account/password'),current_password:resetPassword,password:changed,confirm_password:changed},maxRedirects:0});assert.equal(change.status(),302);credentials.kiosk_03.password=changed;assert.equal((await k3.request.get(base+'/kiosk')).status(),200);assert.equal((await k3.request.get(base+'/members',{maxRedirects:0})).headers().location,'/kiosk');assert.deepEqual(users.rolesForUser(createdUser.id).map(r=>r.key),['kiosk']);
 console.log('PASS existing kiosk_03 creation/reset/forced-change/restricted-access workflow (isolated only); login intent and redirect checks');
 // Independent tabs and refresh continue sharing the normal browser session.
 const normalPage=await admin.newPage();await normalPage.goto(base+'/members');await normalPage.reload();assert.equal(new URL(normalPage.url()).pathname,'/members');const another=await admin.newPage();await another.goto(base+'/attendance');assert.equal(new URL(another.url()).pathname,'/attendance');await normalPage.close();await another.close();
 }
 // Chrome/Chromium profile restart experiments; never export cookie values.
 const profile=path.join(temp,'normal-profile');let persistent=await profileContext(profile);await browserLogin(persistent,'admin');await persistent.pages()[0].goto(base+'/members');await persistent.close();persistent=await profileContext(profile);const reopened=persistent.pages()[0];await reopened.goto(base+'/members');const normalRestored=!new URL(reopened.url()).pathname.startsWith('/login');console.log('BROWSER Chrome normal profile close/reopen authenticated: '+normalRestored);
 if(!normalRestored)await browserLogin(persistent,'admin');await reopened.goto(base+'/members');await persistent.close();persistent=await profileContext(profile,{args:['--restore-last-session']});await persistent.pages()[0].goto(base+'/members');console.log('BROWSER Chrome restore-last-session authenticated: '+!new URL(persistent.pages()[0].url()).pathname.startsWith('/login'));await persistent.close();
 const kioskProfile=path.join(temp,'kiosk-profile');persistent=await profileContext(kioskProfile);await browserLogin(persistent,'k2');await persistent.pages()[0].goto(base+'/kiosk');await persistent.close();persistent=await profileContext(kioskProfile);await persistent.pages()[0].goto(base+'/kiosk');assert.equal(new URL(persistent.pages()[0].url()).pathname,'/kiosk');await persistent.close();
 assert.deepEqual(pageErrors,[]);for(const entry of db.prepare('SELECT detail FROM audit_logs').all())for(const cred of Object.values(credentials))assert(!String(entry.detail).includes(cred.password));assert(!stdout.includes(resetPassword));assert(!stderr.includes(resetPassword));
 await login(k1,'k1');await login(admin,'admin');await stop();await start();for(const ctx of [k1,admin])assert.match((await ctx.request.get(base+'/kiosk',{maxRedirects:0})).headers().location,/login/);
 assert.equal(db.prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1').get().version,(await import('../db/migrate.js')).EXPECTED_MIGRATIONS.at(-1));
 console.log('PASS full isolated server restart invalidates both session types, no new migration, no credential leakage in audited details');console.log('Artifacts: '+temp);
} finally {for(const ctx of contexts)await ctx.close().catch(()=>{});if(browser)await browser.close();await stop();db.close();}
