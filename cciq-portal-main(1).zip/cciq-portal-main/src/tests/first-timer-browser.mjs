import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The First Timer corrections, in a real browser (what a person actually sees and does):
 *   1. a refused form: the summary takes focus, names the field, links to it; the message sits beside the field; typed values stay
 *   2. Back to First Timers from the detail page returns to the list as it was left
 *   3. an administrative check-in opens First Timer registration in a NEW tab; the check-in tab is untouched and scanning still works after
 *   4. the registration tab: the "Invited by" search (names only), a clean done page, Close this tab
 *   5. the Kiosk keeps its own flow (no new tab) and its inviter search shows names only
 *   6. the inviter table: headings and numbers share edges, whatever the digits, whichever column is sorted, at every width
 *   7. the detail page is compact, and nothing overflows on a phone
 */

const f = await buildPortalFixture('cciq-ft-browser-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const today = mods.dates.today();
const past = (n) => mods.dates.addDays(today, -n);
const contextFor = async (account) => {
  const session = await signIn(portal.base, account.email, f.PASSWORD);
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await context.addCookies(session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  return context;
};
const go = async (page, action) => { await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), action()]); };
const pick = async (page, query, name) => {
  await page.fill('[data-picker-input]', query);
  const option = page.locator('.member-picker__result', { hasText: name }).first();
  await option.waitFor({ state: 'visible', timeout: 5000 });
  await option.click();
};

try {
  const admin = await contextFor(users.churchAdmin);
  const kioskContext = await contextFor(users.kiosk);

  // ---- 1. a refused form --------------------------------------------------------------------------------------------------------------------
  {
    const page = await admin.newPage();
    await page.setViewportSize({ width: 1280, height: 520 }); // short, so anything below the fold is genuinely out of sight
    await page.goto(`${portal.base}/visitors/new`, { waitUntil: 'load' });
    await page.fill('#first_name', 'Isaiah'); await page.fill('#last_name', 'Thomas'); await page.fill('#phone', '88971231231');
    await page.fill('#email', '21323@asdasda'); await page.selectOption('#age_group', 'teen'); await page.fill('#first_visit_date', past(30));
    await pick(page, 'Anna', 'Anna MemberA');
    await go(page, () => page.click('main form button[type=submit]'));
    assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.hasAttribute('data-error-summary')), true, 'focus lands on the error summary');
    const box = await page.locator('[data-error-summary]').boundingBox();
    assert.ok(box && box.y >= 0 && box.y + box.height <= 520, 'the summary is in view without scrolling');
    const headerBottom = await page.evaluate(() => document.querySelector('.topbar, header').getBoundingClientRect().bottom);
    assert.ok(box.y >= headerBottom - 1, `and is not hidden under the sticky header (summary top ${Math.round(box.y)}, header bottom ${Math.round(headerBottom)})`);
    const summaryText = (await page.locator('[data-error-summary]').textContent()).replace(/\s+/g, ' ');
    assert.match(summaryText, /Email needs a dot after the @, such as name@example\.com\./);
    assert.doesNotMatch(summaryText, /Email: Email/, 'the field name is not said twice');
    assert.doesNotMatch(summaryText, /highlighted/);
    assert.equal(await page.locator('#email').getAttribute('aria-invalid'), 'true');
    assert.equal(await page.locator('#email').getAttribute('aria-describedby'), 'email-error');
    assert.equal(await page.locator('#first_name').getAttribute('aria-invalid'), 'false');
    assert.match(await page.locator('#email-error').textContent(), /needs a dot after the @/);
    // the link in the summary goes to the field
    await page.click('[data-error-summary] a');
    assert.equal(await page.evaluate(() => document.activeElement.id), 'email', 'the summary link moves focus to the Email field');
    assert.equal(await page.inputValue('#first_name'), 'Isaiah'); assert.equal(await page.inputValue('#phone'), '88971231231');
    assert.equal(await page.inputValue('#email'), '21323@asdasda'); assert.equal(await page.inputValue('#age_group'), 'teen');
    assert.match(await page.textContent('[data-picker-selected-name]'), /Anna MemberA/, 'the inviter is still chosen');
    // errors far below the fold: a long Notes value
    await page.fill('#email', 'isaiah@example.com'); await page.fill('#notes', 'n'.repeat(2100));
    await go(page, () => page.click('main form button[type=submit]'));
    assert.equal(await page.evaluate(() => document.activeElement.hasAttribute('data-error-summary')), true);
    assert.match(await page.locator('[data-error-summary]').textContent(), /Notes must be 2000 characters or fewer/, 'a problem at the bottom of the page is found from the top');
    await page.click('[data-error-summary] a');
    const notesBox = await page.locator('#notes').boundingBox();
    assert.ok(notesBox.y >= 0 && notesBox.y < 520, 'following the link brings the far-away field into view');
    await page.fill('#notes', 'fine');
    await go(page, () => page.click('main form button[type=submit]'));
    assert.match(page.url(), /\/visitors\/\d+$/, 'corrected, it saves');
    assert.equal(db.prepare("SELECT email FROM visitors WHERE first_name = 'Isaiah' AND notes = 'fine'").get().email, 'isaiah@example.com');
    await page.close();
    console.log('PASS (1) a refused First Timer form focuses its summary, names the Email, links to it, keeps every value, and finds a far-below-the-fold field');
  }

  // ---- 2. Back to First Timers --------------------------------------------------------------------------------------------------------------
  {
    const page = await admin.newPage();
    await page.goto(`${portal.base}/visitors?q=Isaiah&sort=name&dir=asc`, { waitUntil: 'load' });
    await go(page, () => page.click('table.data a:has-text("Isaiah Thomas")'));
    assert.match(page.url(), /\/visitors\/\d+$/);
    await go(page, () => page.click('a[data-back-to-list]'));
    const url = new URL(page.url());
    assert.equal(url.pathname, '/visitors'); assert.equal(url.searchParams.get('q'), 'Isaiah'); assert.equal(url.searchParams.get('sort'), 'name'); assert.equal(url.searchParams.get('dir'), 'asc');
    assert.ok(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Isaiah'") >= 1);
    await page.close();
    console.log('PASS (2) Back to First Timers returns to the list with its search and sort');
  }

  // ---- 3 and 4. administrative check-in -> new tab -> registration -> done -----------------------------------------------------------------
  {
    const main = await admin.newPage();
    await main.goto(`${portal.base}/attendance/checkin`, { waitUntil: 'load' });
    assert.equal(await main.evaluate(() => document.activeElement.id), 'checkin-input', 'the scan field has focus');
    const link = main.locator('[data-first-timer-link]');
    assert.equal(await link.getAttribute('target'), '_blank'); assert.match(await link.getAttribute('rel'), /noopener/);
    assert.match(await link.textContent(), /First time here\? Register and check in/);
    assert.match(await link.textContent(), /opens in a new tab/, 'announced as opening a new tab');
    const mainUrl = main.url();
    const [popup] = await Promise.all([admin.waitForEvent('page'), link.click()]);
    await popup.waitForLoadState('load');
    assert.match(popup.url(), /\/attendance\/checkin\/first-timer$/, 'the registration form opens in its own tab');
    assert.equal(main.url(), mainUrl, 'the check-in tab did not navigate');
    assert.ok(await main.locator('#checkin-input').isVisible(), 'and its scan area is still there');

    await popup.fill('#ft-first-name', 'Tabbed'); await popup.fill('#ft-last-name', 'Guest');
    // names only, three characters or more
    await popup.fill('[data-picker-input]', 'An');
    await popup.waitForTimeout(500);
    assert.equal(await popup.locator('.member-picker__result').count(), 0, 'two characters search nothing');
    await popup.fill('[data-picker-input]', 'Ann');
    await popup.locator('.member-picker__result').first().waitFor({ state: 'visible', timeout: 5000 });
    const rows = (await popup.locator('.member-picker__result').allTextContents()).map((t) => t.replace(/\s+/g, ' ').trim());
    assert.ok(rows.length >= 1 && rows.every((t) => !/CCIQ-|5550|Alpha|Beta/.test(t)), `only names are offered (${rows.join(' | ')})`);
    await popup.locator('.member-picker__result', { hasText: 'Anna MemberA' }).click();
    await go(popup, () => popup.click('main form button[type=submit]'));
    assert.match(popup.url(), /\/attendance\/checkin\/first-timer\/done$/, 'a clean done page');
    const doneText = (await popup.textContent('main')).replace(/\s+/g, ' ');
    assert.match(doneText, /Welcome, Tabbed! You are checked in\./); assert.match(doneText, /Close this tab/); assert.match(doneText, /Register another First Timer/);
    const tabbed = db.prepare("SELECT id, invited_by_member_id FROM visitors WHERE first_name = 'Tabbed'").get();
    assert.equal(tabbed.invited_by_member_id, ids.member.a2, 'the inviter was recorded');
    assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', tabbed.id), 1, 'with the visit');
    // Close this tab: the browser may close it (opened from a link) or not; either way the page says what to do
    // the click may close the very tab it is made in; whether Playwright reports that as an error depends on timing, so it is not an assertion
    await popup.click('#ft-close-tab').catch(() => {});
    await popup.waitForEvent('close', { timeout: 1500 }).catch(() => {});
    const closed = popup.isClosed();
    if (!closed) assert.ok(await popup.locator('#ft-close-hint').isVisible(), 'if the browser keeps the tab open, the page says it can be closed');
    // back on the check-in tab: scanning still works with no click needed
    await main.bringToFront();
    await main.evaluate(() => { window.dispatchEvent(new Event('focus')); });
    assert.equal(await main.evaluate(() => document.activeElement.id), 'checkin-input', 'the scan field has focus again when the person returns');
    await main.keyboard.type('CODE123');
    assert.equal(await main.inputValue('#checkin-input'), 'CODE123', 'a scan typed now lands in the scan field');
    assert.equal(main.url(), mainUrl);
    assert.equal(await main.locator('.alert:visible, .toast:visible').count(), 0, 'with no stray message left on the check-in screen');
    if (!popup.isClosed()) await popup.close();
    await main.close();
    console.log(`PASS (3-4) check-in opens registration in a new tab and stays intact; names-only inviter search; clean done page; Close this tab (${closed ? 'the browser closed it' : 'the browser kept it, so the page said so'}); scanning works on return`);
  }

  // ---- 5. the Kiosk keeps its own flow ----------------------------------------------------------------------------------------------------
  {
    const page = await kioskContext.newPage();
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    const link = page.locator('a[href="/attendance/checkin/first-timer"]');
    assert.equal(await link.getAttribute('target'), '_blank', 'the Kiosk link opens in a new tab');
    assert.match(await link.getAttribute('rel'), /noopener/, 'without handing the new tab its opener');
    const [tab] = await Promise.all([kioskContext.waitForEvent('page'), link.click()]);
    await tab.waitForLoadState('load');
    await tab.fill('#ft-first-name', 'Kioskie');
    await tab.fill('[data-picker-input]', 'Bella');
    await tab.locator('.member-picker__result', { hasText: 'Bella MemberB' }).click();
    assert.equal(await tab.locator('[data-picker-selected-name]').isVisible(), true);
    await Promise.all([tab.waitForNavigation({ waitUntil: 'load' }), tab.click('main form button[type=submit]')]);
    assert.equal(new URL(tab.url()).pathname, '/attendance/checkin/first-timer/done', 'the registration tab ends on its own done page');
    assert.match((await tab.textContent('main')).replace(/\s+/g, ' '), /Welcome, Kioskie/);
    assert.match(await tab.content(), /<body class="kiosk">/, 'in the Kiosk layout');
    assert.equal(db.prepare("SELECT invited_by_member_id FROM visitors WHERE first_name = 'Kioskie'").get().invited_by_member_id, ids.member.b1);
    assert.equal(new URL(page.url()).pathname, '/kiosk', 'the kiosk tab was left exactly where it was');
    await tab.close();
    await page.close();
    console.log('PASS (5) the Kiosk registers in its own tab with its optional inviter, ends on a done page in the Kiosk layout, and the kiosk tab is untouched');
  }

  // ---- 6. the inviter table, measured --------------------------------------------------------------------------------------------------------
  {
    const insert = db.prepare("INSERT INTO visitors (first_name, last_name, first_visit_date, invited_by_member_id, state, follow_up_state, created_at, updated_at) VALUES (?, 'Of', ?, ?, ?, 'new', ?, ?)");
    const now = new Date().toISOString();
    const inviters = {};
    for (const [label, n] of [['Zero', 0], ['One', 1], ['Seven', 7], ['Many', 1234]]) {
      inviters[label] = mods.members.createMember({ first_name: `Digits${label}`, last_name: 'Inviter' }, { status: 'active' }).id;
      db.exec('BEGIN');
      for (let i = 0; i < n; i += 1) insert.run(`G${label}${i}`, past(40), inviters[label], i % 5 === 0 ? 'declined' : 'new', now, now);
      db.exec('COMMIT');
    }
    const zeroKid = mods.visitors.createVisitor({ first_name: 'Zeroes', last_name: 'Only', first_visit_date: past(40), invited_by_member_id: inviters.Zero }, { userId: null });
    db.prepare("UPDATE visitors SET state = 'joined', member_id = ? WHERE id = ?").run(ids.member.free, zeroKid.id);

    const measure = (page) => page.evaluate(() => {
      const table = document.querySelector('table.inviter-table');
      const rows = [...table.querySelectorAll(':scope > tbody > tr.inviter-main')];
      const edge = (el) => { const r = document.createRange(); r.selectNodeContents(el); const rects = [...r.getClientRects()]; return rects.length ? Math.max(...rects.map((x) => x.right)) : null; };
      const textEdge = (el) => { // right edge of the visible TEXT inside an element, ignoring the absolutely placed sort arrow
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.parentElement.classList.contains('sort-arrow') || !n.textContent.trim() ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
        let max = -1; while (walker.nextNode()) { const r = document.createRange(); r.selectNodeContents(walker.currentNode); for (const x of r.getClientRects()) max = Math.max(max, x.right); }
        return max;
      };
      const heads = [...table.querySelectorAll(':scope > thead th')];
      return {
        cols: heads.map((th, i) => ({
          headEdge: textEdge(th), headAlign: getComputedStyle(th).textAlign,
          cellEdges: rows.map((tr) => textEdge(tr.children[i])), cellAligns: rows.map((tr) => getComputedStyle(tr.children[i]).textAlign)
        })),
        overflow: document.documentElement.scrollWidth > window.innerWidth + 1,
        tableRight: table.getBoundingClientRect().right, viewport: window.innerWidth
      };
    });

    const page = await admin.newPage();
    for (const [width, height] of [[1440, 900], [1024, 768], [768, 1024]]) {
      await page.setViewportSize({ width, height });
      for (const sortColumn of ['invited', 'still_visiting', 'joined', 'lapsed', 'member']) {
        await page.goto(`${portal.base}/visitors/follow-up?isize=100&isort=${sortColumn}&idir=desc#inviters`, { waitUntil: 'load' });
        const m = await measure(page);
        assert.equal(m.overflow, false, `${width}px, sorted by ${sortColumn}: the page does not overflow sideways`);
        for (const [i, c] of m.cols.entries()) {
          if (i === 0) continue;
          assert.equal(c.headAlign, 'right', `${width}px col ${i}: the heading is right-aligned`);
          assert.ok(c.cellAligns.every((a) => a === 'right'), `${width}px col ${i}: so are its numbers`);
          for (const edge of c.cellEdges) assert.ok(Math.abs(edge - c.headEdge) <= 1.5, `${width}px, sorted by ${sortColumn}, column ${i}: heading text ends at ${c.headEdge.toFixed(1)}, a number at ${edge.toFixed(1)}`);
        }
      }
    }
    // the sort arrow does not move the label: the heading text edge is the same with and without the arrow
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(`${portal.base}/visitors/follow-up?isize=100&isort=invited&idir=desc`, { waitUntil: 'load' });
    const withArrow = (await measure(page)).cols[1].headEdge;
    await page.goto(`${portal.base}/visitors/follow-up?isize=100&isort=member&idir=desc`, { waitUntil: 'load' });
    const without = (await measure(page)).cols[1].headEdge;
    assert.ok(Math.abs(withArrow - without) <= 0.5, `the arrow does not shift the heading (${withArrow} vs ${without})`);
    // expanding an inviter shows invitees readably, without moving the columns
    await page.goto(`${portal.base}/visitors/follow-up?isize=100`, { waitUntil: 'load' });
    const toggle = page.locator('[data-inviter-toggle]').first();
    assert.equal(await toggle.isVisible(), true, 'with scripting, a toggle appears');
    const detail = page.locator('tr.inviter-detail').first();
    assert.equal(await detail.isHidden(), true, 'and the invitees start folded away');
    const before = (await measure(page)).cols.map((c) => c.headEdge);
    await toggle.click();
    assert.equal(await toggle.getAttribute('aria-expanded'), 'true'); assert.equal(await detail.isVisible(), true);
    const after = (await measure(page)).cols.map((c) => c.headEdge);
    assert.deepEqual(after, before, 'opening a row moves no column');
    const detailBox = await page.locator('.inviter-detail__box').first().boundingBox();
    assert.ok(detailBox.width > 300, 'the invitee list has room to be read');
    await toggle.click(); assert.equal(await detail.isHidden(), true, 'and folds away again');
    // a phone: stacked records, labelled, no sideways scroll, with a row expanded
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(`${portal.base}/visitors/follow-up?isize=100`, { waitUntil: 'load' });
    await page.locator('[data-inviter-toggle]').first().click();
    const phone = await measure(page);
    assert.equal(phone.overflow, false, 'a 390px phone does not scroll sideways, even with an inviter expanded');
    assert.ok(phone.tableRight <= phone.viewport + 1);
    const labels = await page.locator('tr.inviter-main').first().locator('td').evaluateAll((tds) => tds.map((td) => td.getAttribute('data-label')));
    assert.deepEqual(labels, ['Member', 'Invited', 'Still visiting', 'Became members', 'Did not continue'], 'every stacked value keeps its label');
    // the right digits are shown for 0, 1, 7 and 1234
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto(`${portal.base}/visitors/follow-up?isize=100`, { waitUntil: 'load' });
    const shown = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll('tr.inviter-main')].map((tr) => [tr.children[0].querySelector('a').textContent.trim().replace(/\s+/g, ' '), [...tr.children].slice(1).map((td) => td.textContent.trim())])));
    assert.deepEqual(shown['DigitsMany Inviter'], ['1234', String(count("SELECT COUNT(*) n FROM visitors WHERE invited_by_member_id = ? AND state IN ('new','returning')", inviters.Many)), '0', String(count("SELECT COUNT(*) n FROM visitors WHERE invited_by_member_id = ? AND state IN ('declined','not_returned')", inviters.Many))]);
    assert.deepEqual(shown['DigitsZero Inviter'], ['1', '0', '1', '0'], 'one invited who became a member: zeros are shown as zeros');
    assert.equal(shown['DigitsOne Inviter'][0], '1'); assert.equal(shown['DigitsSeven Inviter'][0], '7');
    await page.close();
    console.log('PASS (6) the inviter table: heading and numbers share a right edge (0, 1, 7, 1234), whichever column is sorted, at 1440/1024/768; the arrow shifts nothing; expanding moves no column; a 390px phone stacks, labelled, without overflow');
  }

  // ---- 7. the detail page: compact, and fine on a phone ---------------------------------------------------------------------------------------
  {
    const target = db.prepare("SELECT id FROM visitors WHERE first_name = 'Tabbed'").get().id;
    const page = await admin.newPage();
    for (let i = 0; i < 5; i += 1) await (await signIn(portal.base, users.churchAdmin.email, f.PASSWORD)).post(`/visitors/${target}/visits`, { visit_date: past(7 * (i + 1) + 2) }, { csrfFrom: `/visitors/${target}` });
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto(`${portal.base}/visitors/${target}`, { waitUntil: 'load' });
    const layout = await page.evaluate(() => ({
      cards: [...document.querySelectorAll('.ft-detail .card')].map((c) => { const r = c.getBoundingClientRect(); return { top: r.top + window.scrollY, bottom: r.bottom + window.scrollY, h: r.height, title: c.querySelector('h2').textContent.trim() }; }),
      docHeight: document.documentElement.scrollHeight, overflow: document.documentElement.scrollWidth > window.innerWidth + 1
    }));
    assert.equal(layout.cards.length, 4);
    assert.ok(layout.cards.every((c) => c.top < 768), 'all four cards begin on the first screen of a 1366x768 laptop');
    const tallest = Math.max(...layout.cards.map((c) => c.h));
    assert.ok(layout.docHeight <= 1100, `the whole page is short (${layout.docHeight}px with six visits)`);
    assert.ok(tallest <= 520, `no card is oversized (tallest ${Math.round(tallest)}px)`);
    assert.equal(layout.overflow, false);
    const backBtn = await page.locator('a[data-back-to-list]').boundingBox(); assert.ok(backBtn, 'Back is visible');
    // phone and tablet: touch-sized controls, nothing sideways
    for (const [w, h] of [[768, 1024], [390, 844]]) {
      await page.setViewportSize({ width: w, height: h });
      await page.goto(`${portal.base}/visitors/${target}`, { waitUntil: 'load' });
      const m = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > window.innerWidth + 1,
        small: [...document.querySelectorAll('main a.btn, main button.btn, main select, main input:not([type=hidden])')].filter((el) => el.offsetParent !== null).map((el) => ({ h: el.getBoundingClientRect().height, t: (el.textContent || el.name || '').trim().slice(0, 24) })).filter((x) => x.h < 32)
      }));
      assert.equal(m.overflow, false, `${w}px: no sideways scroll`);
      assert.deepEqual(m.small, [], `${w}px: every control is at least 32px tall`);
    }
    await page.close();
    console.log('PASS (7) the detail page shows all four cards on the first screen of a laptop, is short and has no oversized card; phone and tablet stay touch-sized with no sideways scroll');
  }

  // ---- 8. the registration forms at phone width -----------------------------------------------------------------------------------------------
  {
    const page = await admin.newPage();
    await page.setViewportSize({ width: 390, height: 844 });
    for (const url of ['/visitors/new', '/attendance/checkin/first-timer', '/attendance/checkin']) {
      await page.goto(`${portal.base}${url}`, { waitUntil: 'load' });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1), false, `${url} at 390px does not scroll sideways`);
    }
    await page.close();
    console.log('PASS (8) /visitors/new, the registration tab and the check-in screen fit a 390px phone');
  }
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
