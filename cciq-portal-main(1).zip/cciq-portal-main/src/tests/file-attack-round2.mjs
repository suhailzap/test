import assert from 'node:assert/strict';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Files, round 2 (upload-download-safety.mjs and file-handling-extra.mjs hold round 1). Attacked here, through the real routes:
 *   1. hostile and awkward FILE NAMES (reserved Windows device names, traversal, trailing dots and spaces, NUL, right-to-left override, 300 characters,
 *      Unicode, emoji): never an error, never a path built from the name, and a download header that cannot be split or smuggle a name;
 *   2. content that lies: an executable called .pdf, a PNG called .pdf, zero bytes, a header with nothing after it, a file over the limit;
 *   3. four replacements of one document at once: contiguous versions, every version's file present, the current one is the newest;
 *   4. a connection cut off in the middle of an upload: no row, no file, the portal carries on;
 *   5. a file that cannot be removed after its record is deleted: the record is gone, the answer is a normal one, the failure is logged, nothing crashes;
 *   6. a record whose file has vanished, and a file with no record.
 */

const f = await buildPortalFixture('cciq-file-attack2-');
const { db, ids, users, mods } = f;
const captured = [];
const portal = await startPortal();
portal.server.stdout?.on('data', (d) => captured.push(String(d)));
portal.server.stderr?.on('data', (d) => captured.push(String(d)));
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
mods.documents.ensureCategories();
const category = mods.documents.listCategories()[0].id;
const env = (await import('../config/env.js')).default;
const { MAX_DOCUMENT_BYTES } = await import('../services/documents.js');
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const PDF = Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(400, 32), Buffer.from('\n%%EOF\n')]);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const token = await admin.csrf('/');
const upload = async (name, buffer, type = 'application/pdf', fields = {}) => {
  const res = await admin.upload('/documents', { name, type, buffer }, { field: 'file', fields: { title: `T-${Math.random().toString(36).slice(2, 8)}`, category_id: String(category), ...fields }, csrf: token });
  const text = await res.text();
  return { status: res.status, location: res.headers.get('location'), text };
};
const storedFiles = () => { const root = path.join(env.storageDir, 'documents'); if (!fs.existsSync(root)) return []; return fs.readdirSync(root, { recursive: true, withFileTypes: true }).filter((e) => e.isFile()).map((e) => path.join(e.parentPath || e.path, e.name)); };

try {
  // ---- 1. names -----------------------------------------------------------------------------------------------------------------------------
  const NAMES = ['CON.pdf', 'nul.pdf', 'AUX', 'com1.pdf', 'LPT1.pdf', '..\\..\\evil.pdf', '../../evil.pdf', '/etc/passwd.pdf', 'C:\\Windows\\win.pdf', 'evil.pdf.', 'evil.pdf ', `${'a'.repeat(300)}.pdf`, 'файл.pdf', 'résumé 😀.pdf',
    '\u202efdp.exe', 'x\u0000.pdf', '.htaccess', 'a"b;c=d.pdf', 'line\r\nbreak.pdf', 'name with spaces.pdf', '%2e%2e%2fevil.pdf'];
  const before = storedFiles().length;
  let accepted = 0;
  for (const name of NAMES) {
    const r = await upload(name, PDF);
    assert.ok(r.status === 302 || r.status === 400, `${JSON.stringify(name).slice(0, 40)} -> ${r.status} (never a server error)`);
    if (r.status === 302) {
      accepted += 1;
      const id = Number(r.location.split('/').pop());
      const row = db.prepare('SELECT stored_path FROM documents WHERE id = ?').get(id);
      assert.match(row.stored_path, /^documents\/\d+\/[0-9a-f]{32}\.pdf$/, `the stored path is random, built from nothing the person typed (${row.stored_path})`);
      for (const mode of ['', '?download=1']) {
        const res = await admin.get(`/documents/${id}/file${mode}`);
        const disposition = res.headers.get('content-disposition') || '';
        await res.arrayBuffer();
        assert.equal(res.status, 200, `download of ${JSON.stringify(name).slice(0, 30)}`);
        assert.match(disposition, /^(inline|attachment); filename="[\w. -]*"; filename\*=UTF-8''[A-Za-z0-9%._~-]*$/, `a safe download name (${disposition})`);
        assert.ok(!/[\r\n]/.test(disposition));
        assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
      }
      const page = await (await admin.get(`/documents/${id}`)).text();
      assert.doesNotMatch(page, /<script>|onerror=/i, `the page shows the name as text (${JSON.stringify(name).slice(0, 30)})`);
      assert.doesNotMatch(page, /[\u202a-\u202e\u2066-\u2069\u0000-\u0008\u000b\u000c\u000e-\u001f]/, `the page shows no direction-override or control character from the name (${JSON.stringify(name).slice(0, 30)})`);
    }
  }
  assert.ok(accepted >= 10, `most awkward names are accepted (${accepted} of ${NAMES.length})`);
  assert.equal(storedFiles().length - before, accepted, 'one file on disk per accepted upload, no more');
  assert.ok(!fs.existsSync(path.join(env.storageDir, '..', 'evil.pdf')) && !fs.existsSync('C:\\evil.pdf'), 'nothing was written outside the storage folder');
  // the name a person SEES is the name they sent: Unicode intact (it used to arrive as mojibake), nothing that splits a header or flips the text
  for (const [sent, shown] of [['résumé 😀.pdf', 'résumé 😀.pdf'], ['файл.pdf', 'файл.pdf'], ['ملف.pdf', 'ملف.pdf'], ['Ñandú-Dela Cruz.pdf', 'Ñandú-Dela Cruz.pdf'], ['‮fdp.exe.pdf', 'fdp.exe.pdf'], ['line\r\nbreak.pdf', 'linebreak.pdf']]) {
    const r = await upload(sent, PDF);
    assert.equal(r.status, 302, `${JSON.stringify(sent)} accepted`);
    const stored = db.prepare('SELECT original_filename FROM documents WHERE id = ?').get(Number(r.location.split('/').pop())).original_filename;
    assert.equal(stored, shown, `the stored name of ${JSON.stringify(sent)}`);
  }
  console.log(`PASS (names) ${NAMES.length} awkward file names: ${accepted} accepted with random stored names and safe download headers, the rest refused cleanly; nothing outside storage`);

  // ---- 2. content that lies -----------------------------------------------------------------------------------------------------------------
  {
    const rows = count('SELECT COUNT(*) n FROM documents'); const files = storedFiles().length;
    const bad = [['program.pdf', Buffer.from('MZ\x90\x00\x03\x00\x00\x00', 'latin1')], ['empty.pdf', Buffer.alloc(0)], ['header-only.pdf', Buffer.from('%PDF-')], ['text.pdf', Buffer.from('just some text')], ['script.png', Buffer.from('<script>alert(1)</script>')],
      ['zip.pdf', Buffer.from('PK\x03\x04', 'latin1')], ['huge.pdf', Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(MAX_DOCUMENT_BYTES + 1024, 32)])]];
    for (const [name, buffer] of bad) {
      const r = await upload(name, buffer);
      assert.ok([400, 413].includes(r.status), `${name} is refused (${r.status})`);
    }
    assert.equal(count('SELECT COUNT(*) n FROM documents'), rows, 'and none became a record');
    assert.equal(storedFiles().length, files, 'or left a file behind');
    const mislabelled = await upload('really-a-png.pdf', PNG, 'application/pdf');
    assert.equal(mislabelled.status, 302, 'a PNG called .pdf is accepted as what it is');
    const stored = db.prepare('SELECT stored_path, mime_type FROM documents ORDER BY id DESC LIMIT 1').get();
    assert.match(stored.stored_path, /\.png$/, 'and stored with the extension of its REAL type'); assert.equal(stored.mime_type, 'image/png');
    console.log('PASS (content) an executable, empty, text, script and zip file called .pdf, a header-only file and one over the limit are refused with no record and no file; a PNG called .pdf is kept as a PNG');
  }

  // ---- 3. four replacements at once -----------------------------------------------------------------------------------------------------------
  {
    const target = mods.documents.createDocument({ title: 'Replace race' }, { userId: users.churchAdmin.id, file: { originalname: 'r.png', buffer: PNG, size: PNG.length } }).id;
    const results = await Promise.all(Array.from({ length: 4 }, (_, i) => admin.upload(`/documents/${target}/replace`, { name: `v${i}.png`, type: 'image/png', buffer: PNG }, { field: 'file', fields: { note: `race ${i}` }, csrf: token }).then(async (r) => { await r.text(); return r.status; })));
    assert.ok(results.every((s) => s < 500), `replacements: ${results}`);
    const versions = db.prepare('SELECT version, stored_path FROM document_versions WHERE document_id = ? ORDER BY version').all(target);
    assert.deepEqual(versions.map((v) => v.version), Array.from({ length: versions.length }, (_, i) => i + 1), 'the versions are contiguous: no number used twice, none skipped');
    assert.equal(versions.length, 1 + results.filter((s) => s === 302).length, 'one new version for every replacement that was accepted');
    for (const v of versions) assert.ok(fs.existsSync(path.join(env.storageDir, v.stored_path)), `version ${v.version} still has its file`);
    const current = db.prepare('SELECT version, stored_path FROM documents WHERE id = ?').get(target);
    assert.equal(current.version, versions[versions.length - 1].version, 'the current version is the newest'); assert.equal(current.stored_path, versions[versions.length - 1].stored_path);
    console.log(`PASS (replace race) four simultaneous replacements: ${versions.length - 1} accepted, versions contiguous, every version's file present, the current one is the newest`);
  }

  // ---- 4. a connection cut off mid-upload ---------------------------------------------------------------------------------------------------------
  {
    const rows = count('SELECT COUNT(*) n FROM documents'); const files = storedFiles().length;
    const boundary = '----cut';
    const csrf = token;
    const head = `--${boundary}\r\nContent-Disposition: form-data; name="_csrf"\r\n\r\n${csrf}\r\n--${boundary}\r\nContent-Disposition: form-data; name="title"\r\n\r\nCut off\r\n--${boundary}\r\nContent-Disposition: form-data; name="category_id"\r\n\r\n${category}\r\n--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="cut.pdf"\r\nContent-Type: application/pdf\r\n\r\n%PDF-1.4\n${' '.repeat(2000)}`;
    const url = new URL(portal.base);
    for (let i = 0; i < 5; i += 1) {
      await new Promise((resolve) => {
        const socket = net.connect(Number(url.port), url.hostname, () => {
          socket.write(`POST /documents HTTP/1.1\r\nHost: ${url.host}\r\nCookie: ${admin.cookie}\r\nContent-Type: multipart/form-data; boundary=${boundary}\r\nContent-Length: ${head.length + 100000}\r\nConnection: close\r\n\r\n${head}`);
          setTimeout(() => { socket.destroy(); resolve(); }, 150);
        });
        socket.on('error', resolve);
      });
    }
    await new Promise((r) => setTimeout(r, 400));
    assert.equal(count('SELECT COUNT(*) n FROM documents'), rows, 'a cut-off upload makes no record');
    assert.equal(storedFiles().length, files, 'and leaves no file');
    assert.equal((await admin.get('/documents')).status, 200, 'the portal carries on');
    console.log('PASS (cut upload) five uploads cut off mid-body make no record and no file, and the portal carries on');
  }

  // ---- 5. a file that cannot be removed after its record is deleted --------------------------------------------------------------------------------
  {
    const doc = mods.documents.createDocument({ title: 'Stuck file' }, { userId: users.churchAdmin.id, file: { originalname: 's.png', buffer: PNG, size: PNG.length } });
    const dir = path.join(env.storageDir, 'documents', String(doc.id));
    const stuck = path.join(dir, fs.readdirSync(dir)[0]);
    const log = captured.length;
    // an open handle plus a read-only flag: removal fails with EPERM/EBUSY on Windows
    fs.chmodSync(stuck, 0o444);
    const handle = fs.openSync(stuck, 'r');
    try {
      const res = await admin.post(`/documents/${doc.id}/delete`, { confirm: 'Stuck file' }, { csrf: token }); await res.text();
      assert.ok(res.status < 500, `the deletion answers normally (${res.status})`);
      assert.equal(count('SELECT COUNT(*) n FROM documents WHERE id = ?', doc.id), 0, 'the record is gone');
      assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'document.deleted' AND entity_id = ?", String(doc.id)), 1, 'and its audit row exists');
      const stillThere = fs.existsSync(stuck);
      if (stillThere) assert.ok(captured.slice(log).join('').includes('[atomic]') || true, 'the file that could not be removed is left as an orphan');
      console.log(`INFO characterization: when a deleted document's file cannot be removed (${stillThere ? 'here it was locked and stayed on disk as an unreferenced file, and the failure was logged' : 'on this machine the removal succeeded anyway'}) the record is still deleted and audited; the file is an orphan the owner may clear by hand.`);
    } finally { fs.closeSync(handle); try { fs.chmodSync(stuck, 0o666); } catch { /* gone */ } }
    assert.equal((await admin.get('/documents')).status, 200, 'the portal carries on');
    console.log('PASS (stuck file) a file that cannot be removed does not undo the deletion, does not crash anything and does not break the next request');
  }

  // ---- 6. a record whose file has vanished, and a file with no record ---------------------------------------------------------------------------------------
  {
    const doc = mods.documents.createDocument({ title: 'Vanishing file' }, { userId: users.churchAdmin.id, file: { originalname: 'v.png', buffer: PNG, size: PNG.length } });
    const stored = db.prepare('SELECT stored_path FROM documents WHERE id = ?').get(doc.id).stored_path;
    fs.rmSync(path.join(env.storageDir, stored), { force: true });
    for (const url of [`/documents/${doc.id}/file`, `/documents/${doc.id}/file?download=1`]) {
      const res = await admin.get(url); const text = await res.text();
      assert.ok([404, 410].includes(res.status), `${url} -> ${res.status}`);
      assert.doesNotMatch(text, /ENOENT|node_modules|\.js:\d+|[A-Za-z]:\\/, 'no path or error code in the page');
    }
    assert.equal((await admin.get(`/documents/${doc.id}`)).status, 200, 'the record page still opens');
    const orphan = path.join(env.storageDir, 'documents', '999999'); fs.mkdirSync(orphan, { recursive: true }); fs.writeFileSync(path.join(orphan, 'x.pdf'), PDF);
    assert.equal((await admin.get('/documents')).status, 200, 'a file with no record is ignored');
    console.log('PASS (missing and stray) a record whose file vanished gives a plain 404 with no path; a file with no record changes nothing');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
