import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

/*
 * Pre-go-live batch, item H. After the production/development cutover the
 * scheduled launcher failed to restart the service with
 *
 *   EEXIST: file already exists, open '...\run-service.pid'
 *
 * because the previous service process had died and left its PID file
 * behind, and the launcher took ownership with a bare exclusive create. The
 * PID recorded was not running, and nothing was listening on the port - the
 * file was simply stale - yet the service stayed down until someone renamed
 * it by hand. The opposite shortcut (delete whatever is there) would start a
 * second instance beside a live one, both writing to the same database.
 *
 * scripts/lib/pid-lock.mjs decides properly: no file -> take it; a live CCIQ
 * service -> refuse; a dead or reused PID -> quarantine the old file (kept as
 * evidence) and take it; anything malformed or unidentifiable -> refuse.
 *
 * Isolated: every scenario uses its own temp directory, real short-lived
 * child processes, and never reads any real PID file or process state.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const { acquirePidLock } = await import(pathToFileURL(path.join(root, 'scripts/lib/pid-lock.mjs')).href);

const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-pid-lock-'));
let counter = 0;
function freshPidFile() {
  counter += 1;
  const dir = path.join(workDir, `case-${counter}`);
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, 'run-service.pid');
}
function quarantined(pidFile) {
  const prefix = `${path.basename(pidFile)}.stale-`;
  return fs.readdirSync(path.dirname(pidFile)).filter((n) => n.startsWith(prefix));
}
function isAlive(pid) {
  try { process.kill(pid, 0); return true; } catch { return false; }
}

const children = [];
// A real, long-lived process whose command line carries the service marker,
// standing in for a live CCIQ supervisor.
function spawnFakeService() {
  const child = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)', 'run-service.mjs'], { stdio: 'ignore', windowsHide: true });
  children.push(child);
  return child;
}
// A real, long-lived process that is NOT the service (a reused PID).
function spawnUnrelated() {
  const child = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], { stdio: 'ignore', windowsHide: true });
  children.push(child);
  return child;
}
function deadPid() {
  const result = spawnSync(process.execPath, ['-e', '0']);
  assert.equal(result.status, 0);
  assert.ok(!isAlive(result.pid), 'sanity: the PID used as "dead" must really not be running');
  return result.pid;
}
// Stand-in for "this launcher's own PID": never a real process here, so the
// scenarios cannot collide with anything running.
const ME = 2_000_001;

try {
  // --- 1. No PID file: taken cleanly, no quarantine. ---
  {
    const pidFile = freshPidFile();
    const lock = acquirePidLock(pidFile, { pid: ME });
    assert.equal(lock.ok, true);
    assert.equal(fs.readFileSync(pidFile, 'utf8'), String(ME));
    assert.equal(quarantined(pidFile).length, 0);
    assert.equal(fs.readdirSync(path.dirname(pidFile)).filter((n) => n.endsWith('.tmp')).length, 0, 'no temp file may be left behind');
    lock.release();
    console.log('PASS (H, no PID file): ownership is taken cleanly and no evidence files are created');
  }

  // --- 2. A live CCIQ service: a duplicate start is refused, file untouched. ---
  {
    const service = spawnFakeService();
    const pidFile = freshPidFile();
    fs.writeFileSync(pidFile, String(service.pid));
    const lock = acquirePidLock(pidFile, { pid: ME });
    assert.equal(lock.ok, false);
    assert.equal(lock.code, 'already_running');
    assert.equal(lock.existingPid, service.pid);
    assert.equal(fs.readFileSync(pidFile, 'utf8'), String(service.pid), 'the live service\'s PID file must be left exactly as it was');
    assert.equal(quarantined(pidFile).length, 0);
    assert.ok(isAlive(service.pid), 'refusing must not disturb the live process');
    console.log('PASS (H, live CCIQ PID): a duplicate start is refused and nothing is touched');
  }

  // --- 3. A stale (dead) PID: quarantined as evidence, start permitted. ---
  {
    const pidFile = freshPidFile();
    const dead = deadPid();
    fs.writeFileSync(pidFile, String(dead));
    const messages = [];
    const lock = acquirePidLock(pidFile, { pid: ME, log: (m) => messages.push(m) });
    assert.equal(lock.ok, true, 'a dead process\'s PID file must not prevent starting - this is the reported incident');
    assert.equal(fs.readFileSync(pidFile, 'utf8'), String(ME), 'the new owner takes the name');
    const evidence = quarantined(pidFile);
    assert.equal(evidence.length, 1, 'the stale file must be kept as evidence, not deleted');
    assert.equal(fs.readFileSync(path.join(path.dirname(pidFile), evidence[0]), 'utf8'), String(dead), 'the evidence is the original content');
    assert.ok(messages.some((m) => m.includes('stale')), 'the recovery is logged');
    lock.release();
    console.log('PASS (H, stale PID): a dead PID\'s file is quarantined as evidence and start-up proceeds');
  }

  // --- 3b. A reused PID: the number is running, but it is not CCIQ. ---
  {
    const other = spawnUnrelated();
    const pidFile = freshPidFile();
    fs.writeFileSync(pidFile, String(other.pid));
    const lock = acquirePidLock(pidFile, { pid: ME });
    assert.equal(lock.ok, true, 'a live but unrelated process (reused PID) must not block the service');
    assert.equal(quarantined(pidFile).length, 1);
    assert.ok(isAlive(other.pid), 'the unrelated process must not be disturbed');
    lock.release();
    console.log('PASS (H, reused PID): a PID reused by an unrelated live process is treated as stale, and that process is left alone');
  }

  // --- 4. Malformed / ambiguous state: refuse, keep the evidence in place. ---
  {
    for (const content of ['', 'abc', '123 456', '0', '-5', '12.5', '1234567890123']) {
      const pidFile = freshPidFile();
      fs.writeFileSync(pidFile, content);
      const lock = acquirePidLock(pidFile, { pid: ME });
      assert.equal(lock.ok, false, `malformed content ${JSON.stringify(content)} must refuse to start`);
      assert.equal(lock.code, 'malformed');
      assert.equal(fs.readFileSync(pidFile, 'utf8'), content, 'a malformed PID file must be left untouched as evidence');
      assert.equal(quarantined(pidFile).length, 0);
    }
    // A process that is running but cannot be identified.
    const pidFile = freshPidFile();
    fs.writeFileSync(pidFile, '424242');
    const lock = acquirePidLock(pidFile, { pid: ME, inspectProcess: () => ({ alive: true, commandLine: null }) });
    assert.equal(lock.ok, false);
    assert.equal(lock.code, 'ambiguous');
    assert.equal(fs.readFileSync(pidFile, 'utf8'), '424242');
    assert.equal(quarantined(pidFile).length, 0);
    console.log('PASS (H, malformed/ambiguous): unreadable or unidentifiable PID state refuses to start rather than risk two instances');
  }

  // --- 5. Normal cleanup: release() removes only its own file. ---
  {
    const pidFile = freshPidFile();
    const lock = acquirePidLock(pidFile, { pid: ME });
    assert.equal(lock.ok, true);
    lock.release();
    assert.equal(fs.existsSync(pidFile), false, 'a normal shutdown removes the PID file');

    const again = acquirePidLock(pidFile, { pid: ME });
    assert.equal(again.ok, true, 'and the next start is completely clean');
    assert.equal(quarantined(pidFile).length, 0);
    // A file that has meanwhile been taken over by someone else is not ours to remove.
    fs.writeFileSync(pidFile, '777777');
    again.release();
    assert.equal(fs.readFileSync(pidFile, 'utf8'), '777777', 'release() must never remove a PID file that names another process');
    console.log('PASS (H, normal cleanup): release removes only its own PID file, and the next start is clean');
  }

  // --- 5b. Structured records: the production launcher writes JSON
  //     ({ pid, token, release }) rather than a bare PID, and identifies the
  //     service more strictly than a filename marker. The same decisions apply. ---
  {
    const record = (pid) => JSON.stringify({ pid, token: 't'.repeat(64), release: 'rel' });

    // Its own content is written, and only that exact content is ever removed.
    const ownFile = freshPidFile();
    const own = record(ME);
    const lock = acquirePidLock(ownFile, { pid: ME, content: own });
    assert.equal(lock.ok, true);
    assert.equal(fs.readFileSync(ownFile, 'utf8'), own);
    fs.writeFileSync(ownFile, record(ME).replace('t'.repeat(64), 'x'.repeat(64)));
    lock.release();
    assert.ok(fs.existsSync(ownFile), 'release() must not remove a record whose content is no longer this owner\'s (same pid, different token)');

    // Stale JSON record: quarantined (name carries the pid, never the JSON), then started.
    const staleFile = freshPidFile();
    const dead = deadPid();
    fs.writeFileSync(staleFile, record(dead));
    const started = acquirePidLock(staleFile, { pid: ME, content: record(ME) });
    assert.equal(started.ok, true);
    const evidence = quarantined(staleFile);
    assert.equal(evidence.length, 1);
    assert.ok(evidence[0].endsWith(`-pid${dead}`), 'the evidence file name carries the pid');
    assert.equal(fs.readFileSync(path.join(path.dirname(staleFile), evidence[0]), 'utf8'), record(dead));
    started.release();

    // Live JSON record: refused with the default marker, and with a stricter identity test.
    const service = spawnFakeService();
    const liveFile = freshPidFile();
    fs.writeFileSync(liveFile, record(service.pid));
    const refused = acquirePidLock(liveFile, { pid: ME, content: record(ME) });
    assert.equal(refused.ok, false);
    assert.equal(refused.code, 'already_running');
    const strictRefused = acquirePidLock(liveFile, { pid: ME, content: record(ME), isService: (cmd) => /run-service\.mjs$/.test(cmd.trim()) });
    assert.equal(strictRefused.code, 'already_running');
    // A live process that does not satisfy the stricter identity test is not "the service".
    const strictStale = acquirePidLock(liveFile, { pid: ME, content: record(ME), isService: (cmd) => /launch\.mjs\s+serve/.test(cmd) });
    assert.equal(strictStale.ok, true, 'a live process that fails the identity test is a reused PID, not the service');
    assert.equal(quarantined(liveFile).length, 1);
    strictStale.release();

    // Malformed JSON shapes refuse and are left untouched.
    for (const content of ['{"pid": "1234"}', '{"pid": 0}', '{"pid": 1.5}', '{"token": "t"}', '[1234]', '{"pid": 1234', 'null', '"1234"']) {
      const file = freshPidFile();
      fs.writeFileSync(file, content);
      const result = acquirePidLock(file, { pid: ME, content: record(ME) });
      assert.equal(result.ok, false, `${content} must be treated as malformed`);
      assert.equal(result.code, 'malformed');
      assert.equal(fs.readFileSync(file, 'utf8'), content);
    }

    // Owner-only permissions on what it writes (a record can carry a control token).
    if (process.platform !== 'win32') {
      const file = freshPidFile();
      acquirePidLock(file, { pid: ME, content: record(ME) });
      assert.equal(fs.statSync(file).mode & 0o777, 0o600);
    }
    console.log('PASS (H, structured records): JSON records follow the same stale/live/reused/malformed decisions, and only the owner\'s exact record is removed');
  }

  // --- 6. Recovering from a stale file must never allow two instances:
  //     two launchers race for the same stale file; exactly one wins and
  //     the other sees it live. ---
  {
    const pidFile = freshPidFile();
    fs.writeFileSync(pidFile, String(deadPid()));
    const script = `
      import(${JSON.stringify(pathToFileURL(path.join(root, 'scripts/lib/pid-lock.mjs')).href)}).then(async ({ acquirePidLock }) => {
        const lock = acquirePidLock(${JSON.stringify(pidFile)});
        console.log('RESULT:' + JSON.stringify({ ok: lock.ok, code: lock.code || null }));
        if (lock.ok) await new Promise((r) => setTimeout(r, 6000));
      });
    `;
    const scriptPath = path.join(path.dirname(pidFile), 'racer.mjs');
    fs.writeFileSync(scriptPath, script);
    // The trailing marker argument makes each racer's command line look like
    // the service to the other, exactly as a real supervisor's would.
    const racers = [0, 1].map(() => spawn(process.execPath, [scriptPath, 'run-service.mjs'], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true }));
    racers.forEach((r) => children.push(r));
    const outputs = racers.map(() => '');
    racers.forEach((r, i) => r.stdout.on('data', (d) => { outputs[i] += d.toString(); }));
    const deadline = Date.now() + 30000;
    while (Date.now() < deadline && outputs.some((o) => !o.includes('RESULT:'))) {
      await new Promise((r) => setTimeout(r, 100));
    }
    const results = outputs.map((o) => JSON.parse(o.match(/RESULT:(.+)/)[1]));
    assert.equal(results.filter((r) => r.ok).length, 1, `exactly one launcher may win a stale file; got ${JSON.stringify(results)}`);
    const loser = results.find((r) => !r.ok);
    assert.equal(loser.code, 'already_running', 'the loser must see the winner as the live service');
    const winnerIndex = results.findIndex((r) => r.ok);
    assert.equal(fs.readFileSync(pidFile, 'utf8'), String(racers[winnerIndex].pid), 'the PID file names the single winner');
    assert.equal(quarantined(pidFile).length, 1, 'the stale file was set aside exactly once');
    racers.forEach((r) => r.kill());
    console.log('PASS (H, no duplicates): two launchers racing on a stale PID file produce exactly one instance');
  }
} finally {
  for (const child of children) {
    try { child.kill(); } catch { /* already gone */ }
  }
  await new Promise((r) => setTimeout(r, 300));
  fs.rmSync(workDir, { recursive: true, force: true });
}

console.log('ALL PASS');
