import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * Reflected and stored input never becomes markup. Every static GET screen is asked for with hostile text in every query name a
 * screen reads; every create/edit form is submitted invalid with hostile text so it re-renders what was typed; hostile text is
 * saved in records and then displayed on the pages that show them. The raw payload must never appear in the HTML (only its escaped
 * form), and a data block must never be terminable by the payload.
 */

const PAYLOADS = [
  '"><svg onload=alert(1)>',
  "'><img src=x onerror=alert(1)>",
  '</script><script>alert(1)</script>',
  '<script>alert(1)</script>',
  'javascript:alert(1)',
  '{{7*7}}<%= 7*7 %>${7*7}'
];
const DANGEROUS = [/<svg onload=alert\(1\)>/, /<img src=x onerror=alert\(1\)>/, /<script>alert\(1\)<\/script>/, /<\/script><script>/];
function assertNoMarkup(body, where) {
  for (const re of DANGEROUS) assert.doesNotMatch(body, re, `${where}: the payload appears as live markup (${re})`);
  assert.doesNotMatch(body, /href="javascript:alert/i, `${where}: no javascript: link was created`);
  assert.ok(!body.includes('{{7*7}}49') && !body.includes('7*7 %>49'), `${where}: template syntax in the payload was not evaluated`);
}

const f = await buildPortalFixture('cciq-xss-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const names = ['q', 'search', 'status', 'state', 'sort', 'direction', 'dir', 'from', 'to', 'date', 'year', 'campaign', 'cell_group_id', 'group', 'type', 'tab', 'section', 'view', 'list', 'action', 'next', 'selected', 'term', 'error', 'message', 'page', 'page_size', 'ministry_id', 'inviter_id', 'congregation', 'include', 'contact', 'statuses_submitted'];
  const routes = catalogue().filter((r) => r.method === 'GET' && !r.path.includes(':') && !/\.(csv|png)$/.test(r.path) && !/pdf|export|card|qr|media|logout/.test(r.path));
  let requests = 0;
  for (const route of routes) {
    for (const payload of PAYLOADS) {
      const qs = names.map((n) => `${n}=${encodeURIComponent(payload)}`).join('&');
      const res = await admin.get(`${route.path}?${qs}`);
      const type = res.headers.get('content-type') || '';
      const body = await res.text();
      requests += 1;
      assert.ok(res.status < 500, `${route.path}: no server error for hostile query values (${res.status})`);
      if (/html/.test(type)) assertNoMarkup(body, `${route.path}?…=${payload.slice(0, 18)}`);
    }
  }
  // and for pages that are reached by id
  const idPages = [`/members/${ids.member.a2}`, `/members/${ids.member.a2}/edit`, `/cell-groups/${ids.groupA}`, `/ministries/${ids.ministry}`, `/family-groups/${ids.family}`, `/announcements/${ids.announcement}`, `/activities/${ids.activity}`, `/documents/${ids.document}`, `/visitors/${ids.visitor}`, `/attendance/sessions/${ids.session}`, `/admin/users/${users.memberA.id}`];
  for (const page of idPages) {
    for (const payload of PAYLOADS) {
      const qs = names.map((n) => `${n}=${encodeURIComponent(payload)}`).join('&');
      const res = await admin.get(`${page}?${qs}`);
      const body = await res.text();
      requests += 1;
      assert.ok(res.status < 500, `${page}: no server error (${res.status})`);
      assertNoMarkup(body, `${page}?…`);
    }
  }
  console.log(`PASS (reflected) ${requests} requests: hostile text in ${names.length} query names on ${routes.length} screens and ${idPages.length} record pages never appears as markup`);

  // ---- forms re-rendered after a validation error ---------------------------------------------------------------------------------------
  const token = await admin.csrf('/');
  const forms = [
    ['/members', { first_name: '', last_name: '', notes: '', phone: '', email: '', address: '', spouse_name: '', father_name: '', mother_name: '', company: '', occupation: '' }],
    ['/visitors', { first_name: '', last_name: '', how_heard: '', notes: '', invited_by_name: '', phone: '', email: '', congregation: '' }],
    ['/announcements', { title: '', body: '', audience: 'all' }],
    ['/activities', { title: '', description: '', location: '', scope: 'church' }],
    ['/cell-groups', { name: '', description: '', meeting_location: '' }],
    ['/ministries', { name: '', description: '', meets: '', contact: '' }],
    ['/family-groups', { name: '' }],
    ['/admin/users', { email: '', display_name: '', username: '' }],
    ['/admin/ecaq/campaigns', { name: '', description: '', year: 'zzz' }]
  ];
  for (const [url, fields] of forms) {
    for (const payload of PAYLOADS) {
      const filled = Object.fromEntries(Object.keys(fields).map((k) => [k, k === 'year' ? fields[k] : payload]));
      filled.email = 'not-an-email'; // make the form invalid so it is shown again with what was typed
      const res = await admin.post(url, filled, { csrf: token });
      const body = await res.text();
      assert.ok(res.status < 500, `${url}: hostile form values are not a server error (${res.status})`);
      assertNoMarkup(body, `${url} re-render`);
    }
  }
  console.log(`PASS (forms) ${forms.length} forms re-displayed with hostile text in every field never echo live markup`);

  // ---- stored, then displayed -------------------------------------------------------------------------------------------------------------
  const evil = '"><svg onload=alert(1)> <script>alert(1)</script>';
  const member = mods.members.createMember({ first_name: evil, last_name: evil, notes: evil, address: evil, company: evil, occupation: evil }, { status: 'active' });
  mods.announcements.createAnnouncement({ title: evil, body: evil, audience: 'all', status: 'published' }, { userId: users.churchAdmin.id });
  mods.activities.createActivity({ scope: 'church', title: evil, description: evil, location: evil, status: 'published' }, { userId: users.churchAdmin.id });
  mods.ministries.createMinistry({ name: evil, description: evil });
  mods.family.createFamilyGroup({ name: evil });
  mods.groups.createGroup({ name: evil, description: evil, meeting_day: 'Tuesday' });
  mods.visitors.createVisitor({ first_name: evil, last_name: evil, notes: evil, first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
  db.prepare("INSERT INTO reminders (reminder_type, title, detail, state, dedupe_key, created_at, updated_at) VALUES ('manual', ?, ?, 'new', 'xss-rem', ?, ?)").run(evil, evil, new Date().toISOString(), new Date().toISOString());
  db.prepare("INSERT INTO audit_logs (action, detail, result, created_at, actor_label) VALUES (?, ?, 'success', ?, ?)").run(evil, evil, new Date().toISOString(), evil);
  const memberId = member.id ?? member;
  const display = ['/', '/members', `/members/${memberId}`, `/members/${memberId}/edit`, '/announcements', '/activities', '/ministries', '/family-groups', '/cell-groups', '/visitors', '/visitors/follow-up', '/reminders', '/admin/audit', '/search?q=svg', '/calendar', '/ministries/serving', '/members/birthdays', '/attendance/checkin?q=svg', '/kiosk?q=svg', '/admin/users', '/reports', '/about'];
  for (const page of display) {
    const res = await admin.get(page);
    const body = await res.text();
    assert.ok(res.status < 500, `${page} shows stored hostile text without error`);
    assertNoMarkup(body, `${page} (stored text)`);
  }
  const id = db.prepare("SELECT id FROM ministries WHERE name LIKE '%svg%'").get().id;
  for (const page of [`/ministries/${id}`, `/cell-groups/${db.prepare("SELECT id FROM cell_groups WHERE name LIKE '%svg%'").get().id}`, `/family-groups/${db.prepare("SELECT id FROM family_groups WHERE name LIKE '%svg%'").get().id}`, `/visitors/${db.prepare("SELECT id FROM visitors WHERE first_name LIKE '%svg%'").get().id}`, `/announcements/${db.prepare("SELECT id FROM announcements WHERE title LIKE '%svg%'").get().id}`, `/activities/${db.prepare("SELECT id FROM activities WHERE title LIKE '%svg%'").get().id}`]) {
    const res = await admin.get(page);
    const body = await res.text();
    assert.ok(res.status < 500, `${page} opens`);
    assertNoMarkup(body, `${page} (stored text)`);
  }
  // the JSON data block on the attendance register cannot be closed early by a stored name
  const register = await (await admin.get(`/attendance/sessions/${ids.session}`)).text();
  assertNoMarkup(register, 'attendance register');
  console.log(`PASS (stored) hostile text saved in ${9} kinds of record is shown escaped on ${display.length + 6} pages`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
