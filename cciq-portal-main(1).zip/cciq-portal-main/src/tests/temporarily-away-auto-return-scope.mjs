import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness, R05 from the red-team review, across two passes.
 *
 * First pass: maybeReturnFromTemporarilyAway() fired for *any* Friday
 * Service session marked present, including a historical one reached by an
 * admin backfilling a forgotten record weeks later - fixed by gating on a
 * "current operational Friday" definition at every call site.
 *
 * Second pass (independent/Codex verification) reproduced two further
 * gaps in that definition itself:
 *   - a member who went Temporarily Away partway through the still-current
 *     operational week could be wrongly restored by a Present confirmed for
 *     an *earlier* session within that same window (before the member left)
 *     - fixed by requiring the confirmed session's date to be on or after
 *     the member's most recent transition into Temporarily Away;
 *   - cancelling the current week's Friday caused an unlimited fallback to
 *     whatever older non-cancelled Friday still existed in the table,
 *     which could then satisfy auto-return - fixed by
 *     isOperationalFridaySession(), a bounded predicate (this week's actual
 *     calendar Friday, or nothing - never an older week) used in place of
 *     the unbounded getLatestFridayService() fallback for this purpose.
 *
 * Third pass (independent/Codex verification): the transition-order check
 * above compared service_date (a Qatar-calendar date string) against
 * member_status_history.changed_at by slicing the raw UTC ISO string -
 * Qatar is UTC+3 with no DST, so anything from roughly 21:00 UTC onward
 * already belongs to the next day in Qatar. A transition stamped just after
 * midnight Qatar time therefore compared as same-or-earlier than the Friday
 * it actually followed, letting that Friday's own attendance wrongly
 * auto-return the member. Fixed with qatarDateOf() (lib/dates.js), which
 * converts through the same Qatar calendar service_date itself is generated
 * in, rather than slicing the ISO string. Also added: equal Qatar-calendar
 * dates are no longer read as "attendance came after the transition" -
 * service_date carries no time of day, so equal dates alone cannot order the
 * two events, and are now flagged for manual review instead of guessed at.
 */

const env = createIsolatedTestEnv('cciq-temp-away-scope-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember, getMember, changeStatus } = await import('../services/members.js');
const {
  createSession, recordAttendance, recordAttendanceForPeople, setSessionStatus
} = await import('../services/attendance.js');
const { confirmCheckin } = await import('../services/qr-checkin.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

// "Current" is bounded to the actual calendar Friday on or before today, not
// just "dated today" - a real production Friday Service session is always
// generated with its service_date aligned to a genuine Friday, and
// isOperationalFridaySession() now requires that same alignment.
const currentFridayDate = lastFridayOnOrBefore(today());
const currentSession = createSession({ service_date: currentFridayDate, service_type: 'friday_service', title: 'Current' });
const historicalSession = createSession({ service_date: addDays(currentFridayDate, -21), service_type: 'friday_service', title: 'Three weeks ago' });

/**
 * `awayDate` backdates the member_status_history row's own changed_at (the
 * public changeStatus() API always stamps "now") so a test can represent
 * "went away well before this week's Friday" — the ordinary case a
 * successful auto-return actually requires, per the new transition-order
 * check. Defaults well before currentFridayDate for that reason; the one
 * "stale evidence" test below explicitly passes a date AFTER it instead.
 */
function makeAwayMember(previousStatus = 'active', awayDate = addDays(currentFridayDate, -7)) {
  const member = createMember({ first_name: 'Away', last_name: `Fixture${Math.random()}` }, { status: previousStatus });
  changeStatus(member.id, 'temporarily_away', { reason: 'test setup' });
  db.prepare(
    "UPDATE member_status_history SET changed_at = ? WHERE member_id = ? AND new_status = 'temporarily_away'"
  ).run(`${awayDate}T00:00:00.000Z`, member.id);
  return getMember(member.id);
}

// --- 1. A CURRENT Friday Present DOES auto-return. ---
{
  const member = makeAwayMember('active');
  recordAttendance(currentSession.id, [{ memberId: member.id, status: 'present' }], {});
  const after = getMember(member.id);
  assert.equal(after.status, 'active', 'a current Friday Present must auto-return an Active-before member');
  console.log('PASS: a current Friday Present auto-returns a Temporarily Away member');
}

// --- 2. A HISTORICAL Friday Present does NOT auto-return (via /records path, recordAttendance()). ---
{
  const member = makeAwayMember('active');
  recordAttendance(historicalSession.id, [{ memberId: member.id, status: 'present' }], {});
  const after = getMember(member.id);
  assert.equal(after.status, 'temporarily_away', 'R05 CONFIRMED FIXED: a historical Friday Present must NOT auto-return');
  console.log('PASS: a historical Friday Present (recordAttendance) does not auto-return');
}

// --- 3. Same historical check via recordAttendanceForPeople() (the /add route's path). ---
{
  const member = makeAwayMember('active');
  recordAttendanceForPeople(historicalSession.id, [{ type: 'member', id: member.id }], { status: 'present' });
  const after = getMember(member.id);
  assert.equal(after.status, 'temporarily_away', 'R05 CONFIRMED FIXED: a historical Friday Present via recordAttendanceForPeople must NOT auto-return');
  console.log('PASS: a historical Friday Present (recordAttendanceForPeople) does not auto-return');
}

// --- 3b. The current session still works via recordAttendanceForPeople() too. ---
{
  const member = makeAwayMember('bonafide');
  recordAttendanceForPeople(currentSession.id, [{ type: 'member', id: member.id }], { status: 'present' });
  const after = getMember(member.id);
  assert.equal(after.status, 'bonafide', 'a current Friday Present via recordAttendanceForPeople must still auto-return');
  console.log('PASS: a current Friday Present (recordAttendanceForPeople) still auto-returns');
}

// --- 4. Vacation/Absent/Not Recorded never auto-return, even on the current session. ---
{
  for (const status of ['absent', 'excused']) {
    const member = makeAwayMember('active');
    recordAttendance(currentSession.id, [{ memberId: member.id, status }], {});
    const after = getMember(member.id);
    assert.equal(after.status, 'temporarily_away', `a "${status}" record on the current session must not auto-return`);
  }
  // "Not Recorded" is represented by clearing the record entirely (an
  // unrecognized/absent-from-ATTENDANCE_STATUSES value deletes the row).
  const member = makeAwayMember('active');
  recordAttendance(currentSession.id, [{ memberId: member.id, status: 'not_recorded' }], {});
  assert.equal(getMember(member.id).status, 'temporarily_away', 'clearing a record (Not Recorded) must not auto-return');
  console.log('PASS: Vacation/Absent/Not Recorded never auto-return, even on the current session');
}

// --- 5. Ambiguous prior-status handling is unaffected by the date gate (still safe on the current session). ---
{
  const member = makeAwayMember('inactive'); // 'inactive' is not in DEFAULT_ROSTER_STATUSES
  recordAttendance(currentSession.id, [{ memberId: member.id, status: 'present' }], {});
  const after = getMember(member.id);
  assert.equal(after.status, 'temporarily_away', 'an ambiguous previous status must leave the member Temporarily Away, not guess');
  const audit = db.prepare(
    "SELECT * FROM audit_logs WHERE action = 'member.temporarily_away_return_ambiguous' AND entity_id = ? ORDER BY id DESC LIMIT 1"
  ).get(String(member.id));
  assert.ok(audit, 'the ambiguous case must still record its audit entry');
  console.log('PASS: ambiguous prior-status handling remains safe and unaffected by the date gate');
}

// --- 6. QR/confirmCheckin: current session auto-returns; a stale/historical session id does not. ---
{
  const memberCurrent = makeAwayMember('active');
  confirmCheckin(memberCurrent.id, currentSession.id, {});
  assert.equal(getMember(memberCurrent.id).status, 'active', 'a QR confirm against the current session must auto-return');

  const memberStale = makeAwayMember('active');
  confirmCheckin(memberStale.id, historicalSession.id, {});
  assert.equal(getMember(memberStale.id).status, 'temporarily_away',
    'R05 CONFIRMED FIXED: a QR confirm carrying a stale/historical session id must NOT auto-return');
  console.log('PASS: QR check-in confirmation auto-returns for the current session, not for a stale/historical session id');
}

// --- 7. Transition-order: a member who went away AFTER the current
//     session's date must NOT be restored by confirming that (now stale)
//     session, even though it is still the operational current Friday. ---
{
  const member = makeAwayMember('active', addDays(currentFridayDate, 2)); // went away 2 days after this Friday
  recordAttendance(currentSession.id, [{ memberId: member.id, status: 'present' }], {});
  assert.equal(getMember(member.id).status, 'temporarily_away',
    'CODEX FINDING CONFIRMED FIXED: a Present confirmed for a session dated before the member\'s most recent departure must not restore them');
  console.log('PASS: a current-session Present dated before the member\'s most recent Temporarily Away transition does not auto-return');
}

// --- 8. Bounded fallback: if THIS WEEK's Friday is cancelled, nothing is
//     "operational" - not even an older, non-cancelled Friday still sitting
//     in the table. No unlimited "latest non-cancelled Friday ever" fallback. ---
{
  setSessionStatus(currentSession.id, 'cancelled');
  const olderNonCancelled = createSession({
    service_date: addDays(currentFridayDate, -35), service_type: 'friday_service', title: 'Old but not cancelled'
  });

  const member = makeAwayMember('active');
  // The write itself is a perfectly ordinary historical correction and must
  // still succeed - assertSessionMutable() only cares about cancellation/
  // future-dating of THIS session, not about operational-Friday status.
  // What must NOT happen is the auto-return side effect.
  const viaOlder = recordAttendance(olderNonCancelled.id, [{ memberId: member.id, status: 'present' }], {});
  assert.equal(viaOlder.ok, true, 'recording attendance against an old, valid session must still work normally');
  assert.equal(getMember(member.id).status, 'temporarily_away',
    'CODEX FINDING CONFIRMED FIXED: cancelling the current Friday must not cause fallback to an older Friday for auto-return purposes');

  const confirmResult = confirmCheckin(member.id, olderNonCancelled.id, {});
  assert.equal(confirmResult.ok, false, 'confirmCheckin() must also refuse the older session rather than falling back to it');
  console.log('PASS: cancelling this week\'s Friday does not cause an unbounded fallback to an older, non-cancelled Friday');

  // Restore, since later tests below reuse currentSession as "the" operational Friday.
  setSessionStatus(currentSession.id, 'scheduled');
}

// --- 9. Codex/independent verification (R05): the transition-order check
//     compared service_date (a Qatar-calendar date string) against
//     member_status_history.changed_at sliced as a raw UTC string - Qatar is
//     UTC+3 with no DST, so a change from roughly 21:00 UTC onward already
//     falls on the NEXT Qatar day. A member marked Temporarily Away at
//     21:30 UTC on the Friday itself (00:30 Saturday in Qatar) had this
//     compared as "same UTC date as the Friday", never flagged as stale,
//     and would be wrongly restored by that same Friday's own attendance
//     even though the member left AFTER it. ---
{
  const member = createMember({ first_name: 'Away', last_name: `QatarTz${Math.random()}` }, { status: 'active' });
  changeStatus(member.id, 'temporarily_away', { reason: 'test setup' });
  db.prepare(
    "UPDATE member_status_history SET changed_at = ? WHERE member_id = ? AND new_status = 'temporarily_away'"
  ).run(`${currentFridayDate}T21:30:00.000Z`, member.id); // 00:30 Saturday in Qatar (UTC+3)

  recordAttendance(currentSession.id, [{ memberId: member.id, status: 'present' }], {});
  assert.equal(getMember(member.id).status, 'temporarily_away',
    'CODEX FINDING CONFIRMED FIXED: a UTC timestamp that rolls into the next Qatar calendar day must not be read as same-day-or-earlier than the Friday it actually followed');
  console.log('PASS: a Temporarily Away transition just after midnight Qatar time is correctly treated as AFTER that Friday, not same-day');
}

// --- 10. Codex/independent verification (R05): even with the Qatar
//     conversion fixed, a transition landing on the exact SAME Qatar
//     calendar day as the session gives no way to tell, from dates alone,
//     whether the service happened before or after it. Equal dates must not
//     be read as "attendance came after the transition" - flagged for
//     review instead of silently auto-returning or silently doing nothing. ---
{
  const member = createMember({ first_name: 'Away', last_name: `SameDay${Math.random()}` }, { status: 'active' });
  changeStatus(member.id, 'temporarily_away', { reason: 'test setup' });
  db.prepare(
    "UPDATE member_status_history SET changed_at = ? WHERE member_id = ? AND new_status = 'temporarily_away'"
  ).run(`${currentFridayDate}T08:00:00.000Z`, member.id); // 11:00 Qatar, same calendar day as the Friday session

  const result = recordAttendance(currentSession.id, [{ memberId: member.id, status: 'present' }], {});
  assert.equal(result.ok, true, 'recording the attendance itself must still succeed regardless of the ambiguous auto-return outcome');
  assert.equal(getMember(member.id).status, 'temporarily_away',
    'CODEX FINDING CONFIRMED FIXED: a same-Qatar-calendar-day transition and session must not be auto-returned merely because the dates are equal');
  const audit = db.prepare(
    "SELECT * FROM audit_logs WHERE action = 'member.temporarily_away_return_ambiguous' AND entity_id = ? ORDER BY id DESC LIMIT 1"
  ).get(String(member.id));
  assert.ok(audit, 'the same-day-ambiguous case must be flagged for review, not silently ignored');
  console.log('PASS: a Temporarily Away transition on the same Qatar calendar day as the session is flagged for review, not auto-returned');
}

db.close();
env.cleanup();
console.log('ALL PASS');
