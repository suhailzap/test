import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Every printable report: a real PDF (header, trailer, pages), sensible headers, the same permission as its screen, tolerance of
 * hostile and non-Latin names, empty data, bad query values, and a very large directory - never a 500 and never a half-written file.
 */

const f = await buildPortalFixture('cciq-pdf-');
const { db, ids, users, mods } = f;
const KEYS = ['attendance', 'directory', 'occasions', 'cell-groups', 'giving', 'first-timers', 'faith-promise', 'long-absence'];

// names that stress a PDF font: accents, Arabic, emoji, very long, formula and markup text
const odd = [['Zoë', 'Ünïcödé'], ['أحمد', 'محمد'], ['😀Smile', 'Faces😀'], ['Long', 'L'.repeat(300)], ['=1+1', '@cmd'], ['<b>Tag</b>', '</script>'], ['Tab\tName', 'Line\nBreak'], ['中文', '名字']];
for (const [first, last] of odd) mods.members.createMember({ first_name: first, last_name: last, phone: '+974 5550 9999', date_of_birth: '1990-01-01' }, { status: 'active' });
mods.visitors.createVisitor({ first_name: 'مسافر', last_name: 'Visitor😀', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);

  async function pdf(session, url) {
    const res = await session.get(url);
    const bytes = Buffer.from(await res.arrayBuffer());
    return { res, bytes, text: bytes.toString('latin1') };
  }
  function assertPdf({ res, bytes, text }, what) {
    assert.equal(res.status, 200, `${what}: 200 (got ${res.status})`);
    assert.match(res.headers.get('content-type'), /^application\/pdf/, `${what}: served as a PDF`);
    assert.match(res.headers.get('content-disposition'), /^inline; filename="cciq-[\w-]+-\d{4}-\d{2}-\d{2}\.pdf"$/, `${what}: a safe, dated file name`);
    assert.ok(text.startsWith('%PDF-1.'), `${what}: begins with the PDF header`);
    assert.ok(/%%EOF\s*$/.test(text), `${what}: ends with the PDF trailer (the file is complete)`);
    const pages = (text.match(/\/Type\s*\/Page\b(?!s)/g) || []).length;
    assert.ok(pages >= 1, `${what}: has at least one page`);
    assert.ok(bytes.length > 1500, `${what}: is not an empty shell (${bytes.length} bytes)`);
    assert.match(text, /\/Title\s+(\d+ 0 R|[(<])/, `${what}: carries a title`);
    return pages;
  }

  const summary = [];
  for (const key of KEYS) {
    const extra = key === 'directory' ? '?statuses_submitted=1&status=active&contact=yes' : key === 'giving' ? `?campaign=${ids.board}` : key === 'faith-promise' ? `?campaign=${ids.promise}` : '';
    const out = await pdf(admin, `/reports/${key}/pdf${extra}`);
    const pages = assertPdf(out, key);
    summary.push(`${key}:${pages}p`);
  }
  console.log(`PASS (structure) all ${KEYS.length} reports are complete PDFs, including hostile and non-Latin names (${summary.join(' ')})`);

  // bad query values fall back, never error
  for (const url of ['/reports/attendance/pdf?from=garbage&to=2026-99-99', '/reports/attendance/pdf?from=2030-01-01&to=2020-01-01', '/reports/attendance/pdf?cell_group_id=abc', '/reports/attendance/pdf?cell_group_id=99999999',
    '/reports/directory/pdf?statuses_submitted=1&status=nonsense&congregation=zzz', '/reports/occasions/pdf?from=2026-02-30&include=x&status=x', '/reports/cell-groups/pdf?cell_group_id=1&cell_group_id=zzz',
    '/reports/first-timers/pdf?state=zzz&inviter_id=-5', '/reports/giving/pdf?campaign=zzz', '/reports/giving/pdf?campaign=all', '/reports/long-absence/pdf?sort=zzz&dir=zzz', '/reports/faith-promise/pdf?status=zzz']) {
    const out = await pdf(admin, url);
    assert.ok(out.res.status === 200 || out.res.status === 404, `${url} answers 200 or 404, not ${out.res.status}`);
    if (out.res.status === 200) assertPdf(out, url);
  }
  assert.equal((await pdf(admin, '/reports/nonsense/pdf')).res.status, 404, 'an unknown report is a 404');
  console.log('PASS (queries) bad dates, ids, statuses and sort keys fall back to defaults; an unknown report is a 404');

  // permissions
  for (const key of KEYS) {
    const denied = await pdf(member, `/reports/${key}/pdf`);
    assert.ok(denied.res.status === 403 || denied.res.status === 302, `${key}: a Member is refused (${denied.res.status})`);
    assert.ok(!denied.text.startsWith('%PDF'), `${key}: and gets no PDF`);
  }
  const anon = await fetch(`${portal.base}/reports/directory/pdf`, { redirect: 'manual' });
  assert.equal(anon.status, 302, 'signed out: sent to sign in');
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const leaderGiving = await pdf(leader, `/reports/giving/pdf?campaign=${ids.board}`);
  assert.equal(leaderGiving.res.status, 403, 'a leader cannot print the Giving statement');
  const leaderDirectory = await pdf(leader, '/reports/directory/pdf?statuses_submitted=1&status=active&contact=yes');
  assert.equal(leaderDirectory.res.status, 403, 'printing needs reports.view, which a leader does not hold');
  console.log('PASS (permissions) each report needs the permission its screen needs; signed out is sent to sign in');

  // very large directory
  const insert = db.prepare("INSERT INTO members (member_code, first_name, last_name, status, phone, created_at, updated_at) VALUES (?, ?, ?, 'active', ?, ?, ?)");
  const now = new Date().toISOString();
  db.transaction(() => { for (let i = 0; i < 5200; i += 1) insert.run(`CCIQ-P${String(i).padStart(5, '0')}`, `Bulk${i}`, `Person${i % 97}`, `+974 5000 ${String(i).padStart(4, '0')}`, now, now); })();
  const started = Date.now();
  const big = await pdf(admin, '/reports/directory/pdf?statuses_submitted=1&status=active&contact=yes');
  const pages = assertPdf(big, 'large directory');
  const seconds = (Date.now() - started) / 1000;
  assert.ok(pages > 100, `a 5,200-member directory runs to many pages (${pages})`);
  assert.ok(seconds < 90, `and is produced in a reasonable time (${seconds.toFixed(1)}s)`);
  console.log(`PASS (large) a 5,200-member directory is one complete ${pages}-page PDF in ${seconds.toFixed(1)}s`);

  // empty data
  db.exec('DELETE FROM visitor_visits; DELETE FROM visitors;');
  assertPdf(await pdf(admin, '/reports/first-timers/pdf'), 'first timers with none recorded');
  assertPdf(await pdf(admin, '/reports/long-absence/pdf'), 'long absence with none');
  console.log('PASS (empty) reports with nothing to list are still complete PDFs');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
