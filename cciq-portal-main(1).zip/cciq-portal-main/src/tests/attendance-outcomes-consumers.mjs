import assert from 'node:assert/strict';
import net from 'node:net';
import path from 'node:path';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Attendance Go-Live & Finalization, Phase 2C: every consumer of tracked-Friday
 * attendance speaks ONE canonical model (attendance-outcomes.js): tracking start
 * date + session lifecycle + the historical expected snapshot + the attendance
 * row + cancellation. This suite covers the resolver, the rate, the
 * consecutive-absence traversal (including the barrier), the follow-up list,
 * stored-reminder reconciliation, Long Absence, member history, the register
 * and landing figures, reports (screen, CSV, PDF), non-Friday semantics, the
 * Temporarily Away rule and legacy physical Absent rows.
 *
 * Disposable fixtures only. No real Go-Live date is ever set.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-attendance-consumers-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting, getSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember, changeStatus } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createGroup, assignMemberToGroup } = await import('../services/cell-groups.js');
const { createVisitor } = await import('../services/visitors.js');
const tracking = await import('../services/attendance-tracking.js');
const outcomes = await import('../services/attendance-outcomes.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const reminders = await import('../services/reminders.js'); // registers the lifecycle hook
const reports = await import('../services/reports.js');
const pdfs = await import('../services/reports-pdf.js');
const congregations = await import('../services/congregations.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

const SERVICE = lastFridayOnOrBefore(today()); // the current operational Friday
const W = (n) => addDays(SERVICE, 7 * n);       // W(0) = this Friday, W(-1) = last Friday, ...
const oldDate = addDays(SERVICE, -300);
const atNoon = (date, hour = 9) => `${date}T${String(hour).padStart(2, '0')}:00:00.000Z`;

const people = new Map();
function member(name, status = 'active') {
  if (!people.has(name)) people.set(name, createMember({ first_name: name, last_name: 'Cons' }, { status }));
  return people.get(name);
}
const id = (name) => member(name).id;

function plantOne(m, { status, changes = [] }) {
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = NULL WHERE id = ?').run(atNoon(oldDate), m.id);
  const insert = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
  insert.run(m.id, null, status, 'planted', atNoon(oldDate));
  let current = status;
  for (const change of changes) {
    insert.run(m.id, current, change.status, 'planted', change.at);
    current = change.status;
  }
  db.prepare('UPDATE members SET status = ? WHERE id = ?').run(current, m.id);
}

/** Everyone not named is archived (never expected). `spec` values: 'active' | { status, changes }. */
function population(spec) {
  for (const name of Object.keys(spec)) member(name);
  for (const [name, m] of people) {
    const entry = spec[name];
    plantOne(m, entry === undefined ? { status: 'archived' } : (typeof entry === 'string' ? { status: entry } : entry));
  }
}

let sessions = new Map();
const insertSession = db.prepare(
  `INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at)
   VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, 0, @at)`
);
function resetWorld({ goLive, weeks }) {
  db.exec(`DELETE FROM reminders; DELETE FROM qr_checkins; DELETE FROM visitor_visits;
           DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions;`);
  setSetting('attendance.tracking_start_date', goLive);
  sessions = new Map();
  for (const n of weeks) {
    insertSession.run({ date: W(n), at: atNoon(W(n)) });
    sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
  }
}
const range = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => from + i);
const S = (n) => sessions.get(n);
const fresh = (n) => db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(S(n).id);
const mark = (name, n, status) => db.prepare(
  "INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, ?, ?, 'manual')"
).run(S(n).id, id(name), status, atNoon(W(n), 11));
function fin(n) {
  const result = lifecycle.finalizeAttendance(S(n).id, { userId: null, confirmNoAttendance: true });
  assert.equal(result.ok, true, `finalize W(${n}) -> ${result.reason}`);
  return result;
}
const finAll = (...ns) => ns.forEach(fin);
/** Adds a Friday to the current world (Fridays are settled chronologically, oldest first, in real use). */
function addWeek(n) {
  insertSession.run({ date: W(n), at: atNoon(W(n)) });
  sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
}
const ctxAt = (n) => outcomes.buildFridayContexts({ from: W(n), to: W(n) }).find((c) => c.id === S(n).id);
const at = (name, n) => outcomes.memberOutcomeAt(ctxAt(n), id(name));
const streakOf = (name) => attendance.consecutiveMissedFridays(id(name));
const openReminders = (name) => db.prepare(
  "SELECT * FROM reminders WHERE member_id = ? AND reminder_type = 'attendance_followup' AND state IN ('new','acknowledged') ORDER BY id"
).all(id(name));
const allReminders = (name) => db.prepare("SELECT * FROM reminders WHERE member_id = ? AND reminder_type = 'attendance_followup' ORDER BY id").all(id(name));
const audits = (action) => db.prepare('SELECT * FROM audit_logs WHERE action = ? ORDER BY id').all(action);
const physicalAbsentRows = () => db.prepare("SELECT COUNT(*) AS n FROM attendance_records WHERE status = 'absent'").get().n;
const recordCount = () => db.prepare('SELECT COUNT(*) AS n FROM attendance_records').get().n;

// ===========================================================================
// 1-8. TRACKING / LIFECYCLE
// ===========================================================================

// 1. Tracking unset -> nothing is tracked, nothing is absent.
{
  population({ Alpha: 'active', Beta: 'active' });
  resetWorld({ goLive: '', weeks: range(-6, 0) });
  mark('Beta', -3, 'present');
  assert.equal(tracking.isTrackingConfigured(), false);
  assert.equal(at('Alpha', -3).state, 'not_tracked', 'ITEM 1: a missing row with tracking unset is Not Tracked, not Absent');
  assert.equal(at('Alpha', -3).followUp, 'outside');
  assert.equal(streakOf('Alpha').streak, 0, 'ITEM 1: no tracked absence');
  assert.deepEqual(attendance.followUpList({ limit: 100 }), [], 'ITEM 1: follow-up is empty until tracking has started');
  assert.equal(attendance.followUpStatus().configured, false);
  assert.equal(attendance.longAbsenceReview().status, 'not_started');
  const summary = attendance.sessionSummary(S(-3).id);
  assert.equal(summary.tracked, null);
  assert.equal(summary.notRecorded, null, 'a Friday that is not tracked has no "not recorded" figure');
  assert.equal(summary.rate, null);
  assert.equal(summary.figures.absent, 0, 'only the recorded facts are shown');
  assert.equal(summary.figures.register, 'Not tracked');
  assert.equal(at('Beta', -3).state, 'present', 'a recorded historical row is still shown as recorded');
  const report = attendance.attendanceReport({ from: W(-6), to: W(0) });
  assert.equal(report.lifecycle.beforeTracking, 7);
  assert.ok(report.rows.every((r) => r.eligible === 0 && r.absent === 0 && r.rate === null), 'no absence and no rate without tracking');
  assert.equal(report.rows.find((r) => r.member.id === id('Beta')).historical.attended, 1, 'history is kept, labelled not tracked');
  assert.equal(pendingNone(), true);
  function pendingNone() { return attendance.pendingFridayServices({ weeks: 12 }).total === 0 && attendance.attendanceOverview().awaiting.length === 0; }
  console.log('PASS (1) tracking unset: Not Tracked everywhere - no absence, no follow-up, no rate, no "pending" nag');
}

// 2-8. One world containing every lifecycle phase.
//   W(-6), W(-5) before Go-Live | W(-4) finalized | W(-3) cancelled | W(-2) not taken | W(-1) awaiting | W(0) open
const G1 = W(-4);
population({
  Alpha: 'active', Beta: 'active', Xray: 'inactive',
  NotExpAt4: { status: 'inactive', changes: [{ at: atNoon(addDays(W(-4), 3)), status: 'active' }] }
});
resetWorld({ goLive: G1, weeks: range(-6, 0) });
mark('Beta', -6, 'present'); mark('Beta', -4, 'present'); mark('Xray', -4, 'present');
mark('Beta', -3, 'present'); mark('Beta', -2, 'present');
fin(-4);
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-3).id);
assert.equal(lifecycle.markAttendanceNotTaken(S(-2).id, { userId: null, note: 'Sheet lost', confirmExistingAttendance: true }).ok, true);
// -1: awaiting (past, not finalized); 0: open (current)

{
  const tl = outcomes.memberTimeline(id('Alpha'), outcomes.buildFridayContexts({ from: W(-6), to: W(0) }).reverse());
  const state = (n) => tl.find((t) => t.sessionId === S(n).id);
  assert.equal(state(-6).state, 'not_tracked', 'ITEM 2: pre-go-live missing row -> Not Tracked');
  assert.equal(state(-5).followUp, 'outside', 'ITEM 2: no absence consequence');
  assert.equal(state(0).state, 'pending', 'ITEM 3: open Friday, expected, no row -> Pending (Not checked in)');
  assert.equal(state(0).followUp, 'skip');
  assert.notEqual(state(0).state, 'absent');
  assert.equal(state(-1).state, 'awaiting_finalization', 'ITEM 4: past, unfinalized, expected, no row -> Awaiting finalization');
  assert.equal(state(-1).followUp, 'barrier', 'ITEM 4: and it is a barrier');
  assert.equal(state(-4).state, 'absent', 'ITEM 5: finalized, expected, no row -> Absent');
  assert.equal(state(-4).derived, true, 'ITEM 5: ...derived');
  assert.equal(state(-4).outcome, 'absent_derived');
  assert.equal(state(-2).state, 'not_taken', 'ITEM 6: Not Taken generates no absence');
  assert.equal(state(-2).followUp, 'skip');
  assert.equal(state(-3).state, 'cancelled', 'ITEM 7: cancelled generates no absence');
  assert.equal(state(-3).followUp, 'skip');
  // Newest first: W(0) is open (skipped), then W(-1) awaits finalization - a barrier - so the
  // finalized absence at W(-4) is never reached and the run is reported as blocked, not as 1.
  assert.equal(streakOf('Alpha').streak, 0);
  assert.equal(streakOf('Alpha').blocked, true);
  assert.equal(streakOf('Alpha').endedBy, 'awaiting_finalization');
  console.log('PASS (2-7) lifecycle: pre-go-live / open / awaiting / finalized (derived) / not taken / cancelled each resolve as approved');

  // 8. Unexpected attender: headcount only.
  const x = at('Xray', -4);
  assert.equal(x.expected, false);
  assert.equal(x.unexpected, true);
  assert.equal(x.state, 'present');
  assert.equal(x.headcount, true, 'ITEM 8: counts toward the actual headcount');
  assert.equal(x.rateNumerator || x.rateDenominator, false, 'ITEM 8: never enters the expected rate');
  assert.equal(at('NotExpAt4', -4).state, 'not_expected', 'ITEM 45: a member who was not expected is Not Expected, never Absent');
  assert.equal(at('NotExpAt4', -4).followUp, 'break');
  const summary = attendance.sessionSummary(S(-4).id).tracked;
  assert.equal(summary.expected, 2, 'Alpha and Beta were expected; Xray and NotExpAt4 were not');
  assert.equal(summary.unexpected, 1);
  assert.equal(summary.headcount, 2, 'headcount = Beta + Xray');
  assert.equal(summary.rate, 50, 'rate = Beta / (Alpha + Beta): Xray does not inflate it');
  console.log('PASS (8) an unexpected attender is headcount only and never inflates the expected-member rate');
}

// ===========================================================================
// 9-16. RATE
// ===========================================================================
{
  population({ P1: 'active', P2: 'active', V1: 'active', VAC: 'active', ABS: 'active', DER: 'active', X: 'inactive' });
  resetWorld({ goLive: W(-3), weeks: range(-3, 0) });
  // W(-3): 3 of (6 - 1 vacation)
  mark('P1', -3, 'present'); mark('P2', -3, 'present');
  mark('V1', -3, 'visitor');   // member-linked visitor row: positive attendance
  mark('VAC', -3, 'excused');
  mark('ABS', -3, 'absent');   // physical Absent
  // DER: no row -> derived Absent
  mark('X', -3, 'present');    // unexpected
  // W(-2): every expected member on Vacation -> zero denominator
  for (const n of ['P1', 'P2', 'V1', 'VAC', 'ABS', 'DER']) mark(n, -2, 'excused');
  // W(-1): only P1 present
  mark('P1', -1, 'present');
  const before = { absent: physicalAbsentRows(), rows: recordCount() };
  finAll(-3, -2, -1);
  assert.equal(physicalAbsentRows(), before.absent, 'ITEM 64: finalizing creates no physical Absent rows');
  assert.equal(recordCount(), before.rows, 'ITEM 64: and no rows at all');

  const s3 = attendance.sessionSummary(S(-3).id);
  const t = s3.tracked;
  assert.equal(t.expected, 6);
  assert.equal(t.present, 3, 'ITEM 9/10: P1, P2 and the member-linked visitor row are the numerator');
  assert.equal(at('V1', -3).positive, true, 'ITEM 10: a member-linked visitor row is positive attendance');
  assert.equal(at('V1', -3).state, 'present');
  assert.equal(t.vacation, 1);
  assert.equal(t.rateDenominator, 5, 'ITEM 11: Vacation leaves the denominator (6 - 1)');
  assert.equal(t.recordedAbsent, 1, 'ITEM 12: the physical Absent is Absent');
  assert.equal(at('ABS', -3).state, 'absent');
  assert.equal(at('ABS', -3).derived, false);
  assert.equal(t.derivedAbsent, 1, 'ITEM 13: the no-row member is derived Absent');
  assert.equal(at('DER', -3).derived, true);
  assert.equal(t.absent, 2, 'Absent = recorded + derived');
  assert.equal(t.unexpected, 1);
  assert.equal(t.rate, 60, 'ITEM 14: 3 / 5 - the unexpected attendee does not inflate it');
  assert.equal(s3.rate, 60);
  assert.equal(t.headcount, 4);

  const s2 = attendance.sessionSummary(S(-2).id).tracked;
  assert.equal(s2.rateDenominator, 0);
  assert.equal(s2.rate, null, 'ITEM 15: a zero denominator is N/A (null) - not 0% and not a divide-by-zero');
  assert.equal(outcomes.pooledRate([{ numerator: 0, denominator: 0 }]).rate, null);

  const s1 = attendance.sessionSummary(S(-1).id).tracked;
  assert.equal(s1.rate, Math.round((1 / 6) * 100));

  // 16. Weighted aggregate, never an average of percentages.
  const overview = reports.fridayAttendanceOverview({ from: W(-3), to: W(0) });
  assert.equal(overview.rateNumerator, 4, '3 + 0 + 1 attended');
  assert.equal(overview.rateDenominator, 11, '5 + 0 + 6 expected minus Vacation');
  assert.equal(overview.rate, 36, 'ITEM 16: 4/11, summed');
  const naive = Math.round((60 + Math.round((1 / 6) * 100)) / 2);
  assert.notEqual(overview.rate, naive, 'ITEM 16: not the mean of the per-Friday percentages');
  assert.equal(overview.sessions.find((s) => s.sessionId === S(-2).id).rate, null);
  const report = attendance.attendanceReport({ from: W(-3), to: W(-1) });
  assert.equal(report.overall.rate, 36, 'the report uses the same weighted rate');
  assert.equal(report.overall.numerator, 4);
  assert.equal(report.overall.denominator, 11);
  console.log('PASS (9-16, 64) rate: expected present (incl. member-linked visitor) over expected minus Vacation; physical and derived Absent; unexpected never inflate; zero denominator is N/A; aggregate is weighted; finalizing writes no rows');
}

// ===========================================================================
// 17-28. FOLLOW-UP
// ===========================================================================
// Everyone flagged regardless of the engagement window (that rule has its own test below).
setSetting('attendance.recent_engagement_days', 0);
population({
  Abs3: 'active', PresBreak: 'active', VisBreak: 'active', VacBreak: 'active', Ghost: 'active',
  NotExp: { status: 'active', changes: [{ at: atNoon(addDays(W(-3), -2)), status: 'inactive' }, { at: atNoon(addDays(W(-3), 3)), status: 'active' }] }
});
resetWorld({ goLive: W(-7), weeks: [-9, -8, ...range(-7, 0)] });
// Pre-go-live Fridays: Ghost has physical Absent rows there.
mark('Ghost', -9, 'absent'); mark('Ghost', -8, 'absent');
// Abs3: -1 absent(physical), -2, -3 derived, -4..-7 present
mark('Abs3', -1, 'absent');
for (const n of [-4, -5, -6, -7]) mark('Abs3', n, 'present');
// PresBreak: -1 A, -2 A, -3 present
mark('PresBreak', -3, 'present'); mark('PresBreak', -4, 'present');
// VisBreak: -1 A, -2 member-linked visitor row
mark('VisBreak', -2, 'visitor'); mark('VisBreak', -3, 'present');
// VacBreak: -1 A, -2 A, -3 Vacation
mark('VacBreak', -3, 'excused'); mark('VacBreak', -4, 'present');
// NotExp: expected -1 and -2, not expected -3 (inactive that Friday), expected -4..-7
finAll(...range(-7, -1));

{
  assert.equal(streakOf('Abs3').streak, 3, 'ITEM 17: three finalized eligible absences (physical then derived)');
  assert.equal(streakOf('Abs3').flagged, true);
  assert.equal(attendance.followUpList({ limit: 100 }).some((f) => f.member.id === id('Abs3')), true, 'ITEM 17: appears on the follow-up list');
  assert.equal(streakOf('PresBreak').streak, 2, 'ITEM 18: Present breaks the run');
  assert.equal(streakOf('PresBreak').flagged, false);
  assert.equal(streakOf('VisBreak').streak, 1, 'ITEM 19: a member-linked visitor row (positive attendance) breaks the run');
  assert.equal(streakOf('VacBreak').streak, 2, 'ITEM 20: Vacation breaks the run (attendance.excused_counts is on)');
  setSetting('attendance.excused_counts', false);
  assert.equal(streakOf('VacBreak').streak, 3, 'ITEM 20: with the existing rule off, Vacation does not break it (counted as a missed Friday, run ends at the Present)');
  setSetting('attendance.excused_counts', true);
  assert.equal(streakOf('NotExp').streak, 2, 'ITEM 21: a Friday the member was not expected at breaks the run');
  assert.equal(streakOf('NotExp').endedBy, 'not_expected');
  const ghost = streakOf('Ghost');
  assert.equal(ghost.streak, 7, 'ITEM 23: all seven tracked Fridays - the two pre-go-live absent rows are outside the sequence');
  assert.equal(ghost.endedBy, 'no_more_sessions', 'the tracked sequence simply ends at the Go-Live date');
  // ...and if a pre-go-live Friday were ever in the sequence it would stop the run, never extend it.
  const withHistory = outcomes.consecutiveAbsenceRun(id('Ghost'), outcomes.buildFridayContexts({ countingOnly: true, to: W(0) }));
  assert.equal(withHistory.streak, 7);
  assert.equal(withHistory.endedBy, 'outside_tracking');
  console.log('PASS (17-21, 23) follow-up: threshold run of finalized absences; Present, visitor, Vacation and not-expected break it; pre-go-live is outside');
}

// 22 & 27. An unfinalized past Friday is a BARRIER - never skipped over.
{
  assert.equal(lifecycle.reopenAttendance(S(-3).id, { userId: null, reason: 'Late sign-in book' }).ok, true);
  const g = streakOf('Ghost');
  assert.equal(g.streak, 2, 'ITEM 22/27: only W(-1) and W(-2) count; W(-3) is awaiting finalization');
  assert.equal(g.blocked, true);
  assert.equal(g.blockedOn.sessionId, S(-3).id);
  assert.equal(g.flagged, false, 'ITEM 22: the run is NOT carried across the barrier to reach the threshold (no Sep 4 / Sep 18 leapfrog)');
  assert.equal(g.possiblyUnderstated, true);
  assert.notEqual(g.streak, 6);
  const status = attendance.followUpStatus();
  assert.equal(status.complete, false, 'ITEM 27: follow-up is not complete');
  assert.deepEqual(status.awaitingFridays.map((f) => f.id), [S(-3).id]);
  assert.equal(attendance.followUpList({ limit: 100 }).some((f) => f.member.id === id('Ghost')), false);
  // Re-finalizing restores it (the snapshot is preserved).
  fin(-3);
  assert.equal(streakOf('Ghost').streak, 7);
  assert.equal(attendance.followUpStatus().complete, true);
  console.log('PASS (22, 27) an unfinalized past Friday is a barrier: the run is never counted across it and follow-up says it is incomplete; reopening/refinalizing recalculates');
}

// 24. Cancelled: no absence, no break.
{
  db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-2).id);
  assert.equal(streakOf('Ghost').streak, 6, 'ITEM 24: a cancelled Friday neither adds an absence nor breaks the run');
  db.prepare("UPDATE attendance_sessions SET status = 'held' WHERE id = ?").run(S(-2).id);
  assert.equal(streakOf('Ghost').streak, 7);
  // 25. Not taken: same.
  assert.equal(lifecycle.reopenAttendance(S(-2).id, { userId: null, reason: 'x' }).ok, true);
  assert.equal(lifecycle.markAttendanceNotTaken(S(-2).id, { userId: null, note: 'Not taken', confirmExistingAttendance: true }).ok, true);
  assert.equal(streakOf('Ghost').streak, 6, 'ITEM 25: a Not Taken Friday generates no absence');
  assert.equal(streakOf('Ghost').blocked, false, 'and is not a barrier');
  assert.equal(lifecycle.reopenAttendance(S(-2).id, { userId: null, reason: 'x' }).ok, true);
  fin(-2);
  assert.equal(streakOf('Ghost').streak, 7);
  console.log('PASS (24-25) cancelled and Not Taken Fridays neither add absences nor break or block the run');
}

// 26. Correction recalculates.
{
  assert.equal(lifecycle.correctFinalizedAttendance(S(-1).id, [{ memberId: id('Ghost'), to: 'present' }], { userId: null, reason: 'Was here' }).ok, true);
  assert.equal(streakOf('Ghost').streak, 0, 'ITEM 26: a corrected Present ends the run');
  assert.equal(lifecycle.correctFinalizedAttendance(S(-1).id, [{ memberId: id('Ghost'), to: 'remove' }], { userId: null, reason: 'Mistake' }).ok, true);
  assert.equal(streakOf('Ghost').streak, 7, 'ITEM 26: removing it restores the derived absence');
  console.log('PASS (26) a correction recalculates the run immediately');
}

// 28. Threshold setting respected.
{
  setSetting('attendance.followup_threshold', 2);
  assert.equal(streakOf('PresBreak').flagged, true, 'ITEM 28: threshold 2 flags a run of 2');
  setSetting('attendance.followup_threshold', 5);
  assert.equal(streakOf('Abs3').flagged, false, 'ITEM 28: threshold 5 does not flag a run of 3');
  assert.equal(attendance.followUpList({ limit: 100 }).every((f) => f.streak >= 5), true);
  setSetting('attendance.followup_threshold', 3);
  console.log('PASS (28) attendance.followup_threshold is respected');
}

// Engagement window: only steps aside for someone whose last TRACKED attendance is older than it.
// A member who never checked in since Go-Live still qualifies at the threshold (Phase 2C hardening).
{
  setSetting('attendance.recent_engagement_days', 56);
  let flagged = attendance.followUpList({ limit: 100 }).map((f) => f.member.id);
  assert.equal(flagged.includes(id('Ghost')), true, 'never attended since Go-Live: still qualifies at the threshold');
  assert.equal(flagged.includes(id('Abs3')), true, 'a recently attending member is flagged');
  setSetting('attendance.recent_engagement_days', 14);
  flagged = attendance.followUpList({ limit: 100 }).map((f) => f.member.id);
  assert.equal(flagged.includes(id('Abs3')), false, 'last tracked attendance older than the window: left to the Long Absence review');
  assert.equal(flagged.includes(id('Ghost')), true, 'no tracked attendance at all is NOT a reason to leave follow-up');
  setSetting('attendance.recent_engagement_days', 0);
}

// ===========================================================================
// 29-36. STORED REMINDERS
// ===========================================================================
{
  population({ Rem: 'active' });
  resetWorld({ goLive: W(-5), weeks: range(-5, 0) });
  mark('Rem', -5, 'present'); mark('Rem', -4, 'present');
  finAll(-5, -4, -3, -2);
  assert.equal(openReminders('Rem').length, 0, 'two absences: not yet');
  fin(-1);
  const open = openReminders('Rem');
  assert.equal(open.length, 1, 'ITEM 29: exactly one reminder for the qualifying run');
  assert.equal(open[0].dedupe_key, reminders.followUpRunKey(id('Rem'), S(-3).id), 'keyed to the run (its first absence), not the streak length');
  assert.equal(open[0].state, 'new');

  // 30. Idempotent.
  reminders.reconcileFollowUpReminders({ source: 'test' });
  reminders.reconcileFollowUpReminders({ source: 'test' });
  reminders.generateReminders();
  assert.equal(allReminders('Rem').length, 1, 'ITEM 30: re-running never duplicates');
  fin(0);
  assert.equal(streakOf('Rem').streak, 4, 'the run grew to 4 - the same run, so still one reminder');
  assert.equal(allReminders('Rem').length, 1, 'a growing run does not raise a second reminder');
  assert.equal(lifecycle.reopenAttendance(S(0).id, { userId: null, reason: 'Recount' }).ok, true);
  assert.equal(streakOf('Rem').streak, 3, 'the open current Friday is skipped, not a barrier');
  assert.equal(openReminders('Rem').length, 1, 'and the reminder stands');
  fin(0);
  db.prepare('DELETE FROM attendance_records WHERE session_id = ?').run(S(0).id);

  // 32. Reopening a PAST Friday makes it a barrier: the run cannot be evaluated, so the reminder closes...
  assert.equal(lifecycle.reopenAttendance(S(-1).id, { userId: null, reason: 'Late sign-in book' }).ok, true);
  assert.equal(streakOf('Rem').streak, 1, 'only the finalized W(0) counts; the run stops at the barrier');
  assert.equal(streakOf('Rem').blocked, true);
  assert.equal(openReminders('Rem').length, 0, 'ITEM 32: reopening reconciled - the reminder is closed while the run cannot be evaluated');
  assert.equal(allReminders('Rem')[0].state, 'dismissed');
  assert.equal(allReminders('Rem')[0].handled_by, null, 'dismissed by the system, not a person');
  assert.ok(audits('reminder.followup_auto_dismissed').length >= 1, 'the automatic dismissal is audited');
  // ...and re-finalizing reconciles again: the SAME reminder is reopened, not duplicated.
  fin(-1);
  assert.equal(streakOf('Rem').streak, 4);
  assert.equal(openReminders('Rem').length, 1, 'ITEM 32: re-finalization recalculated it');
  assert.equal(allReminders('Rem').length, 1, 'no duplicate');
  assert.ok(audits('reminder.followup_reopened').length >= 1);
  assert.equal(lifecycle.reopenAttendance(S(0).id, { userId: null, reason: 'x' }).ok, true);
  assert.equal(streakOf('Rem').streak, 3);

  // 31. Correction removes qualification -> stale reminder dismissed.
  assert.equal(lifecycle.correctFinalizedAttendance(S(-2).id, [{ memberId: id('Rem'), to: 'present' }], { userId: null, reason: 'Was there' }).ok, true);
  assert.equal(openReminders('Rem').length, 0, 'ITEM 31: the correction dismissed the stale reminder');
  assert.equal(allReminders('Rem')[0].handled_by, null);
  assert.match(allReminders('Rem')[0].detail, /Closed automatically/);
  assert.equal(lifecycle.correctFinalizedAttendance(S(-2).id, [{ memberId: id('Rem'), to: 'remove' }], { userId: null, reason: 'Actually absent' }).ok, true);
  assert.equal(openReminders('Rem').length, 1, 'and undoing it restores the reminder');

  // 33. Cancellation reconciles; 34. reinstatement recalculates.
  assert.equal(lifecycle.changeSessionStatus(S(-2).id, 'cancelled', { userId: null, notes: 'Wrong Friday' }).ok, true);
  assert.equal(streakOf('Rem').streak, 2, 'a cancelled Friday no longer counts, so the run is 2');
  assert.equal(openReminders('Rem').length, 0, 'ITEM 33: cancellation reconciled the reminder');
  assert.equal(lifecycle.changeSessionStatus(S(-2).id, 'held', { userId: null, notes: 'Reinstated' }).ok, true);
  assert.equal(streakOf('Rem').streak, 3);
  assert.equal(openReminders('Rem').length, 1, 'ITEM 34: reinstatement recalculated it');
  assert.equal(allReminders('Rem').length, 1, 'never a duplicate through all of that');

  // A person's own decision is never overridden.
  db.prepare("UPDATE reminders SET state = 'completed', handled_by = NULL WHERE id = ?").run(allReminders('Rem')[0].id);
  const userId = db.prepare('SELECT id FROM users LIMIT 1').get()?.id ?? null;
  if (userId) db.prepare('UPDATE reminders SET handled_by = ? WHERE id = ?').run(userId, allReminders('Rem')[0].id);
  reminders.reconcileFollowUpReminders({ source: 'test' });
  assert.equal(allReminders('Rem')[0].state, 'completed', 'a completed reminder is left alone');
  console.log('PASS (29-34) reminders: one per run, idempotent, keyed to the run; correction / reopen / cancel / reinstate reconcile; system dismissals are audited and distinguishable');
}

// 35. A later, separate run of the SAME length gets its own reminder.
{
  population({ Rem2: 'active' });
  // Fridays are settled oldest-first: a newer unfinalized Friday would (correctly) be a barrier.
  resetWorld({ goLive: W(-8), weeks: [-8, -7, -6] });
  finAll(-8, -7, -6);
  assert.equal(openReminders('Rem2').length, 1, 'run 1 (three absences) qualifies');
  const run1 = openReminders('Rem2')[0];
  addWeek(-5); mark('Rem2', -5, 'present'); fin(-5);
  assert.equal(openReminders('Rem2').length, 0, 'attending ended run 1 and closed its reminder');
  for (const n of [-4, -3, -2]) { addWeek(n); fin(n); }
  const open = openReminders('Rem2');
  assert.equal(open.length, 1, 'ITEM 35: run 2 - the same length as run 1 - raises a fresh reminder');
  assert.notEqual(open[0].dedupe_key, run1.dedupe_key, 'keyed to a different run');
  assert.equal(open[0].dedupe_key, reminders.followUpRunKey(id('Rem2'), S(-4).id));
  assert.equal(allReminders('Rem2').length, 2, 'run 1 is kept as history (never deleted)');
  console.log('PASS (35) a genuinely new run of the same length creates a new reminder; the old one is kept');
}

// 36. A reconciliation failure never undoes the lifecycle commit.
{
  population({ Rem3: 'active' });
  resetWorld({ goLive: W(-4), weeks: range(-4, 0) });
  finAll(-4, -3, -2); // W(-1) is still awaiting, so nothing qualifies yet
  assert.equal(allReminders('Rem3').length, 0);
  const failuresBefore = audits('attendance.followup_reconciliation_failed').length;
  db.exec("CREATE TRIGGER fail_reminders BEFORE INSERT ON reminders BEGIN SELECT RAISE(ABORT, 'reminders unavailable'); END;");
  const realError = console.error;
  const logged = [];
  console.error = (...args) => logged.push(args.join(' '));
  let result;
  try {
    result = lifecycle.finalizeAttendance(S(-1).id, { userId: null, confirmNoAttendance: true }); // settles the barrier -> a run of 4 -> would create a reminder
  } finally {
    console.error = realError;
    db.exec('DROP TRIGGER fail_reminders');
  }
  assert.equal(result.ok, true, 'ITEM 36: the finalization itself succeeded');
  assert.equal(fresh(-1).finalization_state, 'finalized', 'ITEM 36: and is committed');
  assert.ok(db.prepare('SELECT COUNT(*) AS n FROM attendance_expected WHERE session_id = ?').get(S(-1).id).n > 0, 'with its snapshot');
  assert.equal(allReminders('Rem3').length, 0, 'the reminder could not be written');
  assert.equal(audits('attendance.followup_reconciliation_failed').length, failuresBefore + 1, 'the failure is audited');
  assert.ok(logged.some((l) => /follow-up reconciliation failed/.test(l)), 'and logged');
  reminders.reconcileFollowUpReminders({ source: 'test' });
  assert.equal(openReminders('Rem3').length, 1, 'the next reconciliation (or the daily generation) catches up');
  console.log('PASS (36) a reconciliation failure is logged and audited and never rolls back the committed attendance change');
}

// ===========================================================================
// 37-41. LONG ABSENCE
// ===========================================================================
{
  setSetting('attendance.recent_engagement_days', 56);
  population({ Gone: 'active', Recent: 'active', Old: 'active', Back: 'active' });

  // 37/38: immediately after Go-Live nobody is flagged; the state is explicit.
  resetWorld({ goLive: W(0), weeks: [-2, -1, 0] });
  const soon = attendance.longAbsenceReview();
  assert.equal(soon.status, 'insufficient_history', 'ITEM 38: an explicit state, not a list');
  assert.ok(soon.trackedDays < soon.requiredDays);
  assert.equal(soon.rows.length, 0, 'ITEM 37: immediately after Go-Live the whole church is NOT flagged');
  assert.deepEqual(attendance.longAbsenceList(), []);

  // 41. Reset simulation: legacy attendance gone, tracking just began.
  resetWorld({ goLive: addDays(today(), -3), weeks: range(-9, 0) });
  const reset = attendance.longAbsenceReview();
  assert.equal(reset.status, 'insufficient_history');
  assert.equal(reset.rows.length, 0, 'ITEM 41: no legacy records + tracking just started must not read as "never attended"');
  assert.equal(reset.rows.some((r) => r.neverAttended), false);

  // 39/40: after a full observation window.
  resetWorld({ goLive: W(-10), weeks: range(-10, 0) });
  mark('Recent', -1, 'present');
  mark('Old', -9, 'present');
  mark('Back', -9, 'present'); mark('Back', -2, 'present');
  finAll(...range(-10, -1));
  const ready = attendance.longAbsenceReview();
  assert.equal(ready.status, 'ready');
  assert.equal(ready.complete, true);
  const byId = new Map(ready.rows.map((r) => [r.member.id, r]));
  assert.equal(byId.has(id('Recent')), false, 'recently attended: not listed');
  assert.equal(byId.has(id('Back')), false, 'ITEM 40: tracked attendance within the window keeps them off the list');
  assert.equal(byId.get(id('Old')).state, 'long_absent', 'ITEM 39: a genuine long absence appears');
  assert.equal(byId.get(id('Old')).lastAttended.service_date, W(-9));
  assert.equal(byId.get(id('Gone')).state, 'no_tracked_attendance', 'ITEM 39/41: worded as no tracked attendance - never "never attended"');
  assert.equal(byId.get(id('Gone')).neverAttended, true);
  // 40. A tracked Present clears them.
  assert.equal(lifecycle.correctFinalizedAttendance(S(-1).id, [{ memberId: id('Gone'), to: 'present' }], { userId: null, reason: 'Here' }).ok, true);
  assert.equal(attendance.longAbsenceReview().rows.some((r) => r.member.id === id('Gone')), false, 'ITEM 40: a tracked Present clears/removes them');
  // An unfinalized Friday inside the window makes the review say it may be incomplete.
  assert.equal(lifecycle.reopenAttendance(S(-3).id, { userId: null, reason: 'x' }).ok, true);
  const partial = attendance.longAbsenceReview();
  assert.equal(partial.complete, false);
  assert.deepEqual(partial.awaitingFridays.map((f) => f.id), [S(-3).id]);
  console.log('PASS (37-41) Long Absence: insufficient history is explicit and lists nobody; after a full window only genuine long absence appears; tracked Present clears; no false "never attended" after a reset');
}

// ===========================================================================
// 42-45, 55-59, 60. MEMBER HISTORY, LANDING, NON-FRIDAY (lifecycle world again)
// ===========================================================================
population({
  Alpha: 'active', Beta: 'active', Xray: 'inactive', Hist: 'active',
  NotExpAt4: { status: 'inactive', changes: [{ at: atNoon(addDays(W(-4), 3)), status: 'active' }] }
});
resetWorld({ goLive: G1, weeks: range(-6, 0) });
mark('Hist', -6, 'present'); mark('Hist', -4, 'present'); mark('Beta', -4, 'present'); mark('Xray', -4, 'present');
mark('Beta', -3, 'present'); mark('Beta', -2, 'present');
fin(-4);
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-3).id);
assert.equal(lifecycle.markAttendanceNotTaken(S(-2).id, { userId: null, note: 'Sheet lost', confirmExistingAttendance: true }).ok, true);

{
  // Hist: present -6 (before tracking), none at -5 (before tracking), present -4, nothing after.
  const history = attendance.memberAttendanceHistory(id('Hist'), { limit: 20 });
  const st = (n) => history.find((h) => h.id === S(n).id);
  assert.equal(st(-6).state, 'present', 'ITEM 42: a recorded pre-tracking row is shown as recorded');
  assert.equal(st(-5).state, 'not_tracked', 'ITEM 42/2: a pre-go-live missing row is Not tracked - not Absent');
  assert.equal(st(-5).status, 'not_tracked');
  assert.equal(st(-4).state, 'present');
  assert.equal(st(-3).state, 'cancelled', 'cancelled Fridays are shown, labelled');
  assert.equal(st(-2).state, 'not_taken');
  assert.equal(st(-1).state, 'awaiting_finalization');
  assert.equal(st(0).state, 'pending');
  assert.deepEqual(new Set(history.map((h) => h.state)), new Set(['present', 'not_tracked', 'cancelled', 'not_taken', 'awaiting_finalization', 'pending']), 'ITEM 42: every lifecycle state is reachable in the display');
  const alphaHistory = attendance.memberAttendanceHistory(id('Alpha'), { limit: 20 });
  assert.equal(alphaHistory.find((h) => h.id === S(-4).id).state, 'absent', 'ITEM 44: derived Absent is displayed simply as Absent');
  assert.equal(alphaHistory.find((h) => h.id === S(-4).id).derived, true);
  assert.equal(alphaHistory.find((h) => h.id === S(-4).id).status, 'absent');

  // 43. The snapshot survives a later status change.
  changeStatus(id('Alpha'), 'inactive', { reason: 'moved on' });
  changeStatus(id('NotExpAt4'), 'inactive', { reason: 'later change' });
  const later = attendance.memberAttendanceHistory(id('Alpha'), { limit: 20 }).find((h) => h.id === S(-4).id);
  assert.equal(later.state, 'absent', 'ITEM 43: Alpha is inactive now, but was expected then - history is not rewritten');
  assert.equal(attendance.sessionSummary(S(-4).id).tracked.expected, 3, 'the stored roster (Alpha, Beta, Hist) is unchanged');
  assert.equal(attendance.memberAttendanceHistory(id('NotExpAt4'), { limit: 20 }).find((h) => h.id === S(-4).id).state, 'not_expected', 'ITEM 45');
  changeStatus(id('Alpha'), 'active', { reason: 'back' });

  const summary = attendance.memberAttendanceSummary(id('Alpha'), { lastN: 8 });
  assert.equal(summary.services.some((s) => s.state === 'cancelled'), false, 'the recent-services strip leaves cancelled weeks out');
  assert.equal(summary.rate, 0, 'Alpha was expected at exactly one finalized Friday and was absent: 0 of 1');
  assert.equal(summary.rateServices, 1);
  assert.equal(attendance.memberAttendanceSummary(id('Xray'), { lastN: 8 }).rate, null, 'never expected, so no rate (not 0%)');
  console.log('PASS (42-45) member history: every lifecycle state, derived Absent shown as Absent, Not Expected is not Absent, later status changes do not rewrite it');
}

{
  // 55-59 landing / dashboard semantics.
  const pending = attendance.pendingFridayServices({ weeks: 12 });
  assert.deepEqual(pending.sessions.map((s) => s.id), [S(-1).id], 'ITEM 55: exactly the past tracked Friday awaiting finalization is actionable');
  assert.equal(pending.sessions.some((s) => [S(-6).id, S(-5).id].includes(s.id)), false, 'ITEM 56: pre-go-live Fridays are never nagged');
  assert.equal(pending.sessions.some((s) => s.id === S(-2).id), false, 'ITEM 57: Not Taken is not nagged');
  assert.equal(pending.sessions.some((s) => s.id === S(-3).id), false, 'ITEM 58: cancelled is not nagged');
  assert.equal(pending.sessions.some((s) => s.id === S(0).id), false, 'the open Friday is not "pending finalization" yet');
  const overview = attendance.attendanceOverview();
  assert.deepEqual(overview.awaiting.map((s) => s.id), [S(-1).id]);
  const open = attendance.sessionSummary(S(0).id).tracked;
  assert.equal(open.absent, 0, 'ITEM 59: an open Friday shows no absent members');
  assert.equal(open.derivedAbsent, 0);
  assert.equal(open.pending, open.expected, 'everyone expected who has not checked in is Pending');
  assert.equal(attendance.sessionSummary(S(0).id).figures.absent, null);
  const trend = attendance.attendanceTrend({ points: 8 });
  assert.deepEqual(trend.map((t) => t.date), [W(-6), W(-5), W(-4)], 'the trend shows settled Fridays only (history + finalized), never open/awaiting/not-taken/cancelled');
  console.log('PASS (55-59) landing: only a past tracked Friday awaiting finalization is actionable; pre-go-live, cancelled, Not Taken and open Fridays are never nagged or shown as absences');

  // Register roster: the snapshot is authoritative once it exists.
  const roster = attendance.sessionRoster(S(-4).id);
  const names = roster.map((m) => m.first_name).sort();
  assert.deepEqual(names, ['Alpha', 'Beta', 'Hist', 'Xray'], 'the finalized Friday sheet is the stored roster plus the recorded attendee - not today\'s statuses');
  const alpha = roster.find((m) => m.first_name === 'Alpha');
  assert.equal(alpha.derived, true);
  assert.equal(alpha.displayStatus, 'absent');
  assert.equal(alpha.status, 'not_recorded', 'the raw recorded status is unchanged');
  assert.equal(roster.find((m) => m.first_name === 'Xray').expected, false);
  assert.equal(attendance.sessionRoster(S(0).id).find((m) => m.first_name === 'Alpha').displayStatus, 'pending');
  console.log('PASS (register) roster rows carry the canonical state; a finalized Friday uses its stored roster');

  // Congregation & cell group figures.
  const congregation = congregations.attendanceByCongregation(S(-4).id);
  const total = Object.values(congregation).reduce((s, b) => s + b.total, 0);
  const unexpected = Object.values(congregation).reduce((s, b) => s + b.unexpected, 0);
  assert.equal(total, 3, 'congregation split is of the expected roster');
  assert.equal(unexpected, 1, 'the unexpected attender is headcount only');
  const rates = Object.values(congregation).map((b) => b.rate).filter((r) => r !== null);
  assert.ok(rates.length > 0);
  assert.equal(congregations.attendanceByCongregation(S(0).id).adult.rate ?? null, null, 'an open Friday has no rate');
  assert.equal(attendance.cellGroupBreakdown(S(-4).id).reduce((s, g) => s + g.members, 0), 3);
  assert.equal(attendance.cellGroupBreakdown(S(0).id).reduce((s, g) => s + g.absent, 0), 0, 'an open Friday breakdown has no absences');
  console.log('PASS (congregations / cell groups) figures come from the expected roster and follow the lifecycle');
}

// 60. Non-Friday / cell group semantics unchanged.
{
  const group = createGroup({ name: 'Semantics Group' });
  assignMemberToGroup(id('Beta'), group.id, {});
  const meeting = attendance.createCellGroupMeeting(group.id, { date: W(-1), title: 'Midweek' });
  assert.equal(meeting.ok, true);
  attendance.recordAttendance(meeting.sessionId, [{ memberId: id('Beta'), status: 'present' }], { userId: null });
  assert.equal(tracking.classifySession(db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(meeting.sessionId)).phase, 'not_applicable');
  const legacy = attendance.sessionSummary(meeting.sessionId);
  assert.equal(legacy.tracked, null);
  assert.equal(legacy.phase, 'not_applicable');
  assert.equal(legacy.notRecorded, legacy.activeMembers - 1, 'legacy semantics: the current roster minus who was recorded');
  assert.equal(legacy.figures.register, legacy.notRecorded > 0 ? `${legacy.notRecorded} still to mark` : 'Complete');
  const summary = attendance.cellGroupMeetingSummary(group.id, { lastN: 4 });
  assert.equal(summary.rows[0].cells[0].status, 'present');
  assert.equal(outcomes.resolveOutcome({ phase: 'not_applicable', expected: false, rowStatus: null }).token, 'not_recorded');
  assert.equal(attendance.recordAttendance(meeting.sessionId, [{ memberId: id('Beta'), status: null }], { userId: null }).ok, true, 'not gated by finalization');
  console.log('PASS (60) cell group meetings and other non-Friday sessions keep their existing semantics');
}

// ===========================================================================
// 61-64. TEMPORARILY AWAY, PHYSICAL ABSENT, ZERO-ATTENDANCE GUARD
// ===========================================================================
{
  population({ AwayNow: 'active', AwayOld: 'active', PhysAbs: 'active', Solo: 'active' });
  // Both moved to Temporarily Away well before these Fridays.
  for (const name of ['AwayNow', 'AwayOld']) {
    plantOne(member(name), { status: 'active', changes: [{ at: atNoon(W(-6)), status: 'temporarily_away' }] });
  }
  resetWorld({ goLive: W(-3), weeks: range(-3, 0) });
  mark('Solo', -3, 'present'); mark('Solo', -1, 'present'); mark('Solo', 0, 'present');
  mark('PhysAbs', -3, 'absent'); mark('PhysAbs', -2, 'absent');

  // Zero-attendance guard (Phase 2B) is preserved: W(-2) has a row, so use an empty Friday first.
  db.prepare('DELETE FROM attendance_records WHERE session_id = ?').run(S(-2).id);
  const empty = lifecycle.previewFinalization(S(-2).id);
  assert.equal(empty.requiresEmptyConfirmation, true, 'the empty-register guard is still shown');
  assert.equal(lifecycle.finalizeAttendance(S(-2).id, { userId: null }).reason, 'no_attendance_recorded', 'ITEM O: an unused register cannot be finalized without explicit confirmation');
  assert.equal(fresh(-2).finalization_state, null);
  mark('PhysAbs', -2, 'absent');

  const absentBefore = physicalAbsentRows();
  const rowsBefore = recordCount();
  finAll(-3, -2, -1, 0);
  assert.equal(physicalAbsentRows(), absentBefore, 'ITEM 64: finalization created no physical Absent rows');
  assert.equal(recordCount(), rowsBefore);

  // 63. Legacy physical Absent rows resolve correctly alongside derived ones.
  assert.equal(at('PhysAbs', -3).state, 'absent');
  assert.equal(at('PhysAbs', -3).derived, false, 'ITEM 63: a physical Absent row is Absent, not derived');
  assert.equal(at('PhysAbs', -2).derived, false);
  assert.equal(at('PhysAbs', -1).derived, true, 'and a Friday with no row is derived Absent');
  assert.equal(at('PhysAbs', -3).rateDenominator, true);
  assert.equal(at('PhysAbs', -3).rateNumerator, false);
  assert.equal(streakOf('PhysAbs').streak, 4, 'ITEM 63: physical and derived absences form one run');

  // 61. A corrected Present on the CURRENT operational Friday may auto-return Temporarily Away.
  const statusOf = (name) => db.prepare('SELECT status FROM members WHERE id = ?').get(id(name)).status;
  assert.equal(statusOf('AwayNow'), 'temporarily_away');
  assert.equal(lifecycle.correctFinalizedAttendance(S(0).id, [{ memberId: id('AwayNow'), to: 'present' }], { userId: null, reason: 'Here today' }).ok, true);
  assert.equal(statusOf('AwayNow'), 'active', 'ITEM 61: the existing business rule applies to a correction on the current Friday');
  // 62. A historical correction must not change today's status.
  assert.equal(lifecycle.correctFinalizedAttendance(S(-3).id, [{ memberId: id('AwayOld'), to: 'present' }], { userId: null, reason: 'Was here that week' }).ok, true);
  assert.equal(statusOf('AwayOld'), 'temporarily_away', 'ITEM 62: a historical corrected Present does not alter today\'s member status');
  console.log('PASS (61-64, guard) Temporarily Away returns only for the current Friday; legacy physical Absent rows resolve; finalizing writes no rows; the zero-attendance guard stands');
}

// ===========================================================================
// 46-54. REPORTS (screen, CSV, PDF)
// ===========================================================================
//   W(-7), W(-6) before Go-Live | W(-5), W(-4) finalized | W(-3) not taken | W(-2) cancelled
//   W(-1) awaiting | W(0) open
population({ P1: 'active', P2: 'active', Vis: 'active', Vac: 'active', Absm: 'active', Der: 'active', X: 'inactive' });
resetWorld({ goLive: W(-5), weeks: range(-7, 0) });
mark('P1', -7, 'present'); mark('P2', -6, 'absent');           // recorded history before tracking
mark('P1', -5, 'present'); mark('P2', -5, 'present'); mark('Vis', -5, 'visitor');
mark('Vac', -5, 'excused'); mark('Absm', -5, 'absent'); mark('X', -5, 'present');
mark('P1', -4, 'present');
mark('P1', -3, 'present');                                       // evidence on a Not Taken Friday
finAll(-5, -4);
assert.equal(lifecycle.markAttendanceNotTaken(S(-3).id, { userId: null, note: 'Not recorded', confirmExistingAttendance: true }).ok, true);
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-2).id);
const REPORT = { from: W(-7), to: W(0) };

{
  const report = attendance.attendanceReport({ ...REPORT, statuses: ['active', 'inactive'] });
  const row = (name) => report.rows.find((r) => r.member.id === id(name));
  // 46. Finalized.
  assert.equal(report.lifecycle.finalized, 2);
  assert.deepEqual([row('P1').eligible, row('P1').present, row('P1').rate], [2, 2, 100], 'ITEM 46');
  assert.deepEqual([row('P2').eligible, row('P2').present, row('P2').absent, row('P2').rate], [2, 1, 1, 50]);
  assert.deepEqual([row('Vis').eligible, row('Vis').visitor, row('Vis').absent, row('Vis').rate], [2, 1, 1, 50], 'a member-linked visitor row is positive attendance');
  assert.deepEqual([row('Vac').excused, row('Vac').absent, row('Vac').rate], [1, 1, 0], 'Vacation leaves the denominator: 0 of 1');
  assert.deepEqual([row('Absm').absent, row('Der').absent, row('Der').rate], [2, 2, 0], 'physical and derived absence alike');
  assert.equal(row('X').eligible, 0, 'an unexpected attender has no expected Fridays');
  assert.equal(row('X').rate, null);
  const s5 = report.bySession.find((s) => s.sessionId === S(-5).id);
  assert.equal(s5.unexpected, 1, 'ITEM 54: the unexpected attender is headcount');
  assert.equal(s5.numerator, 3);
  assert.equal(s5.denominator, 5);
  assert.equal(s5.rate, 60);
  // 53. Weighted rate.
  assert.equal(report.overall.rate, 36, 'ITEM 53: (3+1)/(5+6) = 36%, not the 39% mean of 60% and 17%');
  assert.equal(report.bySession.find((s) => s.sessionId === S(-4).id).rate, 17);
  // 47. Open / unfinalized.
  assert.equal(report.lifecycle.awaiting, 2, 'ITEM 47: the awaiting and the open Friday');
  for (const n of [-1, 0]) {
    const p = report.bySession.find((s) => s.sessionId === S(n).id);
    assert.equal(p.final, false);
    assert.equal(p.rate, null, 'ITEM 47: no final rate for an unfinalized Friday');
    assert.equal(p.absent, 0, 'ITEM 47: no absence either');
  }
  assert.equal(row('Der').not_recorded, 2, 'ITEM 47: they are Pending, not absent');
  assert.equal(row('Der').absent, 2, 'absences come from the two finalized Fridays only');
  // 48. Not Taken.
  assert.equal(report.lifecycle.notTaken, 1);
  const nt = report.bySession.find((s) => s.sessionId === S(-3).id);
  assert.deepEqual([nt.notTaken, nt.rate, nt.eligibleCount, nt.absent], [true, null, 0, 0], 'ITEM 48: labelled, no rate, no roster, no absence');
  assert.equal(nt.present, 1, 'the recorded evidence is still visible');
  assert.equal(row('Der').eligible, 2, 'and it is excluded from every aggregate');
  // 49. Cancelled.
  assert.equal(report.lifecycle.cancelled, 1);
  assert.equal(report.sessions.some((s) => s.id === S(-2).id), false, 'ITEM 49: cancelled is left out, as before');
  // 50. Pre-go-live.
  assert.equal(report.lifecycle.beforeTracking, 2);
  assert.equal(row('P1').historical.attended, 1, 'ITEM 50: history is retained and labelled');
  assert.equal(row('P2').historical.absent, 1, 'a recorded historical absence is shown as recorded, not counted as tracked');
  assert.equal(row('Der').historical.absent, 0, 'a missing pre-go-live row is not an absence');
  console.log('PASS (46-50, 53-54) attendance report: finalized numbers only, weighted rate, unexpected headcount, open/awaiting/not-taken/cancelled/pre-go-live labelled and excluded');

  // 51. CSV.
  const { csv } = attendance.attendanceReportCsv({ ...REPORT, statuses: ['active', 'inactive'] });
  const lines = csv.trim().split('\r\n');
  assert.match(lines[0], /Services counted/);
  assert.match(lines[0], /Pending \(not yet finalized\)/);
  assert.match(lines[0], /Before tracking: attended/);
  const derLine = lines.find((l) => l.includes(member('Der').member_code));
  const cells = derLine.split(',').map((c) => c.replaceAll('"', ''));
  assert.equal(cells[3], '2', 'ITEM 51: expected finalized Fridays');
  assert.equal(cells[7], '2', 'derived absences are reported as Absent');
  assert.equal(cells[8], '2', 'pending, not absent');
  assert.equal(cells[9], '0', 'rate');
  const xLine = lines.find((l) => l.includes(member('X').member_code)).split(',').map((c) => c.replaceAll('"', ''));
  assert.equal(xLine[9], '', 'ITEM 51: no rate is printed as blank, never 0');
  const overview = reports.fridayAttendanceOverview({ from: W(-7), to: W(0) });
  const overviewCsv = reports.fridayAttendanceOverviewCsv({ from: W(-7), to: W(0), sort: 'date', direction: 'asc' }).csv.split('\n');
  assert.match(overviewCsv[0], /Status/);
  assert.ok(overviewCsv.some((l) => l.includes('Attendance not taken')));
  assert.ok(overviewCsv.some((l) => l.includes('Awaiting finalization')));
  assert.ok(overviewCsv.some((l) => l.includes('Not tracked (before tracking start)')));
  assert.equal(overview.lifecycle.beforeTracking, 2);
  assert.equal(overview.totalUnexpected, 1, 'X attended without being expected: headcount, and not in the rate');
  assert.equal(overview.rate, 36, 'ITEM 54: ...so the overview rate is unchanged by X');
  console.log('PASS (51) CSV: lifecycle status column, pending vs absent, blank (not 0) when nothing is measurable');

  // 52. PDF.
  const text = await pdfText(pdfs.attendancePdf({ from: REPORT.from, to: REPORT.to, statuses: ['active', 'inactive'] }));
  assert.match(text, /Overall attendance %/i, 'ITEM 52');
  assert.match(text, /36%/, 'the weighted overall rate');
  assert.match(text, /Pending/);
  assert.doesNotMatch(text, /derived/i, 'no database jargon');
  const longText = await pdfText(pdfs.longAbsencePdf({}));
  assert.match(longText, /Not enough tracked history yet/, 'Long Absence PDF states the insufficient-history case');
  console.log('PASS (52) PDF: overall weighted rate, pending, no jargon; the Long Absence PDF states insufficient history');
}

async function pdfText(doc) {
  const chunks = [];
  doc.on('data', (c) => chunks.push(c));
  const done = new Promise((resolve) => doc.on('end', resolve));
  // The report builders end the document themselves (finishDocument); just collect it.
  await done;
  const buffer = Buffer.concat(chunks).toString('latin1');
  let text = '';
  for (const match of buffer.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) {
    let content;
    try { content = zlib.inflateSync(Buffer.from(match[1], 'latin1')).toString('latin1'); } catch { continue; }
    for (const hex of content.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(hex[1], 'hex').toString('latin1');
    for (const lit of content.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += lit[1];
    text += '\n';
  }
  return text;
}

// ===========================================================================
// HTTP: every converted screen renders with the new states (views compile and speak the model)
// ===========================================================================
// World: the lifecycle world (pre-go-live, finalized, cancelled, not taken, awaiting, open).
population({
  Alpha: 'active', Beta: 'active', Xray: 'inactive', Hist: 'active',
  NotExpAt4: { status: 'inactive', changes: [{ at: atNoon(addDays(W(-4), 3)), status: 'active' }] }
});
resetWorld({ goLive: G1, weeks: range(-6, 0) });
mark('Hist', -6, 'present'); mark('Hist', -4, 'present'); mark('Beta', -4, 'present'); mark('Xray', -4, 'present');
mark('Beta', -3, 'present'); mark('Beta', -2, 'present');
fin(-4);
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-3).id);
assert.equal(lifecycle.markAttendanceNotTaken(S(-2).id, { userId: null, note: 'Sheet lost', confirmExistingAttendance: true }).ok, true);
const httpGroup = createGroup({ name: 'HTTP Group' });
assignMemberToGroup(id('Beta'), httpGroup.id, {});

const port = await new Promise((resolve) => {
  const srv = net.createServer();
  srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
});
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  await createUser({ email: 'admin.consumers@fixture.invalid', password: 'ConsumersPassw0rd!2026', displayName: 'Consumers Admin', roleKeys: ['church_admin'], mustChangePassword: false });
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'admin.consumers@fixture.invalid', password: 'ConsumersPassw0rd!2026', _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const html = async (url) => {
    const res = await fetch(`${base}${url}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, `GET ${url} -> ${res.status}`);
    return res.text();
  };
  const registerData = (markup) => JSON.parse(markup.match(/id="attendance-register-data">([\s\S]*?)<\/script>/)[1].replace(/\\u003c/g, '<'));

  const landing = await html('/attendance');
  assert.match(landing, /awaiting finalization/i, 'the landing page says which Friday awaits finalization');
  assert.match(landing, new RegExp(dates_(W(-1))), 'and links the Friday');
  assert.doesNotMatch(landing, /no attendance recorded:/, 'the old "no attendance recorded" nag is gone');
  assert.match(landing, /Pending/);

  const friday = await html('/attendance/friday');
  for (const label of ['Finalized', 'Attendance not taken', 'Awaiting finalization', 'Not tracked', 'Cancelled']) {
    assert.match(friday, new RegExp(label), `the Friday list shows "${label}"`);
  }

  const finalized = registerData(await html(`/attendance/sessions/${S(-4).id}`));
  assert.equal(finalized.members.find((m) => m.name.includes('Alpha')).status, 'absent', 'the finalized sheet shows the derived Absent');
  assert.equal(finalized.canRecord, false);
  const finalizedHtml = await html(`/attendance/sessions/${S(-4).id}`);
  assert.match(finalizedHtml, /Expected/);
  assert.match(finalizedHtml, /Rate/);
  const openMarkup = await html(`/attendance/sessions/${S(0).id}`);
  const open = registerData(openMarkup);
  assert.ok(open.statuses.some((s) => s.value === '' && s.label === 'Not checked in'), 'an open tracked Friday says Not checked in, not Not recorded');
  assert.match(openMarkup, /Not checked in/);
  assert.match(await html(`/attendance/sessions/${S(-2).id}`), /Attendance was not taken|attendance not taken/i);
  assert.match(await html(`/attendance/sessions/${S(-6).id}`), /Not tracked/);
  assert.match(await html(`/attendance/sessions/${S(-1).id}`), /Awaiting finalization/);

  const followUp = await html('/attendance/follow-up');
  assert.match(followUp, /may be incomplete/, 'follow-up says it is incomplete while a Friday awaits finalization');
  const longAbsence = await html('/attendance/long-absence');
  assert.match(longAbsence, /Not enough tracked history yet/);
  const reportPage = await html(`/attendance/reports?from=${W(-6)}&to=${W(0)}`);
  assert.match(reportPage, /finalized/i);
  assert.match(reportPage, /Pending/);
  const overviewPage = await html(`/reports/attendance?from=${W(-6)}&to=${W(0)}`);
  assert.match(overviewPage, /Only <strong>finalized<\/strong>/);
  assert.match(overviewPage, /Awaiting finalization/);
  const memberPage = await html(`/members/${id('Hist')}/attendance`);
  assert.match(memberPage, /Not tracked|Awaiting finalization|Not checked in/);
  assert.match(await html(`/members/${id('Alpha')}?tab=attendance`), /Absent/);
  assert.match(await html(`/attendance/cell-groups/${httpGroup.id}`), /Beta/);
  assert.match(await html(`/cell-groups/${httpGroup.id}?tab=attendance`), /Beta/);
  const dashboard = await html('/');
  assert.match(dashboard, /awaiting finalization/i, 'the dashboard nudges about the Friday awaiting finalization');
  const settings = await html('/admin/settings?section=attendance');
  assert.doesNotMatch(settings, /attendance__not_recorded_counts/, 'the retired setting is not offered');
  assert.doesNotMatch(settings, /Count services with no record/);
  console.log('PASS (HTTP) landing, Friday list, every register phase, follow-up, Long Absence, reports, member and cell group pages and the dashboard render the canonical states; the retired setting is hidden');

  // Saving the settings form must not touch the retired setting.
  const settingsCsrf = settings.match(/name="_csrf" value="([^"]+)"/)[1];
  db.prepare("UPDATE system_settings SET value = '1' WHERE key = 'attendance.not_recorded_counts'").run();
  await fetch(`${base}/admin/settings`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ _csrf: settingsCsrf, attendance__followup_threshold: '3' })
  });
  assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.not_recorded_counts'").get().value, '1', 'the retired setting is never written from the form');
  console.log('PASS (retired setting) attendance.not_recorded_counts is hidden, ignored on save and read by nothing');
} finally {
  await terminateAndWait(server);
}

function dates_(date) {
  return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${date}T00:00:00Z`));
}

console.log('ALL PASS');
