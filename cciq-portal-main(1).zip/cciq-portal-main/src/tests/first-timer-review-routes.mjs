import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * The Membership Review screens and the Convert / Link actions over HTTP: access by role, CSRF, forged and stale input, refused repeats,
 * what each action writes, and the read-only "Before membership" card on the member profile.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-review-routes-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
await import('../services/membership-review.js'); // registers the lifecycle hook, as the running portal does
const { checkInvariants } = await import('../lib/db-invariants.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Rv${crypto.randomBytes(12).toString('base64url')}9!`;
const accounts = [['admin', 'church_admin'], ['leader', 'cell_group_leader'], ['kiosk', 'kiosk'], ['member', 'member']];
for (const [name, role] of accounts) await createUser({ username: `rv_${name}`, email: `rv.${name}@fixture.invalid`, password: PASSWORD, displayName: `RV ${name}`, roleKeys: [role], mustChangePassword: false });

// ---- the world: six finalized Fridays, three First Timers who each visited three of the last four ----------------------------------------------
const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
setSetting('attendance.tracking_start_date', W(-6));
const sessions = {};
for (const n of [-6, -5, -4, -3, -2, -1]) {
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), `${W(n)}T09:00:00.000Z`);
  sessions[n] = db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ?").get(W(n));
}
const mk = (first, last, phone = null) => visitors.createVisitor({ first_name: first, last_name: last, phone, first_visit_date: addDays(SERVICE, -400) }, { userId: null }).id;
const ids = { convert: mk('Cora', 'Convert', '+974 5560 0001'), link: mk('Lena', 'Link', '+974 5560 0002'), cont: mk('Cleo', 'Continue', '+974 5560 0003'), spare: mk('Sam', 'Spare') };
for (const id of [ids.convert, ids.link, ids.cont]) for (const n of [-4, -3, -2]) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(id, W(n), sessions[n].id, 'x');
for (const n of [-6, -5, -4, -3, -2, -1]) assert.equal(lifecycle.finalizeAttendance(sessions[n].id, { userId: null, confirmNoAttendance: true }).ok, true);
const reviewOf = (visitorId) => db.prepare('SELECT * FROM visitor_membership_reviews WHERE visitor_id = ? ORDER BY id DESC').get(visitorId);
assert.ok(reviewOf(ids.convert) && reviewOf(ids.link) && reviewOf(ids.cont), 'three reviews are open');
assert.equal(reviewOf(ids.spare), undefined);
const existing = createMember({ first_name: 'Elsa', last_name: 'Existing', phone: '+974 5560 0002' }, { status: 'active' });
const alreadyLinked = createMember({ first_name: 'Taken', last_name: 'Member' }, { status: 'active' });
const holder = mk('Holder', 'Visitor'); visitors.linkVisitorToMember(holder, alreadyLinked.id, { userId: null });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function sessionFor(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf }) });
    return cookieOf(login, pre);
  }
  const jar = {};
  for (const [name] of accounts) jar[name] = await sessionFor(`rv.${name}@fixture.invalid`);
  const get = (url, cookie = jar.admin) => fetch(`${base}${url}`, { headers: cookie ? { Cookie: cookie } : {}, redirect: 'manual' });
  const csrfFor = async (cookie) => {
    for (const url of ['/visitors/new', '/kiosk', '/profile']) { const m = (await (await get(url, cookie)).text()).match(/name="_csrf" value="([^"]+)"/); if (m) return m[1]; }
    throw new Error('no csrf token reachable');
  };
  const post = async (url, fields = {}, cookie = jar.admin, { csrf = true } = {}) => fetch(`${base}${url}`, {
    method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ ...(csrf ? { _csrf: await csrfFor(cookie) } : {}), ...fields })
  });
  const count = (table, where = '1=1') => db.prepare(`SELECT COUNT(*) n FROM ${table} WHERE ${where}`).get().n;
  const audits = (action) => count('audit_logs', `action = '${action}'`);

  // ---- 1. access ----------------------------------------------------------------------------------------------------------------------------
  const reviewId = reviewOf(ids.cont).id;
  const adminOnly = [['GET', '/visitors/reviews'], ['GET', `/visitors/reviews/${reviewId}`], ['POST', `/visitors/reviews/${reviewId}/continue`],
    ['GET', `/visitors/${ids.spare}/convert`], ['POST', `/visitors/${ids.spare}/convert`], ['GET', `/visitors/${ids.spare}/link`], ['POST', `/visitors/${ids.spare}/link`]];
  for (const [method, url] of adminOnly) {
    const anon = method === 'GET' ? await get(url, '') : await fetch(`${base}${url}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: '' });
    assert.ok([302, 403].includes(anon.status), `${method} ${url}: anonymous is turned away (${anon.status})`);
    if (anon.status === 302) assert.match(anon.headers.get('location'), /login/);
    for (const who of ['leader', 'kiosk', 'member']) {
      const res = method === 'GET' ? await get(url, jar[who]) : await post(url, { first_name: 'X', confirm: '1', member_id: String(existing.id) }, jar[who]);
      assert.ok([302, 403].includes(res.status), `${method} ${url}: ${who} is refused (${res.status})`);
      if (res.status === 302) assert.match(res.headers.get('location'), /kiosk|login|\/$|dashboard|profile/, `${who} is sent away, not into the screen`);
    }
  }
  assert.equal(count('visitor_membership_reviews', "status != 'open'"), 0, 'none of those attempts changed a review');
  assert.equal(count('members'), 2, 'nor created a member');
  for (const who of ['leader']) assert.equal((await get('/visitors', jar[who])).status, 200, 'the leader still sees First Timers (members.view)');
  assert.equal((await post(`/visitors/${ids.spare}/convert`, { first_name: 'Sam' }, jar.admin, { csrf: false })).status, 403, 'convert needs the CSRF token');
  assert.equal((await post(`/visitors/${ids.spare}/link`, { member_id: String(existing.id), confirm: '1' }, jar.admin, { csrf: false })).status, 403, 'link needs the CSRF token');
  assert.equal((await post(`/visitors/reviews/${reviewId}/continue`, { confirm: '1' }, jar.admin, { csrf: false })).status, 403, 'continue needs the CSRF token');
  assert.equal(reviewOf(ids.cont).status, 'open');
  console.log('PASS (1) review, convert and link are for administrators only (leader, Kiosk, member and anonymous are turned away) and every post needs the CSRF token');

  // ---- 2. the review list and detail ---------------------------------------------------------------------------------------------------------
  const list = await get('/visitors/reviews');
  const listHtml = await list.text();
  assert.equal(list.status, 200); for (const name of ['Cora Convert', 'Lena Link', 'Cleo Continue']) assert.match(listHtml, new RegExp(name));
  assert.doesNotMatch(listHtml, /Sam Spare/, 'someone without a review is not listed');
  assert.match(await (await get('/visitors')).text(), /Membership review|reviews/i, 'the First Timers screen points at the reviews');
  for (const q of ['?status=bogus', '?sort=evil;DROP', '?page=999', '?page=-1&page_size=100000', '?status=all&sort=visitor&dir=asc', '?status=continued']) assert.ok((await get(`/visitors/reviews${q}`)).status < 500, `${q} never errors`);
  assert.equal((await get('/visitors/reviews/999999')).status, 404); assert.equal((await get('/visitors/reviews/abc')).status, 404);
  const detail = await (await get(`/visitors/reviews/${reviewId}`)).text();
  assert.match(detail, /3 of the last 4/); assert.match(detail, /Review later/); assert.match(detail, /Continue as visitor/); assert.match(detail, /Link to an existing member/); assert.match(detail, /new member/i);
  assert.doesNotMatch(detail, /automatically (made|converted)/i);
  console.log('PASS (2) the review list shows the suggested First Timers, tolerates hostile query strings, 404s unknown ids; the detail offers the four choices');

  // ---- 3. Review Later is a no-op; Continue as Visitor ---------------------------------------------------------------------------------------
  const snapshot = () => JSON.stringify([db.prepare('SELECT * FROM visitor_membership_reviews ORDER BY id').all(), db.prepare('SELECT COUNT(*) n FROM audit_logs').get()]);
  const s0 = snapshot();
  await get('/visitors/reviews'); await get(`/visitors/reviews/${reviewId}`); await get('/visitors/reviews'); // "Review later" is simply leaving the page
  assert.equal(snapshot(), s0, 'looking at a review and leaving it changes and audits nothing');
  const noConfirm = await post(`/visitors/reviews/${reviewId}/continue`, {});
  assert.equal(noConfirm.status, 302); assert.equal(reviewOf(ids.cont).status, 'open', 'without the confirmation box nothing happens');
  const cont = await post(`/visitors/reviews/${reviewId}/continue`, { confirm: '1', note: 'Wants more time' });
  assert.equal(cont.status, 302);
  const closed = reviewOf(ids.cont);
  assert.equal(closed.status, 'continued'); assert.equal(closed.note, 'Wants more time'); assert.ok(closed.suppress_after_date && closed.closed_at && closed.closed_by);
  assert.equal(audits('visitor.membership_review_continued'), 1);
  const again = await post(`/visitors/reviews/${reviewId}/continue`, { confirm: '1' });
  assert.equal(again.status, 302); assert.equal(audits('visitor.membership_review_continued'), 1, 'a repeat is refused and audits nothing');
  assert.equal(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(ids.cont).member_id, null, 'continuing as a visitor converts nobody');
  assert.ok((await post(`/visitors/reviews/${reviewId}/continue`, { confirm: '1', note: 'x'.repeat(5000) })).status < 500);
  console.log('PASS (3) Review Later changes nothing; Continue as Visitor needs its confirmation, records who/when/note, audits once, and a repeat is refused');

  // ---- 4. Link to an existing member ---------------------------------------------------------------------------------------------------------
  const linkReview = reviewOf(ids.link).id;
  const linkPage = await (await get(`/visitors/${ids.link}/link`)).text();
  assert.match(linkPage, /Link .* to an existing member/); assert.doesNotMatch(linkPage, /selected="selected"|checked/, 'nobody is pre-chosen: no automatic matching');
  const before = { members: count('members'), visitors: count('visitors') };
  const linkAudits0 = audits('visitor.linked_to_member'); // the setup linked one First Timer already
  for (const [label, fields, status] of [
    ['no member chosen', { confirm: '1' }, 400], ['a forged member id', { member_id: '99999999', confirm: '1' }, 400], ['a non-numeric id', { member_id: 'abc', confirm: '1' }, 400],
    ['no confirmation', { member_id: String(existing.id) }, 400], ['a member already linked to another First Timer', { member_id: String(alreadyLinked.id), confirm: '1' }, 409]
  ]) {
    const res = await post(`/visitors/${ids.link}/link`, fields);
    assert.equal(res.status, status, `${label} -> ${status}`);
    assert.equal(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(ids.link).member_id, null, `${label}: nothing changed`);
  }
  const okLink = await post(`/visitors/${ids.link}/link`, { member_id: String(existing.id), confirm: '1' });
  assert.equal(okLink.status, 302);
  assert.deepEqual(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(ids.link), { state: 'joined', member_id: existing.id });
  assert.equal(count('members'), before.members, 'linking creates no member');
  const linkedReview = db.prepare('SELECT * FROM visitor_membership_reviews WHERE id = ?').get(linkReview);
  assert.equal(linkedReview.status, 'linked'); assert.equal(linkedReview.member_id, existing.id); assert.ok(linkedReview.closed_by);
  assert.equal(audits('visitor.linked_to_member'), linkAudits0 + 1);
  assert.equal(count('visitor_visits', `visitor_id = ${ids.link}`), 4, 'their visits stay on the First Timer record (first visit + three Fridays)');
  assert.equal((await post(`/visitors/${ids.link}/link`, { member_id: String(existing.id), confirm: '1' })).status, 409, 'a second link is refused');
  assert.equal(audits('visitor.linked_to_member'), linkAudits0 + 1, 'and writes no second audit row');
  const profile = await (await get(`/members/${existing.id}`)).text();
  assert.match(profile, /Before membership/, 'the member profile shows where they came from');
  assert.match(profile, new RegExp('4 visits recorded')); assert.match(profile, /not attendance records/);
  console.log('PASS (4) Link is an explicit choice (nothing pre-selected), refuses forged, unconfirmed and already-taken members, writes the link, closes the review and audits once; the member profile shows "Before membership"');

  // ---- 5. Convert to a new member -----------------------------------------------------------------------------------------------------------
  const convReview = reviewOf(ids.convert).id;
  const form = await (await get(`/visitors/${ids.convert}/convert`)).text();
  assert.match(form, /name="first_name" value="Cora"/, 'the form is pre-filled from the First Timer');
  assert.match(form, new RegExp(`name="date_joined" value="${today()}"`), 'the join date defaults to today');
  const members0 = count('members');
  assert.equal((await post(`/visitors/${ids.convert}/convert`, { first_name: '' })).status, 400, 'a missing name is a 400');
  assert.equal(count('members'), members0, 'and creates nothing');
  const warn = await post(`/visitors/${ids.convert}/convert`, { first_name: 'Elsa', last_name: 'Existing', phone: '+974 5560 0002', date_joined: today() });
  const warnHtml = await warn.text();
  assert.equal(warn.status, 200); assert.match(warnHtml, /link them instead/i, 'a possible duplicate offers Link instead'); assert.equal(count('members'), members0, 'and nothing is created until it is confirmed');
  const okConvert = await post(`/visitors/${ids.convert}/convert`, { first_name: 'Cora', last_name: 'Convert', phone: '+974 5560 0001', status: 'active', date_joined: today() });
  assert.equal(okConvert.status, 302); assert.match(okConvert.headers.get('location'), /^\/members\/\d+$/);
  const memberId = Number(okConvert.headers.get('location').split('/').pop());
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(memberId);
  assert.equal(member.status, 'pending', 'always Pending, whatever the form posted'); assert.equal(member.date_joined, today()); assert.equal(count('members'), members0 + 1);
  assert.equal(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(ids.convert).member_id, memberId);
  const convReviewRow = db.prepare('SELECT * FROM visitor_membership_reviews WHERE id = ?').get(convReview);
  assert.equal(convReviewRow.status, 'converted'); assert.equal(convReviewRow.member_id, memberId);
  assert.equal(audits('visitor.became_member'), 1);
  assert.equal(count('member_status_history', `member_id = ${memberId}`), 1, 'one status-history row for the new member');
  assert.equal((await post(`/visitors/${ids.convert}/convert`, { first_name: 'Cora', last_name: 'Convert' })).status, 409, 'a second conversion is refused');
  assert.equal(count('members'), members0 + 1);
  assert.equal(db.prepare('SELECT qr_token FROM members WHERE id = ?').get(memberId).qr_token ?? null, null, 'no QR code is issued by converting');
  assert.match(await (await get(`/members/${memberId}`)).text(), /Before membership/);
  assert.equal((await get(`/visitors/${ids.convert}/convert`)).status, 302, 'the convert form is no longer offered');
  console.log('PASS (5) Convert is explicit, pre-filled, warns about duplicates and offers Link, creates one Pending member joined today with history, closes the review, issues no QR code, audits once and refuses a repeat');

  // ---- 6. the "joined" outcome cannot be forged; integrity ------------------------------------------------------------------------------------
  const forged = await post(`/visitors/${ids.spare}/state`, { state: 'joined' });
  assert.equal(forged.status, 400); assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(ids.spare).state, 'new');
  const settled = await post(`/visitors/${ids.convert}/state`, { state: 'declined' });
  assert.ok([400, 409].includes(settled.status), `a converted First Timer's outcome is read-only (${settled.status})`);
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(ids.convert).state, 'joined');
  const findings = checkInvariants(db).findings.filter((f) => f.severity === 'error' && /^(visitor|review|member)./.test(f.code)); // the fixture has no Super Administrator, which is unrelated
  assert.deepEqual(findings, [], 'the integrity checker reports no errors after all of that');
  const noReview = await get(`/members/${alreadyLinked.id}`); assert.equal(noReview.status, 200);
  const plainMember = createMember({ first_name: 'Never', last_name: 'Visitor' }, { status: 'active' });
  assert.doesNotMatch(await (await get(`/members/${plainMember.id}`)).text(), /Before membership/, 'a member who was never a First Timer has no such card');
  console.log('PASS (6) "joined" cannot be forged or changed after conversion; the integrity checker is clean; members who were never First Timers show no card');
  console.log('ALL PASS');
} finally {
  await terminateAndWait(server);
}
