import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ejs from 'ejs';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Verse of the Day (NIV): one verse per Qatar calendar day, the same on the portal header and the Attendance Kiosk header, from a local curated list.
 *   - the collection: NIV only, structured, varied (all 18 themes), far inside Biblica's quotation terms (<= 500 verses, no whole book), with the required notice;
 *   - the choice: a pure function of the Qatar date: stable, changes at Qatar midnight (not UTC midnight), every verse once per cycle, neighbouring days differ in theme;
 *   - delivery: the same verse on both headers and every page, no request of its own, escaped;
 *   - the header: shows only where there is room, never moves or squeezes a control, never adds height or sideways scroll, and the whole verse opens in an accessible panel.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
// The isolated environment comes first: nothing from src/ may be imported before it exists.
const f = await buildPortalFixture('cciq-verse-');
const { db, users } = f;
const { NIV_VERSES, NIV_NOTICE, NIV_MAX_VERSES, NIV_TRANSLATION, NIV_TRANSLATION_NAME } = await import('../lib/verses-niv.js');
const { verseForDate, verseOrder, dayNumber } = await import('../lib/verse-of-the-day.js');

// ---- the collection -------------------------------------------------------------------------------------------------------------------------------------------
{
  const REQUIRED = ['faith', 'love', 'hope', 'prayer', 'service', 'fellowship', 'encouragement', 'wisdom', 'perseverance', 'generosity', 'worship', 'family', 'unity', 'discipleship', 'strength', 'grace', 'peace', 'thanksgiving'];
  assert.equal(NIV_TRANSLATION, 'NIV');
  assert.equal(NIV_TRANSLATION_NAME, 'New International Version');
  assert.match(NIV_NOTICE, /^Scripture quotations taken from The Holy Bible, New International Version® NIV® Copyright © 1973, 1978, 1984, 2011 by Biblica, Inc\.® Used by permission\. All rights reserved worldwide\.$/, 'the Biblica notice, in full');
  const themes = new Map();
  const refs = new Set();
  let verseCount = 0;
  for (const v of NIV_VERSES) {
    assert.ok(v.ref && v.text && v.theme, `every entry has a reference, the NIV text and a theme (${JSON.stringify(v).slice(0, 60)})`);
    const m = /^(\d )?[A-Z][A-Za-z]+( [A-Za-z]+)* (\d+):(\d+)(-(\d+))?$/.exec(v.ref);
    assert.ok(m, `${v.ref}: a chapter-and-verse reference (a whole book or chapter is never quoted)`);
    verseCount += m[6] ? Number(m[6]) - Number(m[4]) + 1 : 1;
    assert.ok(!refs.has(v.ref), `${v.ref} is listed once`);
    refs.add(v.ref);
    assert.ok(v.text.length <= 520, `${v.ref} is a short passage (${v.text.length} characters)`);
    assert.ok(REQUIRED.includes(v.theme), `${v.ref}: a known theme (${v.theme})`);
    themes.set(v.theme, (themes.get(v.theme) || 0) + 1);
    assert.doesNotMatch(v.text, /<|>|&[a-z]+;|\{\{|\$\{/, `${v.ref}: plain text only`);
  }
  assert.ok(NIV_VERSES.length <= NIV_MAX_VERSES && NIV_MAX_VERSES <= 500, `at most ${NIV_MAX_VERSES} entries, far inside the 500-verse limit`);
  assert.ok(verseCount <= 500, `${verseCount} verses in all (limit 500 without written permission)`);
  for (const theme of REQUIRED) assert.ok((themes.get(theme) || 0) >= 3, `theme "${theme}" has at least three verses (${themes.get(theme) || 0})`);
  assert.ok(NIV_VERSES.length >= 100, `a varied collection (${NIV_VERSES.length} entries)`);
  const biggestTheme = Math.max(...themes.values());
  assert.ok(biggestTheme <= NIV_VERSES.length * 0.15, `no theme dominates (largest ${biggestTheme} of ${NIV_VERSES.length})`);
  // NIV only: no other translation is named or mixed in anywhere the verse feature lives
  for (const file of ['src/lib/verses-niv.js', 'src/lib/verse-of-the-day.js', 'src/views/partials/verse-of-the-day.ejs']) {
    const text = fs.readFileSync(path.join(root, file), 'utf8');
    assert.doesNotMatch(text.replace(/New International Version/g, ''), /\b(KJV|NKJV|ESV|NLT|NASB|NRSV|ASV|CSB|NET Bible|Message)\b/, `${file} names no other translation`);
    assert.doesNotMatch(text, /\bfetch\(|XMLHttpRequest|https?:\/\/(?!www\.w3\.org)/, `${file} makes no request and links nowhere`);
  }
  console.log(`PASS (collection) ${NIV_VERSES.length} NIV entries (${verseCount} verses; limit 500), all 18 themes (${[...themes.values()].sort((a, b) => a - b)[0]} to ${biggestTheme} each), unique chapter-and-verse references, short passages, the Biblica notice in full, no other translation, no network call in the feature's code`);
}

// ---- the choice -----------------------------------------------------------------------------------------------------------------------------------------------
{
  const n = NIV_VERSES.length;
  assert.deepEqual(verseForDate('2026-10-02'), verseForDate('2026-10-02'), 'the same date always gives the same verse');
  assert.equal(verseForDate('2026-10-02').translation, 'NIV');
  const seen = new Set();
  const days = [];
  for (let i = 0; i < n; i += 1) { const date = new Date(Date.UTC(2026, 0, 1 + i)).toISOString().slice(0, 10); const v = verseForDate(date); seen.add(v.reference); days.push(v); }
  assert.equal(seen.size, n, `every verse appears exactly once in a ${n}-day cycle before any repeats`);
  assert.equal(verseForDate(new Date(Date.UTC(2026, 0, 1 + n)).toISOString().slice(0, 10)).reference, days[0].reference, 'and the cycle then repeats');
  let sameTheme = 0;
  for (let i = 1; i < days.length; i += 1) if (days[i].theme === days[i - 1].theme) sameTheme += 1;
  assert.equal(sameTheme, 0, 'two neighbouring days never share a theme');
  const year = new Map();
  for (let i = 0; i < 365; i += 1) { const v = verseForDate(new Date(Date.UTC(2027, 0, 1 + i)).toISOString().slice(0, 10)); year.set(v.reference, (year.get(v.reference) || 0) + 1); }
  assert.ok(Math.max(...year.values()) <= Math.ceil(365 / n) + 1, `in a year no verse is repeated more than ${Math.ceil(365 / n) + 1} times`);
  assert.ok(year.size >= n - 1, 'a year uses essentially the whole list');
  assert.equal(dayNumber('1970-01-01'), 0);
  assert.equal(dayNumber('2026-10-02') - dayNumber('2026-10-01'), 1);
  assert.equal(verseOrder().length, n);
  // editing the list is all it takes to change what is offered (a shorter list still works, an empty one gives no verse)
  const small = [{ ref: 'John 3:16', text: 'x', theme: 'love' }, { ref: 'John 14:6', text: 'y', theme: 'faith' }];
  assert.ok(['John 3:16', 'John 14:6'].includes(verseForDate('2026-10-02', small).reference));
  assert.equal(verseForDate('2026-10-02', []), null);
  console.log(`PASS (choice) a pure function of the date; all ${n} verses once per cycle then repeating; no neighbouring days share a theme; a year repeats none more than ${Math.ceil(365 / n) + 1} times; any list length works`);
}

// ---- Qatar midnight, not UTC midnight ----------------------------------------------------------------------------------------------------------------------------------
{
  const RealDate = Date;
  const clockAt = (iso) => { const fixed = new RealDate(iso).getTime(); globalThis.Date = class extends RealDate { constructor(...a) { if (a.length === 0) super(fixed); else super(...a); } static now() { return fixed; } }; };
  const { verseOfTheDay } = await import('../lib/verse-of-the-day.js');
  try {
    const at = (iso) => { clockAt(iso); return verseOfTheDay(); };
    const lateThursday = at('2026-10-01T20:59:59Z'); // 23:59:59 in Qatar, Thursday 1 October
    const midnight = at('2026-10-01T21:00:00Z'); // 00:00:00 in Qatar, Friday 2 October
    const earlyFriday = at('2026-10-01T22:30:00Z'); // 01:30 Qatar, still Friday although it is Thursday in UTC
    const utcMidnight = at('2026-10-02T00:00:00Z'); // UTC midnight: 03:00 Qatar, the same Friday
    const lateFriday = at('2026-10-02T20:59:59Z'); // 23:59:59 Qatar, Friday
    const saturday = at('2026-10-02T21:00:00Z');
    assert.equal(lateThursday.date, '2026-10-01');
    assert.equal(midnight.date, '2026-10-02', 'the verse changes at Qatar midnight');
    assert.equal(lateThursday.reference, verseForDate('2026-10-01').reference);
    assert.equal(midnight.reference, verseForDate('2026-10-02').reference);
    assert.notEqual(lateThursday.reference, midnight.reference);
    assert.equal(earlyFriday.reference, midnight.reference, '01:30 in Qatar is already Friday\'s verse (it is still Thursday in UTC)');
    assert.equal(utcMidnight.reference, midnight.reference, 'UTC midnight does NOT change the verse');
    assert.equal(lateFriday.reference, midnight.reference, 'the verse is stable for the whole Qatar day');
    assert.equal(saturday.date, '2026-10-03');
    assert.notEqual(saturday.reference, lateFriday.reference);
  } finally { globalThis.Date = RealDate; }
  console.log('PASS (Qatar date) 23:59:59 Qatar time is still Thursday\'s verse; 00:00:00 Qatar time (21:00 UTC) is Friday\'s; UTC midnight changes nothing; the verse is steady all day and changes again at the next Qatar midnight');
}

// ---- escaping ---------------------------------------------------------------------------------------------------------------------------------------------------------------
{
  const hostile = { reference: '<img src=x onerror=alert(1)>', text: '<script>alert(1)</script>', display: '“<script>alert(1)</script>”', theme: 'faith', translation: 'NIV', translationName: 'New International Version', notice: 'n<b>' };
  const html = await ejs.renderFile(path.join(root, 'src', 'views', 'partials', 'verse-of-the-day.ejs'), { verseOfTheDay: hostile, variant: 'portal' });
  assert.ok(!html.includes('<script>') && !html.includes('<img') && !html.includes('<b>'), 'verse content is escaped, never markup');
  assert.match(html, /&lt;script&gt;/);
  assert.equal((await ejs.renderFile(path.join(root, 'src', 'views', 'partials', 'verse-of-the-day.ejs'), { verseOfTheDay: null })).trim(), '', 'no verse, no markup');
  console.log('PASS (escaping) hostile verse text and reference are escaped; an empty list renders nothing');
}

// ---- the same verse everywhere, nothing external --------------------------------------------------------------------------------------------------------------------------------
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const { today } = await import('../lib/dates.js');
  const expected = verseForDate(today());
  const grab = (html) => {
    const cite = html.match(/<cite class="votd__ref">([^<]*)<\/cite>/)?.[1].replace(/&middot;/g, '·').trim();
    const text = html.match(/<span class="votd__text">([^<]*)<\/span>/)?.[1];
    const full = html.match(/<blockquote class="votd__full">([^<]*)<\/blockquote>/)?.[1];
    return { cite, text, full };
  };
  const decode = (s) => s.replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&');
  const seen = new Set();
  for (const [who, urls] of [[admin, ['/', '/members', '/attendance', '/reports', '/cell-groups', '/about', '/search?q=a']], [kiosk, ['/kiosk', '/kiosk', '/attendance/checkin/first-timer']]]) {
    for (const url of urls) {
      const html = await (await who.get(url)).text();
      const v = grab(html);
      assert.ok(v.cite, `${url}: shows the verse`);
      assert.equal(decode(v.text), expected.display, `${url}: today's verse text`);
      assert.equal(decode(v.full), expected.display);
      assert.equal(v.cite, `${expected.reference} · NIV`, `${url}: reference and NIV`);
      assert.ok(html.includes(NIV_NOTICE.replace(/&/g, '&amp;')) || html.includes('Used by permission'), `${url}: the NIV notice is in the page`);
      assert.doesNotMatch(html.slice(html.indexOf('votd'), html.indexOf('votd') + 2500), /\b(KJV|NKJV|ESV|NLT|NASB)\b/);
      seen.add(`${v.cite}|${v.text}`);
    }
  }
  assert.equal(seen.size, 1, 'the portal and the Kiosk, on every page and every refresh, show exactly the same verse');
  const loginHtml = await (await fetch(`${portal.base}/login`)).text();
  assert.ok(!loginHtml.includes('votd'), 'the sign-in page has no header widget');
  // the sign-in page shows the SAME verse as plain text beside the form (its own layout), escaped like everywhere else
  const escaped = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&#34;').replace(/'/g, '&#39;');
  assert.ok(loginHtml.includes(`<blockquote class="auth__verse-text">${escaped(expected.display)}</blockquote>`), 'the sign-in page shows the day\'s verse');
  console.log(`PASS (same verse) ${expected.reference} (NIV) on the portal (7 pages) and the Kiosk (3 pages), identical text, reference and notice on every load`);

  // no request of its own: every request a portal page and a Kiosk page make is to this server
  for (const [label, who, url] of [['portal', admin, '/'], ['kiosk', kiosk, '/kiosk']]) {
    const context = await browser.newContext();
    await context.addCookies(who.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    const external = [];
    page.on('request', (r) => { const u = new URL(r.url()); if (!['127.0.0.1', 'localhost'].includes(u.hostname) && u.protocol.startsWith('http')) external.push(r.url()); });
    await page.goto(portal.base + url, { waitUntil: 'networkidle' });
    assert.deepEqual(external, [], `${label}: nothing outside this server was requested`);
    const scripts = await page.evaluate(() => [...document.scripts].map((s) => s.src));
    assert.ok(scripts.every((s) => s.startsWith(new URL(portal.base).origin)), `${label}: only this server's scripts`);
    await context.close();
  }
  console.log('PASS (local only) a portal page and a Kiosk page request nothing from outside this server and load no third-party script');

  // ---- the headers, at every width, on both layouts ---------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  const widths = [320, 360, 390, 430, 600, 768, 820, 1024, 1280, 1440, 1920];
  for (const [label, who, url, selectors] of [
    ['portal', admin, '/', { header: '.topbar', controls: ['.topbar__bell', '.topbar__user', '.topbar__search', '.topbar__menu', '.brand--compact', '.topbar__search-toggle'] }],
    ['kiosk', kiosk, '/kiosk', { header: '.kiosk__bar', controls: ['.kiosk__identity', '.kiosk__bar form .btn', '.kiosk__bar .brand'] }]
  ]) {
    const context = await browser.newContext();
    await context.addCookies(who.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    for (const width of widths) {
      const page = await context.newPage();
      await page.setViewportSize({ width, height: 800 });
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const measure = (hideVerse) => page.evaluate(({ sel, hide }) => {
        const style = document.createElement('style'); style.id = 'votd-off'; style.textContent = '.votd { display: none !important; }';
        if (hide) document.head.appendChild(style); else document.getElementById('votd-off')?.remove();
        const r = (el) => { const b = el.getBoundingClientRect(); return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height), right: Math.round(b.right), bottom: Math.round(b.bottom) }; };
        const header = document.querySelector(sel.header);
        const controls = {};
        for (const c of sel.controls) { const el = document.querySelector(c); if (el) { const b = el.getBoundingClientRect(); if (b.width > 0 && b.height > 0) controls[c] = r(el); } }
        const votd = document.querySelector('.votd'); const summary = document.querySelector('.votd__summary');
        const signOut = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Sign out' && b.getBoundingClientRect().width > 0);
        return { header: r(header), controls, shown: getComputedStyle(votd).display !== 'none', summary: summary && getComputedStyle(votd).display !== 'none' ? r(summary) : null,
          slot: r(document.querySelector('.topbar__verse-slot, .kiosk__verse-slot')), overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
          signOutH: signOut ? Math.round(signOut.getBoundingClientRect().height) : null, signOutLines: signOut ? Math.round(signOut.getBoundingClientRect().height / parseFloat(getComputedStyle(signOut).lineHeight || '20')) : null };
      }, { sel: selectors, hide: hideVerse });
      const without = await measure(true);
      const withVerse = await measure(false);
      const tag = `${label} ${width}px`;
      if (withVerse.overflow > 0) problems.push(`${tag}: sideways scroll ${withVerse.overflow}px`);
      const ownRow = label === 'kiosk' && width < 900; // a narrow Kiosk gives the verse its own full-width row UNDER the controls, so the bar is taller by exactly that row
      if (!ownRow && withVerse.header.h !== without.header.h) problems.push(`${tag}: the header grew from ${without.header.h}px to ${withVerse.header.h}px`);
      for (const [c, box] of Object.entries(withVerse.controls)) {
        const was = without.controls[c];
        if (!was) { problems.push(`${tag}: ${c} appeared only with the verse`); continue; }
        if (Math.abs(box.x - was.x) > 1 || Math.abs(box.y - was.y) > 1 || Math.abs(box.w - was.w) > 1 || Math.abs(box.h - was.h) > 1) problems.push(`${tag}: ${c} was moved or resized by the verse (${JSON.stringify(was)} -> ${JSON.stringify(box)})`);
      }
      if (withVerse.summary) {
        for (const [c, box] of Object.entries(withVerse.controls)) {
          const overlap = !(withVerse.summary.right <= box.x || box.right <= withVerse.summary.x || withVerse.summary.bottom <= box.y || box.bottom <= withVerse.summary.y);
          if (overlap) problems.push(`${tag}: the verse overlaps ${c}`);
        }
        if (withVerse.summary.w < 240) problems.push(`${tag}: the verse is squeezed to ${withVerse.summary.w}px`);
        if (withVerse.summary.right > withVerse.slot.right + 1 || withVerse.summary.x < withVerse.slot.x - 1) problems.push(`${tag}: the verse leaves its slot`);
      }
      if (label === 'kiosk' && !withVerse.shown) problems.push(`${tag}: the Kiosk verse must be visible at every width`);
      if (label === 'portal' && withVerse.slot.w >= 300 && !withVerse.shown) problems.push(`${tag}: there is room (${withVerse.slot.w}px) but the verse is hidden`);
      if (label === 'portal' && withVerse.slot.w < 300 && withVerse.shown) problems.push(`${tag}: no room (${withVerse.slot.w}px) but the verse is shown`);
      if (withVerse.signOutH !== null && withVerse.signOutH > 52) problems.push(`${tag}: Sign out is ${withVerse.signOutH}px high (wrapped)`);
      await page.close();
    }
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('\n'));
  console.log(`PASS (headers) portal and Kiosk at ${widths.join(', ')} px: with the verse, no header is taller, no control moves or resizes, nothing overlaps, no sideways scroll, Sign out never wraps; the verse shows exactly when its slot is at least 300px wide (the real room, not the window) and is never squeezed under 240px`);

  // ---- which widths show it (documented behaviour) -------------------------------------------------------------------------------------------------------------------------------
  {
    const context = await browser.newContext();
    await context.addCookies(admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const shownAt = {};
    for (const width of widths) {
      const page = await context.newPage();
      await page.setViewportSize({ width, height: 800 });
      await page.goto(portal.base + '/', { waitUntil: 'load' });
      shownAt[width] = await page.evaluate(() => getComputedStyle(document.querySelector('.votd')).display !== 'none');
      await page.close();
    }
    assert.equal(shownAt[1920] && shownAt[1440] && shownAt[1280], true, 'desktop and wide laptop show it');
    assert.equal(shownAt[320] || shownAt[360] || shownAt[390], false, 'a phone does not (the controls come first)');
    assert.equal(shownAt[600], false, 'nor does a small tablet in portrait');
    console.log(`PASS (priority) portal: ${widths.map((w) => `${w}px ${shownAt[w] ? 'shows' : 'hides'}`).join(', ')}`);
    await context.close();
  }

  // ---- the full-verse panel: keyboard, focus, position -------------------------------------------------------------------------------------------------------------------------
  for (const [label, who, url, width] of [['portal', admin, '/', 1440], ['portal narrow', admin, '/', 1024], ['kiosk', kiosk, '/kiosk', 1280], ['kiosk narrow', kiosk, '/kiosk', 820]]) {
    const context = await browser.newContext();
    await context.addCookies(who.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.setViewportSize({ width, height: 700 });
    await page.goto(portal.base + url, { waitUntil: 'load' });
    const summary = page.locator('.votd__summary');
    if (!(await summary.isVisible())) { await context.close(); continue; }
    // keyboard only: Tab to it (it is a native disclosure), Enter opens, the panel holds the whole verse, reference, translation and notice
    await page.focus('body');
    for (let i = 0; i < 12; i += 1) { await page.keyboard.press('Tab'); if (await page.evaluate(() => document.activeElement?.classList.contains('votd__summary'))) break; }
    assert.equal(await page.evaluate(() => document.activeElement?.classList.contains('votd__summary')), true, `${label}: the verse is reachable with Tab`);
    const ring = await summary.evaluate((el) => { const s = getComputedStyle(el); return s.outlineStyle !== 'none' && parseFloat(s.outlineWidth) >= 2; });
    assert.ok(ring, `${label}: it shows a keyboard focus ring`);
    await page.keyboard.press('Enter');
    assert.equal(await page.locator('.votd__details').evaluate((d) => d.open), true, `${label}: Enter opens it`);
    const panel = page.locator('.votd__panel');
    assert.equal(await panel.isVisible(), true);
    const text = await panel.innerText();
    assert.ok(text.includes(expected.text.replace(/^“|”$/g, '').slice(0, 40)), `${label}: the whole verse is in the panel`);
    assert.ok(text.includes(expected.reference) && text.includes('New International Version') && text.includes('Biblica, Inc.'), `${label}: reference, translation and the NIV notice`);
    const box = await panel.boundingBox();
    assert.ok(box.x >= 0 && box.x + box.width <= width + 0.5, `${label}: the panel stays on screen (${Math.round(box.x)} to ${Math.round(box.x + box.width)} of ${width})`);
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth), 0, `${label}: opening it causes no sideways scroll`);
    assert.equal(page.url().startsWith(portal.base + url), true, `${label}: the page did not change`);
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('.votd__details').evaluate((d) => d.open), false, `${label}: Escape closes it`);
    assert.equal(await page.evaluate(() => document.activeElement?.classList.contains('votd__summary')), true, `${label}: focus returns to the verse`);
    await page.keyboard.press('Space');
    assert.equal(await page.locator('.votd__details').evaluate((d) => d.open), true, `${label}: Space opens it too`);
    await page.mouse.click(width / 2, 650);
    assert.equal(await page.locator('.votd__details').evaluate((d) => d.open), false, `${label}: a click elsewhere closes it`);
    await summary.click();
    assert.equal(await page.locator('.votd__details').evaluate((d) => d.open), true, `${label}: a click or tap opens it`);
    await context.close();
  }
  console.log('PASS (reveal) portal and Kiosk: reachable by Tab with a focus ring; Enter, Space, a click or a tap opens the whole verse, reference, translation and NIV notice without leaving the page; the panel stays on screen with no sideways scroll; Escape returns focus to the verse; a click elsewhere closes it');

  // ---- print --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const context = await browser.newContext();
    await context.addCookies(admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.setViewportSize({ width: 1440, height: 700 });
    await page.goto(portal.base + '/', { waitUntil: 'load' });
    await page.emulateMedia({ media: 'print' });
    assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('.votd')).display), 'none', 'the verse is not printed');
    await context.close();
  }
} finally {
  await browser.close();
  await portal.stop();
}
db.close();
f.env.cleanup();
console.log('ALL PASS');
