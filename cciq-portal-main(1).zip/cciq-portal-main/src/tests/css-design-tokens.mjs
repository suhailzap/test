import assert from 'node:assert/strict';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

/*
 * The stylesheet's design tokens must actually exist. A var(--x) with no definition and no fallback makes the whole
 * declaration invalid - which once left the dashboard's attendance bars transparent, the keyboard focus ring on the top
 * bar invisible and three status pills without a background. Also pins the density standard (docs/UX-STANDARDS.md).
 */

const css = fs.readFileSync(fileURLToPath(new URL('../public/css/cciq.css', import.meta.url)), 'utf8');
const defined = new Set([...css.matchAll(/(--[a-z0-9-]+)\s*:/gi)].map((m) => m[1]));
const used = [...css.matchAll(/var\((--[a-z0-9-]+)\s*([,)])/gi)].map((m) => ({ name: m[1], fallback: m[2] === ',' }));
const undefinedTokens = [...new Set(used.filter((u) => !u.fallback && !defined.has(u.name)).map((u) => u.name))];
assert.deepEqual(undefinedTokens, [], `every design token used without a fallback is defined (missing: ${undefinedTokens.join(', ')})`);
console.log(`PASS (tokens) all ${new Set(used.map((u) => u.name)).size} design tokens used by the stylesheet are defined`);

// The density standard: phone values in :root, one desktop block, kiosk excluded, touch desktops keep big targets.
for (const token of ['--fs-body', '--fs-control', '--fs-label', '--fs-help', '--control-h', '--btn-h', '--btn-h-sm', '--space-card', '--space-field', '--gap-label', '--gap-help', '--cell-pad']) {
  assert.ok(defined.has(token), `${token} is a defined density token`);
}
const desktop = css.match(/@media \(min-width: 861px\) \{\s*body:not\(\.kiosk\) \{([\s\S]*?)\n  \}/);
assert.ok(desktop, 'the desktop density block exists and excludes the kiosk');
const px = (name) => Number(new RegExp(`${name}:\\s*([\\d.]+)px`).exec(desktop[1])[1]);
assert.ok(px('--fs-body') >= 14 && px('--fs-body') <= 15, 'desktop body/table/nav text is about 14-15px');
assert.ok(px('--fs-control') >= 14 && px('--fs-control') <= 15, 'desktop control text is about 14-15px');
assert.ok(px('--control-h') >= 36 && px('--control-h') <= 40, 'desktop controls are about 38px tall');
assert.match(css, /@media \(min-width: 861px\) and \(pointer: coarse\)[\s\S]*--control-h: 44px/, 'a touch tablet in landscape keeps 44px targets');
const root = css.match(/:root \{([\s\S]*?)\n\}/)[1];
assert.match(root, /--fs-body:\s*15\.5px/, 'phones keep the roomier size');
assert.match(root, /--control-h:\s*42px/);
console.log('PASS (density) desktop body/table/nav about 14.5px, controls about 38px, touch tablets keep 44px, phones keep the roomier defaults, kiosk excluded');
console.log('ALL PASS');
