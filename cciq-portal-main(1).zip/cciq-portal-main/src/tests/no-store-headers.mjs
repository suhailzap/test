import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-nostore-test-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

await createUser({
  email: 'nostore.subject@fixture.invalid', password: 'TestPassw0rd!2026',
  displayName: 'No Store Test', roleKeys: ['super_admin'], mustChangePassword: false
});

// --- 1. The login page (no session) is unaffected either way — not the point
//        of this check, but confirms the middleware doesn't error out. ---
const loginRes = await fetch(`${base}/login`);
assert.equal(loginRes.status, 200);

// --- 2. Sign in, then confirm an authenticated page carries Cache-Control:
//        no-store, so a shared computer's back button / disk cache cannot
//        redisplay it after sign-out. ---
const csrfMatch = (await loginRes.text()).match(/name="_csrf" value="([^"]+)"/);
const cookieJar = loginRes.headers.getSetCookie ? loginRes.headers.getSetCookie() : [loginRes.headers.get('set-cookie')];
const cookie = cookieJar.map((c) => c.split(';')[0]).join('; ');

const loginPost = await fetch(`${base}/login`, {
  method: 'POST', redirect: 'manual',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
  body: new URLSearchParams({ email: 'nostore.subject@fixture.invalid', password: 'TestPassw0rd!2026', _csrf: csrfMatch[1] })
});
const sessionCookie = (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
  .map((c) => c.split(';')[0]).join('; ') || cookie;

const membersRes = await fetch(`${base}/members`, { headers: { Cookie: sessionCookie } });
assert.equal(membersRes.status, 200, 'should reach the authenticated Members page');
assert.equal(membersRes.headers.get('cache-control'), 'no-store',
  `an authenticated page must set Cache-Control: no-store, got "${membersRes.headers.get('cache-control')}"`);
console.log('PASS: an authenticated page response carries Cache-Control: no-store');

// --- 3. A static asset served before attachUser must keep its own, separate
//        long-lived cache header — the new middleware must not touch it. ---
const cssRes = await fetch(`${base}/css/cciq.css`);
const cssCache = cssRes.headers.get('cache-control') || '';
assert.ok(cssCache.includes('max-age'), `a static asset must keep its own long-lived cache header, got "${cssCache}"`);
assert.notEqual(cssCache, 'no-store', 'a static asset must not be forced to no-store');
console.log('PASS: static assets keep their own cache header, unaffected by the new middleware');

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
