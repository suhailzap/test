import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import Database from 'better-sqlite3';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Attendance Go-Live & Finalization, Phase 2A: schema + core foundation.
 *
 * Covers migration 0029 (applied to a real 0028-shaped database through the
 * explicit migration command, then re-run), the attendance.finalize
 * permission, the attendance.tracking_start_date setting, the session
 * classification helpers, the deterministic status-as-of-Friday resolver, the
 * expected-roster snapshot primitives, member-deletion protection, and the
 * read-only status-history diagnostic.
 *
 * Nothing here touches a real database: every database is a disposable
 * fixture under the OS temp directory, and no Go-Live date is ever set outside
 * a fixture.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-attendance-foundation-');
const sha256File = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const url = (rel) => pathToFileURL(path.join(root, rel)).href;

// =====================================================================
// 1. Migration 0029 against a genuine 0028-shaped database.
// =====================================================================

const migDir = path.join(env.root, 'migration-fixture');
fs.mkdirSync(migDir, { recursive: true });
const migDb = path.join(migDir, 'fixture.sqlite');
function childEnvFor(databaseFile) {
  return {
    ...process.env,
    NODE_ENV: 'test',
    DOTENV_CONFIG_PATH: path.join(migDir, 'absent.env'),
    DATABASE_FILE: databaseFile,
    STORAGE_DIR: path.join(migDir, 'storage'),
    BACKUP_DIR: path.join(migDir, 'backups'),
    SESSION_SECRET: crypto.randomBytes(32).toString('hex')
  };
}
function runModule(script, databaseFile) {
  const proc = spawnSync(process.execPath, ['--input-type=module', '-e', script], { env: childEnvFor(databaseFile), encoding: 'utf8' });
  assert.equal(proc.status, 0, `child failed: ${proc.stdout}\n${proc.stderr}`);
  return proc.stdout;
}

// Build a current-schema database with roles, permissions and attendance data
// exactly as the application would have written it, then rewind it to 0028.
runModule(`
  const { migrate } = await import(${JSON.stringify(url('src/db/migrate.js'))}); migrate();
  const { seedRolesAndPermissions } = await import(${JSON.stringify(url('src/db/seed.js'))}); seedRolesAndPermissions();
  const { createMember } = await import(${JSON.stringify(url('src/services/members.js'))});
  const { default: db } = await import(${JSON.stringify(url('src/db/index.js'))});
  const a = createMember({ first_name: 'Ada', last_name: 'One' }, { status: 'active' });
  const b = createMember({ first_name: 'Ben', last_name: 'Two' }, { status: 'active' });
  const c = createMember({ first_name: 'Cy', last_name: 'Three' }, { status: 'attendee' });
  const at = '2026-03-01T10:00:00.000Z';
  const ins = db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  const s1 = ins.run('2026-03-06', 'friday_service', 'Friday one', 'held', 1, 0, 'note one', at).lastInsertRowid;
  const s2 = ins.run('2026-03-13', 'friday_service', 'Friday two', 'scheduled', 1, 0, null, at).lastInsertRowid;
  ins.run('2026-03-10', 'special_service', 'Special', 'cancelled', 0, 0, 'cancelled', at);
  const rec = db.prepare("INSERT INTO attendance_records (session_id, member_id, status, notes, recorded_at, source) VALUES (?, ?, ?, ?, ?, ?)");
  rec.run(s1, a.id, 'present', null, at, 'manual');
  rec.run(s1, b.id, 'excused', 'away', at, 'manual');
  rec.run(s1, c.id, 'absent', null, at, 'manual');
  rec.run(s2, a.id, 'visitor', null, at, 'qr_checkin');
  db.prepare("INSERT INTO qr_checkins (member_id, session_id, checked_in_at) VALUES (?, ?, ?)").run(a.id, s1, at);
  db.close();
`, migDb);

// Rewind to the 0028 shape: rebuild attendance_sessions without the new
// columns (the standard SQLite table-rebuild procedure), drop the new table,
// permission and migration row.
{
  const conn = new Database(migDb);
  conn.pragma('foreign_keys = OFF');
  conn.exec(`
    BEGIN;
    DROP TABLE attendance_expected;
    CREATE TABLE attendance_sessions_0028 (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      service_date  TEXT NOT NULL,
      service_type  TEXT NOT NULL DEFAULT 'friday_service'
                      CHECK (service_type IN ('friday_service','special_service','church_activity','cell_group')),
      title         TEXT,
      start_time    TEXT,
      location      TEXT,
      cell_group_id INTEGER NOT NULL DEFAULT 0,
      status        TEXT NOT NULL DEFAULT 'scheduled'
                      CHECK (status IN ('scheduled','held','cancelled')),
      counts_toward_followup INTEGER NOT NULL DEFAULT 1,
      notes         TEXT,
      created_at    TEXT NOT NULL,
      created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
      UNIQUE (service_date, service_type, cell_group_id)
    );
    INSERT INTO attendance_sessions_0028
      SELECT id, service_date, service_type, title, start_time, location, cell_group_id, status,
             counts_toward_followup, notes, created_at, created_by FROM attendance_sessions;
    DROP TABLE attendance_sessions;
    ALTER TABLE attendance_sessions_0028 RENAME TO attendance_sessions;
    CREATE INDEX idx_sessions_date ON attendance_sessions(service_date);
    DELETE FROM role_permissions WHERE permission_id = (SELECT id FROM permissions WHERE key = 'attendance.finalize');
    DELETE FROM permissions WHERE key = 'attendance.finalize';
    DELETE FROM schema_migrations WHERE version = '0029_attendance_finalization';
    COMMIT;
  `);
  conn.pragma('foreign_keys = ON');
  assert.deepEqual(conn.pragma('foreign_key_check'), [], 'sanity: the rewound fixture is referentially sound');
  conn.close();
}

const OLD_SESSION_COLUMNS = 'id, service_date, service_type, title, start_time, location, cell_group_id, status, counts_toward_followup, notes, created_at, created_by';
function dataSnapshot(conn) {
  return {
    sessions: conn.prepare(`SELECT ${OLD_SESSION_COLUMNS} FROM attendance_sessions ORDER BY id`).all(),
    records: conn.prepare('SELECT * FROM attendance_records ORDER BY id').all(),
    qr: conn.prepare('SELECT * FROM qr_checkins ORDER BY id').all(),
    members: conn.prepare('SELECT id, status, date_joined FROM members ORDER BY id').all(),
    history: conn.prepare('SELECT * FROM member_status_history ORDER BY id').all()
  };
}

let before;
{
  const conn = new Database(migDb, { readonly: true });
  const { checkSchemaCompatibility, EXPECTED_MIGRATIONS } = await import('../db/migrate.js');
  assert.ok(EXPECTED_MIGRATIONS.includes('0029_attendance_finalization'), 'the application expects migration 0029');
  const compat = checkSchemaCompatibility(conn);
  assert.equal(compat.ok, false);
  assert.equal(compat.reason, 'behind');
  assert.deepEqual(compat.missing, ['0029_attendance_finalization'], 'a 0028 database is exactly one migration behind, by identity');
  assert.ok(!conn.pragma('table_info(attendance_sessions)').some((c) => c.name === 'finalization_state'));
  before = dataSnapshot(conn);
  assert.equal(before.sessions.length, 3);
  assert.equal(before.records.length, 4);
  conn.close();
}

// Applied through the explicit migration command - the only thing that may advance the schema.
function runMigrateCli() {
  const proc = spawnSync(process.execPath, [path.join(root, 'src/db/migrate.js')], { env: childEnvFor(migDb), encoding: 'utf8' });
  assert.equal(proc.status, 0, `migrate CLI failed: ${proc.stdout}\n${proc.stderr}`);
}
runMigrateCli();

let versionsAfterFirst;
let tableInfoAfterFirst;
{
  const conn = new Database(migDb);
  const { checkSchemaCompatibility } = await import('../db/migrate.js');
  assert.deepEqual(checkSchemaCompatibility(conn), { ok: true }, 'ITEM 1: 0029 applies to a 0028 database and it is then fully current');

  // 2/3/4. Existing data byte-for-byte unchanged; new columns NULL; snapshot table empty.
  assert.deepEqual(dataSnapshot(conn), before, 'ITEMS 2-3: existing sessions, records, QR check-ins, members and history are unchanged');
  assert.equal(conn.prepare(
    `SELECT COUNT(*) AS n FROM attendance_sessions WHERE finalization_state IS NOT NULL OR finalized_at IS NOT NULL
        OR finalized_by IS NOT NULL OR finalization_note IS NOT NULL`
  ).get().n, 0, 'ITEM 2: every existing session simply has NULL in the four new columns');
  assert.equal(conn.prepare('SELECT COUNT(*) AS n FROM attendance_expected').get().n, 0, 'ITEM 4: attendance_expected starts empty');

  // Exact schema.
  const columns = Object.fromEntries(conn.pragma('table_info(attendance_sessions)').map((c) => [c.name, c]));
  for (const name of ['finalization_state', 'finalized_at', 'finalized_by', 'finalization_note']) {
    assert.ok(columns[name], `${name} exists`);
    assert.equal(columns[name].notnull, 0, `${name} is nullable`);
    assert.equal(columns[name].dflt_value, null, `${name} has no default: NULL means "not finalized"`);
  }
  const expectedColumns = conn.pragma('table_info(attendance_expected)');
  assert.deepEqual(expectedColumns.map((c) => c.name), ['session_id', 'member_id', 'status_at_service']);
  assert.deepEqual(expectedColumns.filter((c) => c.pk).map((c) => c.name), ['session_id', 'member_id'], 'PRIMARY KEY(session_id, member_id)');
  const fks = conn.pragma('foreign_key_list(attendance_expected)');
  assert.equal(fks.find((f) => f.from === 'session_id').on_delete, 'CASCADE');
  assert.equal(fks.find((f) => f.from === 'member_id').on_delete, 'RESTRICT',
    'member_id must NOT cascade: deleting a member must never silently erase historical expected-roster evidence');
  assert.equal(conn.pragma('foreign_key_list(attendance_sessions)').find((f) => f.from === 'finalized_by').on_delete, 'SET NULL');
  assert.ok(conn.pragma('index_list(attendance_expected)').some((i) => i.name === 'idx_attendance_expected_member'), 'index on member_id');
  assert.deepEqual(conn.pragma('foreign_key_check'), []);

  // The CHECK on finalization_state.
  const anySession = conn.prepare('SELECT id FROM attendance_sessions ORDER BY id LIMIT 1').get().id;
  assert.throws(() => conn.prepare("UPDATE attendance_sessions SET finalization_state = 'bogus' WHERE id = ?").run(anySession), /CHECK/);
  for (const ok of ['finalized', 'not_taken']) {
    conn.prepare('UPDATE attendance_sessions SET finalization_state = ? WHERE id = ?').run(ok, anySession);
  }
  conn.prepare('UPDATE attendance_sessions SET finalization_state = NULL WHERE id = ?').run(anySession);

  // 6/7/8. Permission grants, on a database whose roles already existed (the production shape).
  const holders = conn.prepare(
    `SELECT r.key FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id JOIN roles r ON r.id = rp.role_id
      WHERE p.key = 'attendance.finalize' ORDER BY r.key`
  ).all().map((r) => r.key);
  assert.deepEqual(holders, ['church_admin', 'super_admin'],
    'ITEMS 6-8: only Church Admin and Super Admin receive attendance.finalize - not the Cell Group Leader, member or kiosk role');
  assert.equal(conn.prepare("SELECT COUNT(*) AS n FROM permissions WHERE key = 'attendance.finalize'").get().n, 1);

  versionsAfterFirst = conn.prepare('SELECT version, applied_at FROM schema_migrations ORDER BY version').all();
  tableInfoAfterFirst = JSON.stringify([conn.pragma('table_info(attendance_sessions)'), conn.pragma('table_info(attendance_expected)')]);
  assert.ok(versionsAfterFirst.some((v) => v.version === '0029_attendance_finalization'));
  conn.close();
}

// 5. Idempotent: running it again changes nothing and does not fail.
runMigrateCli();
{
  const conn = new Database(migDb, { readonly: true });
  assert.deepEqual(conn.prepare('SELECT version, applied_at FROM schema_migrations ORDER BY version').all(), versionsAfterFirst,
    'ITEM 5: a second run applies nothing and rewrites no migration record');
  assert.equal(JSON.stringify([conn.pragma('table_info(attendance_sessions)'), conn.pragma('table_info(attendance_expected)')]), tableInfoAfterFirst);
  assert.deepEqual(dataSnapshot(conn), before, 'and existing data is still untouched');
  assert.equal(conn.prepare("SELECT COUNT(*) AS n FROM permissions WHERE key = 'attendance.finalize'").get().n, 1);
  assert.equal(conn.prepare(
    "SELECT COUNT(*) AS n FROM role_permissions WHERE permission_id = (SELECT id FROM permissions WHERE key = 'attendance.finalize')"
  ).get().n, 2, 'no duplicate grants');
  conn.close();
}
console.log('PASS (migration 0029): applies to a 0028 database through the explicit command, leaves every existing session/record/check-in untouched, has the approved schema and grants, and is idempotent');

// =====================================================================
// 2. Application-level foundation, against the shared disposable fixture.
// =====================================================================

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting, getSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember, changeStatus, memberDependencySummary, canDeleteMember, deleteMemberRecord } = await import('../services/members.js');
const { createUser, loadUserContext } = await import('../services/users.js');
const tracking = await import('../services/attendance-tracking.js');
const { resolveStatusAsOf, checkHistoryChain } = await import('../lib/status-as-of.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

// --- Permission catalogue, through the real role definitions. ---
{
  const rows = db.prepare(
    `SELECT r.key FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id JOIN roles r ON r.id = rp.role_id
      WHERE p.key = 'attendance.finalize' ORDER BY r.key`
  ).all().map((r) => r.key);
  assert.deepEqual(rows, ['church_admin', 'super_admin'], 'seeded roles: only church_admin and super_admin');
  for (const [role, allowed] of [['super_admin', true], ['church_admin', true], ['cell_group_leader', false], ['member', false], ['kiosk', false]]) {
    const id = await createUser({ email: `${role}.finalize@fixture.invalid`, password: 'FinalizeFixturePassw0rd!2026', displayName: role, roleKeys: [role], mustChangePassword: false });
    assert.equal(loadUserContext(id).can('attendance.finalize'), allowed, `${role}: attendance.finalize`);
  }
  console.log('PASS (permission): attendance.finalize belongs to Church Admin and Super Admin only; Cell Group Leader, member and kiosk do not hold it');
}

// --- Setting: blank = tracking not started; validation of the value. ---
assert.equal(getSetting('attendance.tracking_start_date'), '', 'the default is blank');
assert.equal(tracking.trackingStartDate(), null);
assert.equal(tracking.isTrackingConfigured(), false, 'ITEM 9: blank Go-Live means tracking has not started');

// --- Classification (explicit goLive/asOf: independent of today's date). ---
{
  const GO_LIVE = '2026-11-06'; // a Friday
  const friday = (date, extra = {}) => ({ service_type: 'friday_service', service_date: date, status: 'scheduled', finalization_state: null, ...extra });
  const phase = (session, asOf, goLive = GO_LIVE) => tracking.classifySession(session, { asOf, goLive }).phase;

  assert.equal(tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-06', goLive: null }).phase, 'not_started',
    'ITEM 9: no Go-Live date -> not started (no fallback to older behaviour)');
  assert.equal(tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-06', goLive: null }).trackingConfigured, false);
  assert.equal(tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-06', goLive: null }).tracked, false);

  assert.equal(tracking.isOnOrAfterGoLive('2026-11-06', '2026-11-06'), true, 'ITEM 10: the Go-Live Friday itself is on/after');
  assert.equal(tracking.isOnOrAfterGoLive('2026-10-30', '2026-11-06'), false);
  assert.equal(tracking.isOnOrAfterGoLive('2026-11-06', null), false);

  assert.equal(phase(friday('2026-10-30'), '2026-11-06'), 'pre_go_live', 'ITEM 11: a Friday before Go-Live is pre-go-live');
  assert.equal(tracking.classifySession(friday('2026-10-30'), { asOf: '2026-11-06', goLive: GO_LIVE }).tracked, false);
  assert.equal(phase(friday('2026-10-30', { status: 'cancelled' }), '2026-11-06'), 'pre_go_live');

  assert.equal(tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-06', goLive: GO_LIVE }).tracked, true, 'ITEM 12: tracked Friday');
  assert.equal(phase(friday('2026-11-06'), '2026-11-05'), 'scheduled', 'future = scheduled');
  assert.equal(phase(friday('2026-11-06'), '2026-11-06'), 'open', 'the current operational Friday is open on the day...');
  assert.equal(phase(friday('2026-11-06'), '2026-11-12'), 'open', '...and through the following Thursday');
  assert.equal(phase(friday('2026-11-06'), '2026-11-13'), 'awaiting_finalization', 'an earlier, unfinalized Friday awaits finalization');
  assert.equal(phase(friday('2026-11-06', { status: 'held' }), '2026-11-20'), 'awaiting_finalization');

  assert.equal(phase(friday('2026-11-06', { finalization_state: 'finalized' }), '2026-11-20'), 'finalized');
  assert.equal(phase(friday('2026-11-06', { finalization_state: 'not_taken' }), '2026-11-20'), 'not_taken');
  const finalized = tracking.classifySession(friday('2026-11-06', { finalization_state: 'finalized' }), { asOf: '2026-11-20', goLive: GO_LIVE });
  assert.equal(finalized.finalized, true);
  assert.equal(finalized.unfinalized, false);
  const awaiting = tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-20', goLive: GO_LIVE });
  assert.equal(awaiting.awaitingFinalization, true);
  assert.equal(awaiting.unfinalized, true);
  assert.equal(tracking.classifySession(friday('2026-11-06'), { asOf: '2026-11-06', goLive: GO_LIVE }).open, true);

  // Cancelled is orthogonal to finalization: it keeps the state.
  const cancelled = tracking.classifySession(friday('2026-11-13', { status: 'cancelled' }), { asOf: '2026-11-20', goLive: GO_LIVE });
  assert.equal(cancelled.phase, 'cancelled', 'ITEM 13');
  assert.equal(cancelled.cancelled, true);
  const cancelledFinalized = tracking.classifySession(friday('2026-11-13', { status: 'cancelled', finalization_state: 'finalized' }), { asOf: '2026-11-20', goLive: GO_LIVE });
  assert.equal(cancelledFinalized.phase, 'cancelled');
  assert.equal(cancelledFinalized.finalizationState, 'finalized', 'a cancelled session keeps its finalization state, so reinstating restores it');
  assert.equal(phase(friday('2026-11-13', { status: 'cancelled', finalization_state: 'finalized' }), '2026-11-20'), 'cancelled');
  assert.equal(phase(friday('2026-11-13', { finalization_state: 'finalized' }), '2026-11-20'), 'finalized', 'reinstated: back to finalized');

  assert.equal(phase({ service_type: 'cell_group', service_date: '2026-11-06', status: 'scheduled' }, '2026-11-06'), 'not_applicable');
  assert.equal(phase({ service_type: 'special_service', service_date: '2026-11-06', status: 'scheduled' }, '2026-11-06'), 'not_applicable');
  assert.equal(tracking.classifySession(friday('2026-11-06', { finalization_state: 'bogus' }), { asOf: '2026-11-06', goLive: GO_LIVE }).finalizationState, null,
    'an unrecognised stored value is treated as not finalized');
  console.log('PASS (classification): blank Go-Live = not started; pre-go-live, tracked, scheduled/open/awaiting/finalized/not-taken and cancelled Fridays are each classified once, in one place');
}

// --- The setting reads a real value from system_settings, and never guesses. ---
{
  setSetting('attendance.tracking_start_date', '2026-11-06');
  assert.equal(tracking.trackingStartDate(), '2026-11-06', 'ITEM 10: a valid date');
  assert.equal(tracking.isTrackingConfigured(), true);
  setSetting('attendance.tracking_start_date', '2026-02-30');
  assert.equal(tracking.trackingStartDate(), null, 'a date that never existed means "not started", never a guessed date');
  setSetting('attendance.tracking_start_date', 'next friday');
  assert.equal(tracking.trackingStartDate(), null);
  setSetting('attendance.tracking_start_date', '');
  assert.equal(tracking.isTrackingConfigured(), false);
  console.log('PASS (setting): attendance.tracking_start_date is blank by default, read strictly, and an invalid stored value can only mean "not started"');
}

// --- Status as of a Friday: pure resolver. ---
{
  const FRIDAY = '2026-11-06';
  const row = (id, previous, next, at) => ({ id, previous_status: previous, new_status: next, changed_at: at });
  const asOf = (history, currentStatus, createdAt = '2025-01-01T08:00:00.000Z') =>
    resolveStatusAsOf({ history, currentStatus, createdAt, serviceDate: FRIDAY });

  // Normal history; later changes never rewrite the past.
  const away = [row(1, null, 'active', '2025-01-01T08:00:00.000Z'), row(2, 'active', 'temporarily_away', '2026-11-20T10:00:00.000Z')];
  assert.deepEqual(asOf(away, 'temporarily_away'), { status: 'active', certainty: 'exact', basis: 'history' },
    'Active on the Friday, Temporarily Away afterwards: the Friday still remembers Active');
  const later = [row(1, null, 'inactive', '2025-01-01T08:00:00.000Z'), row(2, 'inactive', 'active', '2026-12-01T10:00:00.000Z')];
  assert.equal(asOf(later, 'active').status, 'inactive', 'Inactive then, Active now: still Inactive on that Friday');
  const mid = [row(1, null, 'active', '2025-01-01T08:00:00.000Z'), row(2, 'active', 'inactive', '2026-03-01T08:00:00.000Z'), row(3, 'inactive', 'active', '2026-12-01T10:00:00.000Z')];
  assert.equal(asOf(mid, 'active').status, 'inactive', 'the LAST change on or before the Friday wins');

  // Qatar Friday: the change during the Qatar day counts, Saturday-in-Qatar does not.
  const during = (at) => [row(1, null, 'active', '2025-01-01T08:00:00.000Z'), row(2, 'active', 'temporarily_away', at)];
  assert.equal(asOf(during('2026-11-06T20:59:59.000Z'), 'temporarily_away').status, 'temporarily_away', 'ITEM 14: 23:59:59 Qatar Friday counts (status at the end of the service day)');
  assert.equal(asOf(during('2026-11-06T19:59:00.000Z'), 'temporarily_away').status, 'temporarily_away', 'during the Qatar Friday counts');
  assert.equal(asOf(during('2026-11-06T21:00:00.000Z'), 'temporarily_away').status, 'active', '00:00 Qatar Saturday (21:00 UTC Friday) belongs to Saturday: does not count');
  assert.equal(asOf(during('2026-11-05T21:00:00.000Z'), 'temporarily_away').status, 'temporarily_away', '00:00 Qatar Friday (21:00 UTC Thursday) already belongs to Friday');
  assert.equal(asOf(during('2026-11-05T20:59:59.000Z'), 'temporarily_away').status, 'temporarily_away', 'Thursday night Qatar: earlier, counts');

  // No suitable history: never invent certainty.
  assert.deepEqual(asOf([], 'active'), { status: 'active', certainty: 'inferred', basis: 'no_history_current' },
    'no change was ever recorded, so the status was the current one throughout - inferred, and labelled so');
  assert.deepEqual(asOf([], 'active', '2026-12-01T08:00:00.000Z'), { status: null, certainty: 'ambiguous', basis: 'created_after_service' },
    'a record created after the service, with no history, cannot say who they were on that Friday');
  assert.deepEqual(asOf([row(1, null, 'active', '2026-12-01T08:00:00.000Z')], 'active'), { status: null, certainty: 'ambiguous', basis: 'created_after_service' },
    'only a creation entry, dated after the Friday');
  assert.deepEqual(asOf([row(1, 'inactive', 'active', '2026-12-01T08:00:00.000Z')], 'active'),
    { status: 'inactive', certainty: 'inferred', basis: 'before_first_change' },
    'the first recorded change is after the Friday and states what came before it');

  // Ambiguous / inconsistent history.
  const broken = [row(1, null, 'active', '2025-01-01T08:00:00.000Z'), row(2, 'inactive', 'attendee', '2026-03-01T08:00:00.000Z')];
  assert.deepEqual(asOf(broken, 'attendee'), { status: null, certainty: 'ambiguous', basis: 'history_inconsistent' }, 'a chain break');
  const tail = [row(1, null, 'active', '2025-01-01T08:00:00.000Z')];
  assert.deepEqual(asOf(tail, 'inactive'), { status: null, certainty: 'ambiguous', basis: 'history_inconsistent' },
    'history does not end at the current status: something changed status without recording it');
  assert.equal(checkHistoryChain(tail, 'inactive').issues[0].code, 'tail_mismatch');
  assert.equal(checkHistoryChain(broken, 'attendee').issues[0].code, 'chain_break');
  assert.equal(checkHistoryChain(away, 'temporarily_away').consistent, true);
  // Order does not depend on how rows were supplied.
  assert.equal(asOf([...away].reverse(), 'temporarily_away').status, 'active');
  console.log('PASS (status as of): normal, later-change, Qatar-Friday and UTC/Qatar boundaries, no history, and inconsistent history are each resolved deterministically and labelled exact / inferred / ambiguous');
}

// --- Expectation rules. ---
{
  const FRIDAY = '2026-11-06';
  const base = { history: [], createdAt: '2025-01-01T08:00:00.000Z', dateJoined: null, serviceDate: FRIDAY };
  for (const status of ['active', 'pending', 'attendee', 'bonafide']) {
    const r = tracking.evaluateExpectation({ ...base, currentStatus: status });
    assert.equal(r.eligible, true, `ITEM 15: ${status} is expected`);
    assert.equal(r.statusAtService, status);
  }
  assert.deepEqual([...tracking.EXPECTED_ROSTER_STATUSES], ['active', 'pending', 'attendee', 'bonafide']);
  for (const status of ['temporarily_away', 'inactive', 'returned_home', 'migrated', 'transferred', 'archived', 'other']) {
    const r = tracking.evaluateExpectation({ ...base, currentStatus: status });
    assert.equal(r.eligible, false, `ITEM 16: ${status} is not expected`);
    assert.equal(r.certainty, 'inferred', `${status}: excluded with a definite answer, not flagged as ambiguous`);
  }
  assert.equal(tracking.evaluateExpectation({ ...base, currentStatus: 'active', dateJoined: '2026-11-07' }).eligible, false, 'ITEM 17: joined after the Friday');
  assert.equal(tracking.evaluateExpectation({ ...base, currentStatus: 'active', dateJoined: '2026-11-07' }).basis, 'joined_after_service');
  assert.equal(tracking.evaluateExpectation({ ...base, currentStatus: 'active', dateJoined: '2026-11-06' }).eligible, true, 'joined ON the Friday is expected');
  assert.equal(tracking.evaluateExpectation({ ...base, currentStatus: 'active', dateJoined: null }).eligible, true, 'no join date recorded: expected (the existing sheet rule)');
  const ambiguous = tracking.evaluateExpectation({ ...base, currentStatus: 'active', history: [{ id: 1, previous_status: null, new_status: 'inactive', changed_at: '2025-01-01T08:00:00.000Z' }] });
  assert.equal(ambiguous.eligible, false, 'ambiguity never becomes an expectation');
  assert.equal(ambiguous.certainty, 'ambiguous');
  const joinedSettles = tracking.evaluateExpectation({ ...base, currentStatus: 'active', dateJoined: '2026-12-01', history: [{ id: 1, previous_status: null, new_status: 'inactive', changed_at: '2025-01-01T08:00:00.000Z' }] });
  assert.equal(joinedSettles.certainty, 'exact', 'a join date after the Friday settles it whatever the history says');
  console.log('PASS (expectation): the four expected statuses are expected, the seven others are not, the join-date rule holds, and ambiguity is never turned into an expectation');
}

// --- The roster and snapshot against a real fixture database. ---
const SERVICE = lastFridayOnOrBefore(today());
const GO_LIVE = addDays(SERVICE, -14);
const atNoon = (date, hourUtc = 9) => `${date}T${String(hourUtc).padStart(2, '0')}:00:00.000Z`;

/** Rewrites a member's history to a controlled past: creation entry, then each change in order. */
function plant(member, { created, changes = [] }) {
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(member.id);
  db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(created.at, member.id);
  const insert = db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)');
  insert.run(member.id, null, created.status, 'planted', created.at);
  let current = created.status;
  for (const change of changes) {
    insert.run(member.id, current, change.status, 'planted', change.at);
    current = change.status;
  }
  db.prepare('UPDATE members SET status = ? WHERE id = ?').run(current, member.id);
}
const oldDate = addDays(SERVICE, -200);
const mk = (name, status = 'active', extra = {}) => createMember({ first_name: name, last_name: 'Roster', ...extra }, { status });

const mStable = mk('Stable');
plant(mStable, { created: { at: atNoon(oldDate), status: 'active' } });
const mAwayLater = mk('AwayLater');
plant(mAwayLater, { created: { at: atNoon(oldDate), status: 'active' }, changes: [{ at: atNoon(addDays(SERVICE, 3)), status: 'temporarily_away' }] });
const mInactiveThen = mk('InactiveThen');
plant(mInactiveThen, { created: { at: atNoon(oldDate), status: 'inactive' }, changes: [{ at: atNoon(addDays(SERVICE, 3)), status: 'active' }] });
const mAwayDuring = mk('AwayDuring');
plant(mAwayDuring, { created: { at: atNoon(oldDate), status: 'active' }, changes: [{ at: atNoon(SERVICE, 18), status: 'temporarily_away' }] });
const mAwaySaturday = mk('AwaySaturday');
plant(mAwaySaturday, { created: { at: atNoon(oldDate), status: 'active' }, changes: [{ at: atNoon(SERVICE, 21), status: 'temporarily_away' }] });
const mArchived = mk('Archived');
plant(mArchived, { created: { at: atNoon(oldDate), status: 'archived' } });
const mJoinedLater = mk('JoinedLater', 'active', { date_joined: addDays(SERVICE, 1) });
plant(mJoinedLater, { created: { at: atNoon(oldDate), status: 'active' } });
const mCreatedAfter = mk('CreatedAfter');
plant(mCreatedAfter, { created: { at: atNoon(addDays(SERVICE, 2)), status: 'active' } });
const mInconsistent = mk('Inconsistent');
plant(mInconsistent, { created: { at: atNoon(oldDate), status: 'active' } });
db.prepare("UPDATE members SET status = 'inactive' WHERE id = ?").run(mInconsistent.id); // changed with no history entry

{
  const roster = tracking.resolveExpectedRoster(SERVICE);
  const expectedIds = roster.expected.filter((e) => [mStable, mAwayLater, mInactiveThen, mAwayDuring, mAwaySaturday, mArchived, mJoinedLater].some((m) => m.id === e.memberId)).map((e) => e.memberId).sort((a, b) => a - b);
  assert.deepEqual(expectedIds, [mStable.id, mAwayLater.id, mAwaySaturday.id].sort((a, b) => a - b),
    'Stable, AwayLater (away only AFTER the Friday) and AwaySaturday (away from Saturday Qatar) were expected; Inactive-then, away-during-Friday, archived and joined-later were not');
  const ambiguousIds = roster.ambiguous.map((a) => a.memberId).sort((a, b) => a - b);
  for (const id of [mCreatedAfter.id, mInconsistent.id]) assert.ok(ambiguousIds.includes(id), `member ${id} is surfaced as ambiguous`);
  assert.ok(!ambiguousIds.includes(mStable.id));
  assert.ok(roster.expected.every((e) => tracking.EXPECTED_ROSTER_STATUSES.includes(e.statusAtService)));
  assert.equal(roster.expected.length + roster.ambiguous.length + roster.excludedCount, roster.consideredCount, 'every member is accounted for exactly once');
  assert.equal(tracking.resolveExpectedRoster(SERVICE).expected.length, roster.expected.length, 'deterministic: same input, same answer');
  console.log('PASS (roster): expectation is resolved from history as of the Friday - later changes do not rewrite it - and uncertain members are reported separately');
}

// --- Snapshot primitives. ---
{
  const insertSession = db.prepare(
    `INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at)
     VALUES (@date, @type, @title, @status, 1, 0, @at)`
  );
  const sessionOn = (date, type = 'friday_service', status = 'held') => {
    insertSession.run({ date, type, title: `${type} ${date}`, status, at: atNoon(date) });
    return db.prepare('SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = ? AND cell_group_id = 0').get(date, type);
  };
  const session = sessionOn(SERVICE);
  const snapshotCount = () => db.prepare('SELECT COUNT(*) AS n FROM attendance_expected').get().n;

  // Refusals write nothing.
  assert.equal(tracking.createExpectedSnapshot(session.id).reason, 'not_tracked', 'no Go-Live date: nothing is tracked, so nothing is snapshotted');
  setSetting('attendance.tracking_start_date', GO_LIVE);
  assert.equal(tracking.createExpectedSnapshot(999999).reason, 'session_not_found');
  assert.equal(tracking.createExpectedSnapshot(sessionOn(SERVICE, 'special_service').id).reason, 'not_friday_service');
  const preGoLive = sessionOn(addDays(GO_LIVE, -7));
  assert.equal(tracking.createExpectedSnapshot(preGoLive.id).reason, 'not_tracked', 'a pre-go-live Friday is never snapshotted');
  const cancelled = sessionOn(addDays(SERVICE, -7), 'friday_service', 'cancelled');
  assert.equal(tracking.createExpectedSnapshot(cancelled.id).reason, 'session_cancelled');
  assert.equal(tracking.createExpectedSnapshot(session.id, { asOf: addDays(SERVICE, -1) }).reason, 'session_in_future');
  assert.equal(snapshotCount(), 0, 'every refusal above wrote nothing');

  // Ambiguity is surfaced, never silently resolved.
  const preview = tracking.previewExpectedSnapshot(session.id);
  assert.equal(preview.existing, false);
  assert.ok(preview.ambiguous.some((a) => a.memberId === mInconsistent.id));
  const refused = tracking.createExpectedSnapshot(session.id);
  assert.equal(refused.ok, false);
  assert.equal(refused.reason, 'ambiguous_history');
  assert.ok(refused.ambiguous.length >= 2);
  assert.equal(snapshotCount(), 0, 'ITEM 18: a refused snapshot leaves nothing behind');
  assert.equal(tracking.hasExpectedSnapshot(session.id), false);

  // Created once, transactionally, with the ambiguous members left out.
  const created = tracking.createExpectedSnapshot(session.id, { acknowledgeAmbiguous: true });
  assert.equal(created.ok, true);
  assert.equal(created.created, true);
  assert.equal(created.count, snapshotCount());
  assert.ok(created.excludedAmbiguous.length >= 2, 'acknowledged ambiguous members are excluded, not silently included');
  const rows = tracking.getExpectedSnapshot(session.id);
  assert.equal(rows.length, created.count);
  const inSnapshot = new Set(rows.map((r) => r.member_id));
  assert.ok(inSnapshot.has(mStable.id) && inSnapshot.has(mAwayLater.id) && inSnapshot.has(mAwaySaturday.id));
  for (const m of [mInactiveThen, mAwayDuring, mArchived, mJoinedLater, mCreatedAfter, mInconsistent]) assert.ok(!inSnapshot.has(m.id), `${m.first_name} is not in the snapshot`);
  assert.ok(rows.every((r) => tracking.EXPECTED_ROSTER_STATUSES.includes(r.status_at_service)));
  assert.equal(rows.find((r) => r.member_id === mAwayLater.id).status_at_service, 'active', 'status_at_service records the status THAT day');
  assert.equal(tracking.isMemberInExpectedSnapshot(session.id, mStable.id), true);
  assert.equal(tracking.isMemberInExpectedSnapshot(session.id, mInactiveThen.id), false);
  assert.equal(tracking.expectedSnapshotCount(session.id), rows.length);

  // ITEM 19: never silently replaced - not even when today's statuses have changed.
  const frozen = JSON.stringify(rows);
  changeStatus(mStable.id, 'inactive', { reason: 'test' });
  changeStatus(mInactiveThen.id, 'active', { reason: 'test' });
  const again = tracking.createExpectedSnapshot(session.id, { acknowledgeAmbiguous: true });
  assert.equal(again.ok, true);
  assert.equal(again.created, false);
  assert.equal(again.reused, true, 'a second request reuses the existing snapshot');
  assert.equal(JSON.stringify(tracking.getExpectedSnapshot(session.id)), frozen, 'the snapshot is byte-identical: later status changes did not rewrite who was expected');
  assert.equal(tracking.isMemberInExpectedSnapshot(session.id, mStable.id), true, 'now Inactive, but still expected on that Friday');
  const previewExisting = tracking.previewExpectedSnapshot(session.id);
  assert.equal(previewExisting.existing, true, 'a preview shows the stored snapshot, not a fresh computation');
  assert.equal(previewExisting.expected.length, rows.length);

  // Transactional insert: all or nothing, and never an overwrite.
  const other = sessionOn(addDays(SERVICE, -7));
  const countBefore = snapshotCount();
  assert.throws(() => tracking.insertExpectedRows(other.id, [
    { memberId: mStable.id, statusAtService: 'active' },
    { memberId: mAwayLater.id, statusAtService: 'active' },
    { memberId: 987654321, statusAtService: 'active' } // no such member: violates the foreign key
  ]), /FOREIGN KEY/);
  assert.equal(snapshotCount(), countBefore, 'ITEM 18: a failure part-way rolls the whole insert back');
  assert.equal(tracking.hasExpectedSnapshot(other.id), false);
  assert.throws(() => tracking.insertExpectedRows(session.id, [{ memberId: mStable.id, statusAtService: 'inactive' }]), /UNIQUE|PRIMARY/);
  assert.equal(JSON.stringify(tracking.getExpectedSnapshot(session.id)), frozen, 'a duplicate insert can never overwrite a snapshot row');
  console.log('PASS (snapshot): refusals write nothing; ambiguity must be acknowledged and is then excluded; creation is transactional; an existing snapshot is reused, never replaced, even after members\' statuses change');

  // --- ITEM 20: member deletion protection. ---
  const solo = mk('SnapshotOnly');
  plant(solo, { created: { at: atNoon(oldDate), status: 'active' } });
  const control = mk('Deletable');
  assert.equal(canDeleteMember(control.id).safe, true, 'control: a member with no history can be deleted');

  const soloSession = sessionOn(addDays(SERVICE, -14));
  assert.equal(memberDependencySummary(solo.id).attendanceRecords, 0);
  tracking.insertExpectedRows(soloSession.id, [{ memberId: solo.id, statusAtService: 'active' }]);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM attendance_records WHERE member_id = ?').get(solo.id).n, 0, 'sanity: expected, but never attended: no attendance row at all');
  assert.equal(memberDependencySummary(solo.id).attendanceRecords, 1, 'the snapshot row counts as attendance history');
  assert.equal(canDeleteMember(solo.id).safe, false);
  const deletion = deleteMemberRecord(solo.id);
  assert.equal(deletion.ok, false);
  assert.equal(deletion.reason, 'has_dependencies');
  assert.throws(() => db.prepare('DELETE FROM members WHERE id = ?').run(solo.id), /FOREIGN KEY/,
    'and even a direct delete is stopped by the database (ON DELETE RESTRICT)');
  assert.ok(db.prepare('SELECT 1 FROM members WHERE id = ?').get(solo.id), 'the member is still there');
  assert.equal(tracking.isMemberInExpectedSnapshot(soloSession.id, solo.id), true, 'and so is the historical evidence');
  assert.equal(deleteMemberRecord(control.id).ok, true, 'a record with no history can still be deleted');
  console.log('PASS (member deletion): a member who appears in an expected-roster snapshot can no longer be deleted - by the safe-delete check or by the database itself');
}

// --- Settings admin route: validates the date, and shows a date picker. ---
setSetting('attendance.tracking_start_date', ''); // back to blank: the snapshot tests above used a fixture Go-Live date
// A stored snapshot now locks the Go-Live date (Phase 2B); this section tests the unlocked settings form, so clear the fixture snapshots and the sessions' finalization first.
db.prepare('DELETE FROM attendance_expected').run();
db.prepare('UPDATE attendance_sessions SET finalization_state = NULL, finalized_at = NULL, finalized_by = NULL, finalization_note = NULL').run();
{
  const port = await new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
  await waitForServerReady(base, server);

  await createUser({ email: 'admin.tracking@fixture.invalid', password: 'TrackingAdminPassw0rd!2026', displayName: 'Tracking Admin', roleKeys: ['super_admin'], mustChangePassword: false });
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const loginPage = await fetch(`${base}/login`);
  const loginCsrf = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const preCookie = cookieOf(loginPage, '');
  const loginRes = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email: 'admin.tracking@fixture.invalid', password: 'TrackingAdminPassw0rd!2026', _csrf: loginCsrf })
  });
  const cookie = cookieOf(loginRes, preCookie);

  const page = await fetch(`${base}/admin/settings?section=attendance`, { headers: { Cookie: cookie } });
  const html = await page.text();
  assert.doesNotMatch(html, /name="attendance__tracking_start_date"/, 'the date is changed on its own Super Admin page (with a preview), not by a field in the settings form');
  assert.match(html, /Attendance Tracking Start Date/);
  assert.match(html, /\/admin\/attendance\/tracking-start/);
  const csrf = html.match(/name="_csrf" value="([^"]+)"/)[1];
  const post = (value) => fetch(`${base}/admin/settings`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ _csrf: csrf, attendance__tracking_start_date: value })
  });

  for (const bad of ['not-a-date', '2026-02-30', '06/11/2026', '2027-01-02']) { // the last is a real date but a Saturday
    const res = await post(bad);
    assert.equal(res.status, 302);
    assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, '', `invalid value "${bad}" must not be saved`);
  }
  await post('2027-01-01');
  assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, '2027-01-01', 'a valid date is saved');
  await post('');
  assert.equal(db.prepare("SELECT value FROM system_settings WHERE key = 'attendance.tracking_start_date'").get().value, '', 'blank is accepted: tracking has not started');
  await terminateAndWait(server);
  console.log('PASS (settings route): a hand-built post rejects anything that is not a real Friday, and accepts a Friday and blank (for a Super Admin)');
}

// --- Read-only status-history diagnostic. ---
setSetting('attendance.tracking_start_date', '');
db.close();
{
  const tool = path.join(root, 'tools/check-status-history.mjs');
  const run = (...args) => spawnSync(process.execPath, [tool, ...args], { encoding: 'utf8' });

  const usage = run();
  assert.equal(usage.status, 2, 'a path is required (usage error): the tool has no default and never reads the application configuration');
  const missing = path.join(env.root, 'does-not-exist.sqlite');
  assert.equal(run(missing).status, 1);
  assert.ok(!fs.existsSync(missing), 'it never creates a database');

  const hashBefore = sha256File(env.databaseFile);
  const withProblems = run(env.databaseFile);
  assert.equal(withProblems.status, 3, `the fixture contains a member whose status changed without a history entry: ${withProblems.stdout}${withProblems.stderr}`);
  assert.match(withProblems.stdout, /history contradicts itself\/current:\s+[1-9]/);
  assert.match(withProblems.stdout, /now inactive\): last recorded "active" but current is "inactive"/);
  assert.equal(sha256File(env.databaseFile), hashBefore, 'the diagnostic changed nothing in the database file');

  const clean = run(migDb);
  assert.equal(clean.status, 0, `history written only through the application is coherent: ${clean.stdout}${clean.stderr}`);
  assert.match(clean.stdout, /history contradicts itself\/current:\s+0/);
  console.log('PASS (diagnostic): tools/check-status-history.mjs is read-only, needs an explicit path, flags a member whose history does not reach their current status, and passes coherent history');
}

env.cleanup();
console.log('ALL PASS');
