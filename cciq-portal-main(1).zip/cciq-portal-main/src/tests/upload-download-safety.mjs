import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PassThrough } from 'node:stream';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Files in and out: uploads are accepted only when their first bytes say they are what they claim, are stored under a random
 * name the uploader never chooses, leave exactly one current file per record and never a stray or a missing one if the
 * database write fails; downloads carry safe headers; storage, the database and the source tree are not reachable over HTTP;
 * and a file that cannot be read never stops the server.
 */

const f = await buildPortalFixture('cciq-files-');
const { db, ids, users, mods } = f;
const config = (await import('../config/env.js')).default;
const churchProfile = await import('../services/church-profile.js');
const { streamFile } = await import('../lib/stream-file.js');
const storage = config.storageDir;

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const png = (name = 'photo.png') => ({ name, type: 'image/png', buffer: PNG });
const leader = churchProfile.createLeader({ name: 'Pastor Fixture', role_title: 'Pastor', group_label: 'Pastors' });
const leaderId = leader.id ?? leader;
const filesIn = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir).sort() : []);

const targets = [
  { name: 'member photo', url: `/members/${ids.member.a2}/photo`, dir: path.join(storage, 'members', String(ids.member.a2)), column: () => db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(ids.member.a2).p, table: 'members' },
  { name: 'cell group photo', url: `/cell-groups/${ids.groupA}/photo`, dir: path.join(storage, 'groups', String(ids.groupA)), column: () => db.prepare('SELECT photo_path p FROM cell_groups WHERE id = ?').get(ids.groupA).p, table: 'cell_groups' },
  { name: 'ministry photo', url: `/ministries/${ids.ministry}/photo`, dir: path.join(storage, 'ministries', String(ids.ministry)), column: () => db.prepare('SELECT photo_path p FROM ministries WHERE id = ?').get(ids.ministry).p, table: 'ministries' },
  { name: 'leader photo', url: `/admin/about/leaders/${leaderId}/photo`, dir: path.join(storage, 'leaders', String(leaderId)), column: () => db.prepare('SELECT photo_path p FROM church_leaders WHERE id = ?').get(leaderId).p, table: 'church_leaders' },
  { name: 'giving board picture', url: `/admin/ecaq/campaigns/${ids.board}/background`, dir: path.join(storage, 'ecaq-boards', String(ids.board)), column: () => db.prepare('SELECT background_image p FROM ecaq_campaigns WHERE id = ?').get(ids.board).p, table: 'ecaq_campaigns', background: true }
];

// ---- streamFile never stops the process ------------------------------------------------------------------------------------------
{
  const tmp = path.join(os.tmpdir(), `cciq-stream-${process.pid}.bin`);
  fs.writeFileSync(tmp, 'hello world');
  const sink = new PassThrough(); let got = '';
  sink.on('data', (d) => { got += d; });
  await new Promise((resolve) => { sink.on('end', resolve); sink.removeHeader = () => {}; streamFile(sink, tmp, () => assert.fail('no error for a readable file')); });
  assert.equal(got, 'hello world');
  fs.rmSync(tmp, { force: true });

  const res = new PassThrough(); res.headersSent = false; const removed = [];
  res.removeHeader = (h) => removed.push(h);
  const err = await new Promise((resolve) => streamFile(res, path.join(os.tmpdir(), 'cciq-no-such-file.bin'), resolve));
  assert.equal(err.code, 'ENOENT', 'a file that vanished is handed to the error page instead of becoming an unhandled stream error');
  assert.ok(removed.includes('Content-Disposition') && removed.includes('Content-Type'), 'and the download headers are dropped first');
  console.log('PASS (stream) a readable file is sent whole; one that cannot be opened reaches the error page, not the process');
}

// ---- an abandoned import preview does not stay on disk ---------------------------------------------------------------------------
{
  const imports = await import('../services/imports.js');
  const dir = path.join(storage, 'imports');
  const old = imports.stageImport({ kind: 'members', rows: [['Name'], ['Somebody']] }, { userId: users.superAdmin.id });
  const oldFile = path.join(dir, old + '.json');
  assert.ok(fs.existsSync(oldFile), 'a staged upload exists');
  const sevenHoursAgo = new Date(Date.now() - 7 * 3600 * 1000);
  fs.utimesSync(oldFile, sevenHoursAgo, sevenHoursAgo);
  const recent = imports.stageImport({ kind: 'members', rows: [['Name']] }, { userId: users.superAdmin.id }); // staging a new one clears the abandoned one
  assert.ok(!fs.existsSync(oldFile), 'a staged spreadsheet older than six hours is removed (it holds member details)');
  assert.ok(fs.existsSync(path.join(dir, recent + '.json')), 'a recent one is kept');
  imports.discardStagedImport(recent);
  assert.ok(!fs.existsSync(path.join(dir, recent + '.json')), 'and discarding removes it at once');
  console.log('PASS (staged imports) an abandoned import preview is cleared after six hours; a fresh one is kept');
}

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const anon = (p) => fetch(portal.base + p, { redirect: 'manual' });

  // ---- nothing private is served as a static file --------------------------------------------------------------------------------
  const secret = ['/storage/members/1/x.png', '/storage-dev/', '/data/cciq.sqlite', '/data-dev/cciq.sqlite', '/.env', '/.env.example', '/package.json', '/package-lock.json', '/src/server.js', '/src/db/schema.sql', '/node_modules/express/package.json', '/.git/config', '/tools/run-tests.mjs', '/docs/UX-STANDARDS.md', '/logs/', '/runtime/node.exe', '/scripts/first-run.mjs', '/deploy/'];
  for (const p of secret) {
    const a = await anon(p); await a.arrayBuffer();
    const b = await fetch(portal.base + p, { redirect: 'manual', headers: { cookie: admin.cookie } }); await b.arrayBuffer();
    assert.ok([301, 302, 303, 404].includes(a.status) && (a.status !== 302 || /login/.test(a.headers.get('location') || '')), `${p} is not served to a visitor (${a.status})`);
    assert.equal(b.status, 404, `${p} is not served to a signed-in administrator either (${b.status})`);
  }
  console.log(`PASS (exposure) ${secret.length} private paths (storage, databases, .env, source, tools, docs, logs, git) are never served over HTTP`);

  // ---- photo uploads ---------------------------------------------------------------------------------------------------------------
  for (const t of targets) {
    const field = 'photo';
    let res = await admin.upload(t.url, png('../../evil.png'), { field, csrfFrom: '/' }); await res.arrayBuffer();
    assert.ok(res.status < 400, `${t.name}: a valid PNG is accepted (${res.status})`);
    const first = filesIn(t.dir);
    assert.equal(first.length, 1, `${t.name}: exactly one file is kept`);
    assert.match(first[0], /^[0-9a-f]{24,32}\.png$/, `${t.name}: stored under a random name, never the uploader's (${first[0]})`);
    assert.deepEqual(fs.readFileSync(path.join(t.dir, first[0])), PNG, `${t.name}: stored byte for byte`);
    if (!t.background) assert.ok(String(t.column()).endsWith(first[0]), `${t.name}: the record points at the stored file`);

    res = await admin.upload(t.url, png(), { field, csrfFrom: '/' }); await res.arrayBuffer();
    const second = filesIn(t.dir);
    assert.equal(second.length, 1, `${t.name}: a replacement leaves one file, not two`);
    assert.notEqual(second[0], first[0], `${t.name}: and it is the new one`);
    if (!t.background) assert.ok(String(t.column()).endsWith(second[0]));

    const before = { files: filesIn(t.dir), column: t.column() };
    const refuse = [
      ['text pretending to be a PNG', { name: 'a.png', type: 'image/png', buffer: Buffer.from('just some text, not an image at all') }],
      ['HTML pretending to be a PNG', { name: 'a.png', type: 'image/png', buffer: Buffer.from('<html><script>alert(1)</script></html>          ') }],
      ['an executable named .jpg', { name: 'a.jpg', type: 'image/jpeg', buffer: Buffer.concat([Buffer.from('MZ'), Buffer.alloc(200)]) }],
      ['an SVG', { name: 'a.svg', type: 'image/svg+xml', buffer: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>') }],
      ['a GIF', { name: 'a.gif', type: 'image/gif', buffer: Buffer.from('GIF89a' + 'x'.repeat(40)) }],
      ['an empty file', { name: 'a.png', type: 'image/png', buffer: Buffer.alloc(0) }],
      ['a file over the size limit', { name: 'big.png', type: 'image/png', buffer: Buffer.concat([PNG.subarray(0, 8), Buffer.alloc(5 * 1024 * 1024)]) }]
    ];
    for (const [what, file] of refuse) {
      res = await admin.upload(t.url, file, { field, csrfFrom: '/' }); await res.arrayBuffer();
      assert.ok(res.status < 500, `${t.name}: ${what} is refused cleanly (${res.status})`);
      assert.deepEqual(filesIn(t.dir), before.files, `${t.name}: ${what} leaves the stored files untouched`);
      assert.equal(t.column(), before.column, `${t.name}: ${what} leaves the record untouched`);
    }
    res = await admin.upload(t.url, png(), { field: 'wrongfield', csrfFrom: '/' }); await res.arrayBuffer();
    assert.ok(res.status < 500);
    assert.deepEqual(filesIn(t.dir), before.files, `${t.name}: a file under the wrong field name is ignored`);
    res = await admin.upload(t.url, png(), { field, csrfFrom: '/', csrf: 'not-the-token' }); await res.arrayBuffer();
    assert.ok(res.status === 403, `${t.name}: a wrong CSRF token is refused (${res.status})`);
    assert.deepEqual(filesIn(t.dir), before.files, `${t.name}: and nothing is stored`);

    // the database write fails: the previous picture is kept, and no stray file is left
    db.exec(`CREATE TRIGGER inject_photo_fail BEFORE UPDATE ON ${t.table} BEGIN SELECT RAISE(ABORT, 'injected failure'); END`);
    res = await admin.upload(t.url, png(), { field, csrfFrom: '/' }); await res.arrayBuffer();
    db.exec('DROP TRIGGER inject_photo_fail');
    assert.ok(res.status === 500 || res.status === 302, `${t.name}: a failed save is reported (${res.status})`);
    assert.deepEqual(filesIn(t.dir), before.files, `${t.name}: after a failed save the previous file is still there and no new file is left behind`);
    assert.equal(t.column(), before.column, `${t.name}: and the record still points at it`);
  }
  console.log(`PASS (photos) ${targets.length} upload points: valid images stored under random names (one kept); text, HTML, executables, SVG, GIF, empty, oversize, wrong field and wrong token refused with nothing changed; a failed save keeps the previous picture and leaves no stray file`);

  // ---- downloads ---------------------------------------------------------------------------------------------------------------------
  const nasty = 'a"b\r\nX-Injected: 1; ‮txt.png';
  const created = mods.documents.createDocument({ title: 'Nasty name' }, { userId: users.churchAdmin.id, file: { originalname: nasty, buffer: PNG, size: PNG.length } });
  const docId = created.id ?? created.document?.id;
  for (const query of ['', '?download=1']) {
    const res = await admin.get(`/documents/${docId}/file${query}`);
    await res.arrayBuffer();
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('x-injected'), null, 'a file name cannot inject a response header');
    const disposition = res.headers.get('content-disposition');
    assert.match(disposition, /^(inline|attachment); filename="[\w.\- ]+"; filename\*=UTF-8''[A-Za-z0-9%._~-]+$/, `the file name is reduced to safe characters (${disposition})`);
    assert.equal(res.headers.get('content-type'), 'image/png', 'served as the detected type');
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.match(res.headers.get('content-security-policy'), /sandbox/);
  }
  const gone = await admin.get('/documents/99999/file'); await gone.text();
  assert.equal(gone.status, 404);
  const stored = db.prepare('SELECT stored_path FROM documents WHERE id = ?').get(docId).stored_path;
  assert.ok(!stored.includes('Nasty') && !stored.includes('X-Injected'), 'the stored path never contains the uploaded file name');
  // a file removed from disk behind the portal's back is a 404, not a crash
  fs.rmSync(path.join(storage, stored), { force: true });
  const missing = await admin.get(`/documents/${docId}/file`); await missing.text();
  assert.equal(missing.status, 404, 'a missing file is a 404');
  assert.equal((await anon('/healthz')).status, 200, 'and the server is still up');
  console.log('PASS (downloads) hostile file names cannot inject headers or reach the stored path; type, nosniff and sandbox headers are set; a missing file is a 404');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
