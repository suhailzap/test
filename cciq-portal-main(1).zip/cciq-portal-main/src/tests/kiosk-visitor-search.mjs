import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Returning First Timer search at the check-in desk, and Express First Timer Registration.
 *
 *   - a returning First Timer is found by name or by their WHOLE normalized mobile number (never a fragment, never a member's number);
 *   - the desk sees only the masked tail ("•••• 9999"): the full number is in no HTML, attribute, link or hidden field, and a number
 *     typed into the search is not echoed back or kept in a URL;
 *   - a First Timer cannot be crowded out of the results by a page of member matches;
 *   - Express Registration creates the First Timer and today's visit together, needs the narrow permission, is audited, and a Kiosk can
 *     NEVER override a possible duplicate (the owner has not decided that; the warning names no one).
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-kiosk-visitor-search-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const attendance = await import('../services/attendance.js');
const { maskPhone, looksLikePhone, echoableTerm } = await import('../lib/phone.js');
const { today, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ks${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'ks_admin', email: 'ks.admin@fixture.invalid', password: PASSWORD, displayName: 'KS Admin', roleKeys: ['church_admin'], mustChangePassword: false });
await createUser({ username: 'ks_kiosk_a', email: 'ks.kiosk.a@fixture.invalid', password: PASSWORD, displayName: 'Kiosk A', roleKeys: ['kiosk'], mustChangePassword: false });
await createUser({ username: 'ks_kiosk_b', email: 'ks.kiosk.b@fixture.invalid', password: PASSWORD, displayName: 'Kiosk B', roleKeys: ['kiosk'], mustChangePassword: false });
await createUser({ username: 'ks_member', email: 'ks.member@fixture.invalid', password: PASSWORD, displayName: 'KS Member', roleKeys: ['member'], mustChangePassword: false });

const FRIDAY = lastFridayOnOrBefore(today());
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(FRIDAY, new Date().toISOString());
const session = db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(FRIDAY);

// 25 members all matching "Tan", a returning First Timer who also matches "Tan", a member whose number must never be searchable here
for (let i = 1; i <= 25; i += 1) createMember({ first_name: `Tan${String(i).padStart(2, '0')}`, last_name: 'Member' }, { status: 'active' });
const memberWithPhone = createMember({ first_name: 'Marian', last_name: 'Existing', phone: '+974 5550 1234' }, { status: 'active' });
const grace = visitors.createVisitor({ first_name: 'Grace', last_name: 'Newcomer', phone: '+974 5551 9999', first_visit_date: addDaysIso(FRIDAY, -14) });
const tanya = visitors.createVisitor({ first_name: 'Tanya', last_name: 'Visitor', phone: '+974 5552 7777', first_visit_date: addDaysIso(FRIDAY, -14) });
const noPhone = visitors.createVisitor({ first_name: 'Nophone', last_name: 'Person', first_visit_date: addDaysIso(FRIDAY, -14) });
const linked = visitors.createVisitor({ first_name: 'Linked', last_name: 'Already', phone: '+974 5553 4444', first_visit_date: addDaysIso(FRIDAY, -14) });
const linkedMember = createMember({ first_name: 'Linked', last_name: 'Already', phone: '+974 5553 4444' }, { status: 'active' });
visitors.linkVisitorToMember(linked.id, linkedMember.id, { userId: null });

function addDaysIso(date, n) { const d = new Date(`${date}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }

// ---- pure helpers --------------------------------------------------------------------------------------------------------------
assert.equal(maskPhone('+974 5551 9999'), '•••• 9999');
assert.equal(maskPhone('(974) 555-1-9999'), '•••• 9999', 'only digits count');
assert.equal(maskPhone(''), null); assert.equal(maskPhone(null), null);
assert.equal(maskPhone('12'), '••••', 'a number shorter than four digits shows no digits at all');
assert.equal(looksLikePhone('+974 5551 9999'), true); assert.equal(looksLikePhone('5551'), false, 'too short to be a number'); assert.equal(looksLikePhone('Grace 5551'), false); assert.equal(looksLikePhone('CCIQ-0001'), false, 'a member code is not a phone number');
assert.equal(echoableTerm('55519999'), ''); assert.equal(echoableTerm('Grace'), 'Grace');
console.log('PASS (phone helpers) masking shows the last four digits only; only a whole phone-shaped term is treated as a number');

// ---- service-level search ---------------------------------------------------------------------------------------------------------
// the canonical phone key (lib/phone.js) treats Qatar's eight local digits as the whole number, with or without +974 / 00974
const phoneForms = ['+974 5551 9999', '97455519999', '974-5551-9999', '(974) 5551 9999', ' +974 55519999 ', '5551 9999', '55519999', '00974 5551 9999'];
for (const form of phoneForms) {
  const found = attendance.searchPeopleForAttendance(form);
  assert.deepEqual(found.map((p) => `${p.type}:${p.id}`), [`visitor:${grace.id}`], `the whole number written as "${form}" finds exactly that First Timer`);
  assert.equal(found[0].detail, 'Returning · Review pending · •••• 9999', 'Grace visited two weeks ago: she is a returning person now, not a First Timer again');
  assert.ok(!JSON.stringify(found).match(/5551|974/), 'the result carries no part of the number but the last four digits');
}
for (const fragment of ['5551 999', '55519', '555', '9999', '+974 5551', '974 5551 999']) {
  assert.equal(attendance.searchPeopleForAttendance(fragment).some((p) => p.type === 'visitor' && p.id === grace.id), false, `a fragment ("${fragment}") never finds a First Timer by phone`);
}
{ // superseded by the owner's later decision: a member's WHOLE number is searchable at the desk too (see kiosk-phone-search.mjs); still masked, whole number only
  const found = attendance.searchPeopleForAttendance('+974 5550 1234');
  assert.equal(found.length, 1); assert.equal(found[0].type, 'member'); assert.match(found[0].detail, /•••• 1234$/); assert.ok(!/5550/.test(JSON.stringify(found)), 'the member\'s number is never shown');
  assert.deepEqual(attendance.searchPeopleForAttendance('5550 123'), [], 'and a fragment of it finds no one');
}
assert.deepEqual(attendance.searchPeopleForAttendance('+974 5553 4444').map((p) => p.type), ['member'], 'a First Timer already linked to a member is not offered as a First Timer: the same number finds them as the member, once');
assert.deepEqual(attendance.searchPeopleForAttendance('+974 5559 0000'), [], 'an unknown number finds no one');
assert.ok(!/•/.test(attendance.searchPeopleForAttendance('Nophone Person')[0].detail), 'with no number on file there is nothing to mask');
console.log('PASS (search by number) whole normalized number only, any formatting; fragments and linked First Timers are not matched; a member is found by their whole number; results carry only the masked tail');

// ---- result allocation: member matches cannot starve First Timers -------------------------------------------------------------------
const tanResults = attendance.searchPeopleForAttendance('Tan');
assert.equal(tanResults.length, 20, 'the list is still capped at 20');
assert.ok(tanResults.some((p) => p.type === 'visitor' && p.id === tanya.id), 'a valid First Timer is not lost because 25 members matched first');
assert.ok(tanResults.filter((p) => p.type === 'member').length >= 15, 'and members still fill the remaining places');
assert.equal(new Set(tanResults.map((p) => `${p.type}:${p.id}`)).size, tanResults.length, 'nobody is listed twice');
assert.equal(attendance.searchPeopleForAttendance('Tan', { limit: 3 }).length, 3, 'a small limit is honoured');
const fewMembers = attendance.searchPeopleForAttendance('Newcomer');
assert.deepEqual(fewMembers.map((p) => p.type), ['visitor'], 'with few member matches, the unused places are simply empty');
assert.deepEqual(attendance.searchPeopleForAttendance('Grace Newcomer').map((p) => p.id), [grace.id], 'full name');
assert.ok(attendance.searchPeopleForAttendance('Nophone Person').some((p) => p.id === noPhone.id), 'a First Timer with no surname or number on file can be found');
const noLast = visitors.createVisitor({ first_name: 'Solo', first_visit_date: addDaysIso(FRIDAY, -14) });
assert.ok(attendance.searchPeopleForAttendance('Solo').some((p) => p.id === noLast.id), 'a First Timer with NO surname is found by first name');
assert.ok(attendance.searchPeopleForAttendance('Solo ').some((p) => p.id === noLast.id), 'and by full-name search with a trailing space');
console.log('PASS (allocation) 25 member matches cannot hide a First Timer; limit, de-duplication and the no-surname case hold');

// ---- over HTTP ------------------------------------------------------------------------------------------------------------------------
const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function sessionFor(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const admin = await sessionFor('ks.admin@fixture.invalid');
  const kioskA = await sessionFor('ks.kiosk.a@fixture.invalid');
  const kioskB = await sessionFor('ks.kiosk.b@fixture.invalid');
  const plain = await sessionFor('ks.member@fixture.invalid');
  const get = (url, cookie) => fetch(`${base}${url}`, { headers: { Cookie: cookie }, redirect: 'manual' });
  const csrfOf = async (cookie) => (await (await get('/kiosk', cookie)).text()).match(/name="_csrf" value="([^"]+)"/)?.[1]
    || (await (await get('/visitors/new', cookie)).text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const post = async (url, fields, cookie, { csrf = true } = {}) => fetch(`${base}${url}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ ...(csrf ? { _csrf: await csrfOf(cookie) } : {}), ...fields })
  });
  const visitorCount = () => db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
  const memberCount = () => db.prepare('SELECT COUNT(*) n FROM members').get().n;

  // -- the search screen never shows or keeps the number --
  for (const [label, cookie] of [['Kiosk A', kioskA], ['Kiosk B', kioskB]]) {
    const res = await post('/attendance/checkin/search', { q: '+974 5551 9999', kiosk: '1' }, cookie);
    const html = await res.text();
    assert.equal(res.status, 200, `${label}: a number search works`);
    assert.match(html, /Grace Newcomer/); assert.match(html, /First Timer/); assert.match(html, /•••• 9999/, `${label}: the masked tail is shown`);
    assert.doesNotMatch(html, /5551[\s -]*9999/, `${label}: the full number is nowhere in the page`);
    assert.doesNotMatch(html, /97455519999|\+974/, `${label}: not even in another formatting or the country code`);
    assert.doesNotMatch(html, /value="[^"]*555[^"]*"/, `${label}: not in the search box, a hidden field or any attribute`);
    assert.doesNotMatch(html, /name="q" value="[^"]+"/, `${label}: the number is not carried forward in a hidden field`);
  }
  const adminSearch = await (await post('/attendance/checkin/search', { q: '97455519999' }, admin)).text();
  assert.match(adminSearch, /Grace Newcomer/, 'the administrator check-in screen finds them too');
  assert.doesNotMatch(adminSearch, /5551[\s-]*9999|97455519999/, 'and also never shows the number');
  const nameSearch = await (await post('/attendance/checkin/search', { q: 'Newcomer', kiosk: '1' }, kioskA)).text();
  assert.match(nameSearch, /name="q" value="Newcomer"/, 'a name search is echoed back as before');
  const none = await (await post('/attendance/checkin/search', { q: '+974 5559 0000', kiosk: '1' }, kioskA)).text();
  assert.match(none, /No one found/, 'an unknown number says so'); assert.doesNotMatch(none, /5559[\s-]*0000/);
  const memberNumber = await (await post('/attendance/checkin/search', { q: '+974 5550 1234', kiosk: '1' }, kioskA)).text();
  // superseded by the owner's later decision (kiosk-phone-search.mjs): the member who holds the WHOLE number is found, by name and last four digits only
  assert.match(memberNumber, /Marian/, 'a member\'s whole number finds them');
  assert.match(memberNumber, /•••• 1234/); assert.doesNotMatch(memberNumber, /5550[\s-]*1234/, 'and the number itself is not shown or echoed');

  // hostile and odd search terms never error, never match everyone, and a number-shaped one is never echoed
  const longDigits = '1234567890'.repeat(9);
  for (const term of ['%', '_', '%%', '\\', "O'Brien", '"><script>1</script>', '\u{1F600}', '   ', 'x', 'a'.repeat(500), '9'.repeat(200), '+', '+++', longDigits, 'Gr\u0000ace']) {
    const res = await post('/attendance/checkin/search', { q: term, kiosk: '1' }, kioskA);
    assert.ok(res.status < 500, `search for ${JSON.stringify(term).slice(0, 30)} does not error (${res.status})`);
    const html = await res.text();
    assert.doesNotMatch(html, /SqliteError|at \w+ \(|node_modules/, 'and shows no internals');
    if (/^[%_]+$/.test(term)) assert.doesNotMatch(html, /Grace Newcomer|Tan01/, `"${term}" is a character, not a wildcard`);
    if (/^9{200}$/.test(term)) assert.doesNotMatch(html, /9{20}/, 'a long number is not echoed');
  }
  assert.equal((await post('/attendance/checkin/search', {}, kioskA)).status, 200, 'a search with no term is an empty search');
  assert.ok((await post('/attendance/checkin/search', { q: ['a', 'b'], kiosk: '1' }, kioskA)).status < 500, 'a term sent twice is not a server error');

  // a number must not be accepted in a URL
  const urlSearch = await get('/kiosk?q=%2B97455519999', kioskA);
  assert.equal(urlSearch.status, 302); assert.equal(urlSearch.headers.get('location'), '/kiosk', 'a number in the address bar is dropped, not searched or echoed');
  const urlSearchAdmin = await get('/attendance/checkin?q=97455519999', admin);
  assert.equal(urlSearchAdmin.status, 302); assert.equal(urlSearchAdmin.headers.get('location'), '/attendance/checkin');
  assert.equal((await get('/kiosk?q=Newcomer', kioskA)).status, 200, 'a name in the URL still works');

  // CSRF and permission
  assert.equal((await post('/attendance/checkin/search', { q: 'Grace' }, kioskA, { csrf: false })).status, 403, 'the search post needs the CSRF token');
  assert.ok([302, 403].includes((await post('/attendance/checkin/search', { q: 'Grace' }, plain)).status), 'a plain member cannot search');

  // review step never echoes a forged number in q
  const review = await (await post('/attendance/checkin/review', { q: '+974 5551 9999', person: `visitor:${grace.id}`, kiosk: '1' }, kioskA)).text();
  assert.match(review, /Grace Newcomer/); assert.doesNotMatch(review, /5551[\s-]*9999|97455519999/, 'the review step does not echo a number-shaped search term');

  // recording a returning First Timer from the search results
  const visitsBefore = db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(grace.id).n;
  const rec = await fetch(`${base}/attendance/checkin/record`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskA, Accept: 'application/json' },
    body: new URLSearchParams({ _csrf: await csrfOf(kioskA), person: `visitor:${grace.id}`, kiosk: '1' })
  });
  assert.ok([200, 302].includes(rec.status), `record accepted (${rec.status})`);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(grace.id).n, visitsBefore + 1, 'a returning First Timer\'s visit is recorded');
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(grace.id).state, 'returning', 'and they are now Returning');
  console.log('PASS (kiosk search) both Kiosk accounts and the administrator find a returning First Timer by whole number; the number appears nowhere in the response; it is refused in a URL; CSRF holds; recording works');

  // ---- Express First Timer Registration ----------------------------------------------------------------------------------------------
  const formRes = await get('/attendance/checkin/first-timer', kioskA);
  assert.equal(formRes.status, 200, 'a Kiosk account reaches the registration form');
  const formHtml = await formRes.text();
  assert.match(formHtml, /name="first_name"/); assert.doesNotMatch(formHtml, /name="email"|name="notes"|name="invited_by_name"|name="age_group"|name="how_heard"/, 'the form asks for as little as possible (the optional "Invited by" is the only addition)');
  assert.match(formHtml, /name="invited_by_member_id"/, 'and offers the optional Invited by');
  assert.match(await (await get('/kiosk', kioskA)).text(), /First time here\?/, 'the kiosk offers it');
  assert.equal((await get('/attendance/checkin/first-timer', kioskB)).status, 200, 'Kiosk B too (role-based)');
  assert.equal((await get('/attendance/checkin/first-timer', plain)).status, 403, 'a plain member cannot');
  assert.equal((await post('/attendance/checkin/first-timer', { first_name: 'Sneaky' }, plain)).status, 403);
  assert.equal((await post('/attendance/checkin/first-timer', { first_name: 'Sneaky' }, kioskA, { csrf: false })).status, 403, 'CSRF is required');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Sneaky'").get().n, 0);

  const before = { visitors: visitorCount(), members: memberCount() };
  const ok = await post('/attendance/checkin/first-timer', { first_name: 'Hannah', last_name: 'Fresh', phone: '+974 5554 0001', kiosk: '1' }, kioskA);
  assert.equal(ok.status, 302); assert.equal(ok.headers.get('location'), '/attendance/checkin/first-timer/done', 'the registration tab ends on its done page');
  const hannah = db.prepare("SELECT * FROM visitors WHERE first_name = 'Hannah'").get();
  assert.ok(hannah, 'the First Timer exists'); assert.equal(visitorCount(), before.visitors + 1); assert.equal(memberCount(), before.members, 'no member is created');
  assert.equal(hannah.state, 'new'); assert.equal(hannah.member_id, null); assert.equal(hannah.first_visit_date, session.service_date, 'the first visit is today\'s service');
  const hannahVisits = db.prepare('SELECT * FROM visitor_visits WHERE visitor_id = ?').all(hannah.id);
  assert.equal(hannahVisits.length, 1); assert.equal(hannahVisits[0].session_id, session.id); assert.equal(hannahVisits[0].visit_date, session.service_date, 'one visit, tied to today\'s service');
  const audit = db.prepare("SELECT * FROM audit_logs WHERE action = 'visitor.express_registered' AND entity_id = ?").all(String(hannah.id));
  assert.equal(audit.length, 1, 'exactly one audit row');
  assert.doesNotMatch(JSON.stringify(audit), /5554/, 'and it holds no phone number');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM visitor_membership_reviews").get().n, 0, 'registering opens no membership review');

  // just a first name is enough
  const solo = await post('/attendance/checkin/first-timer', { first_name: 'Ruth', kiosk: '1' }, kioskB);
  assert.equal(solo.status, 302);
  const ruth = db.prepare("SELECT * FROM visitors WHERE first_name = 'Ruth'").get();
  assert.ok(ruth && ruth.last_name === null && ruth.phone === null, 'only the first name is required');

  // the same submission twice makes one record
  const dup1 = await post('/attendance/checkin/first-timer', { first_name: 'Twice', phone: '+974 5554 0002', kiosk: '1' }, kioskA);
  const dup2 = await post('/attendance/checkin/first-timer', { first_name: 'Twice', phone: '+974 5554 0002', kiosk: '1' }, kioskA);
  assert.equal(dup1.status, 302); assert.ok([302, 409].includes(dup2.status));
  assert.equal(db.prepare("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Twice'").get().n, 1, 'a double tap registers one person');

  // validation
  for (const [label, fields] of [['no first name', { first_name: '' }], ['letters in the number', { first_name: 'Bad', phone: 'abc123456' }], ['a huge name', { first_name: 'x'.repeat(500) }]]) {
    const n = visitorCount();
    const res = await post('/attendance/checkin/first-timer', { ...fields, kiosk: '1' }, kioskA);
    assert.equal(res.status, 400, `${label} is a 400`);
    assert.equal(visitorCount(), n, `${label} saves nothing`);
  }
  const repeated = await fetch(`${base}/attendance/checkin/first-timer`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskA },
    body: `_csrf=${encodeURIComponent(await csrfOf(kioskA))}&first_name=Rep&first_name=Eat&kiosk=1` });
  assert.ok(repeated.status < 500, 'a field sent twice is not a server error');

  // a possible duplicate is never overridable by a Kiosk, and the warning names no one
  for (const fields of [
    { first_name: 'Grace', last_name: 'Newcomer' },                                  // same name as a First Timer
    { first_name: 'Someone', last_name: 'Else', phone: '974 5551 9999' },            // same number as a First Timer
    { first_name: 'Marian', last_name: 'Existing' },                                 // same name as a member
    { first_name: 'Different', last_name: 'Name', phone: '(974) 5550-1234' },        // same number as a member
    { first_name: 'Grace', last_name: 'Newcomer', duplicate_override: '1' },         // a forged override
    { first_name: 'Grace', last_name: 'Newcomer', override: 'true', confirm: '1', force: '1' }
  ]) {
    const n = visitorCount();
    const res = await post('/attendance/checkin/first-timer', { ...fields, kiosk: '1' }, kioskA);
    const html = await res.text();
    assert.equal(res.status, 409, `a possible duplicate stops the Kiosk (${JSON.stringify(fields)})`);
    assert.equal(visitorCount(), n, 'nothing is saved');
    assert.match(html, /may already be on file/);
    assert.doesNotMatch(html, /href="\/(visitors|members)\/\d+/, 'no link to anyone\'s record');
    assert.doesNotMatch(html, /Marian Existing|Grace Newcomer|MEM-|•••• (9999|1234)/, 'the warning names nobody and shows nothing about who matched');
  }
  // the administrative screen keeps its owner-approved "record anyway"
  const adminDup = await post('/visitors', { first_name: 'Grace', last_name: 'Newcomer', first_visit_date: today(), duplicate_override: '1' }, admin);
  assert.equal(adminDup.status, 302, 'an administrator can still record anyway on the administrative screen');

  // administrators with the permission may use it; the Kiosk still cannot reach administration
  const adminOk = await post('/attendance/checkin/first-timer', { first_name: 'Adminreg' }, admin);
  assert.equal(adminOk.status, 302); assert.equal(adminOk.headers.get('location'), '/attendance/checkin/first-timer/done', 'an administrative desk gets its own clean "done" page (the check-in tab is untouched)');
  for (const denied of ['/visitors', '/visitors/new', '/visitors/reviews', `/visitors/${hannah.id}`, '/members', '/members/new']) {
    const res = await get(denied, kioskA);
    assert.ok([302, 403].includes(res.status), `${denied} stays closed to a Kiosk account`);
  }
  assert.equal((await post('/visitors', { first_name: 'Nope', first_visit_date: today() }, kioskA)).status === 302 && db.prepare("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Nope'").get().n === 0, true);
  const convertAttempt = await post(`/visitors/${hannah.id}/convert`, { first_name: 'Hannah', last_name: 'Fresh' }, kioskA);
  assert.ok([302, 403].includes(convertAttempt.status)); assert.equal(db.prepare('SELECT member_id FROM visitors WHERE id = ?').get(hannah.id).member_id, null, 'the Kiosk cannot convert anyone');

  // all-or-nothing: a failure while auditing leaves no First Timer and no visit, shows a safe error, and a retry then works
  db.exec("CREATE TRIGGER fx_express BEFORE INSERT ON audit_logs WHEN NEW.action = 'visitor.express_registered' BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
  const atomBefore = { visitors: visitorCount(), visits: db.prepare('SELECT COUNT(*) n FROM visitor_visits').get().n };
  const originalError = console.error;
  const atom = await post('/attendance/checkin/first-timer', { first_name: 'Atomic', kiosk: '1' }, kioskA);
  const atomPage = await atom.text();
  db.exec('DROP TRIGGER fx_express');
  assert.ok(atom.status >= 500, `the failure is reported (${atom.status})`);
  assert.doesNotMatch(atomPage, /injected failure|SqliteError|at \w+ \(|node_modules/, 'with no internals on the page');
  assert.deepEqual({ visitors: visitorCount(), visits: db.prepare('SELECT COUNT(*) n FROM visitor_visits').get().n }, atomBefore, 'no half-registered First Timer: no visitor row and no visit row');
  const retry = await post('/attendance/checkin/first-timer', { first_name: 'Atomic', kiosk: '1' }, kioskA);
  assert.equal(retry.status, 302, 'the retry registers them');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Atomic'").get().n, 1, 'exactly once');
  void originalError;

  // a database guard maps to a clean 409, not a 500
  // closed check-in: nothing can be registered
  db.prepare("UPDATE attendance_sessions SET finalization_state = 'not_taken' WHERE id = ?").run(session.id);
  const closedBefore = visitorCount();
  const closedGet = await get('/attendance/checkin/first-timer', kioskA);
  assert.equal(closedGet.status, 302, 'the form is not offered when check-in is closed');
  const closedPost = await post('/attendance/checkin/first-timer', { first_name: 'Toolate', kiosk: '1' }, kioskA);
  assert.equal(closedPost.status, 302); assert.equal(visitorCount(), closedBefore, 'nothing is registered once the Friday is closed');
  db.prepare('UPDATE attendance_sessions SET finalization_state = NULL WHERE id = ?').run(session.id);
  console.log('PASS (express registration) one step creates the First Timer and today\'s visit; audited; first name only is enough; a double tap is one record; invalid input saves nothing; a Kiosk can never override a duplicate and the warning names no one; permission, CSRF and the closed-Friday rule hold');

  // headers
  const noStore = (await get('/attendance/checkin/first-timer', kioskA)).headers.get('cache-control') || '';
  assert.match(noStore, /no-store/, 'the registration page is not cached');
  console.log('ALL PASS');
} finally {
  await terminateAndWait(server);
}
