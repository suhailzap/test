import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Family: every relative (spouse, father, mother) has ONE authoritative identity - a linked CCIQ
 * member (name comes from their own record) or a typed name for someone who is not a member. No
 * schema change; the columns are the same, only which of the two is kept is decided in one place.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-family-identity-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const members = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Fm${crypto.randomBytes(12).toString('base64url')}9!`;
const mk = (first, last, extra = {}) => members.createMember({ first_name: first, last_name: last, ...extra }, { status: 'active' });
const subject = mk('Subject', 'Person', { marital_status: 'married' });
const wife = mk('Wife', 'Linked');
const dad = mk('Dad', 'Linked');
const mum = mk('Mum', 'Linked');
await createUser({ username: 'fam_admin', email: 'fam.admin@fixture.invalid', password: PASSWORD, displayName: 'Fam Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const row = (id) => db.prepare('SELECT * FROM members WHERE id = ?').get(id);

// ---- service rule (no HTTP) ------------------------------------------------
const created = members.createMember({ first_name: 'Child', last_name: 'One', father_name: 'Typed Dad', father_member_id: dad.id, mother_name: 'Typed Mum' }, { status: 'active' });
assert.equal(row(created.id).father_member_id, dad.id);
assert.equal(row(created.id).father_name, null, 'a linked father keeps no second, typed name');
assert.equal(row(created.id).mother_name, 'Typed Mum', 'a non-member mother keeps the typed name');
db.prepare("UPDATE members SET spouse_name = 'Typed Wife' WHERE id = ?").run(subject.id);
members.setSpouse(subject.id, wife.id, {});
assert.equal(row(subject.id).spouse_member_id, wife.id);
assert.equal(row(wife.id).spouse_member_id, subject.id, 'the link is still symmetrical');
assert.equal(row(subject.id).spouse_name, null, 'linking a spouse drops the typed name');
console.log('PASS (service) a link is the only identity; typed names for non-members are untouched; spouse link stays symmetrical');

// ---- HTTP: the form and the route -------------------------------------------
const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf0 = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'fam.admin@fixture.invalid', password: PASSWORD, _csrf: csrf0 })
  });
  const cookie = cookieOf(login, pre);
  const html = async (url) => { const r = await fetch(`${base}${url}`, { headers: { Cookie: cookie } }); assert.equal(r.status, 200, url); return r.text(); };
  const save = async (id, fields) => {
    const csrf = (await html(`/members/${id}/edit`)).match(/name="_csrf" value="([^"]+)"/)[1];
    return fetch(`${base}/members/${id}`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
      body: new URLSearchParams({ _csrf: csrf, first_name: 'Subject', last_name: 'Person', marital_status: 'married', ...fields })
    });
  };

  // The form: one choice per relative, and the link can be undone.
  const form = await html(`/members/${subject.id}/edit`);
  for (const rel of ['spouse', 'father', 'mother']) {
    assert.match(form, new RegExp(`data-relative="${rel}"`), `${rel} has the relative block`);
    assert.match(form, new RegExp(`name="${rel}_mode" value="linked"`));
    assert.match(form, new RegExp(`name="${rel}_mode" value="manual"`));
    assert.match(form, new RegExp(`name="${rel}_member_id"`));
    assert.match(form, new RegExp(`name="${rel}_name"`), `${rel} typed name is still available for non-members`);
  }
  assert.match(form, />A CCIQ member</);
  assert.match(form, />Not a CCIQ member</);
  assert.match(form, />Unlink</, 'a linked relative can be unlinked');
  assert.match(form, /name="parents_attend_cciq"/, 'parents attend CCIQ is kept');
  assert.match(form, /name="anniversary_date"/, 'wedding date is kept');
  console.log('PASS (form) CCIQ member / Not a CCIQ member for spouse, father and mother; Unlink; wedding date and parents-attend kept');

  // Link wins over a typed name; profile shows the linked record with its Member ID.
  let res = await save(subject.id, { father_mode: 'linked', father_member_id: String(dad.id), father_name: 'Ignored Typed', mother_mode: 'manual', mother_member_id: String(mum.id), mother_name: 'Not A Member', spouse_mode: 'linked', spouse_member_id: String(wife.id), spouse_name: 'Ignored Spouse', anniversary_date: '2015-06-01' });
  assert.equal(res.status, 302);
  let r = row(subject.id);
  assert.equal(r.father_member_id, dad.id); assert.equal(r.father_name, null);
  assert.equal(r.mother_member_id, null, 'Not a CCIQ member removes the link'); assert.equal(r.mother_name, 'Not A Member');
  assert.equal(r.spouse_member_id, wife.id); assert.equal(r.spouse_name, null);
  assert.equal(r.anniversary_date, '2015-06-01', 'wedding date untouched');
  const show = await html(`/members/${subject.id}`);
  assert.match(show, new RegExp(`href="/members/${dad.id}"`));
  assert.ok(show.includes(dad.member_code) && show.includes(wife.member_code), 'linked relatives show their CCIQ Member ID');
  assert.match(show, /Not A Member/);
  assert.doesNotMatch(show, /Ignored Typed|Ignored Spouse/);
  console.log('PASS (route) a linked relative keeps the link and drops the typed name; Not a CCIQ member drops the link and keeps the name; the profile shows the linked Member ID');

  // Switching a linked parent to "not a member" replaces the identity; unlinking spouse is symmetrical.
  res = await save(subject.id, { father_mode: 'manual', father_name: 'Now Typed', father_member_id: String(dad.id), spouse_mode: 'manual', spouse_name: 'Ex Typed Spouse', spouse_member_id: String(wife.id) });
  assert.equal(res.status, 302);
  r = row(subject.id);
  assert.equal(r.father_member_id, null); assert.equal(r.father_name, 'Now Typed');
  assert.equal(r.spouse_member_id, null); assert.equal(r.spouse_name, 'Ex Typed Spouse');
  assert.equal(row(wife.id).spouse_member_id, null, 'the other record is unlinked too');
  console.log('PASS (switch) changing to Not a CCIQ member cleanly replaces the link; unlinking a spouse clears both sides');

  // A minor needs a parent identity of either kind.
  const year = new Date().getFullYear() - 8;
  res = await save(subject.id, { date_of_birth: `${year}-01-01`, father_mode: 'manual', father_name: '', mother_mode: 'linked', mother_member_id: String(mum.id) });
  assert.equal(res.status, 400, 'an under-18 with no father identity is refused');
  res = await save(subject.id, { date_of_birth: `${year}-01-01`, father_mode: 'manual', father_name: 'Typed Father', mother_mode: 'linked', mother_member_id: String(mum.id) });
  assert.equal(res.status, 302, 'a typed name and a link each satisfy the minor rule');
  console.log('PASS (minor) either a typed name or a linked record satisfies the under-18 parent rule');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
