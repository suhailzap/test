import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * A portal-wide audit of how input is handled, complementing hostile-post-fuzz.mjs (hostile form BODIES) and error-handling.mjs (forged
 * ids in forms):
 *   1. static: every POST form carries the CSRF token, no form names two ordinary fields alike (a duplicate name makes the browser send
 *      an array), and no link or GET form performs a state change;
 *   2. every GET route is sent hostile query strings (impossible pages and sizes, malformed and impossible dates, repeated and nested
 *      parameters, NUL bytes, unknown enum values, overlong text) and hostile path ids (zero, negative, enormous, fractional): never a 5xx;
 *   3. a redirect target taken from the request can only ever be an internal path.
 */

const views = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'views');
const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));

// ---- 1. static form rules -----------------------------------------------------------------------------------------------------------------------------
{
  const noCsrf = []; const dup = []; const getState = [];
  for (const file of walk(views).filter((x) => x.endsWith('.ejs'))) {
    const rel = path.relative(views, file); const text = fs.readFileSync(file, 'utf8');
    for (const m of text.matchAll(/<form\b[^>]*>([\s\S]*?)<\/form>/g)) {
      const open = m[0].slice(0, m[0].indexOf('>') + 1); const body = m[1];
      if (/method\s*=\s*["']post["']/i.test(open)) {
        if (!/name="_csrf"|csrf/i.test(body) && !/include\(/.test(body)) noCsrf.push(`${rel}: ${open.slice(0, 70)}`);
      } else if (/action\s*=\s*["']\/[^"']*\/(delete|remove|create|save|toggle|archive|restore|approve|finalize|reopen)\b/i.test(open)) getState.push(`${rel}: ${open.slice(0, 70)}`);
      const names = [...body.matchAll(/<(?:input|select|textarea)\b[^>]*\bname\s*=\s*["']([^"'<%]+)["'][^>]*>/g)]
        .filter((x) => !/type\s*=\s*["'](checkbox|radio|hidden)["']/.test(x[0])).map((x) => x[1]);
      const seen = new Set();
      for (const n of names) { if (seen.has(n) && !/\[\]$/.test(n)) dup.push(`${rel}: ${n}`); seen.add(n); }
    }
  }
  // every literal internal link in a template points at a page that exists (a link to a POST-only or retired path is a dead end)
  const toRe = (p) => new RegExp('^' + p.replace(/\\\\/g, '\\').replace(/:\w+(\((?:[^()]|\([^()]*\))*\))?/g, (m, g) => (g || '[^/]+')).replace(/\//g, '\\/') + '$');
  const getRoutes = catalogue().filter((r) => r.method === 'GET').map((r) => toRe(r.path));
  const deadLinks = new Set();
  for (const file of walk(views).filter((x) => x.endsWith('.ejs'))) {
    const rel = path.relative(views, file); const text = fs.readFileSync(file, 'utf8');
    for (const m of text.matchAll(/<a\b[^>]*\bhref\s*=\s*"(\/[^"]*)"/g)) {
      const href = m[1].replace(/<%[-=]?[\s\S]*?%>/g, '1').split('#')[0].split('?')[0];
      if (!href || href === '/' || /^\/(css|js|branding|media|uploads)\//.test(href)) continue;
      if (!getRoutes.some((re) => re.test(href))) deadLinks.add(`${rel}: ${m[1].slice(0, 90)}`);
    }
  }
  assert.deepEqual(noCsrf, [], 'every POST form carries the CSRF token');
  assert.deepEqual(dup, [], 'no form names two ordinary fields alike');
  assert.deepEqual(getState, [], 'no GET form performs a state change');
  assert.deepEqual([...deadLinks], [], 'every literal internal link in a template resolves to a real GET page');
  console.log('PASS (1) every POST form has a CSRF token, no duplicate field names, no state-changing GET form, and every literal internal link resolves to a real page');
}

const f = await buildPortalFixture('cciq-form-audit-');
const { ids, users, db } = f;
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const get = async (url) => { const res = await admin.get(url); const text = await res.text(); return { status: res.status, text, location: res.headers.get('location') }; };

  // ---- 2a. hostile query strings on every GET route -----------------------------------------------------------------------------------------------------
  const routes = catalogue().filter((r) => r.method === 'GET');
  const firstRole = db.prepare('SELECT id FROM roles ORDER BY id LIMIT 1').get().id;
  const fill = (route) => {
    const p = route.path;
    const id = p.startsWith('/members/') ? ids.member.a2 : p.startsWith('/admin/users/') ? users.memberA.id : p.startsWith('/admin/roles/') ? firstRole
      : p.startsWith('/cell-groups/') || p.startsWith('/attendance/cell-groups/') ? ids.groupA : p.startsWith('/ministries/') ? ids.ministry : p.startsWith('/family-groups/') ? ids.family
        : p.startsWith('/visitors/') ? ids.visitor : p.startsWith('/activities/') ? ids.activity : p.startsWith('/announcements/') ? ids.announcement : p.startsWith('/documents/') ? ids.document
          : p.startsWith('/attendance/sessions/') ? ids.session : p.startsWith('/admin/ecaq/campaigns/') ? ids.board : 1;
    return p.replace(/:memberId(\([^)]*\))?/g, String(ids.member.a2)).replace(/:token(\([^)]*\))?/g, '0'.repeat(32)).replace(/:\w+(\([^)]*\))?/g, String(id));
  };
  const SKIP = /\/logout|\/export|\/pdf|\.csv|\/photo|\/file|\/download|\/media\/|\/card|\/qr|\/print|\/backups\/\d+\/download|\/images?\//;
  const queries = [
    '?page=-1&page_size=-5', '?page=99999999999999999999&page_size=99999999999999999999', '?page=0&page_size=0', '?page=1e9&page_size=1e9', '?page=abc&page_size=xyz', '?page=1.5&page_size=2.5',
    '?from=garbage&to=2026-99-99', '?from=2030-01-01&to=2020-01-01', '?from=0000-00-00&to=9999-99-99', '?q=%00&search=%00', `?q=${'x'.repeat(5000)}`, '?q=%25&search=_', '?q[x]=y&search[]=a', '?status=zzz&status=yyy&state=nope',
    '?sort=zzz&dir=sideways&order=1;DROP', '?sort[]=a&sort[]=b', '?id[]=1&id[]=2', '?tab=nope&section=nope&view=nope', '?year=-1&month=13&day=40', '?year=99999&month=abc', '?limit=-1&offset=-1', '?cell_group_id=abc&inviter_id=-5&member_id=1e99'
  ];
  let sent = 0; const bad = [];
  for (const route of routes) {
    const base = fill(route); if (base.includes(':') || SKIP.test(base)) continue;
    for (const q of queries) {
      const res = await admin.get(`${base}${q}`); await res.arrayBuffer(); sent += 1;
      if (res.status >= 500) bad.push(`${res.status} GET ${base}${q.slice(0, 40)}`);
    }
  }
  assert.deepEqual([...new Set(bad)].slice(0, 20), [], 'no GET route answers a hostile query string with a server error');
  console.log(`PASS (2a) ${sent} hostile query strings across ${routes.length} GET routes: none a server error`);

  // ---- 2b. hostile path ids ---------------------------------------------------------------------------------------------------------------------------------
  const idRoutes = routes.filter((r) => /:id\(\\\\d\+\)|:memberId/.test(r.path) && !SKIP.test(r.path));
  let idSent = 0; const idBad = [];
  for (const route of idRoutes) {
    for (const id of ['0', '00', '-1', '99999999999999999999', '2147483648', '1.5', '1e3', '%00', 'abc', '١٢٣']) {
      const url = route.path.replace(/:memberId(\([^)]*\))?/g, id).replace(/:id(\([^)]*\))?/g, id).replace(/:\w+(\([^)]*\))?/g, '1');
      if (url.includes(':')) continue;
      const res = await admin.get(url); await res.arrayBuffer(); idSent += 1;
      if (res.status >= 500) idBad.push(`${res.status} GET ${url}`);
      if (res.status === 200 && !/^[1-9]\d*$/.test(id)) idBad.push(`200 for a non-id: GET ${url}`);
    }
  }
  assert.deepEqual([...new Set(idBad)].slice(0, 20), [], 'a malformed, zero, negative or enormous id is a 404, never a server error and never a page');
  console.log(`PASS (2b) ${idSent} hostile path ids across ${idRoutes.length} routes: all 404 (or refused), none a server error`);

  // ---- 3. redirect targets taken from the request ---------------------------------------------------------------------------------------------------------
  const evil = ['//evil.example', '/\\evil.example', '/\t/evil.example', 'https://evil.example', 'http://evil.example/x', 'javascript:alert(1)', '///evil.example', '/%2f%2fevil.example', '/ evil', '\\\\evil.example', ' //evil.example', '/\u0000//evil.example'];
  for (const link of [...evil, '/members', '/notifications?x=1']) {
    const res = await admin.post(`/notifications/${ids.notifications.superAdmin}/read`, { link }, { csrfFrom: '/notifications' }); await res.text();
    const location = res.headers.get('location');
    assert.equal(res.status, 302, `link ${JSON.stringify(link).slice(0, 30)} -> 302`);
    const resolved = new URL(location, 'http://portal.invalid');
    assert.equal(resolved.origin, 'http://portal.invalid', `the redirect for ${JSON.stringify(link).slice(0, 30)} stays on this portal (${location})`);
    assert.doesNotMatch(location, /^\/[\\/]|[\\\u0000-\u001f]/, 'and is not a protocol-relative or control-character path');
  }
  for (const body of [{ link: ['//evil.example', '/ok'] }, { 'link[x]': '//evil.example' }, {}]) {
    const res = await admin.post(`/notifications/${ids.notifications.superAdmin}/read`, body, { csrfFrom: '/notifications' }); await res.text();
    assert.ok(res.status < 500, 'an array, a nested value or no link is not a server error');
    if (res.status === 302) assert.equal(new URL(res.headers.get('location'), 'http://portal.invalid').origin, 'http://portal.invalid');
  }
  for (const next of evil) {
    const res = await fetch(`${portal.base}/login?next=${encodeURIComponent(next)}`, { redirect: 'manual' }); await res.text();
    assert.ok(res.status < 500);
  }
  console.log(`PASS (3) ${evil.length + 2} hostile redirect targets (protocol-relative, backslash, control characters, absolute, javascript:, arrays) all resolve inside the portal`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
