import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import Database from 'better-sqlite3';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * R02 FINAL BOOTSTRAP CREDENTIAL CORRECTION (Codex/independent
 * verification): the normal account-creation credential-secrecy/password-
 * security work (see credential-secrecy.mjs, password-security.mjs) passed,
 * but first-administrator/bootstrap creation had two separate P2 issues of
 * its own, neither exercised by those suites:
 *
 * 1. scripts/first-run.mjs wrote the generated administrator password to a
 *    plaintext file ("FIRST SIGN-IN.txt") that stayed on disk until someone
 *    manually deleted it. Fixed by removing that file entirely - the
 *    credential is now shown only once, in the setup script's own
 *    interactive console output (the same "one-time" model already used
 *    everywhere else in this codebase), and first-run now refuses outright,
 *    before creating anything, if it would need to generate a new password
 *    but stdout is not an interactive terminal (no safe channel to show it).
 *
 * 2. src/db/seed.js's seedBootstrapAdmin() generated its own fixed
 *    16-character value (crypto.randomBytes(12).toString('base64url')) and
 *    only ever validated it against checkPasswordPolicy() when it was NOT
 *    the generated branch - so a configured PASSWORD_MIN_LENGTH above 16
 *    was silently ignored for the one credential that matters most. Fixed
 *    by generating it with the same generateInitialPassword()
 *    (services/users.js) every other account in this portal already uses,
 *    which sizes itself to the effective min/max and only ever returns a
 *    candidate that already satisfies the policy, or throws if none can be
 *    found for the current configuration.
 *
 * generateInitialPassword() itself is already covered thoroughly by
 * credential-secrecy.mjs (default policy, a raised minimum, a minimum near
 * the fixed maximum, and a self-contradictory configuration failing at
 * startup). This suite instead proves the WIRING: that seedBootstrapAdmin()
 * and first-run.mjs's own process actually go through that same generator
 * and the same safety rules, end to end - which is exactly the part the
 * original bug got wrong.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-bootstrap-credential-safety-');
process.env.BOOTSTRAP_ADMIN_EMAIL = 'bootstrap.fixture@fixture.invalid';
process.env.BOOTSTRAP_ADMIN_NAME = 'Bootstrap Fixture Admin';
delete process.env.BOOTSTRAP_ADMIN_PASSWORD;

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions, seedBootstrapAdmin } = await import('../db/seed.js');
seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { checkPasswordPolicy } = await import('../lib/passwords.js');
const { default: db } = await import('../db/index.js');
const config = (await import('../config/env.js')).default;

function anySessionContains(substring) {
  return db.prepare('SELECT sess FROM sessions').all().some((row) => row.sess.includes(substring));
}
function anyAuditContains(substring) {
  return db.prepare('SELECT detail FROM audit_logs').all().some((row) => row.detail && row.detail.includes(substring));
}

// --- B/F/G. Default policy: seedBootstrapAdmin() itself (not just the
//     underlying generator) produces a policy-valid password, forces a
//     change at first sign-in, and never leaves the plaintext anywhere
//     other than its own one-time return value. ---
{
  // Pre-go-live batch, item F1: with no way to show a generated password
  // safely (the default - a caller must explicitly assert an interactive
  // channel), seedBootstrapAdmin() refuses BEFORE generating or creating
  // anything, so no executable path that reaches it can print one unsafely.
  const refused = await seedBootstrapAdmin();
  assert.equal(refused.created, false);
  assert.equal(refused.code, 'no_safe_channel');
  assert.equal(refused.password, undefined, 'a refusal must never carry a password');
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 0, 'nothing may be created when there is no safe channel');
  console.log('PASS (Item F1): seedBootstrapAdmin() refuses to generate a password unless the caller asserts an interactive channel');
}

{
  const result = await seedBootstrapAdmin({ interactiveOutput: true });
  assert.ok(result.created, 'sanity: the bootstrap admin must be created against a genuinely empty database');
  assert.ok(result.password, 'sanity: a password must have been generated (BOOTSTRAP_ADMIN_PASSWORD was not set)');
  assert.ok(result.password.length >= config.auth.passwordMinLength,
    `ATTACK B: the generated bootstrap password (${result.password.length} chars) must satisfy the configured minimum (${config.auth.passwordMinLength})`);
  assert.equal(checkPasswordPolicy(result.password, { email: result.email }).length, 0,
    'ATTACK B: the generated bootstrap password must satisfy the full active password policy, not just its length');

  const row = db.prepare('SELECT password_hash, must_change_password FROM users WHERE email = ?').get(result.email);
  assert.equal(row.must_change_password, 1, 'ATTACK F: the bootstrap account must be forced to change its password at first sign-in');
  assert.notEqual(row.password_hash, result.password, 'ATTACK G: the stored credential must be a hash, never the plaintext password');
  assert.match(row.password_hash, /^scrypt\$/, 'ATTACK G: the stored credential must be a recognised scrypt hash');
  assert.equal(anySessionContains(result.password), false, 'ATTACK G: the plaintext bootstrap password must never appear in the sessions table');
  assert.equal(anyAuditContains(result.password), false, 'ATTACK G: the plaintext bootstrap password must never appear in audit_logs');
  console.log('PASS (Attack B/F/G): seedBootstrapAdmin() generates a policy-valid password, forces a change at first sign-in, and never persists the plaintext in the database, a session, or the audit log');
}

/**
 * Runs a throwaway, fully self-contained bootstrap (migrate + seed roles/
 * settings + seedBootstrapAdmin) in its OWN child process against its OWN
 * fresh fixture database, with the given environment overrides applied
 * before config/env.js is ever imported. Needed because
 * config/env.js's PASSWORD_MIN_LENGTH is read once per process - testing a
 * different effective policy means a different process, not a different
 * call in this one.
 */
function runBootstrapChild(label, envOverrides) {
  const childRoot = path.join(env.root, `bootstrap-child-${label}`);
  fs.mkdirSync(childRoot, { recursive: true });
  const childEnv = {
    ...process.env,
    NODE_ENV: 'test',
    DOTENV_CONFIG_PATH: path.join(childRoot, 'absent.env'),
    DATABASE_FILE: path.join(childRoot, 'fixture.sqlite'),
    STORAGE_DIR: path.join(childRoot, 'storage'),
    BACKUP_DIR: path.join(childRoot, 'backups'),
    SESSION_SECRET: crypto.randomBytes(32).toString('hex'),
    BOOTSTRAP_ADMIN_EMAIL: 'bootstrap.fixture@fixture.invalid',
    BOOTSTRAP_ADMIN_NAME: 'Bootstrap Fixture Admin',
    ...envOverrides
  };
  delete childEnv.PORT;

  const script = `
    import('${pathToFileURL(path.join(root, 'src/db/migrate.js')).href}').then(async (migrateModule) => {
      migrateModule.migrate();
      const seed = await import('${pathToFileURL(path.join(root, 'src/db/seed.js')).href}');
      seed.seedRolesAndPermissions();
      const { ensureSettings } = await import('${pathToFileURL(path.join(root, 'src/lib/settings.js')).href}');
      ensureSettings();
      const { checkPasswordPolicy } = await import('${pathToFileURL(path.join(root, 'src/lib/passwords.js')).href}');
      const config = (await import('${pathToFileURL(path.join(root, 'src/config/env.js')).href}')).default;
      const result = await seed.seedBootstrapAdmin({ interactiveOutput: true });
      console.log('CHILD_RESULT:' + JSON.stringify({
        created: result.created,
        code: result.code || null,
        reason: result.reason || null,
        password: result.password,
        passwordLength: result.password ? result.password.length : null,
        policyProblems: result.password ? checkPasswordPolicy(result.password, { email: result.email }) : null,
        min: config.auth.passwordMinLength,
        max: config.auth.passwordMaxLength
      }));
    }).catch((e) => { console.error('CHILD_ERROR:' + e.message); process.exit(1); });
  `;
  const scriptPath = path.join(childRoot, 'run.mjs');
  fs.writeFileSync(scriptPath, script);
  const proc = spawnSync(process.execPath, [scriptPath], { env: childEnv, encoding: 'utf8' });
  return { ...proc, childRoot };
}

// --- C. A configured minimum well above the old fixed 16 characters must
//     still produce a valid, compliant bootstrap password - this is exactly
//     the case the original fixed-length generator could never satisfy. ---
{
  const proc = runBootstrapChild('raised-min', { PASSWORD_MIN_LENGTH: '40' });
  assert.equal(proc.status, 0, `expected success, got status ${proc.status}: ${proc.stderr}`);
  const match = proc.stdout.match(/CHILD_RESULT:(.+)/);
  assert.ok(match, `expected a result marker, got: ${proc.stdout}${proc.stderr}`);
  const result = JSON.parse(match[1]);
  assert.ok(result.created, 'sanity: the bootstrap admin must be created');
  assert.ok(result.passwordLength >= 40,
    `ATTACK C: with PASSWORD_MIN_LENGTH=40, the generated bootstrap password must be at least 40 characters (got ${result.passwordLength})`);
  assert.deepEqual(result.policyProblems, [], 'ATTACK C: the generated bootstrap password must pass the full policy at the raised minimum');
  console.log(`PASS (Attack C): seedBootstrapAdmin() honours a configured minimum well above the old fixed 16 characters (generated ${result.passwordLength} chars)`);
}

// --- D. A configured minimum near the fixed policy maximum must still
//     produce a password within BOTH bounds, not merely at-or-above the
//     minimum - proving the wiring respects the maximum too. ---
{
  const proc = runBootstrapChild('near-max', { PASSWORD_MIN_LENGTH: '195' });
  assert.equal(proc.status, 0, `expected success, got status ${proc.status}: ${proc.stderr}`);
  const match = proc.stdout.match(/CHILD_RESULT:(.+)/);
  assert.ok(match, `expected a result marker, got: ${proc.stdout}${proc.stderr}`);
  const result = JSON.parse(match[1]);
  assert.ok(result.created, 'sanity: the bootstrap admin must be created');
  assert.ok(result.passwordLength >= 195 && result.passwordLength <= result.max,
    `ATTACK D: the generated bootstrap password length (${result.passwordLength}) must stay within [195, ${result.max}]`);
  assert.deepEqual(result.policyProblems, [], 'ATTACK D: the generated bootstrap password must pass the full policy this close to the maximum');
  console.log(`PASS (Attack D): seedBootstrapAdmin() stays within the configured minimum and the fixed policy maximum at once (generated ${result.passwordLength} chars)`);
}

// --- E. A self-contradictory policy (minimum above the fixed maximum) must
//     fail the whole bootstrap process clearly and safely, never create an
//     account with a non-compliant credential. ---
{
  const proc = runBootstrapChild('impossible', { PASSWORD_MIN_LENGTH: '250' });
  assert.notEqual(proc.status, 0, 'ATTACK E: a self-contradictory PASSWORD_MIN_LENGTH must fail the bootstrap process, not succeed');
  assert.doesNotMatch(proc.stdout, /CHILD_RESULT:/, 'ATTACK E: no account may have been created under an impossible policy');
  assert.match(proc.stderr, /PASSWORD_MIN_LENGTH.*cannot exceed/,
    'ATTACK E: the failure must name the actual contradiction, not a generic later error');
  const dbPath = path.join(env.root, 'bootstrap-child-impossible', 'fixture.sqlite');
  if (fs.existsSync(dbPath)) {
    const Database = (await import('better-sqlite3')).default;
    const conn = new Database(dbPath, { readonly: true, fileMustExist: true });
    try {
      const hasUsersTable = conn.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
      if (hasUsersTable) {
        assert.equal(conn.prepare('SELECT COUNT(*) AS n FROM users').get().n, 0,
          'ATTACK E: no user may exist after a bootstrap that failed due to an impossible policy');
      }
    } finally {
      conn.close();
    }
  }
  console.log('PASS (Attack E): a self-contradictory password-policy configuration fails the bootstrap process safely, naming the contradiction, with no account created');
}

/**
 * Runs the real scripts/first-run.mjs entry point in its own fresh,
 * throwaway directory, mirroring exactly what a person double-clicking
 * "Setup CCIQ.bat" would trigger. `tty` controls whether the child's own
 * stdout is treated as an interactive terminal by first-run.mjs's own
 * safety check - a real spawned child's stdout is a pipe (not a TTY) by
 * default, which is itself the realistic "non-interactive" case this suite
 * needs to prove refuses safely.
 */
// A preload that makes a child process see an interactive stdout, exactly as
// if a person had double-clicked the .bat file - a test harness technique
// only; there is no such switch in the production code. (A spawned child's
// stdout is a pipe, so it is otherwise never a TTY.)
const ttyPreload = path.join(env.root, 'pretend-tty.mjs');
fs.writeFileSync(ttyPreload, "Object.defineProperty(process.stdout, 'isTTY', { value: true, configurable: true });\n");
const ttyArgs = ['--import', pathToFileURL(ttyPreload).href];

function filesContain(dir, needle) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (filesContain(full, needle)) return full;
    } else if (fs.readFileSync(full).toString('latin1').includes(needle)) {
      return full;
    }
  }
  return null;
}
function countOccurrences(text, needle) {
  return text.split(needle).length - 1;
}

function runFirstRun(label, { bootstrapPassword = null, tty = false, extraEnv = {} } = {}) {
  const freshRoot = path.join(env.root, `first-run-${label}`);
  fs.mkdirSync(freshRoot, { recursive: true });
  const childEnv = {
    ...process.env,
    NODE_ENV: 'production',
    HOST: '127.0.0.1',
    SECURE_COOKIES: 'false',
    DOTENV_CONFIG_PATH: path.join(freshRoot, 'absent.env'),
    DATABASE_FILE: path.join(freshRoot, 'data', 'cciq.sqlite'),
    STORAGE_DIR: path.join(freshRoot, 'storage'),
    BACKUP_DIR: path.join(freshRoot, 'backups'),
    SESSION_SECRET: crypto.randomBytes(32).toString('hex'),
    BOOTSTRAP_ADMIN_EMAIL: 'admin@cciq.local',
    BOOTSTRAP_ADMIN_NAME: 'Church Administrator'
  };
  delete childEnv.PORT;
  if (bootstrapPassword) childEnv.BOOTSTRAP_ADMIN_PASSWORD = bootstrapPassword;
  else delete childEnv.BOOTSTRAP_ADMIN_PASSWORD;
  Object.assign(childEnv, extraEnv);

  const proc = spawnSync(process.execPath, [...(tty ? ttyArgs : []), path.join(root, 'scripts/first-run.mjs')], {
    cwd: freshRoot, env: childEnv, encoding: 'utf8'
  });
  return { ...proc, freshRoot, dbPath: path.join(freshRoot, 'data', 'cciq.sqlite') };
}

function userRows(dbPath) {
  if (!fs.existsSync(dbPath)) return [];
  const conn = new Database(dbPath, { readonly: true, fileMustExist: true });
  try {
    const hasUsers = conn.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
    return hasUsers ? conn.prepare('SELECT id, email, password_hash, must_change_password, security_generation FROM users').all() : [];
  } finally {
    conn.close();
  }
}

function listAllFiles(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listAllFiles(full));
    else out.push(full);
  }
  return out;
}

// --- A (successful case) / G. A real first-run, with BOOTSTRAP_ADMIN_PASSWORD
//     supplied so no generation - and therefore no interactivity - is
//     needed, must create the account and must never write ANY plaintext
//     credential file, alongside the folder's ordinary settings/database
//     files. ---
{
  const manualPassword = 'FirstRunManualBootstrap!2026Long';
  const proc = runFirstRun('manual-password', { bootstrapPassword: manualPassword });
  assert.equal(proc.status, 0, `expected first-run.mjs to succeed, got: ${proc.stdout}\n${proc.stderr}`);
  assert.match(proc.stdout, /Setup finished/);

  const files = listAllFiles(proc.freshRoot).map((f) => path.basename(f).toLowerCase());
  assert.ok(!files.some((f) => f.includes('sign-in') || f.includes('signin') || f.includes('password')),
    `ATTACK A: first-run.mjs must not create any plaintext-credential-shaped file; found: ${files.join(', ')}`);
  assert.doesNotMatch(proc.stdout, new RegExp(manualPassword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')),
    'an operator-supplied BOOTSTRAP_ADMIN_PASSWORD must not be echoed back by first-run.mjs');
  console.log('PASS (Attack A/G, supplied password): a successful first-run creates no plaintext credential file of any kind');
}

// --- A (generated case) / G. A real first-run that WOULD need to generate a
//     new password, run non-interactively (any spawned child's stdout is a
//     pipe, not a TTY - exactly the case this fix must refuse), must fail
//     safely before creating anything: no account, no plaintext file
//     anywhere. ---
{
  const proc = runFirstRun('non-interactive-generated', {});
  assert.notEqual(proc.status, 0, 'ATTACK A: first-run must refuse when it would need to generate a password with no interactive terminal to show it in');
  assert.match(proc.stdout, /terminal|interactive/i, 'the refusal must explain why, in terms an operator can act on');

  const dbPath = path.join(proc.freshRoot, 'data', 'cciq.sqlite');
  if (fs.existsSync(dbPath)) {
    const Database = (await import('better-sqlite3')).default;
    const conn = new Database(dbPath, { readonly: true, fileMustExist: true });
    try {
      const hasUsersTable = conn.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
      if (hasUsersTable) {
        assert.equal(conn.prepare('SELECT COUNT(*) AS n FROM users').get().n, 0,
          'ATTACK A/G: no account may have been created when first-run refused to generate a password unsafely');
      }
    } finally {
      conn.close();
    }
  }

  const files = fs.existsSync(proc.freshRoot) ? listAllFiles(proc.freshRoot).map((f) => path.basename(f).toLowerCase()) : [];
  assert.ok(!files.some((f) => f.includes('sign-in') || f.includes('signin')),
    `ATTACK A: a refused, non-interactive first-run must not create any plaintext credential file; found: ${files.join(', ')}`);
  console.log('PASS (Attack A/G, non-interactive): first-run.mjs refuses to generate and show a password with no safe channel, before creating anything, leaving no plaintext file behind');
}

// ======================================================================
// Pre-go-live batch, items F and G.
// ======================================================================

// --- F1. On an interactive terminal, first-run still works end to end: the
//     generated password is shown exactly ONCE, satisfies the policy, is
//     stored only as a hash, forces a change at first sign-in, and appears in
//     no file anywhere (database, settings, notes). ---
{
  const proc = runFirstRun('interactive-generated', { tty: true });
  assert.equal(proc.status, 0, `first-run on an interactive terminal must succeed: ${proc.stdout}\n${proc.stderr}`);
  const shown = proc.stdout.match(/Password: (\S+)/);
  assert.ok(shown, 'the generated password must be shown to the person at the terminal');
  const password = shown[1];
  assert.equal(countOccurrences(proc.stdout, password), 1, 'the generated password must be printed exactly once');
  assert.ok(password.length >= config.auth.passwordMinLength);
  assert.equal(checkPasswordPolicy(password, { email: 'admin@cciq.local' }).length, 0);
  assert.equal(filesContain(proc.freshRoot, password), null,
    'the plaintext credential must not be present in ANY file the setup produced (database, WAL, settings, notes)');
  const rows = userRows(proc.dbPath);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].must_change_password, 1, 'the forced first-login password change must remain enabled');
  assert.notEqual(rows[0].password_hash, password);
  assert.match(proc.stdout, /Setup finished/);
  console.log('PASS (Item F1): first-run on an interactive terminal shows the generated password once and leaves it in no file');
}

// --- F1. The OTHER executable bootstrap path, `node src/db/seed.js`
//     (npm run db:seed): non-interactive, it must not print a generated
//     password, must not create the account, and must not exit as though it
//     had; interactive, it works the same way first-run does. ---
function runSeedCli(label, { tty = false, extraEnv = {} } = {}) {
  const freshRoot = path.join(env.root, `seed-cli-${label}`);
  fs.mkdirSync(freshRoot, { recursive: true });
  const childEnv = {
    ...process.env,
    NODE_ENV: 'test',
    DOTENV_CONFIG_PATH: path.join(freshRoot, 'absent.env'),
    DATABASE_FILE: path.join(freshRoot, 'cciq.sqlite'),
    STORAGE_DIR: path.join(freshRoot, 'storage'),
    BACKUP_DIR: path.join(freshRoot, 'backups'),
    SESSION_SECRET: crypto.randomBytes(32).toString('hex'),
    BOOTSTRAP_ADMIN_EMAIL: 'seed.cli@fixture.invalid',
    BOOTSTRAP_ADMIN_NAME: 'Seed Cli Admin',
    ...extraEnv
  };
  delete childEnv.PORT;
  if (!('BOOTSTRAP_ADMIN_PASSWORD' in extraEnv)) delete childEnv.BOOTSTRAP_ADMIN_PASSWORD;
  const proc = spawnSync(process.execPath, [...(tty ? ttyArgs : []), path.join(root, 'src/db/seed.js')], {
    cwd: freshRoot, env: childEnv, encoding: 'utf8'
  });
  return { ...proc, freshRoot, dbPath: path.join(freshRoot, 'cciq.sqlite') };
}
{
  const refused = runSeedCli('non-interactive');
  assert.notEqual(refused.status, 0, 'ITEM F1: db:seed must not exit successfully when it could not create the administrator');
  assert.match(refused.stdout, /No administrator created/);
  assert.match(refused.stdout, /terminal/i);
  assert.doesNotMatch(refused.stdout + refused.stderr, /Password:/, 'ITEM F1: a non-interactive db:seed must never print a generated password');
  assert.equal(userRows(refused.dbPath).length, 0, 'ITEM F1: no account may be created without a safe channel');

  const shownOk = runSeedCli('interactive', { tty: true });
  assert.equal(shownOk.status, 0, `${shownOk.stdout}\n${shownOk.stderr}`);
  const match = shownOk.stdout.match(/Password: (\S+)/);
  assert.ok(match, 'an interactive db:seed shows the generated password');
  assert.equal(countOccurrences(shownOk.stdout, match[1]), 1);
  assert.equal(filesContain(shownOk.freshRoot, match[1]), null, 'and it is written nowhere');
  assert.equal(userRows(shownOk.dbPath)[0].must_change_password, 1);
  console.log('PASS (Item F1): db:seed refuses to emit a generated password non-interactively, and behaves like first-run interactively');
}

// --- F2. Generated credentials satisfy the SAME account-aware policy the
//     account is held to; a candidate that violates it is discarded and
//     redrawn, and a policy that cannot be satisfied for this account fails
//     rather than creating a violating credential. ---
{
  const { generateInitialPassword } = await import('../services/users.js');
  for (let i = 0; i < 300; i += 1) {
    const pw = generateInitialPassword({ email: 'ab@fixture.invalid' });
    assert.equal(checkPasswordPolicy(pw, { email: 'ab@fixture.invalid' }).length, 0);
    assert.ok(!pw.toLowerCase().includes('ab'), 'a generated credential must never contain the account\'s email local part');
  }

  // An email with an empty local part makes every candidate violate the
  // account-aware rule, deterministically: generation must fail, and nothing
  // may be created.
  const impossible = runBootstrapChild('impossible-identity', { BOOTSTRAP_ADMIN_EMAIL: '@fixture.invalid' });
  assert.equal(impossible.status, 0, `${impossible.stdout}${impossible.stderr}`);
  const impossibleResult = JSON.parse(impossible.stdout.match(/CHILD_RESULT:(.+)/)[1]);
  assert.equal(impossibleResult.created, false);
  assert.equal(impossibleResult.code, 'password_generation_failed');
  assert.equal(impossibleResult.password, undefined);

  // The supplied-password path gets the same account-aware check (the local
  // part appears in the password) and a plain weak-password check.
  for (const [label, supplied] of [['weak', 'short1'], ['contains-identity', 'bootstrap.fixture-Passw0rd-2026']]) {
    const child = runBootstrapChild(`supplied-${label}`, { BOOTSTRAP_ADMIN_PASSWORD: supplied });
    assert.equal(child.status, 0, `${child.stdout}${child.stderr}`);
    const result = JSON.parse(child.stdout.match(/CHILD_RESULT:(.+)/)[1]);
    assert.equal(result.created, false, `a supplied password that fails the policy (${label}) must not create an account`);
    assert.equal(result.code, 'weak_password');
    assert.ok(!String(result.reason).includes(supplied), 'the refusal reason must never echo the supplied password');
  }
  console.log('PASS (Item F2): generated and supplied bootstrap credentials are held to the full account-aware policy; unsatisfiable policies fail');
}

// --- F3. first-run must not claim success when no administrator was created. ---
{
  const weak = runFirstRun('supplied-weak', { bootstrapPassword: 'short1' });
  assert.notEqual(weak.status, 0, 'ITEM F3: a setup that created no administrator must not exit successfully');
  assert.doesNotMatch(weak.stdout, /Setup finished/, 'ITEM F3: and must not say it finished');
  assert.match(weak.stdout, /too weak/);
  assert.ok(!weak.stdout.includes('short1'), 'ITEM F3: the supplied password must not be echoed');
  assert.equal(userRows(weak.dbPath).length, 0);

  const unsatisfiable = runFirstRun('unsatisfiable', { tty: true, extraEnv: { BOOTSTRAP_ADMIN_EMAIL: '@fixture.invalid' } });
  assert.notEqual(unsatisfiable.status, 0);
  assert.doesNotMatch(unsatisfiable.stdout, /Setup finished/);
  assert.equal(userRows(unsatisfiable.dbPath).length, 0);

  // The normal re-run case is NOT a failure: an account already exists.
  const first = runFirstRun('rerun', { bootstrapPassword: 'FirstRunRerunPassw0rd!2026' });
  assert.equal(first.status, 0, `${first.stdout}\n${first.stderr}`);
  const second = spawnSync(process.execPath, [path.join(root, 'scripts/first-run.mjs')], {
    cwd: first.freshRoot, env: { ...process.env, DOTENV_CONFIG_PATH: path.join(first.freshRoot, 'absent.env'),
      DATABASE_FILE: first.dbPath, STORAGE_DIR: path.join(first.freshRoot, 'storage'), BACKUP_DIR: path.join(first.freshRoot, 'backups'),
      SESSION_SECRET: crypto.randomBytes(32).toString('hex'), NODE_ENV: 'production', BOOTSTRAP_ADMIN_EMAIL: 'admin@cciq.local' },
    encoding: 'utf8'
  });
  assert.equal(second.status, 0, 're-running setup against an existing account is normal and must still succeed');
  assert.match(second.stdout, /Accounts already exist/);
  console.log('PASS (Item F3): first-run propagates a failure to create the administrator, and still treats "already set up" as success');
}

// --- G. The command-line reset (Reset password.bat): policy-compliant,
//     never generated for an unsafe output channel, and it changes nothing
//     when it refuses. ---
{
  const adminEmail = 'bootstrap.fixture@fixture.invalid';
  const before = db.prepare('SELECT password_hash, security_generation FROM users WHERE email = ?').get(adminEmail);

  // Non-interactive: refused BEFORE anything changes.
  const refused = spawnSync(process.execPath, [path.join(root, 'src/db/reset-password.js'), adminEmail], { env: process.env, encoding: 'utf8' });
  assert.notEqual(refused.status, 0, 'ITEM G: a non-interactive reset must refuse');
  assert.match(refused.stdout, /Nothing was changed/);
  assert.doesNotMatch(refused.stdout + refused.stderr, /Password:/, 'ITEM G: no password may be printed to a non-interactive channel');
  const afterRefusal = db.prepare('SELECT password_hash, security_generation FROM users WHERE email = ?').get(adminEmail);
  assert.deepEqual(afterRefusal, before, 'ITEM G: a refused reset must not have changed the account at all');

  // Interactive, with a raised minimum: the generated reset password honours it.
  const shown = spawnSync(process.execPath, [...ttyArgs, path.join(root, 'src/db/reset-password.js'), adminEmail], {
    env: { ...process.env, PASSWORD_MIN_LENGTH: '40' }, encoding: 'utf8'
  });
  assert.equal(shown.status, 0, `${shown.stdout}\n${shown.stderr}`);
  const match = shown.stdout.match(/Password: (\S+)/);
  assert.ok(match, 'an interactive reset shows the new password once');
  const resetPassword = match[1];
  assert.equal(countOccurrences(shown.stdout, resetPassword), 1, 'the reset password is printed exactly once');
  assert.ok(resetPassword.length >= 40,
    `ITEM G: with PASSWORD_MIN_LENGTH=40 the reset password must be at least 40 characters (got ${resetPassword.length})`);
  assert.ok(resetPassword.length <= config.auth.passwordMaxLength);
  assert.equal(checkPasswordPolicy(resetPassword, { email: adminEmail }).length, 0);
  const after = db.prepare('SELECT password_hash, must_change_password, security_generation FROM users WHERE email = ?').get(adminEmail);
  assert.notEqual(after.password_hash, before.password_hash, 'the reset must actually change the credential');
  assert.notEqual(after.password_hash, resetPassword);
  assert.equal(after.must_change_password, 1, 'the reset password must be forced to change at next sign-in');
  assert.equal(after.security_generation, before.security_generation + 1, 'R03: a reset still advances the security generation');
  assert.equal(filesContain(env.root, resetPassword), null, 'the reset password must be written to no file');
  console.log('PASS (Item G): reset-password refuses non-interactively without changing anything, and generates a policy-compliant password interactively');
}

db.close();
env.cleanup();
console.log('ALL PASS');
