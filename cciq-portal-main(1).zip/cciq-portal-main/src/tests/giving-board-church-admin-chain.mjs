import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The Church Admin's whole "claim for a member" journey, step by step, as the route chain the person actually walks (not just "the page has a button"):
 *   1 GET board  2 GET claim form  3 member search  4 POST review (nothing written)  5 GET Back  6 POST confirm  7 GET the page it lands on
 *   8 the claim is on the board and in the working list  9 the date is now taken  10 Cancel/Back leave no claim
 * The same chain is walked for several free dates (first, month boundaries, last) and for the Super Admin (parity), then:
 *   - a date taken BETWEEN review and confirm, and two simultaneous confirmations, end in one claim and a plain message (never an error page);
 *   - odd and repeated parameters are answered, never a server error;
 *   - a member and a Cell Group leader are refused at every step and nothing is written (no permission is widened to make the chain work);
 *   - the Faith Promise "Record for a member" chain: form, member, commitment, validation, save, the commitment page, the list;
 *   - a real phone-sized browser touch-walks the Giving Board chain as the Church Admin.
 * And a server error always leaves a durable reference in the audit log (system.error), so a reference quoted by a person can be traced.
 */

const f = await buildPortalFixture('cciq-gb-church-chain-');
const { db, ids, users, mods } = f;
const one = (sql, ...p) => db.prepare(sql).get(...p);
const all = (sql, ...p) => db.prepare(sql).all(...p);
db.prepare("UPDATE ecaq_campaigns SET status = 'draft' WHERE id = ?").run(ids.board); // the fixture's current-year board steps aside
const board = mods.ecaq.createCampaign({ name: '2025 Thanksgiving Project (Giving Board)', year: 2025, type: 'giving_board', status: 'active', privacy_mode: 'first_name', currency: 'QAR', start_date: '2025-01-01', end_date: '2025-12-31' });
db.prepare('UPDATE ecaq_campaigns SET amount_per_date = 300 WHERE id = ?').run(board.id);
const dates = mods.ecaq.boardDates(2025);
const claims = () => all('SELECT * FROM ecaq_giving_board_claims WHERE campaign_id = ? ORDER BY id', board.id);
const claimOn = (date) => one('SELECT * FROM ecaq_giving_board_claims WHERE campaign_id = ? AND claim_date = ?', board.id, date);
const text = async (c, url) => { const r = await c.get(url); return { status: r.status, body: await r.text(), location: r.headers.get('location') }; };
const mainOf = (body) => ((/<main[\s\S]*?<\/main>/.exec(body) || [body])[0]).replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const superAdmin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const target = ids.member.a2; // Anna MemberA, in Group Alpha
  const errorPage = (res) => res.status >= 500 || /Something went wrong/.test(res.body || '');

  // ---- 1-10. the whole chain, for several free dates, as Church Admin and as Super Admin ----------------------------------------------------------------------------------
  const chainDates = [dates[0], '2025-02-28', '2025-03-18', '2025-06-17', '2025-12-30'].filter((d) => dates.includes(d));
  assert.ok(chainDates.length >= 4, `several free dates are exercised (${chainDates.join(', ')})`);
  const walked = [];
  for (const [who, client] of [['Church Admin', church], ['Super Admin', superAdmin]]) {
    const own = who === 'Church Admin' ? chainDates.filter((_, i) => i % 2 === 0) : chainDates.filter((_, i) => i % 2 === 1);
    for (const date of own) {
      const label = `${who} ${date}`;
      const before = claims().length;
      // 1 the board links the free date to the claim-for-member form (never to taking it for oneself)
      const boardPage = await text(client, '/projects/ecaq/board?year=2025');
      assert.equal(boardPage.status, 200, `${label}: board`);
      assert.ok(boardPage.body.includes(`href="/admin/ecaq/claims/new?date=${date}"`), `${label}: the free slip leads to the claim form`);
      assert.match(boardPage.body, /action="\/admin\/ecaq\/claims\/new"/, `${label}: and the board offers the date field too`);
      // 2 the form
      const form = await text(client, `/admin/ecaq/claims/new?date=${date}`);
      assert.equal(form.status, 200, `${label}: claim form`);
      assert.match(mainOf(form.body), /Notes \(optional\)/); assert.match(form.body, />Review</);
      assert.ok(!/QAR\s*300/.test(mainOf(form.body)), `${label}: no commitment amount on the first step`);
      // 3 member search (the picker's own endpoint)
      const search = await client.get('/members/picker-search?q=Anna');
      const found = await search.json();
      assert.equal(search.status, 200, `${label}: member search`);
      assert.ok(JSON.stringify(found).includes('Anna'), `${label}: the member is found`);
      // 4 review: nothing is written
      const review = await client.post('/admin/ecaq/claims', { date, member_id: target, notes: 'by phone' }, { csrfFrom: `/admin/ecaq/claims/new?date=${date}` });
      const reviewBody = await review.text();
      assert.equal(review.status, 200, `${label}: review`);
      assert.match(reviewBody, /Review the claim/); assert.match(reviewBody, /QAR 300/);
      assert.equal(claims().length, before, `${label}: reviewing writes nothing`);
      // 5 Back keeps the choice
      const back = await text(client, `/admin/ecaq/claims/new?date=${date}&member_id=${target}&notes=by%20phone`);
      assert.equal(back.status, 200, `${label}: back`); assert.match(back.body, /Anna MemberA/); assert.match(back.body, /value="by phone"/);
      // 6 confirm
      const confirm = await client.post('/admin/ecaq/claims', { date, member_id: target, notes: 'by phone', confirm: '1' }, { csrfFrom: `/admin/ecaq/claims/new?date=${date}` });
      await confirm.text();
      assert.equal(confirm.status, 302, `${label}: confirm redirects`);
      const row = claimOn(date);
      assert.ok(row, `${label}: the claim is stored`);
      assert.equal(row.member_id, target); assert.equal(Number(row.commitment_amount), 300, 'server-authoritative QAR 300');
      assert.equal(row.created_by, client === church ? users.churchAdmin.id : users.superAdmin.id, 'the administrator who recorded it is the creator');
      assert.equal(claims().length, before + 1);
      const audit = one("SELECT * FROM audit_logs WHERE action = 'giving.claim_recorded_by_admin' AND CAST(entity_id AS TEXT) = ?", String(row.id));
      assert.ok(audit, `${label}: audited`); assert.equal(JSON.parse(audit.detail).recorded_by, row.created_by);
      // 7 the page it lands on
      assert.equal(confirm.headers.get('location'), `/admin/ecaq/claims/${row.id}`, `${label}: lands on the claim`);
      const landed = await text(client, confirm.headers.get('location'));
      assert.equal(landed.status, 200, `${label}: the landing page renders`); assert.match(landed.body, /Anna/);
      // 8 board and working list
      const after = await text(client, '/projects/ecaq/board?year=2025');
      assert.ok(!after.body.includes(`href="/admin/ecaq/claims/new?date=${date}"`), `${label}: the date is no longer offered`);
      const list = await text(client, `/admin/ecaq?campaign=${board.id}`);
      assert.equal(list.status, 200); assert.match(mainOf(list.body), /Anna/, `${label}: in the working list`);
      // 9 taken: asking again goes to the claim, with no error
      const again = await text(client, `/admin/ecaq/claims/new?date=${date}`);
      assert.equal(again.status, 302, `${label}: a taken date is redirected`); assert.equal(again.location, `/admin/ecaq/claims/${row.id}`);
      walked.push(label);
    }
  }
  // 10 Cancel / Back leave nothing: a review that is never confirmed
  { const date = '2025-09-23'; const before = claims().length;
    const r = await church.post('/admin/ecaq/claims', { date, member_id: target }, { csrfFrom: `/admin/ecaq/claims/new?date=${date}` }); await r.text();
    assert.equal(r.status, 200); assert.equal(claims().length, before, 'review then walk away: nothing was claimed'); assert.equal(claimOn(date), undefined); }
  console.log(`PASS (chain) the Church Admin / Super Admin claim chain, all steps, for ${walked.length} dates: ${walked.join('; ')}`);

  // ---- date taken BETWEEN review and confirm; two simultaneous confirms -----------------------------------------------------------------------------------------------------
  { const date = '2025-04-15'; const before = claims().length;
    const rv = await church.post('/admin/ecaq/claims', { date, member_id: target }, { csrfFrom: `/admin/ecaq/claims/new?date=${date}` }); await rv.text(); assert.equal(rv.status, 200);
    const other = await superAdmin.post('/admin/ecaq/claims', { date, member_id: ids.member.b1, confirm: '1' }, { csrfFrom: `/admin/ecaq/claims/new?date=${date}` }); await other.text(); assert.equal(other.status, 302);
    const late = await church.post('/admin/ecaq/claims', { date, member_id: target, confirm: '1' }, { csrfFrom: '/account/password' }); const lateBody = await late.text();
    assert.equal(late.status, 400, 'taken in between: a plain refusal, not an error page'); assert.match(lateBody, /just taken by someone else/);
    assert.equal(claims().length, before + 1, 'exactly one claim'); assert.equal(claimOn(date).member_id, ids.member.b1, 'and it is the first one'); }
  { const date = '2025-05-20'; const before = claims().length;
    const fire = (client) => client.post('/admin/ecaq/claims', { date, member_id: target, confirm: '1' }, { csrfFrom: '/account/password' }).then(async (r) => { await r.text(); return r.status; });
    const statuses = await Promise.all([fire(church), fire(church), fire(superAdmin)]);
    assert.ok(statuses.every((s) => s < 500), `simultaneous confirms never error (${statuses.join(', ')})`);
    assert.equal(claims().length, before + 1, 'and make exactly one claim'); }
  console.log('PASS (races) a date taken between review and confirm, and simultaneous confirms, end in one claim and a plain message');

  // ---- odd and repeated parameters: answered, never an error ------------------------------------------------------------------------------------------------------------------
  { const odd = [
      ['no date', {}, { member_id: target }], ['junk date', { date: 'nope' }, { member_id: target }], ['date outside the year', { date: '2031-01-01', member_id: target }, {}],
      ['no member', { date: '2025-09-09' }, {}], ['junk member', { date: '2025-09-09', member_id: 'abc' }, {}], ['unknown member', { date: '2025-09-09', member_id: '99999' }, {}],
      ['huge notes', { date: '2025-09-09', member_id: target, notes: 'x'.repeat(20000) }, {}], ['confirm flag only', { confirm: '1' }, {}]
    ];
    for (const [label, fields] of odd) { const res = await church.post('/admin/ecaq/claims', fields, { csrfFrom: '/account/password' }); const body = await res.text(); assert.ok(res.status < 500 && !/Something went wrong/.test(body), `${label} -> ${res.status}`); }
    // repeated and array-style parameters, raw
    const token = await church.csrf('/account/password');
    for (const raw of ['date=2025-09-09&date=2025-09-10&member_id=' + target, `date=2025-09-09&member_id=${target}&member_id=${ids.member.b1}`, `date=2025-09-09&member_id[]=${target}`, `date[]=2025-09-09&member_id=${target}`, `date=2025-09-09&member_id=${target}&notes[]=a&notes[]=b`, `date=2025-09-09&member_id=${target}&confirm=1&confirm=0`]) {
      const res = await fetch(`${portal.base}/admin/ecaq/claims`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: church.cookie }, body: `_csrf=${encodeURIComponent(token)}&${raw}` });
      const body = await res.text(); assert.ok(res.status < 500 && !/Something went wrong/.test(body), `${raw} -> ${res.status}`);
    }
    for (const url of ['/admin/ecaq/claims/new', '/admin/ecaq/claims/new?date=', '/admin/ecaq/claims/new?date=2025-09-09&member_id=abc', '/admin/ecaq/claims/new?date=2025-09-09&member_id=1&member_id=2', '/admin/ecaq/claims/new?date[]=x', '/admin/ecaq/claims/new?date=2025-09-09&notes[]=a', '/admin/ecaq/claims/new?date=2031-01-01', '/admin/ecaq/claims', '/admin/ecaq/claims/999999']) {
      const res = await text(church, url); assert.ok(res.status < 500 && !/Something went wrong/.test(res.body), `${url} -> ${res.status}`);
    } }
  console.log('PASS (odd input) missing, junk, repeated, array-style and oversized parameters, on every step, are answered with a redirect or a plain message, never a server error');

  // ---- RBAC: nobody is let in by this chain who was not already --------------------------------------------------------------------------------------------------------------
  { const before = claims().length;
    for (const [who, client] of [['member', member], ['Cell Group leader', leader]]) {
      for (const url of ['/admin/ecaq/claims/new?date=2025-09-09', '/admin/ecaq', '/admin/ecaq/faith-promise/new']) { const r = await text(client, url); assert.equal(r.status, 403, `${who}: ${url}`); }
      const r = await client.post('/admin/ecaq/claims', { date: '2025-09-09', member_id: target, confirm: '1' }, { csrfFrom: '/account/password' }); await r.text(); assert.equal(r.status, 403, `${who}: POST confirm`);
      const rf = await client.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: target, amount: '10', frequency: 'monthly' }, { csrfFrom: '/account/password' }); await rf.text(); assert.equal(rf.status, 403, `${who}: POST Faith Promise`);
    }
    assert.equal(claims().length, before, 'refused: nothing written'); }
  // the permission the chain needs is exactly the one the Church Admin was given, and it is the one the Super Admin holds
  { const holds = (key) => all('SELECT 1 FROM role_permissions rp JOIN roles r ON r.id = rp.role_id JOIN permissions p ON p.id = rp.permission_id WHERE r.key = ? AND p.key = ?', key.role, key.perm).length > 0;
    for (const perm of ['giving.manage', 'giving.manage_finance', 'giving.view_board']) assert.ok(holds({ role: 'church_admin', perm }), `Church Admin holds ${perm}`);
    for (const perm of ['giving.manage', 'giving.manage_finance']) assert.ok(!holds({ role: 'member', perm }) && !holds({ role: 'cell_group_leader', perm }), `members and leaders do not hold ${perm}`); }
  console.log('PASS (rbac) a member and a Cell Group leader are refused at every step with nothing written; the Church Admin holds the permissions it was always given');

  // ---- the Faith Promise chain -----------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const url = `/admin/ecaq/faith-promise/new?campaign=${ids.promise}`;
    for (const [who, client] of [['Church Admin', church], ['Super Admin', superAdmin]]) {
      const form = await text(client, url); assert.equal(form.status, 200, `${who}: form`); assert.match(form.body, /data-picker-selected/);
      const bad = await client.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: ids.member.a3, amount: 'abc', frequency: 'monthly' }, { csrfFrom: url }); await bad.text(); assert.equal(bad.status, 400, `${who}: a bad amount is a plain 400`);
      const nomember = await client.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, amount: '10', frequency: 'monthly' }, { csrfFrom: url }); await nomember.text(); assert.equal(nomember.status, 400, `${who}: no member`);
      const memberId = who === 'Church Admin' ? ids.member.a3 : ids.member.free;
      const ok = await client.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: memberId, amount: '75', frequency: 'monthly' }, { csrfFrom: url }); await ok.text();
      assert.equal(ok.status, 302, `${who}: saved`);
      const row = one('SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = ? AND member_id = ?', ids.promise, memberId);
      assert.ok(row, `${who}: the commitment exists`); assert.equal(Number(row.commitment_amount), 75);
      assert.equal(ok.headers.get('location'), `/admin/ecaq/faith-promise/commitments/${row.id}`);
      const landed = await text(client, ok.headers.get('location')); assert.equal(landed.status, 200, `${who}: the commitment page`);
      const list = await text(client, `/admin/ecaq/faith-promise?campaign=${ids.promise}`); assert.equal(list.status, 200, `${who}: the list`);
      assert.ok(one("SELECT 1 FROM audit_logs WHERE action = 'ecaq.faith_promise_submitted_for_member' AND CAST(entity_id AS TEXT) = ?", String(row.id)), `${who}: audited`);
    } }
  console.log('PASS (faith promise) Record for a member: form, member, commitment, validation, save, commitment page and list, as Church Admin and Super Admin');

  // ---- a phone-sized browser walks the Giving Board chain as the Church Admin ----------------------------------------------------------------------------------------------------------------
  { const cookies = church.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
    await context.addCookies(cookies);
    const page = await context.newPage(); const problems = [];
    page.on('pageerror', (e) => problems.push(`pageerror ${e.message}`));
    page.on('response', (r) => { if (r.status() >= 500) problems.push(`${r.status()} ${r.url()}`); });
    const date = dates.find((d) => d.startsWith('2025-07') && !claimOn(d)); assert.ok(date);
    await page.goto(`${portal.base}/projects/ecaq/board?year=2025`, { waitUntil: 'load' });
    await page.locator(`a[href="/admin/ecaq/claims/new?date=${date}"]`).scrollIntoViewIfNeeded();
    await Promise.all([page.waitForURL(/\/admin\/ecaq\/claims\/new\?date=/), page.locator(`a[href="/admin/ecaq/claims/new?date=${date}"]`).tap()]);
    await page.fill('[data-picker-input]', 'Anna');
    await page.locator('.member-picker__result', { hasText: 'Anna MemberA' }).tap();
    await page.fill('#notes', 'on a phone');
    await page.getByRole('button', { name: 'Review', exact: true }).tap();
    await page.getByText('Review the claim').first().waitFor();
    assert.equal(new URL(page.url()).pathname, '/admin/ecaq/claims', 'the review is the POST response');
    await Promise.all([page.waitForURL(/\/admin\/ecaq\/claims\/\d+$/), page.getByRole('button', { name: /Confirm claim/ }).tap()]);
    assert.ok(claimOn(date), 'the phone created the claim');
    assert.equal(claimOn(date).member_id, target);
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth), 0, 'no sideways scroll on the landing page');
    await page.goto(`${portal.base}/projects/ecaq/board?year=2025`, { waitUntil: 'load' });
    assert.equal(await page.locator(`a[href="/admin/ecaq/claims/new?date=${date}"]`).count(), 0, 'and the board no longer offers it');
    // the date field on the board (Claim for a member / Continue) as well
    const other = dates.find((d) => d.startsWith('2025-08') && !claimOn(d));
    await page.fill('#admin-pick-date', other);
    await Promise.all([page.waitForURL(/\/admin\/ecaq\/claims\/new\?date=/), page.locator('form.board-pick button[type=submit]').first().tap()]);
    assert.match(await page.textContent('main'), /for a member/);
    assert.deepEqual(problems, [], `no server error or script error on the phone: ${problems.join('; ')}`);
    await context.close(); }
  console.log('PASS (phone) a 390px touch browser walks board -> claim -> member -> review -> confirm -> board as the Church Admin, with no server or script error');

  // ---- a server error leaves a durable reference --------------------------------------------------------------------------------------------------------------------------------------
  { db.exec('ALTER TABLE ecaq_campaigns RENAME COLUMN name TO name_x');
    let ref = null;
    try { const r = await text(church, '/admin/ecaq/campaigns'); assert.ok(r.status >= 500, 'the fault produces an error page'); ref = (r.body.match(/Reference[^0-9a-f]*([0-9a-f]{8})/i) || [])[1]; }
    finally { db.exec('ALTER TABLE ecaq_campaigns RENAME COLUMN name_x TO name'); }
    assert.ok(ref, 'the page shows a reference');
    const logged = one("SELECT * FROM audit_logs WHERE action = 'system.error' AND CAST(entity_id AS TEXT) = ?", ref);
    assert.ok(logged, 'and the same reference is findable in the audit log'); assert.equal(logged.result, 'failure');
    const detail = JSON.parse(logged.detail); assert.equal(detail.path, '/admin/ecaq/campaigns'); assert.equal(detail.status, 500); assert.ok(!/stack|\bat \w/.test(logged.detail), 'no stack in the record'); }
  console.log('PASS (reference) a 500 reference shown to a person is recorded in the audit log (system.error) without stack, query string or database text');
  console.log('PASS giving-board-church-admin-chain');
} finally {
  await browser.close();
  await portal.stop();
}
