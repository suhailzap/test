import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * A setting that is written into a new .env (by scripts/first-run.mjs) or documented in .env.example must be a setting the
 * portal actually reads. A misspelt key is silently ignored, and the default quietly applies instead of the value the
 * administrator thinks they set (this happened once with the session idle timeout). Checks new-install templates only;
 * it never reads or changes a real .env.
 */

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

function sourceFiles(dir) {
  const out = [];
  for (const entry of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
    const rel = path.join(dir, entry.name);
    if (entry.isDirectory()) { if (!['tests', 'public', 'node_modules'].includes(entry.name)) out.push(...sourceFiles(rel)); } else if (/\.(js|mjs)$/.test(entry.name)) out.push(rel);
  }
  return out;
}

const readKeys = new Set();
for (const file of [...sourceFiles('src'), ...sourceFiles('scripts'), ...sourceFiles('tools')]) {
  for (const m of read(file).matchAll(/process\.env\.([A-Z][A-Z0-9_]+)|process\.env\[['"]([A-Z][A-Z0-9_]+)['"]\]/g)) readKeys.add(m[1] || m[2]);
}
assert.ok(readKeys.has('SESSION_IDLE_TIMEOUT_MINUTES') && readKeys.has('SESSION_SECRET'), 'the keys the portal reads were found');

const firstRun = read('scripts/first-run.mjs');
const template = firstRun.slice(firstRun.indexOf('function settingsFile'), firstRun.indexOf('function ensureEnv'));
const writtenKeys = [...template.matchAll(/^\s*[`']([A-Z][A-Z0-9_]+)=/gm)].map((m) => m[1]);
assert.ok(writtenKeys.length >= 8, `the keys first-run writes were found (${writtenKeys.length})`);
assert.deepEqual(writtenKeys.filter((k) => !readKeys.has(k)), [], 'every key first-run writes into a new .env is read by the portal');
assert.ok(writtenKeys.includes('SESSION_IDLE_TIMEOUT_MINUTES'), 'first-run sets the idle timeout under the name the portal reads');
assert.ok(!writtenKeys.includes('SESSION_TIMEOUT_MINUTES'), 'and not under the old, ignored name');

const example = read('.env.example');
const exampleKeys = [...example.matchAll(/^([A-Z][A-Z0-9_]+)=/gm)].map((m) => m[1]);
assert.deepEqual(exampleKeys.filter((k) => !readKeys.has(k)), [], 'every key documented in .env.example is read by the portal');
assert.deepEqual(writtenKeys.filter((k) => !exampleKeys.includes(k)), [], 'and first-run writes only documented keys');

const idle = /SESSION_IDLE_TIMEOUT_MINUTES=(\d+)/.exec(template)[1];
assert.equal(Number(idle), 60, 'a new install keeps the intended 60-minute idle timeout');

console.log(`PASS (settings) ${writtenKeys.length} keys written by first-run and ${exampleKeys.length} in .env.example are all read by the portal; the idle timeout uses the key the portal reads`);
console.log('ALL PASS');
