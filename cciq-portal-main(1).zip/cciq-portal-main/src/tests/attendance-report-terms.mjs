import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Attendance report wording: the columns say what they count, the same way in the PDF, on the screen and in the CSV, and the figures behind them are the unchanged attendance
 * calculations. A small, hand-checkable world:
 *   W(-6) before Attendance tracking began (never counted)      W(-5), W(-4), W(-1) finalized (the three services counted)
 *   W(-3) cancelled and W(-2) "Attendance not taken" (neither counted nor an absence)       W(0), later, a past service that is NOT finalized (Pending: not counted, not an absence)
 *   Alice present at all three            -> counted 3, present 3, absent 0, 100%, absences in a row 0
 *   Bob   present, absent, absent         -> counted 3, present 1, absent 2, 33%, 2 in a row
 *   Cara  Vacation, present, absent       -> counted 3, vacation 1, present 1, absent 1, 1 / (3 - 1) = 50%, 1 in a row
 *   Dan   no record at all (derived absence) at the three -> counted 3, absent 3, 0%, 3 in a row; and a "present" before tracking began changes nothing
 */

const f = await buildPortalFixture('cciq-attendance-terms-');
const { db, ids, users, mods } = f;
const lifecycle = await import('../services/attendance-lifecycle.js');
const consumers = await import('../services/attendance-consumers.js');
const pdfs = await import('../services/reports-pdf.js');
const { today, addDays, lastFridayOnOrBefore } = mods.dates;
const SERVICE = lastFridayOnOrBefore(today()); const W = (n) => addDays(SERVICE, 7 * n);
const atNoon = (d) => `${d}T09:00:00.000Z`; const OLD = addDays(SERVICE, -400);
for (const m of db.prepare('SELECT id, status FROM members').all()) { // long-standing members, so finalizing past Fridays is never ambiguous
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id); db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, m.status, 'planted', atNoon(OLD));
}
db.exec('DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions;');
mods.setSetting('attendance.tracking_start_date', W(-5)); mods.setSetting('attendance.excused_counts', false);
const session = new Map();
for (const n of [-6, -5, -4, -3, -2, -1, 0]) {
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
  session.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)).id);
}
const mark = (n, memberId, status) => mods.attendance.recordAttendance(session.get(n), [{ memberId, status }], { userId: users.churchAdmin.id });
const M = ids.member; const alice = M.a2; const bob = M.a3; const cara = M.b1; const dan = M.free;
mark(-6, dan, 'present'); // before tracking began: ignored
mark(-5, alice, 'present'); mark(-4, alice, 'present'); mark(-1, alice, 'present');
mark(-5, bob, 'present'); mark(-4, bob, 'absent'); mark(-1, bob, 'absent');
mark(-5, cara, 'excused'); mark(-4, cara, 'present'); mark(-1, cara, 'absent');
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(session.get(-3));
for (const n of [-5, -4, -1]) { const r = lifecycle.finalizeAttendance(session.get(n), { userId: null, confirmNoAttendance: true }); assert.equal(r.ok, true, `finalize W(${n}): ${r.reason}`); }
assert.equal(lifecycle.markAttendanceNotTaken(session.get(-2), { userId: null, note: 'Power cut' }).ok, true);

const range = { from: W(-6), to: W(0) };
const row = (report, id) => report.rows.find((r) => r.member.id === id);
const EXPECTED = {
  [alice]: { counted: 3, present: 3, vacation: 0, absent: 0, rate: 100, run: 0 }, [bob]: { counted: 3, present: 1, vacation: 0, absent: 2, rate: 33, run: 2 },
  [cara]: { counted: 3, present: 1, vacation: 1, absent: 1, rate: 50, run: 1 }, [dan]: { counted: 3, present: 0, vacation: 0, absent: 3, rate: 0, run: 3 }
};
const check = (report, label) => { for (const [id, e] of Object.entries(EXPECTED)) { const r = row(report, Number(id)); assert.ok(r, `${label}: member ${id} listed`);
  assert.deepEqual([r.eligible, r.present + r.visitor, r.excused, r.absent, r.rate, r.consecutive.streak].map(Number), [e.counted, e.present, e.vacation, e.absent, e.rate, e.run], `${label}: member ${id}`); } };
const pdfText = async (doc) => { const chunks = []; doc.on('data', (c) => chunks.push(c)); await new Promise((r) => doc.on('end', r)); const raw = Buffer.concat(chunks).toString('latin1'); let text = '';
  for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) { let c; try { c = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; } for (const h of c.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(h[1], 'hex').toString('latin1'); for (const l of c.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += l[1]; text += '\n'; } return text; };

// ---- 1. the calculations behind the words (unchanged) ----------------------------------------------------------------------------------------------------------------------------------------
{ const report = consumers.attendanceReport(range); check(report, 'the report');
  assert.equal(report.lifecycle.finalized, 3, 'three services counted: not the one before tracking, the cancelled one, the not-taken one or the unfinalized one');
  for (const id of [alice, bob, cara, dan]) assert.equal(row(report, id).not_recorded, 1, 'the one past service that is not finalized is Pending'); }
console.log('PASS (calculations) 3 services counted (pre-tracking, cancelled and not-taken excluded); present, vacation, absent, Attendance % = present / (counted - vacation), and the current absence run, for four hand-checked members');

// ---- 2. the CSV, the PDF and the screen use the same words and the same figures ---------------------------------------------------------------------------------------------------------------
const csv = consumers.attendanceReportCsv(range).csv; const csvLines = csv.split('\r\n'); const header = csvLines[0].split(',').map((h) => h.replace(/"/g, ''));
{ for (const word of ['Services counted', 'Attendance %', 'Absences in a row', 'Pending (not yet finalized)']) assert.ok(header.includes(word), `CSV column "${word}"`);
  assert.ok(!header.some((h) => /Finalized Friday Services expected|Attendance rate|Consecutive Friday Services without/.test(h)), 'the old, longer headings are gone');
  const at = (name) => header.indexOf(name);
  for (const [id, e] of Object.entries(EXPECTED)) { const code = db.prepare('SELECT member_code FROM members WHERE id = ?').get(Number(id)).member_code; const cells = csvLines.find((l) => l.includes(`"${code}"`) || l.startsWith(code)).split(',').map((c) => c.replace(/"/g, ''));
    assert.deepEqual([cells[at('Services counted')], cells[at('Present')], cells[at('Vacation')], cells[at('Absent')], cells[at('Attendance %')], cells[at('Absences in a row')]].map(Number), [e.counted, e.present, e.vacation, e.absent, e.rate, e.run], `CSV row for member ${id}`); } }
const pdf = await pdfText(pdfs.attendancePdf(range));
{ for (const word of ['Services counted', 'Attendance %', 'Absences in a row', 'Overall attendance %']) assert.ok(pdf.toLowerCase().includes(word.toLowerCase()), `PDF says "${word}"`);
  assert.ok(!/\bIn a row\b|\bFinalized\b(?! and counted)(?!\s+Friday)/.test(pdf.replace(/finalized and counted/g, '')), 'the old column names are gone from the PDF');
  assert.match(pdf, /Services counted: the finalized Friday Services in these dates that the member was expected at/, 'the legend explains Services counted');
  assert.match(pdf, /cancelled services and "Attendance not taken" are never counted/); assert.match(pdf, /Attendance % = Present divided by \(Services counted minus Vacation\)/, 'and the formula');
  assert.match(pdf, /Pending: expected at a service that is not finalized yet - not counted, and not absent/);
  assert.match(pdf, /a Vacation counts as missed in the run/, 'the Vacation rule that is actually in force is stated'); }
const portal = await startPortal();
try {
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const screen = await (await church.get(`/attendance/reports?from=${range.from}&to=${range.to}&statuses_submitted=1&status=active&page_size=100`)).text();
  const flat = screen.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&rsquo;/g, "'").replace(/\s+/g, ' ');
  for (const word of ['Services counted', 'Attendance %', 'Absences in a row']) assert.ok(screen.includes(`>${word}<`) || screen.includes(`${word}</a>`), `the screen column "${word}"`);
  assert.ok(!/Current absence streak|>Finalized services</.test(screen), 'the old column names are gone from the screen');
  assert.match(flat, /Services counted: the finalized Friday Services in the range that the member was expected at/); assert.match(flat, /Attendance % = Present divided by \(Services counted minus Vacation\)/); assert.match(flat, /Absences in a row: the member's current run of finalized services missed one after another/);
  for (const [id, e] of Object.entries(EXPECTED)) { const name = mods.members.getMember(Number(id)); const rowHtml = screen.split('<tr>').find((chunk) => chunk.includes(`/members/${id}/attendance`)); assert.ok(rowHtml, `the screen lists member ${id}`);
    const cells = [...rowHtml.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)].map((m) => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()); void name;
    assert.deepEqual([cells[2], cells[3], cells[4], cells[5], cells[7].replace('%', ''), cells[8]].map(Number), [e.counted, e.present, e.vacation, e.absent, e.rate, e.run], `the screen row for member ${id} (${cells.join(' | ')})`); }
  console.log('PASS (same words, same figures) the PDF, the screen and the CSV all say Services counted / Attendance % / Absences in a row, explain them once, and show identical figures for the four members');

  // ---- 3. a past service that is not finalized is Pending: not counted, not an absence --------------------------------------------------------------------------------------------------
  { const report = consumers.attendanceReport(range);
    for (const id of [alice, bob, cara, dan]) { const r = row(report, id); assert.equal(r.not_recorded, 1, `member ${id}: the unfinalized W(0) shows as Pending`); }
    // counted / present / absent / % are exactly as before
    for (const [id, e] of Object.entries(EXPECTED)) { const r = row(report, Number(id)); assert.deepEqual([r.eligible, r.present + r.visitor, r.excused, r.absent, r.rate].map(Number), [e.counted, e.present, e.vacation, e.absent, e.rate], `member ${id}: an unfinalized service changes no counted figure`); }
    const text = await pdfText(pdfs.attendancePdf(range)); assert.match(text, /Pending/); }
  console.log('PASS (pending) a past, unfinalized Friday is Pending: it is not counted and is never turned into an absence');

  // ---- 4. the cell group report ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const text = await pdfText(pdfs.cellGroupsPdf({ groupIds: [ids.groupA, ids.groupB] }));
    for (const word of ['Friday attendance', 'Absences in a row', 'Group meetings']) assert.ok(text.includes(word), `the cell group report says "${word}"`);
    assert.ok(!/\bIn a row\b/.test(text), 'no "In a row"');
    assert.match(text, /Friday attendance: present\/counted \(percentage\)/, 'the legend explains the figure'); assert.match(text, /Vacation taken out of the count/); assert.match(text, /never count as an absence/, 'and that group meetings are separate');
    assert.ok(text.includes('3/3 (100%)'), 'Alice 3 of 3'); assert.ok(text.includes('1/3 (33%)'), 'Bob 1 of 3'); assert.ok(text.includes('1/2 (50%)'), 'Cara 1 of (3 - 1 Vacation)'); }
  console.log('PASS (cell group report) Friday attendance as present/counted (percentage) with Vacation taken out, Absences in a row, Group meetings kept separate, and a short legend');

  // ---- 5. the other attendance outputs --------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const overview = await (await church.get('/reports/attendance/export.csv')).text(); assert.ok(overview.length > 0);
    const csvResp = await church.get(`/reports/attendance/export.csv?from=${range.from}&to=${range.to}`); const body = await csvResp.text(); assert.ok(/Attendance %/.test(body.split('\n')[0]), 'the overview CSV says Attendance %'); assert.ok(!/Rate %/.test(body.split('\n')[0]));
    for (const url of ['/attendance/friday', '/attendance/history', '/attendance/reports', `/cell-groups/${ids.groupA}?tab=attendance`]) { const r = await church.get(url); const html = await r.text(); assert.equal(r.status, 200, url); assert.ok(!/<th scope="col">Rate<\/th>/.test(html), `${url}: no bare "Rate" column`); } }
  console.log('PASS (other outputs) the attendance overview CSV, the Friday list, history and the cell group tab no longer use a bare "Rate"');
  console.log('PASS attendance-report-terms');
} finally {
  await portal.stop();
}
