import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Express First Timer Registration: the CURRENT safe boundary, nothing more. No owner decision is made here (required fields, duplicate
 * override); this pins what the code does today so a later change is deliberate:
 *   - the narrow permission, and nothing wider;  - the server alone chooses the service;  - a cancelled, finalized, not-taken or missing
 *   service refuses it and creates nothing;  - a possible duplicate stops a Kiosk;  - registration and visit are one unit;
 *   - a double tap, a refresh and the Back button cannot make a second person.
 */

const f = await buildPortalFixture('cciq-express-safety-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const visitorsNow = () => count('SELECT COUNT(*) n FROM visitors');
const register = (who, fields, from = '/kiosk') => who.post('/attendance/checkin/first-timer', { kiosk: '1', ...fields }, { csrfFrom: from });

try {
  // ---- 1. who may use it -----------------------------------------------------------------------------------------------------------------
  for (const [label, who, expected] of [['Kiosk', kiosk, 200], ['Church Admin', admin, 200], ['Cell Group Leader', leader, 403], ['plain Member', member, 403]]) {
    const res = await who.get('/attendance/checkin/first-timer');
    assert.equal(res.status, expected, `${label} GET -> ${expected}`); await res.text();
  }
  const perms = (u) => new Set(db.prepare(`SELECT DISTINCT p.key FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id JOIN permissions p ON p.id = rp.permission_id WHERE ur.user_id = ?`).all(u.id).map((r) => r.key));
  const kioskPerms = perms(users.kiosk);
  for (const wider of ['members.create', 'members.edit', 'members.view', 'attendance.record', 'attendance.view', 'reports.view', 'admin.users']) assert.equal(kioskPerms.has(wider), false, `the Kiosk does not hold ${wider}`);
  assert.equal(kioskPerms.has('visitors.express_register'), true);
  for (const url of ['/members/new', '/visitors/new', '/visitors', '/visitors/reviews', `/visitors/${ids.visitor}`, `/visitors/${ids.visitor}/convert`]) {
    const res = await kiosk.get(url); assert.equal(res.status, 302); assert.equal(res.headers.get('location'), '/kiosk', `Kiosk cannot open ${url}`); await res.text();
  }
  for (const [url, body] of [['/members', { first_name: 'Hack', last_name: 'Er' }], ['/visitors', { first_name: 'Hack', first_visit_date: ids.friday }], [`/members/${ids.member.a2}`, { first_name: 'Changed' }]]) {
    const before = JSON.stringify(db.prepare('SELECT id, first_name FROM members ORDER BY id').all()) + visitorsNow();
    const res = await kiosk.post(url, body, { csrfFrom: '/kiosk' }); assert.equal(res.status, 302); assert.equal(res.headers.get('location'), '/kiosk'); await res.text();
    assert.equal(JSON.stringify(db.prepare('SELECT id, first_name FROM members ORDER BY id').all()) + visitorsNow(), before, `Kiosk POST ${url} changed nothing`);
  }
  assert.equal((await register(leader, { first_name: 'Nope' }, '/visitors/new')).status, 403);
  assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Nope'"), 0, 'a Leader or plain Member cannot register through it');
  console.log('PASS (1) only the Kiosk and Church Admin can use it; the Kiosk holds no wider permission and cannot add or edit members or administer First Timers');

  // ---- 2. a double tap, a refresh and the Back button -------------------------------------------------------------------------------------
  {
    const fields = { first_name: 'Dora', last_name: 'Doubletap', phone: '+974 5577 1001', kiosk: '1' };
    const token = await kiosk.csrf('/kiosk');
    const tap = () => fetch(`${portal.base}/attendance/checkin/first-timer`, { method: 'POST', redirect: 'manual', headers: { Cookie: kiosk.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: token, ...fields }) });
    const [a, b, c] = await Promise.all([tap(), tap(), tap()]);
    assert.deepEqual([a.status, b.status, c.status].sort(), [302, 302, 302], 'every tap is answered with the same redirect (no error page)');
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Dora'"), 1, 'three simultaneous taps make one First Timer');
    assert.equal(count("SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = (SELECT id FROM visitors WHERE first_name = 'Dora')"), 1, 'with one visit');
    // a later identical post (a refresh of the form submission minutes later) is a possible duplicate and creates nothing
    const again = await kiosk.post('/attendance/checkin/first-timer', fields, { csrfFrom: '/kiosk' });
    assert.ok([409, 302].includes(again.status)); await again.text();
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Dora'"), 1, 'a later repeat of the same details never makes a second person');
    // the success response is a redirect, so refreshing the page the browser lands on is a GET and repeats nothing; Back shows a fresh empty form
    assert.equal(a.headers.get('location'), '/attendance/checkin/first-timer/done');
    const form = await (await kiosk.get('/attendance/checkin/first-timer')).text();
    assert.doesNotMatch(form, /Dora|Doubletap|5577/, 'the form shown again (Back button) holds nothing from the last registration');
    for (const _ of [1, 2, 3]) await (await kiosk.get('/kiosk')).text();
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Dora'"), 1, 'refreshing the kiosk page repeats nothing');
    console.log('PASS (2) simultaneous taps, a later repeat, a refresh and the Back button each leave exactly one First Timer and one visit');
  }

  // ---- 3. a possible duplicate stops a Kiosk (current behaviour; the override is an owner decision) ----------------------------------------------
  {
    const before = visitorsNow();
    for (const fields of [{ first_name: 'Dora', last_name: 'Doubletap' }, { first_name: 'Someone', last_name: 'New', phone: '974 5577 1001' }, { first_name: 'Anna', last_name: 'MemberA' }, { first_name: 'Other', phone: '+974 5550 0002' }, { first_name: 'Dora', last_name: 'Doubletap', duplicate_override: '1', confirm: '1' }]) {
      const res = await register(kiosk, fields); const text = await res.text();
      assert.equal(res.status, 409, `a possible duplicate stops the Kiosk (${JSON.stringify(fields)})`);
      assert.doesNotMatch(text, /Anna MemberA|Dora Doubletap|href="\/(members|visitors)\/\d+/, 'and names nobody');
    }
    assert.equal(visitorsNow(), before);
    console.log('PASS (3) same name or same number (First Timer or member) stops a Kiosk with a message that names no one; a forged override is ignored');
  }

  // ---- 4. registration and visit are one unit ---------------------------------------------------------------------------------------------------
  {
    db.exec("CREATE TRIGGER fx_visit BEFORE INSERT ON visitor_visits WHEN NEW.visit_date = (SELECT service_date FROM attendance_sessions WHERE id = NEW.session_id) AND (SELECT first_name FROM visitors WHERE id = NEW.visitor_id) = 'Atomic' BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
    const before = { visitors: visitorsNow(), visits: count('SELECT COUNT(*) n FROM visitor_visits'), audits: count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.express_registered'") };
    const res = await register(kiosk, { first_name: 'Atomic' }); const text = await res.text();
    db.exec('DROP TRIGGER fx_visit');
    assert.ok(res.status >= 500, `a failure writing the visit is reported (${res.status})`);
    assert.doesNotMatch(text, /injected failure|SqliteError|\bat \w+ \(|node_modules/, 'with no internals');
    assert.deepEqual({ visitors: visitorsNow(), visits: count('SELECT COUNT(*) n FROM visitor_visits'), audits: count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'visitor.express_registered'") }, before, 'no First Timer, no visit and no audit row: it is one unit');
    assert.equal((await register(kiosk, { first_name: 'Atomic' })).status, 302, 'and the retry works');
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Atomic'"), 1);
    console.log('PASS (4) a failure while writing the visit leaves no First Timer, no visit and no audit row, and the retry registers them once');
  }

  // ---- 5. the service must be open for check-in ---------------------------------------------------------------------------------------------------
  {
    const before = visitorsNow();
    const snapshot = () => ({ visitors: visitorsNow(), visits: count('SELECT COUNT(*) n FROM visitor_visits') });
    const start = snapshot();
    // finalized
    db.prepare("UPDATE attendance_sessions SET finalization_state = 'finalized', finalized_at = '2026-01-01T00:00:00Z' WHERE id = ?").run(ids.session);
    let res = await kiosk.get('/attendance/checkin/first-timer'); assert.equal(res.status, 302, 'the form is not offered when the service is finalized'); await res.text();
    res = await register(kiosk, { first_name: 'Latecomer' }); assert.equal(res.status, 302); await res.text();
    assert.match(await (await kiosk.get('/kiosk')).text(), /Check-in is closed/, 'and the kiosk says why');
    // not taken
    db.prepare("UPDATE attendance_sessions SET finalization_state = 'not_taken' WHERE id = ?").run(ids.session);
    res = await register(kiosk, { first_name: 'Latecomer' }); assert.equal(res.status, 302); await res.text();
    // cancelled
    db.prepare("UPDATE attendance_sessions SET finalization_state = NULL, finalized_at = NULL, status = 'cancelled' WHERE id = ?").run(ids.session);
    res = await kiosk.get('/attendance/checkin/first-timer'); assert.equal(res.status, 302, 'a cancelled service offers no registration'); await res.text();
    res = await register(kiosk, { first_name: 'Latecomer' }); assert.equal(res.status, 302); await res.text();
    assert.deepEqual(snapshot(), start, 'finalized, not taken and cancelled services each create nothing');
    // no service at all
    db.prepare("UPDATE attendance_sessions SET status = 'held' WHERE id = ?").run(ids.session);
    db.prepare('DELETE FROM attendance_sessions WHERE id = ?').run(ids.session);
    res = await register(kiosk, { first_name: 'Latecomer' }); assert.equal(res.status, 302); await res.text();
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Latecomer'"), 0);
    assert.match(await (await kiosk.get('/kiosk')).text(), /no Friday Service scheduled/i);
    void before;
    console.log('PASS (5) a finalized, not-taken, cancelled or missing service refuses registration, offers no form and creates nothing');
  }
  console.log('ALL PASS');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
