import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Membership Review, the "Isaiah" pattern: a First Timer with seven recorded Friday visits (with gaps) who is NOT on the review list.
 * Root cause on the owner's DEV: Attendance tracking had no start date, so the rule (3 of the last 4 ELIGIBLE FINALIZED Fridays) evaluated nothing.
 * That is by design, so these tests pin the rule exactly as it is and prove the screens now SAY why nobody is listed.
 *
 * Pattern (W(n) = the Friday n weeks from the latest Friday Service; his visits: W(-12) W(-11) W(-10) W(-7) W(-4) W(-2) W(-1) = seven):
 *   A  no tracking start date -> nothing evaluated however many visits; page and profile say why; the manual actions are untouched
 *   B  tracking started, only three finalized Fridays -> explained, nobody listed
 *   C  all of W(-10)..W(-1) finalized -> window W(-1) W(-2) W(-3) W(-4), visits on three of them (not W(-3)) -> listed, with evidence naming the dates;
 *      the two visits BEFORE tracking started create nothing
 *   D  the newest two Fridays unfinalized -> ignored (window W(-3)..W(-6)), one visit only -> not listed
 *   E  an unfinalized Friday INSIDE the window blocks (explained) and finalizing it lists him
 *   F  a cancelled and an Attendance Not Taken Friday are skipped: they neither count nor take a place, and the arithmetic is shown on the profile
 *   G  every tab, Continue as Visitor staying historical and suppressing, Convert / Link, and nobody ever becomes a member by themselves
 */

const f = await buildPortalFixture('cciq-review-explained-');
const { db, users, mods } = f;
const { today, addDays, lastFridayOnOrBefore } = mods.dates;
const review = await import('../services/membership-review.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const one = (sql, ...p) => db.prepare(sql).get(...p);
const atNoon = (d) => `${d}T09:00:00.000Z`;

const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -400);
const sessions = new Map();
const range = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => from + i);
const ISAIAH_VISITS = [-12, -11, -10, -7, -4, -2, -1];

/** A clean world: twelve held Friday Services W(-12)..W(-1), one visitor with the visit pattern, tracking start as given. */
function world({ start = W(-10), visits = ISAIAH_VISITS } = {}) {
  db.exec('DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors; DELETE FROM notifications; DELETE FROM reminders;');
  // the fixture's members were created today; plant them as long-standing members so finalizing past Fridays is never ambiguous about them
  for (const m of db.prepare('SELECT id, status FROM members').all()) {
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, m.status, 'planted', atNoon(OLD));
  }
  mods.setSetting('attendance.tracking_start_date', start || '');
  sessions.clear();
  for (const n of range(-12, -1)) {
    db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
    sessions.set(n, one("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'", W(n)));
  }
  return addVisitor('Isaiah', visits);
}
function addVisitor(name, visits) {
  const v = mods.visitors.createVisitor({ first_name: name, last_name: 'Thomas', first_visit_date: OLD, phone: null }, { userId: null });
  for (const n of visits) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(v.id, W(n), sessions.get(n).id, atNoon(W(n)));
  return v.id;
}
const fin = (...ns) => { for (const n of ns) { const r = lifecycle.finalizeAttendance(sessions.get(n).id, { userId: null, confirmNoAttendance: true }); assert.equal(r.ok, true, `finalize W(${n}): ${r.reason}`); } };
const reviewsOf = (vid) => db.prepare('SELECT * FROM visitor_membership_reviews WHERE visitor_id = ? ORDER BY id').all(vid);
const openCount = () => one("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'").n;
const dateList = (ns) => ns.map(W);

// The portal process caches settings, so it is (re)started after each scenario's world is built
let portal = null; let church = null; let csrf = null;
const serve = async () => {
  if (portal) await portal.stop();
  portal = await startPortal();
  church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  csrf = await church.csrf('/account/password');
};
try {
  const page = async (url) => { const r = await church.get(url); const body = await r.text(); return { status: r.status, body, main: (/<main[\s\S]*?<\/main>/.exec(body) || [body])[0].replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ') }; };

  // ---- A. no tracking start ------------------------------------------------------------------------------------------------------------------------------------------------
  let isaiah = world({ start: null });
  // exactly the owner's DEV: Friday Services exist and he has visited, but tracking never started, so nothing can be finalized or evaluated
  assert.equal(lifecycle.finalizeAttendance(sessions.get(-1).id, { userId: null, confirmNoAttendance: true }).reason, 'tracking_not_started', 'and a Friday cannot even be finalized yet');
  assert.equal(review.evaluateMembershipReviews().status, 'tracking_not_started', 'no tracking start: the rule evaluates nothing');
  assert.equal(review.reviewEvaluation().status, 'tracking_not_started');
  assert.equal(openCount(), 0, 'seven recorded visits do not list him');
  await serve();
  let p = await page('/visitors/reviews');
  assert.equal(p.status, 200);
  assert.match(p.main, /Membership review is not running yet/, 'the page says why it is empty');
  assert.match(p.main, /no tracking start date has been set/);
  assert.match(p.main, /however many times they have visited/);
  assert.match(p.main, /No review can appear until the note above is resolved/, 'and the empty state no longer promises "after 3 of 4"');
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /Membership review:\s*not running yet, because no Attendance tracking start date has been set/, 'the profile says so too');
  assert.match(p.main, /Make them a member/); assert.match(p.main, /Link to an existing member/, 'the manual actions are untouched');
  assert.equal(one('SELECT member_id FROM visitors WHERE id = ?', isaiah).member_id, null, 'and nobody became a member');
  console.log('PASS (A) no tracking start date: nothing is evaluated, and the review page and the profile both explain it');

  // ---- B. fewer than four finalized Fridays ---------------------------------------------------------------------------------------------------------------------------------
  isaiah = world();
  fin(-10, -9, -8);
  assert.equal(review.reviewEvaluation().status, 'insufficient'); assert.equal(review.reviewEvaluation().fridays.length, 3);
  assert.equal(openCount(), 0);
  await serve();
  p = await page('/visitors/reviews');
  assert.match(p.main, /Not enough finalized Friday Services yet/); assert.match(p.main, /3 so far/); assert.match(p.main, /Cancelled and Attendance Not Taken Fridays are skipped/);
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /waiting for 4 finalized Friday Services \(3 so far\)/);
  console.log('PASS (B) three finalized Fridays are not four: explained, nobody listed');

  // ---- C. the Isaiah window --------------------------------------------------------------------------------------------------------------------------------------------------
  fin(-7, -6, -5, -4, -3, -2, -1); // finalizing lists him the moment the fourth eligible Friday and the third visit exist
  const ev = review.reviewEvaluation();
  assert.equal(ev.status, 'ready');
  assert.deepEqual(ev.fridays.map((x) => x.date), dateList([-1, -2, -3, -4]), 'the window is the four NEWEST eligible finalized Fridays');
  const rows = reviewsOf(isaiah);
  assert.equal(rows.length, 1, 'three of the last four -> one review');
  assert.equal(rows[0].status, 'open'); assert.equal(rows[0].trigger_service_date, W(-1));
  const evidence = JSON.parse(rows[0].window_json);
  assert.deepEqual(evidence.fridays.map((x) => [x.service_date, x.visited]), [[W(-1), true], [W(-2), true], [W(-3), false], [W(-4), true]], 'the evidence names each Friday and whether he visited');
  assert.equal(evidence.visits, 3);
  assert.equal(openCount(), 1);
  assert.equal(one('SELECT member_id FROM visitors WHERE id = ?', isaiah).member_id, null, 'listing him never makes him a member');
  await serve();
  p = await page('/visitors/reviews');
  assert.match(p.main, /Isaiah Thomas/); assert.match(p.main, /3 of 4/);
  assert.match(p.main, /Checked against the last 4 finalized Friday Services/);
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /Membership Review suggested/, 'his profile carries the suggestion');
  assert.ok(!/Membership review:/.test(p.main), 'and not the standing line (the suggestion replaces it)');
  console.log('PASS (C) the Isaiah pattern: 3 of the last 4 eligible finalized Fridays lists him with dated evidence; pre-tracking visits create nothing');

  // ---- D. unfinalized NEWEST Fridays are ignored ----------------------------------------------------------------------------------------------------------------------------
  isaiah = world(); fin(...range(-10, -3));
  const d = review.reviewEvaluation();
  assert.equal(d.status, 'ready'); assert.deepEqual(d.fridays.map((x) => x.date), dateList([-3, -4, -5, -6]), 'W(-2) and W(-1) are not finalized: ignored, not counted against anyone');
  assert.equal(openCount(), 0, 'one visit in that window is not a review');
  await serve();
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /1 of the last 4 finalized Friday Services/); assert.match(p.main, /3 are needed/);
  console.log('PASS (D) an unfinalized newest Friday is ignored: it neither creates nor erases anything');

  // ---- E. an unfinalized Friday INSIDE the window blocks ---------------------------------------------------------------------------------------------------------------------
  isaiah = world(); fin(...range(-10, -4), -2, -1); // W(-3) left unfinalized between finalized ones
  const e = review.reviewEvaluation();
  assert.equal(e.status, 'blocked'); assert.equal(e.barrierDate, W(-3));
  assert.equal(openCount(), 0, 'blocked: nothing is decided until it is settled');
  await serve();
  p = await page('/visitors/reviews');
  assert.match(p.main, /Waiting for/); assert.match(p.main, /suggestions are paused until it is finalized, cancelled or marked Attendance Not Taken/);
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /paused until .* is finalized/);
  fin(-3);
  assert.equal(openCount(), 1, 'finalizing it lists him (3 of W(-1) W(-2) W(-3) W(-4))');
  console.log('PASS (E) an unfinalized Friday inside the window pauses the review, with the date, until it is settled');

  // ---- F. cancelled and Not Taken Fridays are skipped ---------------------------------------------------------------------------------------------------------------------------
  isaiah = world(); fin(...range(-10, -4), -1);
  db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(sessions.get(-3).id);
  const nt = lifecycle.markAttendanceNotTaken(sessions.get(-2).id, { userId: null, note: 'Power cut' }); assert.equal(nt.ok, true);
  review.evaluateMembershipReviews();
  const g = review.reviewEvaluation();
  assert.deepEqual(g.fridays.map((x) => x.date), dateList([-1, -4, -5, -6]), 'the cancelled and Not Taken Fridays neither count nor take a place');
  assert.equal(openCount(), 0, 'his visits on them (W(-2)) are not evidence: 2 of 4 is below the threshold');
  await serve();
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /2 of the last 4 finalized Friday Services/);
  assert.match(p.main, /✓/); assert.match(p.main, /–/, 'the profile shows which Fridays he visited');
  console.log('PASS (F) cancelled and Attendance Not Taken Fridays are skipped; below the threshold is shown as arithmetic, not listed');

  // ---- G. every tab; Continue as Visitor stays historical; Convert and Link --------------------------------------------------------------------------------------------------------
  isaiah = world(); fin(...range(-10, -1));
  const second = addVisitor('Second', [-1, -2, -3]); const third = addVisitor('Third', [-1, -2, -4]); const fourth = addVisitor('Fourth', [-2, -3, -4]);
  review.evaluateMembershipReviews();
  assert.equal(openCount(), 4);
  await serve();
  let tab = await page('/visitors/reviews');
  for (const name of ['Isaiah', 'Second', 'Third', 'Fourth']) assert.match(tab.main, new RegExp(`${name} Thomas`), `${name} is on the Open tab`);
  for (const label of ['Open', 'Continuing as visitor', 'Became a member', 'Linked to a member', 'All']) assert.match(tab.body, new RegExp(`>${label}<`), `the ${label} tab exists`);

  const continuedId = reviewsOf(isaiah)[0].id;
  const cont = await church.post(`/visitors/reviews/${continuedId}/continue`, { confirm: '1' }, { csrf });
  assert.ok([302, 303].includes(cont.status), `continue as visitor -> ${cont.status}`);
  assert.equal(reviewsOf(isaiah)[0].status, 'continued');
  const memberId = one("SELECT id FROM members WHERE first_name = 'Anna'").id;
  assert.equal(mods.visitors.linkVisitorToMember(second, memberId, { userId: users.churchAdmin.id }).ok !== false, true);
  const converted = mods.visitors.convertToMember(third, { userId: users.churchAdmin.id, values: mods.visitors.defaultMemberValuesFor(mods.visitors.getVisitor(third)) });
  assert.ok(converted && converted.ok !== false, 'convert');

  const statuses = {};
  for (const s of ['open', 'continued', 'converted', 'linked', 'all']) {
    const t = await page(`/visitors/reviews${s === 'open' ? '' : `?status=${s}`}`);
    assert.equal(t.status, 200, `${s} tab renders`);
    statuses[s] = ['Isaiah', 'Second', 'Third', 'Fourth'].filter((n) => new RegExp(`${n} Thomas`).test(t.main));
  }
  assert.deepEqual(statuses.open, ['Fourth'], 'Open: only the one still undecided');
  assert.deepEqual(statuses.continued, ['Isaiah'], 'Continuing as visitor: kept as history, not erased');
  assert.deepEqual(statuses.linked, ['Second']); assert.deepEqual(statuses.converted, ['Third']);
  assert.deepEqual(statuses.all, ['Isaiah', 'Second', 'Third', 'Fourth'], 'All shows every outcome');
  assert.equal(reviewsOf(isaiah).length, 1, 'the continued review is the one audit record; nothing re-opened it');
  assert.ok(one("SELECT 1 FROM audit_logs WHERE action = 'visitor.membership_review_continued' AND CAST(entity_id AS TEXT) = ?", String(isaiah)), 'and it is audited');
  const standing = review.visitorStanding(isaiah);
  assert.ok(standing.suppressedUntilAfter, 'a continued visitor is suppressed by the rule, not by deleting the history');
  p = await page(`/visitors/${isaiah}`);
  assert.match(p.main, /continuing as visitor, so a new suggestion waits for newer Fridays/);
  assert.equal(one('SELECT member_id FROM visitors WHERE id = ?', isaiah).member_id, null, 'continuing as visitor makes nobody a member');
  assert.equal(one('SELECT member_id FROM visitors WHERE id = ?', fourth).member_id, null, 'and the undecided one was never made a member by the evaluator');
  console.log('PASS (G) all five tabs render the right people; Continue as Visitor is historical and suppresses; the evaluator never makes anyone a member');
  console.log('PASS membership-review-explained');
} finally {
  if (portal) await portal.stop();
}
