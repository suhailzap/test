import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What the portal writes to its log (standard output and error: the service log) and to its audit trail must never carry a secret or personal
 * data that does not have to be there.
 *   1. static: no console call in the shipped code prints a request body, query string, header, cookie, password, token, phone number or e-mail
 *      address (the two one-time command-line tools that DISPLAY a generated password to a person watching are listed on purpose);
 *   2. dynamic: the portal is run with its output captured while a person signs in (rightly and wrongly), changes a password, searches by name and
 *      by mobile number, creates a member and a First Timer with distinctive values, hits a forged and a failing request, and the capture is
 *      searched for every one of those values, for session cookie values and for CSRF tokens;
 *   3. the audit trail records what happened without storing passwords, hashes, tokens or the typed phone numbers.
 */

const src = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? (e.name === 'tests' ? [] : walk(path.join(dir, e.name))) : [path.join(dir, e.name)]));

// ---- 1. static ------------------------------------------------------------------------------------------------------------------------------
{
  const intentional = new Set(['db/reset-password.js', 'db/seed.js']); // show a generated password ONCE to a person at the console, never to a file
  const offenders = [];
  const files = [...walk(src), ...walk(path.join(src, '..', 'scripts')), ...walk(path.join(src, '..', 'deploy'))].filter((f) => /\.(js|mjs)$/.test(f));
  for (const file of files) {
    const rel = path.relative(src, file).split(path.sep).join('/');
    if (intentional.has(rel)) continue;
    const lines = fs.readFileSync(file, 'utf8').split('\n');
    lines.forEach((line, i) => {
      if (!/console\.(log|error|warn|info)\(/.test(line)) return;
      if (/req\.(body|query|headers|cookies|params)|\brequest\b|session\.(id|cookie)|csrf|_csrf|password[A-Za-z]*\s*[,)}]|\bphone\b|\bemail\b|set-cookie|authorization/i.test(line.replace(/'[^']*'|"[^"]*"|`[^`]*`/g, (s) => (/\$\{/.test(s) ? s : '""')))) offenders.push(`${rel}:${i + 1}: ${line.trim().slice(0, 110)}`);
    });
  }
  assert.deepEqual(offenders, [], 'no console call prints a request body, query, header, cookie, password, token, phone or e-mail');
  console.log('PASS (static) no logging call in the shipped code prints request data, credentials, tokens or contact details');
}

// ---- 2. dynamic -----------------------------------------------------------------------------------------------------------------------------
const f = await buildPortalFixture('cciq-log-hygiene-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const captured = [];
portal.server.stdout?.on('data', (d) => captured.push(String(d)));
portal.server.stderr?.on('data', (d) => captured.push(String(d)));
const MARK = {
  newPassword: 'Marker-Pass-ZX81-qwerty!', wrongPassword: 'Wr0ng-Marker-Pass-ZX82!', phone: '+974 5533 4455', phoneDigits: '97455334455', email: 'logmarker.person@fixture.invalid',
  name: 'Lograbbit', note: 'LOGMARKER-NOTE-9'
};
try {
  const session = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const sessionCookieValues = session.cookie.split('; ').map((c) => c.split('=').slice(1).join('=')).filter((v) => v.length > 12);
  const csrfToken = await session.csrf('/account/password');
  // sign in wrongly, and with the right account but a wrong password
  await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ email: users.churchAdmin.email, password: MARK.wrongPassword, _csrf: 'x' }) }).then((r) => r.text());
  // change the password
  await (await session.post('/account/password', { current_password: f.PASSWORD, password: MARK.newPassword, confirm_password: MARK.newPassword }, { csrfFrom: '/account/password' })).text();
  // searches, creates, forged and failing requests
  await (await session.post('/members', { first_name: MARK.name, last_name: 'Person', email: MARK.email, phone: MARK.phone, notes: MARK.note, status: 'pending', duplicate_override: '1' }, { csrfFrom: '/members/new' })).text();
  await (await session.post('/visitors', { first_name: MARK.name, last_name: 'Visitor', phone: '+974 5544 6677', notes: MARK.note, first_visit_date: ids.friday, duplicate_override: '1' }, { csrfFrom: '/visitors/new' })).text();
  await (await session.get(`/members?q=${encodeURIComponent(MARK.email)}`)).text();
  await (await session.get(`/visitors?q=${encodeURIComponent(MARK.phone)}`)).text();
  await (await session.get(`/search?q=${encodeURIComponent(MARK.phone)}`)).text();
  await (await session.post('/attendance/checkin/search', { q: MARK.phone }, { csrfFrom: '/attendance/checkin' })).text();
  await (await session.post('/members', { first_name: 'x', csrf: 'forged' }, { csrf: 'forged-token-value-123456' })).text();
  db.exec("CREATE TRIGGER fx_log BEFORE INSERT ON audit_logs WHEN NEW.action = 'member.created' BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
  await (await session.post('/members', { first_name: 'Failing', last_name: MARK.name, email: MARK.email, phone: MARK.phone, notes: MARK.note, status: 'pending', duplicate_override: '1' }, { csrfFrom: '/members/new' })).text();
  db.exec('DROP TRIGGER fx_log');
  await (await session.get(`/documents/${ids.document}/file?x=${MARK.note}`)).arrayBuffer();
  await new Promise((resolve) => setTimeout(resolve, 300));
  const log = captured.join('');
  assert.ok(log.includes('[error '), 'the injected failure was logged (so this capture really would show a leak)');
  const secrets = { 'new password': MARK.newPassword, 'wrong password': MARK.wrongPassword, 'old password': f.PASSWORD, phone: MARK.phone, 'phone digits': MARK.phoneDigits, 'phone (second)': '5544 6677', email: MARK.email, name: MARK.name, note: MARK.note, 'forged token': 'forged-token-value-123456', 'csrf token': csrfToken };
  for (const [what, value] of Object.entries(secrets)) assert.ok(!log.includes(value), `the service log never contains the ${what}`);
  for (const value of sessionCookieValues) assert.ok(!log.includes(value), 'nor a session cookie value');
  assert.doesNotMatch(log, /password_hash|\$2[aby]\$|argon2|scrypt/i, 'nor a password hash');
  assert.doesNotMatch(log, /\?q=|\?search=|[?&]x=LOGMARKER/, 'nor any query string (what someone typed into a search box)');
  assert.match(log, /\[error [0-9a-f]{8}\] \{\s*path: '\/members'/, 'an error is logged with its path and a reference, which is what lets it be traced');
  console.log(`PASS (dynamic) after sign-ins, a password change, searches by name and by mobile number, creates, a forged token and a failing write, the service log (${log.length} characters) holds none of the typed values, passwords, hashes, session cookies, CSRF tokens or query strings`);

  // ---- 3. the audit trail ----------------------------------------------------------------------------------------------------------------------
  const audit = db.prepare('SELECT action, detail, user_agent, ip_address FROM audit_logs').all().map((r) => `${r.action} ${r.detail || ''}`).join('\n');
  for (const [what, value] of Object.entries({ 'new password': MARK.newPassword, 'old password': f.PASSWORD, 'wrong password': MARK.wrongPassword, 'phone digits': MARK.phoneDigits, 'csrf token': csrfToken })) assert.ok(!audit.includes(value), `the audit trail never contains the ${what}`);
  assert.doesNotMatch(audit, /password_hash|\$2[aby]\$|argon2|scrypt|password":"/i, 'nor a hash or a password field');
  assert.ok(!audit.includes('5544 6677') && !audit.includes(MARK.phone), 'nor a typed phone number');
  assert.match(audit, /auth\.login/, 'but it does record that people signed in');
  console.log('PASS (audit) the audit trail records what happened (sign-ins, creates) and holds no password, hash, token or typed phone number');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
