import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Things that go wrong on a real machine, simulated on a disposable portal:
 *   1. the database is locked by another process for several seconds (a backup tool, an antivirus scan, a second copy of the program): requests
 *      answer with a plain page (no stack trace, no file path, no SQL), nothing half-written appears, and the portal works again the moment the lock goes;
 *   2. the storage folder cannot be written (a file sits where a folder should be): an upload is refused cleanly with no record, the rest of the portal
 *      is unaffected, and the same upload works once the folder is back;
 *   3. a member photo file has disappeared while the record still points at it: the member page and the photo address do not crash;
 *   4. cookies that are damaged, forged, absurdly large or sent twice are treated as "not signed in", never as an error.
 */

const f = await buildPortalFixture('cciq-ops-fail-');
const { db, ids, users, mods } = f;
const env = (await import('../config/env.js')).default;
const captured = [];
const portal = await startPortal();
portal.server.stdout?.on('data', (d) => captured.push(String(d)));
portal.server.stderr?.on('data', (d) => captured.push(String(d)));
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const leaks = (text) => /SQLITE_|SqliteError|at\s+\S+\s+\(.*:\d+:\d+\)|node_modules|[A-Z]:\\|database is locked|\bSELECT\b|\bINSERT\b/.test(text);

try {
  // ---- 1. a locked database --------------------------------------------------------------------------------------------------------------------
  const lockCsrf = await admin.csrf('/announcements/new');
  const holder = spawn(process.execPath, ['--input-type=module', '-e', `
    import Database from ${JSON.stringify(new URL('../../node_modules/better-sqlite3/lib/index.js', import.meta.url).href)};
    const db = new Database(${JSON.stringify(env.databaseFile)});
    db.pragma('busy_timeout = 0');
    db.exec('BEGIN IMMEDIATE');
    console.log('locked');
    // The lock is held until the test says so (a line on stdin) or the test goes away (stdin closes): no timer, no fixed wait.
    let released = false;
    const release = () => { if (released) return; released = true; db.exec('ROLLBACK'); db.close(); console.log('released'); process.exit(0); };
    process.stdin.once('data', release); process.stdin.once('end', release); process.stdin.resume();
  `], { stdio: ['pipe', 'pipe', 'pipe'] });
  const holderExit = new Promise((resolve) => holder.on('exit', resolve));
  await new Promise((resolve, reject) => {
    holder.stdout.on('data', (d) => { if (String(d).includes('locked')) resolve(); });
    holder.stderr.on('data', (d) => reject(new Error(String(d))));
    holder.on('exit', () => resolve());
  });
  const announcementsBefore = count('SELECT COUNT(*) n FROM announcements');
  const readStart = Date.now();
  const readDuring = await admin.get('/members');
  const readText = await readDuring.text();
  const readWaited = Date.now() - readStart;
  assert.ok(readDuring.status === 200 || readDuring.status >= 400, `a page read during a lock answers (status ${readDuring.status}, ${readWaited} ms)`);
  assert.ok(!leaks(readText), 'and shows no internals');
  const started = Date.now();
  const during = await admin.post('/announcements', { title: 'Written while locked', body: 'x', audience: 'all', status: 'published' }, { csrf: lockCsrf });
  const duringText = await during.text();
  const waited = Date.now() - started;
  assert.ok(during.status === 302 || during.status >= 400, `the write during a lock answers (status ${during.status})`);
  assert.ok(!leaks(duringText), 'and the page shows no stack trace, path, SQL or driver error');
  assert.ok(waited < 20000, `and answers within seconds, not minutes (${waited} ms)`);
  const health = await fetch(`${portal.base}/healthz`).then((r) => r.status);
  assert.ok([200, 503].includes(health), `/healthz answers during a lock (${health})`);
  holder.stdin.write('release\n');
  await holderExit;
  const appeared = count('SELECT COUNT(*) n FROM announcements') - announcementsBefore;
  assert.ok(appeared === 0 || (during.status === 302 && appeared === 1), `the write either happened once or not at all (${appeared})`);
  // after the lock: normal service
  const after = await admin.get('/members');
  const afterText = await after.text();
  assert.equal(after.status, 200, 'after the lock the portal serves pages again');
  assert.ok(!leaks(afterText));
  const retry = await admin.post('/announcements', { title: 'Written after lock', body: 'x', audience: 'all', status: 'published' }, { csrfFrom: '/announcements/new' });
  await retry.text();
  assert.equal(retry.status, 302, 'and accepts the same write');
  assert.equal(count("SELECT COUNT(*) n FROM announcements WHERE title = 'Written after lock'"), 1);
  const log = captured.join('');
  assert.ok(!/Written while locked|Written after lock/.test(log), 'the service log does not repeat what was typed');
  console.log(`PASS (locked database) a lock held by another process for the whole of the read and the write: a page read answered in ${readWaited} ms (${readDuring.status}), the write in ${waited} ms (status ${during.status}, ${appeared} row), no internals shown, health ${health}, and service resumed at once`);

  // ---- 2. the storage folder cannot be written ---------------------------------------------------------------------------------------------------
  mods.documents.ensureCategories();
  const category = mods.documents.listCategories()[0].id;
  const docsDir = path.join(env.storageDir, 'documents');
  fs.rmSync(docsDir, { recursive: true, force: true });
  fs.mkdirSync(env.storageDir, { recursive: true });
  fs.writeFileSync(docsDir, 'a file where the folder should be');
  const token = await admin.csrf('/');
  const upload = (title) => admin.upload('/documents', { name: 'scan.png', type: 'image/png', buffer: PNG }, { field: 'file', fields: { title, category_id: String(category) }, csrf: token });
  const docsBefore = count('SELECT COUNT(*) n FROM documents');
  const auditBefore = count("SELECT COUNT(*) n FROM audit_logs WHERE action <> 'system.error'");
  const blocked = await upload('Cannot store this');
  const blockedText = await blocked.text();
  assert.ok(blocked.status < 500 || !leaks(blockedText), `an upload with unwritable storage is answered (${blocked.status})`);
  assert.ok(!leaks(blockedText), 'without internals');
  assert.equal(count('SELECT COUNT(*) n FROM documents'), docsBefore, 'no document record without its file');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action <> 'system.error'"), auditBefore, 'and no audit row for something that did not happen');
  const other = await admin.get('/members');
  await other.text();
  assert.equal(other.status, 200, 'the rest of the portal is unaffected');
  fs.rmSync(docsDir, { force: true });
  const ok = await upload('Stored once the folder is back');
  await ok.text();
  assert.equal(ok.status, 302, 'the same upload works when the folder is back');
  assert.equal(count('SELECT COUNT(*) n FROM documents'), docsBefore + 1);
  console.log(`PASS (unwritable storage) an upload with a file where the folder should be answered ${blocked.status} with no record and no audit row; other pages worked; the upload succeeded once the folder returned`);

  // ---- 3. a photo file that has vanished ----------------------------------------------------------------------------------------------------------
  mods.members.setMemberPhoto(ids.member.a2, `members/${ids.member.a2}/does-not-exist.png`, { userId: users.superAdmin.id });
  const page = await admin.get(`/members/${ids.member.a2}`);
  const pageText = await page.text();
  assert.equal(page.status, 200, 'a member whose photo file is gone still opens');
  assert.ok(!leaks(pageText));
  const srcs = [...pageText.matchAll(/(?:src|href)="([^"]*photo[^"]*)"/g)].map((m) => m[1]).filter((s) => !s.startsWith('http'));
  for (const src of srcs) {
    const r = await admin.get(src.replace(/&amp;/g, '&'));
    const body = await r.arrayBuffer();
    assert.ok(r.status < 500, `${src} answers (${r.status}) rather than failing`);
    assert.ok(!leaks(Buffer.from(body).toString('latin1').slice(0, 4000)));
  }
  for (const url of ['/members', '/members/birthdays', '/search?q=Anna']) {
    const r = await admin.get(url);
    await r.text();
    assert.equal(r.status, 200, `${url} still works with a missing photo file`);
  }
  console.log(`PASS (missing photo) a record pointing at a vanished photo file: the member page, ${srcs.length} photo address(es) and the list screens all answer without an error`);

  // ---- 4. damaged cookies ----------------------------------------------------------------------------------------------------------------------------
  const goodCookie = admin.cookie;
  const name = goodCookie.split('=')[0];
  const value = goodCookie.slice(name.length + 1).split(';')[0];
  const bad = {
    garbage: `${name}=not-a-real-session`,
    truncated: `${name}=${value.slice(0, Math.floor(value.length / 2))}`,
    forgedSignature: `${name}=${value.replace(/.$/, (c) => (c === 'a' ? 'b' : 'a'))}`,
    unsignedSid: `${name}=s%3A${'x'.repeat(32)}`,
    huge: `${name}=${'A'.repeat(7000)}`,
    twice: `${goodCookie}; ${name}=garbage`,
    nul: `${name}=%00%00`,
    badEncoding: `${name}=%E0%A4%A`,
    empty: `${name}=`
  };
  for (const [label, cookie] of Object.entries(bad)) {
    const r = await fetch(`${portal.base}/members`, { headers: { Cookie: cookie }, redirect: 'manual' });
    const text = await r.text();
    assert.ok(r.status < 500, `${label}: ${r.status}`);
    assert.ok(!leaks(text), `${label}: no internals`);
    if (label !== 'twice') assert.ok(r.status === 302 && /\/login/.test(r.headers.get('location') || ''), `${label}: treated as signed out (${r.status} ${r.headers.get('location')})`);
  }
  const huge = await fetch(`${portal.base}/login`, { headers: { Cookie: `${name}=${'A'.repeat(70000)}` } }).then((r) => r.status).catch(() => 'closed');
  assert.ok(huge === 431 || huge === 400 || huge === 'closed' || huge < 500, `an enormous cookie is refused or ignored (${huge})`);
  const still = await admin.get('/members');
  await still.text();
  assert.equal(still.status, 200, 'the genuine session still works after all of that');
  console.log(`PASS (cookies) ${Object.keys(bad).length} damaged, forged, oversized or doubled cookies are all "not signed in" (or ignored, when a good one comes first); a 70 KB cookie gets ${huge}; the real session is unaffected`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
