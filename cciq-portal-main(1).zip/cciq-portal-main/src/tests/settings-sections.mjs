import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * System settings UX: named sections (About Our Church, Branding, Friday Service, Attendance, Security &
 * Sessions, Backup & Recovery, plus "Other settings"), each its own form that saves ONLY its own
 * settings. No new semantics: validation, the Go-Live lock and the Super Admin override are covered by
 * their own suites; this proves the reorganisation cannot change another section's values.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-settings-sections-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, getSetting, setSetting, clearSettingsCache } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { ensureFridaySessions } = await import('../services/friday-service.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `St${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'set_admin', email: 'set.admin@fixture.invalid', password: PASSWORD, displayName: 'Settings Admin', roleKeys: ['church_admin'], mustChangePassword: false });
await createUser({ username: 'set_super', email: 'set.super@fixture.invalid', password: PASSWORD, displayName: 'Settings Super', roleKeys: ['super_admin'], mustChangePassword: false });
await createUser({ username: 'set_member', email: 'set.member@fixture.invalid', password: PASSWORD, displayName: 'Plain Member', roleKeys: ['member'], mustChangePassword: false });
setSetting('service.friday.enabled', true);
setSetting('service.friday.weeks_ahead', 8);
setSetting('service.friday.location', 'Main Hall');
setSetting('service.friday.time', '18:30');
ensureFridaySessions({ userId: null });
setSetting('church.public_about', true);
setSetting('attendance.excused_counts', true);
const upcoming = db.prepare("SELECT service_date FROM attendance_sessions WHERE service_type = 'friday_service' AND service_date >= date('now') ORDER BY service_date").all();

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function session(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const cookie = await session('set.admin@fixture.invalid');
  const memberCookie = await session('set.member@fixture.invalid');
  const superCookie = await session('set.super@fixture.invalid');
  const page = async (section = '', c = cookie) => {
    const res = await fetch(`${base}/admin/settings${section ? `?section=${section}` : ''}`, { headers: { Cookie: c } });
    assert.equal(res.status, 200, section);
    return res.text();
  };
  const post = async (fields, c = cookie) => {
    const source = await page(fields.section && ['about', 'friday_service', 'attendance', 'other'].includes(fields.section) ? fields.section : 'about', c);
    const csrf = source.match(/name="_csrf" value="([^"]+)"/)[1];
    const result = await fetch(`${base}/admin/settings`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: c },
      body: new URLSearchParams({ _csrf: csrf, ...fields })
    });
    clearSettingsCache(); // the server process wrote the database; this process must not read its own stale cache
    return result;
  };

  // Access: unchanged.
  assert.equal((await fetch(`${base}/admin/settings`, { headers: { Cookie: memberCookie } })).status, 403, 'a plain member still cannot open System settings');

  // The section navigation.
  let html = await page();
  for (const label of ['About Our Church', 'Branding', 'Friday Service', 'Attendance', 'Security &amp; Sessions', 'Backup &amp; Recovery', 'Other settings']) {
    assert.ok(html.includes(`>${label}</a>`), `tab "${label}"`);
  }
  assert.match(html, /aria-current="page">About Our Church/, 'the default section is About Our Church');
  assert.match(html, /name="section" value="about"/);
  assert.match(html, /church__display_name/, 'church information lives here');
  assert.doesNotMatch(html, /service__friday__weeks_ahead/, 'and Friday Service settings do not clutter it');
  assert.match(await page('nonsense'), /aria-current="page">About Our Church/, 'an unknown section falls back to the default');
  console.log('PASS (navigation) the sections are tabs; About Our Church is the default; an unknown section is harmless; non-admins still refused');

  // Friday Service: lands directly, clear wording, the real next services.
  html = await page('friday_service');
  assert.match(html, /aria-current="page">Friday Service/);
  assert.match(html, /How far ahead to create Friday Services \(weeks\)/, 'the setting is described as a horizon');
  assert.match(html, new RegExp(`Showing the next 5 of ${upcoming.length} scheduled services`), 'the preview says it is a preview, and of how many');
  const firstListed = html.match(/class="list__name">([^<]+)<\/span>/)[1];
  assert.equal(firstListed.includes(String(new Date(`${upcoming[0].service_date}T00:00:00Z`).getUTCFullYear())), true, 'and it starts with the soonest service, not a far-future one');
  assert.match(html, /\/attendance\/friday\?upcoming=all/);
  assert.ok(html.includes('href="/admin/settings?section=friday_service"'), 'the Friday Service shortcut in the Administration menu lands directly in that section');

  // Branding: previews and no internal paths.
  html = await page('branding');
  assert.equal((html.match(/class="logo-preview"/g) || []).length, 2, 'both logos are previewed');
  assert.match(html, /Sign-in page and printed reports/);
  assert.match(html, /Header, sidebar, browser tab and kiosk/);
  assert.doesNotMatch(html, /branding__logo/, 'no logo file-path inputs');
  assert.doesNotMatch(html, /Logo file path|Small logo file path/);
  assert.doesNotMatch(html, /<input[^>]*value="\/branding\//, 'no internal file path is shown as a value');

  // Attendance: critical setting set apart; retired one hidden.
  html = await page('attendance');
  assert.match(html, /Handle with care/);
  assert.match(html, /data-tracking-start/, 'the Attendance Tracking Start Date sits in the Attendance section, with its readiness summary');
  assert.match(html, /Attendance Tracking Start Date/);
  assert.doesNotMatch(html, /name="attendance__tracking_start_date"/, 'it is changed on its own Super Admin page, not by a form field');
  assert.doesNotMatch(html, /not_recorded_counts/);
  // Security and backup panels point at the screens that own the work.
  html = await page('security', superCookie);
  assert.match(html, /href="\/admin\/users"/, 'a Super Admin is pointed at Users, Roles and the Audit log');
  assert.match(html, /href="\/admin\/roles"/);
  html = await page('security');
  assert.match(html, /href="\/account\/password"/, 'everyone is pointed at their own password');
  assert.equal(html.includes('href="/admin/roles"'), html.includes('Roles and permissions'), 'links follow permissions');
  assert.doesNotMatch(html, /<form method="post" action="\/admin\/settings"/, 'an information panel has nothing to save');
  html = await page('backup');
  assert.match(html, /href="\/admin\/backups"/);
  html = await page('other');
  assert.match(html, /congregation__child_max_age/, 'settings without a named section are still reachable');
  assert.match(html, /members__code_prefix/);
  console.log('PASS (sections) Friday Service lands directly with honest wording and real next services; Branding previews without paths; Attendance separates the critical setting; Security and Backup point at their screens; nothing is lost in Other');

  // Saving one section can never change another's settings.
  assert.equal(getSetting('church.public_about'), true);
  assert.equal(getSetting('service.friday.enabled'), true);
  await post({ section: 'attendance', attendance__followup_threshold: '4', church__display_name: 'Injected Name', church__public_about: '' });
  assert.equal(getSetting('attendance.followup_threshold'), 4, 'the Attendance section saved');
  assert.equal(getSetting('church.public_about'), true, "saving Attendance did not turn off another section's checkbox");
  assert.equal(getSetting('service.friday.enabled'), true);
  assert.notEqual(getSetting('church.display_name'), 'Injected Name', "a field from another section is ignored");
  assert.equal(getSetting('attendance.excused_counts'), false, "this section's own unticked checkbox does mean off");
  setSetting('attendance.excused_counts', true);
  let res = await post({ section: 'friday_service', service__friday__time: '19:15', service__friday__enabled: 'on', service__friday__weeks_ahead: '8' });
  assert.equal(res.headers.get('location'), '/admin/settings?section=friday_service', 'saving returns to the same section');
  assert.equal(getSetting('service.friday.time'), '19:15');
  assert.equal(getSetting('attendance.followup_threshold'), 4, 'and left Attendance alone');
  res = await post({ section: 'friday_service', service__friday__time: '25:99', service__friday__enabled: 'on' });
  assert.equal(res.headers.get('location'), '/admin/settings?section=friday_service');
  assert.equal(getSetting('service.friday.time'), '19:15', 'validation still refuses a bad time');
  // Without a section only the fields actually sent are read - nothing is turned off by omission.
  await post({ attendance__followup_threshold: '5' });
  assert.equal(getSetting('attendance.followup_threshold'), 5);
  assert.equal(getSetting('church.public_about'), true);
  assert.equal(getSetting('attendance.excused_counts'), true, 'a sectionless post does not switch checkboxes off');
  console.log('PASS (saving) each section saves only its own settings; other sections\' checkboxes and fields are untouched; validation and redirects are per section');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
