import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * UX only - no attendance semantics: the Attendance landing shows BOUNDED previews (top 5 people,
 * 6 cell groups, "See all"), and the full Follow-up and Long Absence pages page, search, filter and
 * sort on the server with query state preserved. The Phase 2C lifecycle wording (awaiting
 * finalization, incomplete follow-up) is asserted where a preview would otherwise hide it.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-landing-ux-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createGroup } = await import('../services/cell-groups.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
await import('../services/reminders.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const atNoon = (d) => `${d}T09:00:00.000Z`;
const PASSWORD = `La${crypto.randomBytes(12).toString('base64url')}9!`;
setSetting('attendance.tracking_start_date', W(-10));
setSetting('attendance.recent_engagement_days', 56);
await createUser({ username: 'landing_admin', email: 'landing.admin@fixture.invalid', password: PASSWORD, displayName: 'Landing Admin', roleKeys: ['church_admin'], mustChangePassword: false });

const groups = Array.from({ length: 8 }, (_, i) => createGroup({ name: `Landing Group ${i + 1}` }));
const members = [];
for (let i = 1; i <= 34; i += 1) {
  const m = createMember({ first_name: `Absent${String(i).padStart(2, '0')}`, last_name: 'Landing', cell_group_id: groups[i % groups.length].id }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(atNoon(addDays(SERVICE, -300)), m.id);
  db.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, 'active', 'planted', ?)").run(m.id, atNoon(addDays(SERVICE, -300)));
  members.push(m);
}
const old = members[0]; // attended once, long ago: away from the weekly list, on the Long Absence list
const sessions = new Map();
for (let n = -10; n <= 0; n += 1) {
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
  sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
}
db.prepare("INSERT INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, 'present', ?, 'manual')").run(sessions.get(-9).id, old.id, atNoon(W(-9)));
for (let n = -10; n <= -1; n += 1) {
  const result = lifecycle.finalizeAttendance(sessions.get(n).id, { userId: null, confirmNoAttendance: true });
  assert.equal(result.ok, true, `finalize ${n}: ${result.reason}`);
}
const flaggedCount = 33; // everyone but the one with the old attendance is on a 10-Friday run of absences

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'landing.admin@fixture.invalid', password: PASSWORD, _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const html = async (url) => {
    const res = await fetch(`${base}${url}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, url);
    return res.text();
  };
  const section = (markup, heading) => {
    const start = markup.indexOf(`<h2>${heading}</h2>`);
    assert.ok(start >= 0, `section "${heading}" is present`);
    return markup.slice(start, markup.indexOf('</section>', start));
  };
  const names = (markup) => [...markup.matchAll(/class="list__name" href="\/members\/\d+\/attendance"/g)].length;

  // ---- landing: bounded previews ------------------------------------------
  const landing = await html('/attendance');
  const followCard = section(landing, 'Follow-up');
  assert.equal(names(followCard), 5, 'the Follow-up card previews exactly 5 people');
  assert.match(followCard, new RegExp(`See all ${flaggedCount}`), 'and says how many there are in total');
  const longCard = section(landing, 'Long absence');
  assert.equal(names(longCard), 5, 'the Long absence card previews 5 people');
  assert.match(longCard, /See all 34/, 'all 34 have had no tracked attendance in the window (33) or are long absent (1)');
  assert.doesNotMatch(longCard, /Not enough tracked history/, 'ten weeks of tracking is enough history');
  const groupCard = section(landing, 'By cell group');
  assert.equal((groupCard.match(/<tr>/g) || []).length - 1, 6, 'the cell group card is bounded to 6 groups');
  assert.match(groupCard, /See all 8 groups/);
  assert.match(groupCard, /#by-cell-group/);
  assert.ok(landing.length < 60000, 'the landing page stays small no matter how many members there are');
  assert.match(landing, /grid--top/, 'cards keep independent heights');
  // A register page carries the anchor the "See all groups" link points at.
  assert.match(await html(`/attendance/sessions/${sessions.get(-1).id}`), /id="by-cell-group"/);
  console.log('PASS (landing) bounded previews: 5 follow-up, long absence preview, 6 cell groups, "See all" with totals, independent card heights');

  // ---- landing keeps the lifecycle wording when a Friday awaits finalization -
  assert.equal(lifecycle.reopenAttendance(sessions.get(-4).id, { userId: null, reason: 'Recount' }).ok, true);
  const incomplete = await html('/attendance');
  assert.match(incomplete, /awaiting finalization/i);
  assert.match(section(incomplete, 'Follow-up'), /Follow-up may be incomplete because attendance for one or more Fridays is awaiting finalization/);
  assert.equal(lifecycle.finalizeAttendance(sessions.get(-4).id, { userId: null, confirmNoAttendance: true }).ok, true);

  // ---- follow-up: paging, search, filter, sort, query state ---------------
  const rowsOf = (markup) => (markup.match(/<tbody>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 1;
  let follow = await html('/attendance/follow-up');
  assert.equal(rowsOf(follow), 25, 'follow-up pages 25 at a time');
  assert.match(follow, new RegExp(`Showing 1&ndash;25 of ${flaggedCount}`));
  assert.match(follow, /rel="next"/);
  follow = await html('/attendance/follow-up?page=2');
  assert.equal(rowsOf(follow), flaggedCount - 25);
  assert.equal(rowsOf(await html('/attendance/follow-up?page_size=50')), flaggedCount);
  follow = await html('/attendance/follow-up?q=Absent07');
  assert.equal(rowsOf(follow), 1, 'search by name');
  const inGroup = db.prepare('SELECT COUNT(*) n FROM members WHERE cell_group_id = ? AND id != ?').get(groups[3].id, old.id).n;
  follow = await html(`/attendance/follow-up?cell_group_id=${groups[3].id}`);
  assert.equal(rowsOf(follow), inGroup, 'cell group filter');
  follow = await html('/attendance/follow-up?q=Landing&sort=member&dir=asc&page_size=50');
  assert.match(follow, /href="\/attendance\/follow-up\?[^"]*q=Landing/, 'sorting keeps the search');
  const firstNames = [...follow.matchAll(/<td data-label="Member">\s*<a href="\/members\/\d+\/attendance">([^<]+)<\/a>/g)].map((m) => m[1]);
  assert.deepEqual([...firstNames].sort((a, b) => a.localeCompare(b)), firstNames, 'sorted by member, ascending');
  console.log('PASS (follow-up page) paged 25/50/100, search, cell group filter, sort, total count, filters kept in the links');

  // ---- long absence: paging, filter, search ------------------------------
  let long = await html('/attendance/long-absence');
  assert.equal(rowsOf(long), 25, 'long absence pages 25 at a time');
  assert.match(long, /Showing 1&ndash;25 of 34/);
  assert.equal(rowsOf(await html('/attendance/long-absence?page=2')), 9);
  long = await html('/attendance/long-absence?state=no_tracked_attendance&page_size=50');
  assert.equal(rowsOf(long), 33, 'no tracked attendance filter');
  long = await html('/attendance/long-absence?state=long_absent');
  assert.equal(rowsOf(long), 1);
  assert.match(long, /Attended before, now away/);
  assert.equal(rowsOf(await html('/attendance/long-absence?q=Absent12')), 1, 'search');
  const inGroupLong = db.prepare('SELECT COUNT(*) n FROM members WHERE cell_group_id = ?').get(groups[2].id).n;
  assert.equal(rowsOf(await html(`/attendance/long-absence?cell_group_id=${groups[2].id}`)), inGroupLong, 'cell group filter');
  assert.match(await html('/attendance/long-absence?state=no_tracked_attendance&sort=member'), /href="\/attendance\/long-absence\?[^"]*state=no_tracked_attendance/, 'sorting keeps the filter');
  console.log('PASS (long absence page) search/state/cell group filters and the pager are present and correct');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
