import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Members list: by default it shows everyone currently with CCIQ (Active, Pending, Attendee,
 * Bonafide, Temporarily Away - the same population the Dashboard and Ministries use). Every other
 * status is one click away and still filterable; the choice survives paging, sorting and the CSV
 * export. No count is hard-coded: everything is derived from the fixture.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-members-population-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const members = await import('../services/members.js');
const { createUser } = await import('../services/users.js');

const PASSWORD = `Mp${crypto.randomBytes(12).toString('base64url')}9!`;
const STATUSES = members.MEMBER_STATUSES;
const byStatus = {};
STATUSES.forEach((status, i) => {
  byStatus[status] = members.createMember({ first_name: `Person${i}`, last_name: `In${status.replace(/_/g, '')}` }, { status });
});
const currentNames = members.CURRENT_POPULATION_STATUSES.map((s) => byStatus[s].member_code);
const otherStatuses = STATUSES.filter((s) => !members.CURRENT_POPULATION_STATUSES.includes(s));
assert.ok(otherStatuses.length > 0, 'the fixture has non-current statuses to hide');
await createUser({ username: 'pop_admin', email: 'pop.admin@fixture.invalid', password: PASSWORD, displayName: 'Pop Admin', roleKeys: ['church_admin'], mustChangePassword: false });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'pop.admin@fixture.invalid', password: PASSWORD, _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const get = async (url) => { const r = await fetch(`${base}${url}`, { headers: { Cookie: cookie } }); assert.equal(r.status, 200, url); return r.text(); };
  const codesIn = (text) => STATUSES.filter((s) => text.includes(byStatus[s].member_code));

  // Default: current population only.
  let html = await get('/members');
  assert.deepEqual(codesIn(html).sort(), [...members.CURRENT_POPULATION_STATUSES].sort(), 'the default list is exactly the current population');
  assert.match(html, /data-members-scope="default"/);
  assert.match(html, /Showing current members/);
  assert.match(html, /Show all statuses/);
  assert.match(html, />Current members</, 'the status control says what it is showing');
  for (const s of members.CURRENT_POPULATION_STATUSES) {
    assert.match(html, new RegExp(`name="status" value="${s}"[^>]*checked`), `${s} is pre-checked`);
  }
  for (const s of otherStatuses) assert.doesNotMatch(html, new RegExp(`name="status" value="${s}"[^>]*checked`), `${s} is not checked`);
  const summary = html.match(/<strong>(\d+) Current<\/strong> · (\d+) Total/);
  assert.ok(summary, 'the Current / Total summary is still shown');
  assert.equal(Number(summary[1]), members.CURRENT_POPULATION_STATUSES.length, 'derived from data, not hard-coded');
  assert.equal(Number(summary[2]), STATUSES.length);
  console.log('PASS (default) /members lists exactly the current population; other statuses are hidden but counted in the header');

  // Everything else stays reachable.
  html = await get('/members?status=all');
  assert.deepEqual(codesIn(html).sort(), [...STATUSES].sort(), 'status=all shows every status');
  assert.match(html, /data-members-scope="all"/);
  assert.match(html, />All statuses</);
  assert.match(html, /Show current members only/);
  for (const s of otherStatuses) {
    html = await get(`/members?status=${s}`);
    assert.deepEqual(codesIn(html), [s], `filtering by ${s} still works`);
    assert.match(html, /data-members-scope="chosen"/);
  }
  html = await get(`/members?status=archived&status=${members.CURRENT_POPULATION_STATUSES[0]}`);
  assert.deepEqual(codesIn(html).sort(), ['archived', members.CURRENT_POPULATION_STATUSES[0]].sort(), 'multiple chosen statuses combine');
  html = await get('/members?status=not_a_status');
  assert.deepEqual(codesIn(html).sort(), [...members.CURRENT_POPULATION_STATUSES].sort(), 'an unknown status falls back to the default');
  console.log('PASS (reachable) status=all, single and multiple statuses, and an invalid value all behave');

  // Query state survives: links (sort/export/paging) and the CSV.
  html = await get('/members?status=all&sort=code&direction=desc');
  assert.match(html, /export\.csv\?[^"]*status=all/, 'the export link carries the all-statuses choice');
  assert.match(html, /href="\/members\?[^"]*status=all[^"]*"/, 'sort links keep it');
  html = await get('/members');
  const exportLink = html.match(/href="(\/members\/export\.csv\?[^"]*)"/);
  assert.ok(exportLink, 'export link present');
  assert.doesNotMatch(exportLink[1].replace(/&amp;/g, '&'), /status=/, 'the default export needs no status key: it follows the same default');
  const csv = async (url) => (await get(url.replace(/&amp;/g, '&')));
  const csvDefault = await csv(exportLink[1]);
  assert.deepEqual(codesIn(csvDefault).sort(), [...members.CURRENT_POPULATION_STATUSES].sort(), 'the default CSV matches the screen');
  const csvAll = await csv('/members/export.csv?status=all');
  assert.deepEqual(codesIn(csvAll).sort(), [...STATUSES].sort(), 'the all-statuses CSV is complete');
  console.log('PASS (state) sort and export links carry the status choice; the CSV always matches the screen');

  // Dashboard: the members card is the current population, Active is a detail.
  html = await get('/');
  const card = html.slice(html.indexOf('<p class="stat__label">Members</p>'));
  assert.match(card.slice(0, 300), new RegExp(`stat__value">${members.CURRENT_POPULATION_STATUSES.length}<`), 'the headline is the current population');
  assert.match(card.slice(0, 400), /currently with CCIQ/);
  assert.match(card.slice(0, 400), /of them Active status/, 'Active is a sub-count, not the church population');
  console.log('PASS (dashboard) the Members card headlines everyone currently with CCIQ, with Active as a sub-count');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
