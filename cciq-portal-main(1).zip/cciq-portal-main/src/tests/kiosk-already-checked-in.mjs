import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Attendance Kiosk: people who are ALREADY checked in are never offered a "Confirm attendance".
 *   - review (name search) of one person already present: an "Already checked in" state and one way on ("Next check-in"), no confirm form;
 *   - a whole family already present: the same; a mixed family: the already-present person is read-only and is not submitted again, and the button counts NEW check-ins only;
 *   - recording only already-present people writes nothing; a repeat scan or repeat post never creates a second attendance row;
 *   - the QR lookup tells the screen who is already in; in a real browser the single scan, the whole-household scan and the mixed household behave as above and the scan field has focus again.
 */

const f = await buildPortalFixture('cciq-kiosk-already-');
const { db, ids, users, mods } = f;
const sessionId = ids.session;
const rows = (memberId) => db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND member_id = ?').get(sessionId, memberId).n;
const total = () => db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?').get(sessionId).n;
const mark = (memberId) => mods.attendance.recordAttendance(sessionId, [{ memberId, status: 'present' }], { userId: users.churchAdmin.id });
const qr = await import(new URL('../services/qr-checkin.js', import.meta.url)); // after the isolated environment exists
const token = (memberId) => qr.ensureQrToken(memberId);
const { a2, b1, a3, b2 } = ids.member; // a2 and b1 are the two members of the fixture Family Group

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const csrf = await kiosk.csrf('/kiosk');
  const review = async (people, extra = {}) => { const res = await kiosk.post('/attendance/checkin/review', { kiosk: '1', person: people.map((id) => `member:${id}`), ...extra }, { csrf }); return { status: res.status, html: await res.text() }; };
  const record = async (people) => { const res = await kiosk.post('/attendance/checkin/record', { kiosk: '1', person: people.map((id) => `member:${id}`) }, { csrf }); await res.text(); return res; };
  const confirmOffered = (html) => /Confirm attendance for \d+ (person|people)/.test(html);

  // ---- 1. one person, already present ---------------------------------------------------------------------------------------------------------------------------
  mark(a3);
  {
    const page = await review([a3]);
    assert.equal(page.status, 200);
    assert.ok(/Already checked in/.test(page.html), 'says so');
    assert.ok(!confirmOffered(page.html), 'no "Confirm attendance" for someone already in');
    assert.ok(!/action="\/attendance\/checkin\/record"/.test(page.html), 'no record form at all');
    assert.ok(/id="checkin-done"[^>]*>Next check-in</.test(page.html), 'one way on');
    assert.match(page.html, /id="checkin-done" href="\/kiosk"|href="\/kiosk"[^>]*id="checkin-done"|id="checkin-done"[^>]*href="\/kiosk"/, 'it returns to the scanner-ready kiosk home');
  }

  // ---- 2. a person NOT yet in still gets the normal confirm, counting one ----------------------------------------------------------------------------------------------
  {
    const page = await review([b2]);
    assert.ok(/Confirm attendance for 1 person/.test(page.html));
    assert.ok(!/id="checkin-done"/.test(page.html));
  }

  // ---- 3. the whole family already present ----------------------------------------------------------------------------------------------------------------------------
  mark(a2); mark(b1);
  {
    const page = await review([a2, b1]);
    assert.ok(!confirmOffered(page.html), 'no confirm when everyone is already in');
    assert.ok(/Everyone selected is already recorded/.test(page.html));
    assert.equal((page.html.match(/Already checked in<\/span>/g) || []).length, 2, 'each person is marked');
    assert.ok(/id="checkin-done"/.test(page.html));
  }

  // ---- 4. mixed: one already in, one not --------------------------------------------------------------------------------------------------------------------------------
  db.prepare('DELETE FROM attendance_records WHERE session_id = ? AND member_id = ?').run(sessionId, b1);
  {
    const page = await review([a2, b1]);
    assert.ok(/Confirm attendance for 1 person/.test(page.html), 'the count is NEW check-ins only');
    const form = /<form method="post" action="\/attendance\/checkin\/record"[\s\S]*?<\/form>/.exec(page.html)?.[0] || '';
    assert.ok(form.includes(`member:${b1}`) && !form.includes(`member:${a2}`), 'the person already in is not submitted again');
    assert.ok(/Already checked in<\/span>/.test(page.html));
  }

  // ---- 5. recording changes nothing for someone already in, and a repeat never doubles a row -----------------------------------------------------------------------------
  {
    const before = total();
    const first = await record([a2]);
    assert.equal(first.status, 302);
    assert.equal(total(), before, 'nothing written for a person already in');
    await record([b1]); await record([b1]); await record([a2, b1]);
    assert.equal(rows(b1), 1); assert.equal(rows(a2), 1);
  }

  // ---- 6. the scan lookup says who is already in -----------------------------------------------------------------------------------------------------------------------
  {
    const res = await kiosk.post('/attendance/checkin/lookup', { token: token(a3) }, { csrf });
    const data = await res.json();
    assert.equal(data.ok, true);
    assert.equal(data.member.existingStatus, 'present');
    const fam = await (await kiosk.post('/attendance/checkin/lookup', { token: token(a2) }, { csrf })).json();
    assert.deepEqual(fam.family.members.map((m) => m.existingStatus).sort(), ['present', 'present']);
    const fresh = await (await kiosk.post('/attendance/checkin/lookup', { token: token(b2) }, { csrf })).json();
    assert.equal(fresh.member.existingStatus, null);
    const dup = await (await kiosk.post('/attendance/checkin/lookup', { token: token(a3) }, { csrf })).json();
    assert.equal(dup.ok, true);
    assert.equal(rows(a3), 1, 'a lookup writes nothing');
  }

  // ---- 7. a real browser, at a desk size and a tablet/phone size --------------------------------------------------------------------------------------------------------
  const scannerReady = async (page, where) => { try { await page.waitForFunction(() => document.activeElement && document.activeElement.id === 'checkin-input', null, { timeout: 8000 }); } catch (e) { throw new Error(`the scan field has no focus ${where}: ${page.url()} active=${await page.evaluate(() => document.activeElement && document.activeElement.outerHTML.slice(0, 120))}`); } };
  const problems = [];
  for (const width of [1280, 768, 390]) {
    for (const id of [a2, b1, a3]) mark(id); // everyone starts the round already checked in
    const context = await browser.newContext({ viewport: { width, height: 900 } });
    await context.addCookies(kiosk.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    const focused = () => page.evaluate(() => document.activeElement && document.activeElement.id);
    const scan = async (id) => { await page.locator('#checkin-input').fill(token(id)); await page.locator('#checkin-lookup').click(); };
    const tag = `${width}px`;

    // single person, already in
    await scan(a3);
    await page.locator('#checkin-success-view').waitFor({ state: 'visible' });
    const message = await page.locator('#checkin-success-message').innerText();
    if (!/already checked in/i.test(message)) problems.push(`${tag}: message was "${message}"`);
    if (await page.locator('#checkin-confirm').isVisible()) problems.push(`${tag}: Confirm shown for someone already in`);
    await page.locator('#checkin-next').click();
    await scannerReady(page, 'after Next check-in');
    if ((await focused()) !== 'checkin-input') problems.push(`${tag}: the scan field has no focus after Next check-in`);

    // the whole household already in
    await scan(a2);
    await page.locator('#checkin-family-view').waitFor({ state: 'visible' });
    if (await page.locator('#checkin-family-submit').isVisible()) problems.push(`${tag}: household already in but Confirm is offered`);
    if (!(await page.locator('#checkin-family-done').isVisible())) problems.push(`${tag}: no Next check-in for a household already in`);
    if (!/already checked in/i.test(await page.locator('#checkin-family-subtitle').innerText())) problems.push(`${tag}: the household is not said to be in`);
    await page.locator('#checkin-family-done').click();
    await scannerReady(page, 'after Next check-in');

    // mixed household: take b1 out first, then scan the family
    db.prepare('DELETE FROM attendance_records WHERE session_id = ? AND member_id = ?').run(sessionId, b1);
    await scan(a2);
    await page.locator('#checkin-family-view').waitFor({ state: 'visible' });
    if (!/Confirm attendance for 1 person/.test(await page.locator('#checkin-family-submit').innerText())) problems.push(`${tag}: the count is not NEW people only`);
    const boxes = await page.locator('#checkin-family-list input[name="person"]').count();
    if (boxes !== 1) problems.push(`${tag}: ${boxes} checkboxes (the person already in must have none)`);
    await page.locator('#checkin-family-list input[name="person"]').uncheck();
    if (await page.locator('#checkin-family-submit').isVisible()) problems.push(`${tag}: Confirm still shown with nobody new ticked`);
    if (!(await page.locator('#checkin-family-done').isVisible())) problems.push(`${tag}: no Next check-in with nobody new ticked`);
    await page.locator('#checkin-family-list input[name="person"]').check();
    if (!(await page.locator('#checkin-family-submit').isVisible())) problems.push(`${tag}: Confirm gone although someone new is ticked`);
    await page.locator('#checkin-family-submit').click();
    await page.waitForFunction(() => /Attendance recorded for 1 person/.test(document.querySelector('#checkin-success-message')?.textContent || ''));
    if (rows(b1) !== 1) problems.push(`${tag}: the new person was not recorded exactly once (${rows(b1)})`);
    await page.locator('#checkin-next').click();
    await scannerReady(page, 'after Next check-in');

    // duplicate scan right after: still one row, no confirm
    await scan(a3);
    await page.locator('#checkin-success-view').waitFor({ state: 'visible' });
    if (rows(a3) !== 1) problems.push(`${tag}: a duplicate scan changed the rows (${rows(a3)})`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (overflow > 0) problems.push(`${tag}: sideways scroll ${overflow}px`);
    await context.close();
    db.prepare('DELETE FROM attendance_records WHERE session_id = ? AND member_id = ?').run(sessionId, b1);
  }
  assert.deepEqual(problems, [], problems.join('\n'));

  // ---- 7b. confirmation -> success -> Next check-in -> the scanner is ready, with no duplicate row, however it is repeated -----------------------------------------------------------------
  {
    const people = [a3, b2]; // two singles, neither in a household
    const clear = () => { for (const id of [a2, b1, a3, b2, ids.member.free]) db.prepare('DELETE FROM attendance_records WHERE session_id = ? AND member_id = ?').run(sessionId, id); };
    const problems2 = [];
    for (const width of [1280, 390]) {
      clear();
      const context = await browser.newContext({ viewport: { width, height: 900 } });
      await context.addCookies(kiosk.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
      const page = await context.newPage();
      const tag = width + 'px';
      const review2 = async (ids2) => {
        await page.goto(portal.base + '/kiosk?q=' + encodeURIComponent('Other'), { waitUntil: 'load' }); // any search page; the review is posted from the form below
        await page.evaluate(({ people: p, csrf: token }) => {
          const form = document.createElement('form'); form.method = 'post'; form.action = '/attendance/checkin/review';
          const add = (n, v) => { const i = document.createElement('input'); i.type = 'hidden'; i.name = n; i.value = v; form.appendChild(i); };
          add('_csrf', token); add('kiosk', '1'); p.forEach((id) => add('person', 'member:' + id)); document.body.appendChild(form); form.submit();
        }, { people: ids2, csrf });
        await page.waitForURL(/\/attendance\/checkin\/review/);
      };

      // two new people, confirmed together
      await review2(people);
      if (!/Confirm attendance for 2 people/.test(await page.locator('main').innerText())) problems2.push(tag + ': the review does not offer "Confirm attendance for 2 people"');
      await page.getByRole('button', { name: /Confirm attendance for 2 people/ }).click();
      await page.locator('#kiosk-record-done').waitFor({ state: 'visible' });
      const done = await page.locator('#kiosk-record-message').innerText();
      if (!/Attendance recorded for 2 people/.test(done)) problems2.push(tag + ': success message was "' + done + '"');
      if (await page.locator('[data-review-hide]').first().isVisible()) problems2.push(tag + ': the old review is still on screen after success');
      if (await page.getByRole('button', { name: /Confirm attendance/ }).count() && await page.getByRole('button', { name: /Confirm attendance/ }).first().isVisible()) problems2.push(tag + ': a Confirm button is still offered after success');
      const next = page.getByRole('link', { name: 'Next check-in' });
      if (!(await next.isVisible())) problems2.push(tag + ': no Next check-in after success');
      if (rows(a3) !== 1 || rows(b2) !== 1) problems2.push(tag + ': the two people were not recorded exactly once');
      await next.click();
      await page.waitForURL(/\/kiosk$/);
      await scannerReady(page, 'after Next check-in');
      if (page.url().includes('review')) problems2.push(tag + ': still on the review page');

      // repeating the same review (a refresh, a second tab) offers nothing and writes nothing
      const before = total();
      await review2(people);
      if (await page.getByRole('button', { name: /Confirm attendance/ }).count()) problems2.push(tag + ': the repeated review offers Confirm');
      if (!/Already checked in/.test(await page.locator('main').innerText())) problems2.push(tag + ': the repeated review does not say so');
      await page.getByRole('link', { name: 'Next check-in' }).click();
      await scannerReady(page, 'after Next check-in');
      if (total() !== before) problems2.push(tag + ': a repeated review changed the attendance');

      // mixed: one already in, one new -> only the new one is recorded and named
      clear(); mark(a3);
      await review2(people);
      if (!/Confirm attendance for 1 person/.test(await page.locator('main').innerText())) problems2.push(tag + ': the mixed review does not count one new person');
      await page.getByRole('button', { name: /Confirm attendance for 1 person/ }).click();
      await page.locator('#kiosk-record-done').waitFor({ state: 'visible' });
      const mixedDone = await page.locator('#kiosk-record-message').innerText();
      if (!/Attendance recorded for 1 person/.test(mixedDone) || !/Bo/.test(mixedDone) || /Andre/.test(mixedDone.split('Already')[0])) problems2.push(tag + ': the mixed success message was "' + mixedDone + '"');
      if (rows(a3) !== 1 || rows(b2) !== 1) problems2.push(tag + ': the mixed confirmation duplicated or missed a row');
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      if (overflow > 0) problems2.push(tag + ': sideways scroll ' + overflow + 'px');
      await page.getByRole('link', { name: 'Next check-in' }).click();
      await scannerReady(page, 'after Next check-in');
      await context.close();
    }
    assert.deepEqual(problems2, [], problems2.join('\n'));

    // the First Timer link opens in a new tab and leaves this one as it was
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    await context.addCookies(kiosk.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.goto(portal.base + '/kiosk', { waitUntil: 'load' });
    const html = await page.content();
    assert.match(html, /<a href="\/attendance\/checkin\/first-timer" target="_blank" rel="noopener"[^>]*>First time here\? Register and check in<span class="sr-only"> \(opens in a new tab\)<\/span><\/a>/, 'the link says it opens in a new tab and protects the opener');
    const [popup] = await Promise.all([context.waitForEvent('page'), page.getByRole('link', { name: /First time here/ }).click()]);
    await popup.waitForLoadState('load');
    assert.match(popup.url(), /\/attendance\/checkin\/first-timer/, 'the registration opened in its own tab');
    assert.ok(page.url().endsWith('/kiosk'), 'the kiosk tab stayed where it was');
    await popup.close();
    await page.bringToFront(); // coming back to the kiosk tab
    await scannerReady(page, 'after returning from the registration tab');
    await context.close();
  }

  // ---- 8. finalization still closes it ---------------------------------------------------------------------------------------------------------------------------------
  db.prepare("UPDATE attendance_sessions SET finalization_state = 'not_taken', finalized_at = ?, finalization_note = 'x' WHERE id = ?").run(new Date().toISOString(), sessionId);
  {
    const res = await kiosk.post('/attendance/checkin/review', { kiosk: '1', person: [`member:${a3}`] }, { csrf });
    assert.equal(res.status, 302, 'a closed Friday refuses the review');
    await res.text();
  }
} finally {
  await portal.stop();
  await browser.close();
}
f.db.close();
f.env.cleanup();
console.log('PASS (review) one person, a whole family or a mixed family already checked in: an "Already checked in" state with one way on, no Confirm; mixed households submit and count NEW people only');
console.log('PASS (idempotent) recording only already-present people writes nothing; repeat posts and repeat scans never create a second attendance row');
console.log('PASS (scan) the lookup reports who is already in; in a real browser at 1280, 768 and 390 px a single scan, a full household and a mixed household behave the same, the scan field regains focus and nothing scrolls sideways');
console.log('PASS (success journey) scan or search -> review -> Confirm -> "Attendance recorded for N people" -> Next check-in -> the scanner is ready with focus, at 1280 and 390 px; a repeated review writes nothing; a mixed review records and names only the new person');
console.log('PASS (First Timer) the kiosk link opens the registration in a new tab (noopener, announced) and the kiosk tab stays as it was');
console.log('ALL PASS');
