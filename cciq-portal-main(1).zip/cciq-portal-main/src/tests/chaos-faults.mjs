import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * Faults on purpose. The database is made to fail in the ways it can fail (a read that cannot be answered, a write the database refuses at the
 * moment of the audit row, a notification that cannot be written, a pdf or csv that cannot be built) while real requests run. The portal must:
 *   - stay alive and keep answering the next request;
 *   - show a plain error page with a reference, never SQL, a column name, a path or a stack;
 *   - roll back a failed write completely (no half-made First Timer, review, visit or member) and keep every integrity rule true;
 *   - never let a failure of something secondary (a notification, an audit row for a read, a review evaluation) undo or block the primary action
 *     unless the audit row IS part of the action (then everything rolls back together).
 */

const f = await buildPortalFixture('cciq-chaos-');
const { db, ids, users, mods } = f;
const lifecycle = await import('../services/attendance-lifecycle.js');
await import('../services/membership-review.js');
const portal = await startPortal();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
const LEAK = /SqliteError|SQLITE_|no such (column|table)|phone_x|detail_x|title_x|\bat \w+ \(|node_modules|\.js:\d+|C:\\\\|storage[\\/]/i;
const health = async () => (await fetch(`${portal.base}/healthz`)).status;
const count = (sql, ...p) => db.prepare(sql).get(...p).n;

const visitor = mods.visitors.createVisitor({ first_name: 'Chaos', last_name: 'Visitor', phone: '+974 5511 2233', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
let errorPages = 0;

try {
  // ---- 1. reads that cannot be answered ------------------------------------------------------------------------------------------------------
  const readFaults = [
    ['visitors.phone', 'visitors', 'phone', ['/visitors', '/visitors?q=Chaos', `/visitors/${visitor.id}`, '/visitors/follow-up', '/visitors/reviews', `/visitors/${visitor.id}/convert`, `/visitors/${visitor.id}/link`, '/reports/first-timers/pdf', '/']],
    ['members.phone', 'members', 'phone', ['/members', `/members/${ids.member.a2}`, `/members/${ids.member.a2}/edit`, '/members/export.csv', '/reports/directory/pdf?statuses_submitted=1&status=active', '/search?q=Alice', '/members/picker-search?q=Ali']],
    ['attendance_sessions.title', 'attendance_sessions', 'title', ['/attendance', `/attendance/sessions/${ids.session}`, '/attendance/history', '/reports/attendance', '/reports/attendance/pdf']],
    ['documents.title', 'documents', 'title', ['/documents', `/documents/${ids.document}`, '/documents/new']],
    ['audit_logs.detail', 'audit_logs', 'detail', ['/admin/audit', '/admin/audit.csv']],
    ['announcements.title', 'announcements', 'title', ['/announcements', '/']],
    ['cell_groups.name', 'cell_groups', 'name', ['/cell-groups', `/cell-groups/${ids.groupA}`]]
  ];
  for (const [label, table, column, urls] of readFaults) {
    db.exec(`ALTER TABLE ${table} RENAME COLUMN ${column} TO ${column}_x`);
    const seen = [];
    try {
      for (const url of urls) {
        const res = await admin.get(url); const text = await res.text();
        seen.push(`${res.status}`);
        assert.ok(res.status < 600, `${label}: ${url} answers`);
        if (res.status >= 500) {
          errorPages += 1;
          assert.doesNotMatch(text, LEAK, `${label}: the error page for ${url} shows nothing internal`);
          assert.match(text, /Reference [0-9a-f]{8}|could not complete|Something went wrong/i, `${label}: ${url} gives a plain error with a reference`);
        } else if (res.status === 200) assert.doesNotMatch(text, LEAK, `${label}: even a 200 page for ${url} shows nothing internal`);
        assert.equal(await health(), 200, `${label}: the portal is still up after ${url}`);
      }
    } finally { db.exec(`ALTER TABLE ${table} RENAME COLUMN ${column}_x TO ${column}`); }
    for (const url of urls.slice(0, 2)) { const res = await admin.get(url); await res.text(); assert.ok(res.status < 500, `${label}: ${url} works again once the fault is gone (${res.status})`); }
  }
  // the Kiosk too: a search that cannot be answered
  db.exec('ALTER TABLE visitors RENAME COLUMN phone TO phone_x');
  { const res = await kiosk.post('/attendance/checkin/search', { q: 'Chaos', kiosk: '1' }, { csrfFrom: '/kiosk' }); const text = await res.text(); errorPages += res.status >= 500 ? 1 : 0; assert.doesNotMatch(text, LEAK, 'the Kiosk sees nothing internal when a search cannot be answered'); assert.equal(await health(), 200); }
  db.exec('ALTER TABLE visitors RENAME COLUMN phone_x TO phone');
  { // every 5xx left a durable, stack-free record an administrator can find by the reference on the page (when the audit table itself is the fault, it is simply skipped)
    const logged = db.prepare("SELECT detail, result FROM audit_logs WHERE action = 'system.error'").all();
    assert.ok(logged.length > 0 && logged.length <= errorPages, 'server errors are recorded in the audit log (best effort)');
    for (const row of logged) {
      const detail = JSON.parse(row.detail);
      assert.equal(row.result, 'failure'); assert.match(detail.reference, /^[0-9a-f]{8}$/); assert.ok(detail.status >= 500 && detail.path.startsWith('/') && !detail.path.includes('?'), 'path without a query string');
      assert.doesNotMatch(row.detail, LEAK, 'the audit record holds no SQL, column, stack or path');
    }
  }
  console.log(`PASS (read faults) ${readFaults.length} tables made unreadable in turn: every page answers, ${errorPages} became a plain error page with a reference and no SQL, column or path, the portal stayed up, and every page worked again afterwards`);

  // ---- 2. writes refused at the audit row: nothing is half-made -------------------------------------------------------------------------------
  const noAuditFor = (actions, fn) => {
    db.exec(`CREATE TRIGGER fx_chaos_audit BEFORE INSERT ON audit_logs WHEN NEW.action IN (${actions.map((a) => `'${a}'`).join(',')}) BEGIN SELECT RAISE(ABORT, 'injected failure'); END`);
    return Promise.resolve(fn()).finally(() => db.exec('DROP TRIGGER fx_chaos_audit'));
  };
  const world = () => JSON.stringify([count('SELECT COUNT(*) n FROM visitors'), count('SELECT COUNT(*) n FROM visitor_visits'), count('SELECT COUNT(*) n FROM members'), db.prepare('SELECT state, member_id, follow_up_state FROM visitors ORDER BY id').all(), db.prepare('SELECT status FROM visitor_membership_reviews ORDER BY id').all()]);
  const review = Number(db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(visitor.id).lastInsertRowid);
  const attempts = [
    ['record a First Timer', ['visitor.created'], () => admin.post('/visitors', { first_name: 'Never', last_name: 'Saved', first_visit_date: ids.friday }, { csrfFrom: '/visitors/new' })],
    ['record a visit', ['visitor.visit_recorded'], () => admin.post(`/visitors/${visitor.id}/visits`, { visit_date: mods.dates.addDays(ids.friday, -7) }, { csrfFrom: `/visitors/${visitor.id}` })],
    ['change an outcome', ['visitor.state_changed', 'visitor.outcome_changed'], () => admin.post(`/visitors/${visitor.id}/state`, { state: 'declined' }, { csrfFrom: `/visitors/${visitor.id}` })],
    ['Continue as Visitor', ['visitor.membership_review_continued'], () => admin.post(`/visitors/reviews/${review}/continue`, { confirm: '1' }, { csrfFrom: `/visitors/reviews/${review}` })],
    ['Convert', ['visitor.became_member', 'member.created'], () => admin.post(`/visitors/${visitor.id}/convert`, { first_name: 'Chaos', last_name: 'Visitor', duplicate_override: '1' }, { csrfFrom: `/visitors/${visitor.id}/convert` })],
    ['Link', ['visitor.linked_to_member'], () => admin.post(`/visitors/${visitor.id}/link`, { member_id: String(ids.member.free), confirm: '1' }, { csrfFrom: `/visitors/${visitor.id}/link` })],
    ['Express Registration', ['visitor.express_registered'], () => kiosk.post('/attendance/checkin/first-timer', { first_name: 'Quick', last_name: 'Fail', kiosk: '1' }, { csrfFrom: '/kiosk' })],
    ['Kiosk check-in of a First Timer', ['attendance.recorded', 'visitor.visit_recorded', 'attendance.checkin_recorded'], () => kiosk.post('/attendance/checkin/record', { person: `visitor:${visitor.id}`, kiosk: '1' }, { csrfFrom: '/kiosk' })]
  ];
  let refused = 0;
  for (const [label, actions, run] of attempts) {
    const before = world();
    const res = await noAuditFor(actions, run); const text = await res.text();
    assert.doesNotMatch(text, LEAK, `${label}: a refused write shows nothing internal`);
    assert.equal(await health(), 200, `${label}: the portal is up`);
    const after = world();
    if (res.status >= 500) { refused += 1; assert.equal(after, before, `${label}: a failed write left nothing behind`); }
    else if (after !== before) assert.ok(res.status < 500, `${label}: (this action does not write that audit row; it completed normally)`);
  }
  assert.ok(refused >= 5, `most of the actions write an audit row inside their transaction and so rolled back completely (${refused})`);
  assert.deepEqual(checkInvariants(db).findings.filter((x) => x.severity === 'error' && /^(visitor|review|member)\./.test(x.code)), [], 'and every First Timer, review and member rule still holds');
  console.log(`PASS (write faults) ${attempts.length} First Timer actions each refused at their audit row: ${refused} rolled back completely with a plain error, nothing half-made, integrity rules intact`);

  // ---- 3. secondary failures do not undo the primary action ---------------------------------------------------------------------------------------
  {
    // a notification that cannot be written, and an audit row for a review evaluation, while a Friday is finalized and reviews are due
    db.pragma('foreign_keys = OFF');
    db.exec('DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors;');
    db.pragma('foreign_keys = ON');
    db.exec("UPDATE members SET created_at = '2020-01-01T00:00:00.000Z'; UPDATE member_status_history SET changed_at = '2020-01-01T00:00:00.000Z'"); // members who have plainly been here all along, so finalizing past Fridays is not ambiguous about them
    mods.setSetting('attendance.tracking_start_date', mods.dates.addDays(ids.friday, -21));
    const sessions = [];
    for (let n = -3; n <= 0; n += 1) {
      const date = mods.dates.addDays(ids.friday, 7 * n);
      db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(date, `${date}T09:00:00.000Z`);
      sessions.push(db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(date).id);
    }
    const regular = mods.visitors.createVisitor({ first_name: 'Regular', last_name: 'Fault', first_visit_date: mods.dates.addDays(ids.friday, -400) }, { userId: null });
    for (const sid of sessions.slice(0, 3)) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) SELECT ?, service_date, id, ? FROM attendance_sessions WHERE id = ?').run(regular.id, 'x', sid);
    for (const sid of sessions.slice(0, 3)) assert.equal(lifecycle.finalizeAttendance(sid, { userId: null, confirmNoAttendance: true }).ok, true);
    db.exec("DELETE FROM visitor_membership_reviews; DELETE FROM notifications");
    db.exec("CREATE TRIGGER fx_chaos_notify BEFORE INSERT ON notifications BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
    const originalError = console.error; const logged = []; console.error = (...a) => logged.push(a.join(' '));
    let result;
    try { result = lifecycle.finalizeAttendance(sessions[3], { userId: null, confirmNoAttendance: true }); } finally { console.error = originalError; db.exec('DROP TRIGGER fx_chaos_notify'); }
    assert.equal(result.ok, true, 'the Friday is finalized although the notification could not be written');
    assert.equal(count("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'"), 1, 'the review itself was still opened (a notification is only a courtesy)');
    assert.ok(logged.some((l) => /notification/i.test(l)), 'and the failure was logged');
    assert.equal(count('SELECT COUNT(*) n FROM notifications'), 0, 'with no half-written notification');
    console.log('PASS (secondary faults) a notification that cannot be written neither blocks the finalization nor stops the review being opened; it is logged');
  }
  assert.equal(await health(), 200);
  console.log('ALL PASS');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
