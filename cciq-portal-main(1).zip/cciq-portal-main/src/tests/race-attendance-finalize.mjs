import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Attendance writers against finalization, ACROSS PROCESSES. The portal is one process, in which synchronous database access already makes a
 * check-in and a finalization take turns. But a check-in could be read as allowed, then the Friday finalized by another process (a maintenance
 * script, a second copy of the portal started by mistake), then the check-in written: a present mark that finalization never counted, on a
 * Friday that is closed. Every writer therefore re-reads the session inside its own immediate transaction. This proves it with real processes
 * released at the same instant, many times, with the order shuffled:
 *   - after "finalize" races any number of check-ins, register marks and Kiosk additions, every attendance row on that Friday is one the
 *     finalization's own audit record counted (nothing slips in afterwards);
 *   - "finalize" and "attendance not taken" racing: exactly one wins, one audit row, never both;
 *   - every writer that was told "ok" has its row; every writer that was refused has none;
 *   - no unhandled database-locked error.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
createIsolatedTestEnv('cciq-race-attendance-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

await createUser({ username: 'race_att_admin', email: 'race.att@fixture.invalid', password: 'Race-Fixture-Passw0rd!x', displayName: 'Race Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'race_att_admin'").get().id;
const SERVICE = lastFridayOnOrBefore(today());
const OLD = addDays(SERVICE, -400);
const atNoon = (d) => `${d}T09:00:00.000Z`;
setSetting('attendance.tracking_start_date', addDays(SERVICE, -14));

const members = [];
for (let i = 0; i < 12; i += 1) {
  const m = createMember({ first_name: `Racer${i}`, last_name: 'Att' }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', atNoon(OLD));
  members.push(m.id);
}
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(SERVICE, atNoon(SERVICE));
const sessionId = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(SERVICE).id;
const reset = () => {
  db.exec(`DELETE FROM qr_checkins; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM audit_logs;
           UPDATE attendance_sessions SET finalization_state = NULL, finalized_at = NULL, finalized_by = NULL, finalization_note = NULL WHERE id = ${sessionId}`);
};

async function race(jobs) {
  const barrier = path.join(os.tmpdir(), `cciq-race-att-barrier-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const ready = [];
  const children = jobs.map((job) => new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(here, 'lib', 'race-worker.mjs'), barrier, JSON.stringify({ userId: adminId, sessionId, ...job })], { env: process.env });
    let out = ''; let err = '';
    ready.push(new Promise((ok) => { child.stdout.on('data', (d) => { out += d; if (out.includes('READY')) ok(); }); child.on('exit', ok); }));
    child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (code) => resolve({ code, out: out.replace('READY', '').trim().split('\n').pop(), err: err.trim() }));
  }));
  await Promise.all(ready);
  fs.writeFileSync(barrier, 'go');
  const raw = await Promise.all(children);
  fs.rmSync(barrier, { force: true });
  return raw.map((r, i) => {
    assert.equal(r.code, 0, `a worker must not crash: ${r.err.slice(0, 300) || r.out}`);
    const parsed = JSON.parse(r.out);
    if (parsed.error) assert.ok(!/^SQLITE_BUSY/.test(String(parsed.error.code)), `no unhandled database-locked error: ${jobs[i].op} -> ${parsed.error.message}`);
    assert.ok(!parsed.error, `no unexpected error: ${jobs[i].op} -> ${parsed.error?.message}`);
    return { job: jobs[i], ...parsed.result };
  });
}
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const positiveRows = () => count("SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND status IN ('present','visitor')", sessionId);
const shuffle = (list) => { const a = [...list]; for (let i = a.length - 1; i > 0; i -= 1) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

const ROUNDS = 12; let finalizedRounds = 0; let lateRefusals = 0; let notTakenWins = 0;
for (let round = 0; round < ROUNDS; round += 1) {
  reset();
  // some members are already checked in before the race, so the snapshot and the rows are never trivially empty
  for (const id of members.slice(0, 2)) db.prepare("INSERT INTO attendance_records (session_id, member_id, status, source, recorded_at) VALUES (?, ?, 'present', 'manual', ?)").run(sessionId, id, atNoon(SERVICE));
  const jobs = shuffle([
    { op: 'finalize' },
    ...members.slice(2, 5).map((memberId) => ({ op: 'qr', memberId })),
    ...members.slice(5, 7).map((memberId) => ({ op: 'register', memberId })),
    ...members.slice(7, 9).map((memberId) => ({ op: 'people', memberId })),
    ...(round % 3 === 0 ? [{ op: 'notTaken' }] : [])
  ]);
  const out = await race(jobs);
  const state = db.prepare('SELECT finalization_state s FROM attendance_sessions WHERE id = ?').get(sessionId).s;
  const finalizes = count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.finalized'");
  const notTakens = count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.not_taken'");
  assert.ok(finalizes + notTakens === 1, `exactly one of finalize / not taken happened (${finalizes}/${notTakens}); state ${state}`);
  assert.equal(state, finalizes ? 'finalized' : 'not_taken', 'the stored state matches the one audit row');
  for (const o of out) {
    if (o.job.op === 'finalize') assert.equal(o.ok, Boolean(finalizes), 'finalize reports what happened');
    if (o.job.op === 'notTaken') assert.equal(o.ok, Boolean(notTakens), 'not taken reports what happened');
  }
  if (notTakens) notTakenWins += 1;
  if (finalizes) {
    finalizedRounds += 1;
    const detail = JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.finalized'").get().detail);
    const counted = detail.present + detail.unexpected_attendees;
    assert.equal(positiveRows(), counted, `every present mark on the closed Friday was counted by its finalization (rows ${positiveRows()}, counted ${counted})`);
    for (const o of out) if (['qr', 'register', 'people'].includes(o.job.op)) {
      const has = count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND member_id = ?', sessionId, o.job.memberId);
      const told = o.ok && (o.job.op !== 'people' || o.newly > 0 || o.already);
      if (!o.ok) { lateRefusals += 1; assert.equal(has, 0, `${o.job.op} for ${o.job.memberId} was refused (${o.reason}) and left nothing behind`); }
      else assert.equal(has, 1, `${o.job.op} for ${o.job.memberId} said ok and its row exists`);
      void told;
    }
  } else {
    // not taken: rows recorded before it are kept as evidence; no row is added once it is marked (the count stays what the writers reported)
    for (const o of out) if (['qr', 'register', 'people'].includes(o.job.op) && !o.ok) assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND member_id = ?', sessionId, o.job.memberId), 0, 'a refused writer left nothing');
  }
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', sessionId) > 0, Boolean(finalizes), 'a snapshot exists exactly when it was finalized');
}
console.log(`PASS (race) ${ROUNDS} rounds of finalize racing check-ins, register marks, Kiosk additions and "attendance not taken" in separate processes: finalized ${finalizedRounds}, not taken ${notTakenWins}, ${lateRefusals} late writers were refused; every row on a closed Friday was counted by its finalization, exactly one closing action ever won, nothing crashed or locked`);
db.close();
console.log('ALL PASS');
