import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Targeted responsive and role sweep of the screens changed in the overnight batch, in a real browser at 320, 375, 430, 768, 1024, 1280 and 1440 px:
 * First Timers (list, detail, follow-up, Membership review), the report launcher, Faith Promise administration, the Members list and profile, search, the Member
 * dashboard, My profile, Cell groups, and the Kiosk with a phone-number result. Each page must render (no error page, no console error), have no sideways scroll, and show
 * its key control. Each role sees only its own pages: a Member and the Kiosk are refused the administrative ones.
 */

const f = await buildPortalFixture('cciq-sweep-');
const { db, ids, users, mods } = f;
const make = (first, phone, status = 'active') => mods.members.createMember({ first_name: first, last_name: 'Sweep', phone }, { status }).id;
make('Phoneone', '+974 7701 7992'); make('Phonetwo', '+974 7701 7992'); make('Gone', '+974 3300 4400', 'inactive');
const visitor = mods.visitors.createVisitor({ first_name: 'Isaiah', last_name: 'Thomas', phone: '+974 5551 9999', first_visit_date: mods.dates.today(), invited_by_member_id: ids.member.a1 }, { userId: users.churchAdmin.id });

const WIDTHS = [320, 375, 430, 768, 1024, 1280, 1440];
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const problems = [];
try {
  const clients = { church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD), member: await signIn(portal.base, users.memberA.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD), leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD) };
  const cookiesOf = (c) => c.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const pages = {
    church: [['/visitors', 'a.btn'], [`/visitors/${visitor.id}`, 'h1'], ['/visitors/follow-up', 'h1'], ['/visitors/reviews', 'h1'], ['/reports', 'h1'], ['/reports/print', 'h1'], [`/admin/ecaq/faith-promise?campaign=${ids.promise}`, 'a[href*="#record-payment"]'],
      [`/admin/ecaq/faith-promise/commitments/${ids.commitment}`, '#record-payment'], ['/members?status=all', '.pill--member'], [`/members/${ids.member.gone}`, '.pill--member'], ['/search?q=Fixture', 'h1'], [`/cell-groups/${ids.groupA}`, 'h1']],
    member: [['/', '.card'], ['/cell-groups', 'h1'], [`/cell-groups/${ids.groupA}`, 'h1'], ['/search?q=Fixture', 'h1'], ['/my/profile', 'h1'], ['/projects/ecaq/faith-promise', 'h1'], ['/ministries', 'h1']],
    leader: [['/', 'h1'], ['/cell-groups', 'h1'], ['/visitors', 'h1'], ['/search?q=Anna', 'h1']]
  };
  for (const [who, list] of Object.entries(pages)) {
    for (const width of WIDTHS) {
      const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookiesOf(clients[who]));
      const page = await context.newPage(); const consoleErrors = [];
      page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); }); page.on('pageerror', (e) => consoleErrors.push(e.message));
      for (const [url, selector] of list) {
        const response = await page.goto(portal.base + url, { waitUntil: 'load' });
        const m = await page.evaluate((sel) => ({ overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, error: /Something went wrong/.test(document.body.innerText), key: Boolean(document.querySelector(sel)) }), selector);
        const tag = `${who} ${width}px ${url}`;
        if (response.status() !== 200) problems.push(`${tag}: status ${response.status()}`);
        if (m.error) problems.push(`${tag}: error page`);
        if (m.overflow > 0) problems.push(`${tag}: sideways scroll ${m.overflow}px`);
        if (!m.key) problems.push(`${tag}: "${selector}" not found`);
      }
      if (consoleErrors.length) problems.push(`${who} ${width}px: ${consoleErrors.slice(0, 2).join(' / ')}`);
      await context.close();
    }
  }
  // the Kiosk: a phone-number result, at every width
  for (const width of WIDTHS) {
    const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookiesOf(clients.kiosk));
    const page = await context.newPage(); await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    await page.fill('#checkin-search-input', '+97477017992');
    await Promise.all([page.waitForLoadState('load'), page.locator('.kiosk__search-form button[type=submit]').click()]);
    await page.getByText('Phoneone Sweep').first().waitFor();
    const m = await page.evaluate(() => ({ overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, both: /Phoneone/.test(document.body.innerText) && /Phonetwo/.test(document.body.innerText), masked: /•••• 7992/.test(document.body.innerText), leaked: /77017992/.test(document.body.innerText) }));
    if (m.overflow > 0) problems.push(`kiosk ${width}px: sideways scroll ${m.overflow}px`);
    if (!m.both) problems.push(`kiosk ${width}px: the shared number did not show both people`);
    if (!m.masked) problems.push(`kiosk ${width}px: no masked tail`);
    if (m.leaked) problems.push(`kiosk ${width}px: the number is on the page`);
    await context.close();
  }
  assert.deepEqual(problems, [], problems.slice(0, 20).join('\n'));
  console.log(`PASS (sweep) ${Object.values(pages).reduce((n, l) => n + l.length, 0)} screens as Church Admin, Member and leader, plus the Kiosk phone result, at ${WIDTHS.join(', ')} px: they render, nothing scrolls sideways, no console errors`);

  // ---- each role sees only its own pages ----------------------------------------------------------------------------------------------------------------------------------------------
  const refusal = async (who, url) => { const r = await clients[who].get(url); await r.text(); return r.status === 403 || (r.status === 302 && !/\/admin|\/visitors|\/reports/.test(r.headers.get('location') || '')) || r.status === 404; };
  for (const url of ['/visitors', '/visitors/reviews', '/reports', '/reports/occasions/pdf', '/admin/ecaq/faith-promise', '/admin/ecaq/payments', '/members']) assert.ok(await refusal('member', url), `a Member is refused ${url}`);
  for (const url of ['/', '/visitors', '/reports/occasions/pdf', '/admin/ecaq/faith-promise', '/members', '/search?q=a', '/cell-groups']) assert.ok(await refusal('kiosk', url), `the Kiosk is refused ${url}`);
  for (const url of ['/visitors/reviews', '/reports/occasions/pdf', '/admin/ecaq/faith-promise']) assert.ok(await refusal('leader', url), `a Cell Group leader is refused ${url}`);
  console.log('PASS (roles) a Member, a Cell Group leader and the Kiosk are refused the administrative screens by address');
  console.log('PASS responsive-sweep-overnight');
} finally {
  await browser.close();
  await portal.stop();
}
