import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as tar from 'tar';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * A backup archive is a file an administrator can upload to the backups folder and then verify or restore. A hostile or damaged one
 * must never write outside the scratch folder it is unpacked into (path traversal, absolute paths, symlink tricks), must never be
 * mistaken for a good backup, and must never leave its scratch folder behind. Also: the checksum is streamed, so a large archive
 * does not have to fit in memory. Read-only with respect to everything real; all archives are built here.
 */

createIsolatedTestEnv('cciq-backup-hostile-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createBackup, deepVerifyBackup, verifyBackup, resolveBackupFile } = await import('../services/backups.js');
const config = (await import('../config/env.js')).default;

const scratchBefore = new Set(fs.readdirSync(os.tmpdir()).filter((n) => n.startsWith('cciq-backup-verify-')));
const sentinel = path.join(os.tmpdir(), `cciq-outside-sentinel-${process.pid}.txt`);
const deeper = path.join(os.tmpdir(), '..', `cciq-outside-sentinel2-${process.pid}.txt`);
const absolute = path.join(os.tmpdir(), `cciq-absolute-sentinel-${process.pid}.txt`);
for (const p of [sentinel, deeper, absolute]) fs.rmSync(p, { force: true });

const good = await createBackup({ kind: 'manual', note: 'hostile fixture base' });
assert.ok(good.ok);
const goodFile = resolveBackupFile(good.backup.filename);

async function craft(name, build) {
  const stage = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-craft-'));
  try {
    const inner = path.join(stage, 'inner');
    fs.mkdirSync(inner, { recursive: true });
    const { entries, options = {} } = await build({ stage, inner });
    const file = path.join(config.backupDir, name);
    await tar.create({ gzip: true, file, cwd: inner, ...options }, entries);
    return { filename: name };
  } finally { fs.rmSync(stage, { recursive: true, force: true }); }
}

// 1. '../' entries
const traversal = await craft('hostile-traversal.tar.gz', async ({ stage, inner }) => {
  fs.writeFileSync(path.join(stage, path.basename(sentinel)), 'pwned');
  fs.writeFileSync(path.join(stage, '..', path.basename(deeper)), 'pwned2');
  fs.writeFileSync(path.join(inner, 'manifest.json'), JSON.stringify({ format: 'cciq-portal-archive', version: 1, database: 'database.sqlite', storage_folders: [] }));
  return { entries: ['manifest.json', `../${path.basename(sentinel)}`, `../../${path.basename(deeper)}`], options: { preservePaths: true } };
});
fs.rmSync(path.join(os.tmpdir(), '..', path.basename(deeper)), { force: true }); // the craft helper's own helper file, not an extraction result
fs.rmSync(sentinel, { force: true });
const r1 = await deepVerifyBackup(traversal);
assert.equal(r1.ok, false, 'an archive with ../ entries and no database is not a good backup');
assert.ok(!fs.existsSync(sentinel), 'a ../ entry was not written into the temp folder above the scratch folder');
assert.ok(!fs.existsSync(deeper), 'nor two levels above');

// 2. absolute path entry
const abs = await craft('hostile-absolute.tar.gz', async ({ inner }) => {
  fs.writeFileSync(path.join(inner, 'manifest.json'), '{}');
  fs.writeFileSync(absolute, 'pwned');
  return { entries: ['manifest.json', absolute], options: { preservePaths: true } };
});
fs.rmSync(absolute, { force: true });
const r2 = await deepVerifyBackup(abs);
assert.equal(r2.ok, false);
assert.ok(!fs.existsSync(absolute), 'an absolute-path entry was not written where it claims');

// 3. symlink that points outside, then a file written "through" it
const link = await craft('hostile-symlink.tar.gz', async ({ inner }) => {
  fs.mkdirSync(path.join(inner, 'storage'), { recursive: true });
  try { fs.symlinkSync(os.tmpdir(), path.join(inner, 'storage', 'escape'), 'junction'); } catch { /* symlinks may need privileges; the test then only proves the archive is refused */ }
  fs.writeFileSync(path.join(inner, 'manifest.json'), JSON.stringify({ format: 'cciq-portal-archive', version: 1, database: 'database.sqlite', storage_folders: ['escape'] }));
  return { entries: ['manifest.json', 'storage'] };
});
const r3 = await deepVerifyBackup(link);
assert.equal(r3.ok, false, 'an archive with no database is not a good backup even if it unpacks');
assert.ok(!fs.existsSync(path.join(os.tmpdir(), 'pwn.txt')));

// 4. empty, truncated, not-gzip, manifest that lies
fs.writeFileSync(path.join(config.backupDir, 'hostile-empty.tar.gz'), '');
fs.writeFileSync(path.join(config.backupDir, 'hostile-text.tar.gz'), 'this is not an archive');
const cut = fs.readFileSync(goodFile).subarray(0, 200);
fs.writeFileSync(path.join(config.backupDir, 'hostile-cut.tar.gz'), cut);
for (const name of ['hostile-empty.tar.gz', 'hostile-text.tar.gz', 'hostile-cut.tar.gz']) {
  const r = await deepVerifyBackup({ filename: name });
  assert.equal(r.ok, false, `${name} is refused`);
  assert.equal(typeof r.reason, 'string');
}

// 5. names that try to leave the backup folder
for (const name of ['../x.tar.gz', '..\\x.tar.gz', 'sub/x.tar.gz', '/etc/passwd', 'C:\\Windows\\win.ini', '', null, undefined, 42]) {
  assert.equal(resolveBackupFile(name), null, `resolveBackupFile refuses ${JSON.stringify(name)}`);
}
assert.equal(verifyBackup({ filename: '../../etc/passwd', checksum: 'x' }).ok, false);

// 5b. two restores at once: the second is refused untouched, and the guard resets afterwards
const { restoreBackup } = await import('../services/backups.js');
const { default: db } = await import('../db/index.js');
const second = await createBackup({ kind: 'manual', note: 'concurrency fixture' });
db.prepare("UPDATE backups SET checksum = 'deadbeef' WHERE id = ?").run(second.backup.id); // fails verification quickly, without touching anything
const first = restoreBackup(second.backup.id);
const racer = restoreBackup(second.backup.id);
const [r1b, r2b] = await Promise.all([first, racer]);
assert.equal(r2b.reason, 'restore_in_progress', 'a second restore started while one is running is refused');
assert.equal(r1b.reason, 'checksum_mismatch', 'the first restore is unaffected');
assert.equal((await restoreBackup(second.backup.id)).reason, 'checksum_mismatch', 'and once it has finished the next one is allowed to start');

// 6. nothing left behind
const scratchAfter = fs.readdirSync(os.tmpdir()).filter((n) => n.startsWith('cciq-backup-verify-') && !scratchBefore.has(n));
assert.deepEqual(scratchAfter, [], 'verification leaves no scratch folder behind on any path');
assert.deepEqual(fs.readdirSync(config.backupDir).filter((n) => n.startsWith('.restore-extract')), [], 'and no restore extraction folder');

// 7. the checksum is streamed and correct
const big = path.join(config.backupDir, 'big-file-for-checksum.bin');
const chunk = Buffer.alloc(1024 * 1024, 7);
const fd = fs.openSync(big, 'w');
for (let i = 0; i < 40; i += 1) fs.writeSync(fd, chunk); // 40 MB
fs.closeSync(fd);
const { createHash } = await import('node:crypto');
const expected = createHash('sha256');
for (let i = 0; i < 40; i += 1) expected.update(chunk);
const digest = expected.digest('hex');
const before = process.memoryUsage().rss;
const verified = verifyBackup({ filename: 'big-file-for-checksum.bin', checksum: digest });
const growth = process.memoryUsage().rss - before;
assert.equal(verified.ok, true, 'the streamed checksum of a 40 MB file matches');
assert.ok(growth < 35 * 1024 * 1024, `verifying 40 MB does not load it all into memory (rss grew ${(growth / 1048576).toFixed(1)} MB)`);
fs.rmSync(big, { force: true });

console.log('PASS (hostile archives) ../, absolute and symlink entries write nothing outside their scratch folder; empty/truncated/non-archive files are refused; backup names cannot leave the folder; no scratch folder survives; the checksum streams');
console.log('ALL PASS');
