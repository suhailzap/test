import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';
import { DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions.js';

/*
 * A systematic authorization attack, generated from the route catalogue rather than from a list somebody remembered. Every route that takes
 * an object id is requested, as every kind of signed-in person, with:
 *   - every real object of the matching kind in the fixture (own, another group's, another person's), and
 *   - ids that are wrong in every way (0, negative, huge, non-numeric, exponent, decimal, repeated, array, NUL, over-long),
 * by GET and, for people the route's own guard refuses, by POST as well (with forged hidden fields).
 * Checked: no server error anywhere; no response to a refused person carries another person's private data; a refused POST changes nothing
 * (every table is compared before and after); error pages carry no stack trace, SQL or file path.
 * What a person IS allowed to see by current policy is not a finding (the Leader / ministry-phone visibility questions are the owner's);
 * every other private-field leak or unguarded write is.
 */

const f = await buildPortalFixture('cciq-idor-redteam-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
// give every kind of object a second instance, so "another one" always exists
const visitor2 = mods.visitors.createVisitor({ first_name: 'Other', last_name: 'Visitor', phone: '+974 5559 0002', email: 'other.visitor@fixture.invalid', notes: 'private visitor note', first_visit_date: today }, { userId: users.churchAdmin.id });
const portal = await startPortal();
const PERMS = (user) => new Set(user.roleKeys.flatMap((r) => DEFAULT_ROLE_PERMISSIONS[r] || []));
const guardAllows = (user, route) => {
  const held = PERMS(user);
  if (route.roles.length && !route.roles.some((r) => user.roleKeys.includes(r))) return false;
  if (route.all.length && !route.all.every((p) => held.has(p))) return false;
  if (route.any.length && !route.any.some((p) => held.has(p))) return false;
  return true;
};

// which ids each route family takes
const kinds = {
  member: Object.values(ids.member),
  group: [ids.groupA, ids.groupB],
  ministry: [ids.ministry],
  visitor: [ids.visitor, visitor2.id],
  document: [ids.document],
  session: [ids.session, ids.meeting],
  activity: [ids.activity, ids.draftActivity],
  announcement: [ids.announcement, ids.leadersOnly],
  user: Object.values(users).map((u) => u.id),
  family: [ids.family],
  campaign: [ids.board, ids.promise],
  claim: [ids.claim],
  commitment: [ids.commitment],
  reminder: [ids.reminder],
  notification: Object.values(ids.notifications)
};
const kindOf = (p) => {
  if (/^\/(media\/members|members)\//.test(p)) return 'member';
  if (/^\/(cell-groups|attendance\/cell-groups|about\/cell-groups|media\/groups)\//.test(p)) return 'group';
  if (/^\/(ministries|about\/ministries|media\/ministries)\//.test(p)) return 'ministry';
  if (/^\/visitors\//.test(p)) return 'visitor';
  if (/^\/documents\/\d|^\/documents\/:id/.test(p)) return 'document';
  if (/^\/attendance\/sessions\//.test(p)) return 'session';
  if (/^\/(activities|media\/activity)\//.test(p)) return 'activity';
  if (/^\/announcements\//.test(p)) return 'announcement';
  if (/^\/admin\/users\//.test(p)) return 'user';
  if (/^\/family-groups\//.test(p)) return 'family';
  if (/^\/admin\/ecaq\/campaigns\/|^\/media\/ecaq\//.test(p)) return 'campaign';
  if (/^\/admin\/ecaq\/claims\//.test(p)) return 'claim';
  if (/^\/admin\/ecaq\/faith-promise\/commitments\//.test(p)) return 'commitment';
  if (/^\/reminders\//.test(p)) return 'reminder';
  if (/^\/notifications\//.test(p)) return 'notification';
  return null;
};
const BAD_IDS = ['0', '-1', '99999999', '99999999999999999999', 'abc', '1e3', '1.5', '%00', '1%2C2', '1;2', '9'.repeat(400), '١٢'];

// private data that only some people may see (phones are excluded: who may see a ministry or group phone is an owner decision)
const PRIVATE = {
  a1: ['alice@fixture.invalid', 'private note a1', '1 Alpha Street', '1985-03-04'],
  a2: ['anna@fixture.invalid', '2 Alpha Street', '1990-05-06'],
  b1: ['bella@fixture.invalid', 'private note b1', '3 Beta Street', '1992-07-08'],
  visitor2: ['other.visitor@fixture.invalid', 'private visitor note'],
  visitor1: ['vera@fixture.invalid']
};
// Cell Group Leader A leads group A (a1, a2, a3); Leader B leads group B (b1, b2). A Leader is also allowed every First Timer's details by the
// CURRENT policy (members.view opens /visitors): whether that should change is the owner's decision (category C), recorded as evidence below.
const ownMarkers = (key) => ({ superAdmin: Object.keys(PRIVATE), churchAdmin: Object.keys(PRIVATE), leaderA: ['a1', 'a2', 'visitor1', 'visitor2'], leaderB: ['b1', 'visitor1', 'visitor2'], memberA: ['a2'], memberB: ['b1'], kiosk: [] }[key]);
const SECRETS = /(\bat [A-Za-z]:\\|node_modules|\.js:\d+:\d+|SQLITE_|SqliteError|stack trace|password_hash|\$2[aby]\$)/;

const tableNames = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").all().map((r) => r.name).filter((n) => !['sessions', 'audit_logs', 'rate_limits', 'login_attempts'].includes(n));
const snapshot = () => JSON.stringify(tableNames.map((t) => [t, db.prepare(`SELECT * FROM ${t}`).all()]));

const findings = []; let requests = 0; let refusedPosts = 0; let leakChecks = 0;
const note = (m) => findings.push(m);
const requestSignal = () => AbortSignal.timeout(15_000);

try {
  const cast = Object.entries(users).map(([key, user]) => ({ key, user }));
  for (const c of cast) c.session = await signIn(portal.base, c.user.email, f.PASSWORD);
  const routes = catalogue().filter((r) => /:/.test(r.path) && !/\/:token|\/:key/.test(r.path) && kindOf(r.path));
  console.log(`INFO starting ${routes.length} object routes; each request has a 15s diagnostic timeout`);

  for (const [routeIndex, route] of routes.entries()) {
    console.log(`INFO route ${routeIndex + 1}/${routes.length}: ${route.method} ${route.path}`);
    const kind = kindOf(route.path);
    const realIds = kinds[kind].map(String);
    const allIds = [...realIds, ...BAD_IDS];
    for (const { key, user, session } of cast) {
      if (key === 'superAdmin' && route.method !== 'GET') continue; // never fire destructive writes as the all-powerful account
      const allowedByGuard = guardAllows(user, route);
      for (const id of allIds) {
        const memberIdVariant = route.path.includes(':memberId') ? realIds[0] : null;
        const path = route.path.replace(/:id\([^)]*\)|:id\b/, id).replace(/:memberId\([^)]*\)|:memberId\b/, memberIdVariant ?? '1');
        // repeated and array forms of the id in the query string as well
        const queries = realIds.includes(id) ? ['', `?id=${id}&id=${realIds[0]}`, `?id[]=${id}`] : [''];
        for (const q of queries) {
          requests += 1;
          let res;
          if (route.method === 'GET') {
            if (/\/(download|file|card\.png|pdf)$/.test(path) && key === 'superAdmin') continue;
            res = await session.get(`${path}${q}`, { signal: requestSignal() });
          } else {
            if (allowedByGuard) continue; // a permitted person's legitimate write is exercised by the workflow suites; here only the REFUSED are attacked
            const before = snapshot();
            res = await session.post(`${path}${q}`, { name: 'Hacked', first_name: 'Hacked', status: 'archived', role: 'super_admin', roles: 'super_admin', member_id: String(ids.member.a1), cell_group_id: String(ids.groupB), confirm: 'yes', reason: 'x', title: 'Hacked', body: 'Hacked' }, { csrfFrom: '/my/profile', signal: requestSignal() });
            refusedPosts += 1;
            const after = snapshot();
            if (before !== after) note(`${key} POST ${path}${q} was refused by its guard but changed data (HTTP ${res.status})`);
          }
          const text = res.status === 200 || res.status >= 400 ? await res.text() : (await res.arrayBuffer(), '');
          if (res.status >= 500) note(`${key} ${route.method} ${path}${q} -> ${res.status} (server error)`);
          if (res.status >= 400 && SECRETS.test(text)) note(`${key} ${route.method} ${path}${q} -> ${res.status} with internal detail in the page`);
          // a refused person must not be shown anything private about people outside their scope
          if (res.status === 200 && !allowedByGuard && route.method === 'GET' && !/image\//.test(res.headers.get('content-type') || '')) {
            note(`${key} GET ${path}${q} -> 200 although the route's guard refuses this role`);
          }
          if (res.status === 200 && /text\/html/.test(res.headers.get('content-type') || '')) {
            leakChecks += 1;
            const mine = new Set(ownMarkers(key));
            for (const [who, markers] of Object.entries(PRIVATE)) {
              if (mine.has(who)) continue;
              if (key === 'superAdmin' || key === 'churchAdmin') continue;
              for (const m of markers) if (text.includes(m)) note(`${key} GET ${path}${q} shows ${who}'s private "${m}"`);
            }
          }
        }
      }
    }
  }
  // unauthenticated: every one of those routes asks for sign-in, never data
  for (const route of routes.filter((r) => r.method === 'GET').slice(0, 80)) {
    const path = route.path.replace(/:id\([^)]*\)|:id\b/, String(kinds[kindOf(route.path)][0])).replace(/:memberId\([^)]*\)|:memberId\b/, '1');
    const res = await fetch(`${portal.base}${path}`, { redirect: 'manual', signal: requestSignal() }); await res.arrayBuffer();
    if (![302, 401, 403].includes(res.status) && !/^\/(media|about)\//.test(path)) note(`unauthenticated GET ${path} -> ${res.status}`);
  }
  console.log('INFO owner decision (category C, current policy allows it): a Cell Group Leader can open every First Timer, including email and notes, because /visitors needs only members.view. Not changed here.');
  console.log(`INFO ${routes.length} object routes, ${requests} requests, ${refusedPosts} refused writes compared table-by-table, ${leakChecks} pages searched for another person's private data`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
if (findings.length) console.log('FINDINGS\n' + [...new Set(findings)].slice(0, 60).join('\n'));
assert.deepEqual([...new Set(findings)], [], 'no authorization finding');
console.log('PASS (rbac-idor) every object route, every role, every real and malformed id: no server error, no private data for the wrong person, refused writes change nothing, no internal detail in errors');
console.log('ALL PASS');
