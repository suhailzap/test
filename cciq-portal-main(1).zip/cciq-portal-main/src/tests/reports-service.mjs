import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

const env = createIsolatedTestEnv('cciq-reports-test-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const { recordAttendance } = await import('../services/attendance.js');
const { fridayAttendanceOverview, membershipOverview, cellGroupsOverview } = await import('../services/reports.js');
const { execute, db } = await import('../db/index.js');

function makeFridaySession(date) {
  const result = execute(
    `INSERT INTO attendance_sessions
       (service_date, service_type, title, status, counts_toward_followup, created_at)
     VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, @date)`,
    { date }
  );
  return Number(result.lastInsertRowid);
}

// --- Fixture: two cell groups, members split across them, on-roster and
// off-roster statuses, a Temporarily Away member (excluded from roster), and
// an unassigned member. ---
const groupA = createGroup({ name: 'Group A' });
const groupB = createGroup({ name: 'Group B' });

const a1 = createMember({ first_name: 'A1', last_name: 'Member', cell_group_id: groupA.id }, { status: 'active' });
const a2 = createMember({ first_name: 'A2', last_name: 'Member', cell_group_id: groupA.id }, { status: 'active' });
const b1 = createMember({ first_name: 'B1', last_name: 'Member', cell_group_id: groupB.id }, { status: 'active' });
createMember({ first_name: 'Away', last_name: 'Member', cell_group_id: groupA.id }, { status: 'temporarily_away' });
// Current population (temporarily_away) but off the Friday roster and
// unassigned to any group — exercises membershipOverview()'s unassigned
// count without perturbing fridayAttendanceOverview()'s roster size above.
createMember({ first_name: 'Unassigned', last_name: 'Member' }, { status: 'temporarily_away' });
createMember({ first_name: 'Inactive', last_name: 'Member' }, { status: 'inactive' });

const session1 = makeFridaySession('2026-01-02');
const session2 = makeFridaySession('2026-01-09');

// Session 1: a1 present, a2 excused, b1 present.
recordAttendance(session1, [
  { memberId: a1.id, status: 'present' },
  { memberId: a2.id, status: 'excused' },
  { memberId: b1.id, status: 'present' }
]);
// Session 2: a1 present, a2 present, b1 absent.
recordAttendance(session2, [
  { memberId: a1.id, status: 'present' },
  { memberId: a2.id, status: 'present' },
  { memberId: b1.id, status: 'absent' }
]);

// --- Phase 2C: the two Fridays are tracked and FINALIZED, so the overview speaks the
//     canonical model (historical expected snapshot + outcomes). Before a tracking
//     start date a Friday is "not tracked" and yields no rate at all - covered in
//     tests/attendance-outcomes-consumers.mjs. ---
{
  const { setSetting } = await import('../lib/settings.js');
  const { finalizeAttendance } = await import('../services/attendance-lifecycle.js');
  for (const m of db.prepare('SELECT id, status FROM members').all()) {
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run('2025-01-01T09:00:00.000Z', m.id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)')
      .run(m.id, m.status, 'planted', '2025-01-01T09:00:00.000Z');
  }
  setSetting('attendance.tracking_start_date', '2026-01-02');
  for (const id of [session1, session2]) {
    const result = finalizeAttendance(id, { userId: null });
    assert.equal(result.ok, true, `fixture Friday ${id} finalizes: ${result.reason}`);
  }
}

// --- fridayAttendanceOverview(): weighted rate, not a naive average of the two
// sessions' own percentages. Roster size is 3 (a1, a2, b1; Away is excluded).
// Session 1: present=2, excused=1 -> denominator 3-1=2, rate 100%.
// Session 2: present=2, excused=0 -> denominator 3, rate 67%.
// Weighted: totalPresent=4, weightedDenominator = 2*3 - 1 = 5 -> 80%.
// A naive average of 100% and 67% would be 83%/84%, which must NOT be what
// this returns. ---
const overview = fridayAttendanceOverview({ from: '2026-01-01', to: '2026-01-31' });
assert.equal(overview.rosterSize, 3, 'roster size must exclude the Temporarily Away member');
assert.equal(overview.sessions.length, 2);
assert.equal(overview.totalPresent, 4);
assert.equal(overview.totalExcused, 1);
assert.equal(overview.rate, 80, `weighted aggregate rate must be 80, got ${overview.rate}`);
assert.notEqual(overview.rate, 83, 'must not equal a naive average of per-session percentages');
console.log('PASS: fridayAttendanceOverview() computes a weighted aggregate rate across sessions, not a naive average');

const overviewGroupA = fridayAttendanceOverview({ from: '2026-01-01', to: '2026-01-31', cellGroupId: groupA.id });
assert.equal(overviewGroupA.rosterSize, 2, 'cell-group filter must scope the roster to that group only');
console.log('PASS: fridayAttendanceOverview() applies the cellGroupId filter to roster size and totals');

// --- membershipOverview(): current vs total, and scope enforcement for the
// unassigned-members count. ---
const allScope = { type: 'all' };
const overviewAll = membershipOverview(allScope);
assert.equal(overviewAll.total, 6, 'total must include every member regardless of status');
assert.equal(overviewAll.current, 5, 'current population excludes inactive but includes temporarily_away');
assert.equal(overviewAll.unassigned, 1, 'unassigned must count only the current-population member with no cell group');

const groupAScope = { type: 'cell_group', cellGroupIds: [groupA.id] };
const overviewScoped = membershipOverview(groupAScope);
assert.equal(overviewScoped.unassigned, 0,
  'a cell_group_leader scoped to Group A must not see the portal-wide unassigned-members count');
console.log('PASS: membershipOverview() scopes the unassigned-members count by RBAC scope, not just status/current counts');

// --- cellGroupsOverview(): scope restricts which groups appear at all, and
// no ranking/sorting by attendance rate is applied. ---
const allGroups = cellGroupsOverview({ scope: allScope });
assert.equal(allGroups.length, 2, 'an unscoped caller sees every active cell group');

const scopedGroups = cellGroupsOverview({ scope: groupAScope });
assert.equal(scopedGroups.length, 1, 'a cell_group_leader scoped to Group A must only see Group A');
assert.equal(scopedGroups[0].id, groupA.id);
console.log('PASS: cellGroupsOverview() restricts visible groups to the caller\'s scope');

const noneGroups = cellGroupsOverview({ scope: { type: 'none' } });
assert.equal(noneGroups.length, 0, 'a caller with no scope must see no cell-group report rows');
console.log('PASS: cellGroupsOverview() returns nothing for a caller with scope type none');

db.close();
env.cleanup();
console.log('ALL PASS');
