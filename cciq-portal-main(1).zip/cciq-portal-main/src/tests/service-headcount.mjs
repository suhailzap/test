import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';
import { startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * "How many people were at church this Friday?" - one definition (src/services/service-headcount.js) shared by every screen, report and export.
 *
 * Found in physical validation: First Timer Sample Visitor had a visit for Friday 25 September, yet Attendance history showed Present 0 / Recorded 0 for it. Causes:
 *   1. the history query counted attendance MARKS only and never looked at visits;
 *   2. a visit recorded by hand carries a date but no service, so a count by service never saw it;
 *   3. a Friday before tracking started (or with no tracking start) had no headcount at all, only a tracked Friday did;
 *   4. a First Timer who later became a member silently left every past headcount.
 *
 * Rules pinned here (A to L of the correction brief, plus the Sample Visitor case):
 *   A  an expected member Present adds exactly one to the headcount
 *   B  a First Timer visit adds exactly one and leaves the expected count and the rate's denominator alone
 *   C  the same First Timer recorded twice for the same service still counts once
 *   D  converted to a NEW member later: the service still counts that person once
 *   E  linked to an EXISTING member: once - and a member who has their own Present row AND a First Timer record for the same service is the same human, counted once
 *   F  a member's status changing later does not move a past headcount
 *   G  cancelled and Attendance Not Taken services stay what they are however many visits exist; a Friday before tracking is never converted into a tracked one
 *   H  open (awaiting) and finalized Fridays keep their semantics; finalizing changes no headcount
 *   I  Express Registration and a normal check-in of an existing First Timer give the same headcount result
 *   J  a visit recorded by hand (date only) gives the same result as one tied to the service
 *   K  history, Friday list, register, dashboard-style summary, Reports, CSV, the member report and the desk's live count all agree
 *   L  loading every page again and again changes nothing and returns the same numbers
 */

createIsolatedTestEnv('cciq-service-headcount-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember, changeStatus } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const visitors = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const { registerFirstTimerAtDesk } = await import('../services/express-registration.js');
const { checkedInState } = await import('../services/qr-checkin.js');
const { serviceHeadcount, serviceHeadcounts } = await import('../services/service-headcount.js');
const { attendanceReport } = await import('../services/attendance-consumers.js');
const { fridayAttendanceOverview } = await import('../services/reports.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const L = lastFridayOnOrBefore(today()); // the Friday the desk is working on
const X = addDays(L, -28); // tracked, will be finalized
const N = addDays(L, -21); // Attendance Not Taken
const C = addDays(L, -14); // cancelled
const O = addDays(L, -7); // past, awaiting finalization
const P = addDays(L, -56); // before tracking: the Sample Visitor case
const OLD = addDays(X, -400);
const noon = (d) => `${d}T09:00:00.000Z`;
const count = (sql, ...p) => db.prepare(sql).get(...p).n;

function expectedMember(name) {
  const m = createMember({ first_name: name, last_name: 'Hc' }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(noon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', noon(OLD));
  return m;
}
const session = (date, status = 'held') => {
  db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', ?, 1, 0, ?)").run(date, status, noon(date));
  return db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(date);
};
const mark = (sessionId, memberId, status = 'present') => db.prepare("INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, ?, ?, 'manual')").run(sessionId, memberId, status, noon(today()));
const hc = (s) => serviceHeadcount(s.id);
const sum = (s) => attendance.sessionSummary(s.id);

const m = ['One', 'Two', 'Three', 'Four'].map(expectedMember);
setSetting('attendance.tracking_start_date', X);
const sP = session(P); const sX = session(X); const sN = session(N); const sC = session(C); const sO = session(O); const sL = session(L);
await createUser({ username: 'hc_admin', email: 'hc.admin@fixture.invalid', password: 'Hc-Fixture-Passw0rd!x', displayName: 'HC Admin', roleKeys: ['super_admin'], mustChangePassword: false });

// ---- the Sample Visitor case: a First Timer with a visit for a Friday before tracking, no member record, no attendance row ---------------------------------------
{
  const isaiah = visitors.createVisitor({ first_name: 'Sample Visitor', last_name: 'Example', first_visit_date: P }, { userId: null }); // by hand: a date, no service
  assert.equal(db.prepare('SELECT session_id FROM visitor_visits WHERE visitor_id = ?').get(isaiah.id).session_id, null, 'the visit names a date, not a service (as the form records it)');
  assert.equal(isaiah.member_id ?? null, null);
  assert.deepEqual({ members: hc(sP).members, firstTimers: hc(sP).firstTimers, total: hc(sP).total }, { members: 0, firstTimers: 1, total: 1 }, 'ISAIAH: the Friday counts him');
  const s = sum(sP);
  assert.equal(s.phase, 'pre_go_live', 'and it is still a Friday from before tracking, not a tracked one');
  assert.equal(s.tracked, null);
  assert.equal(s.recorded, 0, 'no attendance mark was manufactured for him');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?', sP.id), 0);
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', sP.id), 0, 'and nothing was snapshotted');
  assert.equal(s.figures.total, 1);
  const row = attendance.listSessions({ serviceType: 'friday_service', to: P, from: P }).rows[0];
  assert.deepEqual([row.members_present, row.first_timers, row.total_present, row.recorded], [0, 1, 1, 0], 'history: members 0, First Timers 1, total 1, marks recorded 0');
  // the same person tied to the service by name instead of by date: the same answer
  const lebron = visitors.createVisitor({ first_name: 'Lebron', last_name: 'James', first_visit_date: P, session_id: sP.id }, { userId: null });
  assert.equal(hc(sP).total, 2);
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', lebron.id), 1);
  console.log('PASS (isaiah) a First Timer with a date-only visit for a Friday before tracking is counted (members 0, First Timers 1, total 1), the Friday stays "before tracking", no attendance mark or roster is created; a visit tied to the service gives the same answer');
}

// ---- A, B, C on an open (awaiting finalization) Friday ----------------------------------------------------------------------------------------------------
const base = sum(sX);
assert.equal(base.tracked.expected, 4, 'four expected members');
assert.equal(hc(sX).total, 0);
{
  mark(sX.id, m[0].id);
  assert.equal(hc(sX).total, 1, 'A: an expected member Present = +1');
  assert.equal(sum(sX).tracked.present, 1);

  const v = visitors.createVisitor({ first_name: 'Guest', last_name: 'One', first_visit_date: X, session_id: sX.id }, { userId: null });
  const afterB = sum(sX);
  assert.equal(hc(sX).total, 2, 'B: a First Timer visit tied to the service = +1');
  assert.equal(afterB.tracked.expected, 4, 'B: the expected count is unchanged');
  assert.equal(afterB.tracked.rateDenominator, base.tracked.rateDenominator, 'B: so is the rate denominator');
  assert.equal(afterB.tracked.present, 1, 'B: expected-member Present is unchanged');
  assert.equal(afterB.tracked.headcount, 2);

  const again = visitors.recordVisit(v.id, { date: X, sessionId: sX.id });
  assert.equal(again.ok, false, 'C: a second visit for the same service is refused');
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', v.id), 1);
  assert.equal(hc(sX).total, 2, 'C: still +1');
  const byDateToo = visitors.recordVisit(v.id, { date: X });
  assert.equal(byDateToo.ok, false);
  assert.equal(hc(sX).total, 2, 'C: and the same visit entered by date alone adds nothing');
  console.log('PASS (A,B,C) a Present member +1; a First Timer +1 with the expected count, the denominator and expected Present unchanged; the same First Timer twice still +1');
}

// ---- J on the open Friday: date-only visit equals a tied visit; I on the live Friday ----------------------------------------------------------------------
{
  const before = hc(sX).total;
  const hand = visitors.createVisitor({ first_name: 'Hand', last_name: 'Recorded', first_visit_date: X }, { userId: null });
  assert.equal(db.prepare('SELECT session_id FROM visitor_visits WHERE visitor_id = ?').get(hand.id).session_id, null);
  assert.equal(hc(sX).total, before + 1, 'J: a visit recorded by hand (date only) = +1, the same as a tied one');
  assert.equal(sum(sX).tracked.firstTimeVisitors, 2);
  console.log('PASS (J) a visit recorded by hand with only a date is counted exactly like a visit tied to the service');
}
{
  const start = hc(sL).total;
  const express = registerFirstTimerAtDesk({ first_name: 'Express', last_name: 'Person', phone: '+974 5550 4001' }, { userId: null });
  assert.equal(express.ok, true, JSON.stringify(express));
  assert.equal(hc(sL).total, start + 1, 'I: Express Registration = +1');
  assert.equal(checkedInState().count, hc(sL).total, 'I: and the desk\'s live count says the same');
  const existing = visitors.createVisitor({ first_name: 'Normal', last_name: 'Checkin', phone: '+974 5550 4002', first_visit_date: addDays(L, -70) }, { userId: null });
  const checked = attendance.recordAttendanceForPeople(sL.id, [{ type: 'visitor', id: existing.id }], { userId: null });
  assert.equal(checked.ok, true);
  assert.equal(hc(sL).total, start + 2, 'I: a normal check-in of an existing First Timer = +1, the same as Express');
  assert.equal(attendance.recordAttendanceForPeople(sL.id, [{ type: 'visitor', id: existing.id }], { userId: null }).already.length, 1);
  assert.equal(hc(sL).total, start + 2, 'I: and checking the same person in twice changes nothing');
  assert.equal(checkedInState().count, hc(sL).total);
  assert.equal(sum(sL).tracked.expected, sum(sL).tracked.expected);
  console.log('PASS (I) Express Registration and a normal check-in each add exactly one; a repeat adds none; the desk\'s live count equals the Friday\'s headcount');
}

// ---- finalize X, then D, E, F, H ------------------------------------------------------------------------------------------------------------------------------
const second = visitors.createVisitor({ first_name: 'Guest', last_name: 'Two', first_visit_date: X, session_id: sX.id }, { userId: null });
mark(sX.id, m[1].id);
const totalBeforeFinalize = hc(sX).total;
const guestOne = db.prepare("SELECT id FROM visitors WHERE first_name = 'Guest' AND last_name = 'One'").get();
{
  const preFinal = sum(sX);
  assert.equal(preFinal.phase, 'awaiting_finalization', 'H: a past Friday not yet finalized is awaiting finalization');
  assert.equal(preFinal.tracked.final, false);
  assert.equal(preFinal.tracked.rate, null, 'H: no rate while open');
  const fin = lifecycle.finalizeAttendance(sX.id, { userId: null });
  assert.equal(fin.ok, true);
  const post = sum(sX);
  assert.equal(post.phase, 'finalized');
  assert.equal(hc(sX).total, totalBeforeFinalize, 'H: finalizing changes no headcount');
  assert.equal(post.tracked.headcount, totalBeforeFinalize);
  assert.equal(post.tracked.absent, 2, 'H: derived absence appears only once finalized (m3 and m4 were expected, with no record)');
  assert.equal(post.tracked.rate, Math.round((2 / 4) * 100), 'H: the rate is members only: 2 of 4 expected, the First Timers are not in it');
  assert.equal(JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.finalized' ORDER BY id DESC LIMIT 1").get().detail).first_time_visitors, 3);
  console.log('PASS (H) open: awaiting, no rate; finalized: absence and the member-only rate appear; the headcount is the same before and after');
}
{
  const total = hc(sX).total; const summary = sum(sX).tracked;
  const converted = visitors.convertToMember(guestOne.id, { userId: null });
  assert.ok(converted.member);
  assert.equal(hc(sX).total, total, 'D: converted to a new member: the service still counts that human once');
  assert.equal(hc(sX).firstTimers, 3);
  assert.equal(sum(sX).tracked.expected, summary.expected, 'D: the stored expected roster is unchanged');
  assert.equal(sum(sX).tracked.rate, summary.rate, 'D: so is the rate');
  assert.equal(sum(sX).tracked.present, summary.present);

  // E1: linked to an existing member who has no attendance row for that service: once
  const e1 = visitors.linkVisitorToMember(second.id, m[3].id, { userId: null });
  assert.equal(e1.ok, true);
  assert.equal(hc(sX).total, total, 'E: linked to an existing member with no row of their own: still once');

  // E2: a member who already has their own Present row AND a separate First Timer record for the same service is one human
  const dup = visitors.createVisitor({ first_name: 'Dup', last_name: 'Human', first_visit_date: X, session_id: sX.id }, { userId: null });
  const withBoth = hc(sX).total; // two records of one person look like two people until they are linked
  assert.equal(withBoth, total + 1);
  const memberWithRow = m[0]; // already Present at X
  const e2 = visitors.linkVisitorToMember(dup.id, memberWithRow.id, { userId: null });
  assert.equal(e2.ok, true);
  assert.equal(hc(sX).total, total, 'E: once linked, the member with their own Present row and the First Timer record are ONE human, counted once (the duplicate stops counting)');
  assert.equal(hc(sX).members, 2 + 0, 'E: counted as a member, not also as a First Timer');
  const reread = hc(sX);
  assert.equal(reread.firstTimerIds.includes(dup.id), false);
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', dup.id), 1, 'E: the visit itself is untouched');
  console.log('PASS (D,E) converting or linking never moves a historical headcount; a human recorded twice (member row plus First Timer record) counts once as soon as they are linked');
}
{
  const total = hc(sX).total; const expected = sum(sX).tracked.expected;
  changeStatus(m[0].id, 'inactive', { reason: 'later', userId: null });
  changeStatus(m[1].id, 'archived', { reason: 'later', userId: null });
  assert.equal(hc(sX).total, total, 'F: members whose status changed later are still counted for that Friday');
  assert.equal(sum(sX).tracked.expected, expected, 'F: the expected roster is the stored one');
  assert.equal(hc(sX).members, 2);
  console.log('PASS (F) later status changes (inactive, archived) do not move a past headcount');
}

// ---- H (continued): reopen, re-finalize and a correction -------------------------------------------------------------------------------------------------
{
  const total = hc(sX).total;
  const reopened = lifecycle.reopenAttendance(sX.id, { userId: null, reason: 'check' });
  assert.equal(reopened.ok, true, JSON.stringify(reopened));
  assert.equal(sum(sX).tracked.final, false, 'reopened: not final again');
  assert.equal(hc(sX).total, total, 'reopening changes no headcount');
  assert.equal(lifecycle.finalizeAttendance(sX.id, { userId: null }).ok, true);
  assert.equal(hc(sX).total, total, 're-finalizing changes no headcount');
  const corrected = lifecycle.correctFinalizedAttendance(sX.id, [{ memberId: m[2].id, to: 'present' }], { userId: null, reason: 'late entry' });
  assert.equal(corrected.ok, true, JSON.stringify(corrected));
  assert.equal(hc(sX).total, total + 1, 'a correction that marks one more member Present adds exactly one');
  assert.equal(sum(sX).tracked.rateNumerator, 3);
  console.log('PASS (H, corrections) reopen and re-finalize change no headcount; a correction adding one Present member adds exactly one');
}

// ---- G: cancelled / Not Taken / before tracking stay what they are --------------------------------------------------------------------------------------------
{
  const g = visitors.createVisitor({ first_name: 'Gate', last_name: 'Keeper', first_visit_date: N, session_id: sN.id }, { userId: null });
  mark(sN.id, m[2].id);
  const nt = lifecycle.markAttendanceNotTaken(sN.id, { userId: null, note: 'power cut', confirmExistingAttendance: true });
  assert.equal(nt.ok, true, JSON.stringify(nt));
  const sn = sum(sN);
  assert.equal(sn.phase, 'not_taken');
  assert.equal(sn.tracked.rate, null); assert.equal(sn.tracked.expected, null);
  assert.equal(sn.tracked.headcount, 2, 'G: a Not Taken service still shows what physically happened (1 member + 1 First Timer) as evidence');
  assert.equal(sn.figures.total, 2);

  visitors.createVisitor({ first_name: 'Cancelled', last_name: 'Guest', first_visit_date: C, session_id: sC.id }, { userId: null });
  const cx = lifecycle.changeSessionStatus ? lifecycle.changeSessionStatus(sC.id, 'cancelled', { userId: null }) : null;
  assert.ok(cx === null || cx.ok);
  if (!cx) db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(sC.id);
  const sc = sum(sC);
  assert.equal(sc.phase, 'cancelled', 'G: a cancelled service stays cancelled however many visits it has');
  assert.equal(sc.figures.present, null);
  assert.equal(sc.tracked.rate, null);

  // a Friday that only has a First Timer visit is not "tracked attendance": no mark, no snapshot, no finalization
  const sP2 = sum(sP);
  assert.equal(sP2.phase, 'pre_go_live', 'G: the Friday before tracking is still a Friday before tracking');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id IN (?, ?)', sP.id, sO.id), 0);
  assert.equal(db.prepare('SELECT finalization_state FROM attendance_sessions WHERE id = ?').get(sP.id).finalization_state, null);
  const onlyVisitor = visitors.createVisitor({ first_name: 'Only', last_name: 'Visitor', first_visit_date: O, session_id: sO.id }, { userId: null });
  assert.ok(onlyVisitor);
  const so = sum(sO);
  assert.equal(so.phase, 'awaiting_finalization', 'G/H: a past Friday with only a First Timer is awaiting finalization, not finalized or not taken');
  assert.equal(hc(sO).total, 1);
  assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?', sO.id), 0, 'no attendance mark was manufactured for the visitor');
  const guard = lifecycle.previewFinalization(sO.id);
  assert.ok(guard.summary.firstTimeVisitors + guard.summary.presentExpected + guard.summary.unexpectedAttendees > 0, 'and finalization does not call it "no attendance at all"');
  console.log('PASS (G) Not Taken keeps its figures as evidence with no rate; a cancelled service stays cancelled; a Friday before tracking and a Friday with only a First Timer are not turned into tracked or finalized services; no attendance marks are made for visitors');
}

// ---- K, L: every screen, report and export agrees; repeated loads are idempotent ----------------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, 'hc.admin@fixture.invalid', 'Hc-Fixture-Passw0rd!x');
  const html = async (url) => { const res = await admin.get(url); assert.equal(res.status, 200, url); return res.text(); };
  const rowOf = (page, id) => {
    const start = page.indexOf(`href="/attendance/sessions/${id}"`);
    assert.ok(start >= 0, `session ${id} is listed`);
    const rowStart = page.lastIndexOf('<tr', start);
    const row = page.slice(rowStart, page.indexOf('</tr>', start));
    const cells = {};
    for (const mm of row.matchAll(/data-label="([^"]+)"[^>]*>([\s\S]*?)<\/td>/g)) cells[mm[1]] = mm[2].replace(/<[^>]+>/g, '').trim();
    return cells;
  };
  const tables = () => ({
    sessions: count('SELECT COUNT(*) n FROM attendance_sessions'), records: count('SELECT COUNT(*) n FROM attendance_records'), expected: count('SELECT COUNT(*) n FROM attendance_expected'),
    visits: count('SELECT COUNT(*) n FROM visitor_visits'), visitors: count('SELECT COUNT(*) n FROM visitors'), members: count('SELECT COUNT(*) n FROM members')
  });
  const snapshot = async () => {
    const out = {};
    const history = await html('/attendance/history?type=friday_service&page_size=100');
    const friday = await html('/attendance/friday?past=all');
    const csv = await html('/reports/attendance/export.csv?from=' + P + '&to=' + L);
    const csvLines = csv.split(/\r?\n/).filter(Boolean); const csvHead = csvLines[0].split(',').map((h) => h.replace(/"/g, ''));
    for (const [label, s] of [['P', sP], ['X', sX], ['N', sN], ['O', sO], ['L', sL]]) {
      const h = rowOf(history, s.id);
      const line = csvLines.find((l) => l.startsWith(`"${s.service_date}"`) || l.startsWith(s.service_date));
      out[label] = {
        history: { members: Number(h['Members present']), firstTimers: Number(h['First Timers']), total: Number(h['Total present']), marks: Number(h['Marks recorded']) },
        csvTotal: line ? Number(line.split(',')[csvHead.indexOf('Total present')].replace(/"/g, '')) : null
      };
      if (friday.includes(`/attendance/sessions/${s.id}"`)) {
        const f = rowOf(friday, s.id);
        out[label].fridayList = { firstTimers: Number(f['First Timers']), total: Number(f['Total present']) };
      }
    }
    out.register = Number((await html(`/attendance/sessions/${sX.id}`)).match(/Total present<\/p>\s*<p class="stat__value">(\d+)</)?.[1]);
    return out;
  };

  const before = tables();
  const auditFloor = count('SELECT COALESCE(MAX(id), 0) n FROM audit_logs');
  const shot1 = await snapshot();
  const overview = fridayAttendanceOverview({ from: P, to: L });
  for (const [label, s] of [['P', sP], ['X', sX], ['N', sN], ['O', sO], ['L', sL]]) {
    const truth = hc(s);
    const got = shot1[label];
    assert.deepEqual(got.history, { members: truth.members, firstTimers: truth.firstTimers, total: truth.total, marks: count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?', s.id) }, `${label}: Attendance history agrees with the definition`);
    if (got.fridayList) assert.deepEqual(got.fridayList, { firstTimers: truth.firstTimers, total: truth.total }, `${label}: the Friday list agrees`);
    if (got.csvTotal !== null) assert.equal(got.csvTotal, truth.total, `${label}: the Reports CSV agrees`);
    const row = overview.sessions.find((r) => r.sessionId === s.id);
    if (row) assert.equal(row.total, truth.total, `${label}: the Reports screen's row agrees`);
    assert.equal(sum(s).physical.total, truth.total, `${label}: the service summary agrees`);
    assert.equal(sum(s).figures.total, truth.total);
  }
  assert.equal(shot1.register, hc(sX).total, 'X: the register page says the same');
  assert.equal(checkedInState().count, hc(sL).total, 'L: the desk\'s live count agrees');
  // the member report (a member-population report) never includes First Timers, and its member figures add up to the members of the definition
  const everyone = attendanceReport({ from: X, to: X, statuses: ['active', 'inactive', 'pending', 'archived', 'temporarily_away', 'returned_home', 'migrated', 'transferred', 'other', 'attendee', 'bonafide'] }).bySession.find((p) => p.sessionId === sX.id);
  assert.equal(everyone.present + everyone.visitor + everyone.unexpected, hc(sX).members, 'K: the member report\'s people are exactly the definition\'s members (First Timers are not in it)');
  const bulk = serviceHeadcounts([sP.id, sX.id, sN.id, sC.id, sO.id, sL.id]);
  for (const s of [sP, sX, sN, sC, sO, sL]) assert.deepEqual(bulk.get(s.id), hc(s), 'bulk and single calls agree');
  // PDF and the member CSV render and do not include First Timers as members
  const pdf = await admin.get(`/reports/attendance/pdf?from=${P}&to=${L}`);
  assert.equal(pdf.status, 200, 'the attendance PDF renders');
  assert.equal(Buffer.from(await pdf.arrayBuffer()).subarray(0, 4).toString(), '%PDF');
  const memberCsv = await html(`/attendance/reports/export.csv?from=${X}&to=${X}`);
  assert.ok(!/Sample Visitor|Express Person|Normal Checkin|Gate Keeper|Hand Recorded|Only Visitor|Dup Human|Guest Two/.test(memberCsv), 'the member CSV lists members only, never a person who is still a First Timer');
  console.log(`PASS (K) history, Friday list, register, Reports (screen and CSV), service summary, the member report and the desk's live count agree for ${5} services: ${JSON.stringify(Object.fromEntries(['P', 'X', 'N', 'O', 'L'].map((k) => [k, shot1[k].history.total])))}`);

  for (let i = 0; i < 3; i += 1) assert.deepEqual(await snapshot(), shot1, `L: load ${i + 2} returns the same numbers`);
  assert.deepEqual(tables(), before, 'L: loading every page repeatedly wrote nothing to any attendance, visit, member or session table');
  const audited = db.prepare('SELECT action FROM audit_logs WHERE id > ?').all(auditFloor).map((r) => r.action);
  assert.ok(audited.every((a) => /export|print|pdf|download/.test(a)), `L: the only audit rows page loads add are the exports and prints that audit themselves (${[...new Set(audited)].join(', ')})`);
  console.log('PASS (L) four rounds of loading every screen and export return identical numbers and write no row anywhere');
} finally {
  await portal.stop();
}
db.close();
console.log('ALL PASS');
