import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * The Kiosk as an untrusted, low-privilege terminal. A First Timer is planted with a phone number, an email, notes, follow-up notes and
 * an inviter, each carrying a unique marker. Then the Kiosk does everything an attacker at the desk could: every search shape and phone
 * formatting, forged and malformed posts to its own endpoints, every route in the portal with every kind of id, every state-changing
 * route with a valid CSRF token. Nothing the Kiosk is shown - body, headers, redirect, flash, error page - may contain any marker or
 * any form of the full number, nothing outside the Kiosk's own screens may answer, and nothing it is not allowed to change may change.
 * The portal's own output is captured too: the service log must not contain the typed numbers.
 */

const f = await buildPortalFixture('cciq-kiosk-red-');
const { db, ids, users, mods } = f;
const SECRET = {
  phone: '+974 5588 7766', email: 'secretvisitor.marker@fixture.invalid', notes: 'SECRETNOTE-ALPHA-1', followUp: 'SECRETFOLLOWUP-BRAVO-2',
  inviter: 'SECRETINVITER-CHARLIE-3', address: 'SECRETADDRESS-DELTA-4', lastName: 'Hiddenphone'
};
const visitor = mods.visitors.createVisitor({
  first_name: 'Zacchaeus', last_name: SECRET.lastName, phone: SECRET.phone, email: SECRET.email, notes: SECRET.notes,
  invited_by_name: SECRET.inviter, first_visit_date: mods.dates.addDays(mods.dates.today(), -30)
}, { userId: users.churchAdmin.id });
db.prepare('UPDATE visitors SET follow_up_notes = ? WHERE id = ?').run(SECRET.followUp, visitor.id);
db.prepare('UPDATE members SET address = ? WHERE id = ?').run(SECRET.address, ids.member.a2);
const reviewId = Number(db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', ?)")
  .run(visitor.id, JSON.stringify({ rule: 'r', visits: 3, fridays: [] })).lastInsertRowid);

const digits = SECRET.phone.replace(/\D/g, '');                 // 97455887766
const tail8 = digits.slice(-8);                                   // 55887766
const LEAKS = [
  new RegExp(digits), new RegExp(tail8), /5588[\s -]*7766/, /\+974/, /secretvisitor\.marker/i, /SECRETNOTE|SECRETFOLLOWUP|SECRETINVITER|SECRETADDRESS/
];
const leaksIn = (text) => LEAKS.filter((re) => re.test(text)).map(String);

const captured = [];
const portal = await startPortal();
portal.server.stdout?.on('data', (d) => captured.push(String(d)));
portal.server.stderr?.on('data', (d) => captured.push(String(d)));
const kioskA = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
const kioskB = await (async () => {
  await mods.users.createUser({ username: 'fx_kiosk_b', email: 'fx_kiosk_b@fixture.invalid', password: f.PASSWORD, displayName: 'Kiosk B', roleKeys: ['kiosk'], mustChangePassword: false });
  return signIn(portal.base, 'fx_kiosk_b@fixture.invalid', f.PASSWORD);
})();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
let probes = 0;
const inspect = async (res, label) => {
  probes += 1;
  const text = await res.text();
  const headers = [...res.headers.entries()].map(([k, v]) => `${k}: ${v}`).join('\n');
  assert.deepEqual(leaksIn(text), [], `${label}: the body leaks nothing`);
  assert.deepEqual(leaksIn(headers), [], `${label}: the headers (incl. Location, Set-Cookie) leak nothing`);
  assert.ok(res.status < 500, `${label}: never a server error (${res.status})`);
  assert.doesNotMatch(text, /SqliteError|\bat \w+ \(|node_modules|\.js:\d+/, `${label}: no internals`);
  return { text, status: res.status, location: res.headers.get('location') };
};
const post = (path, fields, who = kioskA, opts = {}) => who.post(path, fields, { csrfFrom: '/kiosk', ...opts });

try {
  // ---- 1. every search shape ------------------------------------------------------------------------------------------------------------
  const phoneForms = [SECRET.phone, digits, `+${digits}`, '974-5588-7766', '(974) 5588 7766', ' 974 5588 7766 ', '974.5588.7766', '00974 5588 7766', tail8, '5588 7766', '558877', '5588776', '5588', '7766', '9'.repeat(300), '0'.repeat(25), '+'.padEnd(60, '9'), '٩٧٤٥٥٨٨٧٧٦٦', '９７４５５８８７７６６'];
  for (const q of phoneForms) {
    const r = await inspect(await post('/attendance/checkin/search', { q, kiosk: '1' }), `search "${q.slice(0, 24)}"`);
    // Qatar's eight local digits ARE the whole number (the canonical phone key drops +974 / 00974), so the local forms find the person too
    if ([digits, SECRET.phone, `+${digits}`, '974-5588-7766', '(974) 5588 7766', ' 974 5588 7766 ', tail8, '5588 7766'].includes(q)) {
      assert.match(r.text, /Zacchaeus/, `the whole number "${q}" finds the First Timer`);
      assert.match(r.text, /•••• 7766/, 'with only the masked tail');
    } else if (q === '558877' || q === '5588776') {
      assert.doesNotMatch(r.text, /Zacchaeus/, `a fragment ("${q}") finds no one`);
    }
  }
  for (const q of ['Zacch', 'Zacchaeus', 'Hiddenphone', 'zacchaeus hiddenphone', 'ZACCHAEUS', '%', '_', '%%__', '\\', "'; DROP TABLE visitors;--", '" OR 1=1 --', '<script>alert(1)</script>', '<img src=x onerror=alert(1)>', '\u{1F600}', 'Z\u0000', 'Zacchaeus'.repeat(40), '   ', '', 'a', '‮evil']) {
    const r = await inspect(await post('/attendance/checkin/search', { q, kiosk: '1' }), `search "${q.slice(0, 24)}"`);
    assert.doesNotMatch(r.text, /<script>alert|<img src=x/i, 'markup in a search term is escaped');
  }
  const afterDrop = db.prepare('SELECT COUNT(*) n FROM visitors').get().n; assert.ok(afterDrop >= 2, 'the visitors table is intact after hostile terms');
  // shapes: arrays, objects, repeated, missing, wrong type
  for (const body of [{ q: ['a', 'b'] }, { 'q[x]': 'y' }, { q: ['+974 5588 7766', 'Zacch'] }, { q: '', 'q ': 'x' }, {}]) {
    await inspect(await post('/attendance/checkin/search', { ...body, kiosk: '1' }), `search shape ${JSON.stringify(body).slice(0, 40)}`);
  }
  // a number must not be accepted in a URL, and the redirect must not carry it
  for (const url of ['/kiosk?q=%2B97455887766', '/kiosk?q=97455887766', '/kiosk?q=974%205588%207766', '/attendance/checkin?q=97455887766']) {
    const res = await kioskA.get(url); const r = await inspect(res, `GET ${url}`);
    assert.equal(r.status, 302); assert.ok(['/kiosk', '/attendance/checkin'].includes(r.location), `redirect target is clean (${r.location})`);
  }
  // both Kiosk accounts behave identically
  const a = await (await post('/attendance/checkin/search', { q: digits, kiosk: '1' }, kioskA)).text();
  const b = await (await post('/attendance/checkin/search', { q: digits, kiosk: '1' }, kioskB)).text();
  const strip = (t) => t.replace(/name="_csrf" value="[^"]+"/g, '').replace(/data-csrf="[^"]+"/g, '').replace(/\?v=[^"']+/g, '')
    .replace(/<span class="kiosk__identity">[^<]*<\/span>/, ''); // only the signed-in account's own display name may differ
  assert.equal(strip(a), strip(b), 'both Kiosk accounts get exactly the same page (role-based, no username-specific behaviour)');

  // ---- 2. review / record steps with forged and crafted selections -----------------------------------------------------------------------
  const forgedPeople = [`visitor:${visitor.id}`, `member:${ids.member.a2}`, 'visitor:999999', 'member:abc', 'visitor:-1', `visitor:${visitor.id}x`, 'admin:1', `visitor:${visitor.id}\u0000`, `visitor:${'9'.repeat(40)}`];
  for (const person of forgedPeople) {
    const r = await inspect(await post('/attendance/checkin/review', { person, q: SECRET.phone, kiosk: '1' }), `review ${person.slice(0, 22)}`);
    assert.doesNotMatch(r.text, /5588|7766/, 'the review step does not echo a number-shaped term');
  }
  const rec = await inspect(await post('/attendance/checkin/record', { person: [`visitor:${visitor.id}`, `member:${ids.member.a2}`], kiosk: '1' }, kioskA, { headers: { Accept: 'application/json' } }), 'record');
  assert.ok(rec.status < 400 || rec.status === 409);
  await inspect(await post('/attendance/checkin/record', { person: `visitor:${visitor.id}`, session_id: '1', status: 'absent', kiosk: '1' }), 'record with forged session/status');
  for (const token of ['x', '0'.repeat(32), 'A'.repeat(5000), '{"a":1}', '%00']) {
    await inspect(await post('/attendance/checkin/lookup', { token }), `lookup ${token.slice(0, 12)}`);
  }

  // ---- 3. Express Registration: forged and hostile ----------------------------------------------------------------------------------------
  const pastSession = db.prepare("SELECT id FROM attendance_sessions ORDER BY id LIMIT 1").get().id;
  const before = db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
  const forged = await post('/attendance/checkin/first-timer', {
    first_name: 'Forger', last_name: 'Test', phone: '+974 5599 0001', session_id: pastSession, sessionId: pastSession, first_visit_date: '2001-01-01', visit_date: '2001-01-01',
    state: 'joined', member_id: ids.member.a2, visitor_id: visitor.id, invited_by_member_id: ids.member.a1, invited_by_name: 'Injected', notes: 'injected note', email: 'inj@fixture.invalid',
    follow_up_state: 'completed', created_by: users.superAdmin.id, duplicate_override: '1', override: '1', kiosk: '1'
  });
  await inspect(forged, 'express with forged fields');
  const row = db.prepare("SELECT * FROM visitors WHERE first_name = 'Forger'").get();
  assert.ok(row, 'the registration itself works');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitors').get().n, before + 1);
  const forgedVisit = db.prepare('SELECT * FROM visitor_visits WHERE visitor_id = ?').all(row.id);
  assert.equal(forgedVisit.length, 1); assert.equal(forgedVisit[0].session_id, ids.session, 'the SERVER chooses the session (the client cannot name a past or future one)');
  assert.equal(forgedVisit[0].visit_date, ids.friday, 'and the visit date is that service date, not the posted one');
  assert.equal(row.first_visit_date, ids.friday); assert.equal(row.state, 'new', 'the state cannot be forged'); assert.equal(row.member_id, null, 'nor a member link');
  assert.equal(row.email, null, 'no email is accepted at the desk'); assert.equal(row.notes, null, 'no notes'); assert.equal(row.invited_by_member_id, ids.member.a1, 'the optional Invited by is accepted only as a real member id'); assert.equal(row.invited_by_name, null, 'and no free-text inviter name is accepted');
  assert.equal(row.follow_up_state, 'new'); assert.equal(row.created_by, users.kiosk.id, 'the audit actor and creator is the signed-in Kiosk account, not a posted id');
  const audit = db.prepare("SELECT user_id, detail FROM audit_logs WHERE action = 'visitor.express_registered' AND entity_id = ?").get(String(row.id));
  assert.equal(audit.user_id, users.kiosk.id, 'the audit row names the Kiosk account');
  assert.doesNotMatch(audit.detail, /5599|\+974/, 'and never holds the number');
  // hostile values
  for (const fields of [
    { first_name: '<script>alert(1)</script>' }, { first_name: '"><img src=x onerror=1>' }, { first_name: "Robert'); DROP TABLE visitors;--" }, { first_name: 'Ünïçode محمد' },
    { first_name: '%'.repeat(50) }, { first_name: 'x'.repeat(100000) }, { first_name: 'Ok', last_name: 'y'.repeat(5000) }, { first_name: 'Ok2', phone: '+'.padEnd(200, '9') }, { first_name: 'Ok3', phone: '٩٧٤٥٥٨٨٧٧٦٦' },
    { first_name: ['a', 'b'] }, { first_name: 'Ok4', phone: ['1', '2'] }, { 'first_name[x]': 'y' }, { first_name: '' }, { first_name: '   ' }, { first_name: 'Nul\u0000l' }
  ]) {
    const r = await inspect(await post('/attendance/checkin/first-timer', { ...fields, kiosk: '1' }), `express ${JSON.stringify(fields).slice(0, 50)}`);
    assert.doesNotMatch(r.text, /<script>alert\(1\)<\/script>|<img src=x onerror/, 'markup is escaped in the response');
  }
  assert.ok(db.prepare("SELECT COUNT(*) n FROM visitors WHERE first_name LIKE '%DROP TABLE%'").get().n <= 1, 'a hostile name is stored as plain text at most (no SQL effect)');
  // the flash after a success is escaped
  const jar = await post('/attendance/checkin/first-timer', { first_name: '<b>Flash</b>', kiosk: '1' });
  const next = await kioskA.get('/kiosk'); const nextText = await next.text();
  assert.doesNotMatch(nextText, /<b>Flash<\/b>/, 'a name is escaped in the success message'); void jar;
  // huge body
  const huge = await fetch(`${portal.base}/attendance/checkin/first-timer`, { method: 'POST', redirect: 'manual', headers: { Cookie: kioskA.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: `_csrf=${await kioskA.csrf('/kiosk')}&first_name=${'A'.repeat(3 * 1024 * 1024)}` });
  assert.ok(huge.status >= 400 && huge.status < 500, `a 3 MB body is refused as a client error (${huge.status})`); await inspect(huge, 'huge body');

  // ---- 4. every route in the portal, every kind of id: the Kiosk gets only its own screens ---------------------------------------------------
  const routes = catalogue();
  const allowedPaths = /^(\/kiosk(\/count)?|\/attendance\/checkin.*|\/quick-access\/(info|card\.png)|\/account\/password|\/logout|\/media\/members\/.*|\/css\/.*|\/js\/.*|\/branding\/.*|\/help(\/.*)?)$/;
  const idsToTry = [visitor.id, ids.member.a2, reviewId, ids.session];
  const concrete = (route, id) => route.path.replace(/:\w+(\([^)]*\))?/g, (m) => (/\[a-f0-9\]\{32\}/.test(m) ? '0'.repeat(32) : String(id)));
  const snapshot = () => JSON.stringify([
    db.prepare('SELECT COUNT(*) n FROM members').get().n, db.prepare('SELECT * FROM visitors ORDER BY id').all(), db.prepare('SELECT COUNT(*) n FROM visitor_visits').get().n,
    db.prepare('SELECT * FROM visitor_membership_reviews ORDER BY id').all(), db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n,
    db.prepare('SELECT COUNT(*) n FROM users').get().n, db.prepare('SELECT COUNT(*) n FROM documents').get().n, db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action NOT LIKE 'auth.%'").get().n
  ]);
  let swept = 0;
  for (const route of routes.filter((r) => r.method === 'GET')) {
    for (const id of idsToTry) {
      const url = concrete(route, id); if (url.includes(':')) continue;
      const res = await kioskA.get(url); swept += 1;
      const r = await inspect(res, `Kiosk GET ${url}`);
      if (!allowedPaths.test(url.split('?')[0])) assert.ok([302, 403, 404].includes(r.status) && (r.status !== 302 || r.location === '/kiosk'), `Kiosk GET ${url} is not served (${r.status} ${r.location})`);
    }
  }
  const snapBefore = snapshot();
  const csrf = await kioskA.csrf('/kiosk');
  for (const route of routes.filter((r) => r.method === 'POST' && !/^\/(attendance\/checkin|logout|account\/password)/.test(r.path) && !/\/login|\/setup|\/first-run/.test(r.path))) {
    for (const id of idsToTry) {
      const url = concrete(route, id); if (url.includes(':')) continue;
      const res = await fetch(`${portal.base}${url}`, { method: 'POST', redirect: 'manual', headers: { Cookie: kioskA.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: csrf, first_name: 'X', state: 'joined', confirm: '1', member_id: String(ids.member.a2), status: 'archived', permissions: 'admin.users' }) });
      swept += 1;
      const r = await inspect(res, `Kiosk POST ${url}`);
      assert.ok([302, 403, 404].includes(r.status) && (r.status !== 302 || r.location === '/kiosk'), `Kiosk POST ${url} is refused (${r.status} ${r.location})`);
    }
  }
  assert.equal(snapshot(), snapBefore, 'after posting to every other route with a valid CSRF token nothing changed (no member, visitor, visit, review, record, user, document or audit row)');

  // ---- 5. the Kiosk account has exactly the permissions it should ----------------------------------------------------------------------------
  const perms = db.prepare(`SELECT DISTINCT p.key FROM users u JOIN user_roles ur ON ur.user_id = u.id JOIN role_permissions rp ON rp.role_id = ur.role_id JOIN permissions p ON p.id = rp.permission_id WHERE u.id = ? ORDER BY p.key`).all(users.kiosk.id).map((r) => r.key);
  assert.deepEqual(perms, ['attendance.checkin', 'visitors.express_register']);
  for (const denied of ['/members', '/members/new', '/visitors', '/visitors/new', '/visitors/reviews', `/visitors/${visitor.id}`, `/visitors/${visitor.id}/convert`, `/visitors/${visitor.id}/link`, `/members/${ids.member.a2}`, '/admin/audit', '/reports']) {
    const res = await kioskA.get(denied); assert.equal(res.status, 302); assert.equal(res.headers.get('location'), '/kiosk', `${denied} sends the Kiosk home`);
  }

  // ---- 6. headers on the Kiosk screens ---------------------------------------------------------------------------------------------------------
  for (const [label, res] of [['kiosk home', await kioskA.get('/kiosk')], ['search', await post('/attendance/checkin/search', { q: 'Zacch', kiosk: '1' })], ['express form', await kioskA.get('/attendance/checkin/first-timer')]]) {
    assert.match(res.headers.get('cache-control') || '', /no-store/, `${label} is never cached (no number or name is kept by a shared terminal's browser cache)`);
    assert.equal(res.headers.get('x-powered-by'), null, `${label} does not advertise the framework`);
    await res.text();
  }
  // a plain administrator on the same screens gets the same privacy
  const adminSearch = await inspect(await admin.post('/attendance/checkin/search', { q: digits }, { csrfFrom: '/attendance/checkin' }), 'admin search by number');
  assert.match(adminSearch.text, /Zacchaeus/);

  // ---- 7. the portal's own log ---------------------------------------------------------------------------------------------------------------------
  await new Promise((resolve) => setTimeout(resolve, 300));
  const log = captured.join('');
  assert.deepEqual(leaksIn(log), [], 'the service log (stdout/stderr) contains no typed or stored number, email or note');
  assert.doesNotMatch(log, /5588|SECRET|password|csrf/i, 'nor a password, CSRF token or marker');
  console.log(`PASS (red team) ${probes} probes by the Kiosk (every search shape and phone format, forged reviews/records/registrations, ${swept} route requests with every kind of id, posts to every state-changing route with a valid CSRF token): no marker or form of the full number appeared in any body, header, redirect, flash or log; only the Kiosk's own screens answered; nothing it may not change changed; the server alone chose the session, date, state and actor`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
