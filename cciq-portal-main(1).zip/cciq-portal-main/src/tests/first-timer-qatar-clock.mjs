import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * The First Timer features around the Qatar day boundary. Qatar is UTC+3 with no daylight saving, so the Qatar date is the UTC date until
 * 21:00 UTC and the NEXT UTC date after it. The clock is pinned at 23:59, 00:00, 00:30, 02:59 and 03:00 Qatar time either side of
 * Thursday -> Friday and Friday -> Saturday, and everything that picks "today" or "this Friday" must follow the Qatar calendar:
 *   - which Friday service the check-in desk is working on;
 *   - the first-visit date written by Express Registration;
 *   - the join date Convert proposes, the date a new First Timer is recorded on;
 *   - the Qatar date a stored timestamp (a review's closing time) is shown as.
 * A stored timestamp itself stays UTC on purpose.
 */

const RealDate = Date;
function clockAt(iso) {
  const fixed = new RealDate(iso).getTime();
  globalThis.Date = class extends RealDate {
    constructor(...args) { if (args.length === 0) super(fixed); else super(...args); }
    static now() { return fixed; }
  };
}
const restoreClock = () => { globalThis.Date = RealDate; };

createIsolatedTestEnv('cciq-ft-clock-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const visitors = await import('../services/visitors.js');
const express = await import('../services/express-registration.js');
const checkin = await import('../services/qr-checkin.js');
const dates = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

await createUser({ username: 'clk_admin', email: 'clk.admin@fixture.invalid', password: 'Clk-Fixture-Passw0rd!x', displayName: 'Clk Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'clk_admin'").get().id;
// Fridays: 2026-09-25 and 2026-10-02 (2026-10-01 is a Thursday)
for (const d of ['2026-09-25', '2026-10-02']) db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, '2026-01-01T00:00:00.000Z')").run(d);
const sessionOn = (d) => db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(d).id;

// [UTC instant, Qatar calendar date, the Friday the desk works on, label]
const INSTANTS = [
  ['2026-10-01T20:59:00Z', '2026-10-01', '2026-09-25', 'Thursday 23:59 Qatar'],
  ['2026-10-01T21:00:00Z', '2026-10-02', '2026-10-02', 'Friday 00:00 Qatar'],
  ['2026-10-01T21:30:00Z', '2026-10-02', '2026-10-02', 'Friday 00:30 Qatar'],
  ['2026-10-01T23:59:00Z', '2026-10-02', '2026-10-02', 'Friday 02:59 Qatar (still Thursday in UTC)'],
  ['2026-10-02T00:00:00Z', '2026-10-02', '2026-10-02', 'Friday 03:00 Qatar (Friday in UTC too)'],
  ['2026-10-02T20:59:00Z', '2026-10-02', '2026-10-02', 'Friday 23:59 Qatar'],
  ['2026-10-02T21:00:00Z', '2026-10-03', '2026-10-02', 'Saturday 00:00 Qatar (the desk still works on Friday\'s service)'],
  ['2026-10-02T21:30:00Z', '2026-10-03', '2026-10-02', 'Saturday 00:30 Qatar']
];
let n = 0;
try {
  for (const [instant, qatarDate, friday, label] of INSTANTS) {
    clockAt(instant);
    assert.equal(dates.today(), qatarDate, `${label}: today is ${qatarDate}`);
    const session = checkin.checkinSession();
    assert.equal(session?.service_date, friday, `${label}: the desk works on the ${friday} service`);

    // Express Registration writes the SERVICE's date, whatever hour it is
    n += 1;
    const result = express.registerFirstTimerAtDesk({ first_name: `Clock${n}`, last_name: 'Walker' }, { userId: adminId });
    assert.equal(result.ok, true, `${label}: registration works`);
    assert.equal(result.visitor.first_visit_date, friday, `${label}: first visit is the service date ${friday}`);
    const visit = db.prepare('SELECT visit_date, session_id FROM visitor_visits WHERE visitor_id = ?').get(result.visitor.id);
    assert.deepEqual(visit, { visit_date: friday, session_id: sessionOn(friday) }, `${label}: the visit is tied to that service on that date`);
    assert.match(result.visitor.created_at, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/, `${label}: the stored time stays UTC`);
    assert.equal(result.visitor.created_at.slice(0, 16), new RealDate(instant).toISOString().slice(0, 16), `${label}: and is the real instant`);

    // a First Timer recorded by hand today, and the join date Convert proposes
    const manual = visitors.createVisitor({ first_name: `Hand${n}`, last_name: 'Walker', first_visit_date: dates.today() }, { userId: adminId });
    assert.equal(manual.first_visit_date, qatarDate, `${label}: a First Timer recorded today is dated ${qatarDate}`);
    assert.equal(visitors.defaultMemberValuesFor(manual).date_joined, qatarDate, `${label}: Convert proposes ${qatarDate} as the join date`);

    // the Qatar date a stored timestamp is SHOWN as
    assert.equal(dates.qatarDateOf(new RealDate(instant).toISOString()), qatarDate, `${label}: a timestamp taken now is shown as ${qatarDate}`);
  }
  // a conversion performed just after Qatar midnight carries that day's date, not UTC's
  clockAt('2026-10-01T21:30:00Z');
  const v = visitors.createVisitor({ first_name: 'Midnight', last_name: 'Convert', first_visit_date: '2026-09-25' }, { userId: adminId });
  const made = visitors.convertToMember(v.id, { userId: adminId });
  assert.equal(made.member.date_joined, '2026-10-02', 'joined on the Qatar date (Friday), not the UTC date (Thursday)');
  const history = db.prepare('SELECT changed_at FROM member_status_history WHERE member_id = ?').get(made.member.id);
  assert.equal(dates.qatarDateOf(history.changed_at), '2026-10-02', 'and the status-history time falls on the same Qatar day');
  // the same instant, one hour earlier, is still Thursday
  clockAt('2026-10-01T20:59:00Z');
  const v2 = visitors.createVisitor({ first_name: 'Evening', last_name: 'Convert', first_visit_date: '2026-09-25' }, { userId: adminId });
  assert.equal(visitors.convertToMember(v2.id, { userId: adminId }).member.date_joined, '2026-10-01', 'Thursday 23:59 Qatar joins on Thursday');
} finally {
  restoreClock();
}
console.log(`PASS (clock) ${INSTANTS.length} instants around Thursday->Friday and Friday->Saturday: the desk's Friday, Express Registration's visit date, new First Timer and join dates all follow the Qatar calendar; stored timestamps stay UTC and display as the Qatar date`);
console.log('ALL PASS');
