import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Migration 0030 torture test. migration-0030.mjs proves the headline behaviour; this suite attacks the edges:
 *   - the whole chain from a 0028 database, from a clean 0029 database, and on a fresh database; identical results;
 *   - every unsafe legacy shape (including a dangling member link), refused with nothing changed, never repaired;
 *   - failure injected BEFORE the transaction (the gate), INSIDE it (a statement that cannot succeed) and AFTER it (recording the
 *     migration), each followed by a clean re-run;
 *   - the guard triggers and the review table's foreign keys behave exactly as designed once the migration is in;
 *   - ordinary updates (visitors, members) are never caught by the guards.
 */

const env = createIsolatedTestEnv('cciq-migration-0030-torture-');
const migrateModule = await import('../db/migrate.js');
const { migrate, EXPECTED_MIGRATIONS, MigrationRefusedError, checkSchemaCompatibility } = migrateModule;
migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember, changeStatus } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const { findFirstTimerLinkProblems } = await import('../lib/first-timer-links.js');
const { default: db } = await import('../db/index.js');

const V0030 = '0030_first_timer_membership_review';
const V0029 = '0029_attendance_finalization';
const OBJECTS = {
  table: 'visitor_membership_reviews',
  indexes: ['idx_membership_reviews_status', 'idx_membership_reviews_visitor', 'idx_visitors_member_unique', 'uniq_open_review_per_visitor'],
  triggers: ['trg_members_delete_has_visitor', 'trg_visitors_joined_iff_member_insert', 'trg_visitors_joined_iff_member_update']
};
const names = (type) => db.prepare('SELECT name FROM sqlite_master WHERE type = ? ORDER BY name').all(type).map((r) => r.name);
const has0030 = () => names('table').includes(OBJECTS.table)
  || OBJECTS.indexes.some((i) => names('index').includes(i)) || OBJECTS.triggers.some((t) => names('trigger').includes(t))
  || Boolean(db.prepare("SELECT 1 FROM permissions WHERE key = 'visitors.express_register'").get())
  || Boolean(db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(V0030));
const schemaSignature = () => JSON.stringify(db.prepare("SELECT type, name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name").all());
const dataSnapshot = () => JSON.stringify({
  visitors: db.prepare('SELECT * FROM visitors ORDER BY id').all(), members: db.prepare('SELECT * FROM members ORDER BY id').all(),
  visits: db.prepare('SELECT * FROM visitor_visits ORDER BY id').all(), sessions: db.prepare('SELECT * FROM attendance_sessions ORDER BY id').all(),
  records: db.prepare('SELECT * FROM attendance_records ORDER BY id').all(), history: db.prepare('SELECT * FROM member_status_history ORDER BY id').all(),
  perms: db.prepare('SELECT key FROM permissions ORDER BY key').all(), grants: db.prepare('SELECT role_id, permission_id FROM role_permissions ORDER BY role_id, permission_id').all(),
  migrations: db.prepare('SELECT version FROM schema_migrations ORDER BY version').all()
});

function rewindTo0029() {
  db.pragma('foreign_keys = OFF');
  db.exec(`
    ${OBJECTS.triggers.map((t) => `DROP TRIGGER IF EXISTS ${t};`).join('\n')}
    ${OBJECTS.indexes.map((i) => `DROP INDEX IF EXISTS ${i};`).join('\n')}
    DROP TABLE IF EXISTS ${OBJECTS.table};
    DELETE FROM role_permissions WHERE permission_id = (SELECT id FROM permissions WHERE key = 'visitors.express_register');
    DELETE FROM permissions WHERE key = 'visitors.express_register';
    DELETE FROM schema_migrations WHERE version = '${V0030}';
  `);
  db.pragma('foreign_keys = ON');
}
function rewindTo0028() {
  rewindTo0029();
  db.pragma('foreign_keys = OFF');
  db.exec(`
    BEGIN;
    DROP TABLE attendance_expected;
    CREATE TABLE attendance_sessions_0028 (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      service_date  TEXT NOT NULL,
      service_type  TEXT NOT NULL DEFAULT 'friday_service'
                      CHECK (service_type IN ('friday_service','special_service','church_activity','cell_group')),
      title         TEXT,
      start_time    TEXT,
      location      TEXT,
      cell_group_id INTEGER NOT NULL DEFAULT 0,
      status        TEXT NOT NULL DEFAULT 'scheduled'
                      CHECK (status IN ('scheduled','held','cancelled')),
      counts_toward_followup INTEGER NOT NULL DEFAULT 1,
      notes         TEXT,
      created_at    TEXT NOT NULL,
      created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
      UNIQUE (service_date, service_type, cell_group_id)
    );
    INSERT INTO attendance_sessions_0028
      SELECT id, service_date, service_type, title, start_time, location, cell_group_id, status,
             counts_toward_followup, notes, created_at, created_by FROM attendance_sessions;
    DROP TABLE attendance_sessions;
    ALTER TABLE attendance_sessions_0028 RENAME TO attendance_sessions;
    CREATE INDEX idx_sessions_date ON attendance_sessions(service_date);
    DELETE FROM role_permissions WHERE permission_id = (SELECT id FROM permissions WHERE key = 'attendance.finalize');
    DELETE FROM permissions WHERE key = 'attendance.finalize';
    DELETE FROM schema_migrations WHERE version = '${V0029}';
    COMMIT;
  `);
  db.pragma('foreign_keys = ON');
}
const clearWorld = () => { db.pragma('foreign_keys = OFF'); db.exec('DELETE FROM visitor_visits; DELETE FROM visitors; DELETE FROM attendance_records; DELETE FROM qr_checkins; DELETE FROM attendance_sessions; DELETE FROM member_status_history; DELETE FROM members;'); db.pragma('foreign_keys = ON'); };
const rawVisitor = (first, state, memberId) => Number(db.prepare("INSERT INTO visitors (first_name, last_name, state, member_id, follow_up_state, first_visit_date, created_at, updated_at) VALUES (?, 'T', ?, ?, 'new', '2025-12-05', 'x', 'x')").run(first, state, memberId).lastInsertRowid);
function plantCleanLegacy() {
  const m = createMember({ first_name: 'Joined', last_name: 'Member' }, { status: 'active' });
  rawVisitor('Ok-New', 'new', null); rawVisitor('Ok-Returning', 'returning', null); rawVisitor('Ok-Declined', 'declined', null); rawVisitor('Ok-Joined', 'joined', m.id);
  db.prepare("INSERT INTO visitor_visits (visitor_id, visit_date, recorded_at) SELECT id, first_visit_date, 'x' FROM visitors").run();
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES ('2025-12-05', 'friday_service', 'Friday', 'held', 1, 0, 'x')").run();
  db.prepare("INSERT INTO attendance_records (session_id, member_id, status, recorded_at, source) SELECT s.id, ?, 'present', 'x', 'manual' FROM attendance_sessions s LIMIT 1").run(m.id);
  return m;
}

// ---- 1. three routes to the same schema ------------------------------------------------------------------------------------------------------
const freshSignature = schemaSignature();
{
  { const i = EXPECTED_MIGRATIONS.indexOf(V0029); assert.ok(i >= 0); assert.deepEqual(EXPECTED_MIGRATIONS.slice(i, i + 2), [V0029, V0030], 'the expected set has 0029 then 0030, in order'); }
  assert.equal(new Set(EXPECTED_MIGRATIONS).size, EXPECTED_MIGRATIONS.length, 'no migration is listed twice');

  clearWorld(); plantCleanLegacy();
  rewindTo0028();
  assert.deepEqual(checkSchemaCompatibility(db).missing, [V0029, V0030], 'a 0028 database is exactly two migrations behind, by identity');
  const columns = db.prepare('PRAGMA table_info(attendance_sessions)').all().map((c) => c.name);
  assert.ok(!columns.includes('finalization_state'), 'sanity: really at 0028');
  const before = JSON.parse(dataSnapshot());
  migrate();
  const after = JSON.parse(dataSnapshot());
  for (const key of ['visitors', 'members', 'visits', 'records', 'history']) assert.deepEqual(after[key], before[key], `0028 -> 0030 leaves ${key} untouched`);
  assert.deepEqual(after.sessions.map((s) => s.id), before.sessions.map((s) => s.id));
  assert.deepEqual(db.prepare('SELECT version FROM schema_migrations WHERE version IN (?, ?) ORDER BY version').all(V0029, V0030).map((r) => r.version), [V0029, V0030]);
  assert.deepEqual(checkSchemaCompatibility(db).missing ?? [], []);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_expected').get().n, 0, '0029 added its empty snapshot table');
  assert.deepEqual(db.pragma('foreign_key_check'), [], 'no foreign key violation after the chain');

  // a clean 0029 database
  rewindTo0029();
  const clean0029 = dataSnapshot();
  migrate();
  assert.ok(has0030());
  assert.equal(JSON.stringify(JSON.parse(dataSnapshot()).visitors), JSON.stringify(JSON.parse(clean0029).visitors));

  // the table objects (not row data) of all routes agree
  const normalise = (sig) => JSON.parse(sig).filter((o) => /visitor_membership_reviews|trg_visitors|trg_members_delete|idx_visitors_member_unique|uniq_open_review|idx_membership_reviews/.test(o.name)).map((o) => `${o.type}:${o.name}:${String(o.sql).replace(/\s+/g, ' ')}`);
  assert.deepEqual(normalise(schemaSignature()), normalise(freshSignature), 'a database that came through 0028 -> 0029 -> 0030 has exactly the same 0030 objects as a fresh one');
  console.log('PASS (1) fresh, 0028->0029->0030 and clean 0029->0030 all reach the same 0030 schema; existing rows are never touched; expected-set checking names exactly what is missing');
}

// ---- 2. idempotence ------------------------------------------------------------------------------------------------------------------------
{
  const sig = schemaSignature(); const data = dataSnapshot();
  for (let i = 0; i < 4; i += 1) migrate();
  assert.equal(schemaSignature(), sig, 'four more runs leave the schema byte-identical');
  assert.equal(dataSnapshot(), data, 'and the data');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get(V0030).n, 1, 'one migration row');
  console.log('PASS (2) re-running migrate() any number of times changes nothing');
}

// ---- 3. every unsafe shape is refused, nothing changes ------------------------------------------------------------------------------------------
const planters = {
  'joined without a member': () => rawVisitor('Bad-A', 'joined', null),
  'linked to a member but not joined': () => rawVisitor('Bad-B', 'returning', createMember({ first_name: 'LB', last_name: 'M' }, { status: 'active' }).id),
  'two First Timers on one member': () => { const m = createMember({ first_name: 'SM', last_name: 'M' }, { status: 'active' }); rawVisitor('Bad-C1', 'joined', m.id); return rawVisitor('Bad-C2', 'joined', m.id); },
  'a link to a member that does not exist': () => { db.pragma('foreign_keys = OFF'); const id = rawVisitor('Bad-D', 'joined', 987654); db.pragma('foreign_keys = ON'); return id; },
  'several kinds at once': () => { rawVisitor('Bad-E1', 'joined', null); const m = createMember({ first_name: 'ME', last_name: 'M' }, { status: 'active' }); return rawVisitor('Bad-E2', 'new', m.id); }
};
for (const [label, plant] of Object.entries(planters)) {
  rewindTo0029(); clearWorld(); plantCleanLegacy();
  const badId = plant();
  const before = dataSnapshot();
  assert.ok(findFirstTimerLinkProblems(db).total > 0, `${label}: the gate sees it`);
  let refusal = null;
  try { migrate(); } catch (err) { refusal = err; }
  assert.ok(refusal instanceof MigrationRefusedError, `${label}: refused with the dedicated error`);
  assert.match(refusal.diagnostic, new RegExp(`\\b${badId}\\b`), `${label}: names visitor ${badId}`);
  assert.equal(has0030(), false, `${label}: nothing of 0030 exists afterwards`);
  assert.equal(dataSnapshot(), before, `${label}: not one row was changed or "repaired"`);
  assert.deepEqual(checkSchemaCompatibility(db).missing, [V0030], `${label}: the database is still exactly one behind`);
}
console.log('PASS (3) joined-without-member, member-without-joined, shared member, dangling member and mixed damage each refuse the migration, name the rows, and change nothing');

// ---- 4. failure injected at three points ---------------------------------------------------------------------------------------------------------
{
  rewindTo0029(); clearWorld(); plantCleanLegacy();
  const snapshot = dataSnapshot();

  // (a) BEFORE the transaction: the gate refuses (covered above); an unreadable state is also a refusal, not a half-run
  // (b) INSIDE the transaction: a statement that cannot succeed. An index name that already belongs to a TABLE makes CREATE INDEX fail
  // after the review table and its first unique index have been created.
  db.exec('CREATE TABLE idx_membership_reviews_status (x INTEGER)');
  let failure = null;
  try { migrate(); } catch (err) { failure = err; }
  assert.ok(failure && !(failure instanceof MigrationRefusedError), 'the injected failure surfaces as a real error, not a refusal');
  assert.equal(names('table').includes(OBJECTS.table), false, 'the review table created earlier in the same transaction was rolled back');
  assert.equal(names('index').includes('uniq_open_review_per_visitor'), false, 'and so was its unique index');
  assert.deepEqual(OBJECTS.triggers.filter((t) => names('trigger').includes(t)), [], 'no trigger was left');
  assert.equal(Boolean(db.prepare("SELECT 1 FROM permissions WHERE key = 'visitors.express_register'").get()), false, 'no permission was left');
  assert.equal(Boolean(db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(V0030)), false, 'and the migration is NOT recorded as applied');
  db.exec('DROP TABLE idx_membership_reviews_status');
  assert.equal(dataSnapshot(), snapshot, 'no data changed by the failed attempt');
  migrate();
  assert.ok(has0030(), 'after the cause is removed the very next run applies cleanly');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get(V0030).n, 1);

  // (c) AFTER the transaction: the work is done but recording it fails. The schema is complete; a re-run must finish without error.
  rewindTo0029();
  db.exec(`CREATE TRIGGER fx_record BEFORE INSERT ON schema_migrations WHEN NEW.version = '${V0030}' BEGIN SELECT RAISE(ABORT, 'injected failure'); END`);
  assert.throws(() => migrate(), /injected failure/);
  assert.ok(names('table').includes(OBJECTS.table), 'the transaction had committed (so the schema is complete)');
  assert.equal(Boolean(db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(V0030)), false, 'but it is not recorded');
  assert.deepEqual(checkSchemaCompatibility(db).missing, [V0030], 'so the portal would still call it behind and refuse to start (safe)');
  db.exec('DROP TRIGGER fx_record');
  assert.doesNotThrow(() => migrate(), 're-running over a completed-but-unrecorded 0030 finishes without error (everything is IF NOT EXISTS)');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get(V0030).n, 1);
  assert.deepEqual(checkSchemaCompatibility(db).missing ?? [], []);
  console.log('PASS (4) a failure inside the transaction rolls everything back and leaves no row recorded; one after it leaves a complete, unrecorded schema; the next run recovers in both cases');
}

// ---- 5. triggers and keys once the migration is in ---------------------------------------------------------------------------------------------
{
  clearWorld();
  const a = createMember({ first_name: 'Anna', last_name: 'Active' }, { status: 'active' });
  const v = visitors.createVisitor({ first_name: 'Vic', last_name: 'T', first_visit_date: '2026-01-02' }, { userId: null });
  assert.equal(visitors.linkVisitorToMember(v.id, a.id, { userId: null }).ok, true);

  // ordinary updates are not caught
  assert.doesNotThrow(() => db.prepare("UPDATE visitors SET follow_up_state = 'contacted', follow_up_notes = 'n', updated_at = 'y', phone = '+974 1', email = 'e@x', notes = 'n' WHERE id = ?").run(v.id), 'ordinary visitor columns update freely even when joined');
  const solo = visitors.createVisitor({ first_name: 'Solo', last_name: 'T', first_visit_date: '2026-01-02' }, { userId: null });
  for (const state of ['returning', 'not_returned', 'declined', 'new']) assert.doesNotThrow(() => db.prepare('UPDATE visitors SET state = ? WHERE id = ?').run(state, solo.id), `state ${state} is a normal change`);
  assert.doesNotThrow(() => db.prepare("UPDATE members SET phone = '+974 2', notes = 'n', address = 'a' WHERE id = ?").run(a.id), 'ordinary member updates are not caught');
  assert.doesNotThrow(() => changeStatus(a.id, 'inactive', { userId: null, reason: 'test' }), 'deactivating a linked member is fine');
  assert.doesNotThrow(() => changeStatus(a.id, 'active', { userId: null, reason: 'test' }), 'and so is reactivating');
  assert.equal(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(v.id).member_id, a.id, 'the link survives a status round trip');

  // deletion
  assert.throws(() => db.prepare('DELETE FROM members WHERE id = ?').run(a.id), /cannot be deleted/, 'a linked member cannot be deleted');
  const free = createMember({ first_name: 'Free', last_name: 'M' }, { status: 'active' });
  assert.doesNotThrow(() => db.prepare('DELETE FROM members WHERE id = ?').run(free.id), 'an unlinked member can be');
  // deleting the visitor first releases the member
  db.prepare('DELETE FROM visitors WHERE id = ?').run(v.id);
  assert.doesNotThrow(() => db.prepare('DELETE FROM members WHERE id = ?').run(a.id), 'once the First Timer is gone the member can be deleted');

  // review table keys
  const w = visitors.createVisitor({ first_name: 'Rev', last_name: 'T', first_visit_date: '2026-01-02' }, { userId: null });
  const sessionId = Number(db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES ('2026-02-06', 'friday_service', 'F', 'held', 1, 0, 'x')").run().lastInsertRowid);
  const reviewId = Number(db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_session_id, trigger_service_date, window_json) VALUES (?, 'open', 'x', ?, '2026-02-06', '{\"fridays\":[1,2,3,4]}')").run(w.id, sessionId).lastInsertRowid);
  db.prepare('DELETE FROM attendance_sessions WHERE id = ?').run(sessionId);
  assert.equal(db.prepare('SELECT trigger_session_id FROM visitor_membership_reviews WHERE id = ?').get(reviewId).trigger_session_id, null, 'deleting the triggering service keeps the review (SET NULL)');
  const m2 = createMember({ first_name: 'Closer', last_name: 'M' }, { status: 'active' });
  db.prepare("UPDATE visitor_membership_reviews SET status = 'linked', closed_at = 'x', member_id = ? WHERE id = ?").run(m2.id, reviewId);
  db.prepare('DELETE FROM members WHERE id = ?').run(m2.id);
  assert.equal(db.prepare('SELECT member_id FROM visitor_membership_reviews WHERE id = ?').get(reviewId).member_id, null, 'deleting the member keeps the closed review (SET NULL)');
  assert.throws(() => db.prepare("UPDATE visitor_membership_reviews SET status = 'weird' WHERE id = ?").run(reviewId), /CHECK/, 'only the four statuses exist');
  assert.throws(() => db.prepare("UPDATE visitor_membership_reviews SET status = 'open' WHERE id = ?").run(reviewId), /CHECK/, 'open with a closing time is refused');
  db.prepare('DELETE FROM visitors WHERE id = ?').run(w.id);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_membership_reviews WHERE id = ?').get(reviewId).n, 0, 'deleting the First Timer deletes their reviews (CASCADE)');
  assert.deepEqual(db.pragma('foreign_key_check'), []);
  console.log('PASS (5) the guards catch only what they should; member status changes and ordinary edits are unaffected; delete rules and the review keys (SET NULL / CASCADE / CHECK) behave as designed');
}

// ---- 6. the restore path: a 0030 database is not mistaken for an older one ----------------------------------------------------------------------
{
  const compat = checkSchemaCompatibility(db);
  assert.equal(compat.ok, true);
  db.exec("INSERT INTO schema_migrations (version, applied_at) VALUES ('0031_future', 'x')");
  const ahead = checkSchemaCompatibility(db);
  assert.equal(ahead.ok, false); assert.ok(ahead.unexpected.includes('0031_future'), 'a database ahead of this code is recognised as ahead');
  db.exec("DELETE FROM schema_migrations WHERE version = '0031_future'");
  assert.equal(checkSchemaCompatibility(db).ok, true);
  void fs; void os; void path; void env;
  console.log('PASS (6) the compatibility check recognises a complete 0030 database and a database ahead of it');
}

console.log('ALL PASS');
