import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ejs from 'ejs';

/*
 * Templates and stylesheet stay consistent with each other and with the code that renders them:
 *   1. every template compiles;
 *   2. every res.render('x') and every include('x') names a template that exists;
 *   3. every template is used (rendered, included, or a layout) - no orphans;
 *   4. every literal class name used in a template is defined in the stylesheet, or is a known styling-free hook (listed below with
 *      its reason) - so a typo such as grid--two (which silently lost a two-column layout) is caught;
 *   5. unescaped output (<%-) is only ever an include, the layout body, a sort-link helper that builds links from URLSearchParams,
 *      or the JSON data block - never a bare variable from a record.
 */

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const walk = (dir, ext) => fs.readdirSync(path.join(root, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name), ext) : e.name.endsWith(ext) ? [path.join(dir, e.name).split(path.sep).join('/')] : []));

const views = walk('views', '.ejs');
const viewNames = new Set(views.map((v) => v.replace(/^views\//, '').replace(/\.ejs$/, '')));

// 1. compile
for (const file of views) {
  try { ejs.compile(read(file), { filename: path.join(root, file), compileDebug: false }); } catch (err) { assert.fail(`${file} does not compile: ${err.message.split('\n')[0]}`); }
}

// 2. every render / include target exists
const sources = [...walk('routes', '.js'), ...walk('services', '.js'), ...walk('lib', '.js'), ...walk('middleware', '.js'), 'server-app.js'];
const rendered = new Set();
const missing = [];
for (const file of sources) {
  // res.render('x') and res.render(flag ? 'x' : 'y')
  for (const m of read(file).matchAll(/\.render\(\s*(?:[\w.]+\s*\?\s*)?['"`]([\w./-]+)['"`](?:\s*:\s*['"`]([\w./-]+)['"`])?/g)) {
    for (const name of [m[1], m[2]].filter(Boolean)) { rendered.add(name); if (!viewNames.has(name)) missing.push(`${file} renders "${name}"`); }
  }
}
const included = new Set();
for (const file of views) {
  const dir = path.posix.dirname(file.replace(/^views\//, ''));
  for (const m of read(file).matchAll(/include\(\s*['"]([\w./-]+)['"]/g)) {
    const target = path.posix.normalize(path.posix.join(dir, m[1]));
    included.add(target);
    if (!viewNames.has(target)) missing.push(`${file} includes "${m[1]}"`);
  }
}
assert.deepEqual(missing, [], 'every rendered or included template exists');

// 3. no orphan templates
const layouts = [...viewNames].filter((n) => n.startsWith('layouts/'));
const dynamicRenders = read('server-app.js') + read('middleware/errors.js');
const orphans = [...viewNames].filter((n) => !rendered.has(n) && !included.has(n) && !layouts.includes(n) && !dynamicRenders.includes(`'${n}'`));
assert.deepEqual(orphans, [], 'every template is rendered, included or a layout');

// 4. literal classes exist in the stylesheet
const css = read('public/css/cciq.css').replace(/\/\*[\s\S]*?\*\//g, '');
const defined = new Set([...css.matchAll(/\.([A-Za-z_][\w-]*)/g)].map((m) => m[1]));
const HOOKS = {
  'leader-list': 'hook on the About editor list (styled through .list)', quick: 'root of the public quick-view fragment', 'profile-photo': 'anchor target and styling hook on My Profile',
  'list--plain': 'modifier with no extra styling', 'register-table-wrap': 'hook for the register script',
  'auth__kiosk-link': 'sign-in page hook', 'about-link': 'sign-in page hook', 'form-section__fields': 'grouping hook on the document form',
  'dropzone__file': 'hook on the document upload field', 'doc-preview': 'hook on the document preview card', 'members-summary': 'hook for the members count line',
  'members-scope': 'hook for the members scope line', relative: 'hook used by the relative-picker script', 'relative__mode': 'hook used by the relative-picker script',
  'relative__pane': 'hook used by the relative-picker script', column: 'layout word in a comment-like attribute'
};
const unknown = new Set();
for (const file of views) {
  // Markup only: template code (which may build HTML strings) is removed first; a class attribute that mixes literal and computed
  // words keeps just its literal words, since the computed modifiers are composed at run time.
  const markup = read(file).replace(/<%[\s\S]*?%>/g, ' ');
  for (const m of markup.matchAll(/\bclass="([^"]*)"/g)) {
    for (const c of m[1].split(/\s+/).filter(Boolean)) if (!defined.has(c) && !HOOKS[c] && !/^(js-|u-)/.test(c) && !/-$/.test(c)) unknown.add(`${c}  (${file})`);
  }
}
assert.deepEqual([...unknown], [], 'every literal class in a template is defined in the stylesheet (or is a listed hook)');
const staleHooks = Object.keys(HOOKS).filter((c) => !views.some((v) => new RegExp(`class="[^"]*\\b${c}\\b`).test(read(v))));
assert.deepEqual(staleHooks, [], 'and the hook list has no entry that no template uses any more');

// 5. unescaped output
const allowed = [/^include\(/, /^body$/, /^\w*[sS]ortLink\(/, /^JSON\.stringify\(registerData\)/, /^isSeveral \? '' : 'aria-current="page"'$/, /^isSeveral \? 'aria-current="page"' : ''$/, /^s\.key === section \? 'aria-current="page"' : ''$/, /^status === t \? 'aria-current="page"' : ''$/];
const bad = [];
for (const file of views) {
  for (const m of read(file).matchAll(/<%-\s*([\s\S]*?)\s*%>/g)) {
    const expr = m[1].trim();
    if (!allowed.some((re) => re.test(expr))) bad.push(`${file}: <%- ${expr.slice(0, 60)} %>`);
  }
}
assert.deepEqual(bad, [], 'unescaped output is only includes, the layout body, sort-link helpers, constant attributes and the JSON data block');
const helperBodies = views.filter((v) => /SortLink\s*=\s*function/.test(read(v)));
for (const file of helperBodies) {
  const text = read(file);
  for (const m of text.matchAll(/SortLink\s*=\s*function[\s\S]*?\n\s*\};/g)) {
    assert.ok(!/href="[^"]*'\s*\+\s*(?:filters|search|query|req)\b/.test(m[0]), `${file}: a sort link never concatenates a raw filter value into its href (it uses URLSearchParams)`);
  }
}

// An escaped output (<%= %>) turns every quote into &#34;. An attribute built as a string inside one - <%= x ? 'aria-current="page"' : '' %> -
// therefore reaches the browser as aria-current=&#34;page&#34;, which is a different, invalid value. That is how a Documents upload form lost its
// enctype="multipart/form-data" (so no file was ever sent from a real browser) and how invalid fields were never marked aria-invalid. An attribute
// that is conditional is written as <% if (x) { %>aria-current="page"<% } %> instead.
{
  const offenders = [];
  for (const file of views) {
    for (const m of read(file).matchAll(/<%=([\s\S]*?)%>/g)) {
      if (/['"`][^'"`]*[A-Za-z-]+=\\?"[^'"`]*['"`]/.test(m[1])) offenders.push(`${file}: ${m[0].replace(/\s+/g, ' ').slice(0, 80)}`);
    }
  }
  assert.deepEqual(offenders, [], 'no escaped output builds a quoted attribute (it would reach the browser as an invalid, entity-encoded value)');
}

console.log(`PASS (templates) ${views.length} templates compile; every render/include target exists; none is orphaned; literal classes are all defined; unescaped output is limited to ${allowed.length} audited shapes`);
console.log('ALL PASS');
