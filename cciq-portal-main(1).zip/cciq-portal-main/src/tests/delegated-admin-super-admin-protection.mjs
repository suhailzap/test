import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness, R08 from the red-team review: /admin/users/:id/status
 * and /admin/users/:id/password were gated only by requirePermission
 * ('admin.users'), with no check comparing the actor's own rank to the
 * target's roles — unlike granting/removing the super_admin role itself,
 * which already correctly requires the actor to be a Super Admin.
 * admin.users is not in church_admin's default bundle, so this was not
 * exploitable out of the box, but became live the moment an owner
 * delegated admin.users to any non-Super-Admin role (a plausible, even
 * encouraged, delegation — "let the office administrator manage staff
 * accounts without full Super Admin"). Fixed via a centralized
 * isSuperAdmin() check reused across both routes, mirroring the existing
 * role-change protection.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-delegated-admin-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser, setRolePermissions, getRoleByKey, permissionsForRole } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

// Simulate the owner delegating admin.users to church_admin (a plausible,
// even encouraged, narrower-than-Super-Admin delegation), without touching
// the fixed super_admin role's own permission set.
const churchAdminRole = getRoleByKey('church_admin');
const existingPermissions = permissionsForRole(churchAdminRole.id).map((p) => p.key);
setRolePermissions(churchAdminRole.id, [...existingPermissions, 'admin.users']);

const superAdminId = await createUser({
  email: 'r08.superadmin@fixture.invalid', password: 'SuperPassw0rd!2026',
  displayName: 'R08 Super Admin', roleKeys: ['super_admin'], mustChangePassword: false
});
const delegatedAdminId = await createUser({
  email: 'r08.delegated@fixture.invalid', password: 'DelegatedPassw0rd!2026',
  displayName: 'R08 Delegated Admin', roleKeys: ['church_admin'], mustChangePassword: false
});
const ordinaryUserId = await createUser({
  email: 'r08.ordinary@fixture.invalid', password: 'OrdinaryPassw0rd!2026',
  displayName: 'R08 Ordinary User', roleKeys: ['member'], mustChangePassword: false
});

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

async function login(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  assert.equal(loginPost.status, 302, `login must succeed for ${email}`);
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preCookie;
}

async function csrfFor(urlPath, cookie) {
  const page = await fetch(`${base}${urlPath}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

const delegatedCookie = await login('r08.delegated@fixture.invalid', 'DelegatedPassw0rd!2026');

function currentHash(userId) {
  return db.prepare('SELECT password_hash FROM users WHERE id = ?').get(userId).password_hash;
}
function currentStatus(userId) {
  return db.prepare('SELECT status FROM users WHERE id = ?').get(userId).status;
}

// --- 1. Delegated admin.users holder CANNOT reset the Super Admin's password. ---
{
  const before = currentHash(superAdminId);
  const csrf = await csrfFor(`/admin/users/${superAdminId}`, delegatedCookie);
  const res = await fetch(`${base}/admin/users/${superAdminId}/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ password: 'AttackerChosenPassw0rd!2026', _csrf: csrf })
  });
  assert.equal(res.status, 302, 'the request should redirect with an error, not crash');
  assert.equal(currentHash(superAdminId), before,
    'R08 CONFIRMED FIXED: a delegated non-Super-Admin admin.users holder must not be able to reset a Super Admin\'s password');
  console.log('PASS: a delegated admin.users holder cannot reset a Super Admin\'s password');
}

// --- 2. Delegated admin.users holder CANNOT disable the Super Admin. ---
{
  const csrf = await csrfFor(`/admin/users/${superAdminId}`, delegatedCookie);
  const res = await fetch(`${base}/admin/users/${superAdminId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ status: 'disabled', _csrf: csrf })
  });
  assert.equal(res.status, 302);
  assert.equal(currentStatus(superAdminId), 'active',
    'R08 CONFIRMED FIXED: a delegated non-Super-Admin admin.users holder must not be able to disable a Super Admin account');
  console.log('PASS: a delegated admin.users holder cannot disable a Super Admin account');
}

// --- 2b. Codex/independent verification found three further gaps in the
//     same permission boundary, each in a route the first pass's
//     role-toggle-specific and status-disable-specific checks never
//     covered: reactivating an already-disabled Super Admin, editing a
//     Super Admin's profile (display name/email), and unlocking a Super
//     Admin's account. Fixed by centralizing into refuseIfProtectedTarget(),
//     applied uniformly to every mutation route rather than a bespoke
//     condition per route. ---
// A SECOND Super Admin performs setup/cleanup actions across the blocks
// below - superAdminId acting on itself would either hit the unrelated,
// pre-existing self-deactivation guard, or (for the unlock cleanup) simply
// fail to log in because the target account is deliberately locked at that
// point. Declared here, outside any single block, so every block below can
// reuse the same already-authenticated session.
const setupSuperAdminId = await createUser({
  email: 'r08.setupsuperadmin@fixture.invalid', password: 'SetupSuperPassw0rd!2026',
  displayName: 'R08 Setup Super Admin', roleKeys: ['super_admin'], mustChangePassword: false
});
const superCookieSetup = await login('r08.setupsuperadmin@fixture.invalid', 'SetupSuperPassw0rd!2026');

{
  const setupCsrf = await csrfFor(`/admin/users/${superAdminId}`, superCookieSetup);
  const disableRes = await fetch(`${base}/admin/users/${superAdminId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: superCookieSetup },
    body: new URLSearchParams({ status: 'disabled', _csrf: setupCsrf })
  });
  assert.equal(disableRes.status, 302);
  assert.equal(currentStatus(superAdminId), 'disabled', 'sanity: a genuine Super Admin can disable another Super Admin');

  // A fresh delegated-admin login, since the target account (which shares
  // no relation to the delegated admin's own session) is now disabled -
  // the delegated admin's own account and session are unaffected.
  const csrfReactivate = await csrfFor(`/admin/users/${superAdminId}`, delegatedCookie);
  const reactivateRes = await fetch(`${base}/admin/users/${superAdminId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ status: 'active', _csrf: csrfReactivate })
  });
  assert.equal(reactivateRes.status, 302);
  assert.equal(currentStatus(superAdminId), 'disabled',
    'CODEX FINDING CONFIRMED FIXED: a delegated non-Super-Admin admin.users holder must not be able to reactivate a disabled Super Admin');
  console.log('PASS: a delegated admin.users holder cannot reactivate a disabled Super Admin');

  // Restore for the remaining tests below.
  const restoreCsrf = await csrfFor(`/admin/users/${superAdminId}`, superCookieSetup);
  await fetch(`${base}/admin/users/${superAdminId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: superCookieSetup },
    body: new URLSearchParams({ status: 'active', _csrf: restoreCsrf })
  });
  assert.equal(currentStatus(superAdminId), 'active', 'sanity: restored for the remaining tests');
}

{
  const before = db.prepare('SELECT display_name, email FROM users WHERE id = ?').get(superAdminId);
  const csrf = await csrfFor(`/admin/users/${superAdminId}`, delegatedCookie);
  const res = await fetch(`${base}/admin/users/${superAdminId}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({
      display_name: 'HIJACKED NAME', email: 'attacker-controlled@fixture.invalid', roles: 'super_admin', _csrf: csrf
    })
  });
  assert.equal(res.status, 302, 'the request itself should redirect cleanly with an error, not crash');
  const after = db.prepare('SELECT display_name, email FROM users WHERE id = ?').get(superAdminId);
  assert.deepEqual(after, before,
    'CODEX FINDING CONFIRMED FIXED: a delegated non-Super-Admin admin.users holder must not be able to edit a Super Admin\'s profile (display name/email), even leaving the role checkbox unchanged');
  console.log('PASS: a delegated admin.users holder cannot edit a Super Admin\'s profile');
}

{
  db.prepare('UPDATE users SET failed_attempts = 5, locked_until = ? WHERE id = ?').run(new Date(Date.now() + 900000).toISOString(), superAdminId);
  const csrf = await csrfFor(`/admin/users/${superAdminId}`, delegatedCookie);
  const res = await fetch(`${base}/admin/users/${superAdminId}/unlock`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ _csrf: csrf })
  });
  assert.equal(res.status, 302);
  const stillLocked = db.prepare('SELECT failed_attempts, locked_until FROM users WHERE id = ?').get(superAdminId);
  assert.equal(stillLocked.failed_attempts, 5,
    'CODEX FINDING CONFIRMED FIXED: a delegated non-Super-Admin admin.users holder must not be able to unlock a Super Admin account');
  assert.ok(stillLocked.locked_until, 'the lock must still be in place');
  console.log('PASS: a delegated admin.users holder cannot unlock a Super Admin account');

  // A genuine Super Admin can still unlock it, for cleanup and as a
  // regression check that the shared guard doesn't over-restrict. This must
  // be a DIFFERENT Super Admin account: superAdminId itself is currently
  // locked, so logging back into it would legitimately fail with 401 and
  // prove nothing about the unlock route's authorization logic.
  const csrf2 = await csrfFor(`/admin/users/${superAdminId}`, superCookieSetup);
  const unlockRes = await fetch(`${base}/admin/users/${superAdminId}/unlock`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: superCookieSetup },
    body: new URLSearchParams({ _csrf: csrf2 })
  });
  assert.equal(unlockRes.status, 302);
  const unlocked = db.prepare('SELECT failed_attempts, locked_until FROM users WHERE id = ?').get(superAdminId);
  assert.equal(unlocked.failed_attempts, 0, 'a genuine Super Admin must still be able to unlock a Super Admin account');
  console.log('PASS: a genuine Super Admin can still unlock a Super Admin account');
}

// --- 3. Legitimate delegation preserved: the same delegated admin CAN still manage an ordinary user. ---
{
  const before = currentHash(ordinaryUserId);
  const csrf = await csrfFor(`/admin/users/${ordinaryUserId}`, delegatedCookie);
  const res = await fetch(`${base}/admin/users/${ordinaryUserId}/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ password: 'LegitimateReset!2026', _csrf: csrf })
  });
  assert.equal(res.status, 302);
  assert.notEqual(currentHash(ordinaryUserId), before,
    'a delegated admin.users holder must still be able to manage an ordinary (non-Super-Admin) account');

  const csrf2 = await csrfFor(`/admin/users/${ordinaryUserId}`, delegatedCookie);
  const disableRes = await fetch(`${base}/admin/users/${ordinaryUserId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: delegatedCookie },
    body: new URLSearchParams({ status: 'disabled', _csrf: csrf2 })
  });
  assert.equal(disableRes.status, 302);
  assert.equal(currentStatus(ordinaryUserId), 'disabled', 'a delegated admin.users holder must still be able to disable an ordinary account');
  console.log('PASS: legitimate delegation is preserved — the delegated admin can still manage an ordinary user account');
}

// --- 4. Last-Super-Admin / self-protection rules are untouched (reuse of existing guarantees). ---
{
  // Only one super_admin exists in this fixture; even a genuine Super Admin
  // cannot be blocked from managing themselves in a way that breaks
  // countUsersWithPermission's own separate "last admin.users holder"
  // guard — that guard is pre-existing and covered by its own logic; this
  // just confirms the new check does not interfere with a Super Admin
  // acting on their own account (self-deactivation is still refused by the
  // pre-existing, separate self-protection rule, not this new one).
  const superCookie = await login('r08.superadmin@fixture.invalid', 'SuperPassw0rd!2026');
  const csrf = await csrfFor(`/admin/users/${superAdminId}`, superCookie);
  const res = await fetch(`${base}/admin/users/${superAdminId}/status`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: superCookie },
    body: new URLSearchParams({ status: 'disabled', _csrf: csrf })
  });
  assert.equal(res.status, 302);
  assert.equal(currentStatus(superAdminId), 'active', 'self-deactivation must still be refused, by the pre-existing rule, unaffected by this fix');
  console.log('PASS: pre-existing self-protection and last-admin protections are unaffected by the new Super Admin target check');
}

// --- 5. A genuine Super Admin CAN still reset/disable another Super Admin (not over-restricted). ---
{
  const otherSuperAdminId = await createUser({
    email: 'r08.othersuper@fixture.invalid', password: 'OtherSuperPassw0rd!2026',
    displayName: 'R08 Other Super Admin', roleKeys: ['super_admin'], mustChangePassword: false
  });
  const superCookie = await login('r08.superadmin@fixture.invalid', 'SuperPassw0rd!2026');
  const before = currentHash(otherSuperAdminId);
  const csrf = await csrfFor(`/admin/users/${otherSuperAdminId}`, superCookie);
  const res = await fetch(`${base}/admin/users/${otherSuperAdminId}/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: superCookie },
    body: new URLSearchParams({ password: 'LegitimateSuperReset!2026', _csrf: csrf })
  });
  assert.equal(res.status, 302);
  assert.notEqual(currentHash(otherSuperAdminId), before, 'a genuine Super Admin must still be able to reset another Super Admin\'s password');
  console.log('PASS: a genuine Super Admin is not over-restricted from managing another Super Admin');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
