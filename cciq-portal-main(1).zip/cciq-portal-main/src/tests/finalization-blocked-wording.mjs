import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * A Friday whose expected list cannot be built (people the portal cannot place on that date) stays blocked - the safety rule is unchanged - but the page now says so in plain words:
 *   - no internal code (created_after_service and the like) is shown;
 *   - it says why finalization is blocked, why there is no Finalize button, and what to do next;
 *   - a member who genuinely joined after the service is resolved by a recorded Date joined (never by guessing), and a member created after the service is never counted absent.
 */

const f = await buildPortalFixture('cciq-finalize-wording-');
const { db, users, mods } = f;
const lifecycle = await import('../services/attendance-lifecycle.js');
const { today, addDays, lastFridayOnOrBefore } = mods.dates;
const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -400);
const atNoon = (d) => `${d}T09:00:00.000Z`;

db.exec('DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions;');
// every member the fixture made is created "today"; make all but two long-standing, so the two that remain are exactly the people created after the service
const late = db.prepare('SELECT id FROM members ORDER BY id LIMIT 2').all().map((m) => m.id);
for (const m of db.prepare('SELECT id, status FROM members').all()) {
  if (late.includes(m.id)) continue;
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id); db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, m.status, 'planted', atNoon(OLD));
}
for (const id of late) { // created two Fridays after the service we test
  db.prepare('UPDATE members SET created_at = ?, date_joined = NULL WHERE id = ?').run(atNoon(W(-1)), id);
  db.prepare('UPDATE member_status_history SET changed_at = ? WHERE member_id = ?').run(atNoon(W(-1)), id);
}
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(-3), atNoon(W(-3)));
const sessionId = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ?").get(W(-3)).id;
assert.equal(lifecycle.setTrackingStartDate(W(-3), { userId: users.superAdmin.id }).ok, true);
mods.attendance.recordAttendance(sessionId, [{ memberId: db.prepare('SELECT id FROM members WHERE id NOT IN (?, ?) ORDER BY id LIMIT 1').get(...late).id, status: 'present' }], { userId: users.churchAdmin.id });

// the rule itself is unchanged: the people created after the service block it, and are not counted anywhere
const preview = lifecycle.previewFinalization(sessionId);
assert.equal(preview.canFinalize, false); assert.equal(preview.ambiguous.length, 2);
assert.deepEqual(preview.ambiguous.map((a) => a.reason).sort(), ['created_after_service', 'created_after_service'], 'the code stays on the data for tests and logs');
assert.ok(preview.ambiguous.every((a) => /Created after this service/.test(a.reasonText) && /cannot be determined/.test(a.reasonText)), 'with a plain-language reason beside it');
assert.equal(lifecycle.finalizeAttendance(sessionId, { userId: users.superAdmin.id }).reason, 'ambiguous_history', 'finalization still fails closed');
assert.equal(db.prepare("SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?").get(sessionId).n, 0, 'and writes nothing');

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const flat = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&rsquo;/g, "'").replace(/&mdash;/g, '—').replace(/\s+/g, ' ');
  const html = await (await admin.get(`/attendance/sessions/${sessionId}/finalize`)).text();
  const text = flat(html);
  assert.match(text, /Finalization is blocked for this service/);
  assert.match(text, /2 members cannot be placed on this service's expected list/);
  assert.match(text, /Created after this service — historical attendance status cannot be determined\./, 'the reason in plain words');
  assert.ok(!/created_after_service|history_inconsistent|status history is unclear/.test(html), 'no internal code and no jargon heading on the page');
  assert.match(text, /Why there is no Finalize button/); assert.match(text, /What to do next/);
  assert.match(text, /Date joined CCIQ/); assert.match(text, /Attendance not taken/); assert.match(text, /Attendance Tracking Start Date/, 'a Super Admin is told about the start date');
  assert.doesNotMatch(html, /action="[^"]*\/finalize"/, 'still no Finalize button');
  const churchText = flat(await (await church.get(`/attendance/sessions/${sessionId}/finalize`)).text());
  assert.match(churchText, /What to do next/); assert.doesNotMatch(churchText, /Attendance Tracking Start Date/, 'a Church Admin is not pointed at the Super Admin control');
  const refusal = await church.post(`/attendance/sessions/${sessionId}/finalize`, {}, { csrfFrom: `/attendance/sessions/${sessionId}/finalize` }); await refusal.text();
  assert.equal(db.prepare('SELECT finalization_state FROM attendance_sessions WHERE id = ?').get(sessionId).finalization_state, null, 'a crafted finalize changes nothing');

  // the honest fix for someone who really joined later: record the date; they are then simply not expected, and are never counted absent
  for (const id of late) db.prepare('UPDATE members SET date_joined = ? WHERE id = ?').run(W(-1), id);
  const after = lifecycle.previewFinalization(sessionId);
  assert.equal(after.ambiguous.length, 0); assert.equal(after.canFinalize, true, 'with the date recorded the Finalize button returns');
  const fin = lifecycle.finalizeAttendance(sessionId, { userId: users.superAdmin.id });
  assert.equal(fin.ok, true);
  const snapshot = db.prepare('SELECT member_id FROM attendance_expected WHERE session_id = ?').all(sessionId).map((r) => r.member_id);
  assert.ok(late.every((id) => !snapshot.includes(id)), 'people who joined after the service are not on its expected list, so they can never be counted absent for it');
  console.log('PASS (blocked page) plain-language reasons, why there is no Finalize button, what to do next, no internal codes; the rule still fails closed; a recorded Date joined resolves it and the late joiners are never counted absent');
} finally { await portal.stop(); }
console.log('PASS finalization-blocked-wording');
