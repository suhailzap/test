import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * /healthz used to be a pure liveness check (process is running) with no
 * proof the database it depends on is actually usable — a locked, corrupt,
 * or disk-full SQLite file would still report "ok" forever. This confirms
 * two things: the happy path is unchanged (so waitForServerReady and any
 * future monitoring script keep working), and the exact query the new
 * check runs genuinely throws against a database that cannot answer it —
 * proving the catch branch is reachable, not just written.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-healthz-test-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { default: db } = await import('../db/index.js');

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

// --- 1. Happy path: unchanged shape, still 200. ---
const res = await fetch(`${base}/healthz`);
assert.equal(res.status, 200);
const body = await res.json();
assert.equal(body.status, 'ok');
assert.ok(body.startedAt);
assert.ok(body.assetVersion);
console.log('PASS: /healthz still returns 200 with the original ok/startedAt/assetVersion shape');

await terminateAndWait(server);
db.close();

// --- 2. The catch branch is reachable: the exact query /healthz now runs
//        must genuinely throw against a database that cannot serve it, not
//        return undefined or hang. Using a fresh, deliberately-broken file
//        rather than corrupting the live server's already-open (and
//        page-cached) database, which would be racy and unreliable to
//        force a real on-disk read failure against. ---
const { default: Database } = await import('better-sqlite3');
const brokenFile = path.join(env.root, 'broken.sqlite');
fs.writeFileSync(brokenFile, Buffer.from('not a valid sqlite file at all'));
const brokenDb = new Database(brokenFile);
assert.throws(
  () => brokenDb.prepare('SELECT version FROM schema_migrations LIMIT 1').get(),
  /file is not a database|not a database|no such table/i,
  'the exact query /healthz runs must throw against an unusable database file'
);
brokenDb.close();
console.log('PASS: the readiness query throws against a broken database, so /healthz\'s catch branch is genuinely reachable');

env.cleanup();
console.log('ALL PASS');
