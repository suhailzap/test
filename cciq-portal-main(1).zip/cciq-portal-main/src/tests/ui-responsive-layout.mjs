import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Source UX checks in a real browser (disposable database, disposable server):
 *   - the sidebar brand and account area stay pinned while only the navigation scrolls
 *     (desktop sidebar and mobile drawer checked separately), with exactly ONE Sign out;
 *   - no page-level horizontal overflow at the standard widths on the pages this UX work touched.
 * No attendance or business semantics are exercised here.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-ui-layout-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const { createGroup, assignMemberToGroup } = await import('../services/cell-groups.js');
const { OVERFLOW_CHECK_SCRIPT } = await import('../../tools/check-overflow.mjs');
const { default: db } = await import('../db/index.js');
const { lastFridayOnOrBefore, today } = await import('../lib/dates.js');

const WIDTHS = [320, 375, 430, 768, 860, 861, 1024, 1280, 1440];
const PASSWORD = `Ui${crypto.randomBytes(12).toString('base64url')}9!`;

// A modest, realistic-shaped fixture population (all synthetic).
const admin = await createUser({ username: 'ui_admin', email: 'ui.admin@fixture.invalid', password: PASSWORD, displayName: 'UI Admin', roleKeys: ['super_admin'], mustChangePassword: false });
void admin;
const groups = [];
for (let g = 1; g <= 22; g += 1) groups.push(createGroup({ name: `Fixture Cell Group ${String(g).padStart(2, '0')}` }));
for (let i = 1; i <= 60; i += 1) {
  const member = createMember({ first_name: `Member${i}`, last_name: 'Fixture', cell_group_id: groups[i % groups.length].id }, { status: i % 9 === 0 ? 'inactive' : 'active' });
  void member;
}
for (let i = 1; i <= 40; i += 1) {
  await createUser({
    username: `ui_user_${i}`, email: `ui.user${i}@fixture.invalid`, password: PASSWORD,
    displayName: `UI User ${String(i).padStart(2, '0')}`, roleKeys: [i % 5 === 0 ? 'cell_group_leader' : 'member'], mustChangePassword: i % 7 === 0
  });
}
void assignMemberToGroup;
// A current Friday Service so the kiosk shows its scan/search card.
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)")
  .run(lastFridayOnOrBefore(today()), new Date().toISOString());

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
let browser;
try {
  await waitForServerReady(base, server);
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}/login`);
  await page.fill('#email', 'ui.admin@fixture.invalid');
  await page.fill('#password', PASSWORD);
  await Promise.all([page.waitForNavigation(), page.click('button[type="submit"]')]);

  const visible = (selector) => page.evaluate((sel) => Array.from(document.querySelectorAll(sel)).filter((el) => {
    const r = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  }).length, selector);

  // ---- 5A. Sidebar / brand ------------------------------------------------
  await page.goto(`${base}/`);
  for (const width of [861, 1024, 1280, 1440]) {
    await page.setViewportSize({ width, height: 460 }); // short: the navigation must scroll
    const report = await page.evaluate(() => {
      const side = document.querySelector('.sidenav');
      const nav = document.querySelector('.sidenav .nav');
      const topbar = document.querySelector('.topbar').getBoundingClientRect();
      nav.scrollTop = nav.scrollHeight;
      const brand = document.querySelector('.brand--stacked').getBoundingClientRect();
      const foot = document.querySelector('.sidenav__foot').getBoundingClientRect();
      return {
        sideScrolls: side.scrollHeight > side.clientHeight + 1,
        navScrolls: nav.scrollHeight > nav.clientHeight + 1,
        navScrolled: nav.scrollTop > 0,
        brandTop: brand.top, brandBottom: brand.bottom, topbarBottom: topbar.bottom,
        footBottom: foot.bottom, viewport: window.innerHeight
      };
    });
    assert.equal(report.sideScrolls, false, `${width}px: the sidebar itself does not scroll (only the navigation)`);
    assert.equal(report.navScrolls, true, `${width}px: the navigation scrolls on a short screen`);
    assert.equal(report.navScrolled, true);
    assert.ok(report.brandTop >= 0 && report.brandTop <= 4 && report.brandBottom > report.brandTop && report.brandBottom <= report.topbarBottom + 1, `${width}px: the brand is still visible, in the top row, after scrolling the navigation`);
    assert.ok(report.footBottom <= report.viewport + 1, `${width}px: the account area stays on screen`);
    assert.equal(await visible('.sidenav .brand--stacked'), 1);
    assert.equal(await visible('form[action="/logout"] button'), 1, `${width}px: exactly one Sign out`);
  }
  for (const width of [320, 375, 430, 768, 860]) {
    await page.setViewportSize({ width, height: 520 });
    await page.evaluate(() => document.body.classList.remove('drawer-open'));
    assert.equal(await visible('.brand--compact'), 1, `${width}px: the compact brand is in the fixed top bar`);
    await page.click('[data-drawer-toggle]');
    await page.waitForFunction(() => document.body.classList.contains('drawer-open'));
    const drawer = await page.evaluate(() => {
      const nav = document.querySelector('.sidenav .nav');
      nav.scrollTop = nav.scrollHeight;
      const foot = document.querySelector('.sidenav__foot').getBoundingClientRect();
      return { sideScrolls: document.querySelector('.sidenav').scrollHeight > document.querySelector('.sidenav').clientHeight + 1, footBottom: foot.bottom, viewport: window.innerHeight };
    });
    assert.equal(drawer.sideScrolls, false, `${width}px: the drawer itself does not scroll`);
    assert.ok(drawer.footBottom <= drawer.viewport + 1, `${width}px: Sign out stays reachable in the drawer`);
    assert.equal(await visible('form[action="/logout"] button'), 1, `${width}px: exactly one Sign out (drawer open)`);
    assert.equal(await visible('.brand--compact'), 1, `${width}px: the brand is still visible with the drawer open`);
    await page.evaluate(() => document.body.classList.remove('drawer-open'));
  }
  console.log('PASS (sidebar) brand and account area pinned while only the navigation scrolls; desktop and drawer checked separately; exactly one Sign out at every width');

  // ---- 5G. Kiosk: compact, but still a kiosk -----------------------------
  await page.goto(`${base}/kiosk`);
  await page.setViewportSize({ width: 1280, height: 800 });
  const kiosk = await page.evaluate(() => {
    const box = (sel) => { const el = document.querySelector(sel); if (!el) return null; const r = el.getBoundingClientRect(); return { w: r.width, h: r.height, top: r.top }; };
    return {
      input: box('#checkin-input'), lookup: box('#checkin-lookup'), search: box('#checkin-search-input'),
      searchButton: box('.kiosk__search-form .btn'), card: box('.kiosk__card'),
      focused: document.activeElement && document.activeElement.id, docHeight: document.documentElement.scrollHeight
    };
  });
  assert.equal(kiosk.focused, 'checkin-input', 'the scanner input still has focus on load');
  assert.ok(kiosk.input.h >= 48, `scan input is a real touch target (${kiosk.input.h}px)`);
  assert.ok(kiosk.lookup.h >= 44 && kiosk.searchButton.h >= 44, 'buttons keep at least 44px touch targets');
  assert.ok(kiosk.search.h >= 44, 'the name search field is large');
  assert.ok(kiosk.card.h <= 520, `the scan/search card is compact (${Math.round(kiosk.card.h)}px)`);
  assert.ok(kiosk.card.top + kiosk.card.h <= 800, 'and fits a 1280x800 screen without scrolling to reach search');
  assert.equal(await visible('a[href="/attendance/checkin"]'), 0, 'no redundant "Scan to check in" navigation item is offered on the kiosk');
  console.log('PASS (kiosk) compact card, scanner focus kept, 44px+ touch targets, fits a 1280x800 screen');

  // ---- Family: a relative shows only the identity that was chosen --------
  await page.goto(`${base}/members/new`);
  await page.setViewportSize({ width: 1280, height: 900 });
  const paneShown = (rel, pane) => page.evaluate(([r, p]) => {
    const el = document.querySelector(`[data-relative="${r}"] [data-relative-pane="${p}"]`);
    return !!el && el.getClientRects().length > 0;
  }, [rel, pane]);
  assert.equal(await paneShown('father', 'manual'), true, 'a new member starts on the typed name');
  assert.equal(await paneShown('father', 'linked'), false, 'the member picker stays hidden until chosen');
  await page.evaluate(() => { const r = document.querySelector('#father_mode_linked'); r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); });
  assert.equal(await paneShown('father', 'linked'), true, 'choosing CCIQ member reveals the picker');
  assert.equal(await paneShown('father', 'manual'), false, 'and hides the typed name');
  console.log('PASS (family) the parent form shows only the chosen identity (CCIQ member picker or typed name)');

  // ---- overflow on the pages this UX work touches ------------------------
  const PAGES = ['/members/new', '/my/profile', '/','/attendance', '/admin/users', '/cell-groups', '/ministries/serving', '/reports', '/members', '/kiosk',
    '/attendance/follow-up', '/attendance/long-absence', '/attendance/reports', '/reports/attendance',
    '/admin/settings?section=friday_service', '/admin/settings?section=attendance', '/admin/settings?section=branding', '/admin/about', '/admin/about/leaders/new'];
  for (const url of PAGES) {
    const res = await page.goto(`${base}${url}`);
    assert.equal(res.status(), 200, `${url} loads`);
    for (const width of WIDTHS) {
      await page.setViewportSize({ width, height: 900 });
      const result = await page.evaluate(OVERFLOW_CHECK_SCRIPT);
      assert.equal(result.overflow, false, `${url} @ ${width}px overflows: ${JSON.stringify(result.offenders)}`);
    }
  }
  console.log(`PASS (overflow) ${PAGES.length} pages x ${WIDTHS.length} widths without page-level horizontal overflow`);
  assert.deepEqual(errors, [], 'no page errors');
} finally {
  if (browser) await browser.close();
  await terminateAndWait(server);
}
console.log('ALL PASS');
