import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';
import { parsePaging, pageWindow, paginateList, serverPaged, pageSizeParam, queryString, paramsFromQueryString } from '../lib/paging.js';

/*
 * Second pass at paging: hostile page / page-size values thrown at every screen that pages, in every spelling the query string
 * allows. Whatever is asked, the answer is a normal page (never a server error, never "NaN", "undefined" or "Infinity"
 * on the page), the window is clamped into range, and a last page never shows a negative range.
 */

// ---- the pure functions ----------------------------------------------------------------------------------------------------------
const hostile = ['0', '-1', '-999999', '1.5', 'abc', '', '1e9', '99999999999999999999', '9'.repeat(400), '0x10', ' 2 ', '2,3', '+2', '٢', '[object Object]', 'NaN', 'Infinity', '-Infinity', undefined, null, ['1', '2'], { a: 1 }];
for (const value of hostile) {
  for (const key of ['page', 'page_size']) {
    const p = parsePaging({ [key]: value });
    assert.ok(Number.isInteger(p.page) && p.page >= 1, `page from ${key}=${JSON.stringify(value)} is a positive whole number (${p.page})`);
    assert.ok([25, 50, 100].includes(p.pageSize), `page size from ${key}=${JSON.stringify(value)} is one of the offered sizes (${p.pageSize})`);
    for (const total of [0, 1, 24, 25, 26, 101, 10000]) {
      const w = pageWindow({ total, ...p });
      assert.ok(Number.isSafeInteger(w.offset) && w.offset >= 0 && w.offset <= Math.max(total - 1, 0), `the offset stays inside the data (${w.offset} of ${total})`);
      assert.ok(w.page >= 1 && w.page <= w.pages);
      assert.ok(w.from >= 0 && w.to >= w.from - 1 && w.to <= total, `the shown range is sane (${w.from}-${w.to} of ${total})`);
    }
  }
}
assert.deepEqual(parsePaging({ page_size: '100', page: '3' }), { page: 3, pageSize: 100 });
assert.deepEqual(parsePaging({ page_size: '7' }, { defaultSize: 12, sizes: [12, 24, 48] }), { page: 1, pageSize: 12 });
const list = Array.from({ length: 101 }, (_, i) => i);
const last = paginateList(list, { page: 9999, pageSize: 25 });
assert.equal(last.page, 5); assert.deepEqual(last.rows, [100]); assert.equal(last.from, 101); assert.equal(last.to, 101);
assert.deepEqual(paginateList([], { page: 5, pageSize: 25 }).rows, []);
assert.equal(paginateList([], { page: 5, pageSize: 25 }).pages, 1);
// serverPaged re-queries the last page exactly once when the page is past the end
let calls = 0;
const sp = serverPaged(({ page, pageSize }) => { calls += 1; return { total: 30, rows: list.slice(0, 30).slice((page - 1) * pageSize, page * pageSize) }; }, { page: 40, pageSize: 25 });
assert.equal(calls, 2); assert.equal(sp.paging.page, 2); assert.equal(sp.result.rows.length, 5);
assert.equal(pageSizeParam({ pageSize: 25 }), ''); assert.equal(pageSizeParam({ pageSize: 50 }), 50);
assert.equal(queryString({ a: 1, b: '', c: null, d: [1, 2], e: false, f: 0 }), 'a=1&d=1&d=2&f=0');
assert.deepEqual(paramsFromQueryString('a=1&b=2&b=3'), { a: '1', b: ['2', '3'] });
console.log('PASS (pure) parsePaging/pageWindow/paginateList/serverPaged hold their invariants for every hostile value and total');

// ---- every paged screen ---------------------------------------------------------------------------------------------------------------
const f = await buildPortalFixture('cciq-paging-torture-');
const { users } = f;
const pagedRoutes = catalogue().filter((r) => r.method === 'GET' && /parsePaging/.test(r.body) && !r.path.includes(':'));
assert.ok(pagedRoutes.length >= 14, `the paged screens were found (${pagedRoutes.length})`);

const pageKeys = ['page', 'mpage', 'upage', 'ipage', 'ppage', 'opage'];
const sizeKeys = ['page_size', 'msize', 'usize', 'isize', 'psize', 'osize'];
const pageValues = ['0', '-1', '-999999', '1.5', 'abc', '', '1e9', '99999999999999999999', '9'.repeat(400), '0x10', ' 2 ', '+2', 'NaN', 'Infinity'];
const sizeValues = ['0', '-25', '7', '25', '50', '100', '101', '1000000', 'abc', '1e3', '9'.repeat(400), '12', '24', '48'];

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const visibleText = (html) => html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ');
  const bad = /\bNaN\b|\bundefined\b|\bInfinity\b|\[object Object\]/g;
  let requests = 0;

  for (const route of pagedRoutes) {
    const baselineRes = await admin.get(route.path);
    const baselineBody = await baselineRes.text();
    assert.equal(baselineRes.status, 200, `${route.path} opens for the super admin`);
    const baselineBad = (visibleText(baselineBody).match(bad) || []).length;

    const probe = async (query, what) => {
      const res = await admin.get(`${route.path}?${query}`);
      const body = await res.text();
      requests += 1;
      assert.equal(res.status, 200, `${route.path}?${query.slice(0, 80)} (${what}) answers normally, not ${res.status}`);
      const found = (visibleText(body).match(bad) || []).length;
      assert.ok(found <= baselineBad, `${route.path}?${query.slice(0, 80)} (${what}) shows no NaN/undefined/Infinity on the page`);
      assert.doesNotMatch(body, /Showing -|of -\d|page -\d/i, `${route.path}: no negative range in "${what}"`);
    };

    for (const value of pageValues) await probe(pageKeys.map((k) => `${k}=${encodeURIComponent(value)}`).join('&'), `page=${value.slice(0, 12)}`);
    for (const value of sizeValues) await probe(sizeKeys.map((k) => `${k}=${encodeURIComponent(value)}`).join('&'), `size=${value.slice(0, 12)}`);
    // combined with sort, filter and repeated / nested keys
    await probe('page=2&page=3&page_size=50&page_size=100', 'repeated page keys');
    await probe('page[]=2&page_size[]=50', 'array-style keys');
    await probe('page[a]=2&page_size[b]=50', 'object-style keys');
    await probe('sort=nonsense&direction=sideways&dir=x&page=3', 'unknown sort');
    await probe('q=zzzznomatch&page=7&page_size=100', 'empty result on a far page');
    await probe('page=2&page_size=25&q=' + encodeURIComponent('%'), 'wildcard search on page 2');
  }
  // a column-sort link starts at page 1 but keeps the chosen page size and the search text
  let sortChecked = 0;
  const droppedSize = [];
  const galleries = new Set(['/activities', '/documents']); // card galleries offer 12 / 24 / 48 instead of 25 / 50 / 100
  for (const route of pagedRoutes) {
    const size = galleries.has(route.path) ? '48' : '100';
    const res = await admin.get(`${route.path}?page_size=${size}&psize=${size}&osize=${size}&isize=${size}&msize=${size}&usize=${size}`);
    const html = await res.text();
    const links = [...html.matchAll(/<a [^>]*>/g)].map((m) => m[0]).filter((tag) => /sortable/.test(tag)).map((tag) => (tag.match(/href="([^"]+)"/) || [])[1]).filter(Boolean);
    for (const href of links) {
      const url = new URL(href.replace(/&amp;/g, '&'), 'http://x');
      assert.ok(!url.searchParams.has('page'), `${route.path}: a sort link ${href} starts from page 1`);
      if (!['page_size', 'psize', 'osize', 'isize', 'msize', 'usize'].some((k) => url.searchParams.get(k) === size)) droppedSize.push(href);
      sortChecked += 1;
    }
  }
  assert.deepEqual(droppedSize, [], 'every column-sort link keeps the chosen page size');
  assert.ok(sortChecked >= 20, `sort links were found and checked (${sortChecked})`);
  console.log(`PASS (sort links) ${sortChecked} column-sort links restart at page 1 and keep the page size`);

  console.log(`PASS (screens) ${pagedRoutes.length} paged screens x hostile page/size values in ${requests} requests: always a normal page, no NaN/undefined/Infinity, no negative range`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
