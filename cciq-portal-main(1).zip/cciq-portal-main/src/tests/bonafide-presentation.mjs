import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Bonafide gets a restrained church-gold treatment. PRESENTATION ONLY: who is Bonafide, and whether a Bonafide member counts as current or expected, did not change.
 *   - the pill is flat (no gradient, glow, shadow, animation or filter), a pale parchment fill with dark brown text and a deeper gold edge;
 *   - its text reaches 4.5:1 (css-contrast.mjs also pins the pair), and it is not the amber of "Inactive" / "Visitor";
 *   - the word "Bonafide" is on every pill, so status is never colour alone, and every place that shows a member's status uses the one class;
 *   - the status meaning (current population, expected roster, Bonafide count) is exactly as before.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const css = fs.readFileSync(path.join(root, 'src', 'public', 'css', 'cciq.css'), 'utf8');
const rule = (selector) => [...css.matchAll(new RegExp(`(^|\\n)${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\{([^}]*)\\}`, 'g'))].map((m) => m[2]).join(' ');

// ---- the stylesheet ------------------------------------------------------------------------------------------------------------------------------------------
{
  const body = rule('.pill--bonafide') + rule('.pill--bonafide::before');
  assert.ok(body.includes('background: #f4ebcf') && body.includes('color: #3b2a06') && body.includes('border-color: #a07e2c'), 'the pill is parchment, dark brown and gold-edged');
  assert.doesNotMatch(body, /gradient|box-shadow|text-shadow|animation|transition|filter|glow|@keyframes/i, 'flat: no gradient, glow, shadow, animation or filter');
  assert.doesNotMatch(css.slice(css.indexOf('.pill--bonafide')), /\.pill--bonafide[^{]*\{[^}]*(gradient|animation|box-shadow)/i);
  const lum = (hex) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
  const ratio = (a, b) => { const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x); return (hi + 0.05) / (lo + 0.05); };
  assert.ok(ratio('#3b2a06', '#f4ebcf') >= 7, `text on the pill is ${ratio('#3b2a06', '#f4ebcf').toFixed(1)}:1 (AAA)`);
  assert.ok(ratio('#a07e2c', '#ffffff') >= 3, 'the gold edge is visible on a white card (3:1)');
  assert.notEqual(rule('.pill--inactive').match(/background: ([^;]+)/)[1].trim(), '#f4ebcf', 'it is not the Inactive colour');
  assert.doesNotMatch(css, /\.members-status-counts \.pill--bonafide/, 'the status counts no longer paint Bonafide sky-blue');
  console.log(`PASS (stylesheet) flat parchment pill, ${ratio('#3b2a06', '#f4ebcf').toFixed(1)}:1 text, a visible gold edge, no gradient / glow / shadow / animation, distinct from Inactive, and no leftover blue override`);
}

// ---- every place a member's status is shown ------------------------------------------------------------------------------------------------------------------
const f = await buildPortalFixture('cciq-bonafide-');
const { db, ids, users, mods } = f;
const bonafide = mods.members.createMember({ first_name: 'Bona', last_name: 'Fide' }, { status: 'bonafide' });
mods.groups.assignMemberToGroup(bonafide.id, ids.groupA, {});
mods.family.addMemberToFamilyGroup(ids.family, bonafide.id);
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const screens = [
    ['Members list', `/members?status=bonafide`], ['Member profile', `/members/${bonafide.id}`], ['Member quick view', `/members/${bonafide.id}/quick`],
    ['Cell group members', `/cell-groups/${ids.groupA}?tab=members`], ['Family group', `/family-groups/${ids.family}`], ['Global search', `/search?q=Bona`]
  ];
  const context = await browser.newContext();
  await context.addCookies(admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  let pills = 0;
  for (const [label, url] of screens) {
    const html = await (await admin.get(url)).text();
    const found = [...html.matchAll(/<span class="[^"]*\bpill--bonafide\b[^"]*">([^<]*)<\/span>/g)].map((m) => m[1].trim());
    assert.ok(found.length >= 1, `${label}: shows a Bonafide pill`);
    for (const text of found) assert.match(text, /Bonafide|bonafide/, `${label}: the pill says "Bonafide" in words (${text})`);
    pills += found.length;
    assert.ok(!/<span class="[^"]*\bpill\b[^"]*">\s*<\/span>/.test(html), `${label}: no status pill is empty (a pill with no word is colour alone; the cell group tab used to have them)`);
    if (label === 'Member quick view') continue; // a drawer fragment: it is shown inside a page that already carries the stylesheet
    const tab = await context.newPage();
    await tab.setViewportSize({ width: 1280, height: 900 });
    await tab.goto(portal.base + url, { waitUntil: 'load' });
    const style = await tab.evaluate(() => {
      const el = document.querySelector('.pill--bonafide'); const s = getComputedStyle(el);
      return { bg: s.backgroundColor, color: s.color, border: s.borderTopColor, image: s.backgroundImage, shadow: s.boxShadow, anim: s.animationName, filter: s.filter, text: el.textContent.trim() };
    });
    assert.equal(style.bg, 'rgb(244, 235, 207)', `${label}: parchment fill`);
    assert.equal(style.color, 'rgb(59, 42, 6)', `${label}: dark brown text`);
    assert.equal(style.border, 'rgb(160, 126, 44)', `${label}: gold edge`);
    assert.equal(style.image, 'none'); assert.equal(style.shadow, 'none'); assert.equal(style.anim, 'none'); assert.equal(style.filter, 'none');
    await tab.close();
  }
  console.log(`PASS (screens) ${pills} Bonafide pills on ${screens.length} screens (list, profile, quick view, cell group, family group, search) all say "Bonafide" and compute to the same flat gold`);

  // ---- the meaning is untouched ------------------------------------------------------------------------------------------------------------------------------
  const members = await import('../services/members.js');
  assert.deepEqual(members.DEFAULT_ROSTER_STATUSES, ['active', 'pending', 'attendee', 'bonafide'], 'the default roster statuses are unchanged');
  assert.ok(members.CURRENT_POPULATION_STATUSES.includes('bonafide'), 'a Bonafide member is still part of the current population');
  assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(bonafide.id).status, 'bonafide');
  const counted = await (await admin.get('/members')).text();
  assert.match(counted, /pill pill--member pill--bonafide">Bonafide \d+</, 'the status counts keep the word and the number');
  console.log('PASS (meaning) the roster statuses, the current population and the stored status are unchanged; the counts still show "Bonafide" and a number');
} finally {
  await browser.close();
  await portal.stop();
}
db.close();
f.env.cleanup();
console.log('ALL PASS');
