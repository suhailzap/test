import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Model-based torture of Attendance (finalization, expected rosters, outcomes, rates, follow-up, Long Absence). A reference model written from
 * the documented rules (docs/ATTENDANCE-GOLIVE-AND-FINALIZATION.md), reading nothing from attendance-outcomes.js, attendance-tracking.js,
 * attendance-consumers.js or status-as-of.js, is driven side by side with the real services through seeded random operations. After EVERY
 * operation the application must agree with the model on: whether the operation was allowed; every member's outcome at every Friday (state,
 * derived-absence, rate numerator and denominator, how follow-up treats it); every Friday's summary (expected, present, Vacation, recorded
 * absent, unexpected attendees, rate); every member's rate; every member's current consecutive-absence run; the follow-up list; Long Absence;
 * and every member's status (nothing may change a status the model does not predict).
 * The world: members with status histories at controlled Qatar dates (including histories that cannot be trusted and members whose join date
 * decides it), Fridays before and after the tracking start, cancelled Fridays, a current Friday, a future one, member-linked Visitor rows,
 * Temporarily Away members who return on a confirmed Present.
 * A failure prints the seed and the last operations. MODEL_SEED=<n> replays one seed, MODEL_OPS=<n> changes its length.
 */

createIsolatedTestEnv('cciq-att-model-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const outcomes = await import('../services/attendance-outcomes.js');
const consumers = await import('../services/attendance-consumers.js');
const { today, addDays, lastFridayOnOrBefore, diffInDays } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const TODAY = today();
const SERVICE = lastFridayOnOrBefore(TODAY);             // the current operational Friday
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -400);
const SEEDS = process.env.MODEL_SEED ? [Number(process.env.MODEL_SEED)] : Array.from({ length: 12 }, (_, n) => n + 1);
const OPS = Number(process.env.MODEL_OPS) || 450;
const STATUSES = ['active', 'pending', 'attendee', 'bonafide', 'inactive', 'temporarily_away', 'archived', 'transferred', 'other', 'returned_home'];
const EXPECTED = new Set(['active', 'pending', 'attendee', 'bonafide']);
const ROW = ['present', 'excused', 'absent', 'visitor'];

function rng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const qatarDay = (iso) => new Date(Date.parse(iso) + 3 * 3600 * 1000).toISOString().slice(0, 10);

// ---------------------------------------------------------------------------------------------------------------------------------------
// The reference model
// ---------------------------------------------------------------------------------------------------------------------------------------
class Model {
  constructor() { this.goLive = null; this.sessions = []; this.members = []; this.threshold = 3; this.vacationBreaks = true; }

  phase(s) {
    if (!this.goLive) return 'not_started';
    if (s.date < this.goLive) return 'pre_go_live';
    if (s.cancelled) return 'cancelled';
    if (s.final === 'finalized') return 'finalized';
    if (s.final === 'not_taken') return 'not_taken';
    if (s.date > TODAY) return 'scheduled';
    return s.date === SERVICE ? 'open' : 'awaiting_finalization';
  }

  /** What the history says about a member at a date: { expected, ambiguous } - from the documented rule. */
  expectation(m, date) {
    if (m.joinDate && m.joinDate > date) return { expected: false, ambiguous: false };
    const h = [...m.history].sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : a.seq - b.seq));
    for (let i = 1; i < h.length; i += 1) if (h[i].prev !== h[i - 1].next) return { expected: false, ambiguous: true };
    if (h.length && h[h.length - 1].next !== m.status) return { expected: false, ambiguous: true };
    const applicable = h.filter((x) => qatarDay(x.at) <= date);
    let status;
    if (applicable.length) status = applicable[applicable.length - 1].next;
    else if (!h.length) { if (qatarDay(m.createdAt) > date) return { expected: false, ambiguous: true }; status = m.status; }
    else if (h[0].prev !== null) status = h[0].prev;
    else return { expected: false, ambiguous: true };
    return { expected: EXPECTED.has(status), ambiguous: false };
  }

  live(date) {
    const expected = new Set(); const ambiguous = new Set();
    for (const m of this.members) { const e = this.expectation(m, date); if (e.ambiguous) ambiguous.add(m.id); else if (e.expected) expected.add(m.id); }
    return { expected, ambiguous };
  }

  /** The roster a session is interpreted with: its snapshot if it ever had one; else live for open / awaiting / scheduled; else none. */
  roster(s) {
    if (s.snapshot) return { set: s.snapshot, ambiguous: new Set() };
    const ph = this.phase(s);
    if (['open', 'awaiting_finalization', 'scheduled'].includes(ph)) { const l = this.live(s.date); return { set: l.expected, ambiguous: l.ambiguous }; }
    return null;
  }

  outcome(s, m) {
    const phase = this.phase(s);
    const row = s.rows.get(m.id) || null;
    const positive = row === 'present' || row === 'visitor';
    const r = this.roster(s);
    let expected;
    if (r) expected = r.set.has(m.id) ? true : (r.ambiguous.has(m.id) ? null : false);
    else expected = phase === 'finalized' ? null : false;
    const base = { state: '', derived: false, num: false, den: false, follow: 'skip' };
    if (phase === 'not_started' || phase === 'pre_go_live') {
      const state = row === 'excused' ? 'vacation' : row === 'absent' ? 'absent' : positive ? 'present' : 'not_tracked';
      return { ...base, state, follow: 'outside' };
    }
    if (phase === 'cancelled') return { ...base, state: 'cancelled', follow: 'skip' };
    if (phase === 'not_taken') return positive ? { ...base, state: 'present', follow: 'break' } : { ...base, state: 'not_taken' };
    if (expected === false) return { ...base, state: positive ? 'present' : 'not_expected', follow: 'break' };
    if (phase === 'finalized') {
      if (expected !== true) return { ...base, state: 'not_tracked', follow: 'barrier' };
      if (positive) return { ...base, state: 'present', num: true, den: true, follow: 'break' };
      if (row === 'excused') return { ...base, state: 'vacation', follow: 'vacation' };
      return { ...base, state: 'absent', derived: row !== 'absent', den: true, follow: 'absence' };
    }
    if (positive) return { ...base, state: 'present', follow: 'break' };
    if (phase === 'awaiting_finalization') return { ...base, state: row === 'excused' ? 'vacation' : row === 'absent' ? 'absent' : 'awaiting_finalization', follow: 'barrier' };
    return { ...base, state: row === 'excused' ? 'vacation' : row === 'absent' ? 'absent' : 'pending', follow: 'skip' };
  }

  summary(s) {
    const live = this.live(s.date);
    const expected = s.snapshot || live.expected;
    let present = 0; let vacation = 0; let absentRecorded = 0; let noRow = 0; let unexpected = 0;
    for (const id of expected) {
      const row = s.rows.get(id);
      if (row === 'present' || row === 'visitor') present += 1; else if (row === 'excused') vacation += 1; else if (row === 'absent') absentRecorded += 1; else noRow += 1;
    }
    for (const [id, row] of s.rows) if (!expected.has(id) && (row === 'present' || row === 'visitor')) unexpected += 1;
    const den = expected.size - vacation;
    return { expected: expected.size, present, vacation, absentRecorded, noRow, unexpected, rate: den > 0 ? Math.round((present / den) * 100) : null };
  }

  memberRate(m) {
    let n = 0; let d = 0; let sessions = 0;
    for (const s of this.sessions) {
      if (this.phase(s) !== 'finalized') continue;
      const o = this.outcome(s, m);
      if (o.den) d += 1; if (o.num) n += 1; if (o.den || o.state === 'vacation') sessions += 1;
    }
    return { n, d, sessions, rate: d > 0 ? Math.round((n / d) * 100) : null };
  }

  /** Counting Fridays from the tracking start up to today, newest first. */
  tracked() {
    return this.goLive ? this.sessions.filter((s) => s.date >= this.goLive && s.date <= TODAY).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id)) : [];
  }

  run(m) {
    let streak = 0; let blocked = false; let endedBy = 'no_more_sessions';
    for (const s of this.tracked()) {
      const o = this.outcome(s, m);
      if (o.follow === 'skip') continue;
      if (o.follow === 'absence') { streak += 1; continue; }
      if (o.follow === 'vacation') { if (this.vacationBreaks) { endedBy = 'vacation'; break; } streak += 1; continue; }
      if (o.follow === 'barrier') { blocked = true; endedBy = 'awaiting_finalization'; break; }
      if (o.follow === 'outside') { endedBy = 'outside_tracking'; break; }
      endedBy = o.state === 'present' ? 'attended' : 'not_expected';
      break;
    }
    return { streak, blocked, flagged: streak >= this.threshold, endedBy };
  }

  followUpIds() { return this.members.filter((m) => EXPECTED.has(m.status) && this.goLive && this.run(m).flagged).map((m) => m.id).sort((a, b) => a - b); }

  longAbsence() {
    const window = 56;
    if (!this.goLive) return { status: 'not_started', ids: [] };
    if (Math.max(diffInDays(this.goLive, TODAY), 0) < window) return { status: 'insufficient_history', ids: [] };
    const ids = []; const states = {};
    for (const m of this.members) {
      if (!EXPECTED.has(m.status)) continue;
      let last = null;
      for (const s of this.sessions) { if (s.cancelled) continue; const row = s.rows.get(m.id); if ((row === 'present' || row === 'visitor') && (!last || s.date > last)) last = s.date; }
      const away = last ? diffInDays(last, TODAY) : null;
      if (away !== null && away <= window) continue;
      ids.push(m.id); states[m.id] = last ? 'long_absent' : 'no_tracked_attendance';
    }
    const awaiting = this.tracked().filter((s) => this.phase(s) === 'awaiting_finalization' && s.date >= addDays(TODAY, -window)).map((s) => s.id).sort((a, b) => a - b);
    return { status: 'ready', ids: ids.sort((a, b) => a - b), states, awaiting };
  }

  // ---- what each operation is allowed to do (the documented rules) ------------------------------------------------------------------
  tracksFriday(s) { return Boolean(this.goLive) && s.date >= this.goLive; }
  writable(s, { correction = false } = {}) {
    if (s.cancelled) return false;
    if (s.date > TODAY) return false;
    if (this.tracksFriday(s) && s.final) return correction && s.final === 'finalized';
    return true;
  }
  finalizeBlockers(s) {
    if (!this.goLive) return 'tracking_not_started';
    if (s.date < this.goLive) return 'not_tracked';
    if (s.cancelled) return 'session_cancelled';
    if (s.date > TODAY) return 'session_in_future';
    if (s.final === 'finalized') return 'already_finalized';
    if (s.final === 'not_taken') return 'already_not_taken';
    return null;
  }
}

// ---------------------------------------------------------------------------------------------------------------------------------------
// The real world, built to match the model
// ---------------------------------------------------------------------------------------------------------------------------------------
function build(seed) {
  const rand = rng(seed);
  const pick = (list) => list[Math.floor(rand() * list.length)];
  const between = (lo, hi) => lo + Math.floor(rand() * (hi - lo + 1));
  db.pragma('foreign_keys = OFF');
  db.exec('DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM member_status_history; DELETE FROM members; DELETE FROM audit_logs; DELETE FROM reminders; DELETE FROM notifications;');
  db.pragma('foreign_keys = ON');
  const model = new Model();
  model.threshold = between(2, 4); model.vacationBreaks = rand() < 0.6;
  setSetting('attendance.followup_threshold', model.threshold);
  setSetting('attendance.excused_counts', model.vacationBreaks);
  setSetting('attendance.recent_engagement_days', 0);
  model.goLive = W(-between(7, 9));
  setSetting('attendance.tracking_start_date', model.goLive);

  const insertSession = db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', ?, 1, 0, ?)");
  for (let n = -12; n <= 1; n += 1) {
    const cancelled = n !== 0 && n !== 1 && rand() < 0.1;
    insertSession.run(W(n), cancelled ? 'cancelled' : (n <= 0 ? 'held' : 'scheduled'), `${W(n)}T09:00:00.000Z`);
    const id = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)).id;
    model.sessions.push({ id, date: W(n), cancelled, final: null, snapshot: null, rows: new Map() });
  }

  const memberCount = 14;
  for (let i = 0; i < memberCount; i += 1) {
    const m = createMember({ first_name: `M${seed}x${i}`, last_name: 'Model' }, { status: 'active' });
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    const old = rand() < 0.65;
    const createdDay = old ? OLD : W(-between(1, 9));
    const createdAt = `${createdDay}T09:00:00.000Z`;
    // A member created part-way through always carries a join date on or after that day (without one, every earlier Friday is rightly refused as
    // unclear, and nothing could ever be finalized); a long-standing member may have none, or an old one, or a later one.
    const joinDate = old ? pick([null, OLD, OLD, W(-between(1, 10))]) : pick([createdDay, createdDay, addDays(createdDay, between(1, 20))]);
    const hist = [];
    let status = pick(['active', 'active', 'pending', 'attendee', 'bonafide', 'inactive', 'temporarily_away']);
    let atDay = createdDay;
    const withHistory = old ? rand() > 0.15 : true;
    const note = (prev, next, at) => { hist.push({ prev, next, at, seq: hist.length + 1 }); };
    if (withHistory) {
      note(null, status, rand() < 0.2 ? `${atDay}T22:30:00.000Z` : `${atDay}T09:00:00.000Z`);
      const changes = between(0, 3);
      for (let c = 0; c < changes; c += 1) {
        atDay = addDays(atDay, between(1, 25));
        if (atDay > TODAY) break;
        let next = pick(STATUSES); if (next === status) next = status === 'active' ? 'inactive' : 'active';
        note(status, next, rand() < 0.2 ? `${atDay}T22:30:00.000Z` : `${atDay}T09:00:00.000Z`);
        status = next;
      }
    }
    db.prepare('UPDATE members SET created_at = ?, date_joined = ?, status = ? WHERE id = ?').run(createdAt, joinDate, status, m.id);
    for (const h of hist) db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)').run(m.id, h.prev, h.next, 'planted', h.at);
    model.members.push({ id: m.id, createdAt, joinDate, history: hist, status, corrupt: false, old, createdDay });
  }
  return { model, rand, pick, between };
}

function sessionsRow(id) { return db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(id); }

function sync(model, member) { // temp-away return writes a history row at the real time: take its timestamp from the database
  const rows = db.prepare('SELECT id, previous_status, new_status, changed_at FROM member_status_history WHERE member_id = ? ORDER BY id').all(member.id);
  member.history = rows.map((r, i) => ({ prev: r.previous_status, next: r.new_status, at: r.changed_at, seq: i + 1 }));
  member.status = db.prepare('SELECT status FROM members WHERE id = ?').get(member.id).status;
}

/** After a Present on the current Friday: the documented Temporarily Away rule, predicted BEFORE the call and checked after it. */
function predictReturn(model, member, session) {
  if (member.status !== 'temporarily_away') return null;
  const last = member.history.filter((h) => h.next === 'temporarily_away').sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : a.seq - b.seq)).pop();
  const candidate = last ? last.prev : null;
  const when = last ? qatarDay(last.at) : null;
  if (when && session.date <= when) return null;                // earlier or the same Qatar day: never an automatic return
  if (!candidate || !EXPECTED.has(candidate)) return null;
  return candidate;
}

function applyRow(model, s, member, status, { viaCorrection = false } = {}) {
  if (status === null) s.rows.delete(member.id); else s.rows.set(member.id, status);
  void viaCorrection;
}

let lastOk = null;
function execute(op, world) {
  lastOk = null;
  const { model } = world;
  const s = op.session != null ? model.sessions[op.session] : null;
  const member = op.member != null ? model.members[op.member] : null;
  switch (op.type) {
    case 'mark': {
      const allowed = model.writable(s);
      const predicted = op.status === 'present' && s.date === SERVICE && !s.cancelled && allowed && !member.corrupt ? predictReturn(model, member, s) : null;
      const result = attendance.recordAttendance(s.id, [{ memberId: member.id, status: op.status || 'clear' }], { userId: null });
      lastOk = result.ok;
      assert.equal(result.ok, allowed, `mark ${op.status} allowed? model ${allowed}, app ${result.ok} (${result.reason})`);
      if (!allowed) break;
      applyRow(model, s, member, op.status);
      if (predicted) { sync(model, member); assert.equal(member.status, predicted, 'Temporarily Away returned to the status before it'); }
      break;
    }
    case 'finalize': {
      const blocker = model.finalizeBlockers(s);
      const roster = model.roster(s);
      const ambiguous = !blocker && !s.snapshot && model.live(s.date).ambiguous.size > 0;
      const result = lifecycle.finalizeAttendance(s.id, { userId: null, confirmNoAttendance: true });
      const expectOk = !blocker && !ambiguous;
      lastOk = result.ok;
      assert.equal(result.ok, expectOk, `finalize allowed? model ${expectOk} (${blocker || (ambiguous ? 'ambiguous' : '')}), app ${result.ok} (${result.reason})`);
      if (!expectOk) { if (blocker) assert.equal(result.reason, blocker, 'the same refusal'); else assert.equal(result.reason, 'ambiguous_history'); break; }
      s.final = 'finalized';
      if (!s.snapshot) s.snapshot = new Set(roster ? roster.set : model.live(s.date).expected);
      break;
    }
    case 'notTaken': {
      const blocker = model.finalizeBlockers(s);
      const result = lifecycle.markAttendanceNotTaken(s.id, { userId: null, note: 'model', confirmExistingAttendance: true });
      lastOk = result.ok;
      assert.equal(result.ok, !blocker, `not-taken allowed? model ${!blocker} (${blocker}), app ${result.ok} (${result.reason})`);
      if (blocker) { assert.equal(result.reason, blocker); break; }
      s.final = 'not_taken';
      break;
    }
    case 'reopen': {
      const allowed = Boolean(s.final) && !s.cancelled;
      const result = lifecycle.reopenAttendance(s.id, { userId: null, reason: 'model' });
      lastOk = result.ok;
      assert.equal(result.ok, allowed, `reopen allowed? model ${allowed}, app ${result.ok} (${result.reason})`);
      if (allowed) s.final = null; // the snapshot is kept
      break;
    }
    case 'correct': {
      const isExpected = Boolean(s.snapshot) && s.snapshot.has(member.id);
      const legalSession = s.final === 'finalized' && !s.cancelled;
      const legalTarget = isExpected || op.to === 'present' || op.to === 'remove';
      const current = s.rows.get(member.id) ?? null;
      const target = op.to === 'remove' ? null : op.to;
      const predicted = op.to === 'present' && legalSession && legalTarget && current !== 'present' && s.date === SERVICE && !s.cancelled && !member.corrupt ? predictReturn(model, member, s) : null;
      const result = lifecycle.correctFinalizedAttendance(s.id, [{ memberId: member.id, to: op.to }], { userId: null, reason: 'model' });
      const expectOk = legalSession && legalTarget;
      lastOk = result.ok;
      assert.equal(result.ok, expectOk, `correct allowed? model ${expectOk}, app ${result.ok} (${result.reason})`);
      if (!expectOk) break;
      if (target !== current) applyRow(model, s, member, target);
      if (predicted) { sync(model, member); assert.equal(member.status, predicted, 'a corrected Present on the current Friday returns a Temporarily Away member too'); }
      break;
    }
    case 'cancel': case 'reinstate': {
      const wantCancel = op.type === 'cancel';
      const result = lifecycle.changeSessionStatus(s.id, wantCancel ? 'cancelled' : 'held', { userId: null, notes: 'model' });
      lastOk = result.ok;
      lastOk = result.ok;
      assert.equal(result.ok, true, `${op.type} ok (${result.reason})`);
      s.cancelled = wantCancel;
      break;
    }
    case 'status': {
      if (member.corrupt) break;
      const rows = member.history;
      const lastAt = rows.length ? rows[rows.length - 1].at : member.createdAt;
      const day = addDays(qatarDay(lastAt), op.days);
      if (day > TODAY) break;
      let next = op.status; if (next === member.status) next = member.status === 'active' ? 'inactive' : 'active';
      const at = `${day}T${op.late ? '22:30' : '09:00'}:00.000Z`;
      if (at <= lastAt) break;
      db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)').run(member.id, member.status, next, 'planted', at);
      db.prepare('UPDATE members SET status = ? WHERE id = ?').run(next, member.id);
      member.history.push({ prev: member.status, next, at, seq: member.history.length + 1 });
      member.status = next;
      break;
    }
    case 'corrupt': {
      if (member.corrupt || !member.history.length) break;
      const other = member.status === 'active' ? 'archived' : 'active';
      db.prepare('UPDATE members SET status = ? WHERE id = ?').run(other, member.id);
      member.status = other; member.corrupt = true;
      break;
    }
    case 'repair': {
      if (!member.corrupt) break;
      const tail = member.history[member.history.length - 1].next;
      db.prepare('UPDATE members SET status = ? WHERE id = ?').run(tail, member.id);
      member.status = tail; member.corrupt = false;
      break;
    }
    case 'join': {
      let date = op.date === 'none' ? null : op.date;
      if (!member.old && (date === null || date < member.createdDay)) date = member.createdDay; // see build(): a member created part-way keeps a join date from that day on
      db.prepare('UPDATE members SET date_joined = ? WHERE id = ?').run(date, member.id);
      member.joinDate = date;
      break;
    }
    default: throw new Error(op.type);
  }
}

function compare(world, label) {
  const { model } = world;
  // statuses
  for (const m of model.members) assert.equal(db.prepare('SELECT status FROM members WHERE id = ?').get(m.id).status, m.status, `${label}: status of member ${m.id}`);
  // outcomes at every Friday
  const contexts = outcomes.buildFridayContexts({ from: null, to: '9999-12-31' });
  assert.equal(contexts.length, model.sessions.length, `${label}: every Friday is prepared`);
  for (const ctx of contexts) {
    const s = model.sessions.find((x) => x.id === ctx.id);
    assert.equal(ctx.phase, model.phase(s), `${label}: phase of ${s.date}`);
    for (const m of model.members) {
      const got = outcomes.memberOutcomeAt(ctx, m.id); const want = model.outcome(s, m);
      const g = { state: got.state, derived: got.derived, num: got.rateNumerator, den: got.rateDenominator, follow: got.followUp };
      assert.deepEqual(g, { state: want.state, derived: want.derived, num: want.num, den: want.den, follow: want.follow }, `${label}: member ${m.id} at ${s.date} (${model.phase(s)}) row=${s.rows.get(m.id) || '-'}`);
    }
  }
  // summaries
  for (const s of model.sessions) {
    const ph = model.phase(s);
    if (!['open', 'awaiting_finalization', 'finalized', 'scheduled'].includes(ph)) continue;
    const got = outcomes.computeSessionSummary(sessionsRow(s.id));
    const want = model.summary(s);
    assert.deepEqual({ e: got.expected, p: got.presentExpected, v: got.vacation, a: got.absentRecorded, n: got.willBecomeAbsent, u: got.unexpectedAttendees, rate: got.rate },
      { e: want.expected, p: want.present, v: want.vacation, a: want.absentRecorded, n: want.noRow, u: want.unexpected, rate: want.rate }, `${label}: summary of ${s.date} (${ph})`);
    assert.equal(got.finalRate, ph === 'finalized' ? want.rate : null, `${label}: a rate is published only for a finalized Friday (${s.date})`);
  }
  // rates and runs
  const sequence = consumers.trackedFridayContexts();
  assert.deepEqual(sequence.map((c) => c.id), model.tracked().map((s) => s.id), `${label}: the tracked sequence`);
  for (const m of model.members) {
    const rate = outcomes.memberRate(m.id, contexts); const want = model.memberRate(m);
    assert.deepEqual({ n: rate.numerator, d: rate.denominator, sessions: rate.sessions, rate: rate.rate }, { n: want.n, d: want.d, sessions: want.sessions, rate: want.rate }, `${label}: rate of member ${m.id}`);
    const run = outcomes.consecutiveAbsenceRun(m.id, sequence); const wantRun = model.run(m);
    assert.deepEqual({ streak: run.streak, blocked: run.blocked, flagged: run.flagged, endedBy: run.endedBy }, wantRun, `${label}: current run of member ${m.id}`);
  }
  // follow-up list and Long Absence
  assert.deepEqual(consumers.followUpList({ limit: 1000 }).map((x) => x.member.id).sort((a, b) => a - b), model.followUpIds(), `${label}: the follow-up list`);
  const long = consumers.longAbsenceReview({ limit: 1000 }); const wantLong = model.longAbsence();
  assert.equal(long.status, wantLong.status, `${label}: Long Absence status`);
  if (wantLong.status === 'ready') {
    assert.deepEqual(long.rows.map((r) => r.member.id).sort((a, b) => a - b), wantLong.ids, `${label}: Long Absence members`);
    for (const r of long.rows) assert.equal(r.state, wantLong.states[r.member.id], `${label}: Long Absence state of ${r.member.id}`);
    assert.deepEqual(long.awaitingFridays.map((x) => x.id).sort((a, b) => a - b), wantLong.awaiting, `${label}: Long Absence completeness`);
  }
  // the stored facts the model also predicts
  for (const s of model.sessions) {
    const row = sessionsRow(s.id);
    assert.equal(row.finalization_state, s.final, `${label}: stored finalization state of ${s.date}`);
    assert.equal(row.status === 'cancelled', s.cancelled, `${label}: stored cancellation of ${s.date}`);
    const stored = new Set(db.prepare('SELECT member_id FROM attendance_expected WHERE session_id = ?').all(s.id).map((r) => r.member_id));
    assert.deepEqual([...stored].sort((a, b) => a - b), [...(s.snapshot || [])].sort((a, b) => a - b), `${label}: stored expected snapshot of ${s.date}`);
    const rows = new Map(db.prepare('SELECT member_id, status FROM attendance_records WHERE session_id = ?').all(s.id).map((r) => [r.member_id, r.status]));
    assert.deepEqual([...rows].sort((a, b) => a[0] - b[0]), [...s.rows].sort((a, b) => a[0] - b[0]), `${label}: stored attendance rows of ${s.date}`);
  }
}

// ---------------------------------------------------------------------------------------------------------------------------------------
let totalOps = 0; const seen = { allowed: 0, refused: 0 };
const coverage = { flaggedMembers: 0, followUpNonEmpty: 0, blockedRuns: 0, longAbsenceReady: 0, longAbsenceRows: 0, ambiguousFridays: 0 };
for (const seed of SEEDS) {
  const world = build(seed);
  const { rand, pick, between } = world;
  const recent = [];
  try {
    if (process.env.MODEL_DEBUG) for (const m of world.model.members) { const e = world.model.expectation(m, W(-3)); console.log('DEBUG', m.id, m.old ? 'old' : 'mid', 'join', m.joinDate, 'status', m.status, 'hist', JSON.stringify(m.history.map((h) => [h.prev, h.next, h.at.slice(0, 10)])), e); }
    compare(world, 'initial');
    for (let i = 0; i < OPS; i += 1) {
      const roll = rand();
      const session = between(0, world.model.sessions.length - 1);
      const member = between(0, world.model.members.length - 1);
      let op;
      const writable = world.model.sessions.map((x, ix) => [x, ix]).filter(([x]) => world.model.writable(x)).map(([, ix]) => ix);
      const awaiting = world.model.sessions.map((x, ix) => [x, ix]).filter(([x]) => ['awaiting_finalization'].includes(world.model.phase(x))).sort((a, b) => (a[0].date < b[0].date ? 1 : -1)).map(([, ix]) => ix);
      if (roll < 0.40) op = { type: 'mark', session: writable.length && rand() < 0.8 ? pick(writable) : session, member, status: pick(['present', 'present', 'present', 'excused', 'absent', 'visitor', null]) };
      else if (roll < 0.47) op = { type: 'finalize', session: awaiting.length ? awaiting[0] : session };
      else if (roll < 0.52) op = { type: 'finalize', session: pick([session, between(0, world.model.sessions.length - 3)]) };
      else if (roll < 0.56) op = { type: 'notTaken', session };
      else if (roll < 0.63) op = { type: 'reopen', session };
      else if (roll < 0.72) op = { type: 'correct', session, member, to: pick(['present', 'excused', 'absent', 'remove']) };
      else if (roll < 0.76) op = { type: world.model.sessions[session].cancelled ? 'reinstate' : 'cancel', session };
      else if (roll < 0.84) op = { type: 'status', member, status: pick(STATUSES), days: between(1, 18), late: rand() < 0.3 };
      else if (roll < 0.85) op = { type: 'corrupt', member };
      else if (roll < 0.93) { const broken = world.model.members.findIndex((x) => x.corrupt); op = { type: 'repair', member: broken >= 0 ? broken : member }; }
      else op = { type: 'join', member, date: pick(['none', OLD, W(-between(1, 10))]) };
      recent.push(`${i}: ${JSON.stringify(op)}`); if (recent.length > 8) recent.shift();
      execute(op, world);
      totalOps += 1;
      const tag = `${op.type}${lastOk === null ? '' : lastOk ? 'Ok' : 'Refused'}`; coverage[tag] = (coverage[tag] || 0) + 1;
      compare(world, `seed ${seed} op ${i} ${op.type}`);
      const ids = world.model.followUpIds(); if (ids.length) coverage.followUpNonEmpty += 1; coverage.flaggedMembers += ids.length;
      coverage.blockedRuns += world.model.members.filter((m) => world.model.run(m).blocked).length;
      const la = world.model.longAbsence(); if (la.status === 'ready') { coverage.longAbsenceReady += 1; coverage.longAbsenceRows += la.ids.length; }
      coverage.ambiguousFridays += world.model.sessions.filter((s) => world.model.live(s.date).ambiguous.size > 0).length;
    }
  } catch (err) {
    console.log(`FAILED seed ${seed}. Replay with MODEL_SEED=${seed}. Last operations:\n  ${recent.join('\n  ')}`);
    throw err;
  }
}
void seen;
console.log('COVERAGE', JSON.stringify(coverage));
console.log(`PASS (attendance model) ${SEEDS.length} seeds, ${totalOps} random operations (marks, finalize, not taken, reopen, correct, cancel, status changes, history corruption and repair, join dates): the application agreed with the independent model on every outcome, summary, rate, run, follow-up list and Long Absence list after every one`);
db.close();
console.log('ALL PASS');
