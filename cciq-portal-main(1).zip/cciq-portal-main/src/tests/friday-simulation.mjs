import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * "Would I trust this on a Friday?" - a whole Friday on synthetic data, driven through the real routes, with every number cross-checked against a plain
 * list this file keeps by itself (not the application's own arithmetic):
 *
 *   history   six earlier Fridays are recorded and finalized for a congregation of 60 (regulars, drifters, people who stopped coming)
 *   Friday    two Kiosk stations scan overlapping groups at the same moment (some people are scanned twice, at both stations); the desk records others,
 *             one by mistake and takes the mistake back; three First Timers register (one invited by a member, one at the desk, one on their own);
 *             latecomers arrive after the count; the same request is double-submitted
 *   close     the Friday is finalized; the door is then closed to every route; absent members are exactly the expected people with no record
 *   checks    one record per person; the session page, the member pages, the follow-up list, the First Timer list and the CSV agree with the plain list;
 *             the audit trail has exactly the rows the changes deserve; the data rules hold; a backup of it all verifies
 *   restart   the portal is stopped and started again (the PC is restarted on Friday night): the same pages give the same answers
 */

const f = await buildPortalFixture('cciq-friday-sim-');
const { db, ids, users, mods } = f;
const { setSetting } = await import('../lib/settings.js');
const attendance = await import('../services/attendance.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const { today, addDays, lastFridayOnOrBefore } = mods.dates;
const count = (sql, ...p) => db.prepare(sql).get(...p).n;

// ---- the congregation and its history, kept as plain lists ----------------------------------------------------------------------------------------
const friday = ids.session ? db.prepare('SELECT service_date FROM attendance_sessions WHERE id = ?').get(ids.session).service_date : lastFridayOnOrBefore(today());
const past = Array.from({ length: 6 }, (_, k) => addDays(friday, -7 * (6 - k)));
const people = [];
for (let i = 0; i < 60; i += 1) {
  const kind = i < 30 ? 'regular' : i < 45 ? 'drifter' : i < 52 ? 'stopped' : 'newish';
  const m = mods.members.createMember({ first_name: `Fri${String(i).padStart(2, '0')}`, last_name: `${kind[0].toUpperCase()}${kind.slice(1)}Person` }, { status: 'active' });
  people.push({ id: m.id, kind, name: `Fri${String(i).padStart(2, '0')} ${kind[0].toUpperCase()}${kind.slice(1)}Person`, history: [] });
}
const wasPresent = (person, week) => {
  if (person.kind === 'regular') return week % 11 !== person.id % 11 || week < 2;
  if (person.kind === 'drifter') return (week + person.id) % 2 === 0;
  if (person.kind === 'stopped') return week < 3; // present the first three Fridays, then gone
  return week >= 4; // newish: started recently
};
setSetting('attendance.followup_threshold', 3);
setSetting('attendance.tracking_start_date', past[0]);
// The fixture's own people are not part of this story; keep them from being ambiguous by giving everyone a settled history.
db.exec(`INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at)
         SELECT id, NULL, status, 'fixture', '2020-01-01T00:00:00.000Z' FROM members WHERE id NOT IN (SELECT member_id FROM member_status_history)`);
db.exec("UPDATE member_status_history SET changed_at = '2020-01-01T00:00:00.000Z'");
db.exec("UPDATE members SET created_at = '2020-01-01T00:00:00.000Z'");
db.prepare("UPDATE attendance_sessions SET created_at = '2020-01-01T00:00:00.000Z'").run();
for (const [week, date] of past.entries()) {
  db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, '2020-01-01T00:00:00.000Z')").run(date);
  const session = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(date);
  const entries = [];
  for (const person of people) {
    if (person.kind === 'newish' && week < 4) continue;
    const here = wasPresent(person, week);
    person.history.push(here);
    entries.push({ memberId: person.id, status: here ? 'present' : 'absent' });
  }
  assert.ok(attendance.recordAttendance(session.id, entries, { userId: users.superAdmin.id }).ok);
  const done = lifecycle.finalizeAttendance(session.id, { userId: users.superAdmin.id, confirmNoAttendance: true });
  assert.ok(done.ok, `history Friday ${date} finalizes (${done.reason})`);
}
// "newish" members joined before week 4 but never attended; they were not on the older rosters in this story, so give them a join date that says so.
db.prepare("UPDATE members SET date_joined = ? WHERE id IN (" + people.filter((p) => p.kind === 'newish').map((p) => p.id).join(',') + ')').run(past[3]);

const portal = await startPortal();
const stationA = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
await mods.users.createUser({ username: 'fri_kiosk_b', email: 'fri_kiosk_b@fixture.invalid', password: f.PASSWORD, displayName: 'Kiosk B', roleKeys: ['kiosk'], mustChangePassword: false });
const stationB = await signIn(portal.base, 'fri_kiosk_b@fixture.invalid', f.PASSWORD);
const desk = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
const sessionId = db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service' AND cell_group_id = 0").get(friday).id;
const auditCount = (action) => count('SELECT COUNT(*) n FROM audit_logs WHERE action = ?', action);
const recordsOf = () => new Set(db.prepare("SELECT member_id FROM attendance_records WHERE session_id = ? AND status = 'present'").all(sessionId).map((r) => r.member_id));
const SECRETS = /(SqliteError|SQLITE_|\bat \S+ \(|node_modules|\.js:\d+|password_hash)/;

try {
  const expectedPresent = new Set();

  // ---- Friday evening: two Kiosk stations, overlapping, at the same time ---------------------------------------------------------------------------
  const scan = (who, person) => who.post('/attendance/checkin/confirm', { member_id: String(person.id), session_id: String(sessionId) }, { csrfFrom: '/kiosk' }).then(async (res) => ({ status: res.status, body: await res.json().catch(() => ({})) }));
  const groupA = people.slice(0, 28); // stations scan 0..27 and 14..41: 14..27 are scanned at both
  const groupB = people.slice(14, 42);
  const results = await Promise.all([...groupA.map((p) => scan(stationA, p)), ...groupB.map((p) => scan(stationB, p))]);
  for (const r of results) assert.equal(r.status, 200, `a scan is accepted (${JSON.stringify(r.body)})`);
  for (const p of [...groupA, ...groupB]) expectedPresent.add(p.id);
  const duplicates = results.filter((r) => r.body.alreadyCheckedIn).length;
  assert.equal(duplicates, 14, 'exactly the 14 people scanned at both stations were told "already checked in" (the second scan changes nothing)');
  assert.deepEqual(recordsOf(), expectedPresent, 'one present record per person scanned, none missing, none extra');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?', sessionId), expectedPresent.size, 'and no duplicate or stray row');
  console.log(`PASS (kiosks) two stations scanning ${groupA.length + groupB.length} times (14 people twice, at the same moment) produce ${expectedPresent.size} records, ${duplicates} "already checked in" answers`);

  // ---- the desk records others, one by mistake ---------------------------------------------------------------------------------------------------------
  const deskPeople = [people[44], people[45], people[46], people[52], people[14]]; // the last was already scanned
  const rec = await desk.post('/attendance/checkin/record', { person: deskPeople.map((p) => `member:${p.id}`) }, { csrfFrom: '/attendance/checkin', headers: { Accept: 'application/json' } });
  const recBody = await rec.json();
  assert.equal(rec.status, 200);
  assert.equal(recBody.newly.length, 4, 'four new people');
  assert.equal(recBody.already.length, 1, 'and the one already scanned is reported as already recorded');
  for (const p of deskPeople) expectedPresent.add(p.id);
  const mistake = people[50];
  const marked = await desk.post(`/attendance/sessions/${sessionId}/records`, { [`status_${mistake.id}`]: 'present' }, { csrfFrom: `/attendance/sessions/${sessionId}` });
  await marked.text();
  assert.ok(recordsOf().has(mistake.id), 'the mistaken mark is on file');
  const undone = await desk.post(`/attendance/sessions/${sessionId}/records`, { [`status_${mistake.id}`]: 'clear' }, { csrfFrom: `/attendance/sessions/${sessionId}` });
  await undone.text();
  assert.deepEqual(recordsOf(), expectedPresent, 'taking the mistake back leaves exactly the intended people present');

  // a double-submitted desk form changes nothing the second time
  const again = await desk.post('/attendance/checkin/record', { person: [`member:${people[47].id}`] }, { csrfFrom: '/attendance/checkin', headers: { Accept: 'application/json' } });
  const again2 = await desk.post('/attendance/checkin/record', { person: [`member:${people[47].id}`] }, { csrfFrom: '/attendance/checkin', headers: { Accept: 'application/json' } });
  assert.equal((await again.json()).newly.length, 1);
  assert.equal((await again2.json()).newly.length, 0, 'the repeat is "already recorded"');
  expectedPresent.add(people[47].id);

  // ---- First Timers --------------------------------------------------------------------------------------------------------------------------------------
  const express = (who, fields, from) => who.post('/attendance/checkin/first-timer', fields, { csrfFrom: from });
  const r1 = await express(stationA, { kiosk: '1', first_name: 'Guesta', last_name: 'Alpha', phone: '+974 5550 1111', invited_by_member_id: String(people[3].id) }, '/attendance/checkin/first-timer');
  const r2 = await express(stationB, { kiosk: '1', first_name: 'Guestb', last_name: 'Beta', phone: '+974 5550 2222' }, '/attendance/checkin/first-timer');
  const r3 = await express(desk, { first_name: 'Guestc', last_name: 'Gamma', phone: '+974 5550 3333' }, '/attendance/checkin/first-timer');
  for (const r of [r1, r2, r3]) { await r.text(); assert.equal(r.status, 302, 'a First Timer registers'); }
  const visitorsNow = db.prepare("SELECT v.id, v.first_name, v.invited_by_member_id FROM visitors v WHERE v.first_name IN ('Guesta','Guestb','Guestc') ORDER BY v.first_name").all();
  assert.equal(visitorsNow.length, 3, 'three new First Timers, no more');
  assert.equal(visitorsNow[0].invited_by_member_id, people[3].id, 'the invited one names the member who invited them');
  assert.equal(visitorsNow[1].invited_by_member_id, null, 'and a person who came on their own has none');
  for (const v of visitorsNow) assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ? AND visit_date = ?', v.id, friday), 1, `${v.first_name} has exactly one visit, on this Friday`);
  // registering the same person again (a second tap, or two stations) is refused as a possible duplicate and creates nothing
  const dup = await express(stationB, { kiosk: '1', first_name: 'Guesta', last_name: 'Alpha', phone: '+974 5550 1111' }, '/attendance/checkin/first-timer');
  await dup.text();
  assert.equal(dup.status, 409);
  // the same mobile number under another name: the refusal must not reveal whose number it is
  const probe = await express(stationB, { kiosk: '1', first_name: 'Someone', last_name: 'Else', phone: '+974 5550 1111' }, '/attendance/checkin/first-timer');
  const probeText = await probe.text();
  assert.equal(probe.status, 409);
  assert.doesNotMatch(probeText, /Alpha|Guesta/, 'and the refusal does not say who is on file');
  assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name IN ('Guesta','Guestb','Guestc')"), 3);

  // ---- a First Timer already recorded by hand for today (the administrative form), then checked in at the door ------------------------------------------------
  const byHand = await admin.post('/visitors', { first_name: 'Guestd', last_name: 'Delta', first_visit_date: friday }, { csrfFrom: '/visitors/new' });
  await byHand.text();
  const delta = db.prepare("SELECT id FROM visitors WHERE first_name = 'Guestd'").get();
  assert.ok(delta, 'recorded by hand');
  assert.equal(db.prepare('SELECT session_id FROM visitor_visits WHERE visitor_id = ?').get(delta.id).session_id, null, 'a visit recorded by hand has no service attached yet');
  const deltaIn = await desk.post('/attendance/checkin/record', { person: [`visitor:${delta.id}`] }, { csrfFrom: '/attendance/checkin', headers: { Accept: 'application/json' } });
  assert.equal(deltaIn.status, 200);
  assert.equal(count('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?', delta.id), 1, 'checking them in does not add a second visit for the same date');
  assert.equal(db.prepare('SELECT session_id FROM visitor_visits WHERE visitor_id = ?').get(delta.id).session_id, sessionId, 'it ties the existing visit to the Friday, so the Friday counts them');
  assert.equal(count('SELECT COUNT(DISTINCT visitor_id) n FROM visitor_visits WHERE session_id = ?', sessionId), 4, 'the Friday counts four First Timers: three at the desks and this one');

  // ---- latecomers after "the count" ----------------------------------------------------------------------------------------------------------------------
  const late = [people[30], people[48], people[55]];
  await Promise.all(late.map((p) => scan(stationA, p)));
  for (const p of late) expectedPresent.add(p.id);
  assert.deepEqual(recordsOf(), expectedPresent);

  // ---- the plain list says who should be absent ---------------------------------------------------------------------------------------------------------
  const rosterEverybody = db.prepare("SELECT id FROM members WHERE status IN ('active','pending','attendee','bonafide')").all().map((r) => r.id);
  const expectedAbsent = rosterEverybody.filter((id) => !expectedPresent.has(id));

  // ---- finalize ------------------------------------------------------------------------------------------------------------------------------------------------
  const preview = await admin.get(`/attendance/sessions/${sessionId}/finalize`);
  const previewText = await preview.text();
  assert.equal(preview.status, 200);
  assert.doesNotMatch(previewText, SECRETS);
  const fin1 = await admin.post(`/attendance/sessions/${sessionId}/finalize`, {}, { csrfFrom: `/attendance/sessions/${sessionId}/finalize` });
  const fin2 = await admin.post(`/attendance/sessions/${sessionId}/finalize`, {}, { csrfFrom: `/attendance/sessions/${sessionId}/finalize` });
  await fin1.text(); await fin2.text();
  assert.equal(count("SELECT COUNT(*) n FROM attendance_sessions WHERE id = ? AND finalization_state = 'finalized'", sessionId), 1, 'the Friday is finalized');
  assert.equal(auditCount('attendance.finalized'), 7, 'six history finalizations plus this one: the double-submitted finalize wrote one audit row, not two');
  const stateOf = (id) => db.prepare('SELECT status FROM attendance_records WHERE session_id = ? AND member_id = ?').get(sessionId, id)?.status ?? null;
  const presentRows = new Set(db.prepare("SELECT member_id FROM attendance_records WHERE session_id = ? AND status = 'present'").all(sessionId).map((r) => r.member_id));
  const rosterRows = db.prepare('SELECT member_id FROM attendance_expected WHERE session_id = ?').all(sessionId).map((r) => r.member_id).sort((a, b) => a - b);
  assert.deepEqual(rosterRows, [...rosterEverybody].sort((a, b) => a - b), 'the expected roster is every current member (the snapshot)');
  const derivedAbsent = rosterRows.filter((id) => !presentRows.has(id));
  assert.deepEqual(derivedAbsent, [...expectedAbsent].sort((a, b) => a - b), 'absent members are exactly the expected people with no present record (absence is derived from the roster, not stored)');
  assert.equal(stateOf(mistake.id), null, 'and the person whose mistaken mark was taken back has no record, so is absent, not present');

  // the door is closed, on every route
  const closedScan = await scan(stationA, people[58]);
  assert.equal(closedScan.status, 409);
  const closedRec = await desk.post('/attendance/checkin/record', { person: [`member:${people[58].id}`] }, { csrfFrom: '/attendance/checkin', headers: { Accept: 'application/json' } });
  assert.equal(closedRec.status, 409);
  const closedManual = await desk.post(`/attendance/sessions/${sessionId}/records`, { [`status_${people[58].id}`]: 'present' }, { csrfFrom: `/attendance/sessions/${sessionId}` });
  await closedManual.text();
  assert.ok(!recordsOf().has(people[58].id), 'nothing was added after finalization, by any route');
  console.log(`PASS (friday) ${expectedPresent.size} present, ${expectedAbsent.length} absent, 4 First Timers; duplicates, a mistake, a double submit and latecomers all resolved; the door closed on every route`);

  // ---- the views agree with the plain list --------------------------------------------------------------------------------------------------------------------
  const sessionPage = await (await admin.get(`/attendance/sessions/${sessionId}`)).text();
  const registerJson = JSON.parse(sessionPage.match(/<script type="application\/json" id="attendance-register-data">([\s\S]*?)<\/script>/)[1]);
  const onPage = new Map(registerJson.members.map((m) => [m.id, m.status]));
  for (const p of people) assert.equal(onPage.get(p.id), expectedPresent.has(p.id) ? 'present' : 'absent', `${p.name} is shown as ${expectedPresent.has(p.id) ? 'present' : 'absent'} on the Friday's own page`);
  assert.equal(registerJson.members.filter((m) => m.status === 'present').length, expectedPresent.size, 'the page shows exactly as many present as the plain list');
  for (const sample of [people[0], people[16], people[50], people[51], people[58], people[10]]) {
    const tab = await (await admin.get(`/members/${sample.id}/attendance`)).text();
    const present = expectedPresent.has(sample.id);
    assert.ok(present ? /Present/.test(tab) : /Absent/.test(tab), `${sample.name}'s own attendance page says ${present ? 'Present' : 'Absent'}`);
  }

  // follow-up: absent three Fridays running (counting this one), worked out here from the plain history
  const threshold = 3;
  const streakNow = (person) => { let streak = 0; const all = [...person.history, expectedPresent.has(person.id)]; for (let i = all.length - 1; i >= 0 && !all[i]; i -= 1) streak += 1; return streak; };
  const shouldFollow = people.filter((p) => streakNow(p) >= threshold && !(p.kind === 'newish' && p.history.length < threshold));
  const followPage = await (await admin.get('/attendance/follow-up?page_size=100')).text();
  for (const p of shouldFollow) assert.ok(followPage.includes(`/members/${p.id}`), `${p.name} (absent ${streakNow(p)} Fridays running) is on the follow-up list`);
  for (const p of people.filter((x) => streakNow(x) < threshold)) assert.ok(!followPage.includes(`/members/${p.id}"`), `${p.name} (absent ${streakNow(p)}) is not on the follow-up list`);

  // First Timers
  const firstTimers = await (await admin.get('/visitors?q=Guest')).text();
  for (const name of ['Guesta', 'Guestb', 'Guestc', 'Guestd']) assert.ok(firstTimers.includes(name), `${name} is on the First Timers list`);

  // the attendance CSV: one row per person with this Friday's mark
  const csv = await (await admin.get(`/attendance/reports/export.csv?from=${friday}&to=${friday}`)).text();
  const csvLines = csv.split(/\r?\n/).filter(Boolean);
  const presentInCsv = people.filter((p) => expectedPresent.has(p.id) && csvLines.some((line) => line.includes(p.name)));
  assert.equal(presentInCsv.length, people.filter((p) => expectedPresent.has(p.id)).length, 'every present person appears in the CSV for the Friday');

  // ---- bookkeeping -----------------------------------------------------------------------------------------------------------------------------------------
  assert.equal(auditCount('visitor.express_registered') + auditCount('visitor.created'), 4, 'one audit row per First Timer (the refused duplicate wrote none as a success)');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE result = 'failure' AND action LIKE 'attendance.%'") >= 2, true, 'the refused after-the-close writes are audited as failures');
  const findings = checkInvariants(db).findings.filter((x) => x.severity === 'error');
  assert.deepEqual(findings, [], 'every data rule holds after the Friday');
  const { createBackup, deepVerifyBackup } = await import('../services/backups.js');
  const backup = await createBackup({ kind: 'manual', note: 'after the Friday' });
  assert.ok(backup.ok);
  assert.ok((await deepVerifyBackup(backup.backup)).ok, 'a backup taken after the Friday verifies deeply');
  console.log('PASS (agree) the session page, 6 member pages, the follow-up list, the First Timer list and the CSV agree with the plain list; audit rows match the changes; data rules hold; a backup of it verifies');

  // ---- the PC is restarted on Friday night ---------------------------------------------------------------------------------------------------------------
  const before = {
    session: (await (await admin.get(`/attendance/sessions/${sessionId}`)).text()).length,
    follow: followPage.length,
    present: recordsOf().size
  };
  await portal.stop();
  const again3 = await startPortal();
  try {
    const admin2 = await signIn(again3.base, users.superAdmin.email, f.PASSWORD);
    const sp = await (await admin2.get(`/attendance/sessions/${sessionId}`)).text();
    const fp = await (await admin2.get('/attendance/follow-up?page_size=100')).text();
    assert.ok(Math.abs(sp.length - before.session) < 400, 'the Friday page is the same after a restart (apart from tokens and clock text)');
    assert.ok(Math.abs(fp.length - before.follow) < 400, 'and so is the follow-up list');
    assert.equal(recordsOf().size, before.present);
    const health = await (await fetch(`${again3.base}/healthz`)).json();
    assert.equal(health.status, 'ok');
    const reopened = await scan(await signIn(again3.base, users.kiosk.email, f.PASSWORD), people[58]);
    assert.equal(reopened.status, 409, 'the finalized Friday is still closed to check-ins after the restart');
  } finally {
    await again3.stop();
  }
  console.log('PASS (restart) after stopping and starting the portal the Friday, the follow-up list and the closed door are exactly as they were');
} finally {
  await portal.stop().catch(() => {});
}
db.close();
f.env.cleanup();
console.log('ALL PASS');
