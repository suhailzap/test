import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What a Member can see of Cell groups, and what they cannot.
 *   - A Member's navigation offers "Cell groups" next to "Ministries", and it opens THEIR OWN group (leader, assistant, when it meets, who is in it) - nothing else.
 *   - Their Dashboard "Your cell group" panel names their group (it used to say "You are not assigned to a cell group yet" to everyone: the route passed null) and
 *     links to it; My profile links to it too. A Member who really has no group is told so.
 *   - Direct addresses stay protected independently of any link: another group, the group's edit page, adding a group, the report and the attendance tabs are refused,
 *     and the group page never carries members' contact details or private notes.
 *   - A Cell Group leader reaches only the groups they lead; administrators reach every group; the Kiosk reaches none (it is sent to the Kiosk).
 */

const f = await buildPortalFixture('cciq-member-cg-');
const { db, ids, users, mods } = f;
const free = await (async () => {
  await mods.users.createUser({ username: 'fx_member_free', email: 'fx_member_free@fixture.invalid', password: f.PASSWORD, displayName: 'Fred', roleKeys: ['member'], memberId: ids.member.free, mustChangePassword: false });
  return 'fx_member_free@fixture.invalid';
})();

const portal = await startPortal();
try {
  const c = {
    member: await signIn(portal.base, users.memberA.email, f.PASSWORD), memberB: await signIn(portal.base, users.memberB.email, f.PASSWORD), free: await signIn(portal.base, free, f.PASSWORD),
    leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD), church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD),
    super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD)
  };
  const get = async (client, url) => { const r = await client.get(url); return { status: r.status, body: await r.text(), location: r.headers.get('location') }; };
  const mainText = (body) => (/<main[\s\S]*?<\/main>/.exec(body) || [body])[0].replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');
  const navOf = (body) => (/<nav class="sidenav"[\s\S]*?<\/nav>/.exec(body) || [''])[0];
  const alpha = ids.groupA; const beta = ids.groupB;

  // ---- navigation: Cell groups sits beside Ministries for a Member ---------------------------------------------------------------------------------------------------------
  { const home = await get(c.member, '/'); assert.equal(home.status, 200);
    assert.match(navOf(home.body), /href="\/cell-groups"/, 'a Member\'s navigation offers Cell groups'); assert.match(navOf(home.body), /href="\/ministries"/, 'next to Ministries');
    assert.ok(!/href="\/cell-groups\/new"/.test(navOf(home.body)), 'but not "Add group"'); }

  // ---- the Dashboard panel and My profile -------------------------------------------------------------------------------------------------------------------------------------------
  { const home = await get(c.member, '/'); const text = mainText(home.body);
    assert.ok(!/not assigned to a cell group/.test(text), 'a Member who belongs to a group is no longer told they have none');
    assert.match(text, /Your cell group\s+Group Alpha/); assert.match(text, /Leader\s+Alice LeaderA/); assert.match(text, /Meets\s+Tuesday/);
    assert.ok(home.body.includes(`href="/cell-groups/${alpha}"`), 'the panel links to their own group');
    assert.ok(!home.body.includes(`/cell-groups/${beta}`) && !/Group Beta/.test(home.body), 'and mentions no other group');
    const profile = await get(c.member, '/my/profile'); assert.ok(profile.body.includes(`href="/cell-groups/${alpha}"`), 'My profile links to the group');
    const bella = await get(c.memberB, '/'); assert.match(mainText(bella.body), /Your cell group\s+Group Beta/); assert.ok(bella.body.includes(`href="/cell-groups/${beta}"`));
    const fred = await get(c.free, '/'); assert.match(mainText(fred.body), /You are not assigned to a cell group yet/, 'a Member with no group is told so'); assert.ok(!/href="\/cell-groups\/\d+"/.test(mainText(fred.body)) && !/Open your cell group/.test(fred.body)); }

  // ---- the list and the group page -----------------------------------------------------------------------------------------------------------------------------------------------------
  { const list = await get(c.member, '/cell-groups'); assert.equal(list.status, 200); const text = mainText(list.body);
    assert.match(text, /Group Alpha/); assert.ok(!/Group Beta/.test(text), 'only their own group is listed'); assert.ok(!/Add group/.test(text));
    const page = await get(c.member, `/cell-groups/${alpha}`); assert.equal(page.status, 200); const body = mainText(page.body);
    assert.match(body, /Alice LeaderA/, 'the leader'); assert.match(body, /Anna MemberA/, 'and who is in the group');
    for (const secret of ['alice@fixture.invalid', '+974 5550 0001', '1 Alpha Street', 'private note a1', 'anna@fixture.invalid', '+974 5550 0002', '2 Alpha Street']) assert.ok(!page.body.includes(secret), `the group page carries no "${secret}"`);
    assert.ok(!/href="\/cell-groups\/\d+\/edit"/.test(page.body), 'no Edit'); assert.ok(!/Record meeting|Attendance|Reports/.test(body.replace(/Your Friday Service attendance/g, '')), 'no attendance or reports tabs');
    const tabs = await get(c.member, `/cell-groups/${alpha}?tab=attendance`); assert.ok(!/Record meeting/.test(tabs.body), 'asking for the attendance tab by address falls back to the overview'); }

  // ---- direct addresses are refused independently of any link ------------------------------------------------------------------------------------------------------------------------
  for (const url of [`/cell-groups/${beta}`, `/cell-groups/${beta}/quick`, `/cell-groups/${alpha}/edit`, '/cell-groups/new', `/cell-groups/${alpha}/report.csv`]) {
    const r = await get(c.member, url); assert.ok([403, 404].includes(r.status), `Member ${url} -> ${r.status}`);
  }
  { const own = await get(c.member, `/cell-groups/${alpha}/quick`); assert.equal(own.status, 200, 'their own group\'s quick view is available'); assert.ok(!/alice@fixture|5550 0001/.test(own.body)); }
  for (const [who, url, expected] of [['free', `/cell-groups/${alpha}`, 403], ['free', `/cell-groups/${beta}`, 403], ['memberB', `/cell-groups/${alpha}`, 403]]) { const r = await get(c[who], url); assert.equal(r.status, expected, `${who} ${url}`); }
  { const none = await get(c.free, '/cell-groups'); assert.equal(none.status, 200); assert.match(mainText(none.body), /No cell group yet/); }
  console.log('PASS (member) Cell groups is in a Member\'s navigation; the dashboard and profile name and link THEIR group; another group, edit, add and the report are refused; no contact details or attendance');

  // ---- every role --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const ownLed = await get(c.leader, `/cell-groups/${alpha}`); assert.equal(ownLed.status, 200, 'a leader reaches the group they lead');
    const otherLed = await get(c.leader, `/cell-groups/${beta}`); assert.equal(otherLed.status, 403, 'and not another');
    const list = await get(c.leader, '/cell-groups'); assert.ok(!/Group Beta/.test(mainText(list.body)), 'the leader\'s list holds only their own groups'); }
  for (const who of ['church', 'super']) for (const url of ['/cell-groups', `/cell-groups/${alpha}`, `/cell-groups/${beta}`, '/cell-groups/new']) { const r = await get(c[who], url); assert.equal(r.status, 200, `${who} ${url}`); }
  for (const url of ['/cell-groups', `/cell-groups/${alpha}`, '/ministries']) { const r = await get(c.kiosk, url); assert.equal(r.status, 302); assert.equal(r.location, '/kiosk', 'the Kiosk is sent to the Kiosk'); }
  console.log('PASS (roles) a leader reaches only the groups they lead; Church Admin and Super Admin reach all; the Kiosk reaches none');
  console.log('PASS member-cell-group');
} finally {
  await portal.stop();
}
