import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Migration 0031 (per-document "Who can view this?"): additive, and EXISTING documents keep exactly the visibility they have today.
 *   - a fresh database reaches 0031 with the column (default 'category'), the role table and its index;
 *   - a database taken back to 0030 with documents in every category audience upgrades with every row untouched (same values, mode 'category', no role rows), and
 *     re-running changes nothing;
 *   - who can open each of those documents is IDENTICAL before and after, for every role: an independent reference of the old rule (the category's audience alone) is
 *     compared with the real access check after the migration;
 *   - the database itself refuses an unknown mode or role (a Kiosk or "system admin" audience cannot be stored) and removes a document's role rows with the document;
 *   - the schema compatibility check reports the 0030 database as behind and the migrated one as compatible.
 */

createIsolatedTestEnv('cciq-migration-0031-');
const { migrate, EXPECTED_MIGRATIONS, checkSchemaCompatibility } = await import('../db/migrate.js');
migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const documents = await import('../services/documents.js');
const { default: db } = await import('../db/index.js');

const objects = (type) => db.prepare('SELECT name FROM sqlite_master WHERE type = ? ORDER BY name').all(type).map((r) => r.name);
const columns = (table) => db.prepare(`PRAGMA table_info(${table})`).all();

// ---- 1. a fresh database ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
{
  assert.ok(EXPECTED_MIGRATIONS.includes('0031_document_audience'));
  assert.ok(db.prepare("SELECT 1 FROM schema_migrations WHERE version = '0031_document_audience'").get(), 'recorded');
  const mode = columns('documents').find((c) => c.name === 'audience_mode');
  assert.ok(mode, 'documents.audience_mode exists'); assert.equal(mode.notnull, 1); assert.equal(mode.dflt_value, "'category'", "defaulting to 'category'");
  assert.ok(objects('table').includes('document_audience_roles')); assert.ok(objects('index').includes('idx_document_audience_roles_role'));
  assert.deepEqual(checkSchemaCompatibility(db).missing ?? [], []);
  console.log('PASS (1) a fresh database reaches 0031: the audience_mode column (NOT NULL, default category), the role table and its index');
}

// ---- 2. the database enforces its own limits -------------------------------------------------------------------------------------------------------------------------------------------
await users.createUser({ username: 'mig_admin', email: 'mig.admin@fixture.invalid', password: 'Mig-Fixture-Passw0rd!x', displayName: 'Mig Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'mig_admin'").get().id;
const category = (name, audience) => documents.createCategory({ name, audience, description: null }).id;
const cats = { staff: category('M staff', 'staff'), leaders: category('M leaders', 'leaders'), members: category('M members', 'members') };
const insertDoc = (title, categoryId, extra = {}) => Number(db.prepare(`INSERT INTO documents (title, description, category_id, original_filename, stored_path, mime_type, file_extension, file_size, document_date, expiry_date, status, version, uploaded_by, created_at, updated_at)
  VALUES (?, 'legacy', ?, 'a.png', 'documents/x/a.png', 'image/png', 'png', 10, '2026-01-01', ?, ?, 1, ?, '2026-01-02T00:00:00.000Z', '2026-01-02T00:00:00.000Z')`).run(title, categoryId, extra.expiry || null, extra.status || 'active', adminId).lastInsertRowid);
{
  const id = insertDoc('Limits', cats.members);
  assert.throws(() => db.prepare("UPDATE documents SET audience_mode = 'everyone' WHERE id = ?").run(id), /CHECK|constraint/i, 'an unknown mode is refused');
  for (const bad of ['kiosk', 'system_admin', '', 'pastor']) assert.throws(() => db.prepare('INSERT INTO document_audience_roles (document_id, role_key) VALUES (?, ?)').run(id, bad), /CHECK|constraint/i, `role "${bad}" cannot be stored`);
  db.prepare("INSERT INTO document_audience_roles (document_id, role_key) VALUES (?, 'member')").run(id);
  assert.throws(() => db.prepare("INSERT INTO document_audience_roles (document_id, role_key) VALUES (?, 'member')").run(id), /UNIQUE|PRIMARY|constraint/i, 'a role is stored once');
  assert.throws(() => db.prepare("INSERT INTO document_audience_roles (document_id, role_key) VALUES (999999, 'member')").run(), /FOREIGN|constraint/i, 'and only for a document that exists');
  db.prepare('DELETE FROM documents WHERE id = ?').run(id);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM document_audience_roles WHERE document_id = ?').get(id).n, 0, 'a document\'s role rows go with it');
  console.log('PASS (2) the database refuses an unknown mode and any role outside the four portal roles (no Kiosk, no "system admin"), a duplicate role, and a role for a missing document; role rows are removed with their document');
}

// ---- 3. a 0030 database with legacy documents upgrades, unchanged ---------------------------------------------------------------------------------------------------------------------------
function rewindTo0030() {
  db.pragma('foreign_keys = OFF');
  db.exec(`DROP INDEX IF EXISTS idx_document_audience_roles_role; DROP TABLE IF EXISTS document_audience_roles; ALTER TABLE documents DROP COLUMN audience_mode;
           DELETE FROM schema_migrations WHERE version = '0031_document_audience';`);
  db.pragma('foreign_keys = ON');
}
const rows = () => JSON.stringify(db.prepare('SELECT id, title, description, category_id, original_filename, stored_path, mime_type, file_size, document_date, expiry_date, status, version, uploaded_by, created_at, updated_at FROM documents ORDER BY id').all());
const legacy = {};
{
  rewindTo0030();
  assert.equal(columns('documents').some((c) => c.name === 'audience_mode'), false, 'sanity: the copy is at 0030');
  assert.equal(checkSchemaCompatibility(db).ok, false); assert.equal(checkSchemaCompatibility(db).reason, 'behind', 'a 0030 database is reported as behind');
  for (const [name, categoryId] of Object.entries(cats)) { legacy[`${name}`] = insertDoc(`Legacy ${name}`, categoryId); legacy[`${name}Expiring`] = insertDoc(`Legacy ${name} expiring`, categoryId, { expiry: '2026-12-31' }); }
  legacy.archived = insertDoc('Legacy archived', cats.members, { status: 'archived' });
  const before = rows(); const roleCount = () => objects('table').includes('document_audience_roles');
  assert.equal(roleCount(), false);
  migrate(); migrate(); // twice: the second is a no-op
  assert.equal(rows(), before, 'every document row is exactly as it was');
  assert.ok(roleCount()); assert.equal(db.prepare('SELECT COUNT(*) n FROM document_audience_roles').get().n, 0, 'no role rows were invented');
  assert.deepEqual(db.prepare("SELECT DISTINCT audience_mode FROM documents").all().map((r) => r.audience_mode), ['category'], "every existing document is in 'category' mode");
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations WHERE version = ?').get('0031_document_audience').n, 1, 'recorded once');
  assert.equal(checkSchemaCompatibility(db).ok, true);
  console.log('PASS (3) a 0030 database with legacy documents in every category audience upgrades with every row untouched, in category mode, no role rows, and a second run changes nothing');
}

// ---- 4. who can open each legacy document is identical before and after -------------------------------------------------------------------------------------------------------------------
{
  const account = async (username, roleKeys, memberId = null) => {
    await users.createUser({ username, email: `${username}@fixture.invalid`, password: 'Mig-Fixture-Passw0rd!x', displayName: username, roleKeys, memberId, mustChangePassword: false });
    return users.loadUserContext(db.prepare('SELECT id FROM users WHERE username = ?').get(username).id);
  };
  const who = {
    super: await account('mig_super', ['super_admin']), church: await account('mig_church', ['church_admin']), leader: await account('mig_leader', ['cell_group_leader', 'member']),
    member: await account('mig_member', ['member']), kiosk: await account('mig_kiosk', ['kiosk'])
  };
  // the OLD rule, restated independently: administrators (documents.manage) open everything; a leader opens the members and leaders categories; a member opens the members
  // category; the Kiosk (no documents.view) nothing. Nothing else decides it.
  const oldRule = (user, doc) => {
    if (!user.can('documents.view')) return false;
    if (user.can('documents.manage')) return true;
    const audience = db.prepare('SELECT audience FROM document_categories WHERE id = ?').get(doc.category_id).audience;
    return user.can('cellgroups.manage_own') ? ['members', 'leaders'].includes(audience) : audience === 'members';
  };
  const all = db.prepare('SELECT id, category_id, status FROM documents').all();
  const expected = Object.fromEntries(Object.entries(who).map(([name, user]) => [name, all.map((d) => [d.id, oldRule(user, d)])]));
  for (const [name, user] of Object.entries(who)) {
    const actual = all.map((d) => [d.id, documents.canSee(user, documents.getDocument(d.id))]);
    assert.deepEqual(actual, expected[name], `${name}: the same documents open as before the migration`);
    // and the lists agree with the single-document check
    const scope = documents.scopeFor(user);
    const listed = scope.type === 'none' ? [] : documents.listDocuments({ scope, status: 'active', pageSize: 100 }).rows.map((r) => r.id).sort((a, b) => a - b);
    const shouldList = expected[name].filter(([id, ok]) => ok && all.find((d) => d.id === id).status === 'active').map(([id]) => id).sort((a, b) => a - b);
    assert.deepEqual(listed, shouldList, `${name}: the library lists the same documents as before`);
    const stats = scope.type === 'none' ? null : documents.libraryStats({ scope });
    if (stats) assert.equal(stats.active, shouldList.length, `${name}: the counts agree`);
  }
  assert.equal(who.kiosk.can('documents.view'), false, 'the Kiosk holds no document access, before or after');
  console.log('PASS (4) for a Super Admin, a Church Admin, a Cell Group leader, a Member and the Kiosk, the documents that open, the library listing and the counts are identical to the old category-only rule');
}
console.log('PASS migration-0031');
