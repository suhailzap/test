import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Attendance non-regression torture pass. NO semantic is changed or assumed beyond what the approved Phase 2A/2B/2C rules and the
 * existing suites already say; this only checks that those rules keep holding under long, seeded, random sequences of the real
 * service operations (marks, status changes, finalize, not-taken, reopen, corrections, repeated and out-of-order calls):
 *
 *   - a finalized Friday's expected-roster snapshot never changes - not by later status changes, not by corrections, not by
 *     reopen and finalize again (the snapshot is reused);
 *   - expected = present + vacation + recorded absent + no row, for every Friday, always;
 *   - finalizing twice, reopening an open Friday, correcting an open Friday and marking a finalized one "not taken" are refused
 *     and change nothing;
 *   - a not-taken Friday that was never finalized has no expected snapshot (one that was finalized, reopened and then marked not taken keeps
 *     the snapshot reopen preserved);
 *   - the data-integrity rules hold after every step.
 * Seeded, so a failure is reproducible: the seed and the step are in the message.
 */

createIsolatedTestEnv('cciq-attendance-torture-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember, changeStatus } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const attendance = await import('../services/attendance.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { checkInvariants } = await import('../lib/db-invariants.js');
const { default: db } = await import('../db/index.js');

await createUser({ username: 'torture_admin', email: 'torture@fixture.invalid', password: `Tt${crypto.randomBytes(12).toString('base64url')}9!`, displayName: 'Torture Admin', roleKeys: ['super_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'torture_admin'").get().id;

// A population with a spread of statuses, all with a clean history that starts long before tracking begins.
const STATUSES = ['active', 'active', 'active', 'pending', 'attendee', 'bonafide', 'temporarily_away', 'inactive', 'archived', 'migrated'];
const memberIds = [];
for (let i = 0; i < 60; i += 1) memberIds.push(createMember({ first_name: `Tort${i}`, last_name: `Person${i % 7}` }, { status: STATUSES[i % STATUSES.length] }).id);
db.prepare("UPDATE members SET created_at = '2020-01-01T00:00:00.000Z', date_joined = '2020-01-01'").run();
db.prepare("UPDATE member_status_history SET changed_at = '2020-01-01T00:00:00.000Z'").run();

const lastFriday = lastFridayOnOrBefore(addDays(today(), -8)); // a Friday that is firmly in the past
const fridays = Array.from({ length: 8 }, (_, i) => addDays(lastFriday, -7 * (7 - i)));
assert.ok(lifecycle.setTrackingStartDate(fridays[0], { userId: adminId }).ok, 'tracking starts at the first Friday');
for (const date of fridays) {
  db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(date, '2020-01-01T00:00:00.000Z');
}
const sessionIds = fridays.map((d) => db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(d).id);

const snapshotOf = (id) => crypto.createHash('sha256').update(JSON.stringify(db.prepare('SELECT member_id, status_at_service FROM attendance_expected WHERE session_id = ? ORDER BY member_id').all(id))).digest('hex');
const stateOf = (id) => db.prepare('SELECT finalization_state s, finalized_at f FROM attendance_sessions WHERE id = ?').get(id);
const rows = (id) => JSON.stringify(db.prepare('SELECT member_id, status FROM attendance_records WHERE session_id = ? ORDER BY member_id').all(id));

function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

const originalSnapshot = new Map(); // session id -> snapshot hash at the moment it was first finalized
let operations = 0;
function checkEverything(seed, step, label) {
  const findings = checkInvariants(db).findings.filter((f) => f.severity === 'error');
  assert.deepEqual(findings, [], `[seed ${seed} step ${step} after ${label}] the data-integrity rules hold`);
  for (const id of sessionIds) {
    const state = stateOf(id).s;
    const session = lifecycle.getSession ? lifecycle.getSession(id) : attendance.getSession(id);
    const roster = lifecycle.expectedRosterForSession(session);
    const summary = lifecycle.computeSessionSummary(session, roster, state === 'finalized' ? 'finalized' : 'open');
    assert.equal(summary.presentExpected + summary.vacation + summary.absentRecorded + summary.willBecomeAbsent, summary.expected, `[seed ${seed} step ${step}] session ${id}: expected = present + vacation + recorded absent + no row`);
    if (state === 'finalized') {
      if (originalSnapshot.has(id)) assert.equal(snapshotOf(id), originalSnapshot.get(id), `[seed ${seed} step ${step} after ${label}] session ${id}: the finalized Friday's expected roster never changed`);
      assert.equal(summary.derivedAbsent, summary.willBecomeAbsent, 'a finalized Friday turns "no row" into derived absence');
    }
    // A Friday that was finalized, reopened (which PRESERVES its snapshot) and then marked not-taken legitimately still carries it.
    if (state === 'not_taken' && !originalSnapshot.has(id)) assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?').get(id).n, 0, `[seed ${seed} step ${step}] session ${id}: a never-finalized not-taken Friday has no expected snapshot`);
  }
}

for (const seed of [20260930, 7, 424242]) {
  const random = rng(seed);
  const pick = (list) => list[Math.floor(random() * list.length)];
  for (let step = 1; step <= 110; step += 1) {
    const id = pick(sessionIds);
    const before = { state: stateOf(id), rows: rows(id), snapshot: snapshotOf(id) };
    const choice = random();
    let label;
    if (choice < 0.36) { // marks
      label = 'marks';
      const entries = Array.from({ length: 1 + Math.floor(random() * 6) }, () => ({ memberId: pick(memberIds), status: pick(['present', 'present', 'absent', 'excused', 'remove']) }));
      const res = attendance.recordAttendance(id, entries, { userId: adminId });
      if (before.state.s) assert.ok(res.ok === false || res.ok === true); // a finalized Friday may refuse ordinary marks; whichever it does must leave the snapshot alone
    } else if (choice < 0.55) {
      label = 'finalize';
      const res = lifecycle.finalizeAttendance(id, { userId: adminId, confirmNoAttendance: true });
      if (res.ok) { if (!originalSnapshot.has(id)) originalSnapshot.set(id, snapshotOf(id)); } else if (before.state.s) { assert.equal(stateOf(id).f, before.state.f, `finalizing an already-settled Friday changes nothing (${res.reason})`); }
    } else if (choice < 0.63) {
      label = 'not taken';
      const res = lifecycle.markAttendanceNotTaken(id, { userId: adminId, note: 'torture', confirmExistingAttendance: true });
      if (!res.ok && before.state.s) assert.equal(stateOf(id).f, before.state.f, `marking an already-settled Friday "not taken" changes nothing (${res.reason})`);
    } else if (choice < 0.72) {
      label = 'reopen';
      const res = lifecycle.reopenAttendance(id, { userId: adminId, reason: 'torture' });
      if (!res.ok) assert.ok(!before.state.s || res.reason === 'session_cancelled', `reopening fails only for an open or cancelled Friday (${res.reason})`);
      if (!res.ok && !before.state.s) assert.deepEqual({ state: stateOf(id), rows: rows(id), snapshot: snapshotOf(id) }, before, 'reopening an open Friday changes nothing');
      if (res.ok) assert.equal(snapshotOf(id), before.snapshot, 'reopening keeps the snapshot');
    } else if (choice < 0.84) {
      label = 'correction';
      const changes = Array.from({ length: 1 + Math.floor(random() * 3) }, () => ({ memberId: pick(memberIds), to: pick(['present', 'excused', 'absent', 'remove']) }));
      const res = lifecycle.correctFinalizedAttendance(id, changes, { userId: adminId, reason: 'torture' });
      if (!before.state.s || before.state.s === 'not_taken') { assert.equal(res.ok, false, 'an open or not-taken Friday cannot be corrected'); assert.equal(rows(id), before.rows, 'and nothing changed'); }
      assert.equal(snapshotOf(id), before.snapshot, 'a correction never changes the snapshot');
    } else if (choice < 0.94) {
      label = 'member status change';
      const member = pick(memberIds);
      changeStatus(member, pick(['active', 'inactive', 'temporarily_away', 'pending', 'archived', 'attendee']), { userId: adminId, reason: 'torture' });
    } else {
      label = 'repeat finalize';
      const first = lifecycle.finalizeAttendance(id, { userId: adminId, confirmNoAttendance: true });
      if (first.ok && !originalSnapshot.has(id)) originalSnapshot.set(id, snapshotOf(id));
      const again = lifecycle.finalizeAttendance(id, { userId: adminId, confirmNoAttendance: true });
      assert.equal(again.ok, false, 'finalizing twice is refused');
    }
    operations += 1;
    checkEverything(seed, step, label);
  }
}

// A reopen -> finalize round trip with no change in between reproduces the same summary.
const settled = sessionIds.find((id) => stateOf(id).s === 'finalized') || (() => { const id = sessionIds[0]; const res = lifecycle.finalizeAttendance(id, { userId: adminId, confirmNoAttendance: true }); assert.ok(res.ok || stateOf(id).s); return id; })();
if (stateOf(settled).s === 'finalized') {
  const before = lifecycle.computeSessionSummary(attendance.getSession(settled), lifecycle.expectedRosterForSession(attendance.getSession(settled)), 'finalized');
  assert.ok(lifecycle.reopenAttendance(settled, { userId: adminId, reason: 'round trip' }).ok);
  assert.ok(lifecycle.finalizeAttendance(settled, { userId: adminId, confirmNoAttendance: true }).ok);
  const after = lifecycle.computeSessionSummary(attendance.getSession(settled), lifecycle.expectedRosterForSession(attendance.getSession(settled)), 'finalized');
  assert.deepEqual(after, before, 'reopen then finalize with nothing changed in between gives the identical summary');
}
const settledCount = sessionIds.filter((id) => stateOf(id).s).length;
assert.ok(originalSnapshot.size >= 3, `enough Fridays were finalized for the snapshot rule to be exercised (${originalSnapshot.size})`);
console.log(`PASS (attendance torture) ${operations} seeded random operations across 3 seeds kept every rule: snapshots immutable, buckets add up, repeated/out-of-order calls refused and harmless, integrity rules hold (${settledCount} of ${sessionIds.length} Fridays settled at the end)`);
console.log('ALL PASS');
