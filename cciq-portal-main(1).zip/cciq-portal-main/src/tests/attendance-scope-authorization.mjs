import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness, R04 from the red-team review: /attendance/sessions/:id/add
 * checked only that a Cell Group Leader could record for the *session* (which
 * canRecordFor() already grants unconditionally for any Friday Service), but
 * never re-checked that each individually *selected member* was actually in
 * a group the leader leads - unlike its sibling /records, which filters
 * submitted member ids to the leader's own roster. A leader could add any
 * member in the church to the shared Friday Service register through this
 * search-and-add screen. Fixed by scopeSelectionForRecording() in
 * routes/attendance.js, applied before recordAttendanceForPeople() is called.
 * Tested here via real HTTP requests against the actual route, not by
 * calling the service function directly - the defect was specifically that
 * the ROUTE never enforced this, so the route is what must be proven fixed.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-attendance-scope-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const { createUser } = await import('../services/users.js');
const { createSession } = await import('../services/attendance.js');
const { createVisitor } = await import('../services/visitors.js');
const { today } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const groupA = createGroup({ name: 'Group A' }, {});
const groupB = createGroup({ name: 'Group B' }, {});
const leaderMember = createMember({ first_name: 'Leader', last_name: 'Alpha' }, { status: 'active' });
db.prepare('UPDATE cell_groups SET leader_member_id = ? WHERE id = ?').run(leaderMember.id, groupA.id);

const memberInGroupA = createMember({ first_name: 'InGroup', last_name: 'A', cell_group_id: groupA.id }, { status: 'active' });
const memberInGroupB = createMember({ first_name: 'InGroup', last_name: 'B', cell_group_id: groupB.id }, { status: 'active' });

await createUser({
  email: 'leader.alpha@fixture.invalid', password: 'LeaderPassw0rd!2026',
  displayName: 'Leader Alpha', roleKeys: ['cell_group_leader'], memberId: leaderMember.id, mustChangePassword: false
});
await createUser({
  email: 'admin.fixture@fixture.invalid', password: 'AdminPassw0rd!2026',
  displayName: 'Admin Fixture', roleKeys: ['church_admin'], mustChangePassword: false
});

const fridaySession = createSession({ service_date: today(), service_type: 'friday_service', title: 'Fixture Friday' });

// A "visitor" (not yet a member, no cell-group concept) for the visitor-scope
// check. Backdated first_visit_date so createVisitor()'s own initial visit
// row (dated first_visit_date) doesn't collide with the (visitor_id,
// visit_date) unique constraint when the test below records today's visit.
const { addDays } = await import('../lib/dates.js');
const visitorId = createVisitor({ first_name: 'Walk', last_name: 'In', first_visit_date: addDays(today(), -7) }).id;

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

async function login(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  assert.equal(loginPost.status, 302, `login must succeed for ${email}`);
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preCookie;
}

async function csrfFor(urlPath, cookie) {
  const page = await fetch(`${base}${urlPath}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

async function postAdd(cookie, sessionId, personValue) {
  const csrf = await csrfFor(`/attendance/sessions/${sessionId}`, cookie);
  return fetch(`${base}/attendance/sessions/${sessionId}/add`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ person: personValue, _csrf: csrf })
  });
}

function wasRecorded(sessionId, memberId) {
  return Boolean(db.prepare(
    "SELECT 1 FROM attendance_records WHERE session_id = ? AND member_id = ? AND status = 'present'"
  ).get(sessionId, memberId));
}

const leaderCookie = await login('leader.alpha@fixture.invalid', 'LeaderPassw0rd!2026');
const adminCookie = await login('admin.fixture@fixture.invalid', 'AdminPassw0rd!2026');

// --- 1. Leader can add a member from their own group. ---
{
  const res = await postAdd(leaderCookie, fridaySession.id, `member:${memberInGroupA.id}`);
  assert.equal(res.status, 302);
  assert.ok(wasRecorded(fridaySession.id, memberInGroupA.id), 'a leader must be able to add a member from their own group');
  console.log('PASS: a Cell Group Leader can add a member from their own group via /attendance/sessions/:id/add');
}

// --- 2. Leader CANNOT add a member from a different group — the direct-route bypass. ---
{
  const res = await postAdd(leaderCookie, fridaySession.id, `member:${memberInGroupB.id}`);
  assert.equal(res.status, 302, 'the request itself should not error, just silently not record the out-of-scope person');
  assert.equal(wasRecorded(fridaySession.id, memberInGroupB.id), false,
    'R04 CONFIRMED FIXED: a leader must not be able to add a member outside their own group via a direct HTTP request');
  console.log('PASS: a Cell Group Leader cannot add a member from a different group via a direct HTTP request');
}

// --- 3. Leader CAN add a visitor regardless of scope (documented, intentional). ---
{
  const res = await postAdd(leaderCookie, fridaySession.id, `visitor:${visitorId}`);
  assert.equal(res.status, 302);
  const recorded = db.prepare(
    "SELECT 1 FROM visitor_visits WHERE visitor_id = ? AND session_id = ?"
  ).get(visitorId, fridaySession.id);
  assert.ok(recorded, 'a leader must still be able to record a visitor through this screen, regardless of cell-group scope');
  console.log('PASS: a Cell Group Leader can still add a visitor regardless of cell-group scope (intentional)');
}

// --- 4. Admin remains unrestricted (no regression). ---
{
  const res = await postAdd(adminCookie, fridaySession.id, `member:${memberInGroupB.id}`);
  assert.equal(res.status, 302);
  assert.ok(wasRecorded(fridaySession.id, memberInGroupB.id), 'an admin must remain unrestricted and able to add any member');
  console.log('PASS: an admin remains unrestricted, able to add a member from any group');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
