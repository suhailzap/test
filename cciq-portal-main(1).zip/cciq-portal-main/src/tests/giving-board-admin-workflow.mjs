import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Giving Board administration, as the Church Admin uses it:
 *   D  claim a date ON BEHALF of a member (review step, fixed QAR 300, the day belongs to the member, the administrator is the recorder) and who may do it;
 *   E  the payment status is the ledger's: it cannot be typed, QAR 0 received is never "Paid", 100 then 200 against 300 is Part paid then Paid, with the right balance;
 *   F  the working list carries date, member, Member ID, commitment, received, balance, status, claimed time and provenance, last payment, Record payment / History / Release;
 *   G  the summary figures are real links that open the matching working list in a NEW TAB, and the list keeps its filter, search and page in the address.
 */

const f = await buildPortalFixture('cciq-gb-admin-');
const { db, ids, users, mods } = f;
const one = (sql, ...p) => db.prepare(sql).get(...p);
db.prepare("UPDATE ecaq_campaigns SET status = 'draft' WHERE id = ?").run(ids.board); // the fixture's 2026 board steps aside
const board = mods.ecaq.createCampaign({ name: '2025 Thanksgiving Project (Giving Board)', year: 2025, type: 'giving_board', status: 'active', privacy_mode: 'first_name', currency: 'QAR', start_date: '2025-01-01', end_date: '2025-12-31' });
const dates = mods.ecaq.boardDates(2025);
const claimRow = (id) => one('SELECT * FROM ecaq_giving_board_claims WHERE id = ?', id);
const claimsOnBoard = () => one('SELECT COUNT(*) n FROM ecaq_giving_board_claims WHERE campaign_id = ?', board.id).n;

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const tokenOf = async (c, from) => c.csrf(from);
  const adminToken = await tokenOf(admin, '/account/password');
  const text = async (client, url) => { const res = await client.get(url); return { status: res.status, body: await res.text(), location: res.headers.get('location') }; };
  const post = async (client, token, url, fields) => { const res = await client.post(url, fields, { csrf: token }); const body = await res.text(); return { status: res.status, body, location: res.headers.get('location') }; };

  // ---- D. claim on behalf ----------------------------------------------------------------------------------------------------------------------------------------------
  const target = '2025-03-18';
assert.ok(dates.includes(target));
  const form = await text(admin, `/admin/ecaq/claims/new?date=${target}`);
  assert.equal(form.status, 200);
  assert.ok(!/name="commitment_amount"/.test(form.body), 'the amount is not typed: a Giving Board date is a fixed commitment');
  assert.ok(!/QAR/.test(form.body.replace(/<script[\s\S]*?<\/script>/g, '')), 'STEP 1 (choose the member) shows no commitment amount at all');
  assert.ok(!/Commitment/i.test(/<main[\s\S]*?<\/main>/.exec(form.body)?.[0] || ''), 'and does not even mention a commitment');
  assert.match(form.body, /<h1>Claim Tuesday 18 March 2025 for a member<\/h1>/, 'the full date is named');
  assert.match(form.body, /on behalf of a member/, 'a concise explanation that this is on the member\'s behalf');
  assert.match(form.body, /<form class="form" method="post" action="\/admin\/ecaq\/claims"/, 'the standard form rhythm');
  assert.match(form.body, /<div class="form__actions">\s*<button class="btn" type="submit"[^>]*>Review<\/button>\s*<a class="btn btn--secondary"[^>]*>Cancel<\/a>/, 'Review and Cancel in the standard action bar, separated from the fields');
  assert.match(form.body, /<label for="notes">Notes/, 'Notes is a normal labelled field');
  assert.match(form.body, /data-picker-selected/, 'the member picker with its selected-member card (name, Member ID, cell group, Change, Clear)');
  assert.match(form.body, /data-picker-change/); assert.match(form.body, /data-picker-clear/);

  const memberA = ids.member.a2;
  const review = await post(admin, adminToken, '/admin/ecaq/claims', { date: target, member_id: memberA, commitment_amount: '5' });
  assert.equal(review.status, 200, 'first a review');
  assert.match(review.body, /Review the claim/);
  assert.match(review.body, /<dt>Date<\/dt>\s*<dd><strong>Tuesday 18 March 2025<\/strong><\/dd>/, 'the full date');
  assert.match(review.body, /Anna MemberA/);
  assert.match(review.body, /<dt>Member ID<\/dt>\s*<dd>CCIQ-\d+<\/dd>/, 'the Member ID');
  assert.match(review.body, /<dt>Commitment<\/dt>\s*<dd><strong>QAR 300<\/strong><\/dd>/, 'the REVIEW shows the commitment');
  assert.match(review.body, /fixed Giving Board commitment of QAR 300/, 'and says it is fixed');
  assert.match(review.body, />Confirm claim</); assert.match(review.body, /Back \/ change/);
  assert.match(review.body, /href="\/admin\/ecaq\/claims\/new\?date=2025-03-18&amp;member_id=\d+&amp;notes="/, 'Back keeps the date and the member');
  const backTo = await text(admin, `/admin/ecaq/claims/new?date=${target}&member_id=${memberA}&notes=hello`);
  assert.match(backTo.body, /Anna MemberA/, 'coming back shows the member already chosen'); assert.match(backTo.body, /value="hello"/);
  assert.equal(claimsOnBoard(), 0, 'nothing is recorded by the review');

  const done = await post(admin, adminToken, '/admin/ecaq/claims', { date: target, member_id: memberA, notes: 'asked by phone', commitment_amount: '5', confirm: '1' });
  assert.equal(done.status, 302);
  const flash = await text(admin, done.location); // (read first: a flash message is shown once)
  assert.match(flash.body, /Tuesday, 18 March 2025 recorded for Anna MemberA/, 'a human-readable confirmation');
  const claim = one('SELECT * FROM ecaq_giving_board_claims WHERE campaign_id = ?', board.id);
  assert.equal(claim.member_id, memberA, 'the day belongs to the member');
  assert.equal(claim.commitment_amount, 300, 'QAR 300 whatever was posted');
  assert.equal(claim.created_by, users.superAdmin.id, 'the administrator is the recorder');
  assert.equal(claim.payment_status, 'not_paid');
  const audit = JSON.parse(one("SELECT detail FROM audit_logs WHERE action = 'giving.claim_recorded_by_admin' ORDER BY id DESC LIMIT 1").detail);
  assert.equal(audit.member_id, memberA); assert.equal(audit.recorded_by, users.superAdmin.id); assert.equal(audit.commitment, 300);
  const mine = await text(member, '/projects/ecaq/my-commitments');
  assert.match(mine.body, /18 March 2025/, 'the member sees it under their commitments');
  const again = await post(admin, adminToken, '/admin/ecaq/claims', { date: target, member_id: ids.member.a3, confirm: '1' });
  assert.equal(again.status, 400, 'a taken date cannot be taken twice');
  assert.equal(claimsOnBoard(), 1);

  // who may
  const churchToken = await tokenOf(church, '/account/password');
  const second = dates[40];
  assert.equal((await text(church, `/admin/ecaq/claims/new?date=${second}`)).status, 200, 'a Church Admin may');
  const byChurch = await post(church, churchToken, '/admin/ecaq/claims', { date: second, member_id: ids.member.a3, confirm: '1' });
  assert.equal(byChurch.status, 302);
  assert.equal(one('SELECT created_by FROM ecaq_giving_board_claims WHERE claim_date = ?', second).created_by, users.churchAdmin.id);
  for (const [who, client] of [['member', member], ['leader', leader]]) {
    const token = await tokenOf(client, '/account/password');
    const denied = await text(client, `/admin/ecaq/claims/new?date=${dates[60]}`);
    assert.ok([302, 403].includes(denied.status) && !/Review|Claim .* for a member/.test(denied.body), `${who} cannot open the claim-for-a-member screen`);
    const before = claimsOnBoard();
    await post(client, token, '/admin/ecaq/claims', { date: dates[60], member_id: ids.member.a3, confirm: '1' });
    assert.equal(claimsOnBoard(), before, `${who} cannot claim for another member`);
    const board2 = await text(client, '/projects/ecaq/board?year=2025');
    assert.ok(!/Claim for a member/.test(board2.body) && !/\/admin\/ecaq\/claims\/new/.test(board2.body), `${who}: the board offers no admin claim`);
  }
  const adminBoard = await text(admin, '/projects/ecaq/board?year=2025');
  assert.match(adminBoard.body, /Claim for a member/);
  assert.match(adminBoard.body, new RegExp(`href="/admin/ecaq/claims/new\\?date=2025-01-02"`), 'an administrator\'s free date leads to claiming it for a member');

  // ---- E. the status is the ledger's -----------------------------------------------------------------------------------------------------------------------------------
  const adminPage = await text(admin, `/admin/ecaq?campaign=${board.id}`);
  // the page's main operational action is the primary button, first in the row, exactly as on the Faith Promise page
  assert.match(adminPage.body, /<div class="page-head__actions">\s*(?:<%#[\s\S]*?%>\s*)?<a class="btn" href="\/projects\/ecaq\/board\?year=2025">Claim a date for a member<\/a>\s*<a class="btn btn--secondary" href="\/admin\/ecaq\/campaigns\/new">New campaign<\/a>/, 'Giving Board: "Claim a date for a member" is the primary action');
  const promiseId = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'faith_promise' LIMIT 1").get().id;
  const faithPage = await text(admin, `/admin/ecaq/faith-promise?campaign=${promiseId}`);
  assert.match(faithPage.body, /<div class="page-head__actions">\s*<a class="btn" href="\/admin\/ecaq\/faith-promise\/new\?campaign=\d+">Record for a member<\/a>\s*<a class="btn btn--secondary" href="\/admin\/ecaq\/campaigns\/new">New campaign<\/a>/, 'Faith Promise: "Record for a member" is the primary action, in the same place');
  for (const body of [adminPage.body, faithPage.body]) {
    const bar = /<div class="page-head__actions">[\s\S]*?<\/div>/.exec(body)[0];
    assert.equal((bar.match(/class="btn"/g) || []).length, 1, 'exactly one primary action in the bar; the management actions are secondary');
  }
  const faithForm = await text(admin, `/admin/ecaq/faith-promise/new?campaign=${promiseId}`);
  assert.match(faithForm.body, /<form class="form" method="post" action="\/admin\/ecaq\/faith-promise\/new"/, 'the Faith Promise form uses the same form rhythm');
  assert.match(faithForm.body, /<div class="form__actions">/, 'and the same action bar');
  assert.ok(!/name="payment_status"/.test(adminPage.body) && !/name="amount_collected"/.test(adminPage.body), 'no status dropdown and no collected box');
  const id = claim.id;
  await post(admin, adminToken, `/admin/ecaq/claims/${id}`, { commitment_amount: '300', payment_status: 'paid', amount_collected: '300', notes: '' });
  assert.deepEqual([claimRow(id).payment_status, claimRow(id).amount_collected], ['not_paid', 0], 'QAR 0 received is never Paid, however it is posted');
  await post(admin, adminToken, `/admin/ecaq/claims/${id}/payments`, { amount: '100', paid_on: mods.dates.addDays(mods.dates.today(), -20), method: 'cash' });
  let c = claimRow(id);
  assert.deepEqual([c.amount_collected, c.payment_status], [100, 'partially_paid'], '100 of 300: part paid');
  let page = await text(admin, `/admin/ecaq/claims/${id}`);
  assert.match(page.body, /QAR 100/); assert.match(page.body, /QAR 200/); assert.match(page.body, /Partially paid/);
  assert.match(page.body, /Claimed .*recorded by .* for the member/s, 'the claim page says who recorded it');
  const futureTry = await post(admin, adminToken, `/admin/ecaq/claims/${id}/payments`, { amount: '50', paid_on: mods.dates.addDays(mods.dates.today(), 2), method: 'cash' });
  assert.equal(futureTry.status, 302); assert.equal(claimRow(id).amount_collected, 100, 'a future payment date is refused');
  await post(admin, adminToken, `/admin/ecaq/claims/${id}/payments`, { amount: '200', paid_on: mods.dates.today(), method: 'bank_transfer', reference: 'TT-7' });
  c = claimRow(id);
  assert.deepEqual([c.amount_collected, c.payment_status], [300, 'paid'], '100 + 200 against 300: paid');
  page = await text(admin, `/admin/ecaq/claims/${id}`);
  assert.match(page.body, /Recorded in the portal/);
  const payments = db.prepare('SELECT paid_on, created_at FROM ecaq_payments WHERE claim_id = ? ORDER BY id').all(id);
  assert.ok(payments[0].paid_on < payments[1].paid_on && payments[0].created_at.slice(0, 10) >= payments[0].paid_on, 'the actual payment date is kept apart from when it was recorded');
  const msg = await post(admin, adminToken, `/admin/ecaq/claims/${id}`, { commitment_amount: '300', notes: 'checked' });
  const msgPage = await text(admin, msg.location);
  assert.match(msgPage.body, /Commitment for [A-Za-z]+, 18 March 2025 updated\./, 'a human-readable message, not 2025-03-18');
  assert.ok(!/Commitment for 2025-03-18/.test(msgPage.body));

  // ---- F/G/H. the working list and the summary shortcuts -----------------------------------------------------------------------------------------------------------------
  // 12 not paid, 10 part paid, 8 paid more (plus the one above that is paid and the one the Church Admin made, not paid)
  const makeMember = (n) => mods.members.createMember({ first_name: `Work${String(n).padStart(2, '0')}`, last_name: 'Queue' }, { status: 'active' });
  let n = 0;
  const give = (count, amount) => { for (let i = 0; i < count; i += 1) { const m = makeMember(n); const r = mods.ecaq.createClaim({ campaignId: board.id, date: dates[100 + n], memberId: m.id, userId: users.churchAdmin.id }); assert.ok(r.ok); if (amount) mods.ecaq.addPayment(r.claim.id, { amount, paid_on: mods.dates.today(), method: 'cash' }, { userId: users.churchAdmin.id }); n += 1; } };
  give(12, 0); give(10, 120); give(8, 300);
  const counts = Object.fromEntries(db.prepare('SELECT payment_status s, COUNT(*) n FROM ecaq_giving_board_claims WHERE campaign_id = ? GROUP BY payment_status').all(board.id).map((r) => [r.s, r.n]));
  assert.deepEqual(counts, { not_paid: 13, partially_paid: 10, paid: 9 });

  const summary = await text(admin, `/admin/ecaq?campaign=${board.id}`);
  const card = (label) => new RegExp(`<a class="card stat stat--drill" href="([^"]+)" target="_blank" rel="noopener">\\s*<p class="stat__label">${label}</p>\\s*<p class="stat__value">([^<]+)</p>`).exec(summary.body);
  const notPaid = card('Not paid'); const part = card('Partially paid'); const paid = card('Paid'); const outstanding = card('Outstanding');
  for (const [name, m] of [['Not paid', notPaid], ['Partially paid', part], ['Paid', paid], ['Outstanding', outstanding]]) assert.ok(m, `${name} is a link that opens in a new tab`);
  assert.equal(notPaid[2], '13'); assert.equal(part[2], '10'); assert.equal(paid[2], '9');
  assert.match(notPaid[1], /payment=not_paid/); assert.match(part[1], /payment=partially_paid/); assert.match(outstanding[1], /payment=outstanding/);
  assert.match(summary.body, /<span class="sr-only">\(opens in a new tab\)<\/span>/, 'the new tab is announced');
  assert.match(outstanding[2], /QAR/, 'the outstanding amount is shown');

  const listOf = async (query) => text(admin, `/admin/ecaq?campaign=${board.id}${query}`);
  const rowCount = (html) => (html.match(/<tr>\s*<td data-label="Date">/g) || []).length;
  let list = await listOf('&payment=partially_paid');
  assert.equal(list.status, 200);
  assert.match(list.body, /Payment status: <strong>Partially paid<\/strong>/, 'the active filter is stated');
  assert.match(list.body, /<strong>10<\/strong> claims/, 'with the count');
  assert.equal(rowCount(list.body), 10); assert.ok(!/Not paid<\/span>/.test(list.body.replace(/<option[\s\S]*?<\/option>/g, '')), 'no other status in the list');
  assert.match(list.body, /Clear filters/);
  list = await listOf('&payment=outstanding');
  assert.match(list.body, /<strong>23<\/strong> claims/, 'not paid and part paid, never a paid one');
  assert.match(list.body, /Still to collect/);
  list = await listOf('&payment=paid');
  assert.match(list.body, /<strong>9<\/strong> claims/);

  // paging: 25 a page by default, the filter/search/size kept in the page links, refresh/bookmark safe
  list = await listOf('');
  assert.equal(rowCount(list.body), 25, '25 rows by default');
  assert.match(list.body, /Showing 1&ndash;25 of 32/);
  const next = /href="([^"]*page=2[^"]*)"/.exec(list.body);
  assert.ok(next, 'a next page');
  list = await listOf('&q=Work');
  assert.match(list.body, /Showing 1&ndash;25 of 30/);
  const link = /href="([^"]*page=2[^"]*)"/.exec(list.body)[1].replace(/&amp;/g, '&');
  assert.ok(link.includes('q=Work') && link.includes(`campaign=${board.id}`), 'the search and the campaign survive in the page link');
  const nextPage = await text(admin, link);
  assert.match(nextPage.body, /Showing 26&ndash;30 of 30/, 'the next page, from the link');
  const page2 = await text(admin, `/admin/ecaq?campaign=${board.id}&payment=outstanding&page=2`);
  assert.equal(rowCount(page2.body), 23, 'a page past the end answers with the last page, never an empty one');
  const big = await listOf('&page_size=50');
  assert.equal(rowCount(big.body), 32, '50 a page shows all 32');
  const searched = await listOf('&q=Work03');
  assert.match(searched.body, /<strong>1<\/strong> claim/); assert.match(searched.body, /matching &ldquo;Work03&rdquo;/); assert.match(searched.body, /Work03 Queue/);
  assert.equal((await listOf('&payment=junk&sort=__proto__&direction=up&page=-3&page_size=7')).status, 200, 'junk parameters fall back safely');

  // the row carries what the Church Admin needs (F)
  list = await listOf('&q=Anna');
  assert.match(list.body, /18 Mar 2025/); assert.match(list.body, /Tuesday/); assert.match(list.body, /CCIQ-\d+/);
  assert.match(list.body, /QAR 300/); assert.match(list.body, /Paid<\/span>/);
  assert.match(list.body, /recorded by /, 'who recorded the claim');
  assert.match(list.body, new RegExp(`href="/admin/ecaq/claims/${id}#record-payment"`), 'Record payment');
  assert.match(list.body, new RegExp(`href="/admin/ecaq/claims/${id}#payments"[^>]*>History \\(2\\)`), 'History with its count');
  assert.match(list.body, /Release/);
  assert.match(list.body, new RegExp(`${mods.dates.formatDate(mods.dates.today(), 'medium').replace(/\s/g, '\\s')}`), 'the last payment date');
  assert.match(list.body, /record-list__item/, 'a card per claim for a phone');

  // permission on the destination
  for (const [who, client] of [['member', member], ['leader', leader]]) {
    const denied = await text(client, `/admin/ecaq?campaign=${board.id}&payment=outstanding`);
    assert.ok([302, 403].includes(denied.status) && !/Still to collect/.test(denied.body), `${who} cannot open a working list`);
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('PASS (claim on behalf) review then confirm with the full date, member, Member ID and fixed QAR 300; the day belongs to the member and the administrator is the recorder; Super Admin and Church Admin may, a member and a leader may not');
console.log('PASS (ledger status) no status dropdown or collected box; QAR 0 is never Paid; 100 then 200 against 300 is Part paid then Paid with the right balance; a future payment date is refused; human-readable messages');
console.log('PASS (work queue) summary figures are links that open in a new tab; filtered lists state the filter and count, keep filter/search/page in the address, page 25 at a time, refuse junk safely and refuse the wrong roles');
console.log('ALL PASS');
