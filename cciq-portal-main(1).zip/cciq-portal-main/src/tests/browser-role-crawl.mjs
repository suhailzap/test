import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * A real browser, signed in as each of the five kinds of person, follows every link the portal OFFERS that person (the menu, its sub-menus and
 * the links on the screens they open, two hops deep) and looks at what a person would: the response, the page title and heading, which menu
 * item is marked as the current one, scripts that fail, files that do not load, a layout that overflows, a tab that opens by itself, and a
 * keyboard that cannot get out of somewhere. Then it does the things people do: search, open, edit, cancel, sort, filter, save and reload.
 * Nothing here weakens a permission: a link that is offered and then refused is a finding.
 */

const f = await buildPortalFixture('cciq-browser-crawl-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const today = mods.dates.today();
// something for every screen to link to
const visitor = mods.visitors.createVisitor({ first_name: 'Crawl', last_name: 'Visitor', first_visit_date: today, invited_by_member_id: ids.member.a2 }, { userId: users.churchAdmin.id });
void visitor;

const problems = [];
const note = (who, message) => problems.push(`${who}: ${message}`);
const contextFor = async (account) => {
  const session = await signIn(portal.base, account.email, f.PASSWORD);
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await context.addCookies(session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  return context;
};
const SKIP = /^\/(logout|login)|\.(csv|pdf|png|jpg|jpeg)(\?|$)|\/(photo|qr\/card\.png|download|export|backups\/\d+\/download)/;

const ROLES = [['Super Administrator', users.superAdmin, '/'], ['Church Administrator', users.churchAdmin, '/'], ['Cell Group Leader', users.leaderA, '/'], ['Member', users.memberA, '/'], ['Kiosk', users.kiosk, '/kiosk']];
let pagesSeen = 0; let tabbed = 0;

try {
  for (const [label, account, start] of ROLES) {
    const context = await contextFor(account);
    const page = await context.newPage();
    const consoleErrors = []; const failedAssets = []; const popups = [];
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(`${m.text()} @ ${page.url()}`); });
    page.on('pageerror', (e) => consoleErrors.push(`${e.message} @ ${page.url()}`));
    page.on('response', (r) => { const u = new URL(r.url()); if (u.origin === portal.base && /\.(css|js|png|jpg|svg|woff2?)(\?|$)/.test(u.pathname) && r.status() >= 400) failedAssets.push(`${r.status()} ${u.pathname}`); });
    context.on('page', (p) => { if (p !== page) popups.push(p); });

    const seen = new Map();
    const queue = [[start, 0, 'start']];
    while (queue.length && seen.size < 120) {
      const [href, depth, from] = queue.shift();
      if (seen.has(href) || SKIP.test(href)) continue;
      const response = await page.goto(`${portal.base}${href}`, { waitUntil: 'load' }).catch((e) => { note(label, `${href} did not load: ${e.message.split('\n')[0]}`); return null; });
      if (!response) continue;
      seen.set(href, true); pagesSeen += 1;
      const path = new URL(page.url()).pathname;
      const status = response.status();
      if (status >= 400) { note(label, `the link ${href} (offered on ${from}) ends in ${status}`); continue; }
      if (/^\/login/.test(path) && href !== '/login') { note(label, `${href} (offered on ${from}) sent a signed-in person to the sign-in page`); continue; }
      const info = await page.evaluate(() => ({
        title: document.title, h1: [...document.querySelectorAll('h1')].map((h) => h.textContent.trim()),
        kioskBody: document.body.classList.contains('kiosk'), current: [...document.querySelectorAll('.sidenav a[aria-current="page"], .sidenav a.is-active')].map((a) => a.getAttribute('href')),
        focusable: [...document.querySelectorAll('a[href], button, input, select, textarea, summary, [tabindex]')].filter((e) => !e.disabled && e.tabIndex >= 0 && e.getBoundingClientRect().width > 0).length,
        overflow: document.documentElement.scrollWidth > window.innerWidth + 1, links: [...document.querySelectorAll('main a[href], .sidenav a[href]')].map((a) => ({ href: a.getAttribute('href'), blank: a.target === '_blank' }))
      }));
      if (!info.title || /^\s*·/.test(info.title)) note(label, `${href}: empty page title`);
      if (info.h1.length !== 1 && !info.kioskBody) note(label, `${href}: ${info.h1.length} h1 headings`);
      if (label === 'Kiosk' ? !info.kioskBody : info.kioskBody) note(label, `${href}: wrong layout (kiosk body: ${info.kioskBody})`);
      if (info.overflow) note(label, `${href}: the page scrolls sideways at 1280px`);
      if (label !== 'Kiosk' && !info.current.length && !/^\/(my|notifications|search|account|about|help|404)/.test(path) && path !== '/') note(label, `${href}: no menu item is marked as the current one`);
      if (label !== 'Kiosk' && path !== '/' && info.current.length) {
        // the page sits under the menu item (or a sub-item) that is marked: its own address, or a screen beneath it, or one of its siblings in that menu
        const best = info.current.find((c) => path === c || path.startsWith(`${c}/`));
        if (!best) note(label, `${href}: the current menu item (${info.current.join(', ')}) does not match this page`);
      }
      // keyboard: tab through; focus must move on every press and always land on something a person can see
      if (tabbed < 60) {
        tabbed += 1;
        await page.evaluate(() => { document.activeElement && document.activeElement.blur(); });
        let stuck = 0; let last = '';
        // only as many presses as there are things to reach: past the last one a browser leaves the page, which is not a trap
        for (let i = 0; i < Math.min(30, Math.max(info.focusable - 1, 1)); i += 1) {
          await page.keyboard.press('Tab');
          const at = await page.evaluate(() => { const e = document.activeElement; const same = e === window.__lastTab; window.__lastTab = e; if (!e || e === document.body) return same ? 'body|same' : 'body'; const r = e.getBoundingClientRect(); return `${e.tagName}#${e.id}.${e.className}|${e.getAttribute('href') || e.name || ''}|${r.width > 0 && r.height > 0 ? 'v' : 'hidden'}${same ? '|same' : ''}`; });
          if (at.includes('|hidden')) note(label, `${href}: Tab landed on something invisible (${at})`);
          stuck = at.endsWith('|same') ? stuck + 1 : 0; last = at;
          if (stuck >= 3) { note(label, `${href}: the keyboard is stuck on ${at}`); break; }
        }
      }
      if (depth < 2) for (const l of info.links) {
        if (!l.href || !l.href.startsWith('/') || l.href.startsWith('//') || l.href.includes('#') && l.href.split('#')[0] === '' || l.blank) continue;
        queue.push([l.href.split('#')[0], depth + 1, href]);
      }
    }
    if (consoleErrors.length) note(label, `browser console errors: ${[...new Set(consoleErrors)].slice(0, 5).join(' || ')}`);
    if (failedAssets.length) note(label, `files that did not load: ${[...new Set(failedAssets)].join(', ')}`);
    if (popups.length) note(label, `${popups.length} tab(s) opened by themselves`);
    console.log(`INFO ${label}: ${seen.size} screens followed`);
    await context.close();
  }

  // ---- what people do ------------------------------------------------------------------------------------------------------------------------
  const adminContext = await contextFor(users.churchAdmin);
  const page = await adminContext.newPage();
  const go = (action) => Promise.all([page.waitForNavigation({ waitUntil: 'load' }), action()]);
  {
    // search -> open -> edit -> cancel returns to the profile; Back to the list keeps the filter
    await page.goto(`${portal.base}/members?q=Anna&sort=name&dir=asc`, { waitUntil: 'load' });
    await go(() => page.click('table.data a:has-text("Anna"), .record-list a:has-text("Anna")'));
    const profile = page.url();
    if (!/\/members\/\d+/.test(profile)) note('flow', `opening a member from search went to ${profile}`);
    await go(() => page.click('a:has-text("Edit")'));
    await go(() => page.click('a.btn:has-text("Cancel")'));
    if (page.url() !== profile) note('flow', `Cancel on the member edit form went to ${page.url()} instead of the profile ${profile}`);
    // sort keeps the filter
    await page.goto(`${portal.base}/visitors?q=Crawl&sort=name&dir=asc`, { waitUntil: 'load' });
    const firstSort = page.locator('thead a.sortable-column').nth(1);
    await go(() => firstSort.click());
    if (!/q=Crawl/.test(page.url())) note('flow', `sorting the First Timers list dropped the search (${page.url()})`);
    // save, flash, reload: the flash is gone and nothing is duplicated
    await page.goto(`${portal.base}/announcements/new`, { waitUntil: 'load' });
    await page.fill('#title', 'Crawl notice'); await page.fill('#body', 'Body of the notice');
    await go(() => page.click('main form button[type=submit]'));
    const flashShown = await page.locator('.alert--success').count();
    if (!flashShown) note('flow', 'saving an announcement showed no confirmation');
    await page.reload({ waitUntil: 'load' });
    if (await page.locator('.alert--success').count()) note('flow', 'the confirmation message came back after a reload (a stale flash)');
    if (db.prepare("SELECT COUNT(*) n FROM announcements WHERE title = 'Crawl notice'").get().n !== 1) note('flow', 'the announcement was created more than once');
    // a refused form: Back to it from the browser keeps values; Cancel goes where it says
    await page.goto(`${portal.base}/activities/new`, { waitUntil: 'load' });
    await page.fill('#title', 'T'.repeat(300));
    await go(() => page.click('main form button[type=submit]'));
    if (!(await page.locator('[data-error-summary]').count())) note('flow', 'a refused activity showed no error summary');
    if ((await page.inputValue('#title')) !== 'T'.repeat(300)) note('flow', 'a refused activity lost what was typed');
    // no tab opened by those flows
    if (adminContext.pages().length !== 1) note('flow', `${adminContext.pages().length - 1} extra tab(s) were opened during ordinary use`);
  }
  console.log(`INFO ${pagesSeen} screens followed in total; keyboard walked on ${tabbed}`);
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
if (problems.length) console.log('PROBLEMS\n' + problems.join('\n'));
assert.deepEqual(problems, [], 'no offered link fails, nothing misbehaves in a real browser');
console.log('PASS (browser crawl) five roles followed through every offered link in a real browser: statuses, titles, headings, current menu item, layout, console, assets, keyboard, popups; and the everyday flows');
console.log('ALL PASS');
