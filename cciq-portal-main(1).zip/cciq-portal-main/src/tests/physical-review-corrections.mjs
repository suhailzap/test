import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';
import { OVERFLOW_CHECK_SCRIPT } from '../../tools/check-overflow.mjs';

/*
 * Post-Phase-2C physical-review corrections (presentation and workflow only, no new semantics):
 *   - sidebar brand sits in the top row instead of under an empty strip
 *   - Family Group detail has Back / New actions and one coherent member row
 *   - a photo that cannot load degrades to the initial avatar (never alt text in the circle)
 *   - member form labels are not double-escaped
 *   - pre-Go-Live attendance pages are compact and keep stored Present/Recorded facts visible
 *   - the attendance report renders no all-zero member rows when nothing is finalized,
 *     and renders normally (with the renamed streak column) once something is
 * Everything is a disposable fixture; the tracking start date below exists only in the fixture.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-physical-review-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const fam = await import('../services/family-groups.js');
const att = await import('../services/attendance.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const { default: db } = await import('../db/index.js');
const dates = await import('../lib/dates.js');

const PASSWORD = `Pr${crypto.randomBytes(12).toString('base64url')}9!`;
const admin = await createUser({ username: 'pr_admin', email: 'pr.admin@fixture.invalid', password: PASSWORD, displayName: 'PR Admin', roleKeys: ['super_admin'], mustChangePassword: false });
const people = [];
for (let i = 1; i <= 14; i += 1) people.push(createMember({ first_name: `Person${i}`, last_name: 'Review' }, { status: 'active' }));
await createUser({ username: 'pr_member', email: 'pr.member@fixture.invalid', password: PASSWORD, displayName: 'PR Member', roleKeys: ['member'], memberId: people[0].id, mustChangePassword: false });
// Photos that point at files that do not exist (the development copy's situation).
for (const p of people.slice(1, 4)) db.prepare('UPDATE members SET photo_path = ?, photo_updated_at = ? WHERE id = ?').run(`members/${p.id}/missing.jpg`, '2026-01-01T00:00:00Z', p.id);
const group = fam.createFamilyGroup({ name: 'Review Family' });
for (const p of people.slice(1, 4)) fam.addMemberToFamilyGroup(group.id, p.id);
fam.setPrimaryMember(group.id, people[1].id);

// Twelve Fridays before any tracking, with stored records on most of them.
const fridays = [];
let cursor = dates.lastFridayOnOrBefore(dates.today());
for (let i = 0; i < 12; i += 1) {
  fridays.push(cursor);
  const d = new Date(`${cursor}T00:00:00Z`); d.setUTCDate(d.getUTCDate() - 7); cursor = d.toISOString().slice(0, 10);
}
const sessionIds = [];
for (const [i, date] of fridays.entries()) {
  const s = att.createSession({ service_date: date, service_type: 'friday_service', title: 'Friday Service', status: 'held' }, {});
  sessionIds.push(s.id);
  if (i % 3 !== 2) att.recordAttendance(s.id, people.slice(0, 6 + i).map((p, k) => ({ memberId: p.id, status: k % 4 === 0 ? 'absent' : 'present' })), {});
}
db.prepare('UPDATE attendance_sessions SET counts_toward_followup = 1').run();
const legacyFacts = db.prepare(`SELECT s.id, s.service_date,
    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status IN ('present','visitor')) AS present,
    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) AS recorded
  FROM attendance_sessions s WHERE s.service_type = 'friday_service' ORDER BY s.service_date DESC`).all();
const recordsBefore = db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n;
const sessionsBefore = db.prepare('SELECT COUNT(*) n FROM attendance_sessions').get().n;

async function startServer() {
  const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
  await waitForServerReady(base, server);
  return { base, server };
}
const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
async function sessionFor(base, email) {
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
  });
  return cookieOf(login, pre);
}
const text = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');

let browser;
let { base, server } = await startServer();
try {
  const adminCookie = await sessionFor(base, 'pr.admin@fixture.invalid');
  const memberCookie = await sessionFor(base, 'pr.member@fixture.invalid');
  const get = async (url, cookie = adminCookie) => {
    const res = await fetch(`${base}${url}`, { headers: { Cookie: cookie }, redirect: 'manual' });
    return { status: res.status, html: await res.text(), res };
  };
  const page = async (url, cookie = adminCookie) => { const r = await get(url, cookie); assert.equal(r.status, 200, url); return r.html; };

  // ---- G. no double-escaped entities; the Father's / Mother's labels read correctly ----------------
  const form = await page(`/members/${people[1].id}/edit`);
  for (const label of ['Father’s name', 'Mother’s name', 'Spouse’s name']) assert.ok(form.includes(`>${label}<`), `${label} is rendered as text`);
  const scanned = ['/members/new', `/members/${people[1].id}/edit`, `/members/${people[1].id}`, '/family-groups', '/family-groups/new',
    `/family-groups/${group.id}`, `/family-groups/${group.id}/edit`, '/attendance', '/attendance/history', '/attendance/friday',
    '/attendance/follow-up', '/attendance/long-absence', '/attendance/reports'];
  for (const url of scanned) {
    const html = await page(url);
    assert.doesNotMatch(html, /&amp;(#\d+|#x[0-9a-f]+|[a-z]+);/i, `${url}: no double-escaped entity such as &amp;rsquo;`);
  }
  console.log('PASS (entities) Father’s / Mother’s / Spouse’s labels render as text; no visible or double-escaped entities on the member, family and attendance screens');

  // ---- B/C/D. Family Group workflow and rows ------------------------------------------------------
  const countsBefore = db.prepare('SELECT COUNT(*) n FROM family_group_members').get().n;
  let html = await page(`/family-groups/${group.id}`);
  assert.match(html, /<a class="btn btn--secondary" href="\/family-groups">Back to Family Groups<\/a>/, 'Back to Family Groups on the detail page');
  assert.match(html, /href="\/family-groups\/new">[\s\S]*?New Family Group/, 'New Family Group on the detail page');
  assert.match(html, /href="\/family-groups\/\d+\/edit">Edit Family Group</);
  assert.match(html, /<ul class="breadcrumb">[\s\S]*href="\/family-groups">Family Groups/, 'a breadcrumb back to the list');
  assert.equal((html.match(/>Remove from Family Group</g) || []).length, 3, 'one Remove action per member, worded identically');
  assert.doesNotMatch(html, /Remove from family<|Add Family Member|Add to Family</, 'the old, inconsistent wording is gone');
  assert.match(html, />Add to Family Group</);
  const row = html.match(/<li class="family-row">[\s\S]*?<\/li>/)[0];
  const order = ['list__name', 'pill pill--primary', 'pill pill--member pill--active', 'list__meta', 'family-row__action'].map((k) => row.indexOf(k));
  assert.ok(order.every((n) => n > 0) && order.every((n, i) => i === 0 || n > order[i - 1]), 'name, primary marker, status, then metadata, then the action - one identity line');
  assert.match(row, /Primary contact/, 'the primary marker is kept and readable');
  const listPage = await page('/family-groups');
  assert.match(listPage, />\s*New Family Group\s*</, 'the list uses the same wording to open the form');
  assert.doesNotMatch(listPage, />\s*Create Family Group\s*</);
  const newPage = await page('/family-groups/new');
  assert.match(newPage, /<h1>New Family Group<\/h1>/);
  assert.match(newPage, />Create Family Group<\/button>/, 'the submit button is the one place that says Create');
  // Creating a family leaves you on its detail with the next actions in view.
  const csrf = newPage.match(/name="_csrf" value="([^"]+)"/)[1];
  const created = await fetch(`${base}/family-groups`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ _csrf: csrf, name: 'Second Family', first_member_id: String(people[5].id) })
  });
  assert.equal(created.status, 302);
  const detail = await page(created.headers.get('location'));
  assert.match(detail, /Back to Family Groups/);
  assert.match(detail, /New Family Group/);
  const membersNow = db.prepare('SELECT COUNT(*) n FROM family_group_members').get().n;
  assert.equal(membersNow, countsBefore + 1, 'only the requested first member was added; viewing pages changed nothing');
  const destructive = html.indexOf('Delete Family Group');
  assert.ok(destructive > html.indexOf('Add to Family Group'), 'the destructive section stays last');
  assert.doesNotMatch(html, /<form[^>]*\/delete/, 'with members present there is no delete button at all');
  console.log('PASS (family) Back / Edit / New actions, breadcrumb, consistent wording, one identity line per row, delete kept last and unavailable while members remain');

  // ---- attendance: pre-Go-Live presentation ------------------------------------------------------
  html = await page('/attendance');
  assert.match(html, /Attendance tracking has not started/);
  assert.match(html, /service-panel--compact/, 'a slim next-service banner, not a hero');
  assert.doesNotMatch(html, /service-panel__count/, 'no large latest-service figure');
  assert.doesNotMatch(html, /Present at latest service|Follow-up may be appropriate/, 'no latest-service statistic cards before tracking');
  assert.doesNotMatch(html, /<h2>Follow-up<\/h2>|<h2>Long absence<\/h2>/, 'no repeated not-started cards');
  assert.equal((html.match(/tracking (has not started|started)/gi) || []).length <= 2, true, 'the state is said once, not on every card');
  assert.match(html, /Latest stored record: \d+ present/, 'the stored fact is still visible, plainly labelled');

  html = await page('/attendance/history');
  assert.match(html, new RegExp(`>${sessionsBefore} sessions<`), 'session count says "N sessions", not "recorded"');
  assert.doesNotMatch(html, /sessions recorded/);
  assert.doesNotMatch(html, /friday service/, 'the stored type value is never shown');
  assert.match(html, /<td data-label="Type">Friday Service<\/td>/);
  // Legacy Present / Recorded facts (including sessions with nothing recorded) are still shown.
  for (const fact of legacyFacts) {
    const rowHtml = html.match(new RegExp(`<tr>(?:(?!</tr>)[\\s\\S])*?/attendance/sessions/${fact.id}"[\\s\\S]*?</tr>`));
    assert.ok(rowHtml, `session ${fact.service_date} is listed`);
    // Present is now "Members present" (the same number: members with a Present or Visitor mark) beside First Timers and Total present; Recorded is "Marks recorded".
    assert.match(rowHtml[0], new RegExp(`data-label="Members present" class="numeric">${fact.present}<`), `stored Present ${fact.present} is shown as Members present`);
    assert.match(rowHtml[0], new RegExp(`data-label="Marks recorded" class="numeric">${fact.recorded}<`), `stored Recorded ${fact.recorded} is shown as Marks recorded`);
    assert.match(rowHtml[0], /Not tracked/, 'and the session is clearly identified as Not tracked');
  }
  assert.ok(legacyFacts.some((f) => f.recorded === 0) && legacyFacts.some((f) => f.recorded > 0), 'the fixture has both empty and recorded sessions');
  html = await page('/attendance/friday');
  assert.doesNotMatch(html, /friday service/);
  const fridayRows = html.match(/<tr>[\s\S]*?<\/tr>/g).filter((r) => r.includes('Not tracked'));
  assert.ok(fridayRows.length >= 10);
  for (const r of fridayRows) assert.equal((r.match(/Not tracked/g) || []).length, 1, 'Not tracked is said once per row, not in two columns');
  console.log('PASS (landing/history/friday) compact not-started landing; "N sessions"; Friday Service wording; stored Present/Recorded facts still visible and marked Not tracked');

  html = await page('/attendance/follow-up');
  assert.equal((html.match(/class="notice"/g) || []).length, 1, 'one information panel');
  assert.doesNotMatch(html, /class="filters/, 'no filters over an empty, not-started list');
  assert.match(html, /empty--compact/);
  assert.match(html, /no one is counted absent yet/);
  assert.doesNotMatch(html, /pagination|Rows per page/, 'no pager for an empty list');

  html = await page('/attendance/long-absence');
  assert.equal((html.match(/class="notice"/g) || []).length, 1, 'one information panel');
  assert.doesNotMatch(html, /Open PDF/, 'no PDF action while the review is unavailable');
  assert.doesNotMatch(html, /Nothing to review yet|class="empty"/, 'no extra empty panel repeating the notice');
  assert.match(html, /Not available yet/);
  assert.match(html, /56 days/, 'the observation window is still stated');
  const pdf = await fetch(`${base}/reports/long-absence/pdf`, { headers: { Cookie: adminCookie } });
  assert.equal(pdf.status, 200, 'a direct PDF request still answers');
  assert.match(pdf.headers.get('content-type') || '', /pdf/);
  console.log('PASS (follow-up / long absence) single compact panels; no PDF link until the review is available; window still stated');

  // ---- M. report with nothing finalized ------------------------------------------------------------
  html = await page('/attendance/reports');
  assert.match(html, /No finalized Friday Services in this range/);
  assert.doesNotMatch(html, /<td data-label="Member">/, 'no per-member rows at all');
  assert.doesNotMatch(html, /Services counted<|Absences in a row</, 'no table headers for an empty table');
  assert.doesNotMatch(html, /Rows per page/, 'no pager');
  assert.match(html, /12 Friday Services/);
  assert.match(html, /before attendance tracking began/);
  assert.match(html, /Export CSV/, 'export is still offered');
  const csv = await fetch(`${base}/attendance/reports/export.csv`, { headers: { Cookie: adminCookie } });
  assert.equal(csv.status, 200);
  assert.ok((await csv.text()).split('\n').length > 5, 'the CSV still lists the members');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n, recordsBefore, 'no attendance record was touched');
  console.log('PASS (report, nothing finalized) one compact explanation instead of identical zero rows; CSV export unchanged');

  // ---- A. sidebar brand position + E. photo rendering, in a real browser ------------------------------
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const p = await context.newPage();
  await p.goto(`${base}/login`);
  await p.fill('#email', 'pr.admin@fixture.invalid');
  await p.fill('#password', PASSWORD);
  await Promise.all([p.waitForNavigation(), p.click('button[type="submit"]')]);

  for (const width of [861, 1024, 1440]) {
    await p.setViewportSize({ width, height: 900 });
    await p.goto(`${base}/`);
    const geo = await p.evaluate(() => {
      const r = (sel) => { const el = document.querySelector(sel); const b = el.getBoundingClientRect(); return { top: b.top, bottom: b.bottom, left: b.left, right: b.right }; };
      return { brand: r('.brand--stacked'), topbar: r('.topbar'), nav: r('.sidenav .nav'), side: r('.sidenav') };
    });
    assert.ok(geo.brand.top <= 4, `${width}px: the brand is at the very top of the sidebar (top ${geo.brand.top})`);
    assert.ok(geo.brand.bottom <= geo.topbar.bottom + 1, `${width}px: it shares the top bar's row instead of sitting under an empty strip`);
    assert.ok(geo.nav.top <= geo.topbar.bottom + 2, `${width}px: the navigation starts right beneath it`);
    assert.ok(geo.side.left === 0 && geo.side.top === 0, `${width}px: the sidebar is flush with the window`);
    const covers = await p.evaluate(() => { const e = document.elementFromPoint(300, 30); return !!e && !!e.closest('.topbar'); });
    assert.equal(covers, true, `${width}px: the top bar's content is not covered by the sidebar`);
  }
  await p.setViewportSize({ width: 390, height: 800 });
  await p.goto(`${base}/`);
  assert.equal(await p.evaluate(() => getComputedStyle(document.querySelector('.brand--stacked')).display), 'none', 'the mobile drawer keeps its own compact brand in the top bar');
  assert.equal(await p.evaluate(() => getComputedStyle(document.querySelector('.brand--compact')).display !== 'none'), true);
  console.log('PASS (sidebar) the brand sits in the top row at 861/1024/1440; the mobile top bar/drawer behaviour is unchanged');

  // The corrected screens do not overflow at phone, tablet and laptop widths.
  for (const url of [`/family-groups/${group.id}`, '/family-groups', '/family-groups/new', `/members/${people[1].id}/edit`, '/attendance', '/attendance/history', '/attendance/friday', '/attendance/follow-up', '/attendance/long-absence', '/attendance/reports']) {
    await p.goto(`${base}${url}`);
    for (const width of [320, 375, 430, 768, 861, 1024, 1440]) {
      await p.setViewportSize({ width, height: 900 });
      assert.equal((await p.evaluate(OVERFLOW_CHECK_SCRIPT)).overflow, false, `${url} overflows at ${width}px`);
    }
  }
  console.log('PASS (overflow) family, member form and attendance screens at 7 widths');

  await p.setViewportSize({ width: 1440, height: 900 });
  // A missing photo file: clean 404, clean fallback, never alt text in the circle.
  const photoRes = await get(`/media/members/${people[1].id}/photo`);
  assert.equal(photoRes.status, 404);
  assert.doesNotMatch(photoRes.html, /missing\.jpg|storage|cciq-physical-review/i, 'the error does not reveal a storage path');
  for (const url of [`/members/${people[1].id}`, `/family-groups/${group.id}`, '/members']) {
    await p.goto(`${base}${url}`);
    await p.waitForLoadState('networkidle');
    const result = await p.evaluate(() => ({
      broken: Array.from(document.querySelectorAll('img.avatar')).filter((i) => !(i.complete && i.naturalWidth > 0)).length,
      leaked: /Photo of|Your current/.test(document.body.innerText),
      empties: document.querySelectorAll('.avatar--empty').length,
      initials: Array.from(document.querySelectorAll('.avatar--empty')).map((e) => e.textContent.trim()).filter(Boolean).length
    }));
    assert.equal(result.broken, 0, `${url}: no broken image is left in the page`);
    assert.equal(result.leaked, false, `${url}: no alt text is drawn`);
    assert.ok(result.empties > 0 && result.initials > 0, `${url}: initials are shown instead`);
  }
  // A real photo still renders, covering the circle.
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const profileHtml = await page('/my/profile', memberCookie);
  const upload = new FormData();
  upload.append('_csrf', profileHtml.match(/name="_csrf" value="([^"]+)"/)[1]);
  upload.append('photo', new Blob([png], { type: 'image/png' }), 'me.png');
  const up = await fetch(`${base}/my/profile/photo`, { method: 'POST', redirect: 'manual', headers: { Cookie: memberCookie }, body: upload });
  assert.equal(up.status, 302);
  const memberContext = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const mp = await memberContext.newPage();
  await mp.goto(`${base}/login`);
  await mp.fill('#email', 'pr.member@fixture.invalid');
  await mp.fill('#password', PASSWORD);
  await Promise.all([mp.waitForNavigation(), mp.click('button[type="submit"]')]);
  await mp.goto(`${base}/my/profile`);
  await mp.waitForLoadState('networkidle');
  const shown = await mp.evaluate(() => Array.from(document.querySelectorAll('img.avatar')).map((i) => ({ ok: i.complete && i.naturalWidth > 0, fit: getComputedStyle(i).objectFit, alt: i.getAttribute('alt') })));
  assert.ok(shown.length >= 2 && shown.every((s) => s.ok && s.fit === 'cover'), 'valid photos render normally with object-fit: cover');
  assert.ok(shown.every((s) => s.alt), 'and keep descriptive alt text for assistive technology');
  assert.equal(await mp.evaluate(() => document.querySelectorAll('#profile-photo').length), 1);
  // My Profile: one compact photo card, not a second identity card.
  const profileLayout = await mp.evaluate(() => {
    const card = document.querySelector('#profile-photo').getBoundingClientRect();
    const membership = document.querySelector('.grid--halves .card').getBoundingClientRect();
    return { photoCardHeight: card.height, membershipHeight: membership.height, bigAvatars: document.querySelectorAll('#profile-photo .avatar--lg').length };
  });
  assert.equal(profileLayout.bigAvatars, 0);
  assert.ok(profileLayout.photoCardHeight < profileLayout.membershipHeight * 0.6, `the photo card (${Math.round(profileLayout.photoCardHeight)}px) is compact next to the membership card`);
  await memberContext.close();
  console.log('PASS (photos / profile) a missing or failed photo degrades to the initial avatar with no alt text or storage path; valid photos render with object-fit cover; My Profile photo card is compact');
  await browser.close(); browser = null;
} finally {
  if (browser) await browser.close();
  await terminateAndWait(server);
}

// ---- Phase B: once tracking has run and services are finalized -------------------------------------
{
  const goLive = fridays[fridays.length - 1];
  for (const person of people) {
    db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(`${dates.addDays(goLive, -400)}T09:00:00.000Z`, person.id);
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(person.id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)')
      .run(person.id, 'active', 'planted', `${dates.addDays(goLive, -400)}T09:00:00.000Z`);
  }
  setSetting('attendance.tracking_start_date', goLive);
  // The three most recent Fridays are finalized; the rest stay open.
  for (const id of sessionIds.slice(0, 3)) lifecycle.finalizeAttendance(id, { userId: admin.id, confirmNoAttendance: true });
  ({ base, server } = await startServer());
  try {
    const adminCookie = await sessionFor(base, 'pr.admin@fixture.invalid');
    const page = async (url) => {
      const res = await fetch(`${base}${url}`, { headers: { Cookie: adminCookie } });
      assert.equal(res.status, 200, url);
      return res.text();
    };
    const html = await page('/attendance/reports');
    assert.doesNotMatch(html, /No finalized Friday Services in this range/, 'with finalized services the report renders normally');
    assert.ok((html.match(/<td data-label="Member">/g) || []).length > 0, 'member rows are shown');
    assert.match(html, />Absences in a row</, 'the streak column says what it counts');
    assert.match(html, /data-label="Absences in a row"/);
    assert.doesNotMatch(html, />Consecutive Friday Services</, 'the old ambiguous heading is gone');
    assert.match(html, /Rows per page/, 'pagination is kept');
    assert.match(html, /Member figures come only from <strong>finalized<\/strong> Friday Services \(3 in this range\)/);
    assert.doesNotMatch(html, /expected members present &divide; expected/, 'the formula is no longer a permanent paragraph');
    const longAbsence = await page('/attendance/long-absence');
    assert.match(longAbsence, /Open PDF/, 'the PDF is offered once the review is available (observation window covered)');
    assert.doesNotMatch(longAbsence, /Not available yet/);
    const landing = await page('/attendance');
    assert.doesNotMatch(landing, /Attendance tracking has not started/);
    assert.match(landing, /Present at latest service/, 'the normal tracked landing returns once tracking has started');
    console.log('PASS (tracked) finalized services render the normal report with "Absences in a row"; Open PDF and the tracked landing return once tracking is running');
  } finally {
    await terminateAndWait(server);
  }
}
console.log('ALL PASS');
