import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-reports-refinement-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const { createUser, getRoleByKey, permissionsForRole, setRolePermissions } = await import('../services/users.js');
const { recordAttendance, attendanceReport, attendanceReportCsv, parseAttendanceStatusFilter } = await import('../services/attendance.js');
const { sortFridaySessions, FRIDAY_SESSION_SORT_COLUMNS } = await import('../services/reports.js');
const { directoryPdf } = await import('../services/reports-pdf.js');
const { buildNavigation } = await import('../lib/navigation.js');
const { execute, default: db } = await import('../db/index.js');

function makeFridaySession(date) {
  const result = execute(
    `INSERT INTO attendance_sessions
       (service_date, service_type, title, status, counts_toward_followup, created_at)
     VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, @date)`,
    { date }
  );
  return Number(result.lastInsertRowid);
}

// --- Fixture ---
const group = createGroup({ name: 'Test Group' });
const active1 = createMember({ first_name: 'Active', last_name: 'One', cell_group_id: group.id }, { status: 'active' });
const inactive1 = createMember({ first_name: 'Inactive', last_name: 'One' }, { status: 'inactive' });
createMember({ first_name: 'Inactive', last_name: 'Two' }, { status: 'inactive' });
const session1 = makeFridaySession('2026-01-02');
const session2 = makeFridaySession('2026-01-09');
recordAttendance(session1, [{ memberId: active1.id, status: 'present' }]);
recordAttendance(session2, [{ memberId: active1.id, status: 'present' }, { memberId: inactive1.id, status: 'present' }]);

// --- 1. parseAttendanceStatusFilter(): default roster, explicit selection,
//        explicit empty (no restriction), invalid values ignored safely. ---
assert.deepEqual(parseAttendanceStatusFilter({}), ['active', 'pending', 'attendee', 'bonafide'],
  'no statuses_submitted marker must default to the normal Friday roster');
assert.deepEqual(parseAttendanceStatusFilter({ statuses_submitted: '1', status: 'inactive' }), ['inactive'],
  'an explicit single selection must be honoured literally');
assert.deepEqual(parseAttendanceStatusFilter({ statuses_submitted: '1' }), [],
  'an explicit submission with nothing checked must mean no restriction, not a silent fallback to the roster');
assert.deepEqual(
  parseAttendanceStatusFilter({ statuses_submitted: '1', status: ['active', 'not-a-real-status', "'; DROP TABLE members; --"] }),
  ['active'],
  'unknown or malicious status values must be dropped, never passed through to SQL'
);
console.log('PASS: parseAttendanceStatusFilter() resolves default/explicit/empty/invalid correctly');

// --- 2. attendanceReport() population reflects only the selected statuses,
//        not silently reverting to the roster. ---
const inactiveOnly = attendanceReport({ from: '2026-01-01', to: '2026-01-31', statuses: ['inactive'] });
assert.equal(inactiveOnly.rows.length, 2, 'population must be exactly the two inactive members');
assert.ok(inactiveOnly.rows.every((r) => r.member.member_status === 'inactive'));
assert.deepEqual(inactiveOnly.statuses, ['inactive']);
console.log('PASS: attendanceReport() with an explicit status list reports only that population');

const rosterDefault = attendanceReport({ from: '2026-01-01', to: '2026-01-31' });
assert.equal(rosterDefault.rows.length, 1, 'no statuses argument must keep the long-standing roster-only behaviour');
console.log('PASS: attendanceReport() with no statuses argument is unchanged (roster only)');

// --- 3. CSV output uses the exact same population as the on-screen report —
//        never a separate, disagreeing calculation. ---
const { members: csvMemberCount } = attendanceReportCsv({ from: '2026-01-01', to: '2026-01-31', statuses: ['inactive'] });
assert.equal(csvMemberCount, inactiveOnly.rows.length, 'CSV export must report the same member count as the on-screen population');
console.log('PASS: attendanceReportCsv() population matches attendanceReport() exactly for the same filter');

// --- 4. directoryPdf() accepts a multi-status list without throwing, and an
//        empty list means every status (same convention as Members). ---
const dirDoc = directoryPdf({ statuses: ['active', 'inactive'], includeContact: false });
assert.equal(typeof dirDoc.pipe, 'function', 'directoryPdf() must return a streamable PDF document');
console.log('PASS: directoryPdf() accepts a multi-status list and produces a document');

// --- 5. sortFridaySessions(): default date DESC, each column both
//        directions, and an invalid/unwhitelisted sort key falls back safely. ---
const sessions = [
  { sessionId: 1, date: '2026-01-02', present: 5, excused: 1, visitors: 0, absent: 2, notRecorded: 0, rate: 60 },
  { sessionId: 2, date: '2026-01-09', present: 8, excused: 0, visitors: 1, absent: 1, notRecorded: 0, rate: 90 },
  { sessionId: 3, date: '2025-12-26', present: 2, excused: 0, visitors: 0, absent: 5, notRecorded: 1, rate: 30 }
];
assert.deepEqual(sortFridaySessions(sessions).map((s) => s.date), ['2026-01-09', '2026-01-02', '2025-12-26'],
  'default sort must be Service Date, latest first');
assert.deepEqual(sortFridaySessions(sessions, 'present', 'asc').map((s) => s.present), [2, 5, 8]);
assert.deepEqual(sortFridaySessions(sessions, 'present', 'desc').map((s) => s.present), [8, 5, 2]);
assert.deepEqual(
  sortFridaySessions(sessions, 'rate; DROP TABLE attendance_records; --', 'desc').map((s) => s.date),
  ['2026-01-09', '2026-01-02', '2025-12-26'],
  'an unwhitelisted sort key must fall back to sorting by date, never reach a query — direction is still honoured, since it is only ever "asc" or "desc"'
);
assert.ok(FRIDAY_SESSION_SORT_COLUMNS.includes('rate') && !FRIDAY_SESSION_SORT_COLUMNS.some((k) => k.includes(';')),
  'the sort whitelist itself must contain only plain column keys');
console.log('PASS: sortFridaySessions() defaults to date desc, sorts every column both ways, and rejects unwhitelisted keys');

// --- 6. Sidebar navigation: "Scan to check in" removed, "Attendance Kiosk"
//        and every other Attendance item unaffected. ---
const fakeUser = { can: () => true, roles: ['super_admin'] }; // a Super Admin: the Attendance Kiosk entry also needs a kind of sign-in that may operate it
const nav = buildNavigation(fakeUser, '/');
const attendanceSection = nav.find((item) => item.label === 'Attendance');
const childLabels = attendanceSection.children.map((c) => c.label);
assert.ok(!childLabels.includes('Scan to check in'), 'the "Scan to check in" sidebar entry must be removed');
assert.ok(childLabels.includes('Attendance Kiosk'), 'Attendance Kiosk must remain in the sidebar');
assert.ok(childLabels.includes('Friday Service') && childLabels.includes('Follow-up') && childLabels.includes('Attendance report'),
  'no other Attendance sidebar entry should have been affected by removing one link');
console.log('PASS: sidebar navigation drops "Scan to check in" without touching any other Attendance entry');

// --- 7. The underlying /attendance/checkin route and its Kiosk-shared POST
//        endpoints must still work — navigation cleanup must not have
//        touched the implementation the Kiosk itself depends on. Reuses
//        this same isolated database (already migrated/seeded) in a
//        spawned server, rather than a second createIsolatedTestEnv() call,
//        since db/index.js and friends are cached per process and would
//        silently keep pointing at this first database anyway. ---
await createUser({
  email: 'checkin-route-subject@fixture.invalid', password: 'TestPassw0rd!2026',
  displayName: 'Checkin Route Subject', roleKeys: ['church_admin'], mustChangePassword: false
});

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;
const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

const csrfRes = await fetch(`${base}/login`);
const csrfHtml = await csrfRes.text();
const csrfToken = csrfHtml.match(/name="_csrf" value="([^"]+)"/)[1];
const cookieHeader = csrfRes.headers.get('set-cookie').split(';')[0];

const loginRes = await fetch(`${base}/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookieHeader },
  body: new URLSearchParams({ _csrf: csrfToken, email: 'checkin-route-subject@fixture.invalid', password: 'TestPassw0rd!2026' }),
  redirect: 'manual'
});
const sessionCookie = (loginRes.headers.get('set-cookie') || cookieHeader).split(';')[0];

const checkinPage = await fetch(`${base}/attendance/checkin`, { headers: { Cookie: sessionCookie } });
assert.equal(checkinPage.status, 200, 'GET /attendance/checkin must still work directly, only the sidebar link was removed');
console.log('PASS: GET /attendance/checkin still works after removing its sidebar entry');

const lookupRes = await fetch(`${base}/attendance/checkin/lookup`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: sessionCookie },
  body: new URLSearchParams({ q: 'zzz-no-such-person' })
});
assert.notEqual(lookupRes.status, 404, 'POST /attendance/checkin/lookup (used by both the admin screen and the Kiosk) must still be registered');
console.log('PASS: /attendance/checkin/lookup, shared with the Kiosk, is still registered and reachable');

// --- 8. Print a report only shows a card for a report the signed-in role
//        can actually use — direct URL, not just hidden nav. Every built-in
//        role either has every relevant permission (super_admin,
//        church_admin) or lacks reports.view entirely (cell_group_leader,
//        member, kiosk, already covered by the earlier Reports workstream),
//        so this temporarily narrows a throwaway copy of church_admin in
//        this isolated database only, to exercise the "has reports.view but
//        not this specific report's permission" case Print a report's own
//        per-card gating exists for. ---
const churchAdminRole = getRoleByKey('church_admin');
const narrowedPermissions = permissionsForRole(churchAdminRole.id)
  .filter((p) => p !== 'attendance.followup' && p !== 'giving.manage');
setRolePermissions(churchAdminRole.id, narrowedPermissions);

await createUser({
  email: 'narrowed-admin@fixture.invalid', password: 'TestPassw0rd!2026',
  displayName: 'Narrowed Admin', roleKeys: ['church_admin'], mustChangePassword: false
});

const narrowedCsrfRes = await fetch(`${base}/login`);
const narrowedCsrfHtml = await narrowedCsrfRes.text();
const narrowedCsrfToken = narrowedCsrfHtml.match(/name="_csrf" value="([^"]+)"/)[1];
const narrowedCookieHeader = narrowedCsrfRes.headers.get('set-cookie').split(';')[0];
const narrowedLoginRes = await fetch(`${base}/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: narrowedCookieHeader },
  body: new URLSearchParams({ _csrf: narrowedCsrfToken, email: 'narrowed-admin@fixture.invalid', password: 'TestPassw0rd!2026' }),
  redirect: 'manual'
});
const narrowedCookie = (narrowedLoginRes.headers.get('set-cookie') || narrowedCookieHeader).split(';')[0];

const printPage = await fetch(`${base}/reports/print`, { headers: { Cookie: narrowedCookie } });
const printHtml = await printPage.text();
assert.equal(printPage.status, 200);
assert.ok(!printHtml.includes('Long absence review'),
  'a role without attendance.followup must not see the Long Absence Review card');
assert.ok(!printHtml.includes('Giving Board statement') && !printHtml.includes('Faith Promise report'),
  'a role without giving.manage must not see the Giving/Faith Promise section at all');
assert.ok(printHtml.includes('Friday Service attendance') && printHtml.includes('Member directory'),
  'reports the role IS permitted for must still appear');
console.log('PASS: Print a report only shows cards the signed-in role actually has permission for');

const longAbsencePdfRes = await fetch(`${base}/reports/long-absence/pdf`, { headers: { Cookie: narrowedCookie } });
assert.equal(longAbsencePdfRes.status, 403, 'direct URL to a PDF the role lacks permission for must 403, not just be hidden from the UI');
console.log('PASS: /reports/long-absence/pdf 403s by direct URL for a role without attendance.followup');

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
