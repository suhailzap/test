import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Membership Review Suggested (services/membership-review.js): the 3-of-the-last-4-eligible-Fridays rule, the barrier, neutral Fridays,
 * Continue as Visitor suppression, idempotence, the lifecycle hook, fault isolation, and what closes a review. It never converts,
 * links or issues a QR code on its own.
 */

createIsolatedTestEnv('cciq-membership-review-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const review = await import('../services/membership-review.js');
const { checkInvariants } = await import('../lib/db-invariants.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -400);
const atNoon = (date) => `${date}T09:00:00.000Z`;

await createUser({ username: 'mr_admin', email: 'mr.admin@fixture.invalid', password: 'Mr-Fixture-Passw0rd!x', displayName: 'MR Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'mr_admin'").get().id;

let sessions = new Map();
const insertSession = db.prepare(
  `INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at)
   VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, 0, @at)`
);
function resetWorld({ goLive, weeks }) {
  db.exec(`DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM notifications; DELETE FROM reminders;
           DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors;`);
  if (goLive) setSetting('attendance.tracking_start_date', goLive);
  sessions = new Map();
  for (const n of weeks) addWeek(n);
}
function addWeek(n) {
  insertSession.run({ date: W(n), at: atNoon(W(n)) });
  sessions.set(n, db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(W(n)));
}
const S = (n) => sessions.get(n);
const range = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => from + i);
function fin(n) {
  const result = lifecycle.finalizeAttendance(S(n).id, { userId: null, confirmNoAttendance: true });
  assert.equal(result.ok, true, `finalize W(${n}) -> ${result.reason}`);
}
const finAll = (...ns) => ns.forEach(fin);
const people = new Map();
function visitor(name, { state = null } = {}) {
  if (!people.has(name)) {
    const v = visitors.createVisitor({ first_name: name, last_name: 'Guest', first_visit_date: OLD, phone: null }, { userId: null });
    people.set(name, v.id);
    if (state) db.prepare('UPDATE visitors SET state = ? WHERE id = ?').run(state, v.id);
  }
  return people.get(name);
}
/** A recorded visit on Friday W(n), tied to that service (as the register and the Kiosk do). */
const visit = (name, n, { linked = true } = {}) => db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)')
  .run(visitor(name), W(n), linked ? S(n).id : null, atNoon(W(n)));
const reviewsOf = (name, status = null) => db.prepare(`SELECT * FROM visitor_membership_reviews WHERE visitor_id = ? ${status ? 'AND status = ?' : ''} ORDER BY id`).all(...[visitor(name), ...(status ? [status] : [])]);
const openCount = () => db.prepare("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'").get().n;
const audits = (action) => db.prepare('SELECT * FROM audit_logs WHERE action = ? ORDER BY id').all(action);
const notes = () => db.prepare("SELECT COUNT(*) n FROM notifications WHERE category = 'membership_review'").get().n;
const reset = () => people.clear();
/** A member who has plainly been around since long before any Friday under test (so finalizing those Fridays is never ambiguous about them). */
function oldMember(first, last) {
  const m = createMember({ first_name: first, last_name: last }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', atNoon(OLD));
  return m;
}

// ---- 1. nothing is evaluated before there are four eligible finalized Fridays -----------------------------------------------------------
{
  reset(); resetWorld({ goLive: null, weeks: range(-5, -1) });
  setSetting('attendance.tracking_start_date', '');
  for (const n of [-4, -3, -2]) visit('Early', n);
  assert.equal(review.evaluateMembershipReviews().status, 'tracking_not_started', 'tracking not started -> no eligible Fridays');
  assert.equal(openCount(), 0);
  setSetting('attendance.tracking_start_date', W(-5));
  finAll(-5, -4, -3);
  assert.equal(review.evaluateMembershipReviews().status, 'insufficient', 'three finalized Fridays are not four');
  assert.equal(openCount(), 0, 'so no review, even with three visits');
  console.log('PASS (1) no review before tracking has started or four eligible Fridays are finalized');
}

// ---- 2. the rule: 3 of the last 4, evidence, idempotence, audit, one courtesy notification --------------------------------------------
{
  reset(); resetWorld({ goLive: W(-4), weeks: range(-4, -1) });
  visit('Three', -4); visit('Three', -3); visit('Three', -1);                   // 3 of the 4 (-4,-3,-2,-1)
  visit('Four', -4); visit('Four', -3); visit('Four', -2); visit('Four', -1);   // 4 of 4
  visit('Two', -4); visit('Two', -1);                                           // 2 of 4
  visit('Old', -6, { linked: false }); visit('Old', -5, { linked: false }); visit('Old', -4);                         // two of them fall outside the window
  visit('Dated', -4, { linked: false }); visit('Dated', -3, { linked: false }); visit('Dated', -2, { linked: false }); // dated visits, no session link
  finAll(-4, -3, -2);
  assert.equal(openCount(), 0, 'three finalized Fridays: nothing yet');
  fin(-1); // the hook opens them
  for (const n of ['Three', 'Four', 'Dated']) assert.equal(reviewsOf(n, 'open').length, 1, `${n}: one open review`);
  for (const n of ['Two', 'Old']) assert.equal(reviewsOf(n).length, 0, `${n}: no review`);
  const three = reviewsOf('Three')[0];
  const evidence = JSON.parse(three.window_json);
  assert.equal(evidence.fridays.length, 4); assert.equal(evidence.visits, 3);
  assert.deepEqual(evidence.fridays.map((f) => f.service_date), [W(-1), W(-2), W(-3), W(-4)], 'newest first');
  assert.deepEqual(evidence.fridays.map((f) => f.visited), [true, false, true, true]);
  assert.equal(three.trigger_service_date, W(-1)); assert.equal(three.trigger_session_id, S(-1).id);
  assert.equal(audits('visitor.membership_review_opened').length, 3, 'one audit row per opened review');
  assert.equal(notes(), 1, 'one courtesy notification per administrator for the batch (one administrator here)');
  const again = review.evaluateMembershipReviews();
  assert.deepEqual(again.opened, [], 'running it again opens nothing'); assert.equal(openCount(), 3);
  assert.equal(audits('visitor.membership_review_opened').length, 3); assert.equal(notes(), 1, 'and sends nothing: an open review never re-notifies');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members').get().n, 0, 'no member was created');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitors WHERE member_id IS NOT NULL').get().n, 0, 'nobody was linked');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM members WHERE qr_token IS NOT NULL").get().n, 0, 'no QR code was issued');
  console.log('PASS (2) 3 of the last 4 opens exactly one review with its evidence, one audit row and one notification; linked or merely dated visits both count; 2 of 4 and old visits do not; re-running changes nothing');
}

// ---- 3. cancelled and not-taken Fridays are neutral ----------------------------------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-8), weeks: range(-8, -1) });
  db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-3).id);
  fin(-8); fin(-7); fin(-6); fin(-5); fin(-4); fin(-2);
  const nt = lifecycle.markAttendanceNotTaken(S(-1).id, { userId: null, note: 'Power cut' });
  assert.equal(nt.ok, true);
  // the four eligible Fridays are -7,-6,-5,-4 ... wait: newest first: -2, -4, -5, -6 (-1 not taken and -3 cancelled are skipped)
  const found = review.eligibleFridayWindow();
  assert.equal(found.status, 'ready');
  assert.deepEqual(found.window.map((c) => c.date), [W(-2), W(-4), W(-5), W(-6)], 'cancelled and not-taken Fridays neither count nor consume a place');
  visit('Skipper', -2); visit('Skipper', -4); visit('Skipper', -6); visit('Skipper', -3, { linked: false }); // the visit on the cancelled Friday is not evidence
  visit('OnlyCancelled', -3, { linked: false }); visit('OnlyCancelled', -1, { linked: false }); visit('OnlyCancelled', -2);
  const out = review.evaluateMembershipReviews();
  assert.equal(reviewsOf('Skipper', 'open').length, 1, '3 of the 4 eligible Fridays');
  assert.equal(reviewsOf('OnlyCancelled').length, 0, 'visits on cancelled / not-taken Fridays do not count');
  assert.equal(out.status, 'ready');
  console.log('PASS (3) cancelled and "attendance not taken" Fridays are neutral: they do not count and do not take one of the four places');
}

// ---- 4. barrier: an unsettled Friday inside the sequence stops the evaluation ----------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-8), weeks: range(-8, 0) });
  finAll(-8, -7, -6, -5);
  visit('Barrier', -5); visit('Barrier', -3); visit('Barrier', -2); // skipping the unsettled Friday would give (-2,-3,-5,-6): three visits
  // -4 is left open (unsettled) while -3, -2 are finalized; W(0) stays open too
  fin(-3); fin(-2);
  const found = review.eligibleFridayWindow();
  assert.equal(found.status, 'blocked', 'W(-4) is unsettled and sits between finalized Fridays');
  assert.equal(found.barrierDate, W(-4), 'and the evaluation says which Friday it is waiting on');
  assert.equal(review.evaluateMembershipReviews().status, 'blocked', 'it waits at the barrier; it does not skip back to older Fridays to find four');
  assert.equal(openCount(), 0, 'so no review is opened, even though skipping it would have produced a window with three visits');
  fin(-4);
  assert.equal(review.eligibleFridayWindow().status, 'ready', 'once the barrier is settled the window is complete');
  assert.equal(reviewsOf('Barrier', 'open').length, 1, 'and the review opens (the lifecycle hook ran on finalization)');
  // the NEWEST Fridays being unsettled is not a barrier: nothing older is skipped
  reset(); resetWorld({ goLive: W(-8), weeks: range(-8, 0) });
  finAll(-8, -7, -6, -5, -4, -3);
  const lead = review.eligibleFridayWindow();
  assert.equal(lead.status, 'ready', 'unsettled Fridays newer than every finalized one are simply not eligible yet');
  assert.deepEqual(lead.window.map((c) => c.date), [W(-3), W(-4), W(-5), W(-6)]);
  console.log('PASS (4) an unsettled Friday inside the sequence is a barrier (the evaluation waits); unsettled Fridays newer than all finalized ones are ignored');
}

// ---- 5. who is evaluated: declined, joined and linked First Timers are not ----------------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-6), weeks: range(-6, -1) });
  for (const n of ['Declined', 'Active', 'Converted', 'Linked']) for (const w of [-4, -3, -2]) visit(n, w);
  db.prepare("UPDATE visitors SET state = 'declined' WHERE id = ?").run(visitor('Declined'));
  const member = oldMember('Linked', 'Guest');
  visitors.linkVisitorToMember(visitor('Linked'), member.id, { userId: adminId });
  const made = visitors.convertToMember(visitor('Converted'), { userId: adminId });
  assert.ok(made.member, 'converted');
  finAll(-6, -5, -4, -3, -2, -1);
  assert.equal(reviewsOf('Declined').length, 0, 'a First Timer who is Not Continuing is not suggested (current declined semantics are preserved)');
  assert.equal(reviewsOf('Linked').length, 0, 'nor one already linked to a member');
  assert.equal(reviewsOf('Converted').length, 0, 'nor one already converted');
  assert.equal(reviewsOf('Active', 'open').length, 1, 'but an ordinary First Timer is');
  console.log('PASS (5) Not Continuing, linked and converted First Timers are not suggested');
}

// ---- 6. Continue as Visitor: suppression until four further eligible Fridays are finalized -----------------------------------------------
{
  reset(); resetWorld({ goLive: W(-14), weeks: range(-14, -1) });
  for (const w of [-14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1]) visit('Loyal', w);
  finAll(-14, -13, -12);
  assert.equal(openCount(), 0);
  fin(-11);
  const first = reviewsOf('Loyal', 'open');
  assert.equal(first.length, 1, 'the first review opens after four finalized Fridays');
  const closed = review.continueAsVisitor(first[0].id, { userId: adminId, note: 'Still deciding' });
  assert.equal(closed.ok, true); assert.equal(closed.suppressAfterDate, W(-11), 'suppressed until four Fridays after the latest finalized one');
  const row = db.prepare('SELECT * FROM visitor_membership_reviews WHERE id = ?').get(first[0].id);
  assert.equal(row.status, 'continued'); assert.equal(row.closed_by, adminId); assert.equal(row.note, 'Still deciding'); assert.ok(row.closed_at);
  assert.equal(audits('visitor.membership_review_continued').length, 1);
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(visitor('Loyal')).state, 'new', 'the First Timer record itself is untouched');
  fin(-10); fin(-9); fin(-8);
  assert.equal(reviewsOf('Loyal', 'open').length, 0, 'three further finalized Fridays: still suppressed');
  fin(-7);
  assert.equal(reviewsOf('Loyal', 'open').length, 1, 'the fourth further finalized Friday ends the suppression and the review opens again');
  assert.equal(reviewsOf('Loyal').length, 2);
  assert.equal(review.continueAsVisitor(first[0].id, { userId: adminId }).reason, 'not_open', 'an already-closed review cannot be continued again');
  assert.equal(review.continueAsVisitor(999999, { userId: adminId }).reason, 'not_found');
  console.log('PASS (6) Continue as Visitor closes the review and suppresses a new one until four further eligible Fridays are finalized');
}

// ---- 7. one open review per visitor is a database fact -----------------------------------------------------------------------------------
{
  const open = db.prepare("SELECT visitor_id FROM visitor_membership_reviews WHERE status = 'open' LIMIT 1").get();
  assert.ok(open);
  assert.throws(() => db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01', '2026-01-02', '{\"fridays\":[1,2,3,4]}')").run(open.visitor_id), /UNIQUE/, 'a second open review for the same First Timer is refused by the database');
  // two evaluations back to back (as two events firing together) still make one
  const before = openCount();
  const [a, b] = [review.evaluateMembershipReviews(), review.evaluateMembershipReviews()];
  assert.deepEqual([a.opened.length, b.opened.length], [0, 0]); assert.equal(openCount(), before);
  console.log('PASS (7) one open review per First Timer is enforced by a unique index; repeated evaluation makes no duplicates');
}

// ---- 8. a failure in the evaluation never undoes or blocks the attendance action that triggered it ------------------------------------------
{
  reset(); resetWorld({ goLive: W(-4), weeks: range(-4, -1) });
  for (const w of [-4, -3, -2]) visit('Fault', w);
  finAll(-4, -3, -2);
  db.exec("CREATE TRIGGER fx_review_audit BEFORE INSERT ON audit_logs WHEN NEW.action = 'visitor.membership_review_opened' BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
  const originalError = console.error; const logged = []; console.error = (...args) => logged.push(args.join(' '));
  try {
    const result = lifecycle.finalizeAttendance(S(-1).id, { userId: null, confirmNoAttendance: true });
    assert.equal(result.ok, true, 'the Friday is finalized even though the review evaluation failed');
    assert.equal(db.prepare('SELECT finalization_state FROM attendance_sessions WHERE id = ?').get(S(-1).id).finalization_state, 'finalized');
    assert.equal(openCount(), 0, 'the failed evaluation left no half-written review (all or nothing)');
    assert.throws(() => review.evaluateMembershipReviews(), /injected failure/);
    assert.equal(openCount(), 0);
    assert.equal(review.evaluateSafely('test').status, 'error', 'the safe wrapper reports an error instead of throwing');
    assert.ok(logged.some((line) => /evaluation failed/.test(line)), 'and logs it');
  } finally { console.error = originalError; db.exec('DROP TRIGGER fx_review_audit'); }
  assert.ok(audits('visitor.membership_review_evaluation_failed').length >= 1, 'the failure is audited');
  const retry = review.evaluateMembershipReviews();
  assert.equal(retry.opened.length, 1, 'the next evaluation (a later event or the scheduled run) opens the review that was missed');
  console.log('PASS (8) a failing evaluation neither blocks nor undoes finalization, leaves nothing half-written, is logged and audited, and the next run recovers');
}

// ---- 9. Convert / Link close the open review; the invariants hold ------------------------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-6), weeks: range(-6, -1) });
  for (const n of ['ToConvert', 'ToLink']) for (const w of [-4, -3, -2]) visit(n, w);
  finAll(-6, -5, -4, -3, -2, -1);
  assert.equal(openCount(), 2);
  const converted = visitors.convertToMember(visitor('ToConvert'), { userId: adminId });
  assert.equal(reviewsOf('ToConvert')[0].status, 'converted'); assert.equal(reviewsOf('ToConvert')[0].member_id, converted.member.id);
  const target = oldMember('Existing', 'Person');
  const linked = visitors.linkVisitorToMember(visitor('ToLink'), target.id, { userId: adminId });
  assert.equal(linked.ok, true);
  assert.equal(reviewsOf('ToLink')[0].status, 'linked'); assert.equal(reviewsOf('ToLink')[0].member_id, target.id);
  assert.equal(openCount(), 0);
  const findings = checkInvariants(db).findings.filter((f) => /^(review|visitor)\./.test(f.code));
  assert.deepEqual(findings, [], 'no review or visitor-link invariant is broken');
  assert.equal(review.evaluateMembershipReviews().opened.length, 0, 'and they are not suggested again');
  console.log('PASS (9) making someone a member, or linking them, closes their open review with the member recorded; the integrity checker finds nothing');
}

// ---- 10. reading a review writes nothing; listing is bounded and sorted ----------------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-6), weeks: range(-6, -1) });
  for (let i = 0; i < 30; i += 1) for (const w of [-4, -3, -2]) visit(`Bulk${String(i).padStart(2, '0')}`, w);
  finAll(-6, -5, -4, -3, -2, -1);
  assert.equal(openCount(), 30);
  const snapshot = () => JSON.stringify([db.prepare('SELECT * FROM visitor_membership_reviews ORDER BY id').all(), db.prepare('SELECT COUNT(*) n FROM audit_logs').get(), db.prepare('SELECT * FROM visitors ORDER BY id').all()]);
  const before = snapshot();
  const page1 = review.listReviews({ status: 'open', page: 1, pageSize: 25 });
  const page2 = review.listReviews({ status: 'open', page: 2, pageSize: 25 });
  assert.equal(page1.rows.length, 25); assert.equal(page2.rows.length, 5); assert.equal(page1.total, 30); assert.equal(page1.pages, 2);
  assert.equal(new Set([...page1.rows, ...page2.rows].map((r) => r.id)).size, 30, 'pages do not overlap or repeat');
  const byName = review.listReviews({ status: 'open', pageSize: 5, sort: 'visitor', direction: 'asc' }).rows.map((r) => r.first_name);
  assert.deepEqual(byName, ['Bulk00', 'Bulk01', 'Bulk02', 'Bulk03', 'Bulk04'], 'sorted by name');
  assert.equal(review.listReviews({ status: 'bogus' }).total, 30, 'an unknown status filter is ignored, not an error');
  assert.equal(review.listReviews({ status: 'open', sort: 'x; DROP TABLE visitors', direction: 'sideways' }).rows.length, 25, 'an unknown sort column falls back safely');
  const detail = review.getReview(page1.rows[0].id);
  assert.equal(detail.evidence.fridays.length, 4); assert.ok(detail.visits.length >= 3);
  assert.equal(review.getReview(123456), null);
  assert.equal(snapshot(), before, 'reading reviews changes nothing (Review Later is a no-op by construction)');
  console.log('PASS (10) listing is paged, stable and safe against bad sort input; reading a review changes nothing');
}

// ---- 11. Convert and Link are all-or-nothing -----------------------------------------------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-6), weeks: range(-6, -1) });
  for (const n of ['AtomConvert', 'AtomLink']) for (const w of [-4, -3, -2]) visit(n, w);
  finAll(-6, -5, -4, -3, -2, -1);
  assert.equal(openCount(), 2);
  const target = oldMember('Atom', 'Target');
  const snapshot = () => JSON.stringify([db.prepare('SELECT * FROM visitors ORDER BY id').all(), db.prepare('SELECT * FROM visitor_membership_reviews ORDER BY id').all(),
    db.prepare('SELECT COUNT(*) n FROM members').get(), db.prepare('SELECT COUNT(*) n FROM member_status_history').get()]);
  const before = snapshot();
  const fail = (action) => db.exec(`CREATE TRIGGER fx_atom BEFORE INSERT ON audit_logs WHEN NEW.action = '${action}' BEGIN SELECT RAISE(ABORT, 'injected failure'); END`);
  const heal = () => db.exec('DROP TRIGGER IF EXISTS fx_atom');
  fail('visitor.became_member');
  assert.throws(() => visitors.convertToMember(visitor('AtomConvert'), { userId: adminId }), /injected failure/);
  heal();
  assert.equal(snapshot(), before, 'a failure while auditing a conversion leaves no member, no history row, no link and the review still open');
  fail('visitor.linked_to_member');
  assert.throws(() => visitors.linkVisitorToMember(visitor('AtomLink'), target.id, { userId: adminId }), /injected failure/);
  heal();
  assert.equal(snapshot(), before, 'a failure while auditing a link changes nothing, and the review is still open');
  assert.equal(visitors.linkVisitorToMember(visitor('AtomLink'), target.id, { userId: adminId }).ok, true, 'and the retry then works exactly once');
  assert.equal(reviewsOf('AtomLink')[0].status, 'linked');
  console.log('PASS (11) a failure part way through Convert or Link rolls everything back (member, history, link, review) and a retry then succeeds once');
}

// ---- 12. two PROCESSES evaluating at the same moment still open each review exactly once ------------------------------------------------------
{
  reset(); resetWorld({ goLive: W(-6), weeks: range(-6, -1) });
  for (let n = 0; n < 12; n += 1) for (const w of [-4, -3, -2]) visit(`Race${n}`, w);
  finAll(-6, -5, -4, -3, -2, -1);
  db.exec("DELETE FROM visitor_membership_reviews; DELETE FROM notifications; DELETE FROM audit_logs WHERE action = 'visitor.membership_review_opened'");
  assert.equal(openCount(), 0, 'sanity: eligible First Timers with no review yet');
  const { spawn } = await import('node:child_process');
  const { fileURLToPath } = await import('node:url');
  const code = "const m = await import(" + JSON.stringify(new URL('../services/membership-review.js', import.meta.url).href) + "); const r = m.evaluateMembershipReviews({ source: 'race' }); console.log(JSON.stringify({ opened: r.opened.length, status: r.status }));";
  const runChild = () => new Promise((resolve) => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', code], { env: process.env });
    let out = ''; let err = '';
    child.stdout.on('data', (d) => { out += d; }); child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (exitCode) => resolve({ exitCode, out: out.trim(), err: err.trim() }));
  });
  const results = await Promise.all([runChild(), runChild(), runChild()]);
  for (const r of results) assert.equal(r.exitCode, 0, `a racing evaluation does not crash: ${r.err.slice(0, 200)}`);
  const opened = results.map((r) => JSON.parse(r.out).opened);
  assert.equal(opened.reduce((a, b) => a + b, 0), 12, 'between them they opened exactly 12 reviews: no duplicates, none missed');
  assert.equal(openCount(), 12);
  assert.equal(audits('visitor.membership_review_opened').length, 12, 'and exactly one audit row each');
  assert.equal(db.prepare('SELECT COUNT(DISTINCT visitor_id) n FROM visitor_membership_reviews').get().n, 12);
  console.log('PASS (12) three processes evaluating at the same moment open each of 12 reviews exactly once, with one audit row each');
}

// ---- 13. a realistic First Timer: many historical visits do not qualify; only 3 of the last 4 eligible finalized Fridays does -----------------
{
  // Physical test: a First Timer was created with six historical visits. Visit COUNT, run of CONSECUTIVE visits, time elapsed and the status shown
  // (First visit / Came back / a recorded decision) must not decide anything. Only the finalized-Friday rule does.
  const membersBefore13 = db.prepare('SELECT COUNT(*) n FROM members').get().n;
  reset(); resetWorld({ goLive: W(-14), weeks: range(-14, -1) });
  finAll(...range(-14, -1));   // the Fridays are finalized first; the visits below are entered afterwards (a backfill), as in the physical test
  const six = [-14, -13, -12, -11, -10, -9];                               // six visits, all of them before the last four Fridays
  for (const w of six) visit('Isaiah', w);
  for (const w of range(-14, -5)) visit('Streak', w);                      // ten consecutive visits, none in the last four Fridays
  visit('Skips', -4); visit('Skips', -2); visit('Skips', -1);              // 3 of the last 4, with a gap (not consecutive)
  for (const w of [-4, -3]) visit('TwoOfFour', w);                         // only 2 of the last 4
  visit('Declined', -4); visit('Declined', -3); visit('Declined', -2);
  db.prepare("UPDATE visitors SET state = 'declined' WHERE id = ?").run(visitor('Declined'));   // an explicit decision already kept a person out of the evaluation
  review.evaluateMembershipReviews();
  assert.equal(visitors.getVisitor(visitor('Isaiah')).visits.length, 7, 'sanity: the visit made when the First Timer was recorded plus six more');
  assert.equal(visitors.getVisitor(visitor('Isaiah')).display_state, 'returning', 'and the status shown is Came back');
  assert.equal(reviewsOf('Isaiah').length, 0, 'six historical visits do not qualify');
  assert.equal(reviewsOf('Streak').length, 0, 'ten consecutive visits that all precede the last four Fridays do not qualify either');
  assert.equal(reviewsOf('TwoOfFour').length, 0, '2 of the last 4 does not qualify');
  assert.equal(reviewsOf('Skips', 'open').length, 1, '3 of the last 4 qualifies, without needing the visits to be consecutive');
  assert.equal(reviewsOf('Declined').length, 0, 'a recorded Not continuing decision keeps that person out of the evaluation, as before (what happens when such a person later attends is an owner decision, not settled here)');
  // the same six-visit person, then visiting on Fridays inside the window: 1 of 4, 2 of 4 do nothing; the third does
  visit('Isaiah', -4); review.evaluateMembershipReviews(); assert.equal(reviewsOf('Isaiah').length, 0, 'eight visits, 1 of the last 4');
  visit('Isaiah', -3); review.evaluateMembershipReviews(); assert.equal(reviewsOf('Isaiah').length, 0, 'nine visits, 2 of the last 4');
  visit('Isaiah', -2); review.evaluateMembershipReviews();
  assert.equal(reviewsOf('Isaiah', 'open').length, 1, 'ten visits and 3 of the last 4 finalized Fridays: now it qualifies');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitors WHERE member_id IS NOT NULL').get().n, 0, 'and nobody became a member by visiting');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members').get().n, membersBefore13, 'no member record was created');
  // an unsettled Friday inside the sequence is still a barrier; cancelled and not-taken Fridays are still neutral
  reset(); resetWorld({ goLive: W(-8), weeks: range(-8, -1) });
  for (const w of [-4, -3, -2]) visit('Waiting', w);
  finAll(-8, -7, -6, -5, -3, -2, -1);                                       // W(-4) is left unsettled
  review.evaluateMembershipReviews();
  assert.equal(reviewsOf('Waiting').length, 0, 'an unsettled Friday in the window is a barrier: nothing is suggested while it waits');
  db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(S(-4).id);
  review.evaluateMembershipReviews();
  assert.equal(review.eligibleFridayWindow().window.some((c) => c.date === W(-4)), false, 'a cancelled Friday is neutral: it neither counts nor takes a place');
  console.log('PASS (13) six historical visits (or ten consecutive ones) never qualify; 3 of the last 4 eligible finalized Fridays does, consecutive or not; the status shown never matters; barrier and neutral Fridays unchanged');
}

console.log('ALL PASS');
