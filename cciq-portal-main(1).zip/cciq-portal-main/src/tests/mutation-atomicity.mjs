import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Workflows that write several things must write all of them or none. Faults are injected with database triggers on the
 * disposable database (a trigger that aborts the second write of a workflow), so the real code path - not a mock - is what fails.
 * Afterwards nothing half-made may remain: no orphan member, no group without its first member, no audit entry claiming a
 * creation that was rolled back, no stray file, and no record pointing at a deleted file.
 */

const f = await buildPortalFixture('cciq-atomicity-');
const { db, ids, mods, users } = f;
const count = (table, where = '1=1') => db.prepare(`SELECT COUNT(*) n FROM ${table} WHERE ${where}`).get().n;
const fail = (name, sql) => db.exec(`CREATE TRIGGER ${name} ${sql}`);
const heal = (name) => db.exec(`DROP TRIGGER IF EXISTS ${name}`);
const ABORT = "BEGIN SELECT RAISE(ABORT, 'injected failure'); END";
const filesUnder = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir, { recursive: true }).filter((p) => fs.statSync(path.join(dir, p)).isFile()).sort() : []);
const storage = process.env.STORAGE_DIR;

// ---- First timer registration: the visitor and the first visit ----------------------------------------------------
{
  fail('fx_visit_insert', `BEFORE INSERT ON visitor_visits ${ABORT}`);
  const before = [count('visitors'), count('visitor_visits')];
  assert.throws(() => mods.visitors.createVisitor({ first_name: 'Half', last_name: 'Made', first_visit_date: mods.dates.today() }), /injected failure/);
  assert.deepEqual([count('visitors'), count('visitor_visits')], before, 'no first timer without their first visit');
  heal('fx_visit_insert');
  assert.ok(mods.visitors.createVisitor({ first_name: 'Whole', last_name: 'Made', first_visit_date: mods.dates.today() }).id);
  console.log('PASS (first timer) a failure while writing the first visit leaves no first timer behind');
}

// ---- Repeat visit: the visit and the "came back" state -------------------------------------------------------------
{
  const v = mods.visitors.createVisitor({ first_name: 'Returner', last_name: 'One', first_visit_date: mods.dates.addDays(mods.dates.today(), -14) });
  fail('fx_state', 'BEFORE UPDATE OF state ON visitors WHEN NEW.state = \'returning\' ' + ABORT);
  assert.throws(() => mods.visitors.recordVisit(v.id, { date: mods.dates.today() }), /injected failure/);
  assert.equal(count('visitor_visits', `visitor_id = ${v.id}`), 1, 'the visit was rolled back with the state change');
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(v.id).state, 'new');
  heal('fx_state');
  assert.equal(mods.visitors.recordVisit(v.id, { date: mods.dates.today() }).ok, true);
  assert.equal(count('visitor_visits', `visitor_id = ${v.id}`), 2);
  console.log('PASS (visit) the visit and the state change are one unit');
}

// ---- Conversion: member + link, never a member without the link, never two on a retry ----------------------------
{
  const v = mods.visitors.createVisitor({ first_name: 'Convert', last_name: 'Me', phone: '+974 5559 7777', age_group: 'adult', first_visit_date: mods.dates.today() });
  const members = count('members'); const history = count('member_status_history');
  fail('fx_link', 'BEFORE UPDATE OF member_id ON visitors WHEN NEW.member_id IS NOT NULL ' + ABORT);
  assert.throws(() => mods.visitors.convertToMember(v.id, { userId: users.churchAdmin.id }), /injected failure/);
  assert.equal(count('members'), members, 'no member is left behind when the link could not be saved');
  assert.equal(count('member_status_history'), history, 'and no status history for it');
  assert.equal(db.prepare('SELECT member_id, state FROM visitors WHERE id = ?').get(v.id).member_id, null);
  heal('fx_link');
  const ok = mods.visitors.convertToMember(v.id, { userId: users.churchAdmin.id });
  assert.equal(ok.ok, true);
  assert.equal(count('members'), members + 1, 'a retry creates exactly one member');
  assert.equal(mods.visitors.convertToMember(v.id, { userId: users.churchAdmin.id }).reason, 'already_a_member');
  assert.equal(count('members'), members + 1);
  console.log('PASS (conversion) a failure after the member was created rolls the member back; the retry creates exactly one; a second conversion is refused');
}

// ---- Family group with its first member ----------------------------------------------------------------------------------
{
  const groups = count('family_groups');
  fail('fx_family_member', `BEFORE INSERT ON family_group_members ${ABORT}`);
  assert.throws(() => mods.family.createFamilyGroup({ name: 'Orphan Family', primaryMemberId: ids.member.free }), /injected failure/);
  assert.equal(count('family_groups'), groups, 'no family group without the member it was created for');
  heal('fx_family_member');
  console.log('PASS (family group) the group and its first member are one unit');
}

// ---- Ministry: leaving and the leadership it clears ---------------------------------------------------------------------------
{
  const leader = mods.ministries.createMinistry({ name: 'Atomic Ministry', leader_member_id: ids.member.a3 });
  fail('fx_leader_clear', 'BEFORE UPDATE OF leader_member_id ON ministries WHEN NEW.leader_member_id IS NULL ' + ABORT);
  assert.throws(() => mods.ministries.removeMember(leader.id, ids.member.a3), /injected failure/);
  assert.equal(count('ministry_members', `ministry_id = ${leader.id} AND member_id = ${ids.member.a3} AND left_at IS NOT NULL`), 0, 'they are not recorded as having left while still the leader');
  heal('fx_leader_clear');
  mods.ministries.removeMember(leader.id, ids.member.a3);
  assert.equal(db.prepare('SELECT leader_member_id l FROM ministries WHERE id = ?').get(leader.id).l, null);
  console.log('PASS (ministry) leaving a ministry and clearing the leader are one unit');
}

// ---- Cell group: the group and the membership its leader implies ------------------------------------------------------------------
{
  const groups = count('cell_groups');
  fail('fx_group_member', `BEFORE INSERT ON cell_group_members ${ABORT}`);
  assert.throws(() => mods.groups.createGroup({ name: 'Half Group', leader_member_id: ids.member.free }), /injected failure/);
  assert.equal(count('cell_groups'), groups, 'no group without its leader\'s membership');
  const g = mods.groups.getGroup(ids.groupA);
  assert.throws(() => mods.groups.updateGroup(ids.groupA, { ...g, name: 'Renamed', leader_member_id: ids.member.free }), /injected failure/);
  assert.equal(mods.groups.getGroup(ids.groupA).name, 'Group Alpha', 'an update that could not finish changes nothing');
  heal('fx_group_member');
  console.log('PASS (cell group) creating or editing a group and syncing its leader\'s membership are one unit');
}

// ---- Documents: no stray file, and the current file survives a failed replacement ------------------------------------------------------
{
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const beforeFiles = filesUnder(storage);
  fail('fx_doc_version', `BEFORE INSERT ON document_versions WHEN NEW.version = 1 ${ABORT}`);
  const docs = count('documents');
  assert.throws(() => mods.documents.createDocument({ title: 'Half document' }, { userId: users.churchAdmin.id, file: { originalname: 'a.png', buffer: png, size: png.length } }), /injected failure/);
  assert.equal(count('documents'), docs, 'no document row');
  assert.deepEqual(filesUnder(storage), beforeFiles, 'and no stray file on disk');
  heal('fx_doc_version');
  fail('fx_doc_version2', `BEFORE INSERT ON document_versions WHEN NEW.version = 2 ${ABORT}`);
  const current = mods.documents.getDocument(ids.document);
  assert.throws(() => mods.documents.replaceFile(ids.document, { originalname: 'b.png', buffer: png, size: png.length }, { userId: users.churchAdmin.id }), /injected failure/);
  const after = mods.documents.getDocument(ids.document);
  assert.equal(after.stored_path, current.stored_path, 'the current file is still the current file');
  assert.equal(after.version, current.version);
  assert.deepEqual(filesUnder(storage), beforeFiles, 'and the rejected replacement left no file behind');
  heal('fx_doc_version2');
  console.log('PASS (documents) a failed upload or replacement leaves no row, no stray file, and the current file intact');
}

// ---- over HTTP: member create (record + audit) and photo (file + record) --------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const members = count('members'); const audits = count('audit_logs', "action = 'member.created'");
  fail('fx_audit_member_created', "BEFORE INSERT ON audit_logs WHEN NEW.action = 'member.created' " + ABORT);
  const res = await admin.post('/members', { first_name: 'Atomic', last_name: 'Newmember', status: 'pending', duplicate_override: '1' }, { csrfFrom: '/members/new' });
  const page = await res.text();
  assert.ok(res.status >= 500, `the failure is reported, not hidden (${res.status})`);
  assert.doesNotMatch(page, /injected failure|SqliteError|at \w+ \(|node_modules|\.js:\d+/, 'and no stack trace or internals reach the page');
  assert.equal(count('members'), members, 'no half-created member');
  assert.equal(count('member_status_history', "reason = 'Record created' AND member_id NOT IN (SELECT id FROM members)"), 0);
  assert.equal(count('audit_logs', "action = 'member.created'"), audits);
  heal('fx_audit_member_created');
  const ok = await admin.post('/members', { first_name: 'Atomic', last_name: 'Newmember', status: 'pending', duplicate_override: '1' }, { csrfFrom: '/members/new' });
  assert.equal(ok.status, 302);
  assert.equal(count('members'), members + 1);
  assert.equal(count('members', "first_name = 'Atomic'"), 1, 'the retry created exactly one member');
  console.log('PASS (member create over HTTP) a failure while auditing rolls the member back, shows a safe error page, and the retry creates exactly one member');

  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const target = ids.member.a3;
  const up1 = await admin.upload(`/members/${target}/photo`, { buffer: png, type: 'image/png', name: 'one.png' }, { csrfFrom: `/members/${target}/edit` });
  assert.equal(up1.status, 302);
  const firstPath = db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(target).p;
  assert.ok(firstPath && fs.existsSync(path.join(storage, firstPath)));
  const folder = path.dirname(path.join(storage, firstPath));
  assert.equal(fs.readdirSync(folder).length, 1);
  fail('fx_photo', 'BEFORE UPDATE OF photo_path ON members ' + ABORT);
  const up2 = await admin.upload(`/members/${target}/photo`, { buffer: png, type: 'image/png', name: 'two.png' }, { csrfFrom: `/members/${target}/edit` });
  await up2.arrayBuffer();
  assert.equal(db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(target).p, firstPath, 'the record still points at the previous photo');
  assert.deepEqual(fs.readdirSync(folder), [path.basename(firstPath)], 'the previous photo was not deleted and no new file was left behind');
  heal('fx_photo');
  const up3 = await admin.upload(`/members/${target}/photo`, { buffer: png, type: 'image/png', name: 'three.png' }, { csrfFrom: `/members/${target}/edit` });
  assert.equal(up3.status, 302);
  const thirdPath = db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(target).p;
  assert.notEqual(thirdPath, firstPath);
  assert.deepEqual(fs.readdirSync(folder), [path.basename(thirdPath)], 'after a successful change only the new photo remains');
  console.log('PASS (photo) a failed save keeps the previous photo and leaves no new file; a successful one replaces it and keeps exactly one file');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
