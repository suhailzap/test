import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ejs from 'ejs';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal } from './lib/portal-fixture.mjs';

/*
 * The sign-in page: a split screen with decorative atmosphere and the verse of the day on a wide display, a banner on a tablet, the form first on a phone - with every sign-in function
 * kept, authentication untouched, nothing loaded from outside this computer, and motion that stops for anyone who asks.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const f = await buildPortalFixture('cciq-login-page-');
const { users } = f;
f.mods.setSetting('church.public_about', true); // the "Not a member yet?" link is shown when the church has published its About page
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const login = async () => { const r = await fetch(`${portal.base}/login`); return { status: r.status, html: await r.text() }; };
  const { status, html } = await login();
  const flat = html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&middot;/g, '·').replace(/&amp;/g, '&').replace(/\s+/g, ' ');

  // ---- 1. every function the page already had is still there ---------------------------------------------------------------------------------------------------------------------------------
  assert.equal(status, 200);
  assert.match(html, /<img src="[^"]*logo[^"]*"[^>]*alt="Christian Church in Qatar"/i, 'the real CCIQ logo'); assert.match(flat, /CCIQ Church Portal/); assert.match(flat, /Christian Church in Qatar/);
  assert.match(html, /<label for="email">Username or email<\/label>\s*<input type="text" id="email" name="email"[^>]*autocomplete="username"[^>]*required[^>]*autofocus/);
  assert.match(html, /<label for="password">Password<\/label>\s*<input type="password" id="password" name="password"[^>]*autocomplete="current-password"[^>]*required/);
  assert.match(html, /<button class="btn btn--block" type="submit"[^>]*>Sign in<\/button>/);
  assert.match(html, /href="\/forgot-password">Forgot your password\?</); assert.match(html, /<button type="button" class="auth__alt-item" data-quick-access-open>[\s\S]*?<span>Quick Access<\/span><\/button>/); assert.match(html, /<dialog class="quick-access" id="quick-access-dialog"/);
  assert.match(html, /href="\/login\?next=%2Fkiosk">[\s\S]*?<span>Sign in to Attendance Kiosk<\/span>/, 'Sign in to Attendance Kiosk');
  assert.match(html, /name="_csrf" value="[^"]+"/, 'the CSRF token'); assert.match(html, /name="next" value="\/"/);
  assert.match(flat, /(Mon|Tues|Wednes|Thurs|Fri|Satur|Sun)day, \d{1,2} \w+ \d{4} · Qatar time/, 'the Qatar date');
  assert.match(html, /<blockquote class="auth__verse-text">[^<]+<\/blockquote>/, 'the verse of the day'); assert.match(flat, /Verse of the day/); assert.match(flat, /\b(NIV)\b/); assert.match(flat, /Scripture quotations taken from The Holy Bible, New International Version/, 'with its NIV notice');
  { const kiosk = await (await fetch(`${portal.base}/login?next=%2Fkiosk`)).text(); assert.match(kiosk, /Attendance Kiosk Sign In/); assert.match(kiosk, /href="\/login">[\s\S]*?<span>Sign in to the normal Portal<\/span>/); }
  console.log('PASS (functions) logo, title, Username or email, Password, Sign in, Forgot your password?, Quick Access, Attendance Kiosk, CSRF, the Qatar date, the verse of the day with its notice');

  // ---- 2. authentication is unchanged ----------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const post = async (fields, csrf = true) => { const page = await fetch(`${portal.base}/login`); const h = await page.text(); const token = h.match(/name="_csrf" value="([^"]+)"/)[1]; const pre = page.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
      const r = await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ ...(csrf ? { _csrf: token } : {}), ...fields }) }); return { status: r.status, body: await r.text(), location: r.headers.get('location') }; };
    assert.equal((await post({ email: users.memberA.email, password: 'wrong-password-1!', next: '/' })).status, 401, 'a wrong password is refused'); assert.match((await post({ email: users.memberA.email, password: 'wrong-password-1!', next: '/' })).body, /Username or email/, 'and the form comes back');
    assert.equal((await post({ email: users.memberA.email, password: f.PASSWORD, next: '/' }, false)).status, 403, 'no CSRF token, no sign-in');
    const ok = await post({ email: users.memberA.email, password: f.PASSWORD, next: '/' }); assert.equal(ok.status, 302); assert.equal(ok.location, '/', 'the right password signs in'); }
  { for (const url of ['/forgot-password']) { const r = await fetch(`${portal.base}${url}`); assert.equal(r.status, 200); assert.match(await r.text(), /auth__shell/, `${url} shares the sign-in layout`); } }
  console.log('PASS (authentication) wrong password 401 with the form back, a missing CSRF token refused, the right password signs in, and the forgot-password page shares the layout');

  // ---- 3. nothing from outside, a replaceable backdrop ------------------------------------------------------------------------------------------------------------------------------------------
  { assert.ok(!/(src|href)="https?:\/\//i.test(html.replace(/<a [^>]*href="https?:[^"]*"[^>]*>/g, '')), 'no external asset in the markup'); assert.ok(!/<video|<audio|<iframe/i.test(html), 'no video, audio or frame'); }
  { const requests = []; const context = await browser.newContext({ viewport: { width: 1280, height: 800 } }); const page = await context.newPage(); page.on('request', (r) => requests.push(r.url()));
    await page.goto(`${portal.base}/login`, { waitUntil: 'networkidle' }); const hosts = new Set(requests.map((u) => new URL(u).host)); assert.deepEqual([...hosts], [new URL(portal.base).host], `every request goes to this server (${[...hosts].join(', ')})`);
    assert.ok(!requests.some((u) => /login-worship(-1000)?\.webp/.test(u)), 'no unverified decorative photograph is requested'); await context.close(); }
  { const css = fs.readFileSync(path.join(root, 'src/public/css/cciq.css'), 'utf8'); assert.equal((css.match(/--login-backdrop:/g) || []).length, 1, 'the neutral backdrop is set in exactly one place'); assert.equal((css.match(/--login-backdrop-small:/g) || []).length, 1, 'and the compact backdrop in exactly one place');
    assert.match(css, /--login-backdrop: linear-gradient\(/, 'the wide surface is a local neutral gradient'); assert.match(css, /--login-backdrop-small: linear-gradient\(/, 'the compact surface is a local neutral gradient');
    assert.ok(!fs.existsSync(path.join(root, 'src/public/branding/login-worship.webp')) && !fs.existsSync(path.join(root, 'src/public/branding/login-worship-1000.webp')), 'unverified decorative image files are absent');
    assert.ok(!fs.existsSync(path.join(root, 'tools/generate-login-backdrop.mjs')) && !fs.existsSync(path.join(root, 'src/public/branding/login-worship.jpg')), 'the old generated illustration and its generator are gone'); }
  { const css = fs.readFileSync(path.join(root, 'src/public/css/cciq.css'), 'utf8'); const waves = fs.readFileSync(path.join(root, 'src/public/branding/login-waves.svg'), 'utf8');
    assert.match(css, /\.auth__shell \.auth__panel \{[^}]*url\("\/branding\/login-waves\.svg"\)/, 'the sign-in side uses the bundled ribbons'); assert.ok(waves.length < 6000, 'and they are a few kilobytes'); assert.ok(!/(href|src)=["']https?:|url\(["']?https?:/i.test(waves), 'no external reference');
    for (const c of waves.match(/<!--[\s\S]*?-->/g) || []) assert.ok(!/--/.test(c.slice(4, -3)), 'valid XML comments'); assert.ok(!/<text|<script|<animate/i.test(waves), 'decoration only: no text, script or animation'); }
  { const layout = fs.readFileSync(path.join(root, 'src/views/layouts/auth.ejs'), 'utf8'); assert.ok(!/photo of|photograph of|our worship|CCIQ worship team|our congregation|our church building/i.test(layout.replace(/is never described as CCIQ/g, '')), 'the page never describes the artwork as CCIQ, its people or its place'); assert.match(layout, /class="auth__hero-art" aria-hidden="true"/, 'the artwork is decorative: hidden from assistive technology and carries no caption'); }
  console.log('PASS (offline, neutral) every request stays on this server, no video or audio, the decorative backdrop is a local CSS gradient, and no unverified photograph is loaded');

  // ---- 4. Friday is derived from the date, never hard-coded -------------------------------------------------------------------------------------------------------------------------------------
  { const render = (today) => ejs.renderFile(path.join(root, 'src/views/layouts/auth.ejs'), {
      title: 'Sign in', body: '<p>form</p>', church: { name: 'Christian Church in Qatar', shortName: 'CCIQ', logo: '/l.png', logoSmall: '/s.png' }, assetVersion: 'x', fridayTitle: 'CCIQ Friday Service',
      verseOfTheDay: { display: 'A verse.', reference: 'Ref 1:1', translation: 'NIV', notice: 'Notice.' }, dates: { today: () => today, formatDate: () => 'a date' }, csrfToken: 't', flash: null });
    { const fri = await render('2026-10-09'); assert.match(fri, /<h2>Welcome to Friday Service<\/h2>/, 'a Friday (Qatar date) welcomes to Friday Service'); assert.match(fri, /We(&rsquo;|&#39;|')re glad you(&rsquo;|&#39;|')re here\./); assert.ok(!/<h2>Welcome to CCIQ<\/h2>/.test(fri)); }
    for (const day of ['2026-10-05', '2026-10-06', '2026-10-07', '2026-10-08', '2026-10-10', '2026-10-11']) { const html = await render(day); assert.match(html, /<h2>Welcome to CCIQ<\/h2>/, `${day} welcomes to CCIQ`); assert.ok(!/Welcome to Friday Service|glad you/.test(html), `${day} is not a Friday: no Friday message`); } }
  console.log('PASS (Friday) "Welcome to Friday Service / We are glad you are here" appears only when the Qatar date is a Friday; every other day says "Welcome to CCIQ"');

  // ---- 5. reduced motion ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  for (const [reduce, expected] of [['no-preference', 'auth-drift'], ['reduce', 'none']]) {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, reducedMotion: reduce }); const page = await context.newPage(); await page.goto(`${portal.base}/login`, { waitUntil: 'load' });
    const m = await page.evaluate(() => { const cs = getComputedStyle(document.querySelector('.auth__hero-art')); return { anim: cs.animationName, dur: cs.animationDuration }; });
    assert.equal(m.anim, expected, `reducedMotion=${reduce}`); if (reduce === 'no-preference') assert.ok(parseFloat(m.dur) >= 20 && parseFloat(m.dur) <= 30, `a slow zoom of 20 to 30 seconds (${m.dur})`);
    await context.close();
  }
  console.log('PASS (motion) one very slow zoom (20 to 30 seconds), switched off entirely when reduced motion is requested');

  // ---- 6. every width ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  for (const [width, height] of [[320, 640], [375, 667], [390, 844], [430, 932], [768, 1024], [1024, 768], [1280, 800], [1440, 900], [1920, 1080]]) {
    const context = await browser.newContext({ viewport: { width, height } }); const page = await context.newPage(); await page.goto(`${portal.base}/login`, { waitUntil: 'load' });
    const m = await page.evaluate(() => {
      const r = (sel) => { const e = document.querySelector(sel); if (!e) return null; const b = e.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height, right: b.right, bottom: b.bottom, display: getComputedStyle(e).display }; };
      const verse = document.querySelector('.auth__verse-text'); const links = ['a[href="/forgot-password"]', '[data-quick-access-open]', 'a[href="/login?next=%2Fkiosk"]', '.about-link a', '.auth__foot'].map((s) => [s, r(s)]);
      return { overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, button: r('button[type=submit]'), hero: r('.auth__hero'), art: r('.auth__hero-art'), panel: r('.auth__panel'), card: r('.auth__card'), links,
        verseClipped: verse ? verse.scrollHeight > verse.clientHeight + 1 || getComputedStyle(verse).textOverflow === 'ellipsis' : true, verseVisible: verse ? r('.auth__verse-text') : null, email: r('#email'), vh: window.innerHeight,
        verseSize: verse ? parseFloat(getComputedStyle(verse).fontSize) : 0, noticeSize: parseFloat(getComputedStyle(document.querySelector('.auth__verse-notice')).fontSize), logo: r('.auth__brand img'), panelBg: getComputedStyle(document.querySelector('.auth__panel')).backgroundColor,
        alt: r('.auth__alt'), quick: r('[data-quick-access-open]'), kiosk: r('.auth__kiosk-link') };
    });
    const tag = `${width}px`;
    if (m.overflow > 0) problems.push(`${tag}: sideways scroll ${m.overflow}px`);
    if (!m.button || m.button.right > width + 1) problems.push(`${tag}: the Sign in button is off screen`);
    for (const [sel, box] of m.links) { if (!box || box.w === 0 || box.h === 0 || box.right > width + 1) problems.push(`${tag}: ${sel} missing, hidden or off screen`); }
    if (m.verseClipped || !m.verseVisible || m.verseVisible.w === 0) problems.push(`${tag}: the verse is clipped or hidden`);
    if (width <= 430) {
      if (m.button.bottom > height) problems.push(`${tag}: the Sign in button is below the fold (${Math.round(m.button.bottom)} > ${height})`);
      if (m.art.display !== 'none' && m.art.w > 0 && m.art.h > 0 && (await page.evaluate(() => getComputedStyle(document.querySelector('.auth__hero-art')).display)) !== 'none') problems.push(`${tag}: the artwork is still drawn on a phone`);
      if (m.hero.y < m.card.y) problems.push(`${tag}: on a phone the form must come before the atmosphere`);
    }
    if (width >= 768 && width < 1100 && !(m.hero.y < m.card.y && m.hero.h >= 150 && m.hero.right >= width - 1)) problems.push(`${tag}: a tablet shows a banner above the form`);
    if (width >= 1100 && !(m.hero.x === 0 && m.panel.x > m.hero.right - 2 && m.hero.h >= height - 2)) problems.push(`${tag}: a wide display is a split screen (hero ${JSON.stringify(m.hero)}, panel ${JSON.stringify(m.panel)})`);
    if (width >= 1100 && m.card.w > 480) problems.push(`${tag}: the sign-in card is too wide (${m.card.w})`);
    if (width >= 1100) {
      const share = m.hero.w / width; if (!(share >= 0.57 && share <= 0.63)) problems.push(`${tag}: the hero is ${Math.round(share * 100)}% of the width (want 58-62%)`);
      if (!(m.verseSize >= 22)) problems.push(`${tag}: the verse is only ${m.verseSize}px`);
      if (!(m.noticeSize <= 12)) problems.push(`${tag}: the copyright notice is ${m.noticeSize}px and competes with the verse`);
      if (!(m.logo.w >= 100)) problems.push(`${tag}: the logo is small (${m.logo.w}px)`);
      if (!(m.panelBg === 'rgb(246, 242, 234)')) problems.push(`${tag}: the sign-in side is not the warm off-white (${m.panelBg})`);
    }
    if (!(m.alt.w > 0 && m.alt.h >= 40) || m.quick.h < 40 || m.kiosk.h < 40) problems.push(`${tag}: the Quick Access and Kiosk actions are missing or too small to tap`);
    if (m.button.h < 46) problems.push(`${tag}: the Sign in button is too short to be the main action (${m.button.h}px)`);
    // typing works (the keyboard is not blocked by anything decorative)
    await page.fill('#email', 'someone@example.org'); await page.fill('#password', 'not-a-real-password'); assert.equal(await page.inputValue('#email'), 'someone@example.org');
    await context.close();
  }
  // the on-screen keyboard: a phone with only 320px of height left must still be able to reach and use every field and the button (nothing is fixed or clipped)
  { const context = await browser.newContext({ viewport: { width: 375, height: 320 }, hasTouch: true, isMobile: true }); const page = await context.newPage(); await page.goto(`${portal.base}/login`, { waitUntil: 'load' });
    const ov = await page.evaluate(() => [getComputedStyle(document.documentElement).overflowY, getComputedStyle(document.body).overflowY]);
    assert.ok(!ov.includes('hidden') && !ov.includes('clip'), `the page can scroll (${ov})`);
    await page.fill('#password', 'typed-with-the-keyboard-open'); assert.equal(await page.inputValue('#password'), 'typed-with-the-keyboard-open');
    await page.locator('form[action="/login"] button[type=submit]').scrollIntoViewIfNeeded(); const box = await page.locator('form[action="/login"] button[type=submit]').boundingBox(); assert.ok(box && box.y >= 0 && box.y + box.height <= 320, 'the Sign in button can be scrolled into view');
    await context.close(); }
  console.log('PASS (keyboard) with only 320px of height (an open on-screen keyboard) the page still scrolls, the fields take input and the Sign in button can be reached');
  assert.deepEqual(problems, [], problems.join('\n'));
  console.log('PASS (widths) 320, 375, 390, 430, 768, 1024, 1280, 1440 and 1920 px: no sideways scroll, the form first on a phone (Sign in above the fold), a banner on a tablet, a 60/40 two-zone composition from 1100, every action reachable and tappable, the verse never clipped');
  console.log('PASS login-page');
} finally {
  await browser.close();
  await portal.stop();
}
