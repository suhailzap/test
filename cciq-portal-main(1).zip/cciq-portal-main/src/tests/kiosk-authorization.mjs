import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Who may operate the Attendance Kiosk / check-in interface: the dedicated Kiosk account, the Church Admin and the Super Admin. NOT a Cell Group leader, NOT a Member.
 *
 * Root cause of the defect: every check-in route was guarded only by an attendance PERMISSION (attendance.record or attendance.checkin), and a Cell Group leader holds both
 * (they take attendance for their own group). The interface behind those routes searches everyone on file (any status, by name, member ID or whole mobile number), checks anyone
 * in, registers First Timers, and the member-photo route trusted attendance.checkin for any member's photo. So a leader who typed /kiosk simply got in. The fix is a server-side
 * check of the KIND of sign-in as well as the permission, on every /kiosk and /attendance/checkin route and on the photo route; permissions themselves are untouched (leaders keep
 * recording their own group's attendance).
 *
 * Tested for all five roles by direct address and by crafted request: pages, search (name and mobile number), QR lookup, review, record, confirm, First Timer registration and
 * its helpers, the member photo, the navigation link, the login entry, and a session whose role is removed after sign-in. A refusal writes nothing.
 */

const f = await buildPortalFixture('cciq-kiosk-authz-');
const { db, ids, users, mods } = f;
const qr = await import('../services/qr-checkin.js');
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const world = () => JSON.stringify([count('SELECT COUNT(*) n FROM attendance_records'), count('SELECT COUNT(*) n FROM visitors'), count('SELECT COUNT(*) n FROM visitor_visits'), count('SELECT COUNT(*) n FROM members'),
  count("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'attendance.%' OR action LIKE 'visitor.%'")]);
const token = qr.ensureQrToken(ids.member.b1); // Bella MemberB, in Group Beta: not in the leader's group
// Bella has a photo (a real file), to prove the photo route does not hand any member's picture to a leader
const photoRel = `members/${ids.member.b1}/portrait.png`;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
fs.mkdirSync(path.dirname(path.join(process.env.STORAGE_DIR, photoRel)), { recursive: true }); fs.writeFileSync(path.join(process.env.STORAGE_DIR, photoRel), png);
db.prepare('UPDATE members SET photo_path = ?, photo_updated_at = ? WHERE id = ?').run(photoRel, new Date().toISOString(), ids.member.b1);

const portal = await startPortal();
try {
  const roles = {
    super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD),
    leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD), member: await signIn(portal.base, users.memberA.email, f.PASSWORD)
  };
  const MAY = { super: true, church: true, kiosk: true, leader: false, member: false };
  const refusedStatus = (r) => r.status === 403;

  // ---- 1. pages and helpers by direct address -----------------------------------------------------------------------------------------------------------------------------------------------
  const gets = ['/kiosk', '/kiosk/count', '/attendance/checkin', '/attendance/checkin/first-timer', '/attendance/checkin/inviter-search?q=ann', '/attendance/checkin/first-timer/done', `/media/members/${ids.member.b1}/photo`];
  for (const [who, client] of Object.entries(roles)) {
    for (const url of gets) {
      const r = await client.get(url); await r.arrayBuffer();
      if (MAY[who]) assert.ok([200, 302].includes(r.status), `${who} ${url} -> ${r.status}`);
      else assert.ok(r.status === 403 || (url.startsWith('/media/') && r.status === 404), `${who} must be refused ${url} (got ${r.status})`);
    }
  }
  console.log('PASS (pages) the Kiosk, Church Admin and Super Admin open /kiosk, its count, the desk, First Timer registration and the photo route; a Cell Group leader and a Member are refused each by address');

  // ---- 1b. nobody signed in: every kiosk page goes to the sign-in screen, every kiosk POST is refused and writes nothing -------------------------------------------------------------------
  {
    const before = world();
    for (const url of gets) { const r = await fetch(`${portal.base}${url}`, { redirect: 'manual' }); await r.arrayBuffer(); assert.equal(r.status, 302, `signed out ${url} -> ${r.status}`); assert.match(r.headers.get('location') || '', /^\/login\?next=/, `signed out ${url} goes to the sign-in screen`); }
    for (const url of ['/attendance/checkin/search', '/attendance/checkin/lookup', '/attendance/checkin/review', '/attendance/checkin/record', '/attendance/checkin/confirm', '/attendance/checkin/first-timer']) {
      const r = await fetch(`${portal.base}${url}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ q: 'Bella', token, kiosk: '1', person: `member:${ids.member.b1}`, first_name: 'Sneaky', last_name: 'Guest' }) });
      const text = await r.text();
      assert.ok([302, 401, 403].includes(r.status), `signed out POST ${url} must be refused (got ${r.status})`); assert.ok(!/Bella|MemberB/.test(text), `signed out POST ${url} reveals nothing`);
    }
    assert.equal(world(), before, 'a signed-out request wrote nothing');
    console.log('PASS (signed out) every kiosk page redirects to the sign-in screen, and every kiosk POST is refused with nothing written or revealed');
  }

  // ---- 2. crafted requests: search (name and number), QR lookup, review, record, confirm, registration -----------------------------------------------------------------------------
  const crafted = [
    ['search by name', '/attendance/checkin/search', { q: 'Bella', kiosk: '1' }],
    ['search by whole mobile number', '/attendance/checkin/search', { q: '+974 5550 0011', kiosk: '1' }],
    ['QR lookup', '/attendance/checkin/lookup', { token }],
    ['review', '/attendance/checkin/review', { kiosk: '1', person: [`member:${ids.member.b1}`] }],
    ['record', '/attendance/checkin/record', { kiosk: '1', person: [`member:${ids.member.b1}`] }],
    ['confirm', '/attendance/checkin/confirm', { token }],
    ['First Timer registration', '/attendance/checkin/first-timer', { first_name: 'Sneaky', last_name: 'Guest', kiosk: '1' }]
  ];
  for (const who of ['leader', 'member']) {
    const before = world();
    for (const [label, url, fields] of crafted) {
      const r = await roles[who].post(url, fields, { csrfFrom: '/account/password' }); await r.text();
      assert.ok(refusedStatus(r), `${who} ${label} -> ${r.status}`);
    }
    assert.equal(world(), before, `${who}: every refused request wrote nothing (no attendance, no First Timer, no audit row)`);
    // the refusal shows nothing of the search
    const search = await roles[who].post('/attendance/checkin/search', { q: 'Bella', kiosk: '1' }, { csrfFrom: '/account/password' }); const body = await search.text();
    assert.ok(!/Bella/.test(body.replace(/value="[^"]*"/g, '')) || !/MemberB/.test(body), `${who}: the refusal reveals no member`);
  }
  // the operators can use all of it (and a leader could not)
  for (const who of ['kiosk', 'church', 'super']) {
    const search = await roles[who].post('/attendance/checkin/search', { q: 'Bella', kiosk: '1' }, { csrfFrom: '/kiosk' }); const body = await search.text();
    assert.equal(search.status, 200, `${who} search`); assert.match(body, /Bella MemberB/, `${who} finds a member by name`);
    const phone = await roles[who].post('/attendance/checkin/search', { q: '+974 5550 0011', kiosk: '1' }, { csrfFrom: '/kiosk' }); assert.match(await phone.text(), /Bella MemberB/, `${who} finds a member by whole mobile number`);
    const lookup = await roles[who].post('/attendance/checkin/lookup', { token }, { csrfFrom: '/kiosk' }); const j = await lookup.json().catch(() => null); assert.ok([200, 409].includes(lookup.status), `${who} QR lookup answers (${lookup.status})`); if (lookup.status === 200) assert.ok(j.ok);
  }
  { const r = await roles.kiosk.post('/attendance/checkin/record', { kiosk: '1', person: [`member:${ids.member.b1}`] }, { csrfFrom: '/kiosk' }); await r.text(); assert.ok([200, 302].includes(r.status)); assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE member_id = ?', ids.member.b1) >= 1, true, 'the Kiosk account records attendance as before'); }
  console.log('PASS (crafted requests) name search, mobile-number search, QR lookup, review, record, confirm and First Timer registration are refused for a leader and a Member, write nothing and reveal nothing; the Kiosk account, Church Admin and Super Admin still use all of them');

  // ---- 3. the member photo route -----------------------------------------------------------------------------------------------------------------------------------------------------------------
  { for (const who of ['kiosk', 'church', 'super']) { const r = await roles[who].get(`/media/members/${ids.member.b1}/photo`); const buf = Buffer.from(await r.arrayBuffer()); assert.equal(r.status, 200, `${who} sees a member's photo (the check-in screen shows it)`); assert.ok(buf.slice(0, 4).toString('hex') === '89504e47'); }
    for (const who of ['leader', 'member']) { const r = await roles[who].get(`/media/members/${ids.member.b1}/photo`); const buf = Buffer.from(await r.arrayBuffer()); assert.notEqual(r.status, 200, `${who} is not handed another group's member photo`); assert.ok(!buf.slice(0, 4).equals(png.slice(0, 4)) || r.status !== 200); } }
  console.log('PASS (photos) a leader is no longer handed any member\'s photo through the check-in permission; the operators still see it');

  // ---- 4. navigation, login entry ------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const navOf = async (client) => { const r = await client.get('/attendance'); const b = await r.text(); return { status: r.status, nav: (/<nav class="sidenav"[\s\S]*?<\/nav>/.exec(b) || [''])[0] }; };
    for (const who of ['super', 'church']) { const n = await navOf(roles[who]); assert.equal(n.status, 200); assert.ok(n.nav.includes('href="/kiosk"'), `${who}'s navigation offers the Attendance Kiosk`); }
    const leaderNav = await navOf(roles.leader); assert.ok(!leaderNav.nav.includes('href="/kiosk"'), 'a Cell Group leader is not offered the Attendance Kiosk'); }
  { // the login screen's Attendance Kiosk entry: only operators land on /kiosk
    const signAs = async (email, next) => { const page = await fetch(`${portal.base}/login?next=${encodeURIComponent(next)}`); const html = await page.text(); const csrf = html.match(/name="_csrf" value="([^"]+)"/)[1]; const pre = page.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
      const r = await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ email, password: f.PASSWORD, next, _csrf: csrf }) }); await r.text(); return r.headers.get('location'); };
    assert.equal(await signAs(users.kiosk.email, '/kiosk'), '/kiosk'); assert.equal(await signAs(users.churchAdmin.email, '/kiosk'), '/kiosk'); assert.equal(await signAs(users.superAdmin.email, '/kiosk'), '/kiosk');
    assert.equal(await signAs(users.leaderA.email, '/kiosk'), '/', 'a leader signing in through the Kiosk entry lands on their own home page'); assert.equal(await signAs(users.memberA.email, '/kiosk'), '/'); }
  console.log('PASS (navigation, login) the Attendance Kiosk link and the login screen\'s Kiosk entry take only the Kiosk account, Church Admin and Super Admin to /kiosk');

  // ---- 5. a session does not outlive the role -----------------------------------------------------------------------------------------------------------------------------------------------------
  { const email = 'fx_demoted@fixture.invalid'; await mods.users.createUser({ username: 'fx_demoted', email, password: f.PASSWORD, displayName: 'Demoted', roleKeys: ['church_admin'], mustChangePassword: false });
    const client = await signIn(portal.base, email, f.PASSWORD); const ok = await client.get('/kiosk'); await ok.text(); assert.equal(ok.status, 200);
    const uid = db.prepare('SELECT id FROM users WHERE username = ?').get('fx_demoted').id; db.prepare('DELETE FROM user_roles WHERE user_id = ?').run(uid);
    db.prepare("INSERT INTO user_roles (user_id, role_id, assigned_at) VALUES (?, (SELECT id FROM roles WHERE key = 'cell_group_leader'), ?)").run(uid, new Date().toISOString());
    const after = await client.get('/kiosk'); await after.text(); assert.ok(after.status === 403 || after.status === 302, `a session whose role was removed is refused (${after.status})`); assert.notEqual(after.status, 200); }

  // ---- 6. what did NOT change ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const perms = (role) => db.prepare('SELECT p.key FROM roles r JOIN role_permissions rp ON rp.role_id = r.id JOIN permissions p ON p.id = rp.permission_id WHERE r.key = ? ORDER BY p.key').all(role).map((r) => r.key);
    assert.deepEqual(perms('kiosk'), ['attendance.checkin', 'visitors.express_register'], 'the Kiosk account keeps exactly its two permissions (it did not gain general portal access)');
    assert.ok(perms('cell_group_leader').includes('attendance.record') && perms('cell_group_leader').includes('attendance.checkin'), 'leaders keep the attendance permissions they need for their own group (nothing was removed)');
    const own = await roles.leader.get(`/cell-groups/${ids.groupA}?tab=attendance`); await own.text(); assert.equal(own.status, 200, 'a leader still reaches their own group\'s attendance');
    for (const url of ['/members', '/reports', '/admin/settings', '/projects/ecaq']) { const r = await roles.kiosk.get(url); await r.text(); assert.equal(r.status, 302); assert.equal(r.headers.get('location'), '/kiosk', `the Kiosk account is still confined: ${url}`); } }
  console.log('PASS (unchanged) the Kiosk account keeps its two permissions and its confinement; leaders keep recording their own group\'s attendance');
  {
    // The route audit must see the check-in guard as permission AND role (it once listed every kiosk route as "NO PERMISSION" because it did not know checkinAccess).
    const { spawnSync } = await import('node:child_process');
    const audit = spawnSync(process.execPath, [path.join(process.cwd(), 'tools', 'audit-routes.mjs')], { encoding: 'utf8' });
    assert.equal(audit.status, 0, `the route audit is clean: ${audit.stdout.slice(-400)}`);
    assert.match(audit.stdout, /GET\s+\/kiosk\s+attendance\.record\|attendance\.checkin \+role:kiosk,church_admin,super_admin/, 'the audit shows the kiosk guard as permission plus role');
    assert.doesNotMatch(audit.stdout, /NO PERMISSION/);
    console.log('PASS (route audit) the audit recognises the check-in guard as permission plus role and reports no unguarded route');
  }
  console.log('PASS kiosk-authorization');
} finally {
  await portal.stop();
}
