import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';
import { startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What happens to the headcount of a FINALIZED Friday when a First Timer who attended it is later converted to a member or linked to an existing member.
 *
 * This suite used to CHARACTERIZE the old behaviour (a visit counted only while the First Timer had no member record, so converting or linking silently
 * lowered every past headcount). The owner has since approved the rule it pinned as wrong: a person physically at a service counts once, for ever, whether or
 * not they were a member that day or became one later. The assertions below are therefore changed ON PURPOSE (see docs/FIRST-TIMER-HEADCOUNT-DECISION.md):
 *   - converting or linking moves nobody in or out of a past headcount, on any screen;
 *   - one human counts once (a linked member who ALSO has their own Present row is not counted twice);
 *   - what is deliberately NOT changed: Attendance semantics. The expected roster, Absent, the follow-up streak and the rate are exactly as they were, so a
 *     member linked to a First Timer still shows Absent on the Friday they attended as a First Timer. That mismatch is recorded as a business decision, not guessed.
 * The visits, the stored expected roster and the finalization audit row are untouched by convert or link, as before.
 */

createIsolatedTestEnv('cciq-headcount-characterization-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const visitors = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const outcomes = await import('../services/attendance-outcomes.js');
const { fridayAttendanceOverview } = await import('../services/reports.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const F = addDays(lastFridayOnOrBefore(today()), -14); // the Friday under test, comfortably in the past
const OLD = addDays(F, -300);
const atNoon = (date) => `${date}T09:00:00.000Z`;

function expectedMember(name) {
  const m = createMember({ first_name: name, last_name: 'Hc' }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', atNoon(OLD));
  return m;
}
const m1 = expectedMember('Present'); const m2 = expectedMember('Absentee');
setSetting('attendance.tracking_start_date', F);
db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(F, atNoon(F));
const session = db.prepare('SELECT * FROM attendance_sessions WHERE service_date = ?').get(F);
db.prepare("INSERT INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, 'present', ?, 'manual')").run(session.id, m1.id, atNoon(F));

const v1 = visitors.createVisitor({ first_name: 'Vera', last_name: 'Convert', first_visit_date: F, session_id: session.id }, { userId: null });
const v2 = visitors.createVisitor({ first_name: 'Vic', last_name: 'Link', first_visit_date: F, session_id: session.id }, { userId: null });

const figures = () => attendance.sessionSummary(session.id).tracked;
const overviewVisitors = () => fridayAttendanceOverview({ from: F, to: F }).totalVisitors;
const visitRows = () => db.prepare('SELECT visitor_id, visit_date, session_id FROM visitor_visits WHERE session_id = ? ORDER BY visitor_id').all(session.id);

assert.equal(lifecycle.finalizeAttendance(session.id, { userId: null }).ok, true);
const finalizedAudit = JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.finalized' ORDER BY id DESC LIMIT 1").get().detail);

// ---- before: two First Timers attended -------------------------------------------------------------------------------------------------------------------
const before = figures();
assert.equal(before.firstTimeVisitors, 2, 'two First Timers attended the finalized Friday');
assert.equal(before.present, 1); assert.equal(before.absent, 1, 'M2 is Absent (expected, no record)');
assert.equal(before.headcount, before.present + before.unexpected + before.firstTimeVisitors, 'headcount = present expected + unexpected + First Timers');
assert.equal(before.headcount, 3);
assert.equal(overviewVisitors(), 2);
assert.equal(finalizedAudit.first_time_visitors, 2, 'the finalization audit row recorded 2');
const visitsBefore = visitRows();
assert.equal(visitsBefore.length, 2);

// The same figure as every consumer SCREEN shows it. Each consumer is listed in docs/FIRST-TIMER-HEADCOUNT-DECISION.md; these are the ones a person reads.
const { createUser } = await import('../services/users.js');
await createUser({ username: 'hc_admin', email: 'hc.admin@fixture.invalid', password: 'Hc-Fixture-Passw0rd!x', displayName: 'HC Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const portal = await startPortal();
const admin = await signIn(portal.base, 'hc.admin@fixture.invalid', 'Hc-Fixture-Passw0rd!x');
const page = async (url) => (await (await admin.get(url)).text()).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
const grab = (text, re) => { const m = re.exec(text); return m ? Number(m[1]) : null; };
const shot = async () => ({
  register: grab(await page(`/attendance/sessions/${session.id}`), /headcount (\d+)\)/),                       // "+ N not on the expected list (headcount H)"; absent when N = 0
  overview: grab(await page('/reports/attendance'), /(\d+) First Timers? counted separately/)
});
const shotBefore = await shot();
assert.deepEqual(shotBefore, { register: 3, overview: 2 }, 'BEFORE: the register says headcount 3 and the overview 2 first-time visitors');

// ---- convert one: the headcount of the FINALIZED Friday does not move ------------------------------------------------------------------------------
const converted = visitors.convertToMember(v1.id, { userId: null });
assert.ok(converted.member);
assert.equal(converted.member.date_joined, today(), 'the new member joins today, so is not expected at the past Friday');
const afterConvert = figures();
assert.equal(afterConvert.firstTimeVisitors, 2, 'converting does not remove the person from that Friday\'s count: they were there');
assert.equal(afterConvert.headcount, 3, 'so the finalized Friday\'s headcount is unchanged');
assert.equal(afterConvert.present, before.present, 'no attendance row was created for the new member');
assert.equal(afterConvert.expected, before.expected, 'the stored expected roster is untouched');
assert.equal(overviewVisitors(), 2, 'the Friday overview report follows the same count');
const shotConvert = await shot();
assert.deepEqual(shotConvert, { register: 3, overview: 2 }, 'AFTER CONVERT: every screen shows the same as before');

// ---- link the other to a member who was expected (and shows Absent) -----------------------------------------------------------------------------------
const linked = visitors.linkVisitorToMember(v2.id, m2.id, { userId: null });
assert.equal(linked.ok, true);
const afterLink = figures();
assert.equal(afterLink.firstTimeVisitors, 2, 'linking does not remove them either');
assert.equal(afterLink.headcount, 3, 'the person who actually attended is still in the headcount, once');
assert.equal(afterLink.absent, 1, 'NOT CHANGED (business decision, see the decision paper): the member they were linked to still shows Absent for that Friday although they attended (as a First Timer)');
assert.equal(overviewVisitors(), 2);
const shotLink = await shot();
assert.deepEqual(shotLink, { register: 3, overview: 2 }, 'AFTER LINK: every screen still shows the same');
console.log(`INFO screens for the SAME finalized Friday (headcount line on the register / first-time visitors on the Attendance report): before ${JSON.stringify(shotBefore)}; after converting one ${JSON.stringify(shotConvert)}; after linking the other ${JSON.stringify(shotLink)}`);
await portal.stop();

// ---- what is preserved ---------------------------------------------------------------------------------------------------------------------------------
assert.deepEqual(visitRows(), visitsBefore, 'every visit row is untouched: the evidence of who attended survives, tied to that Friday');
const stored = db.prepare("SELECT detail FROM audit_logs WHERE action = 'attendance.finalized' ORDER BY id DESC LIMIT 1").get().detail;
assert.equal(JSON.parse(stored).first_time_visitors, 2, 'the finalization audit still says 2 (what was true when it was finalized)');
const profileHistory = (await import('../services/visitors.js')).preMembershipHistory(m2.id);
assert.equal(profileHistory.visits.length, 1, 'and the member profile can show the visit under "Before membership"');
assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ?').get(session.id).n, 1, 'Attendance records were never written by convert or link');
assert.equal(db.prepare('SELECT finalization_state FROM attendance_sessions WHERE id = ?').get(session.id).finalization_state, 'finalized', 'the Friday is still finalized, not reopened');
assert.equal(outcomes.expectedRosterForSession(db.prepare('SELECT * FROM attendance_sessions WHERE id = ?').get(session.id)).expected.size, 2, 'the expected roster is still the two who were expected');

console.log('INFO the headcount of a finalized Friday no longer changes when a First Timer is converted or linked. STILL OPEN (business): a member linked to a First Timer is shown Absent for a Friday they attended as a First Timer, and that feeds the follow-up streak.');
console.log('PASS (headcount) converting or linking a First Timer moves nobody in or out of the headcount of any Friday they visited, finalized or not; visits, audit history and the expected roster are untouched; nothing in Attendance was changed');
console.log('ALL PASS');
