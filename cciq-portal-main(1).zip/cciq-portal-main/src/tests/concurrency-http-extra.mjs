import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Bursts of identical and conflicting requests through the real routes, beyond double-submit.mjs (which covers every create form):
 * Friday closing actions (finalize, reopen, correct, "not taken"), money (payments), documents, memberships. For each the outcome must be
 * one the business rules allow, every audit row must match what really changed, and nothing may be left half done. Where the rules do not say what
 * a repeat should mean (an identical second payment), the behaviour is CHARACTERIZED, not changed: the totals must at least equal the sum of
 * what was recorded and every recorded payment must have its audit row.
 */

const f = await buildPortalFixture('cciq-concurrency-http-');
const { db, ids, users, mods } = f;
// the portal reads its settings once, so the tracking start date is set before it starts
mods.setSetting('attendance.tracking_start_date', mods.dates.addDays(ids.friday, -14));
const portal = await startPortal();
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const today = mods.dates.today();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const token = await admin.csrf('/');
const burst = async (url, fields, n = 5, who = admin) => Promise.all(Array.from({ length: n }, () => who.post(url, fields, { csrf: token }).then(async (r) => { const text = await r.text(); return { status: r.status, location: r.headers.get('location'), text }; })));
const noServerError = (results, label) => assert.ok(results.every((r) => r.status < 500), `${label}: no server error (${results.map((r) => r.status)})`);
const audits = (action) => count('SELECT COUNT(*) n FROM audit_logs WHERE action = ?', action);

try {
  const session = ids.session;
  // a few members with a plainly-expected history, one already present
  // every member has a plainly established history (otherwise finalization correctly refuses: some Friday status could not be established)
  for (const { id, status } of db.prepare('SELECT id, status FROM members').all()) {
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(id);
    db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run('2020-01-01T09:00:00.000Z', '2020-01-01', id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(id, status, 'planted', '2020-01-01T09:00:00.000Z');
  }
  db.prepare("INSERT INTO attendance_records (session_id, member_id, status, source, recorded_at) VALUES (?, ?, 'present', 'manual', ?)").run(session, ids.member.a2, '2026-01-01T09:00:00.000Z');

  // ---- finalize x5 -----------------------------------------------------------------------------------------------------------------------
  let r = await burst(`/attendance/sessions/${session}/finalize`, { confirm_no_attendance: 'on' });
  noServerError(r, 'finalize');
  assert.equal(audits('attendance.finalized'), 1, 'five finalizations make one');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', session) > 0, true);
  const snapshot = count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', session);
  assert.equal(db.prepare('SELECT finalization_state s FROM attendance_sessions WHERE id = ?').get(session).s, 'finalized');

  // ---- correct x4 (identical) ------------------------------------------------------------------------------------------------------------
  r = await burst(`/attendance/sessions/${session}/corrections`, { [`to_${ids.member.a1}`]: 'present', reason: 'was here' }, 4);
  noServerError(r, 'correct');
  assert.equal(audits('attendance.corrected'), 1, 'four identical corrections change one person once and audit once');
  assert.equal(count('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND member_id = ?', session, ids.member.a1), 1);
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', session), snapshot, 'the expected list is untouched by corrections');

  // ---- reopen x5, then not-taken and finalize racing ------------------------------------------------------------------------------------------
  r = await burst(`/attendance/sessions/${session}/reopen`, { reason: 'check again' });
  noServerError(r, 'reopen');
  assert.equal(audits('attendance.reopened'), 1, 'five reopenings make one');
  assert.equal(db.prepare('SELECT finalization_state s FROM attendance_sessions WHERE id = ?').get(session).s, null);
  assert.equal(count('SELECT COUNT(*) n FROM attendance_expected WHERE session_id = ?', session), snapshot, 'reopening keeps the expected list');
  const mixed = await Promise.all([
    ...Array.from({ length: 3 }, () => admin.post(`/attendance/sessions/${session}/finalize`, { confirm_no_attendance: 'on' }, { csrf: token })),
    ...Array.from({ length: 3 }, () => admin.post(`/attendance/sessions/${session}/not-taken`, { note: 'lost the sheet', confirm_existing: 'on' }, { csrf: token }))
  ].map((p) => p.then(async (x) => { await x.text(); return x.status; })));
  assert.ok(mixed.every((s) => s < 500), `finalize and not-taken racing: ${mixed}`);
  const state = db.prepare('SELECT finalization_state s FROM attendance_sessions WHERE id = ?').get(session).s;
  assert.ok(['finalized', 'not_taken'].includes(state));
  assert.equal(audits('attendance.finalized') + audits('attendance.not_taken'), 2, 'exactly one more closing action than before (the first finalization plus this round\'s winner), never both');

  // ---- payments ------------------------------------------------------------------------------------------------------------------------------
  const dates = mods.ecaq.boardDates(Number(today.slice(0, 4)));
  const claim = mods.ecaq.createClaim({ campaignId: ids.board, date: dates[7], memberId: ids.member.a3, commitmentAmount: 100, userId: users.churchAdmin.id }).claim.id;
  const superAdmin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const stoken = await superAdmin.csrf('/');
  const pay = await Promise.all(Array.from({ length: 4 }, () => superAdmin.post(`/admin/ecaq/claims/${claim}/payments`, { amount: '10', paid_on: today, method: 'cash' }, { csrf: stoken }).then(async (x) => { await x.text(); return x.status; })));
  assert.ok(pay.every((s) => s < 500), `payments: ${pay}`);
  const recorded = count('SELECT COUNT(*) n FROM ecaq_payments WHERE claim_id = ?', claim);
  const sum = db.prepare('SELECT SUM(amount) s FROM ecaq_payments WHERE claim_id = ?').get(claim).s;
  assert.equal(db.prepare('SELECT amount_collected a FROM ecaq_giving_board_claims WHERE id = ?').get(claim).a, sum, 'the claim\'s total is exactly the sum of its payments, however they arrived');
  assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'giving.payment_recorded' AND entity_id = ?", String(claim)), recorded, 'every payment on file has its audit row and every audit row has its payment');
  console.log(`INFO characterization: four identical payment posts in a burst recorded ${recorded} payment(s). Whether an identical second payment within seconds should be treated as a repeat is a rule the owner has not set (the browser disables the button on submit; a server-side repeat is not collapsed).`);

  // ---- documents -----------------------------------------------------------------------------------------------------------------------------
  mods.documents.ensureCategories();
  const category = mods.documents.listCategories()[0].id;
  const pdf = { name: 'burst.pdf', type: 'application/pdf', buffer: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(400, 32)]) };
  const docsBefore = count('SELECT COUNT(*) n FROM documents');
  const ups = await Promise.all(Array.from({ length: 4 }, () => admin.upload('/documents', pdf, { field: 'file', fields: { title: 'Burst document', category_id: String(category) }, csrf: token }).then(async (x) => { await x.text(); return x.status; })));
  assert.ok(ups.every((s) => s < 500), `uploads: ${ups}`);
  const docs = db.prepare("SELECT stored_path FROM documents WHERE title = 'Burst document'").all();
  const env = (await import('../config/env.js')).default;
  assert.ok(ups.filter((s) => s === 302).length >= 1, `at least one upload was accepted (${ups})`);
  assert.equal(docs.length, ups.filter((s) => s === 302).length, 'one document row for every upload that was accepted');
  for (const d of docs) assert.ok(fs.existsSync(path.join(env.storageDir, d.stored_path)), 'and each row has its file');
  const onDisk = fs.readdirSync(path.join(env.storageDir, path.dirname(docs[0]?.stored_path || 'documents/x'))).filter((n) => !docs.some((d) => d.stored_path.endsWith(n)) && /burst|\.pdf$/.test(n));
  assert.ok(count('SELECT COUNT(*) n FROM documents') - docsBefore === docs.length);
  void onDisk;

  // ---- memberships ----------------------------------------------------------------------------------------------------------------------------
  const mix = await Promise.all([
    ...Array.from({ length: 4 }, () => admin.post(`/cell-groups/${ids.groupA}/members`, { member_id: String(ids.member.free) }, { csrf: token })),
    ...Array.from({ length: 4 }, () => admin.post(`/cell-groups/${ids.groupA}/members/${ids.member.free}/remove`, {}, { csrf: token }))
  ].map((p) => p.then(async (x) => { await x.text(); return x.status; })));
  assert.ok(mix.every((s) => s < 500), `cell group add/remove racing: ${mix}`);
  assert.ok(count("SELECT COUNT(*) n FROM cell_group_members WHERE member_id = ? AND left_at IS NULL", ids.member.free) <= 1, 'never two current memberships');
  assert.equal(count('SELECT COUNT(*) n FROM members WHERE id = ? AND cell_group_id IS NOT NULL', ids.member.free) <= 1, true);
  const current = db.prepare('SELECT cell_group_id FROM members WHERE id = ?').get(ids.member.free).cell_group_id;
  assert.equal(count('SELECT COUNT(*) n FROM cell_group_members WHERE member_id = ? AND left_at IS NULL', ids.member.free), current ? 1 : 0, 'the member\'s current group agrees with the membership rows');
  const fam = await Promise.all([
    ...Array.from({ length: 3 }, () => admin.post(`/family-groups/${ids.family}/members`, { member_id: String(ids.member.b2) }, { csrf: token })),
    ...Array.from({ length: 3 }, () => admin.post('/family-groups', { name: 'Race Family', first_member_id: String(ids.member.b2) }, { csrf: token }))
  ].map((p) => p.then(async (x) => { await x.text(); return x.status; })));
  assert.ok(fam.every((s) => s < 500), `family racing: ${fam}`);
  assert.equal(count('SELECT COUNT(*) n FROM family_group_members WHERE member_id = ?', ids.member.b2), 1, 'a member is in at most one family, whichever request won');

  // ---- nothing is half done ------------------------------------------------------------------------------------------------------------------
  const { checkInvariants } = await import('../lib/db-invariants.js');
  assert.deepEqual(checkInvariants(db).findings.filter((x) => x.severity === 'error' && !/^user\.no_active_super_admin$/.test(x.code)), [], 'every integrity rule still holds');
  assert.deepEqual(db.pragma('foreign_key_check'), []);
  console.log('PASS (http concurrency) finalize, correct, reopen, not-taken, payments, uploads, cell and family memberships under bursts and conflicts: one audit row per real change, totals equal their parts, files match rows, memberships stay single, every rule holds');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
