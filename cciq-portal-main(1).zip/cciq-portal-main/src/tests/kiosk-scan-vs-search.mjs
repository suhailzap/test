import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The Attendance Kiosk has two ways in: a QR scanner (a keyboard that types the code very fast and presses Enter) and a manual name/mobile search. UAT found that a stale value left in the
 * manual search box could spoil a scan: when focus was still in that box, the scanner typed the code INTO it after the stale text and Enter submitted a NAME SEARCH for "stale text + code":
 * a confusing result and no QR lookup at all. (The server was never the problem: a lookup posts only the code.)
 *
 * A scan is authoritative: a burst of fast keystrokes is a scan wherever focus happens to be, the manual box is taken back to what it held, and the lookup carries only the scanned code.
 *   - blank manual box; stale text with focus on the scan field; stale text with focus IN the manual box; focus on the Search button; focus on the page itself;
 *   - the stale text (even another member's name) can never change who a code resolves to, and is not sent with the lookup;
 *   - manual search still works on purpose (typed at human speed, pasted/filled, or by pressing Search), independently of any scan;
 *   - already-checked-in people are still recognised; an unknown code is still refused; authorization is unchanged (the lookup still needs the check-in guard).
 * The same screen script serves the administrator's Scan page, which is checked too.
 */

const f = await buildPortalFixture('cciq-kiosk-scan-search-');
const { db, ids, users, mods } = f;
const qr = await import(new URL('../services/qr-checkin.js', import.meta.url));
const sessionId = ids.session;
const { a1, a2, a3 } = ids.member; // Alice LeaderA, Anna MemberA, Andre OtherA
const tokens = { a1: qr.ensureQrToken(a1), a2: qr.ensureQrToken(a2), a3: qr.ensureQrToken(a3) };
const recorded = (memberId) => db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id = ? AND member_id = ?').get(sessionId, memberId).n;

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const lookups = [];
async function open(account, url = '/kiosk') {
  const session = await signIn(portal.base, account.email, f.PASSWORD);
  const context = await browser.newContext();
  if (process.env.CCIQ_TEST_FAKE_DATE) await context.clock.install({ time: new Date(`${process.env.CCIQ_TEST_FAKE_DATE}T09:00:00Z`) });
  await context.addCookies(session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
  const page = await context.newPage();
  page.on('request', (r) => { if (r.url().endsWith('/attendance/checkin/lookup')) lookups.push(decodeURIComponent((r.postData() || '').split('&token=')[1] || '')); });
  page.on('request', (r) => { if (r.url().endsWith('/attendance/checkin/search') && r.method() === 'POST') lookups.push(`SEARCH:${decodeURIComponent((r.postData() || '').match(/(?:^|&)q=([^&]*)/)?.[1] || '').replace(/\+/g, ' ')}`); });
  await page.goto(`${portal.base}${url}`, { waitUntil: 'load' });
  return page;
}
const scan = async (page, code) => { await page.keyboard.type(code, { delay: 1 }); await page.keyboard.press('Enter'); }; // what a USB scanner does
const stale = async (page, text) => { await page.click('#checkin-search-input'); await page.keyboard.type(text, { delay: 120 }); await page.waitForTimeout(350); }; // a person typed it, a while ago
const visible = async (page, id) => page.locator(`#${id}`).isVisible();
const name = async (page) => (await page.textContent('#checkin-name')).trim();
const mainText = async (page) => (await page.textContent('main')).replace(/\s+/g, ' ');
const resetKiosk = async (page) => { await page.goto(`${portal.base}${new URL(page.url()).pathname === '/attendance/checkin/search' ? '/kiosk' : new URL(page.url()).pathname}`, { waitUntil: 'load' }); lookups.length = 0; };

try {
  const kiosk = await open(users.kiosk);

  { // 1. blank manual box
    assert.equal(await kiosk.inputValue('#checkin-search-input'), '', 'the manual box starts blank');
    await scan(kiosk, tokens.a1);
    await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)');
    assert.equal(await name(kiosk), 'Alice LeaderA'); assert.deepEqual(lookups, [tokens.a1]);
    await kiosk.click('#checkin-confirm'); await kiosk.waitForSelector('#checkin-success-view:not(.is-hidden)');
    assert.equal(recorded(a1), 1, 'confirming records her attendance once');
    console.log('PASS (1) a scan with the manual box blank resolves to the member and records one attendance row');
  }

  { // 2. stale text, focus on the scan field
    await resetKiosk(kiosk);
    await kiosk.fill('#checkin-search-input', 'Anna');            // stale text left in the manual box
    await kiosk.focus('#checkin-input');
    await scan(kiosk, tokens.a3);
    await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)');
    assert.equal(await name(kiosk), 'Andre OtherA', 'the code decides, not the text in the other box'); assert.deepEqual(lookups, [tokens.a3], 'only the scanned code was sent');
    assert.equal(await kiosk.inputValue('#checkin-search-input'), '', 'the stale text is cleared once a scan is made');
    console.log('PASS (2) stale manual text with focus on the scan field: the code alone decides who it is, and the stale text is cleared');
  }

  { // 3. THE DEFECT: stale text and focus still IN the manual box when the scanner types
    await resetKiosk(kiosk);
    await stale(kiosk, 'Anna');
    assert.equal(await kiosk.inputValue('#checkin-search-input'), 'Anna');
    await scan(kiosk, tokens.a3);
    await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)');
    assert.equal(await name(kiosk), 'Andre OtherA', 'a stale name cannot change who the code resolves to (not Anna, not nobody)');
    assert.deepEqual(lookups, [tokens.a3], 'the lookup carried exactly the code: no "Anna" in front of it, and no name search was made');
    assert.equal(new URL(kiosk.url()).pathname, '/kiosk', 'the page did not navigate to a search result');
    assert.equal(await kiosk.inputValue('#checkin-search-input'), '');
    // the same with a long stale value and with the stale text being the code's own first letters
    await resetKiosk(kiosk); await stale(kiosk, tokens.a3.slice(0, 3)); await scan(kiosk, tokens.a3);
    await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)'); assert.equal(await name(kiosk), 'Andre OtherA'); assert.deepEqual(lookups, [tokens.a3]);
    console.log('PASS (3) stale text with focus IN the manual box: the scanner burst is taken out of that box, the code alone is looked up, nothing navigates, the right person appears');
  }

  { // 4. focus on the Search button, and on the page itself
    await resetKiosk(kiosk); await kiosk.fill('#checkin-search-input', 'Anna');
    await kiosk.focus('.kiosk__search-form button[type=submit]');
    await scan(kiosk, tokens.a3);
    await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)');
    assert.equal(await name(kiosk), 'Andre OtherA'); assert.deepEqual(lookups, [tokens.a3], "the scanner's Enter did not press the Search button");
    await resetKiosk(kiosk); await kiosk.evaluate(() => document.activeElement && document.activeElement.blur());
    await scan(kiosk, tokens.a3); await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)'); assert.equal(await name(kiosk), 'Andre OtherA');
    console.log('PASS (4) focus on the Search button or nowhere: the scan still reaches the scan field, and its Enter does not press Search');
  }

  { // 5. an unknown code and an already-checked-in member
    await resetKiosk(kiosk); await stale(kiosk, 'Anna'); await scan(kiosk, 'THIS-IS-NOT-A-REAL-QR-CODE-000000');
    await kiosk.waitForSelector('#checkin-error:not(.is-hidden)'); assert.match(await kiosk.textContent('#checkin-error'), /does not match any member/); assert.equal(await visible(kiosk, 'checkin-confirm-view'), false, 'an unknown code is refused, whatever was in the other box');
    assert.deepEqual(lookups, ['THIS-IS-NOT-A-REAL-QR-CODE-000000']);
    await resetKiosk(kiosk); await stale(kiosk, 'Andre'); await scan(kiosk, tokens.a1);   // Alice was checked in under (1)
    await kiosk.waitForSelector('#checkin-success-view:not(.is-hidden)');
    assert.match(await kiosk.textContent('#checkin-success-message'), /Alice LeaderA is already checked in/); assert.equal(await visible(kiosk, 'checkin-confirm-view'), false, 'no Confirm for someone already in');
    assert.equal(recorded(a1), 1, 'and no second row');
    console.log('PASS (5) an unknown code is still refused and an already-checked-in member is still recognised, with stale text in the manual box');
  }

  { // 6. manual search still works, independently
    await resetKiosk(kiosk);
    await kiosk.click('#checkin-search-input'); await kiosk.keyboard.type('Anna', { delay: 150 });       // a person typing
    assert.equal(await kiosk.inputValue('#checkin-search-input'), 'Anna', 'human-speed typing is not mistaken for a scan');
    await Promise.all([kiosk.waitForNavigation({ waitUntil: 'load' }), kiosk.click('.kiosk__search-form button[type=submit]')]);
    assert.match(await mainText(kiosk), /Anna MemberA/, 'pressing Search finds her'); assert.deepEqual(lookups, ['SEARCH:Anna'], 'a name search, not a code lookup');
    assert.equal(await kiosk.inputValue('#checkin-search-input'), 'Anna', 'the term stays so the person can see what was searched');
    await kiosk.fill('#checkin-search-input', 'Alice');                                                  // fill / paste
    await Promise.all([kiosk.waitForNavigation({ waitUntil: 'load' }), kiosk.keyboard.press('Enter')]);
    assert.match(await mainText(kiosk), /Alice LeaderA/, 'Enter in the manual box (a person pressing it) searches too');
    // and a scan right after a manual search is unaffected by that search
    await kiosk.focus('#checkin-input'); await scan(kiosk, tokens.a3); await kiosk.waitForSelector('#checkin-confirm-view:not(.is-hidden)'); assert.equal(await name(kiosk), 'Andre OtherA', 'the earlier search for Alice has no say in who the code is');
    console.log('PASS (6) manual search works on purpose (typed at human speed, filled, Search, Enter) and a scan straight after it is independent');
  }

  { // 7. authorization and validation are unchanged
    const csrf = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
    const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
    const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
    for (const [who, client] of [['member', member], ['leader', leader]]) { const r = await client.post('/attendance/checkin/lookup', { token: tokens.a1 }, { csrfFrom: '/account/password' }); assert.equal(r.status, 403, `${who} cannot look a code up`); }
    const ok = await csrf.post('/attendance/checkin/lookup', { token: tokens.a1 }, { csrfFrom: '/kiosk' }); assert.equal(ok.status, 200);
    const stalePrefix = await csrf.post('/attendance/checkin/lookup', { token: `Anna${tokens.a1}` }, { csrfFrom: '/kiosk' }); assert.equal(stalePrefix.status, 404, 'a code with anything in front of it is not a code');
    console.log('PASS (7) the lookup still needs the check-in guard (a Member and a leader are refused) and a code with text in front of it is not accepted');
  }

  { // 8. the administrator's Scan page runs the same script
    const admin = await open(users.churchAdmin, '/attendance/checkin');
    await admin.click('#checkin-search-input'); await admin.keyboard.type('Anna', { delay: 120 }); await admin.waitForTimeout(350);
    lookups.length = 0; await scan(admin, tokens.a3);
    await admin.waitForSelector('#checkin-confirm-view:not(.is-hidden)'); assert.equal(await name(admin), 'Andre OtherA'); assert.deepEqual(lookups, [tokens.a3]);
    console.log('PASS (8) the same holds on the administrator\'s Scan page');
  }
} finally {
  await browser.close();
  await portal.stop();
}
void mods;
f.db.close();
f.env.cleanup();
console.log('PASS kiosk-scan-vs-search');
