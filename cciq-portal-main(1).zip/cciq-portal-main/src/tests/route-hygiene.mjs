import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { catalogue } from './lib/route-catalogue.mjs';

/*
 * Static rules over src/routes that a new route must keep. Cheap, and they catch the class of mistake the dynamic suites
 * only find after it has shipped:
 *   1. an async handler must be wrapped (Express 4 ignores its promise; a throw would end the whole process);
 *   2. every state-changing route needs a signed-in user, except sign-in itself;
 *   3. every route that reads a multipart body verifies the CSRF token itself (the global check runs before the body exists);
 *   4. nothing sends an error stack or raw exception text to the browser;
 *   5. SQL built in the routes uses bound parameters (no template-literal values);
 *   6. files are sent with streamFile(), never a bare createReadStream().pipe(res) (an unhandled stream error ends the process).
 */

const routesDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'routes');
const routes = catalogue();

// 1. async handlers
for (const file of fs.readdirSync(routesDir).filter((f) => f.endsWith('.js'))) {
  const source = fs.readFileSync(path.join(routesDir, file), 'utf8');
  const wrapped = [...source.matchAll(/asyncRoute\(\s*async\s*\(/g)].length;
  const total = [...source.matchAll(/async\s*\(\s*(?:req|_req)\b/g)].length;
  assert.equal(wrapped, total, `${file}: every async route handler is wrapped in asyncRoute() (${total - wrapped} are not)`);
}
console.log('PASS (async) every async route handler is wrapped so a failure reaches the error page instead of ending the process');

// 2. state-changing routes need a session
const PUBLIC_MUTATIONS = new Set(['POST /login']);
const open = routes.filter((r) => r.method !== 'GET' && !r.requiresAuth && !r.requiresGuest && !PUBLIC_MUTATIONS.has(`${r.method} ${r.path}`));
assert.deepEqual(open.map((r) => `${r.method} ${r.path}`), [], 'every POST route requires a signed-in user');
console.log(`PASS (session) all ${routes.filter((r) => r.method !== 'GET').length} state-changing routes require a signed-in user (sign-in excepted)`);

// 3. multipart routes verify CSRF themselves
const uploads = routes.filter((r) => r.method === 'POST' && /[uU]pload\w*\(\s*req/.test(r.body));
assert.ok(uploads.length >= 8, 'the upload routes were found');
assert.deepEqual(uploads.filter((r) => !/verifyCsrf\(req\)/.test(r.body)).map((r) => r.path), [], 'every upload route verifies CSRF after parsing the body');
console.log(`PASS (uploads) all ${uploads.length} upload routes verify the CSRF token after parsing the multipart body`);

// 4. no stack or raw exception text to the browser
for (const r of routes) {
  assert.doesNotMatch(r.body, /res\.(send|json|end)\([^)]*(err(or)?\.stack|\.stack\b)/, `${r.method} ${r.path} must not send an error stack`);
  assert.doesNotMatch(r.body, /res\.(send|end)\(\s*(err|error|e)\s*\)/, `${r.method} ${r.path} must not send a raw exception`);
}
console.log('PASS (errors) no route sends an error stack or a raw exception to the browser');

// 5. SQL in routes is parameterised
const interpolated = [];
for (const r of routes) {
  for (const m of r.body.matchAll(/\b(?:query|queryOne|execute)\(\s*`([^`]*)`/g)) {
    if (/\$\{[^}]*(req\.|params|body|query)/.test(m[1])) interpolated.push(`${r.method} ${r.path}`);
  }
}
assert.deepEqual(interpolated, [], 'no route interpolates request values into SQL');
console.log('PASS (sql) no route interpolates request values into SQL text');

// 6. no bare stream pipes
for (const r of routes) {
  assert.doesNotMatch(r.body, /createReadStream\([^)]*\)\.pipe\(/, `${r.method} ${r.path} must send files with streamFile()`);
}
console.log('PASS (streams) no route pipes a file stream straight into the response');

// 7. every permission a guard, a template or a can() call names really exists. A misspelt or retired key is not a harmless typo: in a
// template it silently hides a control from everyone (the dashboard once offered "Add a visitor" behind visitors.manage, which never
// existed); in a guard it locks the route to nobody.
{
  const { PERMISSIONS } = await import('../lib/permissions.js');
  const known = new Set(PERMISSIONS.map((p) => (Array.isArray(p) ? p[0] : p.key)));
  const srcDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
  const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? (e.name === 'tests' ? [] : walk(path.join(dir, e.name))) : [path.join(dir, e.name)]));
  const unknown = [];
  for (const file of walk(srcDir).filter((x) => /\.(js|ejs)$/.test(x))) {
    const text = fs.readFileSync(file, 'utf8');
    const calls = [...text.matchAll(/(?:requirePermission|requireAnyPermission|\.can|\.canAny)\(([^)]*)\)/g)];
    for (const call of calls) for (const key of [...call[1].matchAll(/['"`]([a-z_]+\.[a-z_.]+)['"`]/g)].map((x) => x[1])) {
      if (!known.has(key)) unknown.push(`${path.relative(srcDir, file)}: ${key}`);
    }
  }
  assert.deepEqual(unknown, [], 'every permission named in a guard, template or can() call is a defined permission');
  console.log(`PASS (permissions) every permission key named in a route guard, template or can() call is defined (${known.size} known)`);
}
console.log('ALL PASS');
