import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal } from './lib/portal-fixture.mjs';

const f = await buildPortalFixture('cciq-quick-public-');
const portal = await startPortal();
let browser;
try {
  const expected = 'https://portal.cciqonline.com';
  for (const headers of [{}, { Host: 'attacker.example:3000', 'X-Forwarded-Host': '192.168.1.5:3000', 'X-Forwarded-Proto': 'http' }]) {
    const response = await fetch(portal.base + '/quick-access/info', { headers });
    assert.equal(response.status, 200);
    const data = await response.json();
    assert.equal(data.url, expected);
    assert.equal(data.ambiguous, false);
    assert.equal(new URL(data.url).search, '');
  }
  const card = await fetch(portal.base + '/quick-access/card.png');
  assert.equal(card.status, 200);
  assert.match(card.headers.get('content-type'), /image\/png/);
  assert.equal(card.headers.get('cache-control'), 'no-store');
  const bytes = Buffer.from(await card.arrayBuffer());
  assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await browser.newPage();
  await page.goto(portal.base + '/login');
  await page.click('[data-quick-access-open]');
  await page.waitForSelector('#quick-access-content .quick-access__url');
  assert.equal(await page.textContent('#quick-access-content .quick-access__url'), expected);
  const dialog = await page.textContent('#quick-access-dialog');
  assert.doesNotMatch(dialog, /same Wi-Fi|today only|church Wi-Fi|More than one network/i);
  assert.match(dialog, /mobile data/);
  const restricted = await fetch(portal.base + '/kiosk', { redirect: 'manual' });
  assert.equal(restricted.status, 302);
  assert.match(restricted.headers.get('location'), /login/);
  await page.goto(portal.base + '/login?next=%2Fkiosk');
  await page.fill('#email', 'fx_kiosk');
  await page.fill('#password', f.PASSWORD);
  await Promise.all([page.waitForURL('**/kiosk'), page.click('button[type="submit"]')]);
  await page.waitForSelector('#lobby-quick-access-content .quick-access__url');
  assert.equal(await page.textContent('#lobby-quick-access-content .quick-access__url'), expected);
  assert.doesNotMatch(await page.textContent('.kiosk__lobby'), /same Wi-Fi|today only/i);
  await page.click('#lobby-quick-access-content button');
  await page.waitForSelector('#lobby-quick-access-content .quick-access__url');
  assert.equal(await page.textContent('#lobby-quick-access-content .quick-access__url'), expected);
  console.log('PASS public canonical URL, hostile headers, PNG signature, login dialog, anonymous kiosk protection, authenticated kiosk panel and refresh');
} finally {
  await browser?.close();
  await portal.stop();
  f.db.close();
  f.env.cleanup();
}
