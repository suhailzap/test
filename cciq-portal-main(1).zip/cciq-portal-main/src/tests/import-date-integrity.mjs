import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Dates in an uploaded spreadsheet. A date cell is a serial number plus a display format, and two things used to go wrong:
 *   1. the cell was read from its DISPLAY text: a month-first "5/6/24" (a common default) was then read day-first as 5 June, not 6 May;
 *   2. the spreadsheet library hands dates over as JavaScript Dates built in the computer's local time zone (and seconds off), so on a Qatar
 *      computer a date came out as the day BEFORE.
 * A date cell is now read from the serial number itself, so the result is the date the spreadsheet holds - whatever it is displayed as and
 * whatever time zone the computer is in. Text a person typed is still read the way the church writes dates (day first).
 */

createIsolatedTestEnv('cciq-import-dates-');
const { default: XLSX } = await import('xlsx');
const { readWorkbook, parseDate, isoFromSerial, detectDateColumns } = await import('../services/imports.js');

const SERIAL = { '2024-05-06': 45418, '2024-05-03': 45415, '2026-12-25': 46381, '2026-01-02': 46024, '2020-02-29': 43890, '2000-03-01': 36586 };
const workbook = (cells, ref) => XLSX.write({ SheetNames: ['S'], Sheets: { S: { ...cells, '!ref': ref } } }, { type: 'buffer', bookType: 'xlsx' });

// ---- 1. the serial arithmetic ------------------------------------------------------------------------------------------------------------------------
for (const [iso, serial] of Object.entries(SERIAL)) assert.equal(isoFromSerial(serial), iso, `serial ${serial} is ${iso}`);
assert.equal(isoFromSerial(45418.75), '2024-05-06', 'a time of day does not move the date');
assert.equal(parseDate('45418'), '2024-05-06', 'a bare serial typed as text still parses');

// ---- 2. every display format of the same date reads as the same date -----------------------------------------------------------------------------
const FORMATS = ['yyyy-mm-dd', 'm/d/yy', 'm/d/yyyy', 'mm-dd-yy', 'dd/mm/yyyy', 'd-mmm-yy', 'd mmmm yyyy', 'dddd, mmmm d, yyyy', 'mmm d', 'yy/mm/dd'];
const probe = () => {
  const out = {};
  for (const z of FORMATS) {
    for (const [iso, serial] of Object.entries(SERIAL)) {
      const buffer = workbook({ A1: { t: 's', v: 'Name' }, B1: { t: 's', v: 'Joined' }, A2: { t: 's', v: 'X' }, B2: { t: 'n', v: serial, z } }, 'A1:B2');
      const [sheet] = readWorkbook(buffer, 'a.xlsx').sheets;
      out[`${z}|${iso}`] = parseDate(sheet.rows[0][1]);
    }
  }
  return out;
};
const here = probe();
for (const z of FORMATS) for (const iso of Object.keys(SERIAL)) assert.equal(here[`${z}|${iso}`], iso, `a cell showing ${iso} as "${z}" is read as ${iso}, not another date`);
console.log(`PASS (1,2) ${FORMATS.length} display formats x ${Object.keys(SERIAL).length} dates read as exactly the date in the spreadsheet`);

// ---- 3. the same answer in any time zone (the computer's, not the church's) --------------------------------------------------------------------------
{
  const script = `
    process.env.NODE_ENV = 'test';
    const { default: XLSX } = await import('xlsx');
    const { readWorkbook, parseDate } = await import(${JSON.stringify(new URL('../services/imports.js', import.meta.url).href)});
    const serials = ${JSON.stringify(SERIAL)}; const formats = ${JSON.stringify(FORMATS)}; const out = {};
    for (const z of formats) for (const [iso, serial] of Object.entries(serials)) {
      const buf = XLSX.write({ SheetNames: ['S'], Sheets: { S: { A1: { t: 's', v: 'Name' }, B1: { t: 's', v: 'Joined' }, A2: { t: 's', v: 'X' }, B2: { t: 'n', v: serial, z }, '!ref': 'A1:B2' } } }, { type: 'buffer', bookType: 'xlsx' });
      out[z + '|' + iso] = parseDate(readWorkbook(buf, 'a.xlsx').sheets[0].rows[0][1]);
    }
    console.log(JSON.stringify(out));`;
  for (const tz of ['Asia/Qatar', 'UTC', 'America/Los_Angeles', 'Pacific/Auckland', 'Asia/Kolkata']) {
    const run = spawnSync(process.execPath, ['--input-type=module', '-e', script], { encoding: 'utf8', env: { ...process.env, TZ: tz }, cwd: fileURLToPath(new URL('../../', import.meta.url)) });
    assert.equal(run.status, 0, `${tz}: ${run.stderr.slice(0, 200)}`);
    assert.deepEqual(JSON.parse(run.stdout.trim().split('\n').pop()), here, `${tz}: every date reads identically`);
  }
  console.log('PASS (3) the results are identical when the computer is set to Qatar, UTC, Los Angeles, Auckland or India');
}

// ---- 4. an attendance register: Friday header dates in a month-first format ---------------------------------------------------------------------------
{
  const fridays = ['2024-05-03', '2026-01-02'];
  const cells = { A1: { t: 's', v: 'Name' } };
  fridays.forEach((d, i) => { cells[XLSX.utils.encode_cell({ r: 0, c: i + 1 })] = { t: 'n', v: SERIAL[d], z: 'm/d/yy' }; });
  cells.A2 = { t: 's', v: 'Ann Member' }; cells.B2 = { t: 's', v: 'P' }; cells.C2 = { t: 's', v: 'P' };
  const [sheet] = readWorkbook(workbook(cells, 'A1:C2'), 'reg.xlsx').sheets;
  assert.deepEqual(detectDateColumns(sheet.headers).map((c) => c.date), fridays, 'the Friday columns of a register whose header dates are shown month-first are the real Fridays');
  console.log('PASS (4) month-first Friday headers in an attendance register are read as the real Fridays (they used to land on other days, e.g. 5 March for 3 May)');
}

// ---- 5. what is NOT a date stays untouched ---------------------------------------------------------------------------------------------------------------
{
  const buffer = workbook({
    A1: { t: 's', v: 'Name' }, B1: { t: 's', v: 'Phone' }, C1: { t: 's', v: 'Note' }, D1: { t: 's', v: 'Amount' }, E1: { t: 's', v: 'Typed date' },
    A2: { t: 's', v: 'Ann' }, B2: { t: 'n', v: 97455551234, z: '0' }, C2: { t: 's', v: '5/6/24' }, D2: { t: 'n', v: 12.5, z: '0.00' }, E2: { t: 's', v: '6/5/2024' },
    A3: { t: 's', v: 'Bob' }, B3: { t: 'n', v: 0.5, z: 'h:mm' }, C3: { t: 's', v: '' }, D3: { t: 'n', v: 3, z: 'General' }, E3: { t: 's', v: '13/05/2024' }
  }, 'A1:E3');
  const [sheet] = readWorkbook(buffer, 'x.xlsx').sheets;
  assert.deepEqual(sheet.rows[0].slice(0, 4), ['Ann', '97455551234', '5/6/24', '12.50'], 'numbers, phone digits and text cells are left exactly as displayed');
  assert.equal(parseDate(sheet.rows[0][4]), '2024-05-06', 'a typed 6/5/2024 is still read day-first, as the church writes it');
  assert.equal(parseDate(sheet.rows[1][4]), '2024-05-13', 'and an unambiguous typed date is read as written');
  assert.equal(sheet.rows[1][1], '12:00', 'a time of day is shown as a time, not turned into a date');
  console.log('PASS (5) phone numbers, amounts, typed text and times of day are unchanged; typed dates keep the day-first convention');
}
console.log('ALL PASS');
