import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

/*
 * Static rules for everything the browser is sent, and for what the portal depends on, so they hold as the code grows:
 *   A. Content-Security-Policy: no inline event handlers, no inline style attributes or <style> blocks, no javascript: URLs, no
 *      inline script that would run (only data blocks), no external origin in a template, stylesheet or script.
 *   B. Front-end JavaScript: it parses, is strict, has no eval / document.write / debugger / alert / console noise, builds HTML only
 *      from fixed strings (or the one server-rendered fragment), guards web storage, and gives every fetch a failure path.
 *   C. Offline dependencies: the portal needs no network at run time - every declared dependency is installed at the locked
 *      version, every locked package has an integrity hash, and no package, script or stylesheet reaches for a CDN.
 */

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const walk = (dir, ext) => fs.readdirSync(path.join(root, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name), ext) : e.name.endsWith(ext) ? [path.join(dir, e.name)] : []));

// ---- A. CSP ---------------------------------------------------------------------------------------------------------------------------
const views = walk('src/views', '.ejs');
const offenders = { handler: [], styleAttr: [], styleTag: [], jsUrl: [], inlineScript: [], external: [] };
for (const file of views) {
  const text = read(file);
  const markup = text.replace(/<%[\s\S]*?%>/g, (m) => m.replace(/[<>]/g, ' ')); // ignore comparison operators inside EJS tags
  if (/\s(on[a-z]+)\s*=\s*["']/i.test(markup)) offenders.handler.push(file);
  if (/\sstyle\s*=\s*["']/i.test(markup)) offenders.styleAttr.push(file);
  if (/<style[\s>]/i.test(markup)) offenders.styleTag.push(file);
  if (/(href|src|action)\s*=\s*["']\s*javascript:/i.test(markup)) offenders.jsUrl.push(file);
  for (const m of markup.matchAll(/<script\b([^>]*)>/gi)) {
    const attrs = m[1];
    if (!/src\s*=/.test(attrs) && !/type\s*=\s*["']application\/json["']/.test(attrs)) offenders.inlineScript.push(file);
  }
  for (const m of markup.matchAll(/(?:href|src|action)\s*=\s*["'](https?:)?\/\/([^"'/]+)/gi)) offenders.external.push(`${file} -> ${m[2]}`);
}
for (const [kind, list] of Object.entries(offenders)) assert.deepEqual(list, [], `no template has ${kind}`);
const css = read('src/public/css/cciq.css');
assert.doesNotMatch(css, /@import|url\(\s*["']?(https?:)?\/\//i, 'the stylesheet imports nothing from another origin');
assert.doesNotMatch(css, /expression\(|[\s;{]behavior\s*:\s*url/i, 'and uses no legacy scriptable CSS');
const server = read('src/server-app.js');
for (const directive of ["defaultSrc: [\"'self'\"]", "scriptSrc: [\"'self'\"]", "styleSrc: [\"'self'\"]", "objectSrc: [\"'none'\"]", "frameAncestors: [\"'none'\"]", "formAction: [\"'self'\"]", "baseUri: [\"'self'\"]"]) {
  assert.ok(server.includes(directive), `the policy keeps ${directive}`);
}
assert.ok(!/unsafe-inline|unsafe-eval/.test(server), 'and never allows unsafe-inline or unsafe-eval');
console.log(`PASS (csp) ${views.length} templates: no inline handlers, styles, javascript: URLs, runnable inline script or external origin; the policy stays strict`);

// ---- B. front-end JavaScript ----------------------------------------------------------------------------------------------------------
const scripts = walk('src/public/js', '.js');
for (const file of scripts) {
  const check = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' });
  assert.equal(check.status, 0, `${file} parses: ${check.stderr}`);
  const text = read(file);
  assert.match(text, /['"]use strict['"]/, `${file} is strict`);
  for (const [name, re] of [['eval', /\beval\s*\(/], ['new Function', /new\s+Function\s*\(/], ['document.write', /document\.write(ln)?\s*\(/], ['debugger', /\bdebugger\b/], ['alert', /\balert\s*\(/], ['console.log', /console\.(log|debug|info)\s*\(/], ['with', /\bwith\s*\(/]]) {
    assert.doesNotMatch(text, re, `${file} has no ${name}`);
  }
  const lines = text.split('\n');
  // HTML is built only from fixed strings, empty strings, or the one server-rendered fragment
  const dynamicHtml = [];
  lines.forEach((line, i) => {
    const m = line.match(/\.(innerHTML|outerHTML)\s*=\s*(.+)$/);
    if (!m) return;
    const value = m[2].trim();
    const fixed = /^(''|""|'[^']*'|"[^"]*"|'[^']*'\s*\+\s*count[\s\S]*)/.test(value);
    const serverFragment = /^result\.html;/.test(value);
    if (!fixed && !serverFragment) dynamicHtml.push(`${file}:${i + 1}: ${value.slice(0, 60)}`);
  });
  assert.deepEqual(dynamicHtml, [], `${file} never puts a variable into innerHTML`);
  assert.ok(!/insertAdjacentHTML/.test(text), `${file} does not use insertAdjacentHTML`);
  // web storage is always guarded (a private window or blocked storage throws)
  lines.forEach((line, i) => {
    if (!/(localStorage|sessionStorage)\.(get|set|remove)Item/.test(line)) return;
    const context = lines.slice(Math.max(0, i - 6), i + 1).join('\n');
    assert.ok(/\btry\s*\{/.test(context), `${file}:${i + 1} web storage access is inside try/catch`);
  });
  // every fetch has a failure path within the function that made it
  lines.forEach((line, i) => {
    if (!/\bfetch\s*\(/.test(line) || /^\s*(\/\/|\*)/.test(line)) return;
    const around = lines.slice(Math.max(0, i - 12), i + 45).join('\n');
    assert.ok(/\.catch\s*\(|\bcatch\s*\(|\bcatch\s*\{/.test(around), `${file}:${i + 1} fetch has a .catch or try/catch failure path`);
  });
}
console.log(`PASS (javascript) ${scripts.length} scripts: strict, parse, no eval/write/debugger/alert/console noise, no variable in innerHTML, storage guarded, every fetch has a failure path`);

// ---- C. offline dependencies ------------------------------------------------------------------------------------------------------------
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
const runtimeDeps = Object.keys(pkg.dependencies);
const problems = [];
for (const name of [...runtimeDeps, ...Object.keys(pkg.devDependencies || {})]) {
  const installedPath = path.join(root, 'node_modules', name, 'package.json');
  if (!fs.existsSync(installedPath)) { problems.push(`${name} is declared but not installed`); continue; }
  const installed = JSON.parse(fs.readFileSync(installedPath, 'utf8')).version;
  const locked = lock.packages?.[`node_modules/${name}`]?.version;
  if (locked !== installed) problems.push(`${name}: installed ${installed} but locked ${locked}`);
}
assert.deepEqual(problems, [], 'every declared dependency is installed at exactly the locked version');
const noHash = Object.entries(lock.packages || {}).filter(([k, v]) => k && !v.link && !v.integrity && !v.inBundle).map(([k]) => k);
assert.deepEqual(noHash, [], 'every locked package has an integrity hash');
const remote = Object.entries(lock.packages || {}).filter(([, v]) => v.resolved && !/^https:\/\/registry\.npmjs\.org\//.test(v.resolved)).map(([k, v]) => `${k} -> ${v.resolved}`);
assert.deepEqual(remote, [], 'every locked package comes from the public npm registry (none from a git URL or an unknown host)');
assert.ok(!Object.values(pkg.scripts).some((s) => /npm (install|i|ci)|curl|wget|npx /.test(s)), 'no package script downloads anything when run');
for (const banned of ['node-fetch', 'axios', 'request', 'got', 'undici']) assert.ok(!runtimeDeps.includes(banned), `no HTTP client library (${banned}): the portal makes no outbound requests`);
const outbound = walk('src', '.js').filter((f) => !f.includes(`${path.sep}tests${path.sep}`) && !f.includes(`${path.sep}public${path.sep}`)).filter((f) => /\bfetch\s*\(\s*['"`]https?:|https?\.request|require\(['"]https?['"]\)|from ['"]node:https?['"]|new WebSocket|net\.connect\(/.test(read(f)));
assert.deepEqual(outbound, [], 'server code makes no outbound network request');
console.log(`PASS (dependencies) ${runtimeDeps.length} runtime dependencies installed at the locked version with integrity hashes from the public registry; no HTTP client, no outbound request, no CDN`);
console.log('ALL PASS');
