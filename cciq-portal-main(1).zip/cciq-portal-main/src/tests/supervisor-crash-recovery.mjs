import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import { spawn, spawnSync, execSync } from 'node:child_process';

/*
 * Regression coverage for a real production incident: a controlled
 * crash-recovery test killed the portal's child process, and it never came
 * back — Task Scheduler's own "restart on failure" setting did not engage
 * (see CCIQ_DECISIONS.md, "Crash-recovery"). Root cause: run-service.mjs had
 * no internal respawn logic at all; it always propagated its child's exit
 * code and quit, on the assumption Task Scheduler would restart the whole
 * task. This suite exercises the fix — a self-healing supervisor — against
 * a disposable fixture tree, never against production or port 3000.
 *
 * run-service.mjs/stop-portal.mjs derive their own "root" directory from
 * their own file location (import.meta.url), and read .env by path rather
 * than from process.env. To test them exactly as they really run, this
 * copies both scripts into a throwaway temp directory that mirrors the real
 * layout (scripts/, .env, runtime/node.exe, src/server.js, logs/), with a
 * tiny fixture HTTP server standing in for the real src/server.js.
 */

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}

async function waitFor(check, { timeoutMs = 8000, intervalMs = 100 } = {}) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await check()) return true;
    await new Promise((r) => { setTimeout(r, intervalMs); });
  }
  return false;
}

async function isHealthy(port) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/healthz`);
    return res.ok;
  } catch {
    return false;
  }
}

function readPidFileSync(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8').trim();
    return raw ? Number(raw) : null;
  } catch {
    return null;
  }
}

function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

// --- Build a throwaway fixture tree mirroring the real deployment layout. ---
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-supervisor-test-'));
const port = await findFreePort();

fs.mkdirSync(path.join(root, 'scripts'), { recursive: true });
fs.mkdirSync(path.join(root, 'src'), { recursive: true });
fs.mkdirSync(path.join(root, 'runtime'), { recursive: true });
fs.mkdirSync(path.join(root, 'logs'), { recursive: true });

fs.copyFileSync(
  path.join(process.cwd(), 'scripts', 'run-service.mjs'),
  path.join(root, 'scripts', 'run-service.mjs')
);
fs.copyFileSync(
  path.join(process.cwd(), 'scripts', 'stop-portal.mjs'),
  path.join(root, 'scripts', 'stop-portal.mjs')
);
// run-service.mjs takes PID-file ownership through this module.
fs.mkdirSync(path.join(root, 'scripts', 'lib'), { recursive: true });
fs.copyFileSync(
  path.join(process.cwd(), 'scripts', 'lib', 'pid-lock.mjs'),
  path.join(root, 'scripts', 'lib', 'pid-lock.mjs')
);
fs.copyFileSync(process.execPath, path.join(root, 'runtime', 'node.exe'));
fs.writeFileSync(path.join(root, '.env'), `PORT=${port}\nHOST=127.0.0.1\n`);
// Matches the real project's package.json so the fixture's plain .js file
// (matching run-service.mjs's own hard-coded 'src/server.js' spawn arg) is
// treated as ESM, not CommonJS.
fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ type: 'module' }));

// A minimal stand-in for src/server.js: serves /healthz, and records its own
// PID to a known file each time it starts so the test can identify exactly
// which process instance is currently serving the port, across respawns.
fs.writeFileSync(path.join(root, 'src', 'server.js'), `
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const childPidFile = path.join(process.cwd(), 'logs', 'child.pid');
fs.writeFileSync(childPidFile, String(process.pid));
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'ok', pid: process.pid }));
}).listen(Number(process.env.PORT), '127.0.0.1');
`);

const pidFile = path.join(root, 'logs', 'run-service.pid');
const childPidFile = path.join(root, 'logs', 'child.pid');

function spawnSupervisor() {
  // run-service.mjs reads the .env FILE only for its own pre-flight
  // isPortInUse() check — it never sets process.env itself. The child it
  // spawns inherits process.env from the supervisor, exactly like any
  // Node child_process by default, so PORT must be set here too for the
  // fixture server (which reads process.env.PORT) to agree with the .env
  // file's value.
  return spawn(process.execPath, [path.join(root, 'scripts', 'run-service.mjs')], {
    cwd: root, env: { ...process.env, PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true
  });
}

function readLog() {
  const stamp = new Date().toISOString().slice(0, 10);
  const file = path.join(root, 'logs', `portal-${stamp}.log`);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
}

// --- Pre-go-live batch, item H: the previous supervisor died without
//     cleaning up. A dead process's PID file left behind must not stop the
//     next start (this is the incident where a bare exclusive create turned
//     one unexpected death into a permanent EEXIST). It is set aside as
//     evidence, not deleted, and the new supervisor takes the name. ---
{
  const dead = spawnSync(process.execPath, ['-e', '0']);
  assert.equal(dead.status, 0);
  const deadPid = dead.pid;
  assert.ok(!isAlive(deadPid), 'sanity: the recorded PID must genuinely not be running');
  fs.writeFileSync(path.join(root, 'logs', 'run-service.pid'), String(deadPid));
}

// --- A. Normal start, B. child becomes healthy ---
let supervisorExited = false;
let supervisor = spawnSupervisor();
supervisor.on('exit', () => { supervisorExited = true; });

assert.ok(await waitFor(() => isHealthy(port)), 'A/B: the supervised child must become healthy shortly after the supervisor starts');
const supervisorPid = supervisor.pid;
assert.equal(readPidFileSync(pidFile), supervisorPid, 'the supervisor must write its own PID to run-service.pid');
assert.ok(fs.readdirSync(path.join(root, 'logs')).some((n) => n.startsWith('run-service.pid.stale-')),
  'ITEM H: the stale PID file left by the dead predecessor must be kept as quarantined evidence, not deleted');
const firstChildPid = readPidFileSync(childPidFile);
assert.ok(firstChildPid && isAlive(firstChildPid), 'the child must be a real, running process distinct from the supervisor');
assert.notEqual(firstChildPid, supervisorPid, 'the child PID must differ from the supervisor PID');
console.log('PASS: A/B — supervisor starts and its child becomes healthy');

// --- C. Externally terminate the child, D. supervisor remains alive,
//     E. exactly one replacement child, F. replacement becomes healthy. ---
execSync(`taskkill /F /PID ${firstChildPid}`, { stdio: 'pipe' });
// taskkill returns before the process table catches up under load, so wait briefly instead of checking once.
assert.ok(await waitFor(() => !isAlive(firstChildPid), { timeoutMs: 5000 }), 'the killed child must actually be gone');
assert.ok(await waitFor(() => isHealthy(port), { timeoutMs: 10000 }),
  'D/E/F: the supervisor must spawn a replacement child that becomes healthy again, without being killed itself');
assert.ok(!supervisorExited, 'D: the supervisor process itself must never have exited');
const secondChildPid = readPidFileSync(childPidFile);
assert.notEqual(secondChildPid, firstChildPid, 'E: the replacement must be a genuinely new process, not the same one');
assert.ok(isAlive(secondChildPid), 'F: the replacement child must actually be running');
console.log('PASS: C/D/E/F — killing the child is survived: supervisor stays up, spawns exactly one healthy replacement');

// --- G. No duplicate child: only one process is serving the port. ---
const res = await fetch(`http://127.0.0.1:${port}/healthz`).then((r) => r.json());
assert.equal(res.pid, secondChildPid, 'G: the port must be served by exactly the one current child, not a leftover duplicate');
console.log('PASS: G — no duplicate child ends up serving the port');

// --- H. Repeated rapid crashes use bounded backoff, then give up. ---
// Each successive attempt waits longer (capped at MAX_DELAY_MS in
// run-service.mjs) before respawning, so the per-iteration wait here must
// comfortably exceed that cap rather than the fast turnaround of the
// earlier, unthrottled attempts.
const killedPids = new Set();
for (let i = 0; i < 6; i += 1) {
  const becameHealthy = await waitFor(() => isHealthy(port), { timeoutMs: 35000 });
  if (!becameHealthy) break; // the supervisor has very likely already given up
  const current = readPidFileSync(childPidFile);
  if (current && isAlive(current) && !killedPids.has(current)) {
    execSync(`taskkill /F /PID ${current}`, { stdio: 'pipe' });
    killedPids.add(current);
  }
}
assert.ok(await waitFor(() => supervisorExited, { timeoutMs: 20000 }),
  'H: after enough rapid crashes, the supervisor must eventually give up and exit rather than restart forever');
const logAfterGiveUp = readLog();
assert.match(logAfterGiveUp, /giving up after \d+ restart attempts/, 'H: giving up must be logged explicitly');
const delays = [...logAfterGiveUp.matchAll(/restarting in (\d+)ms \(attempt (\d+) of \d+\)/g)]
  .map((m) => ({ delay: Number(m[1]), attempt: Number(m[2]) }))
  .sort((a, b) => a.attempt - b.attempt);
assert.ok(delays.length >= 2, 'H: multiple restart attempts must have been logged');
for (let i = 1; i < delays.length; i += 1) {
  assert.ok(delays[i].delay >= delays[i - 1].delay, 'H: restart delay must never decrease — this is a backoff, not a fixed retry');
}
console.log('PASS: H — repeated rapid crashes back off and the supervisor eventually gives up, never restarting forever');

// --- I. Intentional shutdown terminates the child and does NOT respawn it. ---
//
// Confirmed empirically (see CCIQ_DECISIONS.md): on Windows, Node's own
// child.kill('SIGTERM'/'SIGINT') from ANOTHER process is unconditional
// forceful termination — the target's own `process.on('SIGTERM', ...)`
// handler never runs, regardless of whether one is registered. This is
// documented Node/Windows behaviour, not a flake of this test. The
// supervisor's in-process signal handling (the `shuttingDown` flag, the
// "exited during controlled shutdown" log line) can therefore only ever be
// reached by a real interactive Ctrl+C in a shared console — never by any
// external stop mechanism a Task-Scheduler-launched background process can
// receive. It stays in run-service.mjs as reasonable, harmless defensive
// code (useful if ever run by hand in a terminal), but the REAL, reliable
// "intentional stop" path on this platform — the one production actually
// uses — is stop-portal.mjs's forceful whole-tree kill below, which proves
// the invariant (child terminated, nothing respawns) without depending on
// signal delivery at all.
//
// What IS directly verifiable here: forcefully killing the supervisor
// itself does not orphan its child.
supervisor = spawnSupervisor();
let secondSupervisorExited = false;
supervisor.on('exit', () => { secondSupervisorExited = true; });
assert.ok(await waitFor(() => isHealthy(port), { timeoutMs: 10000 }), 'a fresh supervisor must come up healthy before it is killed');
const orphanCheckChildPid = readPidFileSync(childPidFile);

execSync(`taskkill /F /PID ${supervisor.pid}`, { stdio: 'pipe' });
assert.ok(await waitFor(() => secondSupervisorExited, { timeoutMs: 8000 }), 'the supervisor process must actually be gone after being killed');
assert.ok(await waitFor(() => !isAlive(orphanCheckChildPid), { timeoutMs: 8000 }),
  'I: forcefully killing the supervisor must not leave its child running as an orphan');
console.log('PASS: I (partial, platform-limited) — killing the supervisor does not orphan its child; see stop-portal.mjs test below for the real no-respawn guarantee');

// --- J. Logs distinguish an unexpected crash from a restart attempt. ---
// (The "controlled shutdown" log line exists in the source for the
// interactive Ctrl+C case explained above, but is not exercised by this
// automated, cross-process test for the same platform reason — asserting
// its presence here would test a Windows signal-delivery quirk, not this
// fix's own logic.)
const finalLog = readLog();
assert.match(finalLog, /CCIQ process exited unexpectedly/, 'J: an unexpected exit must be logged as such');
assert.match(finalLog, /restarting in \d+ms \(attempt \d+ of \d+\)/, 'J: each restart attempt must be logged with its attempt number and delay');
console.log('PASS: J — logs clearly record each unexpected exit and restart attempt');

// --- stop-portal.mjs compatibility, and the authoritative test of
//     "intentional stop terminates the child and does not respawn it":
//     stops supervisor + child together via the PID file, rather than only
//     killing the child (which would otherwise now look like a crash and
//     be respawned). ---
supervisor = spawnSupervisor();
let thirdSupervisorExited = false;
supervisor.on('exit', () => { thirdSupervisorExited = true; });
assert.ok(await waitFor(() => isHealthy(port), { timeoutMs: 10000 }), 'a fresh supervisor must come up healthy for the stop-portal.mjs test');
const stopTestChildPid = readPidFileSync(childPidFile);

execSync(`"${process.execPath}" "${path.join(root, 'scripts', 'stop-portal.mjs')}"`, { cwd: root, encoding: 'utf8' });
assert.ok(await waitFor(() => thirdSupervisorExited, { timeoutMs: 8000 }), 'stop-portal.mjs must stop the supervisor itself, not just the child');
assert.ok(await waitFor(() => !isAlive(stopTestChildPid), { timeoutMs: 8000 }), 'stop-portal.mjs must stop the child along with the supervisor');
const upAfterStop = await waitFor(() => isHealthy(port), { timeoutMs: 3000 });
assert.ok(!upAfterStop, 'stop-portal.mjs must actually stop the portal, not trigger a respawn');
console.log('PASS: stop-portal.mjs stops the supervisor and its child together via the PID file, with no respawn');

fs.rmSync(root, { recursive: true, force: true });
console.log('ALL PASS');
