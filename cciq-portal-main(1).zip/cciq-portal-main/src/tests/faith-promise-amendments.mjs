import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Faith Promise governance: "Members may submit a Faith Promise once. Subsequent commitment amendments require Church Admin or Super Admin intervention and are auditable."
 *   - a Member's first submission succeeds; after that the commitment is read-only to them (a "Faith Promise submitted" state instead of the form) and ANY further post -
 *     the old update address, another campaign, another member's id, no campaign, a sign-in with no member record - is refused by the server and changes nothing;
 *   - "record for a member" never overwrites an existing commitment either;
 *   - an administrator amends with a reason; the audit row keeps who, when, why and the commitment before and after; payments are never rewritten; Outstanding follows the
 *     current commitment; the history page and the reports tell original from current;
 *   - a Cell Group leader, a Member and the Kiosk cannot amend (crafted posts refused, nothing changed).
 */

const f = await buildPortalFixture('cciq-fp-amend-');
const { db, ids, users, mods } = f;
const one = (sql, ...p) => db.prepare(sql).get(...p);
const count = (sql, ...p) => one(sql, ...p).n;
const year = Number(mods.dates.today().slice(0, 4));
const campaignRow = one('SELECT * FROM ecaq_campaigns WHERE id = ?', ids.promise);
assert.equal(campaignRow.start_date.slice(5), '01-01'); // a full calendar year: 12 monthly instalments
const rowFor = (memberId) => one('SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = ? AND member_id = ?', ids.promise, memberId);
const audits = (action) => db.prepare('SELECT * FROM audit_logs WHERE action = ? ORDER BY id').all(action);
const world = () => JSON.stringify([db.prepare('SELECT * FROM ecaq_faith_promise_commitments ORDER BY id').all(), db.prepare('SELECT * FROM ecaq_faith_promise_payments ORDER BY id').all(), count("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'ecaq.faith_promise%'")]);
const pdfText = (buffer) => {
  let text = ''; const raw = buffer.toString('latin1');
  for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) {
    let content; try { content = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; }
    for (const hex of content.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(hex[1], 'hex').toString('latin1');
    for (const lit of content.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += lit[1];
    text += '\n';
  }
  return text;
};
// an account with NO member record, to prove the lock does not depend on one
await mods.users.createUser({ username: 'fx_nomember', email: 'fx_nomember@fixture.invalid', password: f.PASSWORD, displayName: 'No Record', roleKeys: ['member'], memberId: null, mustChangePassword: false });

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const c = { member: await signIn(portal.base, users.memberB.email, f.PASSWORD), anna: await signIn(portal.base, users.memberA.email, f.PASSWORD), leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD),
    church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD), super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD),
    nomember: await signIn(portal.base, 'fx_nomember@fixture.invalid', f.PASSWORD) };
  const text = async (client, url) => { const r = await client.get(url); return { status: r.status, body: await r.text(), location: r.headers.get('location') }; };
  const main = (body) => ((/<main[\s\S]*?<\/main>/.exec(body) || [body])[0]).replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/&middot;/g, '·').replace(/&rarr;/g, '→').replace(/&amp;/g, '&').replace(/\s+/g, ' ');
  const submit = async (client, fields) => { const r = await client.post('/projects/ecaq/faith-promise', { campaign_id: ids.promise, name: 'Ben MemberB', phone: '', email: '', amount: '10', frequency: 'monthly', ...fields }, { csrfFrom: '/projects/ecaq/faith-promise' }); await r.text(); return r; };

  // ---- 1. the first submission succeeds; afterwards the member sees a locked, submitted state --------------------------------------------------------------------------------------
  assert.equal(rowFor(ids.member.b1), undefined);
  { const form = await text(c.member, '/projects/ecaq/faith-promise'); assert.ok(form.body.includes('id="pledge-form"'), 'before submitting: the form'); assert.match(form.body, />Submit my Faith Promise</); }
  const first = await submit(c.member, { amount: '10', frequency: 'monthly' });
  assert.equal(first.status, 302);
  const own = rowFor(ids.member.b1);
  assert.ok(own); assert.equal(Number(own.commitment_amount), 10); assert.equal(own.frequency, 'monthly'); assert.equal(Number(own.expected_total), 120, 'QAR 10 monthly = QAR 120 for the year');
  { const submitted = audits('ecaq.faith_promise_submitted').find((a) => String(a.entity_id) === String(own.id)); assert.ok(submitted, 'audited'); assert.deepEqual([JSON.parse(submitted.detail).amount, JSON.parse(submitted.detail).frequency, JSON.parse(submitted.detail).expected_total], [10, 'monthly', 120], 'the original commitment is in the audit row'); }
  { const page = await text(c.member, '/projects/ecaq/faith-promise'); const body = main(page.body);
    assert.ok(!page.body.includes('id="pledge-form"'), 'after submitting: no form'); assert.ok(!/Update my Faith Promise|Submit my Faith Promise/.test(page.body), 'no update or submit button');
    assert.match(body, /Faith Promise submitted/); assert.match(body, /QAR 120/); assert.match(body, /QAR 10 monthly · total for the year/);
    assert.match(body, /Your Faith Promise has been recorded\. If you need to change your commitment, please contact the Church Administration\./, 'natural wording, no developer terms');
    assert.match(body, /Your commitment so far/, 'and the member can still see what has been received'); }
  console.log('PASS (first submission) a Member submits once (QAR 10 monthly = QAR 120), the original is in the audit row, and the page becomes a "Faith Promise submitted" state with no form or Update button');

  // ---- 2. every further post is refused and changes nothing ------------------------------------------------------------------------------------------------------------------------------
  { const before = world();
    const crafted = [{ amount: '15' }, { amount: '15', frequency: 'annual' }, { campaign_id: '', amount: '15' }, { campaign_id: '99999', amount: '15' }, { amount: '15', member_id: ids.member.a2 }, { amount: '15', member_id: ids.member.b1 }, { amount: '1' }, { amount: '999999' }, { name: 'Someone Else', amount: '15' }];
    for (const fields of crafted) { const r = await submit(c.member, fields); assert.equal(r.status, 302, JSON.stringify(fields)); assert.equal(world(), before, `a second post ${JSON.stringify(fields)} changed nothing`); }
    const flash = await text(c.member, '/projects/ecaq/faith-promise'); assert.match(main(flash.body), /already been recorded, so nothing was changed/, 'and says so plainly');
    assert.equal(Number(rowFor(ids.member.b1).commitment_amount), 10); assert.equal(Number(rowFor(ids.member.b1).expected_total), 120);
    // Anna (who already holds one from the fixture) is locked too, and her figures are untouched
    const annaBefore = JSON.stringify(rowFor(ids.member.a2)); const r = await submit(c.anna, { name: 'Anna MemberA', amount: '500' }); assert.equal(r.status, 302);
    assert.equal(JSON.stringify(rowFor(ids.member.a2)), annaBefore, 'an existing commitment (from before this rule) is locked as well'); }
  // a sign-in with no member record: one submission, then locked (it cannot create a stream of commitments)
  { const r1 = await submit(c.nomember, { name: 'No Record', amount: '20', frequency: 'quarterly' }); assert.equal(r1.status, 302);
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments WHERE member_id IS NULL AND campaign_id = ?', ids.promise), 1);
    const before = world(); for (const amount of ['25', '30', '35']) await submit(c.nomember, { name: 'No Record', amount, frequency: 'quarterly' });
    assert.equal(world(), before, 'no further commitment, and the first is unchanged'); assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments WHERE member_id IS NULL AND campaign_id = ?', ids.promise), 1); }
  // the service itself refuses (not only the route)
  { const before = world(); const direct = mods.faith.submitCommitment(ids.promise, { member_id: ids.member.b1, name: 'Ben MemberB', amount: 77, frequency: 'monthly' }, { userId: users.memberB.id });
    assert.equal(direct.ok, false); assert.equal(direct.reason, 'already_submitted'); assert.equal(world(), before); }
  // an administrator "recording for a member" does not overwrite either
  { const before = world(); const r = await c.church.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: ids.member.b1, amount: '99', frequency: 'monthly', name: 'Ben MemberB' }, { csrfFrom: `/admin/ecaq/faith-promise/new?campaign=${ids.promise}` });
    const body = await r.text(); assert.equal(r.status, 400); assert.match(body, /already has a Faith Promise in this campaign/); assert.equal(world(), before); }
  console.log('PASS (locked) nine crafted second posts, a sign-in with no member record, the service itself and an administrator\'s "record for a member" are all refused, leaving the commitment, payments and audit untouched');

  // ---- 3. only Church Admin and Super Admin amend -----------------------------------------------------------------------------------------------------------------------------------------------
  const amendUrl = (id) => `/admin/ecaq/faith-promise/commitments/${id}/amend`;
  { const before = world();
    for (const who of ['leader', 'member', 'kiosk', 'nomember']) {
      const r = await c[who].post(amendUrl(own.id), { amount: '15', frequency: 'monthly', reason: 'I want more' }, { csrfFrom: '/account/password' }); await r.text();
      assert.ok(r.status === 403 || (r.status === 302 && !/\/admin\/ecaq/.test(r.headers.get('location') || '')), `${who} amend -> ${r.status}`);
      const page = await text(c[who], `/admin/ecaq/faith-promise/commitments/${own.id}`); assert.ok(page.status === 403 || page.status === 302, `${who} cannot open the commitment page`);
    }
    assert.equal(world(), before, 'crafted amendments by a leader, a Member and the Kiosk changed nothing'); }
  console.log('PASS (no authority) a Cell Group leader, a Member (even for their own commitment) and the Kiosk cannot amend by crafted post or address');

  // ---- 4. the amendment ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  // a payment first, so "payments preserved" and "outstanding" mean something
  mods.faith.addPayment(own.id, { received_by: 'Fixture Receiver', amount: 50, paid_on: mods.dates.today(), method: 'cash' }, { userId: users.churchAdmin.id });
  const paymentsBefore = JSON.stringify(db.prepare('SELECT * FROM ecaq_faith_promise_payments WHERE commitment_id = ? ORDER BY id').all(own.id));
  const amend = async (client, fields) => { const r = await client.post(amendUrl(own.id), fields, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${own.id}` }); await r.text(); return r; };
  { const before = world();
    for (const bad of [{ amount: '15', frequency: 'monthly', reason: '' }, { amount: '15', frequency: 'monthly', reason: '   ' }, { amount: '15', frequency: 'monthly' }, { amount: '0', frequency: 'monthly', reason: 'x' }, { amount: 'abc', frequency: 'monthly', reason: 'x' }, { amount: '-5', frequency: 'monthly', reason: 'x' }, { amount: '15', frequency: 'weekly', reason: 'x' }, { amount: '10', frequency: 'monthly', reason: 'same as now' }]) {
      const r = await amend(c.church, bad); assert.ok(r.status < 500, JSON.stringify(bad)); assert.equal(world(), before, `refused: ${JSON.stringify(bad)}`);
    }
    console.log('PASS (validation) an amendment without a reason, with a bad amount or frequency, or with nothing changed is refused and changes nothing'); }
  const when = Date.now();
  const done = await amend(c.church, { amount: '15', frequency: 'monthly', reason: 'Member requested increase' });
  assert.equal(done.status, 302);
  const amended = rowFor(ids.member.b1);
  assert.equal(Number(amended.commitment_amount), 15); assert.equal(Number(amended.expected_total), 180, 'QAR 15 monthly = QAR 180');
  assert.equal(JSON.stringify(db.prepare('SELECT * FROM ecaq_faith_promise_payments WHERE commitment_id = ? ORDER BY id').all(own.id)), paymentsBefore, 'payments are exactly as they were');
  assert.equal(Number(amended.amount_collected), 50, 'received is the sum of the payments');
  assert.equal(amended.status, 'in_progress');
  const audit = audits('ecaq.faith_promise_amended').find((a) => String(a.entity_id) === String(own.id));
  assert.ok(audit, 'the amendment is audited'); assert.equal(audit.user_id, users.churchAdmin.id, 'who made it');
  assert.ok(Math.abs(Date.parse(audit.created_at) - when) < 120000, 'when');
  const detail = JSON.parse(audit.detail);
  assert.equal(detail.reason, 'Member requested increase'); assert.deepEqual(detail.before, { amount: 10, frequency: 'monthly', expected_total: 120 }); assert.deepEqual(detail.after, { amount: 15, frequency: 'monthly', expected_total: 180 }); assert.equal(detail.received, 50);
  { const page = await text(c.church, `/admin/ecaq/faith-promise/commitments/${own.id}`); const body = main(page.body);
    assert.match(body, /Committed \(current\)\s+QAR 180/); assert.match(body, /Originally QAR 120 \(QAR 10 monthly\)/);
    assert.match(body, /Amended by churchAdmin|Amended by fx_church/); assert.match(body, /QAR 10 monthly → QAR 15 monthly/); assert.match(body, /Year total QAR 120 → QAR 180/); assert.match(body, /Reason: Member requested increase/);
    assert.match(body, /Submitted/); assert.match(body, /Outstanding\s+QAR 130/, 'outstanding follows the CURRENT commitment: 180 - 50'); }
  // a second amendment by the Super Admin: the original stays the original
  const done2 = await amend(c.super, { amount: '20', frequency: 'monthly', reason: 'Second change' });
  assert.equal(done2.status, 302); assert.equal(Number(rowFor(ids.member.b1).expected_total), 240);
  { const history = mods.faith.commitmentHistory(rowFor(ids.member.b1)); assert.equal(history.amendments, 2); assert.deepEqual(history.original, { amount: 10, frequency: 'monthly', expected_total: 120 }, 'the original is still what the member first promised');
    assert.deepEqual(history.entries.map((e) => e.kind), ['submitted', 'amended', 'amended']); assert.deepEqual(history.entries[2].before, history.entries[1].after, 'each amendment starts where the previous one ended');
    assert.equal(audits('ecaq.faith_promise_amended').filter((a) => String(a.entity_id) === String(own.id)).length, 2); assert.equal(audits('ecaq.faith_promise_amended').find((a) => a.user_id === users.superAdmin.id) !== undefined, true, 'the Super Admin amendment is by the Super Admin'); }
  // outstanding reaches zero / completes against the new commitment, never rewriting history
  { mods.faith.addPayment(own.id, { received_by: 'Fixture Receiver', amount: 190, paid_on: mods.dates.today(), method: 'bank_transfer' }, { userId: users.churchAdmin.id }); assert.equal(rowFor(ids.member.b1).status, 'completed');
    await amend(c.church, { amount: '25', frequency: 'monthly', reason: 'Raised again' }); const r = rowFor(ids.member.b1); assert.equal(Number(r.expected_total), 300); assert.equal(r.status, 'in_progress', 'completed becomes in progress when the current commitment rises above what was received'); assert.equal(Number(r.amount_collected), 240); }
  console.log('PASS (amendment) QAR 10 monthly (120) -> 15 monthly (180) by the Church Admin: reason, who, when and before/after are in the audit row; payments untouched; outstanding follows the current commitment (180 - 50 = 130); a Super Admin amendment chains from it; the original stays the original');

  // ---- 5. reports and screens: current vs original ----------------------------------------------------------------------------------------------------------------------------------------
  { const list = await text(c.church, `/admin/ecaq/faith-promise?campaign=${ids.promise}`); const m = main(list.body); assert.match(m, /QAR 300\s*Amended/, 'the list shows the CURRENT commitment, marked Amended'); assert.match(m, /Ben MemberB/);
    const ledger = mods.ecaq.campaignLedger ? null : null; void ledger;
    const sum = one('SELECT SUM(expected_total) s, SUM(amount_collected) r FROM ecaq_faith_promise_commitments WHERE campaign_id = ?', ids.promise);
    const { campaignLedger } = await import('../services/campaign-ledger.js'); const headline = campaignLedger(one('SELECT * FROM ecaq_campaigns WHERE id = ?', ids.promise)).headline;
    assert.equal(headline.committed, sum.s, 'the ledger headline commits to the CURRENT commitments'); assert.equal(headline.received, sum.r, 'and receives the sum of the payments');
    assert.equal(Math.round((headline.outstanding) * 100), Math.round(Math.max(sum.s - sum.r, 0) * 100), 'outstanding = current commitments - payments');
    const pdf = await c.church.get(`/reports/faith-promise/pdf?campaign_id=${ids.promise}`); const buf = Buffer.from(await pdf.arrayBuffer()); assert.equal(pdf.status, 200); assert.equal(buf.slice(0, 5).toString(), '%PDF-');
    const t = pdfText(buf); assert.match(t, /commitment was amended by the Church Administration/, 'the Faith Promise report says amended commitments are current figures'); assert.match(t, /Ben MemberB \(amended\)/);
    const mine = await text(c.member, '/projects/ecaq/my-commitments'); assert.match(main(mine.body), /QAR 300/, 'the member sees the current commitment'); assert.ok(!/Reason|Amended by/.test(main(mine.body)), 'but not the administrators\' reasons');
    const own2 = await text(c.member, '/projects/ecaq/faith-promise'); assert.match(main(own2.body), /Faith Promise submitted\s+QAR 300/); assert.match(main(own2.body), /Received\s+QAR 240/); }
  console.log('PASS (reports) the list, ledger headline, Faith Promise report and the member\'s own page all use the CURRENT commitment and the sum of the payments; amended commitments are marked; the member does not see the reasons');

  // ---- 6. legacy history is shown as it is, never invented ---------------------------------------------------------------------------------------------------------------------------------------
  { const legacy = rowFor(ids.member.a2); db.prepare("INSERT INTO audit_logs (user_id, actor_label, action, entity_type, entity_id, result, detail, created_at) VALUES (?, 'x', 'ecaq.faith_promise_updated', 'faith_promise_commitment', ?, 'success', NULL, ?)").run(users.memberA.id, String(legacy.id), new Date().toISOString());
    const page = await text(c.church, `/admin/ecaq/faith-promise/commitments/${legacy.id}`); const body = main(page.body); assert.match(body, /Changed/); assert.match(body, /recorded before amendments kept the old and new figures/); assert.ok(!/Originally/.test(body), 'no invented "original" for a commitment nobody amended since'); }

  // ---- 7. responsive: the locked state and the amend screen --------------------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  const cookiesOf = (client) => client.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  for (const [who, url, selector] of [['member', '/projects/ecaq/faith-promise', '.pledge-card'], ['church', `/admin/ecaq/faith-promise/commitments/${own.id}`, '#amend button[type=submit]'], ['church', `/admin/ecaq/faith-promise?campaign=${ids.promise}`, 'table.data']]) {
    for (const width of [320, 375, 430, 768, 1024, 1280, 1440]) {
      const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookiesOf(c[who])); const page = await context.newPage(); await page.goto(portal.base + url, { waitUntil: 'load' });
      const m = await page.evaluate((sel) => { const el = document.querySelector(sel); const r = el ? el.getBoundingClientRect() : null; return { overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, found: Boolean(el), right: r ? r.right : 0, w: r ? r.width : 0 }; }, selector);
      if (m.overflow > 0) problems.push(`${who} ${width}px ${url}: sideways scroll ${m.overflow}px`); if (!m.found) problems.push(`${who} ${width}px ${url}: ${selector} missing`); if (m.right > width + 1) problems.push(`${who} ${width}px ${url}: runs off the screen`);
      await context.close();
    }
  }
  assert.deepEqual(problems, [], problems.join('; '));
  console.log('PASS (widths) the locked Faith Promise state, the amend screen and the commitment list at 320 to 1440 px: no sideways scroll, nothing off screen');
  console.log('PASS faith-promise-amendments');
} finally {
  await browser.close();
  await portal.stop();
}
