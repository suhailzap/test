import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Input boundaries, attacked through the real forms: what is accepted is stored EXACTLY (trim and canonical Unicode form only) and what is not
 * is refused with a message beside its field and nothing saved. Nothing is coerced into a different value: "12abc" is not 12, "+1" is not 1,
 * a date in the year 1800 is not a birth date, a line break is not part of a name. Hostile text is stored as text and shown escaped.
 * Control characters, bidirectional overrides, partial numbers, impossible dates, wildcard characters, repeated and array parameters, and
 * oversized bodies are all covered; none may produce a 500.
 */

const f = await buildPortalFixture('cciq-input-boundary-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
const today = mods.dates.today();
let serial = 0;
const memberRow = () => db.prepare('SELECT * FROM members ORDER BY id DESC LIMIT 1').get();
const memberCount = () => db.prepare('SELECT COUNT(*) n FROM members').get().n;
const decode = (s) => s.replace(/&#34;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

async function createMember(fields) {
  serial += 1;
  const before = memberCount();
  const res = await admin.post('/members', { first_name: `Probe${serial}`, last_name: `Surname${serial}`, duplicate_override: '1', ...fields }, { csrfFrom: '/members/new' });
  const html = await res.text();
  assert.ok(res.status === 302 || res.status === 400, `no server error for ${JSON.stringify(fields).slice(0, 80)} (got ${res.status})`);
  return { accepted: res.status === 302, html, row: res.status === 302 ? memberRow() : null, created: memberCount() - before };
}

try {
  // ---- 1. names ---------------------------------------------------------------------------------------------------------------------------
  const ACCEPT = [
    ['Mañuel José', 'Mañuel José'], ["D'Angelo O'Brien", "D'Angelo O'Brien"], ['Dela Cruz-Santos', 'Dela Cruz-Santos'], ['محمد', 'محمد'], ['Joy 😀', 'Joy 😀'], ['山田太郎', '山田太郎'],
    ['  Padded  ', 'Padded'], ['é', 'é'], ['x'.repeat(80), 'x'.repeat(80)], ['😀'.repeat(80), '😀'.repeat(80)], ['A​B', 'A​B'],
    ['<b>bold</b>', '<b>bold</b>'], ['<script>alert(1)</script>', '<script>alert(1)</script>'], ["x'; DROP TABLE members; --", "x'; DROP TABLE members; --"], ['50%', '50%'], ['a_b', 'a_b'], ['a\\b', 'a\\b']
  ];
  for (const [sent, stored] of ACCEPT) {
    const r = await createMember({ first_name: sent });
    assert.equal(r.accepted, true, `accepted: ${JSON.stringify(sent).slice(0, 40)}`);
    assert.equal(r.row.first_name, stored, `stored exactly (trimmed, canonical form): ${JSON.stringify(stored).slice(0, 40)}`);
  }
  assert.ok(db.prepare("SELECT 1 FROM sqlite_master WHERE name = 'members'").get(), 'SQL-looking text is only text');
  const REFUSE = [['', 'required'], ['   ', 'required'], [' ', 'required'], ['x'.repeat(81), '80 characters'], ['😀'.repeat(81), '80 characters'],
    ['A\tB', 'one line'], ['A\nB', 'one line'], ['A\r\nB', 'one line'], ['A\u0000B', 'one line'], ['A\u001bB', 'one line'], ['A\u0085B', 'one line'], ['A B', 'one line'],
    ['A‮B', 'text-direction'], ['A‪B', 'text-direction'], ['A⁦B', 'text-direction']];
  for (const [sent, fragment] of REFUSE) {
    const r = await createMember({ first_name: sent });
    assert.equal(r.accepted, false, `refused: ${JSON.stringify(sent).slice(0, 30)}`);
    assert.equal(r.created, 0, 'and nothing was saved');
    assert.match(decode(r.html), new RegExp(`id="first_name-error"[^>]*>[^<]*${fragment}`), `with its message beside the field (${fragment})`);
  }
  // the astral-plane limit counts characters, not UTF-16 halves: 80 emoji is allowed (above) and 81 is not (above)
  console.log(`PASS (1) ${ACCEPT.length} unusual names are stored exactly (trim and canonical form only); ${REFUSE.length} are refused beside the field with nothing saved: blank, over-length, control characters, line breaks, bidirectional overrides`);

  // ---- 2. multi-line boxes -----------------------------------------------------------------------------------------------------------------
  {
    const ok = await createMember({ notes: 'line one\r\nline two\tindented' });
    assert.equal(ok.accepted, true); assert.equal(ok.row.notes, 'line one\r\nline two\tindented', 'a notes box keeps its line breaks and tabs');
    const bad = await createMember({ notes: 'before\u0000after' });
    assert.equal(bad.accepted, false); assert.match(decode(bad.html), /id="notes-error"[^>]*>[^<]*cannot be saved/);
    const addr = await createMember({ address: 'Villa 4\nStreet 12\nDoha' }); assert.equal(addr.accepted, true);
    const title = await admin.post('/activities', { title: 'Two\nlines', activity_date: today }, { csrfFrom: '/activities/new' }); const t = await title.text();
    assert.equal(title.status, 400); assert.match(decode(t), /Title must be on one line/);
    console.log('PASS (2) a notes or address box keeps line breaks and tabs but refuses a NUL; a title refuses a line break');
  }

  // ---- 3. phone and email ------------------------------------------------------------------------------------------------------------------------
  for (const [sent, ok] of [['+974 5555 1234', true], ['(974) 5555-1234', true], ['123456', true], ['12345', false], ['٠١٢٣٤٥٦٧', false], ['5555abc', false], ['974.5555.1234', false], ['5555 1234 x12', false], ['5555\n1234', false], ['5555\t1234', false], ['------', false], ['+++++++', false], ['1'.repeat(33), false]]) {
    const r = await createMember({ phone: sent });
    assert.equal(r.accepted, ok, `phone ${JSON.stringify(sent)} ${ok ? 'accepted' : 'refused'}`);
    if (ok) assert.equal(r.row.phone, sent);
  }
  for (const [sent, stored] of [['a@b.co', 'a@b.co'], ['A@B.CO', 'a@b.co'], ['a+b@c.de', 'a+b@c.de'], ['müller@beispiel.de', 'müller@beispiel.de'], [' a@b.co ', 'a@b.co'], ['a@sub.b.co', 'a@sub.b.co']]) {
    const r = await createMember({ email: sent }); assert.equal(r.accepted, true, `email ${sent}`); assert.equal(r.row.email, stored);
  }
  for (const sent of ['a@b.com.', 'a@b..com', 'a@.com', '@b.com', 'a@@b.co', 'a@b', 'a b@c.de', 'a@b.co\nbcc:x@y.z', '"a b"@c.de', `${'a'.repeat(250)}@b.com`]) {
    const r = await createMember({ email: sent }); assert.equal(r.accepted, false, `email ${JSON.stringify(sent).slice(0, 30)} refused`); assert.equal(r.created, 0);
  }
  console.log('PASS (3) phone and email: exactly what is typed is stored, a number needs 6 digits, no control characters, a trailing or doubled dot and a missing domain are refused');

  // ---- 4. dates and numbers ----------------------------------------------------------------------------------------------------------------------
  for (const [sent, ok] of [['1990-02-28', true], ['1992-02-29', true], ['1991-02-29', false], ['2100-02-29', false], ['1990-13-01', false], ['1990-00-10', false], ['1990-04-31', false], ['0000-00-00', false],
    ['1990-1-1', false], ['01/02/1990', false], ['1990/01/02', false], ['1990-01-02T10:00', false], ['1899-12-31', false], ['1800-01-01', false], ['1900-01-01', true], ['9999-12-31', false], [mods.dates.addDays(today, 1), false], ['۱۹۹۰-۰۱-۰۲', false]]) {
    const r = await createMember({ date_of_birth: sent });
    assert.equal(r.accepted, ok, `date of birth ${sent} ${ok ? 'accepted' : 'refused'}`);
    if (ok) assert.equal(r.row.date_of_birth, sent);
  }
  const group = ids.groupA;
  for (const [sent, ok] of [[String(group), true], ['', true], ['+1', false], ['1e3', false], ['0x10', false], [' 7 ', false], ['7.0', false], ['-1', false], ['0', false], ['99999999999999999999', false], ['٣', false], ['98765', false]]) {
    const r = await createMember({ cell_group_id: sent });
    assert.equal(r.accepted, ok, `cell group id ${JSON.stringify(sent)} ${ok ? 'accepted' : 'refused'}`);
    if (ok && sent) assert.equal(r.row.cell_group_id, group);
  }
  console.log('PASS (4) dates and ids: real dates only (leap days exact, none before 1900), digits only (no sign, exponent, hex, decimal, padding or overflow), nothing coerced');

  // ---- 5. hostile text is shown as text, and searches treat wildcards literally ---------------------------------------------------------------------
  {
    const html = await (await admin.get(`/members/${db.prepare("SELECT id FROM members WHERE first_name LIKE '<script>%'").get().id}`)).text();
    assert.doesNotMatch(html, /<script>alert\(1\)<\/script>/, 'a script in a name is never emitted as markup');
    assert.match(html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
    const list = await (await admin.get('/members?q=%3Cscript%3E')).text();
    assert.doesNotMatch(list, /<script>alert/);
    const percent = decode(await (await admin.get('/members?q=%25&page_size=100')).text());
    assert.match(percent, /50%/, 'searching % finds the name that contains a percent sign');
    assert.doesNotMatch(percent, /Probe1 Surname1/, 'and does not match everyone');
    const under = decode(await (await admin.get('/members?q=_&page_size=100')).text());
    assert.match(under, /a_b/); assert.doesNotMatch(under, /Dela Cruz/, 'an underscore is not "any character"');
    const accented = decode(await (await admin.get(`/members?q=${encodeURIComponent('é')}&page_size=100`)).text());
    assert.match(accented, /é/, 'a search typed with a combining accent finds the stored single-letter form');
    console.log('PASS (5) hostile text is escaped when shown; % and _ in a search mean themselves; a combining accent finds the accented name');
  }

  // ---- 6. repeated, array and oddly named parameters; huge bodies -----------------------------------------------------------------------------------
  {
    const raw = async (body, headers = {}) => fetch(`${portal.base}/members`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: admin.cookie, ...headers }, body });
    const csrf = await admin.csrf('/members/new');
    const post = (fields) => raw(`_csrf=${encodeURIComponent(csrf)}&duplicate_override=1&${fields}`);
    for (const fields of ['first_name=Dup1&first_name=Dup2&last_name=Rep', 'first_name[]=Arr&last_name=Rep2', 'first_name=Ok&last_name=Proto&__proto__=x&constructor=y&prototype=z', 'first_name=Ok&last_name=Obj&first_name[a]=b',
      'first_name=Ok&last_name=Long&notes=' + 'n'.repeat(5000), `first_name=${'%F0%9F%98%80'.repeat(100)}&last_name=Emoji`, 'first_name=%ff%fe&last_name=BadUtf8', 'first_name=&last_name=&cell_group_id=&date_of_birth=']) {
      const res = await post(fields); await res.text();
      assert.ok([302, 400].includes(res.status), `${fields.slice(0, 40)} -> ${res.status} (never a server error)`);
    }
    const before = memberCount();
    const huge = await post(`first_name=X&last_name=Y&notes=${'z'.repeat(300000)}`); await huge.text();
    assert.ok([400, 413].includes(huge.status), `a 300 KB body is refused (${huge.status}), not processed`);
    assert.equal(memberCount(), before, 'and creates nothing');
    assert.equal((await admin.get('/members')).status, 200, 'the portal is still up');
    console.log('PASS (6) repeated, array, prototype-named and non-UTF-8 parameters and a 300 KB body never cause a server error and create nothing wrong');
  }

  // ---- 7. a settings form is all-or-nothing, and every problem is reported ---------------------------------------------------------------------------
  {
    const { getSetting } = await import('../lib/settings.js');
    const key = 'visitors.follow_up_days';
    const keyBefore = getSetting(key);
    const page = await admin.get('/admin/settings?section=attendance'); await page.text();
    const res = await admin.post('/admin/settings', { section: 'attendance', visitors__follow_up_days: '999', attendance__recent_engagement_days: '12abc', service__friday__time: '25:99' }, { csrfFrom: '/admin/settings' });
    assert.equal(res.status, 302); await res.text();
    const flash = decode(await (await admin.get(res.headers.get('location'))).text());
    assert.match(flash, /Nothing was saved/, 'the message says nothing was saved');
    assert.equal(getSetting(key), keyBefore, 'a valid value in the same submission is not saved when another is wrong');
    console.log('PASS (7) a settings submission with one wrong value saves nothing and says so');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
