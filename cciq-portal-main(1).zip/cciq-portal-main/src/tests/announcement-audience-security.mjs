import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness, R07 from the red-team review, across two passes.
 *
 * First pass: AUDIENCES.administrators mapped to the 'members.view'
 * permission, which every default Cell Group Leader also holds for
 * ordinary roster duties — so "Administrators"-only announcements reached
 * every leader too, both for on-screen visibility (canSeeAudience()) and
 * notification fan-out (audienceUserIds(), which reads
 * AUDIENCES[key].permission directly). Fixed by mapping 'administrators'
 * to 'admin.settings', held by church_admin/super_admin by default and not
 * by LEADER.
 *
 * Second pass (independent/Codex verification): src/services/search.js had
 * its own, independently-duplicated copy of the exact same buggy predicate,
 * never touched by the first fix - a default Cell Group Leader could still
 * discover an Administrators-only announcement's title through GET /search,
 * even though the main list and direct view were both correctly protected.
 * Fixed by having search.js call the same canViewAnnouncement() every other
 * discovery path already used, instead of reimplementing the status/date/
 * audience checks inline - one predicate, everywhere, so a future fix only
 * ever needs to happen once.
 */

const env = createIsolatedTestEnv('cciq-announcement-audience-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { canSeeAudience, AUDIENCES } = await import('../services/announcements.js');
const { default: db } = await import('../db/index.js');

function fakeUser(permissions) {
  const set = new Set(permissions);
  return { can: (...perms) => perms.some((p) => set.has(p)) };
}

const superAdmin = fakeUser(['announcements.manage', 'admin.settings', 'announcements.view', 'cellgroups.manage_own', 'members.view']);
const churchAdmin = fakeUser(['announcements.manage', 'admin.settings', 'announcements.view', 'members.view']);
const cellGroupLeader = fakeUser(['cellgroups.manage_own', 'members.view', 'announcements.view']);
const member = fakeUser(['announcements.view']);
// A custom/delegated role holding admin.settings without any built-in
// "administrator" role name — proves this is genuinely permission-based.
const customRoleWithAdminSettings = fakeUser(['admin.settings']);

// --- Super Admin sees Administrators announcements. ---
assert.equal(canSeeAudience(superAdmin, 'administrators'), true, 'Super Admin must see Administrators-audience announcements');
console.log('PASS: Super Admin sees Administrators-audience announcements');

// --- Church Admin sees Administrators announcements. ---
assert.equal(canSeeAudience(churchAdmin, 'administrators'), true, 'Church Admin must see Administrators-audience announcements');
console.log('PASS: Church Admin sees Administrators-audience announcements');

// --- Cell Group Leader does NOT see Administrators announcements (the confirmed defect). ---
assert.equal(canSeeAudience(cellGroupLeader, 'administrators'), false,
  'R07 CONFIRMED FIXED: a default Cell Group Leader must not see Administrators-audience announcements merely because they hold members.view');
console.log('PASS: a default Cell Group Leader no longer sees Administrators-audience announcements');

// --- Member does NOT see Administrators announcements. ---
assert.equal(canSeeAudience(member, 'administrators'), false, 'an ordinary Member must not see Administrators-audience announcements');
console.log('PASS: an ordinary Member does not see Administrators-audience announcements');

// --- Custom-role/custom-permission edge case: admin.settings alone (no named role) qualifies. ---
assert.equal(canSeeAudience(customRoleWithAdminSettings, 'administrators'), true,
  'a custom role holding admin.settings must see Administrators-audience announcements — this is permission-based, not a hardcoded role check');
console.log('PASS: a custom role holding admin.settings alone qualifies as an Administrators audience — confirms this is permission-based');

// --- No regression: 'leaders' and 'members'/'all' audiences still work as before. ---
assert.equal(canSeeAudience(cellGroupLeader, 'leaders'), true, 'a Cell Group Leader must still see Cell-group-leaders-audience announcements');
assert.equal(canSeeAudience(member, 'leaders'), false, 'an ordinary Member must not see Cell-group-leaders-audience announcements');
assert.equal(canSeeAudience(member, 'members'), true, 'an ordinary Member must still see Members-audience announcements');
assert.equal(canSeeAudience(member, 'all'), true, 'an ordinary Member must still see Everyone-audience announcements');
console.log('PASS: leaders/members/all audiences are unaffected by the fix');

// --- audienceUserIds() (notification fan-out) reads AUDIENCES.administrators.permission
//     directly — confirm the fixed field, not just canSeeAudience()'s own logic. ---
assert.equal(AUDIENCES.administrators.permission, 'admin.settings',
  'AUDIENCES.administrators.permission itself must be fixed — audienceUserIds() reads this field directly for notification fan-out, independent of canSeeAudience()');
console.log('PASS: AUDIENCES.administrators.permission is fixed at the source, so notification fan-out is fixed too');

// --- Codex/R07: search.js had its own independently-duplicated copy of the
//     buggy 'administrators' predicate, never touched by the first fix -
//     a default Cell Group Leader could discover an Administrators-only
//     announcement's title through GET /search even though the main list
//     and direct view were both correctly protected. Fixed by having
//     search.js call the same canViewAnnouncement() everything else uses,
//     rather than reimplementing the status/date/audience checks inline. ---
{
  const { search } = await import('../services/search.js');
  const { createUser } = await import('../services/users.js');
  const { createMember } = await import('../services/members.js');
  const { createGroup } = await import('../services/cell-groups.js');

  const at = new Date().toISOString();
  db.prepare(
    `INSERT INTO announcements (title, body, priority, audience, publish_at, expires_at, status, created_at, updated_at)
     VALUES ('SEARCHABLE ADMIN ONLY ANNOUNCEMENT', 'admin-only body', 'normal', 'administrators', NULL, NULL, 'published', ?, ?)`
  ).run(at, at);

  const group = createGroup({ name: 'R07 Search Group' }, {});
  const leaderMember = createMember({ first_name: 'Leader', last_name: 'R07Search' }, { status: 'active' });
  db.prepare('UPDATE cell_groups SET leader_member_id = ? WHERE id = ?').run(leaderMember.id, group.id);
  const leaderUserId = await createUser({
    email: 'leader.r07search@fixture.invalid', password: 'LeaderPassw0rd!2026',
    displayName: 'Leader R07 Search', roleKeys: ['cell_group_leader'], memberId: leaderMember.id, mustChangePassword: false
  });

  const { loadUserContext } = await import('../services/users.js');
  const leaderContext = loadUserContext(leaderUserId);

  const results = search(leaderContext, 'SEARCHABLE ADMIN ONLY');
  // search() filters out any kind with zero results entirely - the
  // 'announcement' group being absent here (rather than present-but-empty)
  // is itself the correct, expected outcome once nothing qualifies.
  const announcementGroup = results.groups.find((g) => g.kind === 'announcement');
  const leaked = (announcementGroup?.results || []).some((r) => r.title.includes('SEARCHABLE ADMIN ONLY ANNOUNCEMENT'));
  assert.equal(leaked, false,
    'CODEX FINDING CONFIRMED FIXED: a default Cell Group Leader must not discover an Administrators-only announcement via search');
  console.log('PASS: search.js no longer leaks Administrators-only announcements to a default Cell Group Leader');

  const churchAdminUserId = await createUser({
    email: 'churchadmin.r07search@fixture.invalid', password: 'AdminPassw0rd!2026',
    displayName: 'Church Admin R07 Search', roleKeys: ['church_admin'], mustChangePassword: false
  });
  const adminContext = loadUserContext(churchAdminUserId);
  const adminResults = search(adminContext, 'SEARCHABLE ADMIN ONLY');
  const adminAnnouncementGroup = adminResults.groups.find((g) => g.kind === 'announcement');
  assert.ok(adminAnnouncementGroup.results.some((r) => r.title.includes('SEARCHABLE ADMIN ONLY ANNOUNCEMENT')),
    'sanity: a genuine Church Admin must still find the announcement via search');
  console.log('PASS: search.js still correctly surfaces the announcement to an intended Church Admin');
}

db.close();
env.cleanup();
console.log('ALL PASS');
