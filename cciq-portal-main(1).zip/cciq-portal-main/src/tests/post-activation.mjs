import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { createIsolatedTestEnv, terminateAndWait } from './lib/test-env.mjs';

// Never import application modules until a NEW, disposable DB is selected.
const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-physical-test-');
const temp = env.root; // kept for the screenshot paths below
Object.assign(process.env, { KIOSK_SESSION_ABSOLUTE_DAYS: '30', SESSION_IDLE_TIMEOUT_MINUTES: '45' });
const { migrate } = await import('../db/migrate.js'); migrate();
const { default: db } = await import('../db/index.js');
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const attendance = await import('../services/attendance.js');
const qr = await import('../services/qr-checkin.js');
const family = await import('../services/family-groups.js');
const members = await import('../services/members.js');
const { safeRedirect } = await import('../lib/validate.js');
const { OVERFLOW_CHECK_SCRIPT } = await import('../../tools/check-overflow.mjs');
const password = () => crypto.randomBytes(24).toString('base64url') + 'a9!';
const credentials = {};
for (const [key, roles] of [['admin',['super_admin']],['k1',['kiosk']],['k2',['kiosk']],['hybrid',['kiosk','church_admin']],['denied',['member']]]) {
  credentials[key] = { password: password() };
  credentials[key].id = await users.createUser({ username: key, email: key+'@fixture.invalid', password: credentials[key].password, displayName:'Fixture '+key, roleKeys:roles });
}
for(let id=1;id<=20;id++) db.prepare(`INSERT INTO members(id,member_code,first_name,last_name,status,qr_token,created_at,updated_at)
 VALUES(?,?,?,?,?,?,?,?)`).run(id,'FIX-'+id,'Person'+id,'Fixture','active',crypto.randomBytes(24).toString('base64url'),'2026-01-01','2026-01-01');
members.changeStatus(1, 'temporarily_away', { userId: credentials.admin.id, reason: 'Isolated return-path fixture' });
const household=family.createFamilyGroup({name:'Fixture Household'});
family.addMemberToFamilyGroup(household.id,3);family.addMemberToFamilyGroup(household.id,4);
let server, browser, stdout='', stderr='';
const reserve=net.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));
const port=reserve.address().port;await new Promise(r=>reserve.close(r));process.env.PORT=String(port);
const base='http://127.0.0.1:'+port;
async function start(){ server=spawn(process.execPath,['src/server.js'],{cwd:root,env:process.env,windowsHide:true,stdio:['ignore','pipe','pipe']});server.stdout.on('data',d=>stdout+=d);server.stderr.on('data',d=>stderr+=d);for(let i=0;i<100;i++){if(server.exitCode!==null)throw new Error('Isolated server exited: '+stderr);try{if((await fetch(base+'/healthz')).ok)return;}catch{}await new Promise(r=>setTimeout(r,100));}throw new Error('Isolated startup timeout'); }
async function stop(){if(server)await terminateAndWait(server);}
const contexts=[];
let resetPassword;
const pageErrors=[];
async function context(){const ctx=await browser.newContext();contexts.push(ctx);return ctx;}
async function profileContext(profile,options={}){const ctx=await chromium.launchPersistentContext(profile,{channel:'chrome',headless:true,timeout:20000,...options});contexts.push(ctx);ctx.setDefaultTimeout(10000);ctx.setDefaultNavigationTimeout(10000);return ctx;}
async function csrf(ctx,url='/kiosk'){const res=await ctx.request.get(base+url);const html=await res.text();const token=html.match(/name="_csrf" value="([^"]+)"/)?.[1];assert(token,'CSRF token available');return token;}
async function login(ctx,key,next='/'){const token=await csrf(ctx,'/login');const res=await ctx.request.post(base+'/login',{form:{_csrf:token,email:key,password:credentials[key].password,next},maxRedirects:0});assert.equal(res.status(),302,'Login succeeds');return res;}
async function browserLogin(ctx,key){const page=ctx.pages()[0];await page.goto(base+'/login');await page.locator('input[name=email]').fill(key);await page.locator('input[name=password]').fill(credentials[key].password);await Promise.all([page.waitForURL(url=>url.pathname!=='/login'),page.getByRole('button',{name:'Sign in',exact:true}).click()]);}
async function getCount(ctx){return (await ctx.request.get(base+'/kiosk/count')).json();}
async function post(ctx,url,form){const body=new URLSearchParams({_csrf:await csrf(ctx)});for(const [name,value] of Object.entries(form))for(const entry of Array.isArray(value)?value:[value])body.append(name,String(entry));return ctx.request.post(base+url,{data:body.toString(),headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded'},maxRedirects:0});}
function age(key,ageMs,loginAge=0){for(const row of db.prepare('SELECT sid,sess FROM sessions').all()){const value=JSON.parse(row.sess);if(value.userId!==credentials[key].id)continue;value.lastSeenAt=Date.now()-ageMs;if(loginAge)value.loginAt=Date.now()-loginAge;db.prepare('UPDATE sessions SET sess=?,expires=? WHERE sid=?').run(JSON.stringify(value),Date.now()+86400000,row.sid);}}
function saved(key){return db.prepare('SELECT sess FROM sessions').all().map(r=>JSON.parse(r.sess)).filter(r=>r.userId===credentials[key].id);}
async function scan(page,id){const token=db.prepare('SELECT qr_token FROM members WHERE id=?').get(id).qr_token;await page.locator('#checkin-input').fill(token);await page.locator('#checkin-lookup').click();}
async function ready(page){if(await page.locator('#checkin-next').isVisible())await page.locator('#checkin-next').click();await page.locator('#checkin-input').waitFor({state:'visible'});}
async function expectedCount(page,n,timeout=22000){await page.waitForFunction(n=>document.querySelector('[data-kiosk-count]')?.textContent===String(n),n,{timeout});}
try {
 // Synthetic delegated user-administrator exercises the Super Admin guard itself.
 db.prepare("INSERT OR IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r,permissions p WHERE r.key='church_admin' AND p.key='admin.users'").run();
 await start(); browser=await chromium.launch({channel:'msedge',headless:true});
 const admin=await context(), kiosk=await context(), denied=await context(), limited=await context();
 await login(admin,'admin');await login(kiosk,'k1');await login(denied,'denied');await login(limited,'hybrid');
 const page=await admin.newPage();page.setDefaultTimeout(10000);page.on('pageerror',e=>pageErrors.push(e.message));page.on('dialog',d=>d.accept());
 const accountForm=page.locator('[data-user-account-form]');
 const createButton=page.getByRole('button',{name:'Create account',exact:true});
 // Reproduce the actual old picker/validation/loading interaction, with synthetic data.
 if(process.argv.includes('--reproduce-before')) {
 const snapshot=fs.readFileSync(path.join(os.tmpdir(),'cciq-physical-before-path.txt'),'utf8').trim();
 await page.route('**/js/app.js*',r=>r.fulfill({contentType:'application/javascript',body:fs.readFileSync(path.join(snapshot,'public/js/app.js'),'utf8')}));
 await page.goto(base+'/admin/users/new');await page.locator('[data-picker-input]').fill('Person1');await page.locator('[data-picker-input]').press('Enter');
 await page.waitForFunction(()=>document.querySelector('[data-user-account-form] .form__actions button').textContent==='Saving…');
 assert.deepEqual(await page.locator('[aria-invalid=true]').evaluateAll(els=>els.map(e=>e.id)),['display_name','email']);
 assert(await page.locator('[data-user-account-form] .form__actions button').isDisabled());
 console.log('REPRODUCED old picker Enter: invalid Name + Email; no save, but button stuck Saving');
 await page.unroute('**/js/app.js*');
 }
 await page.goto(base+'/admin/users/new');
 let posts=0;page.on('request',r=>{if(r.method()==='POST'&&new URL(r.url()).pathname==='/admin/users')posts++;});
 await page.locator('[data-picker-input]').fill('Person1');await page.locator('[data-picker-input]').press('Enter');await page.locator('[data-picker-results] [role=option]').first().waitFor();assert.equal(posts,0);assert(await createButton.isEnabled());
 await page.locator('[data-picker-results] [role=option]').filter({hasText:'FIX-1'}).first().click();assert.equal(await page.locator('[data-picker-value]').inputValue(),'1');
 await createButton.click();assert.equal(posts,0);assert(await createButton.isEnabled());assert.equal(await page.evaluate(()=>document.activeElement.id),'display_name');
 const messages=await accountForm.locator('.alert[data-live]').innerText();assert.match(messages,/Name:/);assert.match(messages,/Email:/);assert.equal(await page.locator('#email').getAttribute('aria-invalid'),'true');
 await page.setViewportSize({width:320,height:1000});await page.evaluate(()=>window.scrollTo({top:0,behavior:'instant'}));await page.screenshot({path:path.join(temp,'validation-320.png'),fullPage:true,animations:'disabled'});await page.setViewportSize({width:1280,height:1000});
 await page.locator('#display_name').fill('Person1 Fixture');await page.locator('#email').fill('created@fixture.invalid');await page.locator('#username').fill('admin');
 await page.locator('#role-member').uncheck();await page.locator('#role-super_admin').check();await createButton.click();await page.waitForURL(base+'/admin/users');assert(await createButton.isEnabled());assert.match(await page.locator('#username-error').innerText(),/already taken/);assert.equal(await page.locator('#email').inputValue(),'created@fixture.invalid');assert.equal(await page.locator('[data-picker-value]').inputValue(),'1');assert(await page.locator('#role-super_admin').isChecked());assert.equal(await page.evaluate(()=>document.activeElement.id),'username');
 // Hold the intentional POST briefly to observe loading and double-submit prevention.
 await page.locator('#username').fill('created_super');let release;const held=new Promise(r=>release=r);let intercepted=0;
 await accountForm.evaluate(f=>{const frame=document.createElement('iframe');frame.name='isolated-save';frame.hidden=true;document.body.appendChild(frame);f.target='isolated-save';});
 await page.route('**/admin/users',async route=>{if(route.request().method()==='POST'){intercepted++;await held;}await route.continue();});
 await createButton.click({noWaitAfter:true});await page.waitForFunction(()=>document.querySelector('[data-user-account-form] .form__actions button').disabled);
 assert.match(await page.locator('[data-user-account-form] .form__actions button').innerText(),/Saving/);await accountForm.evaluate(f=>f.requestSubmit());assert.equal(intercepted,1);const savedResponse=page.waitForResponse(r=>r.request().method()==='POST'&&r.url()===base+'/admin/users');release();await savedResponse;await page.unroute('**/admin/users');
 const created=users.findUserByIdentifier('created_super');assert.equal(created.member_id,1);assert.equal(created.display_name,'Person1 Fixture');assert.deepEqual(users.rolesForUser(created.id).map(r=>r.key),['super_admin']);assert(users.loadUserContext(created.id).can('admin.users'));
 await page.goto(base+'/admin/users/'+created.id);
 assert(await page.locator('#role-super_admin').isChecked());assert(await page.locator('#role-super_admin').isDisabled());assert(!await page.locator('body').innerText().then(t=>t.includes('[object Object]')));
 await page.getByRole('button',{name:'Update roles',exact:true}).click();assert(await page.locator('#role-super_admin').isEnabled());await page.locator('#role-member').check();await page.locator('[data-roles-cancel]').click();assert(!await page.locator('#role-member').isChecked());assert(await page.locator('#role-super_admin').isChecked());assert(await page.locator('#role-super_admin').isDisabled());
 await page.locator('[data-roles-edit]').click();await page.locator('#role-member').check();await page.locator('[data-roles-edit-actions] button[type=submit]').click();await page.waitForURL(base+'/admin/users/'+created.id);await page.reload();assert(await page.locator('#role-member').isChecked());assert(await page.locator('#role-member').isDisabled());assert.match(await page.locator('fieldset').filter({hasText:'Current roles on file'}).innerText(),/Super Admin/);
 const audit=JSON.parse(db.prepare("SELECT detail FROM audit_logs WHERE action='admin.user_updated' AND entity_id=? ORDER BY id DESC LIMIT 1").get(String(created.id)).detail);assert.deepEqual(audit.roles_from,['super_admin']);assert.deepEqual(new Set(audit.roles_to),new Set(['super_admin','member']));
 // Saving other fields while locked must preserve assigned roles.
 await page.locator('[data-user-account-form] .form__actions button[type=submit]').click();await page.waitForLoadState();assert.equal(users.rolesForUser(created.id).length,2);
 for(const role of ['member','kiosk']){await page.goto(base+'/admin/users/new');await page.locator('#display_name').fill('Created '+role);await page.locator('#email').fill(role+'new@fixture.invalid');await page.locator('#username').fill('created_'+role);if(role!=='member'){await page.locator('#role-member').uncheck();await page.locator('#role-'+role).check();}await createButton.click();await page.waitForURL(/\/admin\/users\/\d+(\?.*)?$/);const u=users.findUserByIdentifier('created_'+role);assert.deepEqual(users.rolesForUser(u.id).map(r=>r.key),[role]);assert(await page.locator('#role-'+role).isChecked());assert(await page.locator('#role-'+role).isDisabled());}
 // History restore resets any stale form lock; no new submission occurs.
 await page.goto(base+'/admin/users/new');await page.locator('#display_name').fill('History fixture');await page.locator('#email').fill('history@fixture.invalid');await page.locator('#username').fill('history_fixture');await createButton.click();await page.waitForURL(/\/admin\/users\/\d+(\?.*)?$/);await page.goBack();assert(await createButton.isEnabled());assert.equal(await createButton.innerText(),'Create account');
 // Direct requests exercise guards independently of disabled controls.
 const profile={display_name:'Fixture admin',email:'admin@fixture.invalid',roles:'member'};
 // R08/Codex: a delegated (non-Super-Admin) admin.users holder acting on a Super Admin
 // target now hits the centralized refuseIfProtectedTarget() guard first, which redirects
 // (like every other refused mutation on that route) rather than rendering a 400 validation
 // error - the target's role must remain unchanged.
 assert.equal((await post(limited,'/admin/users/'+credentials.admin.id,profile)).status(),302);
 assert(users.rolesForUser(credentials.admin.id).some(r=>r.key==='super_admin'));
 assert.equal((await post(limited,'/admin/users',{display_name:'No grant',email:'nogrant@fixture.invalid',roles:'super_admin'})).status(),400);
 assert.equal((await denied.request.get(base+'/admin/users',{maxRedirects:0})).status(),403);
 for(const u of db.prepare('SELECT id FROM users WHERE id<>?').all(credentials.admin.id))users.setUserStatus(u.id,'disabled');
 assert.equal((await post(admin,'/admin/users/'+credentials.admin.id,profile)).status(),400);assert(users.rolesForUser(credentials.admin.id).some(r=>r.key==='super_admin'));
 for(const u of db.prepare('SELECT id FROM users WHERE id<>?').all(credentials.admin.id))users.setUserStatus(u.id,'active');
 // Deactivating now eagerly destroys sessions (go-live session-versioning fix), so any context whose
 // account was disabled and reactivated above needs a fresh login before reuse.
 await login(kiosk,'k1');await login(denied,'denied');
 console.log('PASS User Admin validation/loading/picker/history, roles checked+locked/edit/cancel/save, three created roles, linked member, guards and audit');
 // Kiosk search cancellation keeps state; Clear resets by navigating to the ready kiosk.
 const kp=await kiosk.newPage();kp.setDefaultTimeout(10000);kp.on('pageerror',e=>pageErrors.push(e.message));await kp.goto(base+'/kiosk?q=Fixture');await kp.locator('input[name=person][value="member:3"]').check();await kp.getByRole('button',{name:'Review selected'}).click();await kp.getByRole('link',{name:'Cancel',exact:true}).click();assert.equal(await kp.locator('#checkin-search-input').inputValue(),'Fixture');assert(await kp.locator('input[name=person][value="member:3"]').isChecked());
 const countResponse=kp.waitForResponse(r=>r.url().endsWith('/kiosk/count'),{timeout:20000});await countResponse;assert(await kp.locator('input[name=person][value="member:3"]').isChecked());
 await kp.getByRole('link',{name:'Clear results',exact:true}).click();assert.equal(await kp.locator('#checkin-search-input').inputValue(),'');assert.equal(await kp.locator('input[name=person]:checked').count(),0);assert.equal(await kp.getByText('Select who is checking in',{exact:true}).count(),0);assert.equal(await kp.evaluate(()=>document.activeElement.id),'checkin-input');
 let lookups=0;kp.on('request',r=>{if(r.url().endsWith('/attendance/checkin/lookup'))lookups++;});const token=db.prepare('SELECT qr_token FROM members WHERE id=2').get().qr_token;
 await kp.locator('#checkin-input').fill(token);await kp.locator('#checkin-input').press('Enter');await kp.locator('#checkin-confirm-view').waitFor({state:'visible'});assert.equal(lookups,1);await kp.locator('#checkin-confirm').click();await expectedCount(kp,1,5000);await ready(kp);await scan(kp,2);await kp.waitForFunction(()=>document.querySelector('#checkin-success-message').textContent.includes('already'));assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE member_id=2').get().n,1);await ready(kp);
 await kp.route('**/attendance/checkin/lookup',async r=>{await new Promise(resolve=>setTimeout(resolve,300));await r.continue();});const beforeLookup=lookups;await kp.locator('#checkin-input').fill('invalid-fixture');await kp.locator('#checkin-input').press('Enter');await kp.locator('#checkin-input').press('Enter');await kp.locator('#checkin-error').waitFor({state:'visible'});assert.equal(lookups,beforeLookup+1);assert.equal(await kp.evaluate(()=>document.activeElement.id),'checkin-input');await kp.unroute('**/attendance/checkin/lookup');
 await kp.goto(base+'/kiosk?q=Fixture');await scan(kp,3);await kp.locator('#checkin-family-view').waitFor({state:'visible'});await kp.locator('#checkin-family-cancel').click();await kp.getByRole('link',{name:'Clear results',exact:true}).click();assert.equal(await kp.locator('#checkin-family-list input').count(),0);
 console.log('PASS Kiosk Cancel/Clear, polling preservation, scanner Enter/manual, overlapping lookup guard, invalid QR and duplicate attendance');
 // Archive with attendance and household dependencies uses the ordinary status route.
 const sid=qr.checkinSession().id;attendance.recordAttendance(sid,[{memberId:3,status:'present'}],{userId:credentials.admin.id});
 const beforeRecords=db.prepare('SELECT * FROM attendance_records ORDER BY id').all();const beforeFamily=db.prepare('SELECT * FROM family_group_members ORDER BY rowid').all();
 await page.goto(base+'/members/3/delete');assert.equal(await page.getByRole('button',{name:'Delete Member Record',exact:true}).count(),0);
 assert.equal((await post(admin,'/members/3/delete',{reason:'test'})).status(),400);
 await page.getByRole('button',{name:'Archive Member instead',exact:true}).click();await page.waitForURL(/\/members\/3\?tab=history/);assert.equal(db.prepare('SELECT status FROM members WHERE id=3').get().status,'archived');assert.deepEqual(db.prepare('SELECT * FROM attendance_records ORDER BY id').all(),beforeRecords);assert.deepEqual(db.prepare('SELECT * FROM family_group_members ORDER BY rowid').all(),beforeFamily);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM member_status_history WHERE member_id=3 AND new_status='archived' AND changed_by=?").get(credentials.admin.id).n,1);assert(db.prepare("SELECT id FROM audit_logs WHERE entity_id='3' AND action='member.status_changed' AND user_id=?").get(credentials.admin.id));
 assert.equal((await post(denied,'/members/4/status',{status:'archived'})).status(),403);
 await page.goto(base+'/members/4?tab=church');await page.locator('#status').selectOption('archived');await page.getByRole('button',{name:'Save status',exact:true}).click();await page.waitForURL(/tab=history/);assert.equal(db.prepare('SELECT status FROM members WHERE id=4').get().status,'archived');
 assert.equal((await post(admin,'/members/20/delete',{reason:'test'})).status(),302);assert.equal(db.prepare('SELECT id FROM members WHERE id=20').get(),undefined);
 console.log('PASS archive, dependencies/history/audit, permission enforcement, manual status and legitimate dependency-free delete');
 // Only affected screens: keep the approved Quick Access layout unchanged.
 for(const url of ['/kiosk?q=Fixture','/members/3/delete','/admin/users/new','/admin/users/'+created.id]){await page.goto(base+url);for(const width of [320,390,820,1280]){await page.setViewportSize({width,height:1000});const result=await page.evaluate(OVERFLOW_CHECK_SCRIPT);assert.equal(result.overflow,false,url+' at '+width);await page.screenshot({path:path.join(temp,url.replace(/[^a-z0-9]/gi,'_')+'-'+width+'.png'),fullPage:true,animations:'disabled'});}}console.log('PASS four affected screens at 320/390/820/1280');
 assert.deepEqual(pageErrors,[]);assert.equal(db.prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1').get().version,(await import('../db/migrate.js')).EXPECTED_MIGRATIONS.at(-1));console.log('Artifacts: '+temp);
} finally {for(const ctx of contexts)await ctx.close().catch(()=>{});if(browser)await browser.close();await stop();db.close();}
