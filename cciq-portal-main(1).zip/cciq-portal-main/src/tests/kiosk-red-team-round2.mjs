import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Kiosk, round 2 (kiosk-red-team.mjs holds round 1: search shapes, every route with every id, every state-changing route with CSRF).
 * This round attacks what round 1 does not:
 *   1. the scanner endpoint with hostile, huge and repeated payloads, and a forged confirm;
 *   2. the optional "Invited by" added to Express Registration: forged ids and arrays, what the search can be made to reveal, and how fast it can be
 *      walked (characterized, not limited here);
 *   3. both Kiosk accounts behave identically, byte for byte, on every screen they own;
 *   4. an error inside the Kiosk's own paths keeps the kiosk layout and offers only the kiosk home;
 *   5. in a real browser: the scan field regains focus after every transition (a refused scan, Next check-in, Cancel, a search and back, a
 *      click on empty space) and a scan typed straight after a page change lands in the scan field.
 */

const f = await buildPortalFixture('cciq-kiosk-r2-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const kioskA = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
await mods.users.createUser({ username: 'fx_kiosk_b', email: 'fx_kiosk_b@fixture.invalid', password: f.PASSWORD, displayName: 'fx_kiosk', roleKeys: ['kiosk'], mustChangePassword: false });
const kioskB = await signIn(portal.base, 'fx_kiosk_b@fixture.invalid', f.PASSWORD);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const post = (path, fields, who = kioskA, opts = {}) => who.post(path, fields, { csrfFrom: '/kiosk', ...opts });
const SECRETS = /(SqliteError|SQLITE_|\bat \S+ \(|node_modules|\.js:\d+|password_hash)/;

try {
  // ---- 1. the scanner endpoint ---------------------------------------------------------------------------------------------------------
  {
    const before = count('SELECT COUNT(*) n FROM attendance_records');
    const tokens = ['', ' ', 'x', '0'.repeat(32), 'A'.repeat(5000), '%00', 'a\u0000b', "'; DROP TABLE members; --", '{"a":1}', '<script>', '../../etc/passwd', '‮', '😀'.repeat(300), 'null', 'undefined', '[object Object]', '\n\r'];
    for (const token of tokens) {
      const res = await post('/attendance/checkin/lookup', { token }); const text = await res.text();
      assert.ok([400, 404, 410].includes(res.status), `token ${JSON.stringify(token).slice(0, 20)} -> ${res.status}`);
      assert.doesNotMatch(text, SECRETS, 'no internals');
      assert.ok(/application\/json/.test(res.headers.get('content-type') || ''), 'a scanner always gets JSON back');
    }
    // arrays and repeated fields
    for (const body of ['token=a&token=b', 'token[]=a', 'token[a]=b', 'token=a&token[]=b']) {
      const csrf = await kioskA.csrf('/kiosk');
      const res = await fetch(`${portal.base}/attendance/checkin/lookup`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskA.cookie }, body: `_csrf=${encodeURIComponent(csrf)}&${body}` }); await res.text();
      assert.ok(res.status < 500, `${body} -> ${res.status}`);
    }
    // an oversized payload is refused by the body limit
    const csrf = await kioskA.csrf('/kiosk');
    const big = await fetch(`${portal.base}/attendance/checkin/lookup`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskA.cookie }, body: `_csrf=${encodeURIComponent(csrf)}&token=${'z'.repeat(2_000_000)}` }); await big.text();
    assert.ok([400, 413].includes(big.status), `a 2 MB scan is refused (${big.status})`);
    // many scans in a row: the server keeps answering and stays fast
    const started = Date.now();
    for (let i = 0; i < 300; i += 1) { const res = await post('/attendance/checkin/lookup', { token: `bad-${i}` }, kioskA, { csrf }); await res.text(); assert.ok(res.status < 500); }
    assert.ok(Date.now() - started < 30000, `300 refused scans took ${Date.now() - started} ms`);
    // a forged confirmation cannot write for a stale, foreign or invented session or member
    for (const fields of [{ member_id: String(ids.member.a2), session_id: '999999' }, { member_id: '999999', session_id: String(ids.session) }, { member_id: 'abc', session_id: 'abc' }, { member_id: '0', session_id: '0' }, { member_id: `${ids.member.a2}`, session_id: String(ids.meeting) }]) {
      const res = await post('/attendance/checkin/confirm', fields); await res.text();
      assert.ok(res.status >= 400 && res.status < 500, `forged confirm ${JSON.stringify(fields)} -> ${res.status}`);
    }
    assert.equal(count('SELECT COUNT(*) n FROM attendance_records'), before, 'and no attendance was written by any of it');
    assert.equal((await kioskA.get('/kiosk')).status, 200, 'the Kiosk is still up');
    console.log('PASS (1) hostile, huge, repeated and array scanner payloads are refused as JSON with no internals; 300 refused scans are fast; forged confirmations write nothing');
  }

  // ---- 2. Invited by -------------------------------------------------------------------------------------------------------------------
  {
    const reg = (fields, who = kioskA) => post('/attendance/checkin/first-timer', { kiosk: '1', ...fields }, who);
    const before = count('SELECT COUNT(*) n FROM visitors');
    for (const bad of ['0', '-1', 'abc', '1e3', '99999999', '9'.repeat(30), ' ', '१२']) {
      const res = await reg({ first_name: `Tamper${before}${bad.length}`, invited_by_member_id: bad }); const text = await res.text();
      assert.ok(res.status === 400 || (bad.trim() === '' && res.status === 302), `inviter ${JSON.stringify(bad)} -> ${res.status}`);
      assert.doesNotMatch(text, SECRETS);
    }
    // repeated / array inviter fields: never an inviter nobody chose
    const csrf = await kioskA.csrf('/kiosk');
    for (const body of ['invited_by_member_id=1&invited_by_member_id=2', 'invited_by_member_id[]=1', 'invited_by_member_id[a]=1']) {
      const res = await fetch(`${portal.base}/attendance/checkin/first-timer`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskA.cookie }, body: `_csrf=${encodeURIComponent(csrf)}&kiosk=1&first_name=Arr${body.length}&${body}` }); await res.text();
      assert.ok(res.status < 500, `${body} -> ${res.status}`);
    }
    // forged override, role and permission fields are ignored
    const dupFirst = await reg({ first_name: 'Overrider', last_name: 'Test' }); await dupFirst.text();
    const dup = await reg({ first_name: 'Overrider', last_name: 'Test', duplicate_override: '1', override: '1', force: '1', roles: 'super_admin', permissions: 'members.create', role: 'church_admin' }); const dupText = await dup.text();
    assert.equal(dup.status, 409, 'the duplicate warning cannot be overridden from the Kiosk'); assert.doesNotMatch(dupText, /Overrider Test/, 'and names nobody');
    assert.equal(count("SELECT COUNT(*) n FROM visitors WHERE first_name = 'Overrider'"), 1);
    assert.equal(db.prepare("SELECT COUNT(*) n FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.key <> 'kiosk'").get(users.kiosk.id).n, 0, 'no role or permission was granted');
    // redirects: a hostile return address changes nothing
    for (const extra of [{ next: 'https://evil.example' }, { return_to: '//evil.example' }, { back: 'javascript:alert(1)' }, { redirect: '/admin' }]) {
      const res = await reg({ first_name: `Redirect${Object.keys(extra)[0]}`, ...extra }); await res.text();
      assert.ok(res.status === 302 && res.headers.get('location') === '/attendance/checkin/first-timer/done', `${JSON.stringify(extra)} -> ${res.headers.get('location')}`);
    }
    // what the inviter search can reveal, and how it can be walked
    const search = async (q) => { const res = await kioskA.get(`/attendance/checkin/inviter-search?q=${encodeURIComponent(q)}`); return res.status === 200 ? res.json() : res.status; };
    for (const q of ['%', '_', '%%%', '\\', 'a\u0000', 'An%']) { const r = await search(q); assert.ok(Array.isArray(r) || typeof r === 'number', `search ${JSON.stringify(q)} answers`); if (Array.isArray(r)) assert.ok(r.every((x) => Object.keys(x).sort().join() === 'id,name'), 'names only'); }
    assert.deepEqual(await search('%%%'), [], 'a wildcard is not a way to list everyone');
    // Walking the member list: every member whose first or last name starts with three typed letters is returned (names only, 8 at most).
    const everyone = new Set(); let requests = 0;
    for (const m of db.prepare("SELECT first_name, last_name FROM members").all()) for (const prefix of new Set([m.first_name.slice(0, 3), m.last_name.slice(0, 3)])) { requests += 1; const r = await search(prefix); if (Array.isArray(r)) r.forEach((x) => everyone.add(x.name)); }
    assert.ok(everyone.size >= 5, 'the search does find people by a typed prefix (it is meant to)');
    console.log(`INFO characterization: ${requests} three-letter prefixes revealed ${everyone.size} member names (at most 8 per request, names only; no phone, Member ID, group or photo). The portal's general rate limit is the only brake on walking the list; whether the Kiosk should be stricter is an owner decision.`);
    console.log('PASS (2) forged, malformed and repeated inviter ids, a forged override and role fields, and hostile return addresses change nothing; the inviter search is names-only and a wildcard lists nobody');
  }

  // ---- 3. both Kiosk accounts are identical -----------------------------------------------------------------------------------------------
  {
    const norm = (html) => html.replace(/name="_csrf" value="[^"]+"/g, 'name="_csrf" value="X"').replace(/data-csrf="[^"]+"/g, 'data-csrf="X"').replace(/\?v=[0-9a-f]+/g, '?v=V').replace(/content="[^"]*"/g, 'content=""');
    for (const url of ['/kiosk', '/attendance/checkin', '/attendance/checkin/first-timer', '/kiosk/count', '/account/password']) {
      const a = await kioskA.get(url); const b = await kioskB.get(url);
      assert.equal(a.status, b.status, `${url}: same status`); assert.equal(a.headers.get('location'), b.headers.get('location'), `${url}: same redirect`);
      assert.equal(norm(await a.text()), norm(await b.text()), `${url}: the same page for both accounts`);
    }
    const permsOf = (u) => db.prepare('SELECT DISTINCT p.key FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id JOIN permissions p ON p.id = rp.permission_id WHERE ur.user_id = ? ORDER BY p.key').all(u).map((r) => r.key);
    const idB = db.prepare("SELECT id FROM users WHERE username = 'fx_kiosk_b'").get().id;
    assert.deepEqual(permsOf(users.kiosk.id), permsOf(idB), 'the same permissions');
    // and they are refused the same things
    for (const url of ['/members', '/visitors', '/reports', '/admin/settings', '/documents', '/admin/users', '/admin/ecaq', `/members/${ids.member.a2}`, `/visitors/${ids.visitor}`]) {
      const a = await kioskA.get(url); const b = await kioskB.get(url); await a.text(); await b.text();
      assert.deepEqual([a.status, a.headers.get('location')], [b.status, b.headers.get('location')], `${url}: refused the same way`);
      assert.equal(a.headers.get('location'), '/kiosk');
    }
    console.log('PASS (3) both Kiosk accounts get the same pages, the same permissions and the same refusals');
  }

  // ---- 4. error pages stay in the kiosk layout --------------------------------------------------------------------------------------------
  {
    for (const [label, res] of [['a missing kiosk path', await kioskA.get('/attendance/checkin/no-such-thing')], ['a missing scan route', await kioskA.get('/attendance/checkin/lookup')],
      ['a forbidden post', await fetch(`${portal.base}/attendance/checkin/search`, { method: 'POST', redirect: 'manual', headers: { Cookie: kioskA.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'q=x' })]]) {
      const text = await res.text();
      assert.ok(res.status >= 400 || res.status === 302, `${label}: ${res.status}`);
      if (res.status >= 400) {
        assert.match(text, /<body class="kiosk"/, `${label}: the error page is the kiosk layout`);
        assert.doesNotMatch(text, /class="sidenav"|href="\/members"|href="\/reports"|href="\/admin/, `${label}: no administrative menu`);
        assert.match(text, /href="\/kiosk"/, `${label}: the only way out is the kiosk home`);
      }
    }
    console.log('PASS (4) errors inside the Kiosk\'s own paths are kiosk-layout pages whose only link is the kiosk home');
  }

  // ---- 5. the scan field in a real browser ---------------------------------------------------------------------------------------------------
  {
    const browser = await chromium.launch({ channel: 'msedge', headless: true });
    try {
      const context = await browser.newContext({ viewport: { width: 1024, height: 768 } });
      await context.addCookies(kioskA.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
      const page = await context.newPage();
      const focused = () => page.evaluate(() => document.activeElement && document.activeElement.id);
      await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
      assert.equal(await focused(), 'checkin-input', 'on arrival');
      // a refused scan
      await page.keyboard.type('NOTACODE'); await page.keyboard.press('Enter');
      await page.waitForSelector('#checkin-error:not(.is-hidden)', { timeout: 5000 });
      assert.equal(await focused(), 'checkin-input', 'after a refused scan the scan field still has focus');
      assert.equal(await page.inputValue('#checkin-input'), '', 'and it is cleared and ready for the next scan, with the refusal shown beside it');
      assert.ok(await page.locator('#checkin-error').isVisible());
      // a click on empty space
      await page.mouse.click(40, 600);
      assert.equal(await focused(), 'checkin-input', 'after a click on empty space');
      // a search, then back to the scan screen
      await page.fill('#checkin-search-input', 'Anna');
      await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.click('.kiosk__search-form button[type=submit]')]);
      await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.click('a:has-text("Clear results")')]);
      assert.equal(await focused(), 'checkin-input', 'after a search and Clear results');
      // a scan typed immediately after a navigation lands in the scan field, not nowhere
      await page.goto(`${portal.base}/kiosk`, { waitUntil: 'commit' });
      await page.waitForSelector('#checkin-input', { state: 'attached' });
      await page.keyboard.type('FASTSCAN');
      assert.equal(await page.inputValue('#checkin-input'), 'FASTSCAN', 'a scan typed as the page appears is not lost');
      // the registration page opens in its own tab (the kiosk tab keeps focus on its scan field), and Cancel there goes back to the kiosk home
      const [reg] = await Promise.all([page.context().waitForEvent('page'), page.click('a[href="/attendance/checkin/first-timer"]')]);
      await reg.waitForLoadState('load');
      assert.equal(await focused(), 'checkin-input', 'the scan field keeps focus while the registration tab is open');
      await Promise.all([reg.waitForNavigation({ waitUntil: 'load' }), reg.click('a:has-text("Cancel")')]);
      assert.equal(new URL(reg.url()).pathname, '/kiosk', 'Cancel in the registration tab returns to the kiosk');
      await reg.close();
      await page.bringToFront();
      assert.equal(await focused(), 'checkin-input', 'after the registration tab and Cancel');
      // the browser Back button
      await page.goto(`${portal.base}/kiosk?q=ab`, { waitUntil: 'load' }); // a second screen in this tab's history, so Back has somewhere to go
      await page.goBack({ waitUntil: 'load' });
      await page.goForward({ waitUntil: 'load' });
      assert.equal(await focused(), 'checkin-input', 'after Back and Forward');
      await context.close();
    } finally { await browser.close(); }
    console.log('PASS (5) in a real browser the scan field has focus on arrival, after a refused scan, an empty click, a search, Cancel, Back and Forward, and a scan typed as the page appears is kept');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
