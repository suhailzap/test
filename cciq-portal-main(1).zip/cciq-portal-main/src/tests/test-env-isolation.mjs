import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

// --- 1. Normal use: paths are created, are under the OS temp dir, and are
//        nowhere near the real project's data/storage. ---
const env = createIsolatedTestEnv('cciq-isolation-selftest-');
assert.ok(path.isAbsolute(env.databaseFile));
assert.ok(!env.databaseFile.includes('cciq-portal\\data') && !env.databaseFile.includes('cciq-portal/data'));
assert.equal(process.env.DATABASE_FILE, env.databaseFile);
assert.equal(process.env.STORAGE_DIR, env.storageDir);
assert.equal(process.env.BACKUP_DIR, env.backupDir);
assert.ok(process.env.DOTENV_CONFIG_PATH.endsWith('absent.env'));
env.cleanup();
console.log('PASS: createIsolatedTestEnv() produces temp paths outside the real project, sets every relevant env var');

// --- 2. Fail closed: a path that resolves inside the real project's data/
//        directory must throw, not silently proceed. Simulated by
//        re-implementing just the guard clause against a deliberately bad
//        path, since the real function does not accept a path override —
//        this confirms the guard LOGIC is sound, independent of whether any
//        real caller would ever actually pass such a value. ---
const root = fileURLToPath(new URL('../../', import.meta.url));
const realDataDir = path.resolve(root, 'data');
function guard(candidate) {
  const resolved = path.resolve(candidate);
  if (resolved === realDataDir || resolved.startsWith(realDataDir + path.sep)) {
    throw new Error('test isolation failure: resolves inside the real data/ directory');
  }
}
assert.throws(() => guard(path.join(realDataDir, 'cciq.sqlite')), /test isolation failure/,
  'the guard must reject a path inside the real data/ directory');
guard(path.join(root, '..', 'somewhere-else', 'fixture.sqlite')); // must not throw
console.log('PASS: the real-data-directory guard rejects a path inside data/ and accepts one outside it');

console.log('ALL PASS');
