import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * A smoke test for scale, not a benchmark: the church today is a few hundred people, so this builds roughly three times that
 * (1,000 members, 1,000 First Timers, 12,000 audit rows, 600 reminders, a year of Fridays with 1,000 marks each) and opens every
 * list, report, export and search once. Each must answer correctly and within a generous ceiling - a page that takes seconds here
 * has a query that grows faster than the data. The measured times are printed so a trend is visible from run to run.
 */

// CCIQ_PERF_SCALE=10 builds ten times the data (10,000 members and First Timers, 120,000 audit rows, about 400,000 marks); the suite runs at 1.
const SCALE = Math.max(1, Number(process.env.CCIQ_PERF_SCALE) || 1);
const f = await buildPortalFixture('cciq-perf-');
const { db, users, mods } = f;
const today = mods.dates.today();
const now = new Date().toISOString();
const t0 = Date.now();

db.transaction(() => {
  const insertMember = db.prepare("INSERT INTO members (member_code, first_name, last_name, status, phone, email, cell_group_id, date_of_birth, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  const groups = db.prepare('SELECT id FROM cell_groups').all().map((g) => g.id);
  const statuses = ['active', 'active', 'active', 'active', 'inactive', 'pending', 'temporarily_away', 'attendee', 'bonafide', 'archived'];
  for (let i = 0; i < 1000 * SCALE; i += 1) {
    const month = String((i % 12) + 1).padStart(2, '0'); const day = String((i % 27) + 1).padStart(2, '0');
    insertMember.run(`CCIQ-P${String(i).padStart(5, '0')}`, `First${i % 173}`, `Last${i % 211}`, statuses[i % statuses.length], `+974 5000 ${String(i).padStart(4, '0')}`, `p${i}@fixture.invalid`, groups[i % groups.length] ?? null, `19${60 + (i % 40)}-${month}-${day}`, now, now);
  }
  const insertVisitor = db.prepare("INSERT INTO visitors (first_name, last_name, phone, first_visit_date, state, follow_up_state, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'new', ?, ?)");
  const insertVisit = db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, recorded_at) VALUES (?, ?, ?)');
  const vStates = ['new', 'returning', 'not_returned', 'declined'];
  for (let i = 0; i < 1000 * SCALE; i += 1) {
    const date = mods.dates.addDays(today, -(i % 300));
    const id = Number(insertVisitor.run(`Guest${i % 97}`, `Visitor${i}`, `+974 6000 ${String(i).padStart(4, '0')}`, date, vStates[i % 4], now, now).lastInsertRowid);
    insertVisit.run(id, date, now);
    if (i % 3 === 0) insertVisit.run(id, mods.dates.addDays(date, 7), now);
  }
  const audit = db.prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, result, detail, ip_address, created_at) VALUES (?, ?, 'member', ?, 'success', ?, '127.0.0.1', ?)");
  const actions = ['member.updated', 'auth.login', 'attendance.recorded', 'visitor.created', 'document.downloaded', 'giving.claim_created'];
  for (let i = 0; i < 12000 * SCALE; i += 1) audit.run(users.churchAdmin.id, actions[i % actions.length], String(i), '{"n":1}', new Date(Date.now() - i * 60000).toISOString());
  const reminder = db.prepare("INSERT INTO reminders (reminder_type, member_id, title, detail, due_date, state, dedupe_key, created_at, updated_at) VALUES ('birthday', ?, ?, 'x', ?, ?, ?, ?, ?)");
  const ids = db.prepare('SELECT id FROM members LIMIT ' + (600 * SCALE)).all();
  ids.forEach((m, i) => reminder.run(m.id, `Birthday ${i}`, mods.dates.addDays(today, i % 90), i % 5 === 0 ? 'completed' : 'new', `perf-${i}`, now, now));
  // a year of Fridays, each with marks for most of the congregation
  const session = db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)");
  const friday = mods.dates.lastFridayOnOrBefore(today);
  for (let w = 0; w < 52; w += 1) session.run(mods.dates.addDays(friday, -7 * w), now);
  db.exec(`INSERT OR IGNORE INTO attendance_records (session_id, member_id, status, recorded_at, source)
           SELECT s.id, m.id, CASE WHEN ((m.id * 7 + s.id * 13) % 10) < 7 THEN 'present' ELSE 'absent' END, '${now}', 'manual'
             FROM attendance_sessions s CROSS JOIN members m
            WHERE s.service_type = 'friday_service' AND m.status IN ('active','pending','attendee','bonafide')`);
})();
// Track and finalize the whole year, as a church that has been using attendance tracking would have: every member needs a status
// history that starts before tracking, and each Friday is finalized (which builds its expected-roster snapshot).
const lifecycle = await import('../services/attendance-lifecycle.js');
const tFinal = Date.now();
db.exec(`INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at)
         SELECT id, NULL, status, 'fixture', '2020-01-01T00:00:00.000Z' FROM members WHERE id NOT IN (SELECT member_id FROM member_status_history)`);
db.exec("UPDATE member_status_history SET changed_at = '2020-01-01T00:00:00.000Z'");
db.exec("UPDATE attendance_sessions SET created_at = '2020-01-01T00:00:00.000Z'");
db.exec("UPDATE members SET created_at = '2020-01-01T00:00:00.000Z'");
const sessionsOldestFirst = db.prepare("SELECT id, service_date FROM attendance_sessions WHERE service_type = 'friday_service' AND service_date <= ? ORDER BY service_date").all(today);
assert.ok(lifecycle.setTrackingStartDate(sessionsOldestFirst[0].service_date, { userId: users.superAdmin.id }).ok);
let finalized = 0;
const failures = new Set();
for (const session of sessionsOldestFirst) { const r = lifecycle.finalizeAttendance(session.id, { userId: users.superAdmin.id, confirmNoAttendance: true }); if (r.ok) finalized += 1; else failures.add(r.reason + (r.ambiguous ? " x" + r.ambiguous.length : "")); }
if (failures.size) console.log("INFO finalize refused:", [...failures].join(", "));
console.log(`INFO tracked and finalized ${finalized} Fridays (${((Date.now() - tFinal) / 1000).toFixed(1)}s)`);
assert.ok(finalized >= 40, `a year of Fridays was finalized (${finalized})`);
const counts = {
  members: db.prepare('SELECT COUNT(*) n FROM members').get().n,
  visitors: db.prepare('SELECT COUNT(*) n FROM visitors').get().n,
  audit: db.prepare('SELECT COUNT(*) n FROM audit_logs').get().n,
  reminders: db.prepare('SELECT COUNT(*) n FROM reminders').get().n,
  marks: db.prepare('SELECT COUNT(*) n FROM attendance_records').get().n
};
console.log(`INFO dataset built in ${((Date.now() - t0) / 1000).toFixed(1)}s: ${JSON.stringify(counts)}`);
assert.ok(counts.members >= 1000 && counts.visitors >= 1000 && counts.audit >= 12000 && counts.marks >= 30000);
counts.expectedRosterRows = db.prepare('SELECT COUNT(*) n FROM attendance_expected').get().n;

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const someMember = db.prepare("SELECT id FROM members WHERE member_code = 'CCIQ-P00500'").get().id;
  const someVisitor = db.prepare('SELECT id FROM visitors ORDER BY id LIMIT 1 OFFSET 500').get().id;
  const pages = [
    ['dashboard', '/'], ['members list', '/members'], ['members page 20', '/members?page=20&page_size=50'], ['members search', '/members?q=Last17'],
    ['members by status', '/members?status=active&status=pending'], ['member record', `/members/${someMember}`], ['member attendance tab', `/members/${someMember}?tab=attendance`],
    ['birthdays', '/members/birthdays'], ['congregations', '/members/congregations'], ['first timers', '/visitors'], ['first timers search', '/visitors?q=Guest9'],
    ['first timer follow-up', '/visitors/follow-up'], ['first timer record', `/visitors/${someVisitor}`], ['attendance landing', '/attendance'], ['attendance history', '/attendance/history'],
    ['follow-up list', '/attendance/follow-up'], ['long absence', '/attendance/long-absence'], ['attendance reports', '/attendance/reports'], ['reports home', '/reports'],
    ['attendance overview', '/reports/attendance'], ['membership overview', '/reports/membership'], ['cell groups overview', '/reports/cell-groups'], ['audit log', '/admin/audit'],
    ['audit page 100', '/admin/audit?page=100&page_size=100'], ['audit by action', '/admin/audit?action=member.updated'], ['reminders', '/reminders'], ['global search', '/search?q=Last17'],
    ['calendar', '/calendar'], ['ministries serving', '/ministries/serving'], ['cell groups', '/cell-groups'], ['users', '/admin/users'], ['check-in search', '/attendance/checkin?q=First1'],
    ['members CSV', '/members/export.csv'], ['audit CSV', '/admin/audit.csv'], ['attendance CSV', '/attendance/reports/export.csv'], ['directory PDF', '/reports/directory/pdf?statuses_submitted=1&status=active'],
    ['attendance PDF', '/reports/attendance/pdf'], ['long absence PDF', '/reports/long-absence/pdf']
  ];
  const CEILING_MS = 4000;
  const timings = [];
  for (const [label, url] of pages) {
    const started = Date.now();
    const res = await admin.get(url);
    const bytes = (await res.arrayBuffer()).byteLength;
    const ms = Date.now() - started;
    timings.push({ label, ms, status: res.status, kb: Math.round(bytes / 1024) });
    assert.equal(res.status, 200, `${label} (${url}) answers 200 at this size`);
    assert.ok(ms < CEILING_MS, `${label} answers within ${CEILING_MS} ms at this size (took ${ms} ms)`);
  }
  const slowest = timings.slice().sort((a, b) => b.ms - a.ms).slice(0, 8);
  console.log(`INFO slowest: ${slowest.map((t) => `${t.label} ${t.ms}ms/${t.kb}KB`).join(' | ')}`);
  console.log(`INFO total ${timings.reduce((t, x) => t + x.ms, 0)}ms for ${timings.length} requests`);

  // the pages are still bounded in size (paging): a 1,000-row list is not sent whole
  const list = timings.find((t) => t.label === 'members list');
  assert.ok(list.kb < 400, `the members list is one page, not all 1,000 rows (${list.kb} KB)`);
  const audit = timings.find((t) => t.label === 'audit log');
  assert.ok(audit.kb < 400, `the audit log is one page of 12,000 rows (${audit.kb} KB)`);

  // the hot queries use an index (a full scan of a big table on every page view is what slows a list down as it grows)
  const plan = (sql, ...params) => db.prepare(`EXPLAIN QUERY PLAN ${sql}`).all(...params).map((r) => r.detail).join(' | ');
  const scans = [];
  for (const [label, sql, params] of [
    ['member by status', "SELECT id FROM members WHERE status = 'active' LIMIT 25", []],
    ['member by cell group', 'SELECT id FROM members WHERE cell_group_id = 1', []],
    ['member by surname', "SELECT id FROM members ORDER BY last_name, first_name LIMIT 25", []],
    ['marks for a member', 'SELECT id FROM attendance_records WHERE member_id = 5', []],
    ['marks for a session', 'SELECT id FROM attendance_records WHERE session_id = 5', []],
    ['visits for a first timer', 'SELECT id FROM visitor_visits WHERE visitor_id = 5', []],
    ['first timers by date', "SELECT id FROM visitors WHERE first_visit_date >= '2026-01-01'", []],
    ['audit newest first', 'SELECT id FROM audit_logs ORDER BY created_at DESC LIMIT 50', []],
    ['audit by action', "SELECT id FROM audit_logs WHERE action = 'member.updated' LIMIT 50", []],
    ['status history for a member', 'SELECT id FROM member_status_history WHERE member_id = 5 ORDER BY changed_at', []],
    ['sessions by date', "SELECT id FROM attendance_sessions WHERE service_date >= '2026-01-01'", []],
    ['notifications for a user', 'SELECT id FROM notifications WHERE user_id = 1 AND read_at IS NULL', []]
  ]) {
    const detail = plan(sql, ...params);
    if (/\bSCAN\b/.test(detail) && !/USING (COVERING )?INDEX/.test(detail)) scans.push(`${label}: ${detail}`);
  }
  console.log(`INFO queries that scan a whole table: ${scans.length ? '\n   ' + scans.join('\n   ') : 'none'}`);
  assert.deepEqual(scans, [], 'every hot lookup uses an index');
  console.log('PASS (performance) every list, report, export and search answers correctly and quickly on 3x today\'s data; pages stay one page long; hot lookups use an index');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
