import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * Cheap guards on the single stylesheet so it cannot drift into trouble: balanced, one :root, !important kept rare (it beats the
 * cascade and makes later fixes harder), and repeated top-level rules kept in check. Not a rewrite: the stylesheet is large and
 * working, so this only stops it getting worse. Design tokens are covered by css-design-tokens.mjs, contrast by css-contrast.mjs.
 */

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public', 'css', 'cciq.css');
const css = fs.readFileSync(file, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
assert.equal((css.match(/\{/g) || []).length, (css.match(/\}/g) || []).length, 'braces balance');
assert.equal((css.match(/\(/g) || []).length, (css.match(/\)/g) || []).length, 'parentheses balance');
assert.equal((css.match(/:root\s*\{/g) || []).length, 1, 'exactly one :root block holds the tokens');
const important = (css.match(/!important/g) || []).length;
assert.ok(important <= 20, `!important stays rare (${important} now; the limit is 20 - raise it only with a reason)`);

const top = []; let depth = 0; let buffer = '';
for (const ch of css) {
  if (ch === '{') { if (depth === 0) top.push(buffer.trim()); depth += 1; buffer = ''; } else if (ch === '}') { depth -= 1; buffer = ''; } else if (depth === 0) buffer += ch;
}
const counts = new Map(); for (const s of top) counts.set(s, (counts.get(s) || 0) + 1);
const repeated = [...counts].filter(([s, n]) => n > 1 && !s.startsWith('@')).map(([s]) => s);
assert.ok(repeated.length <= 12, `top-level rules repeated under the same selector stay few (${repeated.length}: ${repeated.join(', ')})`);
assert.ok(!/[^\w-]\.\.[\w]/.test(css), 'no double-dot selectors');
console.log(`PASS (css) balanced, one :root, ${important} !important (limit 20), ${repeated.length} repeated selectors (limit 12): ${repeated.join(', ')}`);
console.log('ALL PASS');
