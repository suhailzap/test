import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { likePattern, escapeLike } from '../lib/like.js';

/*
 * Every search box means what was typed. "%" and "_" are wildcards to SQL LIKE, so unescaped they match everything; a
 * search for "50%" must find "50%" and nothing else, in every list and in the global search, and odd input must never
 * give a server error.
 */

assert.equal(escapeLike('50%_\\'), '50\\%\\_\\\\');
assert.equal(likePattern('  ann  '), '%ann%', 'surrounding spaces are not part of the term');
assert.equal(likePattern(null), '%%');
assert.equal(likePattern('a%b'), '%a\\%b%');

const f = await buildPortalFixture('cciq-search-');
const { db, ids, users, mods } = f;
const uid = users.churchAdmin.id;
const today = mods.dates.today();
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

mods.announcements.createAnnouncement({ title: 'Zed50% offer', body: 'x', audience: 'all', status: 'published' }, { userId: uid });
mods.activities.createActivity({ scope: 'church', title: 'Zed50% outing', status: 'published' }, { userId: uid });
mods.documents.createDocument({ title: 'Zed50% report' }, { userId: uid, file: { originalname: 'r.png', buffer: png, size: png.length } });
mods.family.createFamilyGroup({ name: 'Zed50% Family' });
mods.visitors.createVisitor({ first_name: 'Zed50%', last_name: 'Guest', first_visit_date: today }, { userId: uid });
mods.members.createMember({ first_name: 'Zoe', last_name: 'Zed50%' }, { status: 'active' });
await mods.users.createUser({ username: 'zed_user', email: 'zed@fixture.invalid', password: 'Zed-Passw0rd-long-enough!', displayName: 'Zed50% User', roleKeys: ['member'], mustChangePassword: false });
const reminderTitle = db.prepare("SELECT title FROM reminders WHERE id = ?").get(ids.reminder).title;
db.prepare("INSERT INTO reminders (reminder_type, title, state, dedupe_key, created_at, updated_at) VALUES ('manual', 'Zed50% reminder', 'new', 'zed-rem', ?, ?)").run(new Date().toISOString(), new Date().toISOString());

const lists = [
  { url: '/announcements', special: 'Zed50% offer', control: 'Fixture notice' },
  { url: '/activities', special: 'Zed50% outing', control: 'Fixture outing' },
  { url: '/documents', special: 'Zed50% report', control: 'Fixture document' },
  { url: '/family-groups', special: 'Zed50% Family', control: 'Fixture Family' },
  { url: '/visitors', special: 'Zed50%', control: 'Vera' },
  { url: '/members', special: 'Zed50%', control: 'MemberA' },
  { url: '/admin/users', special: 'Zed50% User', control: 'fx_member_a' },
  { url: '/reminders', special: 'Zed50% reminder', control: reminderTitle },
  { url: '/search', special: 'Zed50%', control: 'Fixture', probe: 'Fixture' }
];

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const get = async (url, q) => {
    const res = await admin.get(`${url}?q=${encodeURIComponent(q)}`);
    const body = await res.text();
    assert.ok(res.status < 500, `${url}?q=${q} must not be a server error (got ${res.status})`);
    return { status: res.status, body };
  };

  for (const { url, special, control, probe } of lists) {
    const all = await get(url, probe || '');
    assert.ok(all.body.includes(control), `${url}: the control "${control}" is listed with no search`);

    for (const wildcard of ['%', '%%', '__', '_%_']) {
      const r = await get(url, wildcard);
      assert.ok(!r.body.includes(control), `${url}?q=${wildcard}: a bare wildcard must not list everything (found "${control}")`);
    }
    const literal = await get(url, 'd50%');
    assert.ok(literal.body.includes(special), `${url}?q=d50%: the literal term finds "${special}"`);
    assert.ok(!literal.body.includes(control), `${url}?q=d50%: and only it`);
    const spaced = await get(url, '  d50%  ');
    assert.ok(spaced.body.includes(special), `${url}: surrounding spaces do not stop a match`);
    const wrong = await get(url, 'Z%d50');
    assert.ok(!wrong.body.includes(special), `${url}?q=Z%d50: a % in the middle is a character, not a gap`);
    const under = await get(url, 'Z_d50');
    assert.ok(!under.body.includes(special), `${url}?q=Z_d50: an _ is a character, not "any one letter"`);
    const hostile = await get(url, "x' OR 1=1 --");
    assert.ok(!hostile.body.includes(control), `${url}: SQL in the search box matches nothing`);
    for (const odd of ['\\', 'a\\', '\\%', '', 'x'.repeat(5000), 'Ünïcödé ✓', 'أحمد', '<script>alert(1)</script>', '%00', "O'Brien"]) {
      const r = await get(url, odd);
      assert.ok(!r.body.includes('<script>alert(1)</script>'), `${url}: the typed term is escaped on the page`);
    }
    // repeated and nested parameters
    const repeated = await admin.get(`${url}?q=a&q=b`);
    await repeated.text();
    assert.ok(repeated.status < 500, `${url}: a repeated q parameter is not a server error`);
    const nested = await admin.get(`${url}?q[a]=1`);
    await nested.text();
    assert.ok(nested.status < 500, `${url}: a nested q parameter is not a server error`);
  }
  console.log(`PASS (literal) ${lists.length} searches: a bare % or _ matches nothing, "d50%" finds exactly the "Zed50%" record, wildcards inside a term are characters, spaces are ignored, SQL text matches nothing, odd input is never a server error`);

  // the same person is found the same way from every place that searches members
  const names = ['Anna MemberA', 'anna', 'ANNA', 'MemberA', 'Anna Memb'];
  for (const term of names) {
    for (const url of ['/members', '/search']) {
      const r = await get(url, term);
      assert.ok(r.body.includes(`/members/${ids.member.a2}`), `${url}?q=${term} finds Anna MemberA (a link to her record)`);
    }
  }
  const picker = await (await admin.get('/members/picker-search?q=' + encodeURIComponent('Anna'))).text();
  assert.ok(picker.includes('MemberA'), 'the member picker finds her too');
  for (const url of ['/members/picker-search']) {
    const r = await admin.get(`${url}?q=%25`);
    const text = await r.text();
    assert.ok(!text.includes('MemberB'), 'the picker treats % literally');
  }
  const visitorFull = await get('/visitors', 'Vera Visitor');
  assert.ok(visitorFull.body.includes(`/visitors/${ids.visitor}`), 'the First Timers list finds a person by first and last name together');
  console.log('PASS (consistent) a member is found by full name, first name, surname, partial name and any letter case in the list, global search and picker');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
