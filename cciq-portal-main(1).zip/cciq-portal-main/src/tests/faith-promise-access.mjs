import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Faith Promise (and the shared giving administration): who may WRITE, enforced by the server, and how an administrator finds the way to record a payment.
 *   - read your own / submit your own  (a Member, a Cell Group leader):  /projects/ecaq/faith-promise, /projects/ecaq/my-commitments, own commitment only, never another person's
 *   - administer (Super Admin, Church Admin): campaigns, another person's commitment, payments (record, correct, remove), claims, ledger
 *   - Kiosk: nothing of this
 * Every administrative write is tried as a Member, a Cell Group leader and the Kiosk with a complete, valid request: it must be refused and change nothing.
 * Then the discoverability: the commitment list says plainly what to do (Record payment on every row), the commitment page leads with it, and the whole payment
 * workflow is walked as Church Admin and as Super Admin with the stored values checked.
 */

const f = await buildPortalFixture('cciq-fp-access-');
const { db, ids, users, mods } = f;
const one = (sql, ...p) => db.prepare(sql).get(...p);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const world = () => JSON.stringify([count('SELECT COUNT(*) n FROM ecaq_campaigns'), count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments'), count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments'),
  count('SELECT COUNT(*) n FROM ecaq_giving_board_claims'), count('SELECT COUNT(*) n FROM ecaq_payments'), one('SELECT SUM(commitment_amount) s, COUNT(*) n FROM ecaq_faith_promise_commitments'),
  one('SELECT status, name FROM ecaq_campaigns WHERE id = ?', ids.promise), one('SELECT SUM(amount) s FROM ecaq_faith_promise_payments')]);

// a Giving Board with a claim and a payment, so the claim/payment write routes have real targets
const board = mods.ecaq.createCampaign({ name: '2025 Giving Board', year: 2025, type: 'giving_board', status: 'active', privacy_mode: 'first_name', currency: 'QAR', start_date: '2025-01-01', end_date: '2025-12-31' });
db.prepare('UPDATE ecaq_campaigns SET amount_per_date = 300 WHERE id = ?').run(board.id);
const claim = mods.ecaq.createClaim({ campaignId: board.id, date: mods.ecaq.boardDates(2025)[3], memberId: ids.member.a3, commitmentAmount: 300, userId: users.churchAdmin.id });
const claimId = claim.claim?.id || claim.id;
const fpPayment = mods.faith.addPayment(ids.commitment, { received_by: 'Fixture Receiver', amount: 10, paid_on: mods.dates.today(), method: 'cash' }, { userId: users.churchAdmin.id });
const fpPaymentId = fpPayment.payment.id;
const fpOther = mods.faith.submitCommitment(ids.promise, { member_id: ids.member.b1, name: 'Bella MemberB', amount: 600, frequency: 'monthly' }, { userId: users.churchAdmin.id }).commitment;

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const clients = {
    super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD),
    leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD), member: await signIn(portal.base, users.memberA.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD)
  };
  const text = async (c, url) => { const r = await c.get(url); return { status: r.status, body: await r.text(), location: r.headers.get('location') }; };
  const refused = (r) => r.status === 403 || (r.status === 302 && !/\/admin\/ecaq/.test(r.location || '')) ;

  // ---- 1. every administrative write, refused for Member / leader / Kiosk, changes nothing ------------------------------------------------------------------------------
  const writes = [
    ['POST', '/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: ids.member.a3, amount: '100', frequency: 'monthly' }],
    ['POST', `/admin/ecaq/faith-promise/commitments/${ids.commitment}/payments`, { received_by: 'Fixture Receiver', amount: '25', paid_on: mods.dates.today(), method: 'cash' }],
    ['POST', `/admin/ecaq/faith-promise/payments/${fpPaymentId}`, { amount: '1', paid_on: mods.dates.today(), method: 'cash', reason: 'x' }],
    ['POST', `/admin/ecaq/faith-promise/payments/${fpPaymentId}/delete`, { reason: 'x' }],
    ['POST', '/admin/ecaq/campaigns', { name: 'Rogue', year: '2031', type: 'faith_promise', status: 'active', privacy_mode: 'first_name', currency: 'QAR' }],
    ['POST', `/admin/ecaq/campaigns/${ids.promise}`, { name: 'Renamed', year: '2026', type: 'faith_promise', status: 'closed', privacy_mode: 'first_name', currency: 'QAR' }],
    ['POST', `/admin/ecaq/campaigns/${ids.promise}/background/reset`, {}],
    ['POST', `/admin/ecaq/claims/${claimId}`, { commitment_amount: '999', notes: 'x' }],
    ['POST', `/admin/ecaq/claims/${claimId}/release`, {}],
    ['POST', '/admin/ecaq/claims', { date: mods.ecaq.boardDates(2025)[9], member_id: ids.member.a3, confirm: '1' }],
    ['POST', `/admin/ecaq/claims/${claimId}/payments`, { amount: '50', paid_on: mods.dates.today(), method: 'cash' }],
    ['POST', '/admin/ecaq/payments/999999', { amount: '1', paid_on: mods.dates.today(), method: 'cash', reason: 'x' }],
    ['POST', '/admin/ecaq/payments/999999/delete', { reason: 'x' }],
    ['POST', '/admin/ecaq/updates', { title: 'Rogue', body: 'x' }]
  ];
  const reads = ['/admin/ecaq', '/admin/ecaq/faith-promise', '/admin/ecaq/faith-promise/new', `/admin/ecaq/faith-promise/commitments/${ids.commitment}`, '/admin/ecaq/campaigns', '/admin/ecaq/campaigns/new',
    `/admin/ecaq/campaigns/${ids.promise}/edit`, `/admin/ecaq/campaigns/${ids.promise}/ledger`, `/admin/ecaq/campaigns/${ids.promise}/ledger.csv`, '/admin/ecaq/payments', '/admin/ecaq/payments.csv', '/admin/ecaq/claims.csv',
    `/admin/ecaq/claims/${claimId}`, `/admin/ecaq/claims/new?date=${mods.ecaq.boardDates(2025)[9]}`, '/admin/ecaq/updates'];
  const before = world(); let auditBefore = count('SELECT COUNT(*) n FROM audit_logs WHERE action LIKE \'ecaq.%\' OR action LIKE \'giving.%\'');
  for (const who of ['member', 'leader', 'kiosk']) {
    for (const url of reads) { const r = await text(clients[who], url); assert.ok(refused(r), `${who} GET ${url} -> ${r.status}`); assert.ok(!/Record payment|Faith Promise administration/.test(r.body.replace(/<script[\s\S]*?<\/script>/g, '')) || r.status !== 200); }
    for (const [, url, fields] of writes) {
      const res = await clients[who].post(url, fields, { csrfFrom: '/account/password' }); await res.text();
      assert.ok(res.status === 403 || (res.status === 302 && !/\/admin\/ecaq/.test(res.headers.get('location') || '')) || res.status === 404, `${who} POST ${url} -> ${res.status}`);
    }
  }
  assert.equal(world(), before, 'every refused write changed nothing: no campaign, commitment, payment or claim was created, edited or removed');
  assert.equal(count('SELECT COUNT(*) n FROM audit_logs WHERE action LIKE \'ecaq.%\' OR action LIKE \'giving.%\''), auditBefore, 'and left no success row in the audit log');
  console.log(`PASS (refusals) ${reads.length} administrative pages and ${writes.length} administrative writes are refused for a Member, a Cell Group leader and the Kiosk, and change nothing`);

  // ---- 2. self-service: read your own, submit your own, never anyone else's -----------------------------------------------------------------------------------------------
  for (const who of ['member', 'leader']) {
    const page = await text(clients[who], '/projects/ecaq/faith-promise'); assert.equal(page.status, 200, `${who}: Faith Promise page`);
    assert.ok(!/\/admin\/ecaq|Record payment|Record for a member/.test(page.body.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<nav[\s\S]*?<\/nav>/g, '')), `${who}: the self-service page offers no administration`);
    const mine = await text(clients[who], '/projects/ecaq/my-commitments'); assert.equal(mine.status, 200);
  }
  { // Anna (member A) sees her own commitment and not Bella's
    const page = await text(clients.member, '/projects/ecaq/faith-promise'); assert.match(page.body.replace(/\s+/g, ' '), /50/, 'her own commitment is shown');
    const mine = await text(clients.member, '/projects/ecaq/my-commitments'); assert.ok(!/Bella/.test(mine.body), 'never another person\'s');
    // a crafted submission cannot name another member: the commitment is always the signed-in person's own
    const res = await clients.member.post('/projects/ecaq/faith-promise', { campaign_id: ids.promise, name: 'Anna MemberA', amount: '70', frequency: 'monthly', member_id: ids.member.b1 }, { csrfFrom: '/projects/ecaq/faith-promise' }); await res.text();
    assert.ok([302, 303].includes(res.status));
    const own = one('SELECT * FROM ecaq_faith_promise_commitments WHERE id = ?', ids.commitment);
    assert.equal(own.member_id, ids.member.a2, 'still hers'); assert.equal(Number(own.commitment_amount), 50, 'her commitment was NOT changed: a Faith Promise is submitted once');
    assert.equal(Number(one('SELECT commitment_amount a FROM ecaq_faith_promise_commitments WHERE id = ?', fpOther.id).a), 600, 'Bella\'s was not touched');
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments WHERE campaign_id = ? AND member_id = ?', ids.promise, ids.member.b1), 1, 'and no second one was created for her');
    // reading is not recording: the payment total is the ledger's, not something a member can change
    assert.equal(Number(one('SELECT SUM(amount) s FROM ecaq_faith_promise_payments WHERE commitment_id = ?', ids.commitment).s), 10);
  }
  { // the one commitment id in the address does not give a member the administrator's page
    const r = await text(clients.member, `/admin/ecaq/faith-promise/commitments/${fpOther.id}`); assert.ok(refused(r), 'another person\'s commitment page is not reachable by address');
  }
  console.log('PASS (self-service) a Member and a Cell Group leader can read their OWN commitment and submit it once; an update or a crafted member id is refused; another person\'s commitment is unreachable');

  // ---- 3. discoverability: the list says what to do ---------------------------------------------------------------------------------------------------------------------------------
  for (const who of ['church', 'super']) {
    // the journey starts in the navigation: Church ECAQ Projects > Faith Promise administration > a commitment > Record payment > its Payment history
    const home = await text(clients[who], '/projects/ecaq'); const nav = (/<nav class="sidenav"[\s\S]*?<\/nav>/.exec(home.body) || [''])[0];
    assert.ok(nav.includes('href="/admin/ecaq/faith-promise"') && /Faith Promise administration/.test(nav), `${who}: the navigation leads to Faith Promise administration`);
    const list = await text(clients[who], `/admin/ecaq/faith-promise?campaign=${ids.promise}`); assert.equal(list.status, 200);
    const main = /<main[\s\S]*?<\/main>/.exec(list.body)[0];
    assert.match(main, /<th scope="col">Outstanding<\/th>/, `${who}: an Outstanding figure on every row`);
    assert.match(main, /<th scope="col">Actions<\/th>/);
    for (const id of [ids.commitment, fpOther.id]) {
      assert.ok(main.includes(`href="/admin/ecaq/faith-promise/commitments/${id}#record-payment"`), `${who}: Record payment on commitment ${id}`);
      assert.ok(main.includes(`href="/admin/ecaq/faith-promise/commitments/${id}#payments"`), `${who}: History on commitment ${id}`);
    }
    assert.match(main, /class="btn btn--small" href="[^"]*#record-payment">Record payment/, 'Record payment is the primary action of the row');
    const detail = await text(clients[who], `/admin/ecaq/faith-promise/commitments/${ids.commitment}`);
    assert.match(detail.body, /<a class="btn" href="#record-payment">Record payment<\/a>/, `${who}: the commitment page leads with Record payment`);
    assert.match(detail.body, /id="record-payment"/); assert.match(detail.body, /id="payments"/);
  }
  { const empty = mods.ecaq.createCampaign({ name: 'Empty promise', year: 2030, type: 'faith_promise', status: 'draft', start_date: '2030-01-01', end_date: '2030-12-31' });
    const page = await text(clients.church, `/admin/ecaq/faith-promise?campaign=${empty.id}`); assert.match(page.body.replace(/\s+/g, ' '), /No one has committed to this campaign yet\. Use <strong>Record for a member<\/strong>/); }
  console.log('PASS (discoverability) every commitment row offers Record payment and History, shows what is outstanding, and the commitment page leads with Record payment');

  // ---- 4. the payment workflow, end to end, as Church Admin and as Super Admin --------------------------------------------------------------------------------------------------
  for (const [who, expectedBy] of [['church', users.churchAdmin.id], ['super', users.superAdmin.id]]) {
    const target = who === 'church' ? ids.commitment : fpOther.id;
    const received0 = Number(one('SELECT COALESCE(SUM(amount),0) s FROM ecaq_faith_promise_payments WHERE commitment_id = ?', target).s);
    const paid = await clients[who].post(`/admin/ecaq/faith-promise/commitments/${target}/payments`, { received_by: 'Fixture Receiver', amount: '123.50', paid_on: mods.dates.today(), method: 'bank_transfer', reference: `ref-${who}` }, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${target}` }); await paid.text();
    assert.equal(paid.status, 302, `${who}: payment recorded`); assert.equal(paid.headers.get('location'), `/admin/ecaq/faith-promise/commitments/${target}`);
    const row = one('SELECT * FROM ecaq_faith_promise_payments WHERE commitment_id = ? AND reference = ?', target, `ref-${who}`);
    assert.ok(row, `${who}: stored`); assert.equal(Number(row.amount), 123.5); assert.equal(row.method, 'bank_transfer'); assert.equal(row.paid_on, mods.dates.today()); assert.equal(row.created_by ?? row.recorded_by, expectedBy, `${who}: recorded by the signed-in administrator`);
    const total = Number(one('SELECT SUM(amount) s FROM ecaq_faith_promise_payments WHERE commitment_id = ?', target).s);
    assert.equal(total, received0 + 123.5, `${who}: the received total is the sum of the payments`);
    assert.ok(one("SELECT 1 FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_recorded' AND CAST(entity_id AS TEXT) = ? AND user_id = ?", String(target), expectedBy), `${who}: audited`);
    const detail = await text(clients[who], `/admin/ecaq/faith-promise/commitments/${target}`); assert.match(detail.body, /QAR 123\.5/); assert.match(detail.body, new RegExp(`ref-${who}`));
    // correct it (a reason is required), then remove it (a reason is required)
    const noReason = await clients[who].post(`/admin/ecaq/faith-promise/payments/${row.id}`, { amount: '100', paid_on: mods.dates.today(), method: 'cash' }, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${target}` }); await noReason.text();
    assert.equal(Number(one('SELECT amount a FROM ecaq_faith_promise_payments WHERE id = ?', row.id).a), 123.5, `${who}: a correction without a reason changes nothing`);
    const fix = await clients[who].post(`/admin/ecaq/faith-promise/payments/${row.id}`, { amount: '100', paid_on: mods.dates.today(), method: 'cash', reason: 'typed wrongly' }, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${target}` }); await fix.text();
    assert.equal(Number(one('SELECT amount a FROM ecaq_faith_promise_payments WHERE id = ?', row.id).a), 100, `${who}: corrected`);
    assert.ok(one("SELECT 1 FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_corrected' AND CAST(entity_id AS TEXT) = ?", String(row.id)));
    const del = await clients[who].post(`/admin/ecaq/faith-promise/payments/${row.id}/delete`, { reason: 'duplicate' }, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${target}` }); await del.text();
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE id = ?', row.id), 0, `${who}: removed`);
    assert.ok(one("SELECT 1 FROM audit_logs WHERE action = 'ecaq.faith_promise_payment_deleted' AND CAST(entity_id AS TEXT) = ?", String(row.id)));
    assert.equal(Number(one('SELECT COALESCE(SUM(amount),0) s FROM ecaq_faith_promise_payments WHERE commitment_id = ?', target).s), received0, `${who}: the ledger is back where it started`);
    // invalid payments are refused with a message, not an error page
    for (const bad of [{ amount: 'abc' }, { amount: '-5' }, { amount: '0' }, { amount: '1e9' }, { amount: '10', paid_on: '2999-01-01' }, { amount: '10', paid_on: 'nope' }]) {
      const res = await clients[who].post(`/admin/ecaq/faith-promise/commitments/${target}/payments`, { received_by: 'Fixture Receiver', paid_on: mods.dates.today(), method: 'cash', ...bad }, { csrfFrom: `/admin/ecaq/faith-promise/commitments/${target}` }); await res.text();
      assert.ok(res.status < 500, `${who}: ${JSON.stringify(bad)} -> ${res.status}`);
    }
    assert.equal(Number(one('SELECT COALESCE(SUM(amount),0) s FROM ecaq_faith_promise_payments WHERE commitment_id = ?', target).s), received0, `${who}: no invalid payment was stored`);
  }
  // record for a member (another person's commitment), as an administrator
  { const res = await clients.church.post('/admin/ecaq/faith-promise/new', { campaign_id: ids.promise, member_id: ids.member.a3, amount: '90', frequency: 'quarterly' }, { csrfFrom: `/admin/ecaq/faith-promise/new?campaign=${ids.promise}` }); await res.text(); assert.equal(res.status, 302);
    const row = one('SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = ? AND member_id = ?', ids.promise, ids.member.a3); assert.ok(row); assert.equal(Number(row.commitment_amount), 90); }
  console.log('PASS (payments) Church Admin and Super Admin record, correct (reason required) and remove a payment; the ledger, the audit and the stored values agree; invalid payments store nothing');

  // ---- 5. the list at every width: no sideways scroll, the action is reachable ------------------------------------------------------------------------------------------------------------
  const cookies = clients.church.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const problems = [];
  for (const width of [320, 375, 430, 768, 1024, 1280, 1440]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } }); await context.addCookies(cookies);
    const page = await context.newPage();
    for (const url of [`/admin/ecaq/faith-promise?campaign=${ids.promise}`, `/admin/ecaq/faith-promise/commitments/${ids.commitment}`]) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const m = await page.evaluate(() => ({ overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, buttons: [...document.querySelectorAll('a.btn, button.btn')].filter((b) => /Record payment/.test(b.textContent)).map((b) => { const r = b.getBoundingClientRect(); return { w: r.width, h: r.height, right: r.right, visible: r.width > 0 && r.height > 0 }; }) }));
      if (m.overflow > 0) problems.push(`${width}px ${url}: sideways scroll ${m.overflow}px`);
      if (!m.buttons.length || !m.buttons.every((b) => b.visible)) problems.push(`${width}px ${url}: Record payment missing or not visible`);
      if (m.buttons.some((b) => b.right > width + 1)) problems.push(`${width}px ${url}: Record payment runs off the screen`);
    }
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('; '));
  console.log('PASS (widths) the commitment list and page show Record payment at 320 to 1440 px with no sideways scroll');
  console.log('PASS faith-promise-access');
} finally {
  await browser.close();
  await portal.stop();
}
