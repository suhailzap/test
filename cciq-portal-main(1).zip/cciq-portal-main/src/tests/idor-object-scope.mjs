import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Object-level authorization (IDOR): can a signed-in user reach, or change, somebody else's record by editing the id in
 * the address? Run as a Cell Group Leader (group A), a second Leader (group B) and two Members against objects that belong
 * to the other side. Reads must not show the object; writes must not change it.
 */

const f = await buildPortalFixture('cciq-idor-');
const { db, ids, users } = f;
const portal = await startPortal();
const refused = (res) => [302, 401, 403, 404].includes(res.status);
const body = async (res) => (res.status === 200 ? res.text() : '');
try {
  const s = {};
  for (const key of Object.keys(users)) s[key] = await signIn(portal.base, users[key].email, f.PASSWORD);
  const sha = (table, where = '1=1') => JSON.stringify(db.prepare(`SELECT * FROM ${table} WHERE ${where} ORDER BY 1`).all());

  // ---------------- members: a Leader's scope is their own group --------------------------------------------------
  const { a2, a3, b1, b2 } = ids.member;
  assert.equal((await s.leaderA.get(`/members/${a2}`)).status, 200, 'a Leader sees a member of their own group');
  for (const path of [`/members/${b1}`, `/members/${b1}/edit`, `/members/${b1}/attendance`, `/members/${b1}/quick`, `/members/${b1}/qr`, `/members/${b1}/delete`]) {
    const res = await s.leaderA.get(path);
    assert.ok(refused(res), `Leader A must not open ${path} (got ${res.status})`);
  }
  const beforeB1 = sha('members', `id = ${b1}`);
  for (const [path, fields] of [[`/members/${b1}`, { first_name: 'Hacked', last_name: 'Hacked' }], [`/members/${b1}/status`, { status: 'archived', reason: 'x' }],
    [`/members/${b1}/qr/regenerate`, {}], [`/members/${b1}/photo/remove`, {}], [`/members/${b1}/delete`, { confirm: 'yes' }]]) {
    const res = await s.leaderA.post(path, fields);
    assert.ok(refused(res) && res.status !== 302 || res.status === 302 && !String(res.headers.get('location')).includes('/members/'), `Leader A POST ${path} refused (got ${res.status} ${res.headers.get('location') || ''})`);
  }
  assert.equal(sha('members', `id = ${b1}`), beforeB1, 'another group\'s member record is untouched');
  const csv = await (await s.leaderA.get('/members/export.csv')).text();
  assert.ok(!csv.includes('MemberB') && !csv.includes('Bella'), 'a Leader\'s member export holds only their own group');
  const searchB = await (await s.leaderA.get('/search?q=Bella')).text();
  assert.ok(!searchB.includes('MemberB'), 'portal search hides members outside a Leader\'s scope');
  // The member picker is deliberately NOT scoped (a Leader adding someone to their group must be able to find people from any
  // group - CCIQ_DECISIONS.md, "shared searchable member picker"), so what it may return is limited instead: name, Member ID, cell
  // group and photo - never phone, email, address, status or notes.
  const picker = await s.leaderA.get('/members/picker-search?q=Bella');
  const pickerRows = JSON.parse(await body(picker));
  assert.ok(pickerRows.length >= 1, 'the picker finds people from other groups by design');
  for (const row of pickerRows) {
    for (const key of Object.keys(row)) assert.ok(['id', 'name', 'memberCode', 'cellGroup', 'photoUrl'].includes(key), `picker field "${key}" is not on the allowed list`);
  }
  assert.ok(!JSON.stringify(pickerRows).match(/5550|fixture.invalid|Beta Street|private note/), 'and carries no contact data or notes');
  assert.ok(refused(await s.memberA.get('/members/picker-search?q=Bella')), 'a plain Member cannot use the picker at all');
  const listB = await (await s.leaderA.get('/members?q=Bella&status=all')).text();
  assert.ok(!listB.includes('MemberB'), 'the member list hides members outside scope');
  console.log('PASS (members) a Leader reaches only their own group\'s members - detail, edit, attendance, QR, delete, export, list, search and picker; POSTs against another group\'s member change nothing');

  // ---------------- a plain Member ---------------------------------------------------------------------------------
  for (const path of [`/members/${b1}`, `/members/${a3}`, `/members/${b1}/qr`, `/members/${b1}/attendance`, `/members`, '/members/export.csv', '/visitors', `/visitors/${ids.visitor}`, '/family-groups', '/reminders', '/admin/users', `/admin/users/${users.superAdmin.id}`, '/attendance/history', '/reports']) {
    const res = await s.memberA.get(path);
    assert.ok(refused(res), `Member A must not open ${path} (got ${res.status})`);
  }
  assert.equal((await s.memberA.get(`/media/members/${b1}/photo`)).status, 403, 'a Member cannot fetch another member\'s photo');
  assert.equal((await s.memberA.get(`/media/members/${ids.member.a2}/photo`)).status, 404, 'their own photo route answers (no photo yet)');
  const ownProfile = await (await s.memberA.get('/my/profile')).text();
  assert.match(ownProfile, /Anna/);
  assert.ok(!ownProfile.includes('Bella'), 'My profile shows only the member\'s own record');
  const mineAttendance = await s.memberA.get('/attendance/mine');
  assert.equal(mineAttendance.status, 200);
  // A profile POST can only ever change the signed-in member: there is no member id in the request to tamper with.
  const beforeOthers = sha('members', `id <> ${a2}`);
  await s.memberA.post('/my/profile', { phone: '+974 5550 9999', member_id: String(b1), id: String(b1) });
  assert.equal(sha('members', `id <> ${a2}`), beforeOthers, 'a tampered profile post cannot change another member');
  assert.equal(db.prepare('SELECT phone FROM members WHERE id = ?').get(a2).phone, '+974 5550 9999', 'but it does change their own');
  const photoRes = await s.memberA.upload(`/members/${b1}/photo`, { buffer: Buffer.from('x'), type: 'image/png', name: 'x.png' });
  assert.ok(refused(photoRes), 'a Member cannot upload a photo to another member');
  console.log('PASS (member) a Member reaches only their own record, photo, attendance and profile; admin lists, exports, first timers and other members are refused; a tampered profile post changes only themselves');

  // ---------------- users ------------------------------------------------------------------------------------------
  const beforeUsers = sha('users');
  for (const who of ['memberA', 'leaderA']) {
    for (const path of ['/admin/users', `/admin/users/${users.superAdmin.id}`, '/admin/roles']) assert.ok(refused(await s[who].get(path)), `${who} ${path}`);
    for (const path of [`/admin/users/${users.superAdmin.id}/password`, `/admin/users/${users.superAdmin.id}/status`, `/admin/users/${users.superAdmin.id}`]) {
      assert.ok(refused(await s[who].post(path, { password: 'Changed123456!', status: 'disabled' })), `${who} POST ${path}`);
    }
  }
  assert.equal(sha('users'), beforeUsers, 'no account changed');
  console.log('PASS (users) Members and Leaders cannot read or change any account, including the Super Admin');

  // ---------------- cell groups and their attendance -----------------------------------------------------------------
  const meetingB = f.mods.attendance.createCellGroupMeeting(ids.groupB, { date: f.mods.dates.today(), userId: users.churchAdmin.id }).sessionId;
  assert.equal((await s.leaderA.get(`/cell-groups/${ids.groupA}`)).status, 200);
  for (const path of [`/cell-groups/${ids.groupB}`, `/cell-groups/${ids.groupB}/edit`, `/cell-groups/${ids.groupB}/activities/new`]) {
    assert.ok(refused(await s.leaderA.get(path)), `Leader A must not open ${path}`);
  }
  const otherGroupAttendance = await s.leaderA.get(`/attendance/cell-groups/${ids.groupB}`);
  console.log(`INFO attendance.view is "View attendance for the church" and the Leader role holds it, so a Leader opening ANOTHER group attendance summary -> ${otherGroupAttendance.status} (member lists are scoped, this summary is not: an owner decision, docs/WORKFLOW-INTEGRITY-AUDIT.md)`);
  const otherRegister = await s.leaderA.get(`/attendance/sessions/${meetingB}`);
  assert.ok(refused(otherRegister) || !(await otherRegister.text()).includes("Bella"), "another group meeting register never lists that group members to this Leader");
  const beforeGroups = sha('cell_group_members') + sha('cell_groups') + sha('attendance_sessions') + sha('attendance_records');
  for (const [path, fields] of [[`/cell-groups/${ids.groupB}/members/${b1}/remove`, {}], [`/cell-groups/${ids.groupB}`, { name: 'Hijacked' }],
    [`/cell-groups/${ids.groupB}/meetings`, { date: '2026-10-07' }], [`/attendance/sessions/${meetingB}/records`, { [`status_${b1}`]: 'present' }],
    [`/attendance/sessions/${meetingB}/add`, { person: `member:${b1}` }], [`/cell-groups/${ids.groupB}/activities`, { title: 'x' }]]) {
    const res = await s.leaderA.post(path, fields);
    assert.ok(res.status === 403 || res.status === 404 || res.status === 400 || (res.status === 302 && !String(res.headers.get('location')).includes(`/cell-groups/${ids.groupB}`)), `Leader A POST ${path} -> ${res.status} ${res.headers.get('location') || ''}`);
  }
  assert.equal(sha('cell_group_members') + sha('cell_groups') + sha('attendance_sessions') + sha('attendance_records'), beforeGroups, 'another group\'s roster, details and register are untouched');
  console.log('PASS (cell groups) a Leader reaches only their own group - page, edit, activities, attendance, meetings and register; POSTs against the other group change nothing');

  // ---------------- announcements / activities / documents --------------------------------------------------------------
  assert.equal((await s.memberA.get(`/announcements/${ids.announcement}`)).status, 200);
  assert.ok(refused(await s.memberA.get(`/announcements/${ids.leadersOnly}`)), 'a Member cannot open a leaders-only announcement by id');
  assert.equal((await s.leaderA.get(`/announcements/${ids.leadersOnly}`)).status, 200, 'a Leader can');
  const annList = await (await s.memberA.get('/announcements')).text();
  assert.ok(!annList.includes('Leaders only notice'), 'and it is not listed for a Member');
  assert.ok(refused(await s.memberA.get(`/announcements/${ids.announcement}/edit`)));
  assert.ok(refused(await s.memberA.post(`/announcements/${ids.announcement}/delete`, {})));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM announcements').get().n, 2);
  assert.ok(refused(await s.memberA.get(`/activities/${ids.draftActivity}`)), 'a draft activity is not visible to a Member');
  assert.ok(refused(await s.leaderA.get(`/activities/${ids.draftActivity}`)), 'nor to another group\'s Leader');
  assert.ok(refused(await s.leaderA.post(`/activities/${ids.draftActivity}`, { title: 'x' })));
  assert.equal(db.prepare('SELECT title FROM activities WHERE id = ?').get(ids.draftActivity).title, 'Beta draft');
  const docMember = await s.memberA.get(`/documents/${ids.document}`);
  const docFile = await s.memberA.get(`/documents/${ids.document}/file`);
  console.log(`INFO documents: a plain Member opening a document by id -> ${docMember.status}; its file -> ${docFile.status} (documents.view is part of the Member role; audience rules are tested in document-audience-security.mjs)`);
  assert.ok(refused(await s.memberA.post(`/documents/${ids.document}/delete`, {})));
  assert.ok(refused(await s.memberA.post(`/documents/${ids.document}/archive`, {})));
  console.log('PASS (content) audience-restricted announcements, draft activities and document changes are not reachable by id');

  // ---------------- notifications, reminders, first timers -----------------------------------------------------------
  await s.memberB.post(`/notifications/${ids.notifications.memberA}/read`, {});
  assert.equal(db.prepare('SELECT read_at FROM notifications WHERE id = ?').get(ids.notifications.memberA).read_at, null, 'another user\'s notification cannot be marked read');
  await s.memberB.post('/notifications/read-all', {});
  assert.equal(db.prepare('SELECT COUNT(*) n FROM notifications WHERE read_at IS NOT NULL AND user_id <> ?').get(users.memberB.id).n, 0, 'read-all touches only the caller\'s own');
  assert.ok(refused(await s.memberA.get('/reminders')));
  assert.ok(refused(await s.memberA.post(`/reminders/${ids.reminder}/state`, { state: 'completed' })));
  assert.equal(db.prepare("SELECT state FROM reminders WHERE id = ?").get(ids.reminder).state, 'new');
  const leaderVisitors = await s.leaderA.get('/visitors');
  console.log(`INFO first timers: a Cell Group Leader (members.view, scoped to their group for MEMBERS) opening /visitors -> ${leaderVisitors.status}; /visitors/${ids.visitor} -> ${(await s.leaderA.get(`/visitors/${ids.visitor}`)).status}. First timers are not scoped to a group, so this is the full list with phone and email - recorded as an owner decision (docs/WORKFLOW-INTEGRITY-AUDIT.md).`);
  console.log('PASS (notifications / reminders) a user changes only their own notifications; reminders and their state changes are refused to Members');

  // ---------------- Giving Board and Faith Promise -------------------------------------------------------------------
  assert.ok(refused(await s.memberA.get(`/admin/ecaq/claims/${ids.claim}`)), "the administrative claim page is not open to the claim owner");
  const ownRelabel = await s.memberA.post(`/projects/ecaq/claims/${ids.claim}/display-name`, { display_as: "Anna M." });
  assert.equal(ownRelabel.status, 302, "the owner can relabel their own date");
  const beforeClaim = sha('ecaq_giving_board_claims');
  assert.ok(refused(await s.memberB.post(`/projects/ecaq/claims/${ids.claim}/display-name`, { display_as: 'Hijacked' })));
  assert.ok(refused(await s.memberB.post(`/admin/ecaq/claims/${ids.claim}/release`, {})));
  assert.equal(sha('ecaq_giving_board_claims'), beforeClaim, 'another member\'s claim is untouched');
  const mine = await (await s.memberB.get('/projects/ecaq/my-commitments')).text();
  assert.ok(!mine.includes('Anna'), 'My Commitments shows only the caller\'s own');
  assert.ok(refused(await s.memberB.get(`/admin/ecaq/faith-promise/commitments/${ids.commitment}`)));
  console.log('PASS (Giving Board / Faith Promise) a claim can be opened or changed only by its owner (or an administrator); My Commitments lists only the caller\'s own');

  // ---------------- family groups, ministries, visitors - write routes ---------------------------------------------------
  const beforeFamily = sha('family_group_members') + sha('ministry_members') + sha('visitors');
  for (const who of ['memberA', 'leaderA']) {
    for (const [path, fields] of [[`/family-groups/${ids.family}/members/${a2}/remove`, {}], [`/family-groups/${ids.family}/delete`, {}], [`/family-groups/${ids.family}/members`, { member_id: String(a3) }],
      [`/ministries/${ids.ministry}/members/${a2}/remove`, {}], [`/ministries/${ids.ministry}/members`, { member_id: String(a3) }],
      [`/visitors/${ids.visitor}/convert`, {}], [`/visitors/${ids.visitor}`, { first_name: 'Hijacked' }], [`/visitors/${ids.visitor}/state`, { state: 'declined' }]]) {
      assert.ok(refused(await s[who].post(path, fields)), `${who} POST ${path}`);
    }
  }
  assert.equal(sha('family_group_members') + sha('ministry_members') + sha('visitors'), beforeFamily, 'family, ministry and first timer records are untouched');
  console.log('PASS (family / ministry / first timers) Members and Leaders cannot change family groups, ministry rosters or first timers');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
