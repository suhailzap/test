import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { crawl } from './lib/crawl.mjs';
import { OVERFLOW_CHECK_SCRIPT } from '../../tools/check-overflow.mjs';

/*
 * Responsive stress. The deep responsive pass uses ordinary names and ordinary text. Real data is not: a long compound surname, an e-mail
 * address with no break point, a file name or a campaign name with no spaces, a note pasted from a document. Every kind of text a person can
 * enter is made as long and as unbreakable as the form accepts, planted across members, First Timers, groups, ministries, families,
 * announcements, activities, documents, ECAQ and the audit log, and every reachable screen is opened at the twelve design widths (320 to 1920).
 * No page may overflow horizontally, none may clip its main content, and no text may spill out of its card.
 */

const WIDTHS = [320, 360, 390, 430, 768, 820, 860, 861, 1024, 1280, 1440, 1920];
const f = await buildPortalFixture('cciq-responsive-stress-');
const { db, ids, users, mods } = f;
const long = (n, ch = 'W') => ch.repeat(n);
const unbreakable = 'Pneumonoultramicroscopicsilicovolcanoconiosis'.repeat(4);
const bigEmail = `${long(60, 'a')}@${long(60, 'b')}.${long(60, 'c')}.example.invalid`;
const now = new Date().toISOString();

// ---- members: the longest names, e-mail, address, notes the forms accept ------------------------------------------------------------------------------
const monster = mods.members.createMember({
  first_name: long(80, 'A'), middle_name: long(80, 'B'), last_name: long(80, 'C'), preferred_name: long(80, 'D'),
  phone: '+974 5550 0099', email: bigEmail, address: `${unbreakable} ${unbreakable}`, company: long(120, 'E'), occupation: long(120, 'F'),
  home_country: long(80, 'G'), notes: `${unbreakable} ${unbreakable}${unbreakable}`, emergency_contact_name: long(120, 'H'), emergency_contact_relation: long(60, 'I')
}, { status: 'active' });
for (let i = 0; i < 6; i += 1) mods.members.createMember({ first_name: `${long(70, String.fromCharCode(97 + i))}${i}`, last_name: `${long(70, String.fromCharCode(103 + i))}${i}`, email: bigEmail.replace('a', String(i)) }, { status: 'active' });
db.prepare('UPDATE members SET cell_group_id = ? WHERE id = ?').run(ids.groupA, monster.id);

// ---- groups, ministries, families --------------------------------------------------------------------------------------------------------------------
db.prepare('UPDATE cell_groups SET name = ?, description = ?, meeting_location = ? WHERE id = ?').run(long(120, 'G'), `${unbreakable} ${unbreakable}`, long(200, 'L'), ids.groupA);
db.prepare('UPDATE ministries SET name = ?, description = ? WHERE id = ?').run(long(120, 'M'), `${unbreakable}`, ids.ministry);
db.prepare('UPDATE family_groups SET name = ? WHERE id = ?').run(long(120, 'Y'), ids.family);

// ---- First Timers and a review ----------------------------------------------------------------------------------------------------------------------------
const visitor = mods.visitors.createVisitor({ first_name: long(80, 'V'), last_name: long(80, 'T'), phone: '+974 5559 8877', email: bigEmail, how_heard: long(200, 'H'), notes: `${unbreakable}${unbreakable}`, invited_by_name: long(120, 'I'), first_visit_date: mods.dates.addDays(mods.dates.today(), -30) }, { userId: users.churchAdmin.id });
db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json, note) VALUES (?, 'open', ?, '2026-01-02', ?, ?)")
  .run(visitor.id, now, JSON.stringify({ rule: '3 of the last 4 eligible Fridays', visits: 3, fridays: [4, 3, 2, 1].map((n, i) => ({ session_id: n, service_date: `2026-01-0${n}`, visited: i !== 1 })) }), long(300, 'N'));

// ---- announcements, activities, documents, ECAQ, audit -------------------------------------------------------------------------------------------------
db.prepare('UPDATE announcements SET title = ?, body = ? WHERE id = ?').run(long(160, 'T'), `${unbreakable}\n\n${unbreakable}${unbreakable}`, ids.announcement);
db.prepare('UPDATE activities SET title = ?, description = ?, location = ? WHERE id = ?').run(long(160, 'A'), `${unbreakable}`, long(200, 'L'), ids.activity);
db.prepare('UPDATE documents SET title = ?, description = ?, original_filename = ? WHERE id = ?').run(long(160, 'D'), unbreakable, `${long(200, 'f')}.pdf`, ids.document);
db.prepare('UPDATE ecaq_campaigns SET name = ? WHERE id = ?').run(long(150, 'C'), ids.board);
db.prepare("UPDATE ecaq_faith_promise_commitments SET name = ? WHERE id = ?").run(long(150, 'N'), ids.commitment);
const audit = db.prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, result, detail, ip_address, created_at) VALUES (?, ?, 'member', ?, 'success', ?, '127.0.0.1', ?)");
for (let i = 0; i < 8; i += 1) audit.run(users.churchAdmin.id, `${long(90, 'x')}.${i}`, String(monster.id), JSON.stringify({ note: unbreakable, name: long(150, 'n') }), now);
mods.reminders && db.prepare("INSERT INTO reminders (reminder_type, member_id, title, detail, state, dedupe_key, created_at, updated_at) VALUES ('birthday', ?, ?, ?, 'new', 'stress-1', ?, ?)").run(monster.id, long(150, 'R'), unbreakable, now, now);

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const report = { overflow: [], clipped: [], spill: [] };
const SPILL_SCRIPT = () => {
  // text that runs past the right edge of the card that holds it, while the page itself does not scroll
  const out = [];
  document.querySelectorAll('main .card, main td, main .list__name, main h1, main h2, main .stat__value, main .identity').forEach((box) => {
    if (getComputedStyle(box).overflow !== 'visible') return; // deliberately clipped or scrolling
    const b = box.getBoundingClientRect(); if (b.width === 0) return;
    for (const child of box.querySelectorAll('*')) {
      const r = child.getBoundingClientRect();
      if (r.width > 0 && r.right > b.right + 2 && getComputedStyle(child).position !== 'absolute' && getComputedStyle(child).position !== 'fixed' && !child.closest('.table-wrap, .tabs, [class*="scroll"], pre')) { out.push(`${box.tagName.toLowerCase()}.${String(box.className).split(' ')[0]} > ${child.tagName.toLowerCase()}.${String(child.className).split(' ')[0]} (${Math.round(r.right - b.right)}px past)`); break; }
    }
  });
  return [...new Set(out)].slice(0, 5);
};
const shape = (href) => href.replace(/\/\d+/g, '/#').replace(/([?&])(?!tab=)[^=&]+=[^&]*/g, '').replace(/[?&]$/, '') || '/';
try {
  const roles = [['Super Administrator', users.superAdmin, 60, WIDTHS], ['Church Administrator', users.churchAdmin, 60, [320, 390, 768, 1280]], ['Cell Group Leader', users.leaderA, 30, [320, 390, 768]], ['Member', users.memberA, 25, [320, 390, 768]]];
  let opened = 0;
  for (const [label, account, limit, widths] of roles) {
    const session = await signIn(portal.base, account.email, f.PASSWORD);
    const pages = new Map();
    for (const [href, page] of await crawl(session, { depth: 3, max: 400 })) {
      if (page.status !== 200 || !/text\/html/.test(page.type) || /\/(export|pdf|print)|\.csv|\/file|\/photo|\/qr\b/.test(href)) continue;
      if (!pages.has(shape(href.split('#')[0]))) pages.set(shape(href.split('#')[0]), href);
      if (pages.size >= limit) break;
    }
    // the screens that show the stress data directly
    const direct = label === 'Member' || label === 'Cell Group Leader' ? [] : [`/members/${monster.id}`, `/members/${monster.id}/edit`, `/visitors/${visitor.id}`, `/visitors/reviews`, `/visitors/${visitor.id}/convert`, `/visitors/${visitor.id}/link`, '/members', '/visitors', '/admin/audit', `/documents/${ids.document}`, `/announcements/${ids.announcement}`, `/activities/${ids.activity}`, `/ministries/${ids.ministry}`, `/cell-groups/${ids.groupA}`, `/family-groups/${ids.family}`, '/reminders', '/projects/ecaq/board'];
    const list = [...new Set([...pages.values(), ...direct])];
    const cookies = session.cookie.split('; ').map((c) => { const [name, ...rest] = c.split('='); return { name, value: rest.join('='), url: portal.base }; });
    const context = await browser.newContext(); await context.addCookies(cookies);
    const page = await context.newPage();
    for (const href of list) {
      for (const width of widths) {
        await page.setViewportSize({ width, height: width < 700 ? 800 : 900 });
        const res = await page.goto(portal.base + href, { waitUntil: 'load' }); opened += 1;
        if (res.status() >= 400) continue; // a screen this role may not open
        const over = await page.evaluate(OVERFLOW_CHECK_SCRIPT);
        if (over.overflow) report.overflow.push(`${label} ${href} @${width}: ${over.scrollWidth}>${over.clientWidth} ${over.offenders.slice(0, 2).map((o) => o.selector).join(' | ')}`);
        const left = await page.evaluate(() => { const m = document.querySelector('main'); return m && m.getBoundingClientRect().left < -1 ? Math.round(m.getBoundingClientRect().left) : null; });
        if (left !== null) report.clipped.push(`${label} ${href} @${width}: main starts at ${left}px`);
        if (width <= 430 || width === 768) for (const s of await page.evaluate(SPILL_SCRIPT)) report.spill.push(`${label} ${href} @${width}: ${s}`);
      }
    }
    await context.close();
  }
  const show = (title, list) => console.log(`INFO ${title}: ${list.length}${list.length ? '\n   ' + [...new Set(list)].slice(0, 30).join('\n   ') : ''}`);
  console.log(`INFO ${opened} screen x width combinations opened with stress data`);
  show('horizontal page overflow', report.overflow); show('clipped main content', report.clipped); show('text spilling out of its card', report.spill);
  assert.deepEqual(report.overflow, [], 'no page overflows horizontally with the longest unbreakable text');
  assert.deepEqual(report.clipped, [], 'no main content is clipped');
  assert.deepEqual(report.spill, [], 'no text spills out of its card');
  console.log('PASS (stress) the longest names, e-mail addresses, file names, notes and project names the forms accept never overflow, clip or spill at any of the twelve design widths (320 to 1920)');
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
