import assert from 'node:assert/strict';
import express from 'express';
import Database from 'better-sqlite3';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * The answer to a state-changing request is not sent until its transaction has committed.
 *
 * Found while correcting the headcount: first-timer-workflow failed about one run in ten with "the visitor is not there" straight after a 302. atomicRouter()
 * runs a route's final handler inside one transaction, but the handler calls res.redirect() from INSIDE it and Node sends those bytes at once, a moment before
 * COMMIT. Another process (here, the test's own connection) could be told "saved" and look before the row was committed - and a commit that then FAILED would
 * leave a person on a success page for a change that was never stored. (A browser asking for the next page of the same portal could not see the gap, because
 * the portal is one process; it is the second reader and the failing commit that matter.)
 *
 * Proven here against the real router and the real database module:
 *   1. when the client receives the answer, a second connection already sees the committed row (200 requests in a row, and 40 at once);
 *   2. a commit that FAILS (a deferred foreign key checked only at COMMIT) gives the client the error page, not the redirect, and stores nothing;
 *   3. a handler that throws, or an audit-style failure after the redirect call, never lets the redirect out;
 *   4. read routes are not delayed or wrapped.
 */

const env = createIsolatedTestEnv('cciq-atomic-response-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { default: db } = await import('../db/index.js');
const { atomicRouter } = await import('../lib/atomic-router.js');

db.exec(`
  CREATE TABLE probe_parent (id INTEGER PRIMARY KEY);
  CREATE TABLE probe_child (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT, parent_id INTEGER REFERENCES probe_parent(id) DEFERRABLE INITIALLY DEFERRED);
  CREATE TABLE probe_log (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT);
  INSERT INTO probe_parent (id) VALUES (1);
`);
assert.equal(db.pragma('foreign_keys', { simple: true }), 1, 'foreign keys are enforced');

const router = atomicRouter();
router.post('/ok', (req, res) => {
  db.prepare('INSERT INTO probe_child (label, parent_id) VALUES (?, 1)').run(req.query.label);
  res.redirect('/saved');
});
router.post('/commit-fails', (req, res) => {
  db.prepare('INSERT INTO probe_child (label, parent_id) VALUES (?, 999)').run(req.query.label); // nothing complains until COMMIT
  res.redirect('/saved');
});
router.post('/throws-after-redirect', (req, res) => {
  db.prepare('INSERT INTO probe_log (label) VALUES (?)').run(req.query.label);
  res.redirect('/saved');
  throw new Error('the audit row could not be written');
});
router.post('/renders', (req, res) => {
  db.prepare('INSERT INTO probe_log (label) VALUES (?)').run(req.query.label);
  res.status(201).json({ saved: req.query.label });
});
router.get('/read', (req, res) => res.json({ rows: db.prepare('SELECT COUNT(*) n FROM probe_child').get().n }));

const app = express();
app.use(router);
app.use((err, req, res, next) => { void next; res.status(500).type('text').send('error page'); });
const server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
const base = `http://127.0.0.1:${server.address().port}`;
const post = (path, label) => fetch(`${base}${path}?label=${encodeURIComponent(label)}`, { method: 'POST', redirect: 'manual' });
const outsider = new Database(env.databaseFile, { readonly: true }); // a second connection, as another process would have
const seen = (table, label) => outsider.prepare(`SELECT COUNT(*) n FROM ${table} WHERE label = ?`).get(label).n;

try {
  // 1. committed by the time the answer arrives
  for (let i = 0; i < 200; i += 1) {
    const res = await post('/ok', `row-${i}`);
    assert.equal(res.status, 302);
    assert.equal(res.headers.get('location'), '/saved');
    assert.equal(seen('probe_child', `row-${i}`), 1, `request ${i}: the row is already committed when the redirect arrives`);
  }
  const burst = await Promise.all(Array.from({ length: 40 }, (_, i) => post('/ok', `burst-${i}`).then((res) => ({ res, i }))));
  for (const { res, i } of burst) { assert.equal(res.status, 302); assert.equal(seen('probe_child', `burst-${i}`), 1); }
  const json = await post('/renders', 'json-1');
  assert.equal(json.status, 201);
  assert.deepEqual(await json.json(), { saved: 'json-1' }, 'a JSON answer arrives intact');
  assert.equal(seen('probe_log', 'json-1'), 1);
  console.log('PASS (1) 240 requests (200 in sequence, 40 at once): every redirect arrives only after a second connection can already see the committed row; JSON answers arrive intact');

  // 2. a commit that fails
  const bad = await post('/commit-fails', 'doomed');
  assert.equal(bad.status, 500, 'a failed commit is an error page, never "saved"');
  assert.equal(await bad.text(), 'error page');
  assert.equal(bad.headers.get('location'), null, 'and the redirect was never sent');
  assert.equal(seen('probe_child', 'doomed'), 0, 'nothing was stored');
  const after = await post('/ok', 'after-failure');
  assert.equal(after.status, 302, 'the next request is unaffected');
  assert.equal(seen('probe_child', 'after-failure'), 1);
  console.log('PASS (2) a commit that fails (a foreign key checked only at COMMIT) answers with the error page, not the redirect, and stores nothing');

  // 3. a handler that redirects and then fails
  const late = await post('/throws-after-redirect', 'late');
  assert.equal(late.status, 500, 'a handler that redirects and then throws never lets the redirect out');
  assert.equal(late.headers.get('location'), null);
  assert.equal(seen('probe_log', 'late'), 0, 'and its write was rolled back');
  console.log('PASS (3) a handler that calls res.redirect() and then fails: the client gets the error page and the write is rolled back');

  // 4. reads
  const read = await fetch(`${base}/read`);
  assert.equal(read.status, 200);
  assert.ok((await read.json()).rows >= 241);
  console.log('PASS (4) a read route is untouched');
} finally {
  await new Promise((resolve) => server.close(resolve));
  outsider.close();
  db.close();
  env.cleanup();
}
console.log('ALL PASS');
