import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { catalogue } from './lib/route-catalogue.mjs';
import { DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions.js';

/*
 * Every route, every role. The catalogue reads the guards off the source; the portal is then asked for each GET route as the
 * anonymous visitor and as each of the five roles, and each POST route without a CSRF token and (for guarded routes) by a
 * role that lacks the permission. Invariants - not a hand-written table, so a new route is covered the day it is added:
 *   1. nothing ever answers 5xx;
 *   2. the anonymous visitor reaches only the routes that are public on purpose;
 *   3. a role that lacks a route's guard is never answered 200 (and a Kiosk is confined to its own screens);
 *   4. a state change without a CSRF token is refused, on every POST route;
 *   5. a guarded POST from a role without the permission changes nothing.
 */

const f = await buildPortalFixture('cciq-rbac-matrix-');
const { db, ids, users } = f;
const portal = await startPortal();
try {
  const routes = catalogue();
  const gets = routes.filter((r) => r.method === 'GET');
  const posts = routes.filter((r) => r.method === 'POST');
  const roleKey = { superAdmin: 'super_admin', churchAdmin: 'church_admin', leaderA: 'cell_group_leader', memberA: 'member', kiosk: 'kiosk' };
  const permsOf = (user) => new Set(user.roleKeys.flatMap((r) => DEFAULT_ROLE_PERMISSIONS[r] || []));
  const roleOf = (user) => new Set(user.roleKeys);

  const firstRole = db.prepare('SELECT id FROM roles ORDER BY id LIMIT 1').get().id;
  const fill = (route) => {
    const p = route.path;
    const pick = (() => {
      if (p.startsWith('/members/')) return ids.member.a2;
      if (p.startsWith('/admin/users/')) return users.memberA.id;
      if (p.startsWith('/admin/roles/')) return firstRole;
      if (p.startsWith('/cell-groups/') || p.startsWith('/attendance/cell-groups/')) return ids.groupA;
      if (p.startsWith('/ministries/')) return ids.ministry;
      if (p.startsWith('/family-groups/')) return ids.family;
      if (p.startsWith('/visitors/')) return ids.visitor;
      if (p.startsWith('/activities/') || p.startsWith('/media/activity/')) return ids.activity;
      if (p.startsWith('/announcements/')) return ids.announcement;
      if (p.startsWith('/documents/')) return ids.document;
      if (p.startsWith('/attendance/sessions/')) return ids.session;
      if (p.startsWith('/projects/ecaq/claims/') || p.startsWith('/admin/ecaq/claims/')) return ids.claim;
      if (p.startsWith('/admin/ecaq/campaigns/')) return ids.board;
      if (p.startsWith('/admin/ecaq/faith-promise/commitments/')) return ids.commitment;
      if (p.startsWith('/notifications/')) return ids.notifications.memberA;
      return 999999;
    })();
    return p.replace(/:memberId(\([^)]*\))?/g, String(ids.member.a2))
      .replace(/:token(\([^)]*\))?/g, '0'.repeat(32))
      .replace(/:[a-zA-Z]+(\([^)]*\))?/g, String(pick));
  };

  const PUBLIC = new Set(['/healthz', '/login', '/forgot-password', '/about', '/about/cell-groups/:id(\\\\d+)/quick', '/about/ministries/:id(\\\\d+)/quick',
    '/about/leaders/:id(\\\\d+)/photo', '/about/cell-groups/:id(\\\\d+)/photo', '/about/ministries/:id(\\\\d+)/photo', '/quick-access/info', '/quick-access/card.png']);
  const isPublic = (route) => PUBLIC.has(route.path) || /^\/about\b/.test(route.path);
  const KIOSK_OK = (p) => p === '/kiosk' || p === '/kiosk/count' || p.startsWith('/attendance/checkin') || p.startsWith('/quick-access/') || p === '/account/password' || p === '/help' || p.startsWith('/help/') || p.startsWith('/media/members/');

  // ---- sign in once per role --------------------------------------------------------------------
  const sessions = {};
  for (const [key, user] of Object.entries(users)) {
    sessions[key] = await signIn(portal.base, user.email, f.PASSWORD);
    assert.ok([302, 303].includes(sessions[key].loginStatus), `${key} can sign in`);
  }
  const anonymous = { get: (url) => fetch(`${portal.base}${url}`, { redirect: 'manual' }) };

  // ---- 1-3: GET matrix ---------------------------------------------------------------------------
  const table = [];
  const problems = [];
  for (const route of gets) {
    const url = fill(route);
    if (url.includes('/report.csv') && false) continue;
    // anonymous
    let res = await anonymous.get(url);
    await res.arrayBuffer();
    if (res.status >= 500) problems.push(`anonymous ${url} -> ${res.status}`);
    if (!isPublic(route) && res.status === 200) problems.push(`anonymous reaches ${route.path}`);
    if (!isPublic(route) && res.status !== 200 && ![302, 303, 401, 403].includes(res.status)) problems.push(`anonymous ${url} -> ${res.status}`);
    for (const [key, user] of Object.entries(users)) {
      res = await sessions[key].get(url);
      await res.arrayBuffer();
      const status = res.status;
      table.push({ route: route.path, role: key, status });
      if (status >= 500) { problems.push(`${key} ${url} -> ${status}`); continue; }
      const held = permsOf(user);
      const roles = roleOf(user);
      const isKiosk = roles.has('kiosk') && roles.size === 1;
      const guardedOut = (route.all.length && !route.all.every((p) => held.has(p)))
        || (route.any.length && !route.any.some((p) => held.has(p)))
        || (route.roles.length && !route.roles.some((r) => roles.has(r)));
      if (isKiosk && !KIOSK_OK(route.path) && !isPublic(route)) {
        if (!(status === 302 && String(res.headers.get('location')).startsWith('/kiosk'))) problems.push(`kiosk reaches ${route.path} (${status})`);
      } else if (guardedOut && status === 200) {
        problems.push(`${key} reaches ${route.path}, which needs ${[...route.all, ...route.any, ...route.roles].join(',')}`);
      }
    }
  }
  // Sanity: the matrix is really exercising the portal (a Super Admin gets real pages, not a wall of redirects).
  const ok = (key) => table.filter((t) => t.role === key && t.status === 200).length;
  assert.ok(ok('superAdmin') >= gets.length * 0.6, `a Super Admin reaches most screens (${ok('superAdmin')}/${gets.length})`);
  assert.ok(ok('superAdmin') > ok('churchAdmin') && ok('churchAdmin') > ok('leaderA') && ok('leaderA') >= ok('memberA') && ok('memberA') > ok('kiosk'), 'access narrows from Super Admin to Kiosk');
  // Information: routes a role holds the permission for but is still refused (the handler scopes to an object the role does not own).
  const refusedDespitePermission = [];
  for (const row of table) {
    const route = gets.find((r) => r.path === row.route);
    const user = users[row.role]; const held = permsOf(user);
    const hasGuard = route.all.length || route.any.length;
    const holds = (!route.all.length || route.all.every((p) => held.has(p))) && (!route.any.length || route.any.some((p) => held.has(p))) && !route.roles.length;
    if (hasGuard && holds && row.status === 403) refusedDespitePermission.push(`${row.role} ${row.route}`);
  }
  console.log(`INFO ${refusedDespitePermission.length} (role, route) pairs hold the permission but were refused by the handler's own scoping: ${refusedDespitePermission.slice(0, 12).join('; ')}`);
  assert.deepEqual(problems, [], `GET matrix problems:\n  ${problems.join('\n  ')}`);
  console.log(`PASS (GET matrix) ${gets.length} routes x 5 roles + anonymous = ${table.length + gets.length} requests: no 5xx, anonymous reaches only public routes, no role reaches a route whose guard it lacks, the Kiosk is confined to its own screens`);

  // ---- 4: CSRF on every POST ---------------------------------------------------------------------
  const rowCount = () => ['members', 'users', 'visitors', 'visitor_visits', 'attendance_records', 'attendance_sessions', 'announcements', 'activities', 'documents',
    'family_groups', 'family_group_members', 'cell_groups', 'cell_group_members', 'ministries', 'ministry_members', 'reminders', 'ecaq_giving_board_claims',
    'ecaq_faith_promise_commitments', 'user_roles', 'roles', 'role_permissions', 'system_settings', 'backups', 'qr_checkins', 'church_leaders', 'notifications']
    .map((t) => `${t}=${db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n}`).join(' ');
  const snapshot = () => rowCount() + ' ' + JSON.stringify(db.prepare("SELECT status, COUNT(*) n FROM members GROUP BY status").all())
    + db.prepare('SELECT COALESCE(SUM(security_generation),0) s FROM users').get().s;
  const before = snapshot();
  const csrfProblems = [];
  for (const route of posts.filter((r) => r.path !== '/login')) {
    const url = fill(route);
    const res = await fetch(`${portal.base}${url}`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: sessions.superAdmin.cookie }, body: new URLSearchParams({ note: 'no token' })
    });
    await res.arrayBuffer();
    if (res.status !== 403) csrfProblems.push(`POST ${route.path} without a CSRF token -> ${res.status}`);
  }
  const loginNoToken = await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ email: users.superAdmin.email, password: f.PASSWORD }) });
  await loginNoToken.arrayBuffer();
  if (loginNoToken.status !== 403) csrfProblems.push(`POST /login without a CSRF token -> ${loginNoToken.status}`);
  assert.deepEqual(csrfProblems, [], `CSRF problems:\n  ${csrfProblems.join('\n  ')}`);
  assert.equal(snapshot(), before, 'nothing changed');
  console.log(`PASS (CSRF) all ${posts.length} POST routes refuse a request without the token (multipart routes included), and nothing changed`);

  // ---- 5: guarded POST by a role without the permission ---------------------------------------------
  const denied = [];
  let attempts = 0;
  const pristine = snapshot();
  for (const route of posts) {
    if (route.path === '/login' || route.path === '/logout') continue;
    if (!route.all.length && !route.any.length && !route.roles.length) continue;
    const url = fill(route);
    for (const key of ['memberA', 'leaderA', 'churchAdmin', 'kiosk']) {
      const user = users[key];
      const held = permsOf(user); const roles = roleOf(user);
      const guardedOut = (route.all.length && !route.all.every((p) => held.has(p)))
        || (route.any.length && !route.any.some((p) => held.has(p)))
        || (route.roles.length && !route.roles.some((r) => roles.has(r)));
      if (!guardedOut) continue;
      attempts += 1;
      const res = await sessions[key].post(url, { title: 'x', name: 'x', first_name: 'x', last_name: 'x', note: 'x', reason: 'x' });
      await res.arrayBuffer();
      const isKiosk = key === 'kiosk';
      const ok = isKiosk ? (res.status === 302 && String(res.headers.get('location')).startsWith('/kiosk')) : res.status === 403;
      if (!ok) denied.push(`${key} POST ${route.path} -> ${res.status} ${res.headers.get('location') || ''}`);
    }
  }
  assert.deepEqual(denied, [], `guarded POST problems:\n  ${denied.join('\n  ')}`);
  assert.equal(snapshot(), pristine, 'a denied POST changed nothing');
  console.log(`PASS (guarded POST) ${attempts} attempts by roles lacking the permission: every one refused (403, or back to the kiosk) and no row changed`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
