import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Model-based test of Membership Review. A small reference model that implements ONLY the approved rules (and reads nothing from
 * services/membership-review.js, attendance-outcomes.js or buildFridayContexts) is driven side by side with the real application through
 * thousands of seeded, random operations. After EVERY operation the application's reviews, notifications and First Timer links must equal
 * the model's.
 *
 * Approved rules, restated independently here:
 *   - the window is the newest FOUR eligible Fridays; eligible = finalized; cancelled and "not taken" Fridays are neutral (skipped);
 *     an unsettled Friday newer than every finalized one is ignored; an unsettled Friday after the first finalized one is a BARRIER;
 *   - a First Timer qualifies with visits on at least 3 of the four; declined, joined and linked First Timers never do;
 *   - at most one OPEN review per First Timer; reaching the rule while one is open does nothing;
 *   - Continue as Visitor suppresses until FOUR FURTHER finalized eligible Fridays exist after the anchor;
 *   - Review Later changes nothing; Convert and Link close the open review and stop evaluation;
 *   - the evaluator never creates a member; "joined" if and only if linked; one courtesy notification per batch that opens something.
 * A failure prints the seed and the last operations; set MODEL_SEED=<n> to replay one seed, MODEL_OPS=<n> to change its length.
 */

createIsolatedTestEnv('cciq-review-model-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const visitorsService = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const review = await import('../services/membership-review.js');
const { checkInvariants } = await import('../lib/db-invariants.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

await createUser({ username: 'model_admin', email: 'model.admin@fixture.invalid', password: 'Model-Fixture-Passw0rd!x', displayName: 'Model Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'model_admin'").get().id;

const FRIDAYS = 20;                                   // W(-20) .. W(-1), oldest first as index 0..19
const SERVICE = lastFridayOnOrBefore(today());
const dateOf = (i) => addDays(SERVICE, -7 * (FRIDAYS - i));
const OLD = addDays(SERVICE, -500);
const atNoon = (d) => `${d}T09:00:00.000Z`;
const VISITORS = 8;
const SEEDS = process.env.MODEL_SEED ? [Number(process.env.MODEL_SEED)] : Array.from({ length: 30 }, (_, n) => n + 1);
const OPS = Number(process.env.MODEL_OPS) || 500;

function rng(seed) { // mulberry32
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

function oldMember(first) {
  const m = createMember({ first_name: first, last_name: 'Pool' }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', atNoon(OLD));
  return m.id;
}

// ---------------------------------------------------------------------------------------------------------------------------------------
// The reference model
// ---------------------------------------------------------------------------------------------------------------------------------------
class Model {
  constructor(visitorIds) {
    this.visitors = new Map(visitorIds.map((id) => [id, { declined: false, joined: false }]));
    this.visits = new Map(visitorIds.map((id) => [id, new Set()]));
    this.reviews = [];            // { vid, status, trigger, anchor }
    this.batches = 0;
  }
  /** phase of each Friday from the raw columns (the attendance engine is the oracle for WHAT happened to a Friday) */
  static phases() {
    const rows = db.prepare("SELECT service_date, status, finalization_state FROM attendance_sessions WHERE service_type = 'friday_service' ORDER BY service_date").all();
    return rows.map((r) => (r.status === 'cancelled' ? 'cancelled' : r.finalization_state === 'finalized' ? 'finalized' : r.finalization_state === 'not_taken' ? 'not_taken' : 'unsettled'));
  }
  window(phases) {
    const found = []; let leading = true;
    for (let i = FRIDAYS - 1; i >= 0; i -= 1) {
      const p = phases[i];
      if (p === 'cancelled' || p === 'not_taken') continue;
      if (p === 'finalized') { found.push(i); leading = false; if (found.length === 4) break; continue; }
      if (leading) continue;
      return { blocked: true, found };
    }
    return { blocked: false, found };
  }
  openFor(vid) { return this.reviews.find((r) => r.vid === vid && r.status === 'open') || null; }
  evaluate(phases) {
    const { blocked, found } = this.window(phases);
    if (blocked || found.length < 4) return;
    let opened = 0;
    for (const [vid, v] of this.visitors) {
      if (v.joined || v.declined || this.openFor(vid)) continue;
      const hits = found.filter((i) => this.visits.get(vid).has(i)).length;
      if (hits < 3) continue;
      const anchors = this.reviews.filter((r) => r.vid === vid && r.status === 'continued').map((r) => r.anchor);
      if (anchors.length) {
        const anchor = anchors.sort().pop();
        const newer = phases.map((p, i) => (p === 'finalized' && dateOf(i) > anchor ? 1 : 0)).reduce((a, b) => a + b, 0);
        if (newer < 4) { stats.suppressedChecks += 1; continue; } // fewer than four further finalized eligible Fridays: still suppressed
      }
      this.reviews.push({ vid, status: 'open', trigger: dateOf(found[0]), anchor: null });
      opened += 1;
    }
    if (opened > 0) this.batches += 1;
  }
  continueReview(vid, phases) {
    const open = this.openFor(vid);
    const newestFinalized = phases.map((p, i) => (p === 'finalized' ? dateOf(i) : null)).filter(Boolean).sort().pop() || null;
    open.status = 'continued';
    open.anchor = [newestFinalized, open.trigger].filter(Boolean).sort().pop();
  }
  closeOpen(vid, status) { const open = this.openFor(vid); if (open) open.status = status; }
}

// ---------------------------------------------------------------------------------------------------------------------------------------
// One seeded run
// ---------------------------------------------------------------------------------------------------------------------------------------
let totalOps = 0; const opCounts = {};
const stats = { opened: 0, continued: 0, reopenedAfterContinue: 0, suppressedChecks: 0 };
function resetWorld() {
  db.pragma('foreign_keys = OFF');
  db.exec('DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM notifications; DELETE FROM reminders; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors;');
  db.pragma('foreign_keys = ON');
  setSetting('attendance.tracking_start_date', dateOf(0));
}

function runSeed(seed) {
  const rand = rng(seed);
  const pick = (list) => list[Math.floor(rand() * list.length)];
  resetWorld();
  const sessions = [];
  for (let i = 0; i < FRIDAYS; i += 1) {
    db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(dateOf(i), atNoon(dateOf(i)));
    sessions.push(db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(dateOf(i)).id);
  }
  const vids = [];
  for (let n = 0; n < VISITORS; n += 1) vids.push(visitorsService.createVisitor({ first_name: `M${seed}v${n}`, last_name: 'Model', first_visit_date: OLD }, { userId: null }).id);
  const model = new Model(vids);
  const pool = Array.from({ length: 5 }, (_, n) => oldMember(`P${seed}x${n}`));
  const log = [];
  const membersBefore = () => db.prepare('SELECT COUNT(*) n FROM members').get().n;

  const phasesNow = () => Model.phases();
  const evaluateModel = () => model.evaluate(phasesNow());

  const regulars = vids.slice(0, 3);            // people who keep coming: they are what makes reviews (and suppression) actually happen
  const phaseList = () => phasesNow();
  const unsettledIndexes = () => phaseList().map((p, i) => (p === 'unsettled' ? i : -1)).filter((i) => i >= 0);
  const ops = [
    ['attend_round', 16, () => { // a Friday's attendance: the regulars almost always, the others now and then
      const i = Math.floor(rand() * FRIDAYS); let count = 0;
      for (const vid of vids) {
        if (rand() < (regulars.includes(vid) ? 0.85 : 0.18)) {
          const r = visitorsService.recordVisit(vid, { date: dateOf(i), sessionId: sessions[i], userId: adminId });
          if (r.ok !== false) { model.visits.get(vid).add(i); count += 1; }
        }
      }
      return `attend_round F${i} (${count} visits)`;
    }],
    ['attend', 12, () => { // a Kiosk / register style visit: recorded, nothing evaluated until a Friday is finalized
      const vid = pick(vids); const i = Math.floor(rand() * FRIDAYS);
      const r = visitorsService.recordVisit(vid, { date: dateOf(i), sessionId: sessions[i], userId: adminId });
      if (r.ok !== false) model.visits.get(vid).add(i);
      return `attend v${vids.indexOf(vid)} F${i}`;
    }],
    ['manual', 9, () => { // an administrator records a past visit: the route evaluates afterwards
      const vid = pick(vids); const i = Math.floor(rand() * FRIDAYS); const linked = rand() < 0.5;
      const r = visitorsService.recordVisit(vid, { date: dateOf(i), sessionId: linked ? sessions[i] : null, userId: adminId });
      if (r.ok !== false) model.visits.get(vid).add(i);
      review.evaluateSafely('manual-visit'); evaluateModel();
      return `manual v${vids.indexOf(vid)} F${i}${linked ? '' : ' (dated only)'}`;
    }],
    ['finalize', 26, () => {
      const open = unsettledIndexes();
      const i = open.length && rand() < 0.8 ? open[0] : Math.floor(rand() * FRIDAYS); // usually the oldest unsettled Friday, as in real use
      const r = lifecycle.finalizeAttendance(sessions[i], { userId: adminId, confirmNoAttendance: true });
      if (r.ok) evaluateModel();
      return `finalize F${i} -> ${r.ok ? 'ok' : r.reason}`;
    }],
    ['not_taken', 2, () => {
      const i = Math.floor(rand() * FRIDAYS);
      const r = lifecycle.markAttendanceNotTaken(sessions[i], { userId: adminId, note: 'model', confirmExistingAttendance: true });
      if (r.ok) evaluateModel();
      return `not_taken F${i} -> ${r.ok ? 'ok' : r.reason}`;
    }],
    ['reopen', 3, () => {
      const i = Math.floor(rand() * FRIDAYS);
      const r = lifecycle.reopenAttendance(sessions[i], { userId: adminId, reason: 'model' });
      if (r.ok) evaluateModel();
      return `reopen F${i} -> ${r.ok ? 'ok' : r.reason}`;
    }],
    ['cancel', 2, () => {
      const i = Math.floor(rand() * FRIDAYS);
      const r = lifecycle.changeSessionStatus(sessions[i], 'cancelled', { userId: adminId });
      if (r.ok && r.cancelling) evaluateModel(); // the engine announces only a real change of status
      return `cancel F${i} -> ${r.ok ? 'ok' : r.reason}`;
    }],
    ['reinstate', 4, () => {
      const i = Math.floor(rand() * FRIDAYS);
      const r = lifecycle.changeSessionStatus(sessions[i], 'held', { userId: adminId });
      if (r.ok && r.reinstating) evaluateModel();
      return `reinstate F${i} -> ${r.ok ? 'ok' : r.reason}`;
    }],
    ['continue', 14, () => {
      const open = [...vids].filter((v) => model.openFor(v));
      if (!open.length) return 'continue (none open)';
      const vid = pick(open); const row = db.prepare("SELECT id FROM visitor_membership_reviews WHERE visitor_id = ? AND status = 'open'").get(vid);
      const phases = phasesNow();
      const r = review.continueAsVisitor(row.id, { userId: adminId });
      assert.equal(r.ok, true, 'continuing an open review works');
      model.continueReview(vid, phases);
      return `continue v${vids.indexOf(vid)}`;
    }],
    ['review_later', 3, () => { // reading a review is all "Review later" is
      const open = db.prepare("SELECT id FROM visitor_membership_reviews WHERE status = 'open' LIMIT 1").get();
      if (open) review.getReview(open.id);
      review.listReviews({ status: 'open' });
      return 'review_later';
    }],
    ['convert', 0.5, () => {
      const candidates = vids.filter((v) => !model.visitors.get(v).joined);
      if (!candidates.length) return 'convert (none)';
      const vid = pick(candidates);
      const r = visitorsService.convertToMember(vid, { userId: adminId });
      assert.equal(r.ok, true, 'convert works for a First Timer who is not yet a member');
      model.visitors.get(vid).joined = true; model.closeOpen(vid, 'converted');
      return `convert v${vids.indexOf(vid)}`;
    }],
    ['link', 0.5, () => {
      const candidates = vids.filter((v) => !model.visitors.get(v).joined);
      if (!candidates.length || !pool.length) return 'link (none)';
      const vid = pick(candidates); const memberId = pool.pop();
      const r = visitorsService.linkVisitorToMember(vid, memberId, { userId: adminId });
      assert.equal(r.ok, true, 'link works for a free member');
      model.visitors.get(vid).joined = true; model.closeOpen(vid, 'linked');
      return `link v${vids.indexOf(vid)}`;
    }],
    ['decline', 1.5, () => {
      const vid = pick(vids); const m = model.visitors.get(vid);
      if (m.joined) return 'decline (joined)';
      const r = visitorsService.setVisitorState(vid, m.declined ? 'returning' : 'declined', { userId: adminId });
      if (r.ok) m.declined = !m.declined;
      return `${m.declined ? 'decline' : 'undecline'} v${vids.indexOf(vid)}`;
    }],
    ['scheduled', 5, () => { review.evaluateSafely('scheduled'); evaluateModel(); return 'scheduled evaluation'; }]
  ];
  const total = ops.reduce((s, o) => s + o[1], 0);

  for (let n = 0; n < OPS; n += 1) {
    let roll = rand() * total; let op = ops[0];
    for (const o of ops) { roll -= o[1]; if (roll <= 0) { op = o; break; } }
    const membersStart = membersBefore();
    const note = op[2]();
    log.push(note); totalOps += 1; opCounts[op[0]] = (opCounts[op[0]] || 0) + 1;
    try {
      compare(model, vids, sessions);
      if (/^convert v/.test(note)) assert.equal(membersBefore(), membersStart + 1, 'convert creates exactly one member');
      else assert.equal(membersBefore(), membersStart, `${op[0]} never creates a member`);
    } catch (err) {
      console.error(`MODEL MISMATCH seed=${seed} op#${n + 1} (${note})\nlast operations:\n  ${log.slice(-14).join('\n  ')}\nreplay with: MODEL_SEED=${seed} node src/tests/membership-review-model.mjs`);
      throw err;
    }
  }
  stats.opened += model.reviews.length; stats.continued += model.reviews.filter((r) => r.status === 'continued').length;
  for (const vid of vids) { const list = model.reviews.filter((r) => r.vid === vid); stats.reopenedAfterContinue += list.filter((r, k) => k > 0 && list[k - 1].status === 'continued').length; }
  return { reviews: model.reviews.length, batches: model.batches };
}

function compare(model, vids) {
  const rows = db.prepare('SELECT id, visitor_id, status, trigger_service_date, suppress_after_date FROM visitor_membership_reviews ORDER BY id').all();
  for (const vid of vids) {
    const actual = rows.filter((r) => r.visitor_id === vid).map((r) => r.status);
    const expected = model.reviews.filter((r) => r.vid === vid).map((r) => r.status);
    assert.deepEqual(actual, expected, `reviews of visitor ${vid} (statuses, oldest first)`);
    assert.ok(actual.filter((s) => s === 'open').length <= 1, 'at most one open review');
    const detail = rows.filter((r) => r.visitor_id === vid).map((r) => `${r.trigger_service_date}|${r.suppress_after_date || ''}`);
    const modelDetail = model.reviews.filter((r) => r.vid === vid).map((r) => `${r.trigger}|${r.anchor || ''}`);
    assert.deepEqual(detail, modelDetail, `trigger Friday and suppression anchor of visitor ${vid}'s reviews`);
    const v = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(vid);
    assert.equal(Boolean(v.member_id), model.visitors.get(vid).joined, `linked iff the model says so (visitor ${vid})`);
    assert.equal(v.state === 'joined', Boolean(v.member_id), 'joined if and only if linked');
    assert.equal(v.state === 'declined', model.visitors.get(vid).declined && !v.member_id, `declined state (visitor ${vid})`);
  }
  assert.equal(db.prepare("SELECT COUNT(*) n FROM notifications WHERE category = 'membership_review'").get().n, model.batches, 'one notification per batch that opened a review, never one for an already-open review');
  const open = db.prepare("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'").get().n;
  assert.equal(open, model.reviews.filter((r) => r.status === 'open').length, 'open review count');
}

const summary = [];
for (const seed of SEEDS) {
  const result = runSeed(seed);
  summary.push(`seed ${seed}: ${result.reviews} reviews, ${result.batches} notification batches`);
  const bad = checkInvariants(db).findings.filter((f) => f.severity === 'error' && /^(visitor|review)\./.test(f.code));
  assert.deepEqual(bad, [], `seed ${seed}: the integrity checker finds no First Timer or review error`);
}
const reviewsTotal = db.prepare('SELECT COUNT(*) n FROM visitor_membership_reviews').get().n;
console.log(`INFO ${SEEDS.length} seeds x ${OPS} operations = ${totalOps} operations compared with the model after every step`);
console.log(`INFO operation mix: ${Object.entries(opCounts).sort().map(([k, v]) => `${k} ${v}`).join(', ')}`);
console.log(`INFO ${summary.join('; ')}`);
assert.ok(opCounts.finalize > 400 && opCounts.attend_round > 300, 'the run exercised finalizations and attendance in volume');
assert.ok(stats.opened >= 100, `reviews really were opened (${stats.opened}): the model is not agreeing about nothing`);
assert.ok(stats.continued >= 30, `Continue as Visitor really happened (${stats.continued})`);
assert.ok(stats.reopenedAfterContinue >= 5, `suppression really ended and a new review opened for the same person (${stats.reopenedAfterContinue} times)`);
assert.ok(stats.suppressedChecks >= 5, 'and suppression really held back a qualifying First Timer');
void reviewsTotal;
console.log(`PASS (model) ${totalOps} seeded random operations: the application's reviews, suppression anchors, notifications and First Timer links equalled the independent model after every one`);
console.log('ALL PASS');
