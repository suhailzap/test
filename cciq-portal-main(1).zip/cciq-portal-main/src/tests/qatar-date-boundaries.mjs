import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Qatar is UTC+3 with no daylight saving: from 21:00 UTC the Qatar calendar is already on the next day. Everything the
 * portal shows or decides by calendar date must use the Qatar date, never the UTC date. This suite pins the clock at the
 * edges (midnight, Thursday->Friday, Friday->Saturday, New Year, leap day) and checks the helpers, the validator and a
 * rendered page that shows a stored timestamp as a date.
 */

const RealDate = Date;
function clockAt(iso) {
  const fixed = new RealDate(iso).getTime();
  globalThis.Date = class extends RealDate {
    constructor(...args) { if (args.length === 0) super(fixed); else super(...args); }
    static now() { return fixed; }
  };
}
const restoreClock = () => { globalThis.Date = RealDate; };

const f = await buildPortalFixture('cciq-qatar-dates-');
const { db, mods } = f;
const d = mods.dates;

try {
  // ---- the day turns over at 21:00 UTC --------------------------------------------------------------------------------------
  clockAt('2026-06-30T20:59:59.999Z'); assert.equal(d.today(), '2026-06-30', '23:59:59 in Qatar is still the 30th');
  clockAt('2026-06-30T21:00:00.000Z'); assert.equal(d.today(), '2026-07-01', 'midnight in Qatar is the 1st');
  clockAt('2026-12-31T21:00:00.000Z'); assert.equal(d.today(), '2027-01-01', 'New Year arrives in Qatar three hours before UTC');
  clockAt('2026-12-31T20:59:59.000Z'); assert.equal(d.today(), '2026-12-31');
  clockAt('2028-02-28T21:00:00.000Z'); assert.equal(d.today(), '2028-02-29', 'a leap day is reached');
  console.log('PASS (today) the Qatar date turns over at 21:00 UTC, including New Year and a leap day');

  // ---- Friday is decided by the Qatar calendar -------------------------------------------------------------------------------
  clockAt('2026-10-01T20:59:59Z'); assert.equal(d.isFriday(d.today()), false, 'Thursday 23:59 in Qatar is not Friday');
  clockAt('2026-10-01T21:00:00Z'); assert.equal(d.today(), '2026-10-02'); assert.equal(d.isFriday(d.today()), true, 'Friday 00:00 in Qatar is Friday');
  assert.equal(d.nextFridayOnOrAfter(), '2026-10-02'); assert.equal(d.lastFridayOnOrBefore(), '2026-10-02');
  clockAt('2026-10-02T20:59:59Z'); assert.equal(d.isFriday(d.today()), true, 'Friday 23:59 is still Friday');
  clockAt('2026-10-02T21:00:00Z'); assert.equal(d.isFriday(d.today()), false, 'Saturday 00:00 is not');
  assert.equal(d.nextFridayOnOrAfter(), '2026-10-09'); assert.equal(d.lastFridayOnOrBefore(), '2026-10-02');
  console.log('PASS (friday) Thursday->Friday and Friday->Saturday flip at 21:00 UTC, and next/last Friday follow');

  // ---- stored timestamps become Qatar dates --------------------------------------------------------------------------------------
  assert.equal(d.qatarDateOf('2026-06-30T21:30:00.000Z'), '2026-07-01');
  assert.equal(d.qatarDateOf('2026-06-30T20:59:59.999Z'), '2026-06-30');
  assert.equal(d.qatarDateOf('2026-12-31T23:00:00.000Z'), '2027-01-01');
  assert.equal(d.qatarDateOf('not a date'), null);
  assert.match(d.formatTimestamp('2026-06-30T21:30:00.000Z'), /^01 Jul 2026, 12:30 am$/i);
  assert.match(d.formatTimestamp('2026-06-30T20:30:00.000Z'), /^30 Jun 2026, 11:30 pm$/i);
  console.log('PASS (timestamps) a UTC timestamp after 21:00 is shown on the next Qatar date, with the right clock time');

  // ---- pure calendar arithmetic ---------------------------------------------------------------------------------------------------
  restoreClock();
  assert.equal(d.isValidDate('2026-02-29'), false); assert.equal(d.isValidDate('2028-02-29'), true);
  assert.equal(d.isValidDate('2026-13-01'), false); assert.equal(d.isValidDate('2026-4-01'), false); assert.equal(d.isValidDate('2026-04-31'), false);
  assert.equal(d.addDays('2028-02-28', 1), '2028-02-29'); assert.equal(d.addDays('2026-02-28', 1), '2026-03-01');
  assert.equal(d.addDays('2026-12-31', 1), '2027-01-01'); assert.equal(d.addDays('2026-01-01', -1), '2025-12-31');
  assert.equal(d.diffInDays('2026-03-28', '2026-03-29'), 1, 'no daylight-saving hour is lost or gained in Qatar (or in any calendar diff)');
  assert.equal(d.diffInDays('2026-01-01', '2027-01-01'), 365);
  assert.deepEqual(d.fridaysBetween('2026-10-02', '2026-10-16'), ['2026-10-02', '2026-10-09', '2026-10-16'], 'both ends inclusive');
  assert.deepEqual(d.fridaysBetween('2026-10-03', '2026-10-08'), [], 'no Friday inside the range');
  assert.equal(d.fridaysBetween('2026-01-01', '2026-12-31').length, 52);
  assert.equal(d.yearsSince('2000-06-15', '2018-06-14'), 17, 'the day before the 18th birthday');
  assert.equal(d.yearsSince('2000-06-15', '2018-06-15'), 18, 'on the 18th birthday');
  assert.equal(d.yearsSince('2000-02-29', '2019-02-28'), 18); assert.equal(d.yearsSince('2000-02-29', '2019-03-01'), 19);
  assert.equal(d.nextAnniversaryOf('2000-02-29', '2027-01-01'), '2027-02-28', 'a 29 February birthday falls on 28 February in a common year');
  assert.equal(d.nextAnniversaryOf('2000-02-29', '2028-01-01'), '2028-02-29');
  assert.equal(d.nextAnniversaryOf('1990-06-15', '2026-06-15'), '2026-06-15', 'today counts');
  assert.equal(d.nextAnniversaryOf('1990-06-15', '2026-06-16'), '2027-06-15');
  assert.equal(d.nextAnniversaryOf('1990-01-01', '2026-12-31'), '2027-01-01', 'across New Year');
  assert.equal(d.daysUntil('2026-12-25', '2026-12-24'), 1);
  assert.equal(d.formatDate('2026-02-30'), '', 'an impossible date renders as nothing rather than another date');
  assert.equal(d.formatTime('00:05'), '12:05 am'); assert.equal(d.formatTime('12:00'), '12:00 pm'); assert.equal(d.formatTime('24:00'), '', 'out-of-range clock text is not guessed at');
  console.log('PASS (arithmetic) month/year/leap edges, inclusive Friday ranges, birthdays and 29 February behave');

  // ---- the validator's "not in the future" rule uses today in Qatar ------------------------------------------------------------------
  const { Validator } = await import('../lib/validate.js');
  clockAt('2026-06-30T22:00:00.000Z'); // 01:00 on 1 July in Qatar; still 30 June in UTC
  let v = new Validator({ joined: '2026-07-01' }); v.date('joined', { notFuture: true, label: 'Joined' });
  assert.equal(v.valid, true, 'the Qatar date "today" is accepted in the first three hours after midnight');
  v = new Validator({ joined: '2026-07-02' }); v.date('joined', { notFuture: true, label: 'Joined' });
  assert.equal(v.valid, false, 'tomorrow is still refused');
  clockAt('2026-06-30T20:59:59.000Z');
  v = new Validator({ joined: '2026-07-01' }); v.date('joined', { notFuture: true, label: 'Joined' });
  assert.equal(v.valid, false, 'and at 23:59 Qatar time 1 July is tomorrow');
  console.log('PASS (validator) "cannot be in the future" follows the Qatar date (accepted just after Qatar midnight, refused a day ahead)');

  // ---- a rendered page shows stored timestamps on the Qatar date ----------------------------------------------------------------------
  restoreClock();
  const row = db.prepare("SELECT cell_group_id, member_id FROM cell_group_members WHERE left_at IS NULL LIMIT 1").get();
  db.prepare('UPDATE cell_group_members SET joined_at = ? WHERE cell_group_id = ? AND member_id = ?').run('2026-06-30T21:30:00.000Z', row.cell_group_id, row.member_id);
  const portal = await startPortal();
  try {
    const admin = await signIn(portal.base, f.users.churchAdmin.email, f.PASSWORD);
    const page = await (await admin.get(`/members/${row.member_id}?tab=cell-group`)).text();
    assert.match(page, /1 Jul 2026/, 'a membership stored at 21:30 UTC on 30 June is shown as 1 Jul 2026 (Qatar)');
    assert.doesNotMatch(page, /30 Jun 2026/);
  } finally {
    await portal.stop();
  }
  console.log('PASS (render) a timestamp stored at 21:30 UTC is shown on the next Qatar date on the member page');

  // ---- nothing new slips back in: today's date is never taken from the UTC clock --------------------------------------------------
  const fsm = await import('node:fs'); const pathm = await import('node:path'); const url = await import('node:url');
  const src = pathm.join(pathm.dirname(url.fileURLToPath(import.meta.url)), '..');
  const banned = ['new Date().toISOString().slice(0, 10)', 'nowIso().slice(0, 10)', 'new Date().getUTCFullYear', 'new Date().getFullYear'];
  const offenders = [];
  const walk = (dir) => {
    for (const e of fsm.readdirSync(dir, { withFileTypes: true })) {
      const p = pathm.join(dir, e.name);
      if (e.isDirectory()) { if (!['tests', 'public'].includes(e.name)) walk(p); continue; }
      if (!e.name.endsWith('.js') && !e.name.endsWith('.ejs')) continue;
      const text = fsm.readFileSync(p, 'utf8');
      if (banned.some((b) => text.includes(b))) offenders.push(pathm.relative(src, p).split(pathm.sep).join('/'));
    }
  };
  walk(src);
  // views/members/form.ejs runs in the browser (age hint while typing), where the browser clock is the only clock there is.
  assert.deepEqual(offenders.filter((o) => o !== 'views/members/form.ejs'), [], 'use today() (Qatar), not the UTC clock, for the current date or year');
  console.log('PASS (static) no server code takes the current date or year from the UTC clock');
} finally {
  restoreClock();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
