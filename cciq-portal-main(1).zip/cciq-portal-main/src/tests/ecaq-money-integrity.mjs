import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * ECAQ money handling: a payment and the total it changes are one unit; totals are exact to the cent; releasing a date
 * never silently destroys payments; the board never shows more than the campaign's privacy setting allows.
 */

const f = await buildPortalFixture('cciq-ecaq-money-');
const { db, ids, users, mods } = f;
const ecaq = mods.ecaq;
const faith = mods.faith;
const moneyFindings = () => checkInvariants(db).findings.filter((x) => x.code.startsWith('ecaq.'));
const year = Number(mods.dates.today().slice(0, 4));
const dates = ecaq.boardDates(year);
const claimRow = (id) => db.prepare('SELECT * FROM ecaq_giving_board_claims WHERE id = ?').get(id);
const paymentCount = (claimId) => db.prepare('SELECT COUNT(*) n FROM ecaq_payments WHERE claim_id = ?').get(claimId).n;

// ---- exact to the cent ---------------------------------------------------------------------------------------------------------
const made = ecaq.createClaim({ campaignId: ids.board, date: dates[5], memberId: ids.member.a3, commitmentAmount: 1, userId: users.churchAdmin.id });
assert.ok(made.ok);
const claimId = made.claim.id;
for (let i = 0; i < 10; i += 1) ecaq.addPayment(claimId, { amount: 0.1, paid_on: mods.dates.today() }, { userId: users.churchAdmin.id });
assert.equal(claimRow(claimId).amount_collected, 1, 'ten payments of 0.10 total exactly 1.00 (not 0.9999999999999999)');
assert.equal(claimRow(claimId).payment_status, 'paid', 'and the commitment is therefore paid, with no phantom balance');
const third = ecaq.createClaim({ campaignId: ids.board, date: dates[6], memberId: ids.member.a3, commitmentAmount: 100, userId: users.churchAdmin.id }).claim.id;
for (const amount of [33.33, 33.33, 33.34]) ecaq.addPayment(third, { amount }, { userId: users.churchAdmin.id });
assert.equal(claimRow(third).amount_collected, 100);
assert.equal(claimRow(third).payment_status, 'paid');
ecaq.deletePayment(db.prepare('SELECT MAX(id) id FROM ecaq_payments WHERE claim_id = ?').get(third).id);
assert.equal(claimRow(third).amount_collected, 66.66);
assert.equal(claimRow(third).payment_status, 'partially_paid');
const firstPayment = db.prepare('SELECT MIN(id) id FROM ecaq_payments WHERE claim_id = ?').get(third).id;
assert.ok(ecaq.updatePayment(firstPayment, { amount: 40 }).ok);
assert.equal(claimRow(third).amount_collected, 73.33, 'editing a payment recalculates the claim');
assert.deepEqual(moneyFindings().filter((x) => x.severity === 'error'), [], 'every total equals the sum of its payments');

const commitmentId = ids.commitment;
for (let i = 0; i < 10; i += 1) faith.addPayment(commitmentId, { received_by: 'Fixture Receiver', amount: 0.1 }, { userId: users.churchAdmin.id });
assert.equal(db.prepare('SELECT amount_collected a FROM ecaq_faith_promise_commitments WHERE id = ?').get(commitmentId).a, 1);
assert.ok(faith.addPayment(commitmentId, { received_by: 'Fixture Receiver', amount: 599 }, { userId: users.churchAdmin.id }).ok);
const done = db.prepare('SELECT amount_collected a, status s, expected_total e FROM ecaq_faith_promise_commitments WHERE id = ?').get(commitmentId);
assert.equal(done.a, 600); assert.equal(done.s, 'completed', `Faith Promise: 600 collected of ${done.e} is completed`);
console.log('PASS (cents) repeated small payments total exactly; status follows the exact total; edits and removals recalculate');

// ---- a payment and its total are one unit ------------------------------------------------------------------------------------------
db.exec("CREATE TRIGGER inject_claim_fail BEFORE UPDATE ON ecaq_giving_board_claims BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
const before = paymentCount(claimId);
assert.throws(() => ecaq.addPayment(claimId, { amount: 5 }, { userId: users.churchAdmin.id }), /injected failure/);
assert.equal(paymentCount(claimId), before, 'a payment whose total could not be updated is not left on file');
assert.throws(() => ecaq.deletePayment(db.prepare('SELECT MIN(id) id FROM ecaq_payments WHERE claim_id = ?').get(claimId).id), /injected failure/);
assert.equal(paymentCount(claimId), before, 'a payment removal whose total could not be updated is undone');
const beforeClaims = db.prepare('SELECT COUNT(*) n FROM ecaq_giving_board_claims').get().n;
assert.throws(() => ecaq.createClaim({ campaignId: ids.board, date: dates[9], memberId: ids.member.a3, displayAs: 'The Zs', userId: users.churchAdmin.id }), /injected failure/);
assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_giving_board_claims').get().n, beforeClaims, 'a claim whose display label could not be saved is not half-created');
db.exec('DROP TRIGGER inject_claim_fail');
db.exec("CREATE TRIGGER inject_fp_fail BEFORE UPDATE ON ecaq_faith_promise_commitments BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
const fpBefore = db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE commitment_id = ?').get(commitmentId).n;
assert.throws(() => faith.addPayment(commitmentId, { received_by: 'Fixture Receiver', amount: 7 }, { userId: users.churchAdmin.id }), /injected failure/);
assert.equal(db.prepare('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE commitment_id = ?').get(commitmentId).n, fpBefore, 'same for Faith Promise payments');
db.exec('DROP TRIGGER inject_fp_fail');
assert.deepEqual(moneyFindings().filter((x) => x.severity === 'error'), []);
console.log('PASS (atomic) a payment, a removal, a claim with its label and a Faith Promise payment each succeed or vanish whole');

// ---- claim rules -----------------------------------------------------------------------------------------------------------------------
assert.equal(ecaq.createClaim({ campaignId: ids.board, date: dates[5], memberId: ids.member.a2 }).reason, 'already_claimed', 'a date is taken once');
assert.equal(ecaq.createClaim({ campaignId: ids.board, date: `${year + 1}-01-01`, memberId: ids.member.a2 }).reason, 'date_not_in_campaign');
assert.equal(ecaq.createClaim({ campaignId: ids.board, date: `${year}-02-30`, memberId: ids.member.a2 }).reason, 'date_not_in_campaign');
assert.equal(ecaq.createClaim({ campaignId: 999999, date: dates[1], memberId: ids.member.a2 }).reason, 'no_campaign');
assert.equal(ecaq.boardDates(2028).length, 366); assert.equal(ecaq.boardDates(2027).length, 365);
assert.ok(ecaq.boardDates(2028).includes('2028-02-29')); assert.ok(!ecaq.boardDates(2027).includes('2027-02-29'));
const draft = ecaq.createCampaign({ name: 'Draft board', year: year + 3, type: 'giving_board', status: 'draft' });
assert.equal(ecaq.createClaim({ campaignId: draft.id, date: `${year + 3}-03-03`, memberId: ids.member.a2 }).reason, 'campaign_not_active', 'a draft board takes no claims');
console.log('PASS (claims) one claimant per date; dates outside the campaign, impossible dates, unknown and draft campaigns are refused; leap years have 366 dates');

// ---- release never destroys payments ---------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const auditCount = (action) => db.prepare('SELECT COUNT(*) n FROM audit_logs WHERE action = ?').get(action).n;

  let res = await admin.post(`/admin/ecaq/claims/${claimId}/release`, { reason: 'test' });
  await res.arrayBuffer();
  assert.ok(claimRow(claimId), 'a claim with payments is not released');
  assert.ok(paymentCount(claimId) >= 10, 'and its payments are untouched');
  assert.equal(auditCount('giving.claim_released'), 0, 'a refused release leaves no "released" audit row');

  const empty = ecaq.createClaim({ campaignId: ids.board, date: dates[20], memberId: ids.member.a3, userId: users.churchAdmin.id }).claim.id;
  res = await admin.post(`/admin/ecaq/claims/${empty}/release`, { reason: 'entered by mistake' });
  await res.arrayBuffer();
  assert.equal(claimRow(empty), undefined, 'a claim with no payments is released');
  assert.equal(auditCount('giving.claim_released'), 1, 'and audited');
  assert.ok(ecaq.createClaim({ campaignId: ids.board, date: dates[20], memberId: ids.member.a2 }).ok, 'the freed date can be taken again');

  // ---- privacy on the board -------------------------------------------------------------------------------------------------------------
  const viewer = await signIn(portal.base, users.memberB?.email || users.leaderA.email, f.PASSWORD);
  for (const mode of ['claimed', 'private']) {
    db.prepare('UPDATE ecaq_campaigns SET privacy_mode = ? WHERE id = ?').run(mode, ids.board);
    const page = await (await viewer.get('/projects/ecaq/board')).text();
    assert.doesNotMatch(page, /Anna|MemberA|Newmember|Zaragosa/, `the board shows no member name in "${mode}" mode`);
  }
  db.prepare("UPDATE ecaq_campaigns SET privacy_mode = 'first_name' WHERE id = ?").run(ids.board);
  console.log('PASS (release + privacy) a release never deletes payments; a payment-free release frees the date and is audited; "claimed"/"private" boards show no names');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
