import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness: independent adversarial (Codex) verification
 * reproduced four concrete gaps beyond the first pass's fix for
 * /attendance/sessions/:id/add's cross-group bypass:
 *
 * 1. /add still writes attendance into a CANCELLED session (no guard,
 *    unlike its sibling /records).
 * 2. A visitor can be added to a cancelled session through the same route.
 * 3. /attendance/checkin/confirm (the QR front-door flow) trusts a raw
 *    client-supplied session_id with no validation at all - it can be
 *    made to write into a cancelled session, a non-Friday cell-group
 *    session, or a future-dated session, regardless of who is checking
 *    someone in.
 * 4. The same route can record a member with no cell-group into a
 *    session that has not happened yet.
 *
 * Fixed with one centralized invariant, assertSessionMutable() in
 * services/attendance.js, that every attendance-mutating entry point
 * calls before writing anything: a session must exist, must not be
 * cancelled, and must not be dated in the future. recordAttendance() and
 * recordAttendanceForPeople() both now refuse early, refusing works
 * identically whether the person being added is a member or a visitor
 * (the check is on the session, not the person). confirmCheckin() goes
 * further, since it is the one entry point whose entire purpose is "the
 * live front door, right now": it requires the client-supplied session_id
 * to literally match checkinSession()'s own resolution before writing
 * anything at all - which structurally rules out cancelled, non-Friday,
 * and future sessions in one check, not three separate ones.
 *
 * Second pass (independent/Codex verification): confirmCheckin()'s own
 * "match checkinSession()'s resolution" check was only as good as
 * checkinSession() itself - which still fell back to the most recent
 * non-cancelled Friday from an OLDER week whenever the current week's own
 * Friday was cancelled. /checkin/confirm's stricter isOperationalFridaySession()
 * check on the session it's given caught that; /checkin/record (and the
 * shared lookup/review screens, and the kiosk, which all resolve "today's
 * session" via checkinSession() itself rather than validating a client-
 * supplied id) did not, and would silently record arrivals into that older
 * week. Fixed by bounding checkinSession() itself to the exact
 * calendar-current Friday, with no fallback - see
 * getCurrentOperationalFridayService() in services/friday-service.js.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-attendance-invariants-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const { createUser } = await import('../services/users.js');
const { createVisitor } = await import('../services/visitors.js');
const {
  createSession, setSessionStatus, recordAttendance, recordAttendanceForPeople, assertSessionMutable
} = await import('../services/attendance.js');
const { confirmCheckin } = await import('../services/qr-checkin.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

// A single anchor so every fixture session's date is a clearly-separated,
// mutually-distinct offset from it - avoids the attendance_sessions unique
// constraint on (service_date, service_type, cell_group_id) coincidentally
// colliding depending on what day of the week this test happens to run on.
const fridayAnchor = lastFridayOnOrBefore(today());

// --- Unit-level: the shared invariant itself. ---
{
  assert.equal(assertSessionMutable(null).ok, false);
  assert.equal(assertSessionMutable(null).reason, 'session_not_found');
  assert.equal(assertSessionMutable({ status: 'cancelled', service_date: today() }).ok, false);
  assert.equal(assertSessionMutable({ status: 'cancelled', service_date: today() }).reason, 'session_cancelled');
  assert.equal(assertSessionMutable({ status: 'scheduled', service_date: addDays(today(), 7) }).ok, false);
  assert.equal(assertSessionMutable({ status: 'scheduled', service_date: addDays(today(), 7) }).reason, 'session_in_future');
  assert.equal(assertSessionMutable({ status: 'scheduled', service_date: today() }).ok, true);
  assert.equal(assertSessionMutable({ status: 'held', service_date: addDays(today(), -7) }).ok, true);
  console.log('PASS: assertSessionMutable() correctly gates on existence, cancellation, and future dates');
}

const memberA = createMember({ first_name: 'Member', last_name: 'A' }, { status: 'active' });
const visitorA = createVisitor({ first_name: 'Visitor', last_name: 'A' });

// --- 1/2. recordAttendance() and recordAttendanceForPeople() refuse a cancelled session,
//     for both a member and a visitor. ---
{
  const cancelled = createSession({ service_date: addDays(fridayAnchor, -100), service_type: 'friday_service', title: 'Cancelled' });
  setSessionStatus(cancelled.id, 'cancelled');

  const r1 = recordAttendance(cancelled.id, [{ memberId: memberA.id, status: 'present' }], {});
  assert.equal(r1.ok, false);
  assert.equal(r1.reason, 'session_cancelled');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(cancelled.id).n, 0,
    'CODEX FINDING CONFIRMED FIXED: recordAttendance() must not write into a cancelled session');

  const r2 = recordAttendanceForPeople(cancelled.id, [{ type: 'member', id: memberA.id }], {});
  assert.equal(r2.ok, false);
  assert.equal(r2.reason, 'session_cancelled');

  const r3 = recordAttendanceForPeople(cancelled.id, [{ type: 'visitor', id: visitorA.id }], {});
  assert.equal(r3.ok, false);
  assert.equal(r3.reason, 'session_cancelled');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE session_id=?').get(cancelled.id).n, 0,
    'CODEX FINDING CONFIRMED FIXED: a visitor must not be recorded into a cancelled session either');
  console.log('PASS: recordAttendance() and recordAttendanceForPeople() both refuse a cancelled session, for members and visitors alike');
}

// --- Future-dated session refused too. ---
{
  const future = createSession({ service_date: addDays(fridayAnchor, 100), service_type: 'friday_service', title: 'Future' });
  const r = recordAttendanceForPeople(future.id, [{ type: 'member', id: memberA.id }], {});
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'session_in_future');
  console.log('PASS: recordAttendanceForPeople() refuses a session dated in the future');
}

// --- HTTP-level: /attendance/sessions/:id/add against a cancelled session. ---
function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;
const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

async function login(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preCookie;
}
async function csrfFor(urlPath, cookie) {
  const page = await fetch(`${base}${urlPath}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

await createUser({ email: 'admin.invariants@fixture.invalid', password: 'AdminPassw0rd!2026', displayName: 'Admin Invariants', roleKeys: ['church_admin'], mustChangePassword: false });
const adminCookie = await login('admin.invariants@fixture.invalid', 'AdminPassw0rd!2026');

{
  const cancelled = createSession({ service_date: addDays(fridayAnchor, -101), service_type: 'friday_service', title: 'HTTP Cancelled' });
  setSessionStatus(cancelled.id, 'cancelled');
  const memberB = createMember({ first_name: 'Member', last_name: 'B' }, { status: 'active' });

  const csrf = await csrfFor(`/attendance/sessions/${cancelled.id}`, adminCookie);
  const res = await fetch(`${base}/attendance/sessions/${cancelled.id}/add`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ person: `member:${memberB.id}`, _csrf: csrf })
  });
  assert.equal(res.status, 302, 'the request itself should redirect cleanly with an error, not crash');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(cancelled.id).n, 0,
    'CODEX FINDING CONFIRMED FIXED (HTTP level): POST /attendance/sessions/:id/add must not write into a cancelled session');
  console.log('PASS: POST /attendance/sessions/:id/add refuses a cancelled session over real HTTP');
}

// --- 3/4. /attendance/checkin/confirm with a forged session_id: cancelled,
//     non-Friday cell-group, and future sessions must all be refused,
//     structurally, by requiring the session to be checkinSession()'s own
//     current resolution. ---
{
  const group = createGroup({ name: 'Invariants Group' }, {});
  const ungroupedMember = createMember({ first_name: 'Ungrouped', last_name: 'Member' }, { status: 'active' });

  const cancelledFriday = createSession({ service_date: addDays(fridayAnchor, -102), service_type: 'friday_service', title: 'Cancelled Friday' });
  setSessionStatus(cancelledFriday.id, 'cancelled');
  const cellGroupSession = createSession({ service_date: today(), service_type: 'cell_group', cell_group_id: group.id, title: 'Cell Group Meeting' });
  const futureSession = createSession({ service_date: addDays(fridayAnchor, 101), service_type: 'friday_service', title: 'Future Friday' });

  async function attemptConfirm(memberId, sessionId) {
    const csrf = await csrfFor('/attendance/checkin?kiosk=0', adminCookie);
    const res = await fetch(`${base}/attendance/checkin/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
      body: new URLSearchParams({ member_id: String(memberId), session_id: String(sessionId), _csrf: csrf })
    });
    return res;
  }

  const r1 = await attemptConfirm(ungroupedMember.id, cancelledFriday.id);
  assert.equal(r1.status, 409, 'CODEX FINDING CONFIRMED FIXED: confirming against a cancelled Friday session must be refused');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(cancelledFriday.id).n, 0);

  const r2 = await attemptConfirm(ungroupedMember.id, cellGroupSession.id);
  assert.equal(r2.status, 409, 'CODEX FINDING CONFIRMED FIXED: confirming against a non-Friday cell-group session must be refused');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(cellGroupSession.id).n, 0);

  const r3 = await attemptConfirm(ungroupedMember.id, futureSession.id);
  assert.equal(r3.status, 409, 'CODEX FINDING CONFIRMED FIXED: confirming against a future-dated session must be refused');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(futureSession.id).n, 0);
  console.log('PASS: /attendance/checkin/confirm refuses cancelled, non-Friday, and future sessions, regardless of member scope');
}

// --- Regression: a genuine current Friday Service confirm still works normally. ---
{
  // The spawned server's own startup ensureFridaySessions() call already
  // auto-generates this week's real Friday session (and weeks ahead) the
  // moment it starts, sharing this same fixture database - reuse it rather
  // than creating a duplicate, which would collide on the same unique
  // (service_date, service_type, cell_group_id) constraint.
  const currentFriday = db.prepare(
    "SELECT * FROM attendance_sessions WHERE service_type = 'friday_service' AND service_date = ? AND status != 'cancelled'"
  ).get(fridayAnchor);
  assert.ok(currentFriday, 'the server\'s own startup Friday-generation must have created this week\'s session');
  const member = createMember({ first_name: 'Genuine', last_name: 'Current' }, { status: 'active' });
  const csrf = await csrfFor('/attendance/checkin?kiosk=0', adminCookie);
  const res = await fetch(`${base}/attendance/checkin/confirm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ member_id: String(member.id), session_id: String(currentFriday.id), _csrf: csrf })
  });
  assert.equal(res.status, 200, 'a genuine current Friday Service confirm must still succeed normally');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=? AND member_id=?').get(currentFriday.id, member.id).n, 1);
  console.log('PASS: a genuine current-session confirm is unaffected by the new checks');

  // --- R04, Codex/independent verification: unlike /checkin/confirm above,
  //     the front door's quick-record path (checkinSession(), shared by
  //     /checkin/lookup, /checkin/review and /checkin/record, and by the
  //     kiosk) used an UNBOUNDED "most recent non-cancelled Friday" lookup.
  //     Cancelling this week's own Friday while an older, non-cancelled
  //     Friday still existed let /checkin/record silently write today's
  //     arrivals into that older session instead of refusing - exactly the
  //     class of defect isOperationalFridaySession() already prevents for
  //     QR confirmation. Fixed by bounding checkinSession() itself
  //     (getCurrentOperationalFridayService() in services/friday-service.js)
  //     rather than patching this one route. ---
  setSessionStatus(currentFriday.id, 'cancelled');
  const olderFriday = createSession({ service_date: addDays(fridayAnchor, -7), service_type: 'friday_service', title: 'Older Friday' });
  const walkIn = createMember({ first_name: 'WalkIn', last_name: 'Person' }, { status: 'active' });

  const recordCsrf = await csrfFor('/attendance/checkin?kiosk=0', adminCookie);
  const recordRes = await fetch(`${base}/attendance/checkin/record`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ person: `member:${walkIn.id}`, _csrf: recordCsrf })
  });
  assert.equal(recordRes.status, 302, 'the request itself should redirect cleanly with an error, not crash');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(olderFriday.id).n, 0,
    'CODEX FINDING CONFIRMED FIXED: /attendance/checkin/record must not fall back to an older, non-cancelled Friday when this week\'s own Friday is cancelled');
  console.log('PASS: cancelling the current Friday makes /attendance/checkin/record refuse rather than fall back to an older week');
}

// --- Pre-go-live batch, item A: callers that ignored recordAttendance().ok. ---
//
// 1. POST /attendance/sessions/:id/records checked only for a CANCELLED
//    session itself, then reported success regardless of what
//    recordAttendance() returned - so a session the shared service refuses
//    (future-dated, or vanished) still flashed "Attendance saved" and wrote an
//    audit row claiming attendance was recorded.
{
  const future = createSession({ service_date: addDays(fridayAnchor, 103), service_type: 'friday_service', title: 'Future records target' });
  const member = createMember({ first_name: 'Records', last_name: 'Refused' }, { status: 'active' });
  const auditBefore = db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.recorded' AND result = 'success'").get().n;

  const csrf = await csrfFor(`/attendance/sessions/${future.id}`, adminCookie);
  const res = await fetch(`${base}/attendance/sessions/${future.id}/records`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ [`status_${member.id}`]: 'present', _csrf: csrf })
  });
  assert.equal(res.status, 302, 'a refused form submission redirects back to the session with an error');
  const page = await fetch(`${base}${res.headers.get('location')}`, { headers: { Cookie: adminCookie } });
  const html = await page.text();
  assert.ok(html.includes('This service has not happened yet'), 'ITEM A: the refusal must be shown to the user');
  assert.ok(!html.includes('Attendance saved'), 'ITEM A: a refused write must never be reported as saved');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE session_id=?').get(future.id).n, 0);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.recorded' AND result = 'success'").get().n, auditBefore,
    'ITEM A: no success audit row may be written for a refused write');
  assert.ok(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'attendance.recorded' AND result = 'failure'").get().n >= 1,
    'ITEM A: the refusal is audited as a failure');

  const jsonCsrf = await csrfFor(`/attendance/sessions/${future.id}`, adminCookie);
  const jsonRes = await fetch(`${base}/attendance/sessions/${future.id}/records`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie, Accept: 'application/json' },
    body: new URLSearchParams({ [`status_${member.id}`]: 'present', _csrf: jsonCsrf })
  });
  assert.equal(jsonRes.status, 409, 'ITEM A: the JSON form of a refused write must not answer ok');
  const jsonBody = await jsonRes.json();
  assert.equal(jsonBody.ok, false);
  assert.equal(jsonBody.reason, 'session_in_future');
  console.log('PASS (Item A): POST /attendance/sessions/:id/records no longer reports success when the shared service refuses the write');
}

// 2. commitAttendance() (spreadsheet import) added recordAttendance()'s
//    `saved` and then wrote its import_batches row as though the whole
//    register had gone in, even when a session was refused.
{
  const { commitAttendance, AttendanceImportRefusedError } = await import('../services/imports.js');
  const importee = createMember({ first_name: 'Import', last_name: 'Person' }, { status: 'active' });
  const pastDate = addDays(fridayAnchor, -140);
  const futureDate = addDays(today(), 60);
  const batchesBefore = db.prepare('SELECT COUNT(*) n FROM import_batches').get().n;
  const sessionsBefore = db.prepare('SELECT COUNT(*) n FROM attendance_sessions').get().n;

  const badPreview = {
    sessions: [
      { date: pastDate, sessionId: null, sessionExists: false, isFriday: false },
      { date: futureDate, sessionId: null, sessionExists: false, isFriday: false }
    ],
    people: [{ memberId: importee.id, entries: [{ date: pastDate, status: 'present' }, { date: futureDate, status: 'present' }] }]
  };
  let thrown = null;
  try { commitAttendance(badPreview, { userId: null, filename: 'refused.xlsx', createSessions: true }); } catch (err) { thrown = err; }
  assert.ok(thrown instanceof AttendanceImportRefusedError, 'ITEM A: a write the shared service refused must fail the import, not be counted');
  assert.deepEqual(thrown.refused.map((r) => r.reason), ['session_in_future']);
  assert.equal(thrown.refused[0].date, futureDate);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM import_batches').get().n, batchesBefore,
    'ITEM A: no import_batches row may claim success for a refused import');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_sessions').get().n, sessionsBefore,
    'ITEM A: the whole import rolls back - no session created for the refused (or the accepted) date');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM attendance_records WHERE member_id=?').get(importee.id).n, 0,
    'ITEM A: nothing from a refused import may be committed');

  // Control: a register the shared service accepts imports exactly as before.
  const goodPreview = {
    sessions: [{ date: pastDate, sessionId: null, sessionExists: false, isFriday: false }],
    people: [{ memberId: importee.id, entries: [{ date: pastDate, status: 'present' }] }]
  };
  const counts = commitAttendance(goodPreview, { userId: null, filename: 'ok.xlsx', createSessions: true });
  assert.equal(counts.records, 1);
  assert.equal(counts.services, 1);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM import_batches').get().n, batchesBefore + 1);
  console.log('PASS (Item A): commitAttendance() rolls back and reports failure when the shared service refuses a write, and still imports a valid register');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
