import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Admin -> About our church: "Church information" and "Church leadership" are separate, with an
 * explicit Save church information; the leadership list is compact (one Edit button per person) and
 * each person is edited on their own page. Data, permissions and the public page are unchanged.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-about-editor-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const profile = await import('../services/church-profile.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ab${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'about_admin', email: 'about.admin@fixture.invalid', password: PASSWORD, displayName: 'About Admin', roleKeys: ['church_admin'], mustChangePassword: false });
await createUser({ username: 'about_member', email: 'about.member@fixture.invalid', password: PASSWORD, displayName: 'About Member', roleKeys: ['member'], mustChangePassword: false });
setSetting('church.public_about', true);
profile.ensureSections();
const first = profile.createLeader({ name: 'Pastor Fixture', role_title: 'Senior Pastor', group_label: profile.LEADERSHIP_GROUPS[0], description: 'Leads the fixture church.', email: 'pastor@fixture.invalid', phone: null, sort_order: 1 });
const second = profile.createLeader({ name: 'Deacon Fixture', role_title: 'Chair', group_label: profile.LEADERSHIP_GROUPS[1], description: null, email: null, phone: null, sort_order: 1 });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function session(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const admin = await session('about.admin@fixture.invalid');
  const member = await session('about.member@fixture.invalid');
  const get = (url, cookie = admin) => fetch(`${base}${url}`, { headers: { Cookie: cookie }, redirect: 'manual' });
  const html = async (url) => { const r = await get(url); assert.equal(r.status, 200, url); return r.text(); };
  const csrfOf = async (url) => (await html(url)).match(/name="_csrf" value="([^"]+)"/)[1];
  const post = async (url, fields, csrfFrom) => fetch(`${base}${url}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: admin },
    body: new URLSearchParams({ _csrf: await csrfOf(csrfFrom), ...fields })
  });

  // ---- the editor page -----------------------------------------------------
  let page = await html('/admin/about');
  assert.match(page, /<h2>Church information<\/h2>/);
  assert.match(page, /<h2>Church leadership<\/h2>/, 'two clearly separate sections');
  assert.match(page, />Save church information<\/button>/, 'an explicit, named save');
  assert.doesNotMatch(page, />Save<\/button>/, 'no ambiguous plain "Save"');
  assert.match(page, /the public About page is switched on/, 'says where the information appears');
  assert.match(page, /href="\/about"/, 'links to the page it edits');
  assert.match(page, /System settings &rarr; About Our Church/, 'and to where the contact details live');
  assert.match(page, /href="\/admin\/about\/leaders\/new"/, 'a clear Add a leader');
  assert.equal((page.match(/class="btn btn--secondary btn--small" href="\/admin\/about\/leaders\/\d+\/edit"/g) || []).length, 2, 'one Edit button per leader');
  assert.equal((page.match(/action="\/admin\/about\/leaders/g) || []).length, 0, 'no permanently expanded per-leader edit forms');
  assert.doesNotMatch(page, /name="description"/, 'no leader fields on the list page');
  assert.match(page, /Pastor Fixture/);
  assert.match(page, /Senior Pastor/);
  assert.match(page, /Board of Elders/);
  console.log('PASS (editor page) Church information and Church leadership are separate; explicit Save church information; compact leader list with Edit / Add; no expanded per-leader forms');

  // Church information saves on its own.
  const key = profile.listSections()[0].key;
  let res = await post('/admin/about', { [`title_${key}`]: 'Our story', [`body_${key}`]: 'Written in the test.', [`visible_${key}`]: 'on' }, '/admin/about');
  assert.equal(res.status, 302);
  assert.equal(profile.getSection(key).title, 'Our story');
  assert.equal(profile.listLeaders().length, 2, 'saving church information does not touch the leadership list');
  assert.ok(db.prepare("SELECT 1 FROM audit_logs WHERE action = 'church.profile_updated'").get(), 'audited');

  // ---- one leader at a time ------------------------------------------------
  page = await html(`/admin/about/leaders/${first.id}/edit`);
  assert.equal((page.match(/name="name"/g) || []).length, 1, 'a single editor');
  assert.match(page, /value="Pastor Fixture"/);
  assert.match(page, />Save changes<\/button>/);
  assert.match(page, /The photo is saved separately from the details above/);
  assert.match(page, /action="\/admin\/about\/leaders\/\d+\/photo"/, 'photo has its own form');
  assert.match(page, />Remove from leadership<\/button>/);
  res = await post(`/admin/about/leaders/${first.id}`, { name: 'Pastor Renamed', role_title: 'Lead Pastor', group_label: profile.LEADERSHIP_GROUPS[0], description: 'Updated.', email: 'pastor@fixture.invalid', phone: '', sort_order: '1', is_visible: 'on' }, `/admin/about/leaders/${first.id}/edit`);
  assert.equal(res.headers.get('location'), '/admin/about', 'saving returns to the list');
  assert.equal(profile.getLeader(first.id).name, 'Pastor Renamed');
  assert.ok(db.prepare("SELECT 1 FROM audit_logs WHERE action = 'church.leader_updated'").get());
  res = await post(`/admin/about/leaders/${first.id}`, { name: '', group_label: profile.LEADERSHIP_GROUPS[0] }, `/admin/about/leaders/${first.id}/edit`);
  assert.equal(res.headers.get('location'), `/admin/about/leaders/${first.id}/edit`, 'a validation error returns to that editor');
  assert.equal(profile.getLeader(first.id).name, 'Pastor Renamed', 'and changed nothing');
  assert.equal(profile.getLeader(second.id).name, 'Deacon Fixture', 'no other leader was touched');

  // Add.
  page = await html('/admin/about/leaders/new');
  assert.match(page, />Add to leadership<\/button>/);
  assert.doesNotMatch(page, /Remove from leadership/, 'nothing to remove on the add form');
  res = await post('/admin/about/leaders', { name: 'New Leader', role_title: 'Elder', group_label: profile.LEADERSHIP_GROUPS[0], description: '', email: '', phone: '', sort_order: '2', is_visible: 'on' }, '/admin/about/leaders/new');
  assert.equal(res.headers.get('location'), '/admin/about');
  assert.equal(profile.listLeaders().length, 3);
  res = await post('/admin/about/leaders', { name: '', group_label: profile.LEADERSHIP_GROUPS[0] }, '/admin/about/leaders/new');
  assert.equal(res.headers.get('location'), '/admin/about/leaders/new');
  assert.equal(profile.listLeaders().length, 3);

  // Remove.
  const added = profile.listLeaders().find((l) => l.name === 'New Leader');
  res = await post(`/admin/about/leaders/${added.id}/delete`, {}, `/admin/about/leaders/${added.id}/edit`);
  assert.equal(profile.listLeaders().length, 2);
  assert.ok(db.prepare("SELECT 1 FROM audit_logs WHERE action = 'church.leader_removed'").get());

  // Photo: upload (a real 1x1 PNG) stays on the editor and is saved separately.
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const form = new FormData();
  form.append('_csrf', await csrfOf(`/admin/about/leaders/${first.id}/edit`));
  form.append('photo', new Blob([png], { type: 'image/png' }), 'leader.png');
  const upload = await fetch(`${base}/admin/about/leaders/${first.id}/photo`, { method: 'POST', redirect: 'manual', headers: { Cookie: admin }, body: form });
  assert.equal(upload.headers.get('location'), `/admin/about/leaders/${first.id}/edit`, 'the photo upload returns to the editor');
  assert.equal(upload.status, 302);
  console.log('PASS (leadership) one person per page; save returns to the list; validation errors return to the editor; add and remove; audited; the photo is its own step');

  // ---- access unchanged ----------------------------------------------------
  for (const url of ['/admin/about', '/admin/about/leaders/new', `/admin/about/leaders/${first.id}/edit`]) {
    assert.equal((await get(url, member)).status, 403, `a plain member cannot open ${url}`);
    const anonymous = await fetch(`${base}${url}`, { redirect: 'manual' });
    assert.equal(anonymous.status, 302, `${url} needs a sign-in`);
    assert.match(anonymous.headers.get('location'), /^\/login/);
  }
  assert.equal((await get('/admin/about/leaders/999999/edit')).status, 404, 'an unknown leader is a 404, not a crash');
  const publicAbout = await (await fetch(`${base}/about`)).text();
  assert.match(publicAbout, /Pastor Renamed/, 'the public About page still shows the leadership');
  console.log('PASS (access) admin.settings only; sign-in required; unknown leader 404; the public page still shows the leaders');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
