import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What the portal search reaches, for each role, over HTTP - and what it must not.
 *   Member:  ministries, activities, announcements they may read, documents their audience may open, their OWN cell group, and the portal's pages they can open.
 *            Never another member, a First Timer, a phone number or an email, a draft, a leaders-only announcement or document, a staff document, an administration page.
 *   Leader:  the same plus the people and documents their own scope allows.   Church Admin / Super Admin: everything.   Kiosk: not the search at all.
 * A result a person may not open leaves nothing behind: no title, no snippet, no count. And the direct addresses stay protected independently of any search result.
 * The search box and its empty states say what is actually searchable for that person, at every width.
 */

const f = await buildPortalFixture('cciq-search-role-');
const { db, ids, users, mods } = f;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const category = (name, audience) => mods.documents.createCategory({ name, audience, description: null }).id;
const catMembers = category('Handbooks', 'members'); const catLeaders = category('Leader resources', 'leaders'); const catStaff = category('Church finance', 'staff');
const doc = (title, categoryId) => mods.documents.createDocument({ title, category_id: categoryId, description: `${title} description` }, { userId: users.churchAdmin.id, file: { originalname: 'scan.png', buffer: png, size: png.length } });
const dMembers = doc('Welcome handbook', catMembers); const dLeaders = doc('Leaders guidebook', catLeaders); const dStaff = doc('Ledger secrets', catStaff);
const draftActivity = ids.draftActivity; // a Group Beta draft
const leadersOnly = ids.leadersOnly;
db.prepare("UPDATE members SET phone = '+974 5550 0011', email = 'bella@fixture.invalid' WHERE id = ?").run(ids.member.b1);

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const c = { member: await signIn(portal.base, users.memberA.email, f.PASSWORD), leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD), church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD),
    super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD), kiosk: await signIn(portal.base, users.kiosk.email, f.PASSWORD) };
  const q = async (who, term) => {
    const r = await c[who].get(`/search?q=${encodeURIComponent(term)}`); const body = await r.text();
    const main = (/<main[\s\S]*?<\/main>/.exec(body) || [body])[0];
    const groups = [...main.matchAll(/<h2>([^<]+)<\/h2>\s*<span class="list__meta">(\d+)<\/span>/g)].map((m) => `${m[1]}:${m[2]}`);
    const titles = [...main.matchAll(/class="list__name" href="([^"]+)">([^<]+)</g)].map((m) => ({ href: m[1], title: m[2] }));
    // everything on the page except the box that echoes what was typed
    const visible = main.replace(/<input[^>]*>/g, '').replace(/<[^>]+>/g, ' ').replace(/&ldquo;[^&]*&rdquo;/g, ' ').replace(/\s+/g, ' ');
    return { status: r.status, body, main, groups, titles, visible, location: r.headers.get('location') };
  };
  const has = (r, title) => r.titles.some((t) => t.title === title);

  // ---- Member: what is searchable ------------------------------------------------------------------------------------------------------------------------------------------
  assert.ok((await q('member', 'Fixture Ushers')).titles.some((t) => t.href === `/ministries/${ids.ministry}`), 'a ministry');
  assert.ok(has(await q('member', 'Fixture outing'), 'Fixture outing'), 'a church activity');
  assert.ok(has(await q('member', 'Fixture notice'), 'Fixture notice'), 'an announcement for everyone');
  assert.ok(has(await q('member', 'Welcome handbook'), 'Welcome handbook'), 'a document their audience may open');
  assert.ok(has(await q('member', 'Group Alpha'), 'Group Alpha'), 'their own cell group');
  { const pages = await q('member', 'profile'); assert.ok(pages.titles.some((t) => t.href === '/my/profile'), 'a page of the portal they can open'); }
  { const pages = await q('member', 'ministries'); assert.ok(pages.titles.some((t) => t.href === '/ministries' && /Section|In /.test(pages.main)), 'the Ministries section'); }
  console.log('PASS (member finds) ministries, activities, announcements, documents, their own cell group and pages');

  // ---- Member: what must not leak -------------------------------------------------------------------------------------------------------------------------------------------
  const none = [['Bella', 'another member by name'], ['MemberB', 'another member by surname'], ['CCIQ-', 'a member ID'], ['5550 0011', 'a phone number'], ['+974 5550 0011', 'a phone number with the country code'], ['55500011', 'a phone number without spaces'],
    ['bella@fixture.invalid', 'an email address'], ['Anna', 'their own name (members are not searchable by a Member)'], ['Vera', 'a First Timer'], ['Beta', 'another cell group'], ['Group Beta', 'another cell group'], ['Beta draft', 'a draft activity of another group'],
    ['Leaders only notice', 'a leaders-only announcement'], ['Leaders guidebook', 'a leaders-only document'], ['Ledger secrets', 'a staff document'], ['Friday Service', 'attendance services'], ['Administration', 'an administration page'], ['Audit log', 'an administration page'],
    ['Add group', 'a page they cannot open'], ['Roles and permissions', 'an administration page']];
  for (const [term, what] of none) {
    const r = await q('member', term); assert.equal(r.status, 200, `${term} -> ${r.status}`);
    assert.deepEqual(r.titles, [], `a Member searching "${term}" (${what}) finds nothing: ${JSON.stringify(r.titles)}`);
    assert.deepEqual(r.groups, [], `and no result group or count exists for it`);
    for (const secret of ['Bella', 'MemberB', 'bella@fixture', '5550 0011', 'Leaders only', 'Leaders guidebook', 'Ledger', 'Beta draft']) {
      if (term.includes(secret.split(' ')[0]) ) continue; // the page may echo the word the person typed
      assert.ok(!r.visible.includes(secret), `the page for "${term}" does not mention "${secret}"`);
    }
  }
  { const r = await q('member', 'Bella'); assert.match(r.visible, /Nothing found/); assert.match(r.visible, /Search covers ministries, activities, announcements, documents, your cell group and pages of the portal/); assert.ok(!/members|First Timers/.test(/Search covers[^.]*\./.exec(r.visible)[0]), 'and says plainly what it covers'); }
  { const r = await q('member', ''); assert.match(r.visible, /does not search for other people/); }
  console.log(`PASS (member never) ${none.length} searches for people, contact details, other groups, drafts, leaders-only and staff content, and administration pages find nothing: no result, no group heading, no count, no mention`);

  // ---- direct addresses are protected on their own ---------------------------------------------------------------------------------------------------------------------------------
  for (const url of [`/members/${ids.member.b1}`, `/documents/${dLeaders.id}`, `/documents/${dStaff.id}`, `/announcements/${leadersOnly}`, `/activities/${draftActivity}`, `/cell-groups/${ids.groupB}`, '/admin/audit', '/visitors', '/search.json']) {
    const r = await c.member.get(url); await r.text(); assert.ok([403, 404, 302].includes(r.status), `Member ${url} -> ${r.status}`);
    assert.notEqual(r.status, 200, `Member ${url}`);
  }
  { const r = await c.member.get(`/documents/${dMembers.id}`); await r.text(); assert.equal(r.status, 200, 'the document they may open opens'); }
  console.log('PASS (direct addresses) a document, member, announcement, activity, group or administration page a Member may not open is refused by address, whatever search shows');

  // ---- Leader ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const anna = await q('leader', 'Anna'); assert.ok(anna.titles.some((t) => t.href === `/members/${ids.member.a2}`), 'a leader finds the people in their own group');
    const bella = await q('leader', 'Bella'); assert.deepEqual(bella.titles.filter((t) => /members\//.test(t.href)), [], 'but not people outside it');
    assert.ok(has(await q('leader', 'Leaders guidebook'), 'Leaders guidebook'), 'a leaders document'); assert.ok(has(await q('leader', 'Leaders only notice'), 'Leaders only notice'));
    assert.deepEqual((await q('leader', 'Ledger secrets')).titles, [], 'not a staff document'); assert.deepEqual((await q('leader', 'Audit log')).titles, [], 'not an administration page'); }
  console.log('PASS (leader) a Cell Group leader finds their own group\'s people, leaders\' documents and notices, and nothing of staff or administration');

  // ---- administrators -------------------------------------------------------------------------------------------------------------------------------------------------------------------
  for (const who of ['church', 'super']) {
    assert.ok((await q(who, 'Bella')).titles.some((t) => t.href === `/members/${ids.member.b1}`), `${who}: any member`);
    assert.ok((await q(who, '5550 0011')).titles.some((t) => t.href === `/members/${ids.member.b1}`), `${who}: by phone, however it is spaced`);
    assert.ok((await q(who, '55500011')).titles.some((t) => t.href === `/members/${ids.member.b1}`), `${who}: and by the digits alone`);
    assert.ok(has(await q(who, 'Ledger secrets'), 'Ledger secrets'), `${who}: staff documents`);
    assert.ok((await q(who, 'Audit')).titles.some((t) => t.href === '/admin/audit') === (who === 'super'), `${who}: the Audit log page only for Super Admin`);
    const text = (await q(who, 'zzzz')).visible; assert.match(text, /Search covers members, First Timers/, `${who}: the scope text names people`);
  }
  console.log('PASS (administrators) Church Admin and Super Admin find people (by name, and by phone however written), staff documents and their pages');

  // ---- Kiosk ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  { const r = await c.kiosk.get('/search?q=Bella'); await r.text(); assert.ok(r.status === 302 && r.headers.get('location') === '/kiosk' || r.status === 403, `the Kiosk has no portal search (${r.status})`); }

  // ---- the box says what it searches, at every width ------------------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  for (const [who, expectPlaceholder, forbid] of [['member', /Search ministries, activities/, /members|First Timers/], ['church', /Search members, First Timers/, null]]) {
    const cookies = c[who].cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
    for (const width of [320, 375, 430, 768, 1024, 1280, 1440]) {
      const context = await browser.newContext({ viewport: { width, height: 800 } }); await context.addCookies(cookies);
      const page = await context.newPage(); await page.goto(`${portal.base}/search?q=Fixture`, { waitUntil: 'load' });
      const m = await page.evaluate(() => { const i = document.getElementById('topbar-search'); const p = document.getElementById('q'); return { top: i && i.getAttribute('placeholder'), page: p && p.getAttribute('placeholder'), overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth }; });
      if (!expectPlaceholder.test(m.top || '')) problems.push(`${who} ${width}px: top-bar placeholder "${m.top}"`);
      if (forbid && forbid.test(`${m.top} ${m.page}`)) problems.push(`${who} ${width}px: placeholder mentions people ("${m.top}" / "${m.page}")`);
      if (m.overflow > 0) problems.push(`${who} ${width}px: sideways scroll ${m.overflow}px`);
      await context.close();
    }
  }
  assert.deepEqual(problems, [], problems.join('; '));
  console.log('PASS (box) the search box and page say what each role can search, at 320 to 1440 px, with no sideways scroll');
  console.log('PASS search-by-role');
} finally {
  await browser.close();
  await portal.stop();
}
