import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Campaign reports follow the campaign's OWN dates, never a calendar year the campaign does not have.
 *   - a whole-year Giving Board has every day of its year (365/366); one that runs 15 Mar to 15 Sep has exactly those 185 days, on the wall, in the progress figure and in what a member may take;
 *   - a Giving Board whose dates run past its year is clipped to that year (a board is one calendar year's wall); a future (draft) and a completed board each count their own days;
 *     no activity is 0 of N, never "N of 365";
 *   - a Faith Promise (or any non-Giving-Board) campaign is NOT a Giving Board year: it is absent from "All years" and from the launcher's Giving list, and a Giving Board
 *     statement for it is refused (no 2037 row, no 365 days);
 *   - payments dated after a campaign ends are still payments received and are counted in the whole-ledger figures; the ledger and the PDFs say the campaign's real period.
 */

const f = await buildPortalFixture('cciq-campaign-bounds-');
const { db, users, mods } = f;
const ecaq = mods.ecaq;
const pdfs = await import('../services/reports-pdf.js');
const ledgerSvc = await import('../services/campaign-ledger.js');
const pdfText = async (doc) => {
  const chunks = []; doc.on('data', (c) => chunks.push(c)); await new Promise((r) => doc.on('end', r));
  const raw = Buffer.concat(chunks).toString('latin1'); let text = '';
  for (const m of raw.matchAll(/stream\r?\n([\s\S]*?)\r?\nendstream/g)) {
    let c; try { c = zlib.inflateSync(Buffer.from(m[1], 'latin1')).toString('latin1'); } catch { continue; }
    for (const h of c.matchAll(/<([0-9a-fA-F]+)>/g)) text += Buffer.from(h[1], 'hex').toString('latin1');
    for (const l of c.matchAll(/\(((?:\\.|[^\\)])*)\)\s*Tj/g)) text += l[1];
    text += '\n';
  }
  return text;
};

const mk = (data) => ecaq.createCampaign({ type: 'giving_board', amount_per_date: 100, status: 'active', ...data });
const member = mods.members.createMember({ first_name: 'Bound', last_name: 'Tester' }, { status: 'active' });

// ---- the window ----------------------------------------------------------------------------------------------------------------------------------------------------------
const whole = mk({ name: 'Whole year board', year: 2031 });
const leap = mk({ name: 'Leap board', year: 2032 });
const partial = mk({ name: 'Partial board', year: 2033, start_date: '2033-03-15', end_date: '2033-09-15' });
const cross = mk({ name: 'Cross-year board', year: 2034, start_date: '2034-07-01', end_date: '2035-06-30' });
const early = mk({ name: 'Early start board', year: 2035, start_date: '2034-11-01', end_date: '2035-01-10' });
const odd = mk({ name: 'Contradictory dates board', year: 2036, start_date: '2036-12-31', end_date: '2036-01-01' });
const none = mk({ name: 'Draft future board', year: 2040, status: 'draft' });
const done = mk({ name: 'Completed board', year: 2020, status: 'closed', start_date: '2020-02-01', end_date: '2020-02-29' });

assert.equal(ecaq.campaignDayCount(whole), 365); assert.equal(ecaq.campaignDayCount(leap), 366);
assert.equal(ecaq.campaignDayCount(partial), 185, '15 Mar to 15 Sep is 185 days');
assert.equal(ecaq.campaignDayCount(cross), 184, 'the board is clipped to its own calendar year: 1 Jul to 31 Dec');
assert.equal(ecaq.campaignDayCount(early), 10, 'a start before the year is clipped to 1 Jan; 1 to 10 Jan');
assert.equal(ecaq.campaignDayCount(odd), 366, 'contradictory dates fall back to the whole year, never to nothing');
assert.equal(ecaq.campaignDayCount(done), 29, 'a completed Feb 2020 board has its 29 days');
assert.equal(ecaq.campaignDates(partial)[0], '2033-03-15'); assert.equal(ecaq.campaignDates(partial).at(-1), '2033-09-15');
assert.equal(ecaq.campaignWindow(whole).whole, true); assert.equal(ecaq.campaignWindow(partial).whole, false);

// ---- the wall, the progress figure and what may be taken -----------------------------------------------------------------------------------------------------------------
{
  const board = ecaq.buildBoard(partial, {});
  const days = board.months.flatMap((m) => m.stubs);
  assert.equal(days.length, 185, "only the campaign's days are on the wall");
  assert.deepEqual(board.months.map((m) => m.name), ['March', 'April', 'May', 'June', 'July', 'August', 'September'], 'months with no campaign day are not shown');
  assert.equal(ecaq.campaignProgress(partial).totalDates, 185);
  assert.equal(ecaq.campaignProgress(partial).claimed, 0, 'no activity is 0 of 185');
  assert.equal(ecaq.createClaim({ campaignId: partial.id, date: '2033-03-14', memberId: member.id, userId: users.churchAdmin.id }).ok, false, 'the day before the start cannot be taken');
  assert.equal(ecaq.createClaim({ campaignId: partial.id, date: '2033-09-16', memberId: member.id, userId: users.churchAdmin.id }).reason, 'date_not_in_campaign', 'the day after the end cannot be taken');
  assert.equal(ecaq.createClaim({ campaignId: partial.id, date: '2033-03-15', memberId: member.id, userId: users.churchAdmin.id }).ok, true, 'the first day can');
  assert.equal(ecaq.createClaim({ campaignId: partial.id, date: '2033-09-15', memberId: member.id, userId: users.churchAdmin.id }).ok, true, 'and so can the last');
  assert.equal(ecaq.campaignProgress(partial).claimed, 2);
  assert.equal(ecaq.campaignProgress(partial).totalDates, 185);
  assert.equal(ecaq.campaignProgress(none).totalDates, 366, 'a future board counts its own year (2040 is a leap year)');
  assert.equal(ecaq.campaignProgress(done).totalDates, 29);
}

// ---- only Giving Boards are boards ------------------------------------------------------------------------------------------------------------------------------------------
const fp = ecaq.createCampaign({ name: 'Faith Promise across two years', year: 2037, type: 'faith_promise', status: 'active', start_date: '2037-02-01', end_date: '2038-01-31' });
{
  const all = ecaq.allCampaignsProgress();
  assert.ok(all.years.length >= 8 && all.years.every((y) => y.campaign.type === 'giving_board'), 'every row of "All years" is a Giving Board');
  assert.ok(!all.years.some((y) => y.campaign.id === fp.id || y.year === 2037), 'the Faith Promise campaign is not a board year');
  assert.equal(all.totals.days, all.years.reduce((s, y) => s + y.totalDates, 0), "the total days are the sum of the boards' own days");
  assert.equal(all.years.find((y) => y.campaign.id === partial.id).totalDates, 185);
}

// ---- the PDFs ----------------------------------------------------------------------------------------------------------------------------------------------------------------
{
  const allYears = await pdfText(pdfs.allYearsGivingPdf());
  assert.ok(!allYears.includes('Faith Promise across two years') && !/\b2037\b/.test(allYears), 'the all-years PDF has no Faith Promise row and no fabricated year');
  assert.match(allYears, /2033/, 'the real boards are there');
  assert.match(allYears, /15 Mar 2033 to 15 Sep/, 'a part-year board says so in the Year column');
  const partialPdf = await pdfText(pdfs.givingPdf({ campaignId: partial.id }));
  assert.match(partialPdf, /15 Mar 2033 to 15 Sep/, "a partial board's statement names its real dates");
  const wholePdf = await pdfText(pdfs.givingPdf({ campaignId: whole.id }));
  assert.match(wholePdf, /Whole year board/); assert.doesNotMatch(wholePdf, / to 31 Dec 2031/, 'a whole-year board stays labelled by its year');
  const refused = await pdfText(pdfs.givingPdf({ campaignId: fp.id }));
  assert.match(refused, /No campaign/); assert.ok(!refused.includes('Faith Promise across two years'), 'a Giving Board statement is never produced for a Faith Promise campaign');
  const fpPdf = await pdfText(pdfs.faithPromisePdf({ campaignId: fp.id }));
  assert.match(fpPdf, /February 2037 to January 2038/, 'the Faith Promise report names its own cross-year period');
}

// ---- the ledger: later payments, the campaign's real period -----------------------------------------------------------------------------------------------------------------
{
  const c = mods.faith.submitCommitment(fp.id, { member_id: member.id, name: 'Bound Tester', amount: 100, frequency: 'monthly' }, { userId: users.churchAdmin.id });
  const cid = c.commitment.id;
  assert.equal(mods.faith.addPayment(cid, { amount: 40, paid_on: '2037-05-10', received_by: 'Treasurer' }, { userId: users.churchAdmin.id }).ok, true);
  assert.equal(mods.faith.addPayment(cid, { amount: 60, paid_on: '2038-03-02', received_by: 'Treasurer' }, { userId: users.churchAdmin.id }).ok, true, 'a late payment after the campaign ended is accepted');
  const report = ledgerSvc.campaignLedger(fp, {});
  assert.equal(report.headline.received, 100, 'a payment after the end date is still counted as received');
  const inWindow = ledgerSvc.campaignLedger(fp, { from: '2037-02-01', to: '2038-01-31' });
  assert.equal(inWindow.headline.receivedInPeriod, 40, 'the period filter still narrows to the dates chosen');
}

// ---- the screens and the launcher ---------------------------------------------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const launcher = await (await admin.get('/reports/print')).text();
  const giving = launcher.match(/<select[^>]*id="c-campaign"[\s\S]*?<\/select>/)?.[0] || '';
  assert.ok(giving.includes('Partial board'), 'the launcher lists Giving Boards');
  assert.ok(!giving.includes('Faith Promise across two years'), 'and not a Faith Promise campaign');
  const board = await (await admin.get('/projects/ecaq/board?year=2033')).text();
  assert.match(board, /min="2033-03-15" max="2033-09-15"/, "the claim form offers only the campaign's dates");
  assert.ok(!/id="board-month-1"/.test(board), 'no January on a March-to-September board');
  const ledger = await (await admin.get(`/admin/ecaq/campaigns/${fp.id}/ledger`)).text();
  assert.match(ledger, /Campaign: 1 Feb 2037 to 31 Jan 2038/, "the ledger says the campaign's real period");
  const pdfRes = await admin.get(`/reports/giving/pdf?campaign=${fp.id}`);
  assert.equal(pdfRes.status, 200, 'a stale Faith Promise id in the Giving link yields the "No campaign" statement, not an error');
} finally { await portal.stop(); }
console.log('PASS campaign-report-boundaries');
