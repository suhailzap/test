import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Parity of the two ways a member record is created since both were routed through one shared service (services/member-create.js):
 * Add member (POST /members) and Convert a First Timer (POST /visitors/:id/convert). The same form body must give the same member,
 * the same history, group, age-group and relationship rows, the same validation, the same duplicate warning, the same audit rows and the
 * same atomic behaviour. The ONLY differences are the intended ones, listed and pinned at the end: Convert always creates a Pending member,
 * defaults the join date to today, labels the history "Joined after visiting", links the First Timer, closes an open review, and (as
 * before the refactor) does not create a sign-in account the way Add member does.
 */

const f = await buildPortalFixture('cciq-member-parity-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const today = mods.dates.today();
let serial = 0;
const unique = () => { serial += 1; return `Parity${serial}x${Math.random().toString(36).slice(2, 6)}`; };

const visitorFor = (name) => mods.visitors.createVisitor({ first_name: name, last_name: 'Source', first_visit_date: mods.dates.addDays(today, -21), phone: `+974 5566 ${String(serial).padStart(4, '0')}` }, { userId: users.churchAdmin.id }).id;
const addMember = (body) => admin.post('/members', { status: 'pending', duplicate_override: '1', ...body }, { csrfFrom: '/members/new' });
const convert = (visitorId, body) => admin.post(`/visitors/${visitorId}/convert`, { duplicate_override: '1', ...body }, { csrfFrom: `/visitors/${visitorId}/convert` });
const memberIdFrom = (res) => Number(/\/members\/(\d+)/.exec(String(res.headers.get('location')))?.[1]);

const IGNORED = new Set(['spouse_member_id', 'id', 'member_code', 'created_at', 'updated_at', 'created_by', 'updated_by', 'qr_token', 'notes', 'status_changed_at']);
function memberShape(id) {
  const row = db.prepare('SELECT * FROM members WHERE id = ?').get(id);
  const shape = Object.fromEntries(Object.entries(row).filter(([k]) => !IGNORED.has(k)));
  const group = db.prepare('SELECT cell_group_id, role_in_group, left_at FROM cell_group_members WHERE member_id = ?').all(id);
  const history = db.prepare('SELECT previous_status, new_status FROM member_status_history WHERE member_id = ? ORDER BY id').all(id);
  const spouse = db.prepare('SELECT id, spouse_member_id FROM members WHERE id = ?').get(id).spouse_member_id;
  const created = db.prepare("SELECT detail FROM audit_logs WHERE action = 'member.created' AND entity_id = ?").get(String(id));
  const createdDetail = JSON.parse(created.detail); delete createdDetail.from_first_timer; delete createdDetail.member_code;
  const override = db.prepare("SELECT detail FROM audit_logs WHERE action = 'member.duplicate_warning_overridden' AND entity_id = ?").get(String(id));
  const overrideDetail = override ? JSON.parse(override.detail) : null;
  if (overrideDetail) delete overrideDetail.new_member;
  return { shape, group, history, spouse, createdDetail, overrideDetail, account: count('SELECT COUNT(*) n FROM users WHERE member_id = ?', id) };
}
const errorsOf = (html) => { const block = /data-error-summary[\s\S]*?<\/ul>/.exec(html)?.[0]; return block ? [...block.matchAll(/<a href="#[^"]*" data-field="[^"]*">(?:<strong>[^<]*<\/strong> )?([^<]*)<\/a>/g)].map((m) => m[1].trim()).sort() : []; };

const validBodies = {
  minimal: (n) => ({ first_name: n, last_name: 'Min', date_joined: '2024-05-05' }),
  trimming: (n) => ({ first_name: `  ${n}  `, last_name: '  Spaced  ', date_joined: '2024-05-05', phone: '  +974 5577 0001  ', email: '  Trim@Example.com ', address: '  1 Street  ' }),
  full: (n) => ({ first_name: n, middle_name: 'Mid', last_name: 'Full', preferred_name: 'Nick', date_of_birth: '1988-02-29', gender: 'female', phone: '+974 5577 0002', email: 'full@fixture.invalid', address: '2 Road', marital_status: 'married', anniversary_date: '2015-06-01', date_joined: '2020-01-10', home_country: 'Ireland', company: 'ACME', occupation: 'Nurse', emergency_contact_name: 'Em', emergency_contact_phone: '+974 5577 0003', emergency_contact_relation: 'Sister', is_baptized: '1', baptism_date: '2010-04-04', baptism_place: 'Doha', notes: 'a note', parents_attend_cciq: 'both' }),
  baptismOff: (n) => ({ first_name: n, last_name: 'Bapt', date_joined: '2024-05-05', is_baptized: '', baptism_date: '2010-04-04', baptism_place: 'Ignored' }),
  withGroup: (n) => ({ first_name: n, last_name: 'Grouped', date_joined: '2024-05-05', cell_group_id: String(ids.groupA) }),
  withAgeGroup: (n) => ({ first_name: n, last_name: 'Aged', date_joined: '2024-05-05', age_group: 'teen', date_of_birth: '2010-03-03', father_name: 'Dad Name', mother_name: 'Mum Name' }),
  withGuardian: (n) => ({ first_name: n, last_name: 'Guarded', date_joined: '2024-05-05', age_group: 'child', date_of_birth: '2017-03-03', father_name: 'Dad', mother_name: 'Mum', guardian_member_id: String(ids.member.a1), guardian_relation: 'Aunt' }),
  withSpouse: (n) => ({ first_name: n, last_name: 'Wed', date_joined: '2024-05-05', marital_status: 'married', spouse_member_id: String(mods.members.createMember({ first_name: `Spouse${n}`, last_name: 'Target' }, { status: 'active' }).id), spouse_mode: 'member' }),
  manualRelatives: (n) => ({ first_name: n, last_name: 'Kin', date_joined: '2024-05-05', father_name: 'Typed Father', mother_member_id: String(ids.member.a1), mother_mode: 'member', father_mode: 'manual' }),
  futureJoined: (n) => ({ first_name: n, last_name: 'Later', date_joined: '2030-01-01' })
};
const invalidBodies = {
  noFirst: () => ({ first_name: '', last_name: 'X', date_joined: '2024-05-05' }),
  noLast: (n) => ({ first_name: n, last_name: '', date_joined: '2024-05-05' }),
  longName: () => ({ first_name: 'x'.repeat(81), last_name: 'Y' }),
  badPhone: (n) => ({ first_name: n, last_name: 'P', phone: 'abc' }),
  badEmail: (n) => ({ first_name: n, last_name: 'E', email: 'nope' }),
  futureBirth: (n) => ({ first_name: n, last_name: 'F', date_of_birth: '2999-01-01' }),
  badDate: (n) => ({ first_name: n, last_name: 'D', date_joined: '31/12/2024' }),
  badEnum: (n) => ({ first_name: n, last_name: 'G', gender: 'robot', marital_status: 'zzz', age_group: 'giant' }),
  minorNoParents: (n) => ({ first_name: n, last_name: 'M', date_of_birth: addYears(-10), date_joined: '2024-05-05' }),
  hugeNotes: (n) => ({ first_name: n, last_name: 'N', notes: 'n'.repeat(4001) })
};
function addYears(delta) { const d = new Date(); d.setUTCFullYear(d.getUTCFullYear() + delta); return d.toISOString().slice(0, 10); }

try {
  // ---- 1. the same valid body makes the same member ------------------------------------------------------------------------------------------------
  const compared = [];
  for (const [label, make] of Object.entries(validBodies)) {
    const nameA = unique(); const nameC = unique();
    const a = await addMember(make(nameA)); const v = visitorFor(nameC); const c = await convert(v, make(nameC));
    assert.equal(a.status, 302, `${label}: Add member succeeds (${a.status})`); assert.equal(c.status, 302, `${label}: Convert succeeds (${c.status})`);
    const sa = memberShape(memberIdFrom(a)); const sc = memberShape(memberIdFrom(c));
    // names differ by construction; every other stored field must match
    for (const key of ['first_name']) { delete sa.shape[key]; delete sc.shape[key]; }
    assert.deepEqual(sc.shape, sa.shape, `${label}: the stored member rows match field by field`);
    assert.deepEqual(sc.group, sa.group, `${label}: cell group membership`);
    assert.deepEqual(sc.history, sa.history, `${label}: status history (the first row)`);
    assert.deepEqual(sc.createdDetail, sa.createdDetail, `${label}: the member.created audit detail`);
    assert.deepEqual(sc.overrideDetail && { ...sc.overrideDetail, possible_matches: undefined }, sa.overrideDetail && { ...sa.overrideDetail, possible_matches: undefined }, `${label}: the duplicate-override audit row exists on BOTH paths`);
    assert.equal(sc.spouse === null, sa.spouse === null, `${label}: spouse link`);
    assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'member.duplicate_warning_overridden' AND entity_id = ?", String(memberIdFrom(c))), 1, `${label}: Convert audits the override exactly once`);
    compared.push(label);
  }
  console.log(`PASS (1) ${compared.length} valid bodies (${compared.join(', ')}) give identical members, history, groups, relationships and audit rows by Add member and by Convert`);

  // ---- 2. the same invalid body is refused the same way --------------------------------------------------------------------------------------------
  for (const [label, make] of Object.entries(invalidBodies)) {
    const members = count('SELECT COUNT(*) n FROM members'); const visitorsBefore = db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
    const a = await addMember(make(unique())); const v = visitorFor(unique()); const c = await convert(v, make(unique()));
    assert.equal(a.status, 400, `${label}: Add member refuses`); assert.equal(c.status, 400, `${label}: Convert refuses`);
    const ea = errorsOf(await a.text()); const ec = errorsOf(await c.text());
    assert.ok(ea.length > 0, `${label}: Add member shows an error message`);
    assert.deepEqual(ec, ea, `${label}: the very same validation messages`);
    assert.equal(count('SELECT COUNT(*) n FROM members'), members, `${label}: nothing was created by either`);
    assert.equal(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(v).member_id, null, `${label}: and the First Timer is untouched`);
    void visitorsBefore;
  }
  console.log(`PASS (2) ${Object.keys(invalidBodies).length} invalid bodies are refused with identical messages and nothing is created, by either path`);

  // ---- 3. the same duplicate gets the same warning -------------------------------------------------------------------------------------------------
  {
    const first = await addMember({ first_name: 'Duplicate', last_name: 'Twin', phone: '+974 5588 1234', date_of_birth: '1990-01-01', date_joined: '2024-05-05' }); assert.equal(first.status, 302);
    const dupBody = { first_name: 'Duplicate', last_name: 'Twin', phone: '+974 5588 1234', date_of_birth: '1990-01-01', date_joined: '2024-05-05' };
    const members = count('SELECT COUNT(*) n FROM members');
    const a = await admin.post('/members', { status: 'pending', ...dupBody }, { csrfFrom: '/members/new' });
    const v = visitorFor(unique()); const c = await admin.post(`/visitors/${v}/convert`, dupBody, { csrfFrom: `/visitors/${v}/convert` });
    const [ta, tc] = [await a.text(), await c.text()];
    assert.equal(a.status, 200); assert.equal(c.status, 200); assert.match(ta, /Possible duplicate/i); assert.match(tc, /Possible duplicate/i);
    const names = (t) => [...t.matchAll(/Duplicate Twin/g)].length > 0;
    assert.ok(names(ta) && names(tc), 'both name the existing member');
    assert.match(tc, /link them instead/i, 'Convert also offers Link (the one intended addition)');
    assert.equal(count('SELECT COUNT(*) n FROM members'), members, 'neither created a member while the warning is showing');
    console.log('PASS (3) the same duplicate raises the same warning on both paths and creates nothing until it is confirmed');
  }

  // ---- 4. the intended differences, pinned ------------------------------------------------------------------------------------------------------------
  {
    const nA = unique(); const nC = unique();
    const a = await addMember({ first_name: nA, last_name: 'Diff' }); const v = visitorFor(nC); const c = await convert(v, { first_name: nC, last_name: 'Diff', status: 'active' });
    const ma = db.prepare('SELECT * FROM members WHERE id = ?').get(memberIdFrom(a)); const mc = db.prepare('SELECT * FROM members WHERE id = ?').get(memberIdFrom(c));
    assert.equal(ma.date_joined, null, 'Add member leaves the join date empty when none is typed');
    assert.equal(mc.date_joined, today, 'Convert defaults it to today (never the first visit)');
    assert.equal(mc.status, 'pending', 'Convert always creates a Pending member, whatever status the form posts');
    assert.equal(db.prepare("SELECT reason FROM member_status_history WHERE member_id = ?").get(mc.id).reason, 'Joined after visiting');
    assert.equal(db.prepare("SELECT reason FROM member_status_history WHERE member_id = ?").get(ma.id).reason, 'Record created');
    assert.equal(count('SELECT COUNT(*) n FROM users WHERE member_id = ?', ma.id), 1, 'Add member provisions a sign-in account');
    assert.equal(count('SELECT COUNT(*) n FROM users WHERE member_id = ?', mc.id), 0, 'Convert does not (unchanged from before the refactor; an owner decision if it should)');
    assert.deepEqual(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(v), { state: 'joined', member_id: mc.id }, 'Convert links the First Timer');
    console.log('PASS (4) the intended differences are exactly: join-date default, forced Pending, history wording, no sign-in account, and the First Timer link');
  }

  // ---- 5. atomic behaviour is the same ------------------------------------------------------------------------------------------------------------------
  {
    db.exec("CREATE TRIGGER fx_member_audit BEFORE INSERT ON audit_logs WHEN NEW.action = 'member.created' BEGIN SELECT RAISE(ABORT, 'injected failure'); END");
    const members = count('SELECT COUNT(*) n FROM members'); const history = count('SELECT COUNT(*) n FROM member_status_history');
    const a = await addMember({ first_name: unique(), last_name: 'Atomic', date_joined: '2024-05-05', cell_group_id: String(ids.groupA) });
    const v = visitorFor(unique()); const c = await convert(v, { first_name: unique(), last_name: 'Atomic', date_joined: '2024-05-05', cell_group_id: String(ids.groupA) });
    db.exec('DROP TRIGGER fx_member_audit');
    assert.ok(a.status >= 500 && c.status >= 500, `both report the failure (${a.status}, ${c.status})`);
    assert.equal(count('SELECT COUNT(*) n FROM members'), members, 'no half-created member from either');
    assert.equal(count('SELECT COUNT(*) n FROM member_status_history'), history, 'no orphan history');
    assert.equal(db.prepare('SELECT member_id, state FROM visitors WHERE id = ?').get(v).member_id, null, 'and the First Timer is not linked');
    console.log('PASS (5) a failure part-way rolls back the member, history, group and link identically on both paths');
  }
  console.log('ALL PASS');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
