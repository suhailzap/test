import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Ministries: sits immediately after Cell groups in the one main navigation (Members, Attendance, Cell groups, Ministries, Activities, Calendar ...), for every role that sees it;
 * and wherever a ministry lists the people serving, someone with no profile photo gets the SAME default avatar used on the Members list (a round initial), not a blank image.
 */

const f = await buildPortalFixture('cciq-ministries-ui-');
const { db, ids, users } = f;
const nav = await import(new URL('../lib/navigation.js', import.meta.url));
void nav;

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  for (const [who, client] of [['super admin', admin], ['cell group leader', leader]]) {
    const html = await (await client.get('/')).text();
    const sidenav = /<nav class="sidenav"[\s\S]*?<\/nav>/.exec(html)?.[0] || '';
    const labels = [...sidenav.matchAll(/<a class="nav__link[^"]*"[^>]*>\s*<svg[^>]*>[\s\S]*?<\/svg>\s*<span>([^<]+)<\/span>/g)].map((m) => m[1].trim());
    const pick = (name) => labels.indexOf(name);
    assert.ok(pick('Ministries') > -1, `${who} sees Ministries`);
    assert.ok(pick('Cell groups') > -1 && pick('Ministries') === pick('Cell groups') + 1, `${who}: Ministries comes immediately after Cell groups (${labels.join(' > ')})`);
    if (pick('Activities') > -1) assert.ok(pick('Ministries') < pick('Activities'), `${who}: and before Activities`);
    if (pick('Calendar') > -1) assert.ok(pick('Ministries') < pick('Calendar'), `${who}: and before the Calendar`);
    if (pick('Members') > -1 && pick('Attendance') > -1) assert.ok(pick('Members') < pick('Attendance') && pick('Attendance') < pick('Cell groups'), `${who}: Members, Attendance, Cell groups keep their order`);
  }

  // ---- default avatar ------------------------------------------------------------------------------------------------------------------------------------------------
  const ministryId = ids.ministry;
  const withPhoto = ids.member.a3;
  db.prepare('UPDATE members SET photo_path = ?, photo_updated_at = ? WHERE id = ?').run('members/test/photo.jpg', '2026-10-01T00:00:00.000Z', withPhoto);
  const services = await import(new URL('../services/ministries.js', import.meta.url));
  services.addMember(ministryId, withPhoto, {});
  const noPhoto = ids.member.a2; // already serving in the fixture ministry, no photo

  const show = await (await admin.get(`/ministries/${ministryId}`)).text();
  assert.match(show, /<span class="avatar avatar--empty" aria-hidden="true">A<\/span>/, 'a member with no photo gets the standard round initial (Anna: A)');
  assert.match(show, new RegExp(`<img class="avatar" data-initial="A" src="/media/members/${withPhoto}/photo`), 'a member with a photo gets the photo in the same avatar');
  const quick = await (await admin.get(`/ministries/${ministryId}/quick`)).text();
  assert.match(quick, /<span class="avatar avatar--empty" aria-hidden="true">A<\/span>/, 'the quick view uses the same default avatar');
  assert.ok(!/<span class="avatar">\s*<span aria-hidden="true">/.test(quick), 'the old blank treatment is gone');
  assert.ok(db.prepare('SELECT 1 FROM ministry_members WHERE ministry_id = ? AND member_id = ?').get(ministryId, noPhoto), 'the fixture member serves here');
  const members = await (await admin.get('/members')).text();
  assert.match(members, /<span class="avatar avatar--empty" aria-hidden="true">/, 'the Members list uses this very treatment');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('PASS (navigation) Ministries sits immediately after Cell groups, before Activities and the Calendar, for an administrator and for a leader; the other items keep their order');
console.log('PASS (avatar) people serving with no photo get the standard round initial, with a photo the photo, on the ministry page and in the quick view, exactly as on the Members list');
console.log('ALL PASS');
