import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * A test that imports application code BEFORE creating its isolated environment would run against the database .env names (the development one). That happened once, and a whole
 * fixture landed in the development database. createIsolatedTestEnv() now refuses to continue when the application configuration was already read in the process.
 * Proven in child processes: the wrong order throws and creates nothing; the right order works.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const run = (body) => spawnSync(process.execPath, ['--input-type=module', '-e', body], { cwd: root, encoding: 'utf8', env: { ...process.env, NODE_ENV: 'test' } });
const envUrl = new URL('./lib/test-env.mjs', import.meta.url).href;
const datesUrl = new URL('../lib/dates.js', import.meta.url).href;

const wrong = run(`import ${JSON.stringify(datesUrl)}; const { createIsolatedTestEnv } = await import(${JSON.stringify(envUrl)}); createIsolatedTestEnv('guard-wrong-'); console.log('NOT REFUSED');`);
assert.notEqual(wrong.status, 0, 'application code imported first: refused');
assert.match(wrong.stderr, /imported before the isolated environment was created/);
assert.doesNotMatch(wrong.stdout, /NOT REFUSED/);

const right = run(`const { createIsolatedTestEnv } = await import(${JSON.stringify(envUrl)}); const env = createIsolatedTestEnv('guard-right-'); await import(${JSON.stringify(datesUrl)}); const c = (await import(${JSON.stringify(new URL('../config/env.js', import.meta.url).href)})).default; console.log(c.databaseFile === env.databaseFile ? 'ISOLATED' : 'WRONG DB'); env.cleanup();`);
assert.equal(right.status, 0, right.stderr);
assert.match(right.stdout, /ISOLATED/, 'environment first, imports after: the application uses the disposable database');
console.log('PASS (order guard) importing application code before createIsolatedTestEnv() is refused with a clear message; the right order resolves the disposable database');
console.log('ALL PASS');
