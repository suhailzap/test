import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * My profile: the personal-details save and the photo upload are visibly separate steps. Storage,
 * file validation and permissions are unchanged - this checks they still hold and that neither form
 * carries the other's fields.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-profile-photo-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Pp${crypto.randomBytes(12).toString('base64url')}9!`;
const me = createMember({ first_name: 'Profile', last_name: 'Owner', phone: '+974 5550 0001' }, { status: 'active' });
const other = createMember({ first_name: 'Someone', last_name: 'Else' }, { status: 'active' });
await createUser({ username: 'profile_owner', email: 'profile.owner@fixture.invalid', password: PASSWORD, displayName: 'Profile Owner', roleKeys: ['member'], memberId: me.id, mustChangePassword: false });
await createUser({ username: 'profile_unlinked', email: 'profile.unlinked@fixture.invalid', password: PASSWORD, displayName: 'Unlinked', roleKeys: ['member'], mustChangePassword: false });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function session(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const cookie = await session('profile.owner@fixture.invalid');
  const html = async (c = cookie) => {
    const res = await fetch(`${base}/my/profile`, { headers: { Cookie: c } });
    assert.equal(res.status, 200);
    return res.text();
  };
  const photoOf = () => db.prepare('SELECT photo_path, phone FROM members WHERE id = ?').get(me.id);
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const upload = async (blob, name, c = cookie) => {
    const form = new FormData();
    form.append('_csrf', (await html(c)).match(/name="_csrf" value="([^"]+)"/)[1]);
    form.append('photo', blob, name);
    return fetch(`${base}/my/profile/photo`, { method: 'POST', redirect: 'manual', headers: { Cookie: c }, body: form });
  };

  // Layout: two separate forms, photo first, each says the other is a separate step.
  let page = await html();
  const photoAt = page.indexOf('id="profile-photo"');
  const detailsAt = page.indexOf('<h2>Your contact details</h2>');
  assert.equal((page.match(/id="profile-photo"/g) || []).length, 1, 'one photo-management card');
  assert.ok(photoAt > 0 && detailsAt > photoAt, 'the Profile photo card comes before the contact details');
  const photoCard = page.slice(photoAt, detailsAt);
  const detailsCard = page.slice(detailsAt);
  assert.match(photoCard, /data-photo-preview/, 'a small current-photo preview (an initial placeholder when there is none)');
  assert.match(photoCard, /Saved separately from your contact details/);
  assert.match(photoCard, />Profile photo</);
  assert.doesNotMatch(photoCard, /avatar--lg/, 'the photo card is compact: not a second large identity card');
  assert.ok(photoCard.length < 1500, 'and its copy is short');
  assert.match(photoCard, /type="file"/);
  assert.match(photoCard, />Upload photo<\/button>/, 'an explicit photo action');
  assert.doesNotMatch(photoCard, /name="phone"|name="email"|name="address"/, 'the photo form carries no personal details');
  assert.doesNotMatch(detailsCard, /type="file"/, 'the details form carries no file field, so it cannot upload one');
  assert.match(detailsCard, />Save my details<\/button>/);
  assert.match(detailsCard, /Your photo is saved separately/);
  console.log('PASS (layout) the photo card and the contact-details form are separate; each says the other is a separate step; the details form has no file input');

  // Behaviour: saving details never touches the photo; uploading never touches the details.
  const csrf = page.match(/name="_csrf" value="([^"]+)"/)[1];
  const save = await fetch(`${base}/my/profile`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ _csrf: csrf, phone: '+974 5550 0002', preferred_name: 'Pro' })
  });
  assert.equal(save.status, 302);
  assert.equal(photoOf().phone, '+974 5550 0002');
  assert.equal(photoOf().photo_path, null, 'saving details did not create or change a photo');

  const good = await upload(new Blob([png], { type: 'image/png' }), 'me.png');
  assert.equal(good.status, 302);
  assert.equal(good.headers.get('location'), '/my/profile');
  const stored = photoOf();
  assert.ok(stored.photo_path && stored.photo_path.startsWith(`members/${me.id}/`), 'the photo is stored under the member\'s own folder');
  assert.equal(stored.phone, '+974 5550 0002', 'uploading did not touch the details');
  page = await html();
  assert.match(page, /alt="Your current photo"/);
  assert.match(page, /Change photo/);
  assert.match(page, new RegExp(`/media/members/${me.id}/photo`));
  console.log('PASS (behaviour) details and photo save independently; the stored photo shows as the current photo with a Change action');

  // Existing validation and authorization still hold.
  const before = photoOf().photo_path;
  const notAnImage = await upload(new Blob(['this is text, not an image'], { type: 'image/png' }), 'fake.png');
  assert.equal(notAnImage.status, 302);
  assert.equal(photoOf().photo_path, before, 'a file whose bytes are not an image is refused (the declared type is only a claim)');
  const wrongType = await upload(new Blob(['<html></html>'], { type: 'text/html' }), 'page.html');
  assert.equal(wrongType.status, 302);
  assert.equal(photoOf().photo_path, before, 'a non-image type is refused');
  assert.match(await (await fetch(`${base}/my/profile`, { headers: { Cookie: cookie } })).text(), /alert/, 'and a message is shown');
  const unlinked = await session('profile.unlinked@fixture.invalid');
  const refused = await upload(new Blob([png], { type: 'image/png' }), 'x.png', unlinked);
  assert.equal(refused.status, 302, 'an account not linked to a member record cannot upload');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM members WHERE id = ? AND photo_path IS NOT NULL").get(other.id).n, 0, 'nobody else\'s photo changed');
  const anonymous = await fetch(`${base}/my/profile/photo`, { method: 'POST', redirect: 'manual' });
  assert.ok([302, 403].includes(anonymous.status), 'an anonymous upload is refused');
  console.log('PASS (validation/authorization) non-images and forged types are refused, unlinked accounts cannot upload, nobody can touch another member\'s photo');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
