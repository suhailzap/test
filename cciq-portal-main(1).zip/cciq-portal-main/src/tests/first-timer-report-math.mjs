import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The First Timer numbers, checked against answers worked out BY HAND from a designed dataset (the expected figures are computed from the
 * specification below in plain JavaScript, never from the application's own queries):
 *   total, still visiting, returning, joined, did not continue, conversion and retention rates, needing follow-up, per-inviter totals,
 *   returned-at-least-once, and the Membership Review counts.
 * They must agree on every surface that shows them (service, the list header, the follow-up page, the inviter table, the drill-down, the
 * dashboard notice, the report data behind the PDF), must not depend on the page or page size, must survive filters exactly, and must not
 * be capped. The approved formulas are NOT changed here; they are written down and pinned.
 */

const f = await buildPortalFixture('cciq-report-math-');
const { db, users, mods } = f;
const { today, addDays } = mods.dates;
const visitors = mods.visitors;
db.exec('DELETE FROM visitor_visits; DELETE FROM visitors;');
const GRACE = 21;

// ---- the designed dataset ----------------------------------------------------------------------------------------------------------------------------
// lastVisitDaysAgo / visits describe the visit history; first visit is the oldest. inviter: 'A' | 'B' | null (members created below).
const GROUPS = [
  { key: 'new-recent', n: 5, state: 'new', visits: 1, lastAgo: 10, fu: 'new', inviters: ['A', 'A', 'B', null, null] },
  { key: 'new-lapsed', n: 4, state: 'new', visits: 1, lastAgo: 30, fu: 'new', inviters: ['A', 'B', 'B', null] },
  { key: 'returning-lapsed', n: 3, state: 'returning', visits: 2, lastAgo: 40, fu: 'contacted', inviters: ['A', null, null] },
  { key: 'returning-active', n: 6, state: 'returning', visits: 3, lastAgo: 5, fu: 'new', inviters: ['A', 'A', 'B', 'B', null, null] },
  { key: 'not-returned', n: 7, state: 'not_returned', visits: 1, lastAgo: 100, fu: 'new', inviters: ['A', 'B', 'B', 'B', null, null, null], twoVisits: 3 },
  { key: 'not-returned-done', n: 2, state: 'not_returned', visits: 1, lastAgo: 100, fu: 'completed', inviters: ['A', null] },
  { key: 'declined', n: 3, state: 'declined', visits: 1, lastAgo: 50, fu: 'new', inviters: ['B', null, null] },
  { key: 'returning-dismissed', n: 2, state: 'returning', visits: 2, lastAgo: 60, fu: 'dismissed', inviters: [null, null] },
  { key: 'joined', n: 8, state: 'joined', visits: 2, lastAgo: 14, fu: 'new', inviters: ['A', 'A', 'A', 'B', null, null, null, null] }
];
const SPEC = [];
for (const g of GROUPS) {
  for (let i = 0; i < g.n; i += 1) {
    const visits = g.twoVisits && i < g.twoVisits ? 2 : g.visits;
    SPEC.push({ group: g.key, state: g.state, fu: g.fu, inviter: g.inviters[i], visits, lastAgo: g.lastAgo, firstAgo: g.lastAgo + (visits - 1) * 7 });
  }
}
const inviterA = mods.members.createMember({ first_name: 'Inviter', last_name: 'Alpha' }, { status: 'active' }).id;
const inviterB = mods.members.createMember({ first_name: 'Inviter', last_name: 'Bravo' }, { status: 'active' }).id;
const oldMembers = [];
let serial = 0;
for (const spec of SPEC) {
  serial += 1;
  const id = visitors.createVisitor({
    first_name: `Math${serial}`, last_name: spec.group, first_visit_date: addDays(today(), -spec.firstAgo),
    invited_by_member_id: spec.inviter === 'A' ? inviterA : spec.inviter === 'B' ? inviterB : null
  }, { userId: users.churchAdmin.id }).id;
  spec.id = id;
  for (let k = 1; k < spec.visits; k += 1) db.prepare('INSERT INTO visitor_visits (visitor_id, visit_date, recorded_at) VALUES (?, ?, ?)').run(id, addDays(today(), -(spec.firstAgo - 7 * k)), 'x');
  db.prepare('UPDATE visitors SET follow_up_state = ? WHERE id = ?').run(spec.fu, id);
  if (spec.state === 'joined') {
    if (spec.id % 2) assert.equal(visitors.convertToMember(id, { userId: users.churchAdmin.id }).ok, true);
    else {
      const m = mods.members.createMember({ first_name: `LinkTarget${serial}`, last_name: 'M' }, { status: 'active' }); oldMembers.push(m.id);
      assert.equal(visitors.linkVisitorToMember(id, m.id, { userId: users.churchAdmin.id }).ok, true);
    }
  } else if (spec.state !== 'new') db.prepare('UPDATE visitors SET state = ? WHERE id = ?').run(spec.state, id);
}
assert.equal(SPEC.length, 40);

// ---- the expected figures, worked out from SPEC ---------------------------------------------------------------------------------------------------------------
const expect = (subset) => {
  const by = { new: 0, returning: 0, joined: 0, not_returned: 0, declined: 0 };
  let returned = 0; let needs = 0; const inviters = new Map(); const byFu = { new: 0, acknowledged: 0, contacted: 0, completed: 0, dismissed: 0 };
  for (const s of subset) {
    by[s.state] += 1; byFu[s.fu] += 1;
    if (s.visits > 1) returned += 1;
    if (['new', 'not_returned', 'returning'].includes(s.state) && !['completed', 'dismissed'].includes(s.fu) && s.lastAgo > GRACE) needs += 1; // last visit strictly before today-21
    if (s.inviter) {
      const row = inviters.get(s.inviter) || { invited: 0, joined: 0, stillVisiting: 0, lapsed: 0 };
      row.invited += 1; if (s.state === 'joined') row.joined += 1; if (['new', 'returning'].includes(s.state)) row.stillVisiting += 1; if (['not_returned', 'declined'].includes(s.state)) row.lapsed += 1;
      inviters.set(s.inviter, row);
    }
  }
  const total = subset.length; const still = by.new + by.returning;
  const pct = (n) => (total ? Math.round((n / total) * 100) : 0);
  return { total, by, still, joined: by.joined, didNotContinue: by.not_returned + by.declined, returned, needs, conversion: pct(by.joined), retention: pct(still + by.joined), inviters, byFu };
};
const all = expect(SPEC);
assert.deepEqual([all.total, all.by.new, all.by.returning, all.by.not_returned, all.by.declined, all.by.joined], [40, 9, 11, 9, 3, 8], 'sanity: the designed dataset has the intended shape');
assert.equal(all.needs, 14); assert.equal(all.returned, 22); assert.equal(all.conversion, 20); assert.equal(all.retention, 70);

const sameAsExpected = (report, want, label) => {
  assert.equal(report.total, want.total, `${label}: total`);
  assert.deepEqual(report.byState, want.by, `${label}: by state`);
  assert.equal(report.stillVisiting, want.still, `${label}: still visiting (new + returning)`);
  assert.equal(report.joined, want.joined, `${label}: joined`);
  assert.equal(report.didNotContinue, want.didNotContinue, `${label}: did not continue (not returned + declined)`);
  assert.equal(report.returnedAtLeastOnce, want.returned, `${label}: returned at least once`);
  assert.equal(report.needsFollowUp, want.needs, `${label}: needing follow-up`);
  assert.equal(report.conversionRate, want.conversion, `${label}: conversion = round(joined / total)`);
  assert.equal(report.retentionRate, want.retention, `${label}: retention = round((still visiting + joined) / total)`);
  assert.deepEqual(report.byFollowUp, want.byFu, `${label}: follow-up status counts`);
  const got = new Map(report.inviters.map((r) => [r.id === inviterA ? 'A' : 'B', r]));
  for (const [key, row] of want.inviters) {
    assert.deepEqual({ invited: got.get(key).invited, joined: got.get(key).joined, stillVisiting: got.get(key).stillVisiting, lapsed: got.get(key).lapsed }, row, `${label}: inviter ${key}`);
  }
  assert.equal(report.inviters.length, want.inviters.size, `${label}: only inviters who invited someone in the set are listed`);
};

// ---- 1. the report data, whole and filtered --------------------------------------------------------------------------------------------------------------------
sameAsExpected(visitors.firstTimersReportData({ graceDays: GRACE }), all, 'all time');
for (const state of ['new', 'returning', 'joined', 'not_returned', 'declined']) sameAsExpected(visitors.firstTimersReportData({ state, graceDays: GRACE }), expect(SPEC.filter((s) => s.state === state)), `state=${state}`);
sameAsExpected(visitors.firstTimersReportData({ inviterId: inviterA, graceDays: GRACE }), expect(SPEC.filter((s) => s.inviter === 'A')), 'inviter A');
sameAsExpected(visitors.firstTimersReportData({ inviterId: inviterB, graceDays: GRACE }), expect(SPEC.filter((s) => s.inviter === 'B')), 'inviter B');
const from = addDays(today(), -60); const to = addDays(today(), -20);
sameAsExpected(visitors.firstTimersReportData({ from, to, graceDays: GRACE }), expect(SPEC.filter((s) => addDays(today(), -s.firstAgo) >= from && addDays(today(), -s.firstAgo) <= to)), 'a date range (by first visit)');
sameAsExpected(visitors.firstTimersReportData({ from, to, state: 'returning', inviterId: inviterA, graceDays: GRACE }), expect(SPEC.filter((s) => addDays(today(), -s.firstAgo) >= from && addDays(today(), -s.firstAgo) <= to && s.state === 'returning' && s.inviter === 'A')), 'filters combined');
assert.deepEqual(visitors.firstTimersReportData({ state: 'declined', inviterId: inviterA, graceDays: GRACE }).total, 0, 'an empty selection is zero, not an error');
assert.equal(visitors.firstTimersReportData({ state: 'declined', inviterId: inviterA, graceDays: GRACE }).conversionRate, 0, 'and its rates are 0, not NaN');
const counts = visitors.visitorCounts();
assert.deepEqual([counts.total, counts.new, counts.returning, counts.joined, counts.not_returned, counts.declined, counts.stillVisiting], [40, 9, 11, 8, 9, 3, 20], 'visitorCounts agrees');
console.log('PASS (1) the report data equals the hand-worked answers for the whole set, each state, each inviter, a date range and combined filters');

// ---- 2. the three implementations of "needs follow-up" agree ---------------------------------------------------------------------------------------------------
{
  const list = visitors.needingFollowUp({ graceDays: GRACE, limit: 100000 });
  assert.equal(list.length, all.needs, 'the follow-up list has exactly the people the report counts');
  const ids = new Set(list.map((v) => v.id));
  for (const s of SPEC) assert.equal(ids.has(s.id), expect([s]).needs === 1, `${s.group}: ${ids.has(s.id) ? 'listed' : 'not listed'} as designed`);
  let flagged = 0;
  for (const who of [inviterA, inviterB]) flagged += visitors.inviteesFor(who, { graceDays: GRACE }).filter((v) => v.needs_follow_up).length;
  assert.equal(flagged, SPEC.filter((s) => s.inviter && expect([s]).needs === 1).length, 'and the per-inviter drill-down flags the same people');
  const small = visitors.needingFollowUp({ graceDays: GRACE, limit: 5 });
  assert.equal(small.length, 5, 'a limit only shortens the list');
  console.log('PASS (2) the follow-up list, the report and the inviter drill-down agree on exactly who needs follow-up');
}

// ---- 3. every surface shows the same numbers, on any page or page size --------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const text = async (url) => { const res = await admin.get(url); assert.equal(res.status, 200, url); return (await res.text()).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '); };
  const header = await text('/visitors');
  assert.match(header, new RegExp(`${all.still} still visiting · ${all.joined} became members · ${all.by.not_returned} have not returned`), 'the list header');
  for (const q of ['', '?page=2', '?page_size=10', '?page=3&page_size=10', '?page_size=100', '?state=returning', '?state=returning&page_size=5']) {
    const page = await text(`/visitors${q}`);
    assert.match(page, new RegExp(`${all.still} still visiting`), `the header does not change with the page or filter (${q})`);
  }
  const wantTotal = (state) => (state ? expect(SPEC.filter((s) => s.state === state)).total : 40);
  for (const [q, n] of [['', wantTotal(null)], ['?page_size=10', 40], ['?page=2&page_size=10', 40], ['?state=returning', wantTotal('returning')], ['?state=joined&page_size=5', wantTotal('joined')]]) {
    const page = await text(`/visitors${q}`);
    assert.match(page, new RegExp(`of ${n}\\b`), `the list reports a total of ${n} on ${q || "the first page"}`);
  }
  const followUp = await text('/visitors/follow-up');
  assert.match(followUp, new RegExp(`${all.needs} First Timers worth checking on`), 'the follow-up page total');
  for (const q of ['?page_size=5', '?page=2&page_size=5', '?page_size=100']) assert.match(await text(`/visitors/follow-up${q}`), new RegExp(`${all.needs} First Timers worth checking on`), `the follow-up total does not depend on paging (${q})`);
  assert.equal(visitors.inviterSummary({ pageSize: 1 }).total, 2, 'two inviters however the table is paged');
  const invitedSum = [1, 2].reduce((s, p) => s + visitors.inviterSummary({ page: p, pageSize: 1 }).rows.reduce((a, r) => a + r.invited, 0), 0);
  assert.equal(invitedSum, [...all.inviters.values()].reduce((s, r) => s + r.invited, 0), 'the inviter table sums to the number invited, split across pages');
  console.log('PASS (3) the list header, list totals and follow-up totals are identical on every page, page size and filter and match the hand-worked figures');

  // the PDF is built from the very same data function and carries the same figures
  const pdfSource = (await import('node:fs')).readFileSync(new URL('../services/reports-pdf.js', import.meta.url), 'utf8');
  const fn = pdfSource.slice(pdfSource.indexOf('export function firstTimersPdf'), pdfSource.indexOf('export function', pdfSource.indexOf('export function firstTimersPdf') + 10));
  for (const field of ['report.total', 'report.stillVisiting', 'report.joined', 'report.needsFollowUp', 'report.conversionRate', 'report.retentionRate', 'report.didNotContinue']) assert.ok(fn.includes(field), `the PDF prints ${field} straight from the shared report data`);
  assert.ok(fn.includes('firstTimersReportData('), 'and calls the same function the screens use (no second formula)');
  for (const q of ['', '?state=joined', `?inviter_id=${inviterA}`, `?from=${from}&to=${to}`]) {
    const res = await admin.get(`/reports/first-timers/pdf${q}`); const bytes = Buffer.from(await res.arrayBuffer());
    assert.equal(res.status, 200); assert.ok(bytes.subarray(0, 5).toString() === '%PDF-' && bytes.length > 1500, `the PDF (${q || 'all'}) is a real document`);
  }
  console.log('PASS (3b) the PDF uses the shared figures (no second formula) and renders for every filter');
} finally {
  await portal.stop();
}

// ---- 4. no silent cap ---------------------------------------------------------------------------------------------------------------------------------------------
{
  const insert = db.prepare("INSERT INTO visitors (first_name, last_name, first_visit_date, state, follow_up_state, created_at, updated_at) VALUES (?, 'Bulk', ?, 'new', 'new', 'x', 'x')");
  db.transaction(() => { for (let i = 0; i < 5300; i += 1) insert.run(`Cap${i}`, addDays(today(), -400)); })();
  const big = visitors.firstTimersReportData({ graceDays: GRACE });
  assert.equal(big.total, 5340, 'a report over more than 5,000 First Timers counts every one of them');
  assert.equal(big.byState.new, 9 + 5300);
  assert.equal(visitors.needingFollowUp({ graceDays: GRACE, limit: 100000 }).length, all.needs + 5300, 'and so does the follow-up list');
  assert.equal(visitors.listVisitors({ page: 1, pageSize: 25 }).total, 5340, 'the list total is the whole set');
  assert.equal(visitors.visitorCounts().total, 5340);
  db.exec("DELETE FROM visitors WHERE last_name = 'Bulk'");
  console.log('PASS (4) 5,340 First Timers: the report, the follow-up list, the list total and the counts all see every row (no 5,000-row cap)');
}

// ---- 5. Membership Review counts ------------------------------------------------------------------------------------------------------------------------------------
{
  const ins = db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, closed_at, trigger_service_date, suppress_after_date, member_id, window_json) VALUES (?, ?, 'x', ?, '2026-01-02', ?, ?, '{\"fridays\":[1,2,3,4]}')");
  const pool = SPEC.filter((s) => s.state !== 'joined').map((s) => s.id);
  const plan = [['open', 6], ['continued', 4]];
  let at = 0;
  for (const [status, n] of plan) for (let i = 0; i < n; i += 1) ins.run(pool[at++], status, status === 'open' ? null : 'x', status === 'continued' ? '2026-01-02' : null, null);
  const joinedIds = SPEC.filter((s) => s.state === 'joined').map((s) => s.id);
  joinedIds.slice(0, 2).forEach((id) => ins.run(id, 'converted', 'x', null, db.prepare('SELECT member_id FROM visitors WHERE id = ?').get(id).member_id));
  joinedIds.slice(2, 3).forEach((id) => ins.run(id, 'linked', 'x', null, db.prepare('SELECT member_id FROM visitors WHERE id = ?').get(id).member_id));
  const review = await import('../services/membership-review.js');
  assert.equal(review.openReviewCount(), 6);
  for (const [status, n] of [['open', 6], ['continued', 4], ['converted', 2], ['linked', 1], ['all', 13]]) {
    for (const size of [1, 5, 25, 100]) {
      let seen = 0; let total = 0; let pages = 1;
      for (let p = 1; p <= pages; p += 1) { const r = review.listReviews({ status, page: p, pageSize: size }); seen += r.rows.length; total = r.total; pages = r.pages; }
      assert.equal(total, n, `${status}: total ${n} at page size ${size}`); assert.equal(seen, n, `${status}: every row appears exactly once across the pages at size ${size}`);
    }
  }
  const portal2 = await startPortal();
  try {
    const admin = await signIn(portal2.base, users.churchAdmin.email, f.PASSWORD);
    const dash = (await (await admin.get('/')).text()).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    assert.match(dash, /6 First Timers are ready for a membership review/, 'the dashboard notice equals the open count');
    const list = (await (await admin.get('/visitors')).text()).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    assert.match(list, /Membership review \(6\)/, 'and so does the button on the First Timers page');
    assert.match((await (await admin.get('/visitors/reviews?status=all&page_size=5')).text()).replace(/<[^>]+>/g, ' '), /13/, 'the all-statuses list reports 13');
  } finally { await portal2.stop(); }
  console.log('PASS (5) Membership Review counts (6 open, 4 continued, 2 converted, 1 linked, 13 in all) are identical in the service at every page size, on the dashboard and on the First Timers page');
}
console.log('ALL PASS');
f.db.close();
f.env.cleanup();
