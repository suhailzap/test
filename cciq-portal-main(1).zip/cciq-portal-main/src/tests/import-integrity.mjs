import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness: a red-team review found that re-importing an existing
 * member from a spreadsheet silently wiped every WRITABLE_FIELDS column the
 * spreadsheet didn't mention (company, occupation, father_name, is_baptized,
 * baptism_date, cell_group_id, and others) — because commitMembers() built
 * its update payload only from the ~15 fields the import UI maps, and
 * updateMember() writes `undefined` as NULL for anything else. The fix seeds
 * the update payload from the current row first. This proves the original
 * defect is closed and the intended "fill blanks only" contract still holds.
 */

const env = createIsolatedTestEnv('cciq-import-integrity-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember, getMember } = await import('../services/members.js');
const { createGroup } = await import('../services/cell-groups.js');
const { previewMembers, commitMembers } = await import('../services/imports.js');
const { default: db } = await import('../db/index.js');

function preview(rows, mapping, headers) {
  return previewMembers({ headers: headers || Object.keys(rows[0]), rows, mapping });
}

// --- 1. Existing populated fields survive a minimal spreadsheet update. ---
{
  const group = createGroup({ name: 'Fixture Group', status: 'active' }, {});
  const member = createMember({
    first_name: 'Jane', last_name: 'Doe', phone: '5550000',
    company: 'Acme Corp', occupation: 'Engineer', father_name: 'John Doe Sr.',
    is_baptized: 1, baptism_date: '2010-05-01', baptism_place: 'CCIQ',
    cell_group_id: group.id, notes: 'Existing note'
  }, { status: 'active' });

  const rows = [{ First: 'Jane', Last: 'Doe', Phone: '5551111' }];
  const mapping = { first_name: 'First', last_name: 'Last', phone: 'Phone' };
  const p = preview(rows, mapping);
  assert.equal(p.rows[0].outcome, 'update');
  commitMembers(p, { filename: 'update-only.xlsx' });

  const after = getMember(member.id);
  assert.equal(after.company, 'Acme Corp', 'company must survive an import that never mentions it');
  assert.equal(after.occupation, 'Engineer', 'occupation must survive');
  assert.equal(after.father_name, 'John Doe Sr.', 'father_name must survive');
  assert.equal(after.is_baptized, 1, 'is_baptized must survive');
  assert.equal(after.baptism_date, '2010-05-01', 'baptism_date must survive');
  assert.equal(after.baptism_place, 'CCIQ', 'baptism_place must survive');
  assert.equal(after.notes, 'Existing note', 'notes must survive');
  console.log('PASS: existing populated fields survive a minimal spreadsheet update');
}

// --- 2. Blank existing fields can still be filled where intended. ---
{
  const member = createMember({ first_name: 'Blank', last_name: 'Fields' }, { status: 'active' });
  assert.equal(member.company, null);

  const rows = [{ First: 'Blank', Last: 'Fields', Company: 'New Co' }];
  const mapping = { first_name: 'First', last_name: 'Last' };
  // 'company' isn't in MEMBER_FIELDS' mappable set today, so fill a field
  // that is: phone, currently blank on this fixture.
  const rows2 = [{ First: 'Blank', Last: 'Fields', Phone: '5559999' }];
  const mapping2 = { first_name: 'First', last_name: 'Last', phone: 'Phone' };
  const p = preview(rows2, mapping2);
  assert.equal(p.rows[0].outcome, 'update');
  commitMembers(p, { filename: 'fill-blank.xlsx' });

  const after = getMember(member.id);
  assert.equal(after.phone, '5559999', 'a genuinely blank field must still be filled by the import');
  console.log('PASS: a blank existing field is still filled where the spreadsheet supplies one');
}

// --- 3. Populated fields are not overwritten (fill-blanks-only contract). ---
{
  const member = createMember({ first_name: 'Keep', last_name: 'Mine', phone: '5551000' }, { status: 'active' });
  const rows = [{ First: 'Keep', Last: 'Mine', Phone: '5552000' }];
  const mapping = { first_name: 'First', last_name: 'Last', phone: 'Phone' };
  const p = preview(rows, mapping);
  commitMembers(p, { filename: 'no-overwrite.xlsx' });

  const after = getMember(member.id);
  assert.equal(after.phone, '5551000', 'an already-populated field must not be overwritten by a re-import');
  console.log('PASS: an already-populated field is left as-is, not overwritten, on re-import');
}

// --- 4. Existing cell-group assignment survives import when no replacement is supplied. ---
{
  const group = createGroup({ name: 'Survives Group', status: 'active' }, {});
  const member = createMember(
    { first_name: 'Group', last_name: 'Member', cell_group_id: group.id },
    { status: 'active' }
  );
  assert.equal(getMember(member.id).cell_group_id, group.id);

  const rows = [{ First: 'Group', Last: 'Member', Phone: '5553000' }];
  const mapping = { first_name: 'First', last_name: 'Last', phone: 'Phone' };
  const p = preview(rows, mapping);
  assert.equal(p.rows[0].groupId, null, 'this row supplies no cell_group column, so no group should be resolved from it');
  commitMembers(p, { filename: 'group-survives.xlsx' });

  const after = getMember(member.id);
  assert.equal(after.cell_group_id, group.id, 'an existing cell-group assignment must survive an import that says nothing about groups');
  console.log('PASS: an existing cell-group assignment survives an import that supplies no replacement');
}

// --- 5. New-member import still works (create path unaffected by the fix). ---
{
  const group = createGroup({ name: 'New Member Group', status: 'active' }, {});
  const rows = [{ First: 'Brand', Last: 'New', Phone: '5554000', Group: 'New Member Group' }];
  const mapping = { first_name: 'First', last_name: 'Last', phone: 'Phone', cell_group: 'Group' };
  const p = preview(rows, mapping);
  assert.equal(p.rows[0].outcome, 'create');
  const counts = commitMembers(p, { filename: 'new-member.xlsx' });
  assert.equal(counts.created, 1);

  const created = p.rows[0];
  assert.ok(created);
  const rowsAfter = db.prepare(
    "SELECT id, phone, cell_group_id FROM members WHERE first_name = 'Brand' AND last_name = 'New'"
  ).get();
  assert.ok(rowsAfter, 'the new member must have been created');
  assert.equal(rowsAfter.phone, '5554000');
  assert.equal(rowsAfter.cell_group_id, group.id, 'a new member should be assigned to the group named in the spreadsheet');
  console.log('PASS: new-member import still creates records correctly, including cell-group assignment');
}

db.close();
env.cleanup();
console.log('ALL PASS');
