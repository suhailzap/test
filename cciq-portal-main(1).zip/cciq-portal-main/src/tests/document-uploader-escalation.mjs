import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness, R06 from the red-team review, independently
 * re-verified by Codex: a leader uploads a document under a category
 * they can see; an administrator later replaces its content (or moves
 * its category) to something confidential. Because uploaded_by never
 * changes, the previous scopeClause() fix (removing the relationship-
 * based bypass) still left an *uploader*-based bypass intact - the
 * original uploader retained access to whatever the document became.
 *
 * Fixed by removing uploaded_by as an independent grant in scopeClause()
 * entirely (src/services/documents.js) - audience is now the sole
 * boundary, full stop - and by adding the same canSee() check the GET
 * routes already had to the POST edit and POST replace routes, which
 * previously relied only on "are you the uploader" with no audience
 * check at all, reachable by direct POST even after GET access was
 * already correctly cut off.
 *
 * This suite proves the fix at the real HTTP level: list, detail, file
 * delivery, edit, and replace all correctly cut off the original
 * uploader the moment an admin moves the document to a staff-only
 * category - not just the canSee() unit tested in
 * document-audience-security.mjs.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-document-escalation-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createCategory } = await import('../services/documents.js');
const { default: db } = await import('../db/index.js');
const config = (await import('../config/env.js')).default;

const leaderMember = createMember({ first_name: 'Leader', last_name: 'Escalation' }, { status: 'active' });
await createUser({ email: 'leader.escalation@fixture.invalid', password: 'LeaderPassw0rd!2026', displayName: 'Leader Escalation', roleKeys: ['cell_group_leader'], memberId: leaderMember.id, mustChangePassword: false });
await createUser({ email: 'admin.escalation@fixture.invalid', password: 'AdminPassw0rd!2026', displayName: 'Admin Escalation', roleKeys: ['church_admin'], mustChangePassword: false });

const membersCategory = createCategory({ name: 'Church Activities Escalation', audience: 'members' });
const staffCategory = createCategory({ name: 'Financial Records Escalation', audience: 'staff' });

const leaderUserId = db.prepare('SELECT id FROM users WHERE email = ?').get('leader.escalation@fixture.invalid').id;

const docsDir = path.join(config.storageDir, 'documents');
fs.mkdirSync(docsDir, { recursive: true });
fs.writeFileSync(path.join(docsDir, 'escalation-fixture.pdf'), '%PDF-1.4 escalation fixture');

const at = new Date().toISOString();
const docId = Number(db.prepare(
  `INSERT INTO documents (title, category_id, original_filename, stored_path, mime_type,
     file_extension, file_size, status, version, uploaded_by, created_at, updated_at)
   VALUES ('Escalation Doc', ?, 'fixture.pdf', 'documents/escalation-fixture.pdf', 'application/pdf', 'pdf', 100, 'active', 1, ?, ?, ?)`
).run(membersCategory.id, leaderUserId, at, at).lastInsertRowid);

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;
const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

async function login(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preCookie;
}
async function csrfFrom(res) {
  return (await res.text()).match(/name="_csrf" value="([^"]+)"/)?.[1];
}

const leaderCookie = await login('leader.escalation@fixture.invalid', 'LeaderPassw0rd!2026');
const adminCookie = await login('admin.escalation@fixture.invalid', 'AdminPassw0rd!2026');

// --- Before the category change: the leader (uploader) legitimately reaches everything. ---
{
  const list = await fetch(`${base}/documents`, { headers: { Cookie: leaderCookie } });
  assert.ok((await list.text()).includes('Escalation Doc'), 'sanity: the document appears in the list while members-audience');
  const detail = await fetch(`${base}/documents/${docId}`, { headers: { Cookie: leaderCookie } });
  assert.equal(detail.status, 200, 'sanity: detail view reachable while members-audience');
  const file = await fetch(`${base}/documents/${docId}/file`, { headers: { Cookie: leaderCookie } });
  assert.equal(file.status, 200, 'sanity: file delivery reachable while members-audience');
}

// --- Admin moves it to a staff-only category. ---
{
  const editPage = await fetch(`${base}/documents/${docId}/edit`, { headers: { Cookie: adminCookie } });
  const csrf = await csrfFrom(editPage);
  const res = await fetch(`${base}/documents/${docId}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ title: 'Escalation Doc', category_id: String(staffCategory.id), _csrf: csrf })
  });
  assert.equal(res.status, 302, 'the admin must be able to move the category normally');
  assert.equal(db.prepare('SELECT category_id FROM documents WHERE id = ?').get(docId).category_id, staffCategory.id);
}

// --- After: the original uploader (leader) must be cut off everywhere. ---
{
  const list = await fetch(`${base}/documents`, { headers: { Cookie: leaderCookie } });
  assert.equal((await list.text()).includes('Escalation Doc'), false,
    'CODEX FINDING CONFIRMED FIXED: the document must disappear from the original uploader\'s list once moved to staff-only');

  const detail = await fetch(`${base}/documents/${docId}`, { headers: { Cookie: leaderCookie } });
  assert.equal(detail.status, 404, 'CODEX FINDING CONFIRMED FIXED: the detail view must be cut off for the original uploader');

  const file = await fetch(`${base}/documents/${docId}/file`, { headers: { Cookie: leaderCookie } });
  assert.equal(file.status, 404, 'CODEX FINDING CONFIRMED FIXED: file delivery must be cut off for the original uploader');

  const editPage = await fetch(`${base}/documents/${docId}/edit`, { headers: { Cookie: leaderCookie } });
  assert.equal(editPage.status, 404, 'the edit form must be cut off for the original uploader');

  // Direct POST to the edit route, bypassing the GET form entirely - this is
  // exactly the gap that existed even after the GET routes were fixed. Uses
  // a genuinely valid CSRF token (from a page the leader can still reach)
  // so this actually exercises the new authorization check, not the
  // separate, pre-existing CSRF layer.
  const csrfPage = await fetch(`${base}/account/password`, { headers: { Cookie: leaderCookie } });
  const validCsrf = await csrfFrom(csrfPage);
  assert.ok(validCsrf, 'sanity: must obtain a genuinely valid CSRF token for this check to be meaningful');
  const directEdit = await fetch(`${base}/documents/${docId}`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: leaderCookie },
    body: new URLSearchParams({ title: 'Tampered by former uploader', category_id: String(staffCategory.id), _csrf: validCsrf || '' })
  });
  assert.equal(directEdit.status, 404,
    'CODEX FINDING CONFIRMED FIXED: a direct POST to the edit route must be cut off for the original uploader, not just the GET form');
  assert.equal(db.prepare('SELECT title FROM documents WHERE id = ?').get(docId).title, 'Escalation Doc',
    'the document must be genuinely unchanged, not just have returned an error page');

  console.log('PASS: the original uploader is cut off from list, detail, file delivery, and both the GET and POST edit routes once the document moves to a staff-only category');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
