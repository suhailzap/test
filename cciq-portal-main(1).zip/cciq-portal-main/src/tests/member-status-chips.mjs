import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The member lifecycle status "Inactive" is a restrained pale rose, no longer the gold family that Bonafide uses.
 *   - applied wherever a MEMBER's status is shown with the shared pill (Members list chips, rows, cards, profile, quick view, search, cell group and family group lists);
 *   - readable (contrast >= 4.5:1) and clearly apart from Bonafide in hue, at desktop and phone width;
 *   - nothing else moved: Active, Pending, Archived and Bonafide keep their colours, and the other "inactive" chips (a draft activity, a closed backup, a review that is no
 *     longer open) keep the amber they had, because only the member status carries the .pill--member marker;
 *   - no status semantics or counts changed.
 */

const f = await buildPortalFixture('cciq-status-chips-');
const { db, ids, users, mods } = f;
const make = (first, status) => mods.members.createMember({ first_name: first, last_name: 'Chip', phone: null }, { status }).id;
const pendinga = make('Pendinga', 'pending'); const inactive = make('Inactiva', 'inactive'); const bonafide = make('Bonafida', 'bonafide'); const attendee = make('Attendea', 'attendee'); const archived = make('Archiva', 'archived');
mods.groups.assignMemberToGroup(inactive, ids.groupA, {});
mods.family.addMemberToFamilyGroup(ids.family, inactive);
mods.activities.createActivity({ scope: 'church', title: 'A draft event', status: 'draft' }, { userId: users.churchAdmin.id });

const rgb = (s) => s.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number);
const lum = ([r, g, b]) => { const c = [r, g, b].map((v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const contrast = (a, b) => { const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x); return (hi + 0.05) / (lo + 0.05); };
const hue = ([r, g, b]) => { const max = Math.max(r, g, b); const min = Math.min(r, g, b); if (max === min) return 0; const d = max - min; const h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4; return (h * 60 + 360) % 360; };

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const church = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const cookies = church.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const styleOf = async (page, selector) => page.evaluate((sel) => { const el = document.querySelector(sel); if (!el) return null; const s = getComputedStyle(el); return { bg: s.backgroundColor, color: s.color, border: s.borderTopColor, text: el.textContent.trim().replace(/\s+/g, ' ') }; }, selector);
  const sizes = [{ width: 1280, height: 900, label: 'desktop' }, { width: 375, height: 800, label: 'phone' }];
  for (const { width, height, label } of sizes) {
    const context = await browser.newContext({ viewport: { width, height } }); await context.addCookies(cookies);
    const page = await context.newPage();
    await page.goto(`${portal.base}/members?status=all`, { waitUntil: 'load' });
    // the summary chips above the list (visible at both widths) and the row / card pill
    const chip = await styleOf(page, 'ul .pill--member.pill--inactive');
    assert.ok(chip, `${label}: an Inactive chip exists`); assert.match(chip.text, /^Inactive\s*\d+$/, `${label}: the chip keeps its wording and count`);
    const inactiveRow = await page.evaluate(() => [...document.querySelectorAll('.pill--member.pill--inactive')].map((e) => e.textContent.trim().replace(/\s+/g, ' ')));
    assert.ok(inactiveRow.some((t) => t === 'Inactive'), `${label}: Inactive appears on a member row/card`);
    const bg = rgb(chip.bg); const fg = rgb(chip.color); const edge = rgb(chip.border);
    assert.ok(contrast(fg, bg) >= 4.5, `${label}: Inactive text contrast ${contrast(fg, bg).toFixed(2)} >= 4.5`);
    assert.ok(bg[0] > bg[1] + 8 && bg[0] > bg[2] + 8 && bg[0] >= 240, `${label}: a pale rose background (${chip.bg})`);
    assert.ok(fg[0] > fg[1] + 40 && fg[0] > fg[2] + 40, `${label}: a rose-red word (${chip.color})`);
    const bona = await styleOf(page, '.pill--bonafide');
    assert.ok(bona, `${label}: Bonafide is shown`);
    const bh = hue(rgb(bona.bg)); const ih = hue(bg);
    assert.ok(bh > 30 && bh < 70, `${label}: Bonafide stays gold (hue ${bh.toFixed(0)})`); assert.ok(ih < 15 || ih > 340, `${label}: Inactive is red-ish (hue ${ih.toFixed(0)}), not gold`);
    assert.notEqual(chip.bg, bona.bg); assert.notEqual(chip.border, bona.border);
    // nothing else moved
    for (const status of ['active', 'pending', 'archived']) { const other = await styleOf(page, `ul .pill--member.pill--${status}`); assert.ok(other, `${label}: a ${status} chip exists`); assert.notEqual(other.bg, chip.bg, `${label}: ${status} is not the rose`); }
    assert.equal((await styleOf(page, 'ul .pill--member.pill--archived')).bg, 'rgb(238, 241, 245)', `${label}: Archived unchanged`);
    assert.equal(bona.bg, 'rgb(244, 235, 207)', `${label}: Bonafide unchanged`);
    // the status filter, the counts and the semantics are untouched
    const counts = await page.evaluate(() => [...document.querySelectorAll('ul .pill--member')].map((e) => e.textContent.trim().replace(/\s+/g, ' ')));
    assert.ok(counts.some((t) => /^Active \d+$/.test(t)) && counts.some((t) => /^Bonafide \d+$/.test(t)) && counts.some((t) => /^Inactive \d+$/.test(t)), `${label}: chip counts present: ${counts.join(' | ')}`);
    // the other places the same member status appears
    for (const [name, url] of [['profile', `/members/${inactive}`], ['search', '/search?q=Inactiva'], ['cell group list', `/cell-groups/${ids.groupA}?tab=members`], ['family group', `/family-groups/${ids.family}`]]) {
      await page.goto(portal.base + url, { waitUntil: 'load' });
      const s = await styleOf(page, '.pill--member.pill--inactive'); assert.ok(s, `${label}: ${name} shows the rose Inactive pill`); assert.equal(s.bg, chip.bg, `${label}: ${name} uses the same colour`);
    }
    // another "inactive" chip keeps its amber: a draft activity (not a member status)
    await page.goto(`${portal.base}/activities/all`, { waitUntil: 'load' });
    const draft = await page.evaluate(() => { const el = [...document.querySelectorAll('.pill--inactive')].find((e) => !e.classList.contains('pill--member')); return el ? getComputedStyle(el).backgroundColor : null; });
    if (draft) assert.equal(draft, 'rgb(251, 241, 217)', `${label}: a draft activity keeps its amber`);
    await context.close();
  }
  // the markup: every member-status pill carries the shared marker, no page hard-codes a colour
  const members = await (await church.get('/members?status=all')).text();
  assert.ok(!/style="[^"]*(background|color)[^"]*"[^>]*pill--inactive/.test(members), 'no inline colour');
  assert.equal((members.match(/pill--member pill--(archived|active|inactive|pending|bonafide|attendee)/g) || []).length > 5, true);
  console.log('PASS (inactive chip) member Inactive is a pale rose (contrast >= 4.5:1), apart from Bonafide gold, on the Members list, profile, search, cell group and family group, desktop and phone; other statuses and other "inactive" chips unchanged');
  console.log('PASS member-status-chips');
} finally {
  await browser.close();
  await portal.stop();
}
