import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Every growing list that was brought onto the shared pager is exercised at the boundaries that break pagers:
 * 0, 1, 24, 25, 26, 50, 51, 100 and 101 rows, at 25 / 50 / 100 per page - first, middle, last and out-of-range pages,
 * a filter that shrinks the result, an empty result, the query state carried by links, a stable order when the sort key
 * ties (no row repeated, none skipped), and the permission check. Isolated database, isolated server.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-paging-boundaries-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser } = await import('../services/users.js');
const { createMember } = await import('../services/members.js');
const { createFamilyGroup } = await import('../services/family-groups.js');
const { createVisitor } = await import('../services/visitors.js');
const { today, addDays } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Pb${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'pb_admin', email: 'pb.admin@fixture.invalid', password: PASSWORD, displayName: 'PB Admin', roleKeys: ['super_admin'], mustChangePassword: false });
await createUser({ username: 'pb_member', email: 'pb.member@fixture.invalid', password: PASSWORD, displayName: 'PB Member', roleKeys: ['member'], mustChangePassword: false });
const adminId = db.prepare("SELECT id FROM users WHERE username = 'pb_admin'").get().id;

const pad = (n) => String(n).padStart(4, '0');
const nowIso = () => new Date().toISOString();

/** One entry per list: how to add row n, how to ask for it, how to recognise it on the page. */
const screens = [
  {
    name: 'members', path: '/members', token: /Pgm\d{4}/g, search: 'q', filterTerm: 'Pgm001', tieSort: 'sort=status',
    base: 'q=Pgm', add: (n) => createMember({ first_name: `Pgm${pad(n)}`, last_name: 'Zlist' }, { status: 'active' })
  },
  {
    name: 'family groups', path: '/family-groups', token: /Pgf\d{4}/g, search: 'q', filterTerm: 'Pgf001', tieSort: 'sort=members',
    base: 'q=Pgf', add: (n) => createFamilyGroup({ name: `Pgf${pad(n)} Family` })
  },
  {
    name: 'first timers', path: '/visitors', token: /Pgv\d{4}/g, search: 'q', filterTerm: 'Pgv001', tieSort: 'sort=status',
    base: 'q=Pgv', add: (n) => createVisitor({ first_name: `Pgv${pad(n)}`, last_name: 'Visitor', first_visit_date: today() })
  },
  {
    name: 'first timers to follow up', path: '/visitors/follow-up', token: /Pgw\d{4}/g, search: null, tieSort: 'fsort=name&fdir=asc',
    base: '', add: (n) => createVisitor({ first_name: `Pgw${pad(n)}`, last_name: 'Lapsed', first_visit_date: addDays(today(), -60) })
  },
  {
    name: 'announcements', path: '/announcements', token: /Pga\d{4}/g, search: 'q', filterTerm: 'Pga001', tieSort: null,
    base: 'q=Pga', add: (n) => db.prepare("INSERT INTO announcements (title, body, priority, audience, status, created_at, updated_at) VALUES (?, 'body', 'normal', 'all', 'draft', ?, ?)").run(`Pga${pad(n)}`, '2026-01-01T00:00:00.000Z', '2026-01-01T00:00:00.000Z')
  },
  {
    name: 'reminders', path: '/reminders', token: /Pgr\d{4}/g, search: 'q', filterTerm: 'Pgr001', tieSort: 'sort=state',
    base: 'state=all&q=Pgr', add: (n) => db.prepare("INSERT INTO reminders (reminder_type, member_id, title, state, dedupe_key, created_at, updated_at) VALUES ('birthday', NULL, ?, 'new', ?, ?, ?)").run(`Pgr${pad(n)} reminder`, `pg-reminder-${n}`, '2026-01-01T00:00:00.000Z', '2026-01-01T00:00:00.000Z')
  },
  {
    name: 'audit log', path: '/admin/audit', token: /Pgl\d{4}/g, search: null, tieSort: 'sort=result&direction=asc',
    base: 'action=pg.test', add: (n) => db.prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, result, detail, created_at) VALUES (?, 'pg.test', 'pg', ?, 'success', ?, '2026-01-01T00:00:00.000Z')").run(adminId, String(n), `Pgl${pad(n)}`)
  },
  {
    name: 'attendance history', path: '/attendance/history', token: /Pgs\d{4}/g, search: null, tieSort: 'sort=status',
    base: 'type=special_service', add: (n) => db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'special_service', ?, 'held', 0, 0, ?)").run(addDays('2026-01-01', -n), `Pgs${pad(n)} session`, '2026-01-01T00:00:00.000Z')
  },
  {
    name: 'notifications', path: '/notifications', token: /Pgn\d{4}/g, search: null, tieSort: null,
    base: '', add: (n) => db.prepare("INSERT INTO notifications (user_id, title, created_at) VALUES (?, ?, ?)").run(adminId, `Pgn${pad(n)} note`, '2026-01-01T00:00:00.000Z')
  },
  {
    name: 'birthdays', path: '/members/birthdays', token: /Pgb\d{4}/g, search: null, tieSort: null,
    base: 'days=365', add: (n) => {
      const d = new Date(`${today()}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + 1 + (n % 60));
      return createMember({ first_name: `Pgb${pad(n)}`, last_name: 'Born', date_of_birth: `1990-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}` }, { status: 'active' });
    }
  }
];

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  async function sessionFor(email) {
    const page = await fetch(`${base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = cookieOf(page, '');
    const login = await fetch(`${base}/login`, {
      method: 'POST', redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
      body: new URLSearchParams({ email, password: PASSWORD, _csrf: csrf })
    });
    return cookieOf(login, pre);
  }
  const admin = await sessionFor('pb.admin@fixture.invalid');
  const member = await sessionFor('pb.member@fixture.invalid');
  // The server rate-limits each address (300 requests a minute) - honour it rather than weaken it.
  const get = async (url, cookie = admin) => {
    for (;;) {
      const res = await fetch(`${base}${url}`, { headers: { Cookie: cookie }, redirect: 'manual' });
      if (res.status !== 429) return res;
      await res.text();
      await new Promise((resolve) => setTimeout(resolve, (Number(res.headers.get('retry-after')) || 5) * 1000 + 250));
    }
  };
  const html = async (url) => { const r = await get(url); assert.equal(r.status, 200, url); return r.text(); };
  const distinct = (markup, token) => new Set(markup.match(token) || []);
  const showing = (markup) => {
    const m = markup.match(/Showing (\d+)&ndash;(\d+) of (\d+)/);
    return m ? { from: Number(m[1]), to: Number(m[2]), total: Number(m[3]) } : null;
  };
  const url = (screen, extra = '') => `${screen.path}?${[screen.base, extra].filter(Boolean).join('&')}`;
  const LADDER = [0, 1, 24, 25, 26, 50, 51, 100, 101];

  for (const screen of screens) {
    let have = 0;
    const items = [];
    for (const total of LADDER) {
      while (have < total) { have += 1; screen.add(have); items.push(`Pg${screen.token.source[2]}${pad(have)}`); }
      // The page size only changes behaviour once there is more than one page to cut differently.
      for (const size of (total >= 51 ? [25, 50, 100] : [25])) {
        const pages = Math.max(Math.ceil(total / size), 1);
        const sizeQuery = size === 25 ? '' : `page_size=${size}`;
        // First page.
        let markup = await html(url(screen, sizeQuery));
        const first = distinct(markup, screen.token);
        assert.equal(first.size, Math.min(total, size), `${screen.name}: ${total} rows, ${size}/page, first page`);
        if (total === 0) {
          assert.equal(showing(markup), null, `${screen.name}: an empty list shows no pager`);
          continue;
        }
        assert.deepEqual(showing(markup), { from: 1, to: Math.min(total, size), total }, `${screen.name}: pager text, first page (${total}/${size})`);
        // Last page and an out-of-range page (clamped to the last, never an empty page).
        for (const requested of [pages, pages + 7]) {
          markup = await html(url(screen, [sizeQuery, `page=${requested}`].filter(Boolean).join('&')));
          const expectedRows = total - (pages - 1) * size;
          assert.equal(distinct(markup, screen.token).size, expectedRows, `${screen.name}: ${total} rows, ${size}/page, page ${requested} -> last page rows`);
          assert.equal(showing(markup).to, total);
        }
        // A middle page.
        if (pages >= 3) {
          markup = await html(url(screen, [sizeQuery, 'page=2'].filter(Boolean).join('&')));
          assert.equal(distinct(markup, screen.token).size, size, `${screen.name}: middle page is full`);
        }
      }
    }
    // The links carry the query state.
    let markup = await html(url(screen, 'page_size=25&page=2'));
    const links = [...markup.matchAll(/class="[^"]*"[^>]*href="([^"]*page=\d[^"]*)"/g)].map((m) => m[1].replaceAll('&amp;', '&'));
    assert.ok(links.length > 0, `${screen.name}: paging links exist at 101 rows`);
    markup = await html(url(screen, 'page_size=50'));
    const next = markup.match(/href="([^"]*)" rel="next"/)[1].replaceAll('&amp;', '&');
    assert.match(next, /page=2/, `${screen.name}: Next goes to page 2`);
    assert.match(next, /page_size=50/, `${screen.name}: Next keeps the page size`);
    for (const part of screen.base.split('&').filter(Boolean)) assert.ok(next.includes(part), `${screen.name}: Next keeps ${part}`);
    assert.match(markup, /<option value="50" selected>/, `${screen.name}: the size selector shows the chosen size`);
    assert.match(markup, /rel="prev"|aria-label="First page"|<a class="pager__number"/, `${screen.name}: numbered navigation is present`);
    // Total order: sorting by a key that ties never repeats or skips a row across pages.
    if (screen.tieSort) {
      const seen = [];
      for (let page = 1; page <= 5; page += 1) {
        const pageMarkup = await html(url(screen, `${screen.tieSort}&page=${page}`));
        seen.push(...distinct(pageMarkup, screen.token));
      }
      assert.equal(seen.length, 101, `${screen.name}: five pages at 25 cover 101 rows`);
      assert.equal(new Set(seen).size, 101, `${screen.name}: no row repeated and none skipped when the sort key ties`);
    }
    // A filter that shrinks the result shrinks the page count; nothing matching is an empty state.
    if (screen.search) {
      const term = screen.filterTerm;
      const expected = items.filter((name) => name.includes(term)).length;
      markup = await html(`${screen.path}?${screen.search}=${term}&page=3`);
      assert.equal(showing(markup).total, expected, `${screen.name}: filter "${term}" matches ${expected}`);
      assert.equal(distinct(markup, screen.token).size, expected, `${screen.name}: a stale page number after filtering falls back to the last page`);
      markup = await html(`${screen.path}?${screen.search}=Zzznomatch`);
      assert.equal(distinct(markup, screen.token).size, 0, `${screen.name}: nothing matches`);
      assert.equal(showing(markup), null, `${screen.name}: an empty result shows no pager`);
    }
    // Permission: a plain member is refused every admin list.
    if (!['notifications', 'members', 'birthdays', 'announcements', 'family groups', 'first timers', 'first timers to follow up', 'reminders', 'attendance history', 'audit log'].includes(screen.name)) continue;
    const denied = await get(screen.path, member);
    if (['notifications', 'announcements'].includes(screen.name)) assert.equal(denied.status, 200, `${screen.name} is open to members (their own view)`);
    else assert.equal(denied.status, 403, `${screen.name}: a member is refused`);
    console.log(`PASS (${screen.name}) 0/1/24/25/26/50/51/100/101 rows at 25/50/100 per page, out-of-range pages, stale page after filtering, empty state, query state, stable order, permissions`);
  }
  // Unknown sizes fall back to the default rather than an arbitrary number.
  const odd = await html('/members?q=Pgm&page_size=9999');
  assert.deepEqual(showing(odd), { from: 1, to: 25, total: 101 });
  const bad = await html('/members?q=Pgm&page=abc');
  assert.equal(showing(bad).from, 1);
  // The portal-wide search is a short "best matches" page: when a group is full it says so and links to the paged list.
  const found = await html('/search?q=Pgm');
  assert.match(found, /Showing the first 8\./);
  assert.match(found, /href="\/members\?q=Pgm&amp;status=all">See every matching member</);
  assert.equal(distinct(found, /Pgm\d{4}/g).size, 8, 'the search page itself stays bounded at 8 per group');
  console.log('PASS (global search) a full result group is capped at 8, says so, and links to the paged member list');
  console.log('PASS (hostile paging values) an unknown page size or a non-numeric page falls back to the defaults');
} finally {
  await terminateAndWait(server);
}
db.close();
console.log('ALL PASS');
