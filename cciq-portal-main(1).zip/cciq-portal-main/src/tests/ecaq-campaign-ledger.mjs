import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * ECAQ campaign phase: the payment ledger is the only source of "Received".
 *   1. A typed collected figure on a Giving Board claim is ignored: Received is always the sum of the payments.
 *   2. A payment has a payment date (entered, never in the future, may be in the past) and a recorded-at / recorded-by that the system sets and a request cannot forge.
 *   3. A correction or a removal needs a reason; the audit row keeps the payment as it was and as it became; who recorded it and when never change.
 *   4. The campaign ledger report reconciles to the ledger, filters by payment date, keeps the two campaigns apart, is search/sort/page-able and prints every row.
 *   5. Only people with the finance permission reach the report, the CSV and the corrections; the CSV neutralises formulas and is audited.
 */

const f = await buildPortalFixture('cciq-ecaq-ledger-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const year = Number(today.slice(0, 4));
const addDays = mods.dates.addDays;
const one = (sql, ...p) => db.prepare(sql).get(...p);
const count = (sql, ...p) => one(sql, ...p).n;
const claimRow = (id = ids.claim) => one('SELECT * FROM ecaq_giving_board_claims WHERE id = ?', id);
const commitmentRow = (id = ids.commitment) => one('SELECT * FROM ecaq_faith_promise_commitments WHERE id = ?', id);
const lastAudit = (action) => one('SELECT * FROM audit_logs WHERE action = ? ORDER BY id DESC LIMIT 1', action);
const auditCount = () => count('SELECT COUNT(*) n FROM audit_logs');

const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const token = await admin.csrf('/account/password');
  const leaderToken = await leader.csrf('/account/password');
  const memberToken = await member.csrf('/account/password');
  const post = async (client, csrf, url, fields) => { const res = await client.post(url, fields, { csrf }); await res.text(); return res; };
  const get = async (client, url) => { const res = await client.get(url); res.bodyText = await res.text(); return res; };

  // ---- 1. Received is only ever the ledger ------------------------------------------------------------------------------------------------------------
  {
    const res = await post(admin, token, `/admin/ecaq/claims/${ids.claim}`, { commitment_amount: '100', amount_collected: '9999', payment_status: 'paid', notes: '' });
    assert.equal(res.status, 302);
    assert.equal(claimRow().amount_collected, 0, 'a typed collected figure is ignored: nothing was paid');
    assert.equal(claimRow().payment_status, 'not_paid', 'the status follows the (empty) ledger, not the typed status');
    const page = await get(admin, `/admin/ecaq?campaign=${ids.board}`);
    assert.ok(!/name="amount_collected"/.test(page.bodyText), 'the administration page has no collected field to type into');

    await post(admin, token, `/admin/ecaq/claims/${ids.claim}/payments`, { amount: '40', paid_on: today, method: 'cash' });
    await post(admin, token, `/admin/ecaq/claims/${ids.claim}`, { commitment_amount: '100', amount_collected: '0', payment_status: 'not_paid', notes: 'checked' });
    assert.equal(claimRow().amount_collected, 40, 'saving the commitment again does not erase what the payments add up to');
    assert.equal(claimRow().payment_status, 'partially_paid');
    await post(admin, token, `/admin/ecaq/claims/${ids.claim}`, { commitment_amount: '40', payment_status: 'not_paid' });
    assert.equal(claimRow().amount_collected, 40);
    assert.equal(claimRow().payment_status, 'paid', 'a commitment lowered to what was paid is Paid');
    await post(admin, token, `/admin/ecaq/claims/${ids.claim}`, { commitment_amount: '100', payment_status: 'partially_paid' });
  }

  // ---- 2. payment date vs recorded at / by -----------------------------------------------------------------------------------------------------------
  {
    const past = addDays(today, -45);
    const before = count('SELECT COUNT(*) n FROM ecaq_payments WHERE claim_id = ?', ids.claim);
    const res = await post(admin, token, `/admin/ecaq/claims/${ids.claim}/payments`, {
      amount: '10', paid_on: past, method: 'bank_transfer', reference: 'TT-1', created_at: '2001-01-01T00:00:00.000Z', created_by: String(users.leaderA.id), recorded_by: String(users.leaderA.id)
    });
    assert.equal(res.status, 302);
    const row = one('SELECT * FROM ecaq_payments WHERE claim_id = ? ORDER BY id DESC LIMIT 1', ids.claim);
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_payments WHERE claim_id = ?', ids.claim), before + 1);
    assert.equal(row.paid_on, past, 'the payment date is the date entered, in the past');
    assert.notEqual(row.created_at.slice(0, 10), past, 'recorded-at is not the payment date');
    assert.ok(row.created_at.startsWith(new Date().toISOString().slice(0, 4)), 'recorded-at is set by the system now');
    assert.equal(row.created_by, users.superAdmin.id, 'recorded-by is the signed-in user; a posted value is ignored');
    const page = await get(admin, `/admin/ecaq/claims/${ids.claim}`);
    assert.ok(page.bodyText.includes('Recorded in the portal') && page.bodyText.includes('Payment date'), 'the payment table shows both dates');

    const future = addDays(today, 3);
    const n = count('SELECT COUNT(*) n FROM ecaq_payments');
    await post(admin, token, `/admin/ecaq/claims/${ids.claim}/payments`, { amount: '10', paid_on: future, method: 'cash' });
    await post(admin, token, `/admin/ecaq/claims/${ids.claim}/payments`, { amount: '10', paid_on: '', method: 'cash' });
    await post(admin, token, `/admin/ecaq/faith-promise/commitments/${ids.commitment}/payments`, { received_by: 'Fixture Receiver', amount: '10', paid_on: future, method: 'cash' });
    await post(admin, token, `/admin/ecaq/faith-promise/commitments/${ids.commitment}/payments`, { received_by: 'Fixture Receiver', amount: '10', paid_on: '', method: 'cash' });
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_payments'), n, 'a future or missing payment date records nothing (Giving Board)');
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments'), 0, 'a future or missing payment date records nothing (Faith Promise)');

    // a historical Faith Promise payment goes to ITS commitment, with its real date
    const fp = await post(admin, token, `/admin/ecaq/faith-promise/commitments/${ids.commitment}/payments`, { received_by: 'Fixture Receiver', amount: '100', paid_on: addDays(today, -60), method: 'cash', created_by: String(users.leaderA.id) });
    assert.equal(fp.status, 302);
    const fpRow = one('SELECT * FROM ecaq_faith_promise_payments WHERE commitment_id = ?', ids.commitment);
    assert.equal(fpRow.paid_on, addDays(today, -60));
    assert.equal(fpRow.created_by, users.superAdmin.id);
    assert.equal(commitmentRow().amount_collected, 100);
    assert.equal(lastAudit('ecaq.faith_promise_payment_recorded').entity_id, String(ids.commitment));
  }

  // ---- 3. reasoned, audited, atomic corrections -------------------------------------------------------------------------------------------------------
  {
    const pay = one('SELECT * FROM ecaq_payments WHERE claim_id = ? ORDER BY id DESC LIMIT 1', ids.claim);
    const auditsBefore = auditCount();
    const noReason = await post(admin, token, `/admin/ecaq/payments/${pay.id}`, { amount: '12', paid_on: pay.paid_on, method: 'cash', reason: '' });
    assert.equal(noReason.status, 302);
    assert.equal(one('SELECT amount FROM ecaq_payments WHERE id = ?', pay.id).amount, pay.amount, 'a correction without a reason changes nothing');
    assert.equal(auditCount(), auditsBefore, 'and writes no audit row');

    const corrected = await post(admin, token, `/admin/ecaq/payments/${pay.id}`, { amount: '12.50', paid_on: addDays(today, -44), method: 'cash', reference: 'TT-1b', reason: 'Wrong day and amount keyed in', created_at: '2001-01-01', created_by: '99' });
    assert.equal(corrected.status, 302);
    const after = one('SELECT * FROM ecaq_payments WHERE id = ?', pay.id);
    assert.equal(after.amount, 12.5);
    assert.equal(after.paid_on, addDays(today, -44));
    assert.equal(after.created_at, pay.created_at, 'recorded-at never changes');
    assert.equal(after.created_by, pay.created_by, 'recorded-by never changes');
    assert.equal(after.updated_by, users.superAdmin.id);
    const total = one('SELECT ROUND(SUM(amount), 2) s FROM ecaq_payments WHERE claim_id = ?', ids.claim).s;
    assert.equal(claimRow().amount_collected, total, 'the commitment total follows the corrected payment');
    const audit = JSON.parse(lastAudit('giving.payment_corrected').detail);
    assert.equal(audit.reason, 'Wrong day and amount keyed in');
    assert.equal(audit.before.amount, pay.amount);
    assert.equal(audit.after.amount, 12.5);
    assert.equal(audit.before.paid_on, pay.paid_on);
    assert.equal(audit.after.paid_on, addDays(today, -44));

    const futureFix = await post(admin, token, `/admin/ecaq/payments/${pay.id}`, { amount: '12.50', paid_on: addDays(today, 5), method: 'cash', reason: 'x' });
    assert.equal(futureFix.status, 302);
    assert.equal(one('SELECT paid_on FROM ecaq_payments WHERE id = ?', pay.id).paid_on, addDays(today, -44), 'a correction cannot move a payment into the future');

    // removal needs a reason; the audit row keeps the whole payment
    const total1 = claimRow().amount_collected;
    await post(admin, token, `/admin/ecaq/payments/${pay.id}/delete`, { reason: '' });
    assert.ok(one('SELECT id FROM ecaq_payments WHERE id = ?', pay.id), 'no reason, no removal');
    await post(admin, token, `/admin/ecaq/payments/${pay.id}/delete`, { reason: 'Recorded twice by mistake' });
    assert.equal(one('SELECT id FROM ecaq_payments WHERE id = ?', pay.id), undefined);
    assert.equal(claimRow().amount_collected, Math.round((total1 - 12.5) * 100) / 100);
    const removed = JSON.parse(lastAudit('giving.payment_removed').detail);
    assert.equal(removed.reason, 'Recorded twice by mistake');
    assert.equal(removed.removed.amount, 12.5);
    assert.equal(removed.removed.recorded_by, users.superAdmin.id);

    // Faith Promise: the same
    const fpPay = one('SELECT * FROM ecaq_faith_promise_payments WHERE commitment_id = ?', ids.commitment);
    await post(admin, token, `/admin/ecaq/faith-promise/payments/${fpPay.id}`, { amount: '150', paid_on: fpPay.paid_on, method: 'cash', reason: '' });
    assert.equal(one('SELECT amount FROM ecaq_faith_promise_payments WHERE id = ?', fpPay.id).amount, 100, 'Faith Promise: no reason, no change');
    await post(admin, token, `/admin/ecaq/faith-promise/payments/${fpPay.id}`, { amount: '150', paid_on: addDays(today, -58), method: 'cash', reason: 'Member gave 150 on the 58th day back' });
    const fpAfter = one('SELECT * FROM ecaq_faith_promise_payments WHERE id = ?', fpPay.id);
    assert.equal(fpAfter.amount, 150);
    assert.equal(fpAfter.created_at, fpPay.created_at);
    assert.equal(fpAfter.created_by, fpPay.created_by);
    assert.equal(commitmentRow().amount_collected, 150);
    const fpAudit = JSON.parse(lastAudit('ecaq.faith_promise_payment_corrected').detail);
    assert.equal(fpAudit.reason, 'Member gave 150 on the 58th day back');
    assert.equal(fpAudit.before.amount, 100);
    assert.equal(fpAudit.after.amount, 150);
    await post(admin, token, `/admin/ecaq/faith-promise/payments/${fpPay.id}/delete`, { reason: '' });
    assert.ok(one('SELECT id FROM ecaq_faith_promise_payments WHERE id = ?', fpPay.id), 'Faith Promise: no reason, no removal');
    // put it back for the report below
  }

  // ---- 4. the ledger report ---------------------------------------------------------------------------------------------------------------------------
  // Fixture: board = one member (fixture) with dates; promise = one. Add 29 more Faith Promise members and a few Giving Board dates.
  const names = ['=HYPERLINK("http://x","click")', '+Plus', '-Minus', '@At'];
  const created = [];
  for (let i = 0; i < 29; i += 1) {
    const last = `Ledgerlast${String(i).padStart(2, '0')}`;
    const first = i < names.length ? names[i] : `Fp${String(i).padStart(2, '0')}`; // a name that BEGINS with a formula character
    const m = mods.members.createMember({ first_name: first, last_name: last }, { status: 'active' });
    const c = mods.faith.submitCommitment(ids.promise, { member_id: m.id, name: `Fp${i} ${last}`, amount: 10 + i, frequency: 'monthly' }, { userId: users.churchAdmin.id });
    assert.ok(c.ok, 'fixture commitment');
    created.push({ member: m, commitment: c.commitment });
  }
  const dates = mods.ecaq.boardDates(year);
  const boardMember = mods.members.createMember({ first_name: 'Beth', last_name: 'Boardmember' }, { status: 'active' });
  const claim2 = mods.ecaq.createClaim({ campaignId: ids.board, date: dates[5], memberId: boardMember.id, userId: users.churchAdmin.id });
  assert.ok(claim2.ok);
  mods.ecaq.updateClaimFinance(claim2.claim.id, { commitmentAmount: 200, paymentStatus: 'not_paid', notes: null, userId: users.churchAdmin.id });
  mods.ecaq.addPayment(claim2.claim.id, { amount: 75, paid_on: addDays(today, -10), method: 'cash' }, { userId: users.churchAdmin.id });
  mods.faith.addPayment(created[5].commitment.id, { received_by: 'Fixture Receiver', amount: 33, paid_on: addDays(today, -20), method: 'cash' }, { userId: users.churchAdmin.id });
  mods.faith.addPayment(created[6].commitment.id, { received_by: 'Fixture Receiver', amount: 20, paid_on: addDays(today, -5), method: 'cash' }, { userId: users.churchAdmin.id });

  const boardSum = one('SELECT ROUND(COALESCE(SUM(p.amount), 0), 2) s FROM ecaq_payments p JOIN ecaq_giving_board_claims k ON k.id = p.claim_id WHERE k.campaign_id = ?', ids.board).s;
  const promiseSum = one('SELECT ROUND(COALESCE(SUM(p.amount), 0), 2) s FROM ecaq_faith_promise_payments p JOIN ecaq_faith_promise_commitments c ON c.id = p.commitment_id WHERE c.campaign_id = ?', ids.promise).s;
  const promiseCommitted = one('SELECT ROUND(SUM(expected_total), 2) s FROM ecaq_faith_promise_commitments WHERE campaign_id = ?', ids.promise).s;

  {
    const report = mods.ledger?.campaignLedger ?? (await import(new URL('../services/campaign-ledger.js', import.meta.url))).campaignLedger;
    const board = report(mods.ecaq.getCampaign(ids.board));
    const promise = report(mods.ecaq.getCampaign(ids.promise));
    assert.equal(board.headline.received, boardSum, 'Giving Board received equals the sum of ITS payments');
    assert.equal(promise.headline.received, promiseSum, 'Faith Promise received equals the sum of ITS payments');
    assert.equal(promise.headline.committed, promiseCommitted);
    assert.equal(Math.round((promise.headline.committed - promise.headline.received) * 100) / 100, promise.headline.outstanding, 'outstanding is committed minus received when no commitment is over-paid');
    assert.equal(promise.members.reduce((s, r) => Math.round((s + r.received) * 100) / 100, 0), promiseSum, 'the member rows add up to the headline');
    assert.equal(promise.payments.reduce((s, p) => Math.round((s + p.amount) * 100) / 100, 0), promiseSum, 'the payment rows add up to the headline');
    assert.equal(board.members.length, 2);
    assert.ok(board.payments.every((p) => p.commitmentId !== undefined));
    // campaigns never leak into each other
    assert.ok(!promise.payments.some((p) => board.payments.some((b) => b.id === p.id && b.amount === p.amount && b.forDate)), 'no Giving Board payment appears in Faith Promise');
    // payment-date period
    const periodFrom = addDays(today, -25);
    const periodTo = addDays(today, -15);
    const inPeriod = report(mods.ecaq.getCampaign(ids.promise), { from: periodFrom, to: periodTo });
    assert.equal(inPeriod.headline.receivedInPeriod, 33, 'only the payment DATED in the period (the one recorded later for an earlier date counts where it belongs)');
    assert.equal(inPeriod.headline.received, promiseSum, 'received to date ignores the period');
    assert.equal(inPeriod.payments.length, 1);
    // an extra payment recorded now but dated in the past lands in the past period
    mods.faith.addPayment(created[7].commitment.id, { received_by: 'Fixture Receiver', amount: 5, paid_on: addDays(today, -20), method: 'cash' }, { userId: users.churchAdmin.id });
    assert.equal(report(mods.ecaq.getCampaign(ids.promise), { from: periodFrom, to: periodTo }).headline.receivedInPeriod, 38);
  }

  {
    const base = `/admin/ecaq/campaigns/${ids.promise}/ledger`;
    const page = await get(admin, base);
    assert.equal(page.status, 200);
    const text = page.bodyText;
    assert.ok(text.includes('Committed') && text.includes('Received to date') && text.includes('Outstanding'), 'the terminology is Committed / Received / Outstanding');
    assert.ok(/Showing 1&ndash;25 of 30/.test(text), 'members are paged 25 at a time (30 commitments)');
    assert.ok(/Faith Promise 20\d\d &mdash; ledger/.test(text) && !/Giving Board \d{4} &mdash; ledger/.test(text.replace(/<section class="print-only[\s\S]*$/, '')), 'the page names its own campaign');
    const printed = text.slice(text.indexOf('class="print-only attendance-print"'));
    assert.equal((printed.match(/<tr><td>\d+<\/td><td>/g) || []).length, 30 + (one('SELECT COUNT(*) n FROM ecaq_faith_promise_payments p JOIN ecaq_faith_promise_commitments c ON c.id = p.commitment_id WHERE c.campaign_id = ?', ids.promise).n), 'the print view lists EVERY member and payment, not one page');

    const second = await get(admin, `${base}?mpage=2`);
    assert.ok(/Showing 26&ndash;30 of 30/.test(second.bodyText), 'page two holds the rest');
    const searched = await get(admin, `${base}?q=Ledgerlast05`);
    assert.ok(/Showing 1&ndash;1 of 1/.test(searched.bodyText) && searched.bodyText.includes('Ledgerlast05'), 'search finds one member');
    const code = created[3].member.member_code;
    assert.ok((await get(admin, `${base}?q=${encodeURIComponent(code)}`)).bodyText.includes(code), 'search by Member ID');
    const sorted = await get(admin, `${base}?msort=received&mdir=desc`);
    const firstRow = /<tbody>\s*<tr>\s*<td data-label="Member">([^<]*)/.exec(sorted.bodyText)[1];
    assert.ok(firstRow.includes('Anna MemberA') || firstRow.includes('Fp'), 'sorted by received, largest first');
    assert.match(sorted.bodyText, /aria-sort="descending"/);
    const bad = await get(admin, `${base}?msort=__proto__&mdir=up&from=2026-13-45&to=nonsense&mpage=-4&msize=7`);
    assert.equal(bad.status, 200, 'junk parameters fall back to defaults');
    const range = await get(admin, `${base}?from=${addDays(today, -1)}&to=${addDays(today, -9)}`);
    assert.ok(range.bodyText.includes('is after the'), 'a backwards period is reported and not applied');
    const periodPage = await get(admin, `${base}?from=${addDays(today, -25)}&to=${addDays(today, -15)}`);
    assert.ok(periodPage.bodyText.includes('Received in the period') && periodPage.bodyText.includes('Payments dated'), 'a period shows the in-period figure and says so');

    // the Giving Board report and an unknown or custom campaign
    const board = await get(admin, `/admin/ecaq/campaigns/${ids.board}/ledger`);
    assert.equal(board.status, 200);
    assert.ok(board.bodyText.includes('Commitment date'), 'the Giving Board report shows the date each payment is for');
    assert.equal((await get(admin, '/admin/ecaq/campaigns/99999/ledger')).status, 404);
  }

  // ---- 5. permissions, CSV ----------------------------------------------------------------------------------------------------------------------------
  {
    const url = `/admin/ecaq/campaigns/${ids.promise}/ledger`;
    for (const [who, client] of [['leader', leader], ['member', member]]) {
      for (const path of [url, `${url}.csv`, `/admin/ecaq/campaigns/${ids.board}/ledger`]) {
        const res = await get(client, path);
        assert.ok([302, 403, 404].includes(res.status) && !/Received to date/.test(res.bodyText), `${who} cannot read ${path}`);
      }
    }
    const pay = one('SELECT * FROM ecaq_payments WHERE claim_id = ? ORDER BY id LIMIT 1', ids.claim);
    const auditsBefore = auditCount();
    for (const [client, csrf] of [[leader, leaderToken], [member, memberToken]]) {
      await post(client, csrf, `/admin/ecaq/payments/${pay.id}`, { amount: '1', paid_on: pay.paid_on, method: 'cash', reason: 'sneaky' });
      await post(client, csrf, `/admin/ecaq/payments/${pay.id}/delete`, { reason: 'sneaky' });
      await post(client, csrf, `/admin/ecaq/faith-promise/payments/1`, { amount: '1', paid_on: today, reason: 'sneaky' });
    }
    assert.equal(one('SELECT amount FROM ecaq_payments WHERE id = ?', pay.id).amount, pay.amount, 'unauthorised corrections change nothing');
    assert.ok(auditCount() >= auditsBefore);

    const before = auditCount();
    const csv = await get(admin, `${url}.csv?view=members`);
    assert.equal(csv.status, 200);
    assert.match(csv.headers.get('content-type'), /text\/csv/);
    assert.match(csv.headers.get('content-disposition'), /faith-promise-\d{4}-members\.csv/);
    const lines = csv.bodyText.trim().split('\r\n');
    assert.equal(lines.length, 31, 'a header and one row per member, whatever the screen page');
    assert.ok(lines.some((l) => l.includes('"\'=HYPERLINK')), 'a name starting with = is neutralised');
    assert.ok(!lines.some((l) => /(^|,)"[=+\-@]/.test(l)), 'no cell starts with a formula character');
    assert.equal(auditCount(), before + 1);
    assert.equal(JSON.parse(lastAudit('ecaq.ledger_exported').detail).view, 'members');
    const payments = await get(admin, `${url}.csv?view=payments`);
    assert.equal(payments.bodyText.trim().split('\r\n').length, 1 + count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments p JOIN ecaq_faith_promise_commitments c ON c.id = p.commitment_id WHERE c.campaign_id = ?', ids.promise));
  }

  // ---- FP administration headline is campaign-wide -----------------------------------------------------------------------------------------------------
  {
    const page = await get(admin, `/admin/ecaq/faith-promise?campaign=${ids.promise}&page_size=25`);
    assert.ok(page.bodyText.includes('in the whole campaign'));
    const committedText = mods.ecaq.formatMoney(promiseCommitted, 'QAR');
    assert.ok(page.bodyText.includes(committedText), 'the Committed card counts every member, not just the 25 on this page');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('PASS (received) a typed collected figure is ignored; Received is the ledger; backlog payments keep their payment date while recorded-at/by are the system\'s');
console.log('PASS (corrections) a reason is required to correct or remove a payment; the audit row keeps before/after/removed; recorded-at/by never change; future dates refused');
console.log('PASS (report) the ledger report reconciles to the ledger, filters by payment date, keeps campaigns apart, searches, sorts, pages and prints every row');
console.log('PASS (access) only the finance permission reaches the report, the CSV and the corrections; the CSV neutralises formulas and is audited');
console.log('ALL PASS');
