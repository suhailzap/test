import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as tar from 'tar';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness, R09 from the red-team review: restoreBackup() closed
 * the shared database connection, then performed a non-atomic, multi-step
 * storage-folder replacement *after* that close — a failure partway through
 * left the database already swapped but storage only partially replaced,
 * and the function's own failure-handling path (recordRestore() -> execute())
 * would itself throw against the already-closed connection, an unhandled
 * exception at the worst possible moment.
 *
 * Fixed with a shadow-and-swap-with-rollback cutover: every live file/folder
 * is renamed aside (never deleted) before its replacement is renamed into
 * place, storage is cut over before the database (so most failures can
 * still log through the still-open connection), and any failure anywhere in
 * the cutover rolls back everything already done, restoring the exact
 * original state. A database-cutover failure — the one case where the
 * shared connection is already closed — logs through a fresh, independent
 * connection instead, and returns processRestartRequired: true.
 *
 * The two database-cutover scenarios below run in a spawned child process,
 * not inline: production code's own db.close() is unconditional and
 * irreversible in-process (a better-sqlite3 handle cannot be reopened),
 * exactly the property this fix works around for the *file* rollback — but
 * it does mean this *test* process's own shared connection would be
 * unusable for any further assertion or restore call after triggering that
 * path, same as the real running portal would be. A disposable child
 * process is the correct way to exercise that path repeatedly and still
 * make assertions from a live connection afterward.
 *
 * Second pass (independent/Codex verification): the shadow-and-swap-with-
 * rollback design above only ever checked whether its OWN rename calls threw
 * - it never verified the rollback actually put a genuine original database
 * back, never distinguished "rolled back cleanly, just needs a restart" from
 * "the rollback itself failed, the live path is now missing or unverifiable",
 * and its failure-logging reconnect opened the live path WITHOUT
 * fileMustExist — silently creating a brand-new EMPTY database there if the
 * rollback had actually failed, while the operator-facing page unconditionally
 * claimed "nothing was lost". Storage's own rollback failures were also only
 * ever console.error'd, never surfaced to the caller, and secondary cleanup
 * errors (removing the staged file/extract dir) could throw and swallow the
 * primary failure result entirely. Finally, shadow files left behind by an
 * earlier interrupted restore were never checked for, so a new restore could
 * roll back onto a STALE original from an unrelated prior incident.
 *
 * Fixed by: verifying the rollback (verifyRestoredDatabase(), with
 * fileMustExist) before ever calling it successful; a fatal_unrecovered
 * state, distinct from the ordinary restart_required one, whenever a
 * rollback (database or storage) cannot be verified, carrying a
 * recoveryHint that points at the safety copy taken before the restore
 * began; wrapping every cleanup step in its own try/catch so a secondary
 * error can never replace the primary result; and refusing outright,
 * before touching anything, whenever a leftover shadow file from an earlier
 * interrupted restore is still on disk.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-restore-failure-safety-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember } = await import('../services/members.js');
const { createBackup } = await import('../services/backups.js');
const { default: db } = await import('../db/index.js');
const { default: Database } = await import('better-sqlite3');
const config = (await import('../config/env.js')).default;

const storageBase = path.resolve(config.storageDir);
function writeMarker(folder, content) {
  const dir = path.join(storageBase, folder);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'marker.txt'), content);
}
function readMarker(folder) {
  const file = path.join(storageBase, folder, 'marker.txt');
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
}

createMember({ first_name: 'Original', last_name: 'BeforeBackup' }, { status: 'active' });
writeMarker('members', 'version-A');
writeMarker('documents', 'version-A');

const goodBackup = await createBackup({ kind: 'manual', note: 'fault-injection fixture' });
assert.ok(goodBackup.ok, 'the fixture backup must be created successfully');

// Drift the live state after the backup was taken, so every check below can
// distinguish "rolled back to current" from "partially advanced toward the
// backup" — a real restore of goodBackup would try to move this drifted
// state back toward version-A / Original-only.
createMember({ first_name: 'Drifted', last_name: 'AfterBackup' }, { status: 'active' });
writeMarker('members', 'version-B-drifted');
writeMarker('documents', 'version-B-drifted');

// Uses its OWN short-lived connection rather than the shared `db` import -
// WAL mode allows concurrent readers freely, and this way the check works
// identically whether the shared connection is still open (tests above the
// child-process section) or already closed by a child scenario (tests
// below it), without needing two code paths.
function assertOriginalStateIntact(label) {
  assert.equal(readMarker('members'), 'version-B-drifted', `${label}: members storage must remain the current (drifted) content, not partially restored`);
  assert.equal(readMarker('documents'), 'version-B-drifted', `${label}: documents storage must remain the current (drifted) content, not partially restored`);
  assert.ok(fs.existsSync(config.databaseFile), `${label}: the live database file must still exist at its normal path`);
  const conn = new Database(config.databaseFile, { readonly: true, fileMustExist: true });
  try {
    const row = conn.prepare('SELECT COUNT(*) AS n FROM members WHERE last_name = ?').get('AfterBackup');
    assert.equal(row.n, 1, `${label}: the drifted member added after the backup must still exist — the database must not have been swapped`);
  } finally {
    conn.close();
  }
}

// --- Fault injector for the two in-process scenarios: wraps fs.renameSync /
//     fs.accessSync so a call can be made to throw by matching its
//     arguments, then is restored immediately after each case. ---
const realRenameSync = fs.renameSync;
const realAccessSync = fs.accessSync;
let renameFailPredicate = null;
let accessFailPredicate = null;
fs.renameSync = (...args) => {
  if (renameFailPredicate && renameFailPredicate(...args)) {
    throw new Error(`injected failure: renameSync(${args[0]}, ${args[1]})`);
  }
  return realRenameSync(...args);
};
fs.accessSync = (...args) => {
  if (accessFailPredicate && accessFailPredicate(...args)) {
    throw new Error(`injected failure: accessSync(${args[0]})`);
  }
  return realAccessSync(...args);
};
function resetInjection() { renameFailPredicate = null; accessFailPredicate = null; }

// --- 1. Failure BEFORE cutover (the new storage-readability pre-check). ---
{
  const { restoreBackup } = await import('../services/backups.js');
  accessFailPredicate = (target) => String(target).includes(path.join('storage', 'documents'));
  const result = await restoreBackup(goodBackup.backup.id, {});
  resetInjection();

  assert.equal(result.ok, false, 'an injected pre-cutover failure must be reported as a failure');
  assert.notEqual(result.processRestartRequired, true, 'a pre-cutover failure must not require a process restart — the connection was never touched');
  assertOriginalStateIntact('before-cutover failure');

  const restore = db.prepare('SELECT * FROM backup_restores ORDER BY id DESC LIMIT 1').get();
  assert.equal(restore.status, 'failed', 'the failure must be logged via the normal (still-open) connection');
  console.log('PASS: a failure before cutover leaves the original database and storage completely untouched');
}

// --- 2. Failure DURING storage cutover (second of two folders). ---
{
  const { restoreBackup } = await import('../services/backups.js');
  const suffix = '.pre-restore-original';
  // Folder iteration order (fs.readdirSync) is not something to hardcode a
  // name against — let the *first* folder's swap-in succeed and fail the
  // *second* one, whichever names those turn out to be, via a call count.
  let swapInsAttempted = 0;
  renameFailPredicate = (from, to) => {
    const toStr = String(to);
    const fromStr = String(from);
    // A forward swap-in renames the freshly extracted folder (never
    // suffixed) into the live destination (never suffixed) — distinct from
    // the aside-rename (destination -> ...suffix) and from a rollback's own
    // rename (...suffix -> destination), neither of which should count here.
    const isForwardSwapIn = !fromStr.endsWith(suffix) && !toStr.endsWith(suffix)
      && (toStr.endsWith(path.join('storage', 'members')) || toStr.endsWith(path.join('storage', 'documents')));
    if (!isForwardSwapIn) return false;
    swapInsAttempted += 1;
    return swapInsAttempted === 2; // fail the second folder's swap-in
  };

  const result = await restoreBackup(goodBackup.backup.id, {});
  resetInjection();

  assert.equal(result.ok, false, 'an injected mid-storage-cutover failure must be reported as a failure');
  assert.notEqual(result.processRestartRequired, true, 'a storage-cutover failure must not require a process restart — the database connection was never touched');
  assert.equal(swapInsAttempted, 2, 'sanity check: the first folder\'s swap-in must have succeeded before the second one failed');
  assertOriginalStateIntact('mid-storage-cutover failure (including the folder that had already swapped in)');
  console.log('PASS: a failure partway through storage cutover rolls back every folder already swapped, including the one that had already succeeded');
}

// --- 2b. Codex/independent verification: the storage ROLLBACK itself can
//     fail (not just the forward cutover) - the old code just console.error'd
//     and moved on, leaving the caller to believe storage was safely put
//     back when it might not have been. Fail the same forward swap-in as
//     test 2, and ALSO fail the rollback's own rename-back for whichever
//     folder had already swapped forward, so rollbackStorage() itself can't
//     fully succeed. ---
{
  const { restoreBackup } = await import('../services/backups.js');
  const suffix = '.pre-restore-original';
  let swapInsAttempted = 0;
  renameFailPredicate = (from, to) => {
    const toStr = String(to);
    const fromStr = String(from);
    const isForwardSwapIn = !fromStr.endsWith(suffix) && !toStr.endsWith(suffix)
      && (toStr.endsWith(path.join('storage', 'members')) || toStr.endsWith(path.join('storage', 'documents')));
    if (isForwardSwapIn) {
      swapInsAttempted += 1;
      return swapInsAttempted === 2; // fail the second folder's swap-in, same as test 2
    }
    // The rollback's own rename-back (suffixed -> unsuffixed) for the folder
    // that HAD already swapped forward must itself fail here.
    return fromStr.endsWith(suffix) && !toStr.endsWith(suffix);
  };

  const result = await restoreBackup(goodBackup.backup.id, {});
  resetInjection();

  assert.equal(result.ok, false, 'an injected storage-rollback failure must still be reported as a failure');
  assert.equal(result.processRestartRequired, true,
    'CODEX FINDING CONFIRMED FIXED (R09 requirement D): fatal storage, even though the database connection itself is untouched, must still stop this process from continuing to serve normally - storage in an unverified state is dangerous to keep serving from');
  assert.equal(result.fatal, true,
    'CODEX FINDING CONFIRMED FIXED: a storage rollback that cannot itself be verified must be surfaced as fatal, not silently assumed successful');
  assert.equal(result.state, 'fatal_unrecovered');
  assert.ok(result.recoveryHint, 'a fatal result must point the operator at the safety copy for manual recovery');

  const { checkRecoveryInterlock, clearRecoveryInterlock } = await import('../lib/recovery-interlock.js');
  const interlock = checkRecoveryInterlock();
  assert.ok(interlock, 'CODEX FINDING CONFIRMED FIXED (R09): a fatal storage rollback must write a durable recovery interlock outside the database');
  assert.equal(interlock.kind, 'storage');
  // Cleared immediately: later scenarios below spawn fresh child processes
  // that each check this same interlock at their own startup (db/index.js),
  // and this test's own point is already proven - leaving it in place would
  // incorrectly block every subsequent scenario in this file.
  clearRecoveryInterlock();
  assert.equal(checkRecoveryInterlock(), null, 'the interlock must actually be removed once cleared');
  console.log('PASS: a storage rollback that itself fails is reported as fatal, stops this process from serving normally, and writes a recovery interlock');

  // Repair: this scenario deliberately leaves storage in an unverified
  // state, including the very shadow folders (name + suffix) that the new
  // stale-shadow-artifact guard (test 2c below, and in production) exists to
  // detect - clean those up too, not just the live folders' content, or the
  // next restore attempt in this file would be legitimately refused by that
  // guard rather than exercising what each test actually means to isolate.
  for (const entry of fs.readdirSync(storageBase)) {
    if (entry.endsWith('.pre-restore-original')) fs.rmSync(path.join(storageBase, entry), { recursive: true, force: true });
  }
  writeMarker('members', 'version-B-drifted');
  writeMarker('documents', 'version-B-drifted');
}

fs.renameSync = realRenameSync;
fs.accessSync = realAccessSync;

// --- 2c. Codex/independent verification: leftover shadow files from an
//     earlier, interrupted restore (crash, kill -9, bug) must not be
//     silently reused or overwritten by a NEW restore attempt - that risks
//     a stale rollback later restoring the WRONG generation of data over the
//     current live file. A new restore must refuse deterministically instead. ---
{
  const { restoreBackup, listBackups } = await import('../services/backups.js');
  const staleFile = `${config.databaseFile}.pre-restore-original`;
  fs.writeFileSync(staleFile, 'leftover from a prior interrupted restore, never cleaned up');
  const backupsBefore = listBackups({ limit: 1000 }).length;

  const result = await restoreBackup(goodBackup.backup.id, {});

  assert.equal(result.ok, false, 'a restore attempt must refuse to proceed while a stale shadow artifact exists');
  assert.equal(result.reason, 'stale_shadow_artifacts',
    'CODEX FINDING CONFIRMED FIXED: leftover files from an earlier interrupted restore must be detected and refused deterministically');
  assert.ok(result.staleArtifacts.includes(staleFile), 'the specific stale file must be named in the result');
  assertOriginalStateIntact('stale shadow artifact refusal');
  assert.equal(listBackups({ limit: 1000 }).length, backupsBefore,
    'refusing before any work begins must not waste a new safety backup');

  fs.rmSync(staleFile, { force: true });
  console.log('PASS: a restore refuses to proceed while a stale shadow artifact from an earlier interrupted restore exists');
}

// --- 2d. Codex/independent verification: a truncated/corrupted backup
//     archive (an incomplete transfer or partial write) must be rejected
//     before anything live is touched, exactly like any other verification
//     failure. Runs here (in-process, sharing `db`) rather than alongside
//     the child-process scenarios below, since it never reaches the
//     database cutover at all - verifyBackup()'s checksum check rejects it
//     first, through the still-open shared connection. ---
{
  const { restoreBackup } = await import('../services/backups.js');
  const backupFile = path.join(config.backupDir, goodBackup.backup.filename);
  const original = fs.readFileSync(backupFile);
  fs.writeFileSync(backupFile, original.subarray(0, Math.floor(original.length / 2)));

  const result = await restoreBackup(goodBackup.backup.id, {});
  fs.writeFileSync(backupFile, original);

  assert.equal(result.ok, false, 'a truncated/corrupted backup archive must not be restorable');
  assert.equal(result.reason, 'checksum_mismatch', 'a truncated archive must fail checksum verification before any extraction is attempted');
  assertOriginalStateIntact('truncated/incomplete backup archive');
  console.log('PASS: a truncated/incomplete backup archive is rejected before touching anything live');
}

// --- 2e. Codex/independent verification (R09-B): the pre-cutover storage
//     check only ever validated whatever folders HAPPENED to be present in
//     the extraction - it never cross-checked that against what the
//     manifest itself declares. An archive missing one of its own
//     manifest-declared storage folders (a partial write that still passes
//     checksum, since the checksum covers whatever bytes ARE there) would
//     restore the database and the folders that DID make it, while
//     silently leaving whichever folder didn't untouched at its old LIVE
//     content - a restore that is part archive, part live state. Tampering
//     the manifest (adding a folder the real archive doesn't have) and
//     recomputing the checksum so it passes that earlier gate reproduces
//     exactly this. ---
{
  const { restoreBackup } = await import('../services/backups.js');
  const backupFile = path.join(config.backupDir, goodBackup.backup.filename);
  const originalBytes = fs.readFileSync(backupFile);
  const originalChecksum = db.prepare('SELECT checksum FROM backups WHERE id = ?').get(goodBackup.backup.id).checksum;

  const tamperDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-manifest-tamper-'));
  await tar.extract({ file: backupFile, cwd: tamperDir });
  const manifestPath = path.join(tamperDir, 'manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  manifest.storage_folders = [...(manifest.storage_folders || []), 'a_folder_the_archive_does_not_actually_have'];
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  await tar.create({ gzip: true, file: backupFile, cwd: tamperDir }, fs.readdirSync(tamperDir));
  const tamperedChecksum = crypto.createHash('sha256').update(fs.readFileSync(backupFile)).digest('hex');
  db.prepare('UPDATE backups SET checksum = ? WHERE id = ?').run(tamperedChecksum, goodBackup.backup.id);

  const result = await restoreBackup(goodBackup.backup.id, {});

  fs.writeFileSync(backupFile, originalBytes);
  db.prepare('UPDATE backups SET checksum = ? WHERE id = ?').run(originalChecksum, goodBackup.backup.id);
  fs.rmSync(tamperDir, { recursive: true, force: true });

  assert.equal(result.ok, false, 'an archive missing a manifest-declared storage folder must not be restorable');
  assert.equal(result.reason, 'incomplete_archive',
    'CODEX FINDING CONFIRMED FIXED (R09-B): a manifest declaring a storage folder that is not actually present in the archive must be refused before any cutover, never restored as a mix of archive and live state');
  assert.ok(result.missingFolders?.includes('a_folder_the_archive_does_not_actually_have'));
  assertOriginalStateIntact('archive missing a manifest-declared storage folder');
  console.log('PASS: an archive missing a storage folder its own manifest declares is rejected before touching anything live');
}

// This process's OWN long-lived connection to fixture.sqlite, still open from
// the tests above, holds Windows-level handles on that database's own files -
// on this platform, that alone is enough to make a CHILD process's rename of
// fixture.sqlite-wal fail with a genuine, deterministic EBUSY, regardless of
// which of that child's OWN renames is the one actually meant to be under
// test. Every remaining assertion in this file uses assertOriginalStateIntact
// or its own fresh connection rather than this `db` variable, so closing it
// here (once, for the rest of the file) is safe.
db.close();

// --- Child-process scenarios: database-cutover failures. db.close() is
//     unconditional and irreversible in-process (see file header), so these
//     run standalone and are inspected via a fresh connection afterward. ---
function runChildRestoreScenario(scenario) {
  const renameFailCondition = {
    // The wal/shm renames are each guarded by fs.existsSync() and only
    // attempted when those files actually exist at that moment, which isn't
    // guaranteed (a database with nothing pending to checkpoint may have no
    // -wal file at all). target->dbOriginal is the first rename the cutover
    // always unconditionally attempts regardless of wal/shm state, so it's
    // the reliable place to fail "as early as possible, nothing moved yet".
    'early-db': "from === process.env.DATABASE_FILE && to === process.env.DATABASE_FILE + '.pre-restore-original'",
    'late-db': "from.endsWith('.restore-staged') && to === process.env.DATABASE_FILE",
    // Same forward failure as late-db (a clean, verifiable rollback in
    // itself) - the shadow original is made to vanish separately (see
    // hideShadowOriginal below) before the rollback needs it, rather than by
    // intercepting the rollback rename call directly, which unlike every
    // other rename here is prone to a genuine, sustained EBUSY in this test
    // environment unrelated to anything this scenario means to exercise.
    'rollback-fails': "from.endsWith('.restore-staged') && to === process.env.DATABASE_FILE",
    // Same forward failure as early-db (a clean, verifiable rollback), but a
    // SECONDARY cleanup error (removing the now-unneeded staged file) must
    // never be allowed to swallow the primary failure result.
    'cleanup-fails': "from === process.env.DATABASE_FILE && to === process.env.DATABASE_FILE + '.pre-restore-original'",
    // No injected failure at all - a genuine, uninterrupted restore. Run via
    // the same child-process scaffolding as the failure scenarios above (not
    // a direct in-process call) because backups.js's own restoreBackup()
    // needs a working, unclosed `db` connection, and this test file's own
    // shared one is intentionally closed for the whole child-scenario
    // section above.
    'success': 'false',
    // Also a genuine, uninterrupted cutover - the failure is purely in the
    // POST-success cleanup of the now-unneeded shadow database file.
    'success-cleanup-fails': 'false'
  }[scenario];

  const rmSyncFailCondition = {
    'cleanup-fails': "String(args[0]).endsWith('.restore-staged')",
    'success-cleanup-fails': "String(args[0]).endsWith('.pre-restore-original') && !String(args[0]).includes('storage') && !String(args[0]).includes('-wal') && !String(args[0]).includes('-shm')"
  }[scenario] || 'false';

  // rollback-fails only: the code decides whether to even attempt the
  // rollback rename with `if (fs.existsSync(dbOriginal)) ...` - reporting
  // that check as false (while the real file is untouched) reproduces "the
  // shadow original is gone when the rollback needs it" (a concurrent
  // cleanup, an antivirus quarantine) without ever calling renameSync on
  // that path at all, sidestepping the flaky rename entirely.
  const hideShadowOriginal = scenario === 'rollback-fails';

  const script = `
    import fs from 'node:fs';
    const realRename = fs.renameSync;
    // Windows can throw a transient, genuinely-unrelated EBUSY on a rename of
    // this database's own files while THIS PARENT test process still holds
    // its own connection/handles open against the very same path - nothing
    // to do with the fault this scenario actually means to inject. Retrying
    // briefly on the PASS-THROUGH path only (never on an intercepted,
    // deliberately-injected failure) keeps that real-world hiccup from
    // pre-empting the specific failure point each scenario isolates.
    function renameWithRetry(from, to) {
      const deadline = Date.now() + 3000;
      for (let attempt = 0; ; attempt++) {
        try {
          return realRename(from, to);
        } catch (e) {
          if (e.code === 'EBUSY' && Date.now() < deadline) {
            Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.min(250, 25 * (attempt + 1)));
            continue;
          }
          throw e;
        }
      }
    }
    fs.renameSync = (...args) => {
      const [from, to] = args.map(String);
      if (process.env.DEBUG_RESTORE_TEST) console.error('DEBUGRENAME', JSON.stringify({from, to}));
      if (${renameFailCondition}) {
        throw new Error('injected failure (${scenario})');
      }
      return renameWithRetry(...args);
    };
    const realRmSync = fs.rmSync;
    fs.rmSync = (...args) => {
      if (${rmSyncFailCondition}) {
        throw new Error('injected cleanup failure (${scenario})');
      }
      return realRmSync(...args);
    };
    ${hideShadowOriginal ? `
    const realExistsSync = fs.existsSync;
    fs.existsSync = (p) => {
      if (String(p) === process.env.DATABASE_FILE + '.pre-restore-original') return false;
      return realExistsSync(p);
    };
    ` : ''}
    const { restoreBackup } = await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/services/backups.js')).href)});
    const result = await restoreBackup(${goodBackup.backup.id}, {});
    process.stdout.write('RESULT_JSON:' + JSON.stringify(result) + '\\n');
  `;
  const scriptPath = path.join(env.root, `restore-child-${scenario}.mjs`);
  fs.writeFileSync(scriptPath, script);
  const proc = spawnSync(process.execPath, [scriptPath], { env: process.env, encoding: 'utf8' });
  if (process.env.DEBUG_RESTORE_TEST) console.error(`--- child stderr (${scenario}) ---\n${proc.stderr}\n--- child stdout (${scenario}) ---\n${proc.stdout}`);
  const line = proc.stdout.split('\n').find((l) => l.startsWith('RESULT_JSON:'));
  if (!line) {
    throw new Error(`child scenario "${scenario}" produced no result — stdout:\n${proc.stdout}\nstderr:\n${proc.stderr}`);
  }
  return JSON.parse(line.slice('RESULT_JSON:'.length));
}

// --- 3 (run first among the child-db-cutover scenarios). Codex/independent
//     verification: the database ROLLBACK itself can fail (not just the
//     forward cutover) - the old code assumed the rename back had worked
//     whenever it didn't throw an error IT checked for, then told the
//     operator "the original database and files have been put back exactly
//     as they were — nothing was lost" regardless. Here the forward cutover
//     fails AND the rollback's own rename-back fails, leaving the live path
//     genuinely missing (the real content sits at the shadow path) - the
//     one case a truthful result must never call safe. Deliberately placed
//     before the other child-db-cutover scenarios below: on this test
//     machine, running a THIRD child-process db cutover against the same
//     fixture can hit a genuine, sustained OS-level EBUSY renaming the wal
//     file, unrelated to anything any of these scenarios mean to exercise -
//     going first avoids that entirely. ---
{
  let result;
  for (let attempt = 1; ; attempt++) {
    result = runChildRestoreScenario('rollback-fails');
    if (typeof result.reason === 'string' && result.reason.includes('-wal') && attempt < 5) continue;
    break;
  }
  assert.equal(result.ok, false, 'an injected rollback failure must be reported as a failure');
  assert.equal(result.processRestartRequired, true, 'the shared connection was closed before the rollback attempt, so a restart is still required');
  assert.equal(result.fatal, true,
    'CODEX FINDING CONFIRMED FIXED: when the database rollback cannot be verified, the result must say so as fatal rather than claiming a safe, ordinary restart-required outcome');
  assert.equal(result.state, 'fatal_unrecovered');
  assert.ok(result.recoveryHint, 'a fatal result must point the operator at the safety copy for manual recovery, not merely say "try again"');

  // Reproduce the exact defect this closes: the live database file is
  // genuinely missing at this point (both the forward and rollback renames
  // were injected to fail) - the real content was never lost, it simply
  // never made it back to the live path automatically. A truthful result
  // must not claim otherwise, and the operator-facing view (restore-fatal.ejs)
  // deliberately never says "nothing was lost" the way restore-failed.ejs does.
  const shadowDb = `${config.databaseFile}.pre-restore-original`;
  assert.ok(!fs.existsSync(config.databaseFile), 'sanity: the live database path is genuinely missing after this injected double failure');
  assert.ok(fs.existsSync(shadowDb), 'sanity: the real original content still exists at the shadow path, recoverable by hand');

  const { checkRecoveryInterlock, clearRecoveryInterlock } = await import('../lib/recovery-interlock.js');
  const interlock = checkRecoveryInterlock();
  assert.ok(interlock, 'CODEX FINDING CONFIRMED FIXED (R09): a fatal database rollback must write a durable recovery interlock outside the database, checked by db/index.js before ordinary startup can open it');
  assert.equal(interlock.kind, 'database');

  // R09 P0: an ordinary startup attempt (a fresh process importing
  // db/index.js, exactly what the supervisor's restart of the crashed
  // process would do) must be refused OUTRIGHT while this interlock is
  // active and the live database path is genuinely missing - and, above
  // all, must NOT silently create a brand-new empty database at that path
  // the way better-sqlite3's default behavior otherwise would.
  {
    const startupScript = `
      try {
        await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/db/index.js')).href)});
        process.stdout.write('OPENED\\n');
      } catch (e) {
        process.stdout.write('REFUSED:' + e.message + '\\n');
      }
    `;
    const startupScriptPath = path.join(env.root, 'startup-attempt.mjs');
    fs.writeFileSync(startupScriptPath, startupScript);
    const startupProc = spawnSync(process.execPath, [startupScriptPath], { env: process.env, encoding: 'utf8' });
    const line = startupProc.stdout.trim();
    assert.ok(line.startsWith('REFUSED:'),
      `CODEX FINDING CONFIRMED FIXED (R09 P0): ordinary startup must be refused while a fatal recovery interlock is active and the database is missing - got: ${line || startupProc.stderr}`);
    assert.ok(!fs.existsSync(config.databaseFile),
      'CODEX FINDING CONFIRMED FIXED (R09 P0): the attempted startup must not have silently created a new, empty database at the live path');
    console.log('PASS: an ordinary startup attempt while the recovery interlock is active is refused outright, without creating a new empty database');
  }

  // Repair by hand (a real operator would do exactly this, guided by the
  // recovery hint) so later tests in this file resume from the expected
  // drifted baseline. Clearing the interlock (rather than leaving it for
  // tools/clear-recovery-interlock.mjs, exercised separately below) is
  // required here too - the next child-process scenario's own startup would
  // otherwise be refused by db/index.js just like a real ordinary restart
  // would be.
  fs.renameSync(shadowDb, config.databaseFile);
  clearRecoveryInterlock();
  assert.equal(checkRecoveryInterlock(), null, 'the interlock must actually be removed once cleared');
  assertOriginalStateIntact('after manual repair of the intentionally-unrecovered rollback-fails scenario');
  console.log('PASS: a database rollback that itself fails is reported as fatal, writes a recovery interlock, with a truthful recovery hint instead of a false "nothing was lost"');
}

// --- 4. Failure DURING database cutover, early (right as the connection closes). ---
{
  const result = runChildRestoreScenario('early-db');
  assert.equal(result.ok, false, 'an injected early-db-cutover failure must be reported as a failure');
  assert.equal(result.processRestartRequired, true, 'a database-cutover failure closes the shared connection, so it must report that a process restart is required');
  assertOriginalStateIntact('early database-cutover failure (storage must also roll back, not stay "ahead" of a now-reverted database)');

  const conn = await import('better-sqlite3').then((m) => new m.default(config.databaseFile));
  const restore = conn.prepare('SELECT * FROM backup_restores ORDER BY id DESC LIMIT 1').get();
  conn.close();
  assert.equal(restore.status, 'failed', 'the failure must be logged via a fresh connection once the shared one is closed');
  console.log('PASS: an early database-cutover failure rolls back storage too and logs via a fresh connection, flagging that a restart is required');
}

// --- 5. Failure DURING database cutover, AFTER the original file has already
//        moved aside but BEFORE the new one has taken its place — "one
//        component moved, not complete." ---
{
  const result = runChildRestoreScenario('late-db');
  assert.equal(result.ok, false, 'an injected late-db-cutover failure (staged file not yet in place) must be reported as a failure');
  assert.equal(result.processRestartRequired, true, 'this failure also closed the shared connection and must require a restart');
  assert.ok(fs.existsSync(config.databaseFile), 'the database file must exist at its normal path after rollback, not be missing because only the original was moved aside');
  assertOriginalStateIntact('late database-cutover failure, after the original db had already moved aside');
  console.log('PASS: a failure after the original database file has moved aside but before the new one is in place is fully rolled back');
}

// --- 6. Codex/independent verification: a SECONDARY error while cleaning up
//     the now-unneeded staged file after a (successfully rolled back)
//     database-cutover failure must never be allowed to throw past the
//     primary failure handling and swallow the processRestartRequired
//     signal - the old code's unguarded fs.rmSync() calls could do exactly
//     that. ---
{
  const result = runChildRestoreScenario('cleanup-fails');
  assert.equal(result.ok, false, 'an injected early-db-cutover failure must still be reported as a failure even when its own cleanup afterward also fails');
  assert.equal(result.processRestartRequired, true,
    'CODEX FINDING CONFIRMED FIXED: a secondary cleanup error must not prevent the restart-required signal from being returned at all');
  assert.notEqual(result.fatal, true, 'the database and storage rollback themselves both succeeded here - only an unrelated cleanup step failed, so this is not fatal');
  assertOriginalStateIntact('database-cutover failure whose own cleanup afterward also failed');
  console.log('PASS: a secondary cleanup error after a database-cutover failure does not swallow the restart-required result');
}

// --- Sanity: a real, uninterrupted restore still succeeds normally. Run in
//     a child process, same as the failure scenarios above (this file's own
//     shared `db` is closed - see the comment above the child-scenario
//     section), and inspected via a fresh connection afterward. ---
{
  const result = runChildRestoreScenario('success');
  assert.equal(result.ok, true, 'an uninjected restore must still succeed normally after all the fault-injection cases above');
  assert.equal(readMarker('members'), 'version-A', 'a genuinely successful restore must still actually replace storage content');

  const conn = new Database(config.databaseFile, { readonly: true, fileMustExist: true });
  const row = conn.prepare('SELECT COUNT(*) AS n FROM members WHERE last_name = ?').get('AfterBackup');
  conn.close();
  assert.equal(row.n, 0, 'a genuinely successful restore must still actually replace the database content');
  console.log('PASS: a normal, uninterrupted restore still succeeds, with unchanged external behavior');

  // A successful restore rewinds the ENTIRE database, including the backups
  // table's own row for goodBackup itself - captured mid-createBackup(),
  // before that row's own status flip to 'completed', so the row this
  // restore just brought back shows 'pending'. Unrelated to anything this
  // pass fixes; corrected by hand so the next test below can restore from
  // goodBackup a second time.
  const fix = new Database(config.databaseFile, { fileMustExist: true });
  fix.prepare('UPDATE backups SET status = @status, checksum = @checksum, file_size = @size WHERE id = @id').run({
    id: goodBackup.backup.id, status: 'completed', checksum: goodBackup.backup.checksum, size: goodBackup.backup.file_size
  });
  fix.close();
}

// --- R09 items A and C together: the cutover itself can succeed (verified)
//     while the PURELY COSMETIC cleanup of the now-unneeded shadow database
//     file afterward fails. The old code's unguarded fs.rmSync() calls here
//     would throw straight into the generic outer catch, which assumes the
//     shared connection is still open (dbClosed: false) - it is not, right
//     after a successful cutover - crashing through a closed connection
//     instead of returning a coherent result (item A). Separately, that
//     leftover shadow file would then silently block the NEXT restore via
//     staleShadowArtifacts(), with nothing in THIS restore's own result
//     ever saying so (item C). ---
{
  const result = runChildRestoreScenario('success-cleanup-fails');
  assert.equal(result.ok, true,
    'CODEX FINDING CONFIRMED FIXED (R09 item A): a cutover that itself succeeded must still be reported as a success even when its own post-success cleanup afterward fails, not crash through the closed connection');
  assert.equal(result.cleanupIncomplete, true,
    'CODEX FINDING CONFIRMED FIXED (R09 item C): a leftover shadow file from cleanup must be reported, not silently ignored while claiming ordinary success');
  assert.ok(result.recoveryHint, 'a cleanup-incomplete result must tell the operator what needs manual attention');

  // The exact consequence item C warns about: this leftover shadow file
  // matches precisely what staleShadowArtifacts() checks for (test 2c above
  // already proves that check reliably refuses a new restore while any such
  // file exists) - confirming it is genuinely left on disk, not merely
  // reported as a flag with nothing behind it, is what item C actually
  // requires of a truthful result.
  const leftoverShadowDb = `${config.databaseFile}.pre-restore-original`;
  assert.ok(fs.existsSync(leftoverShadowDb),
    'the leftover shadow file this result reports on must genuinely still be on disk, exactly what would block the next restore attempt');
  fs.rmSync(leftoverShadowDb, { force: true });
  console.log('PASS: a successful restore whose own post-success cleanup fails is reported as success-with-cleanup-incomplete, not a crash, and genuinely leaves the artifact that would block the next restore until removed');
}

env.cleanup();
console.log('ALL PASS');
