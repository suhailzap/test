import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Faith Promise: two defects found by independent review.
 *   A. A member's submission must only be accepted by the ACTIVE campaign. It used to fall back to "the latest campaign" of any status, so a draft, closed or
 *      archived campaign (or a crafted post naming one) could take a commitment, and a commitment could silently land in a different campaign from the one shown.
 *   B. Editing a commitment's amount or frequency changed its expected total but left the derived status stale: a Completed commitment raised above what had been
 *      received stayed Completed.
 * Historical identity is not touched: Giving Board 2025, Faith Promise 2026 (here: whatever year the fixture uses for each, unchanged by every step).
 */

const f = await buildPortalFixture('cciq-fp-integrity-');
const { db, ids, users, mods } = f;
const year = Number(mods.dates.today().slice(0, 4));
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const commitmentRow = () => db.prepare('SELECT * FROM ecaq_faith_promise_commitments WHERE id = ?').get(ids.commitment);
const campaignRows = () => JSON.stringify(db.prepare('SELECT id, name, type, year, start_date, end_date FROM ecaq_campaigns ORDER BY id').all());
const setStatus = (id, status) => db.prepare('UPDATE ecaq_campaigns SET status = ? WHERE id = ?').run(status, id);
const identities = campaignRows();
const promiseId = ids.promise ?? db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'faith_promise'").get().id;

const portal = await startPortal();
try {
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const token = await member.csrf('/account/password');
  const submit = async (fields) => {
    const res = await member.post('/projects/ecaq/faith-promise', { name: 'Anna MemberA', phone: '', email: '', amount: '50', frequency: 'monthly', ...fields }, { csrf: token });
    await res.text();
    return res;
  };
  const completedCommitment = () => {
    const c = commitmentRow();
    mods.faith.addPayment(c.id, { received_by: 'Fixture Receiver', amount: c.expected_total, paid_on: mods.dates.today() }, { userId: users.churchAdmin.id });
    assert.equal(commitmentRow().status, 'completed');
  };

  // ---- B. status follows the amount (a change is an ADMINISTRATOR's amendment: a member submits once) ----------------------------------------------------------
  {
    completedCommitment();
    const before = commitmentRow();
    assert.equal(before.expected_total, 600);
    const paymentsBefore = JSON.stringify(db.prepare('SELECT id, amount, paid_on FROM ecaq_faith_promise_payments WHERE commitment_id = ? ORDER BY id').all(before.id));
    const adminToken = await admin.csrf('/admin/ecaq/faith-promise/new');
    const amend = async (fields) => { const res = await admin.post(`/admin/ecaq/faith-promise/commitments/${before.id}/amend`, { reason: 'Member asked for the change', ...fields }, { csrf: adminToken }); await res.text(); return res; };

    // the member can no longer change it by the old address: refused, nothing changes
    const refused = await submit({ campaign_id: String(promiseId), amount: '100' });
    assert.equal(refused.status, 302);
    assert.equal(JSON.stringify(commitmentRow()), JSON.stringify(before), 'a second submission by the member changes nothing');

    const raise = await amend({ amount: '100', frequency: 'monthly' });
    assert.equal(raise.status, 302);
    const raised = commitmentRow();
    assert.equal(raised.expected_total, 1200, 'the expected total follows the new amount');
    assert.equal(raised.amount_collected, 600, 'what was received is untouched');
    assert.equal(raised.status, 'in_progress', 'B: a Completed commitment raised above the receipts is In progress again');
    assert.equal(raised.campaign_id, before.campaign_id, 'the commitment stays in its own campaign');

    const lowered = (await amend({ amount: '40', frequency: 'monthly' }), commitmentRow());
    assert.equal(lowered.expected_total, 480);
    assert.equal(lowered.status, 'completed', 'B: lowered to what has been received it is Completed (the same calculation as a payment)');

    await amend({ amount: '100', frequency: 'annual' });
    assert.equal(commitmentRow().expected_total, 100);
    assert.equal(commitmentRow().status, 'completed', 'a change of frequency recalculates too');
    await amend({ amount: '60', frequency: 'monthly' });
    assert.equal(commitmentRow().expected_total, 720);
    assert.equal(commitmentRow().status, 'in_progress');
    assert.equal(JSON.stringify(db.prepare('SELECT id, amount, paid_on FROM ecaq_faith_promise_payments WHERE commitment_id = ? ORDER BY id').all(before.id)), paymentsBefore, 'every payment is preserved exactly');
    assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'ecaq.faith_promise_amended'"), 4, 'each amendment has its audit row');
    // "record for a member" no longer overwrites an existing commitment
    const onBehalf = await admin.post('/admin/ecaq/faith-promise/new', { campaign_id: String(promiseId), member_id: String(commitmentRow().member_id), amount: '30', frequency: 'monthly', name: 'Anna MemberA' }, { csrf: adminToken });
    await onBehalf.text();
    assert.equal(onBehalf.status, 400, 'recording for a member who already has a commitment is refused');
    assert.equal(commitmentRow().expected_total, 720, 'and changes nothing');
    assert.equal(commitmentRow().amount_collected, 600);
    console.log('PASS (B) an amendment recalculates the derived status from the new expected total and the existing payments (up: In progress; down: Completed); payments, campaign and audit rows preserved; the member cannot change it and "record for a member" does not overwrite');
  }

  // ---- A. only the ACTIVE campaign accepts a member's submission --------------------------------------------------------------------------------------------
  {
    const snapshot = () => JSON.stringify([commitmentRow(), count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments'), count("SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'ecaq.faith_promise%'")]);
    const start = snapshot();
    for (const status of ['draft', 'closed', 'archived']) {
      setStatus(promiseId, status);
      const page = await (await member.get('/projects/ecaq/faith-promise')).text();
      assert.ok(!page.includes('id="pledge-form"'), `${status}: the form is not offered`);
      assert.match(page, /not open for new commitments/);
      assert.match(page, /Your commitment so far/, `${status}: the member can still see their own commitment`);
      for (const body of [{ campaign_id: String(promiseId), amount: '999' }, { amount: '999' }]) {
        const res = await submit(body);
        assert.equal(res.status, 302);
        assert.equal(snapshot(), start, `${status}: nothing was saved (${Object.keys(body).join(', ')})`);
      }
    }
    setStatus(promiseId, 'active');

    // no active campaign at all, and a latest campaign that is closed: still refused, never "falls back"
    const closed = mods.ecaq.createCampaign({ name: 'Closed promise', year: year + 1, type: 'faith_promise', status: 'closed', start_date: `${year + 1}-01-01`, end_date: `${year + 1}-12-31` });
    setStatus(promiseId, 'closed');
    const noActive = await submit({ amount: '777' });
    assert.equal(noActive.status, 302);
    assert.equal(snapshot(), start);
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments WHERE campaign_id = ?', closed.id), 0, 'and no commitment landed in the other (latest) campaign');
    setStatus(promiseId, 'active');

    // crafted posts naming another campaign while one IS active
    const draft = mods.ecaq.createCampaign({ name: 'Draft promise', year: year + 2, type: 'faith_promise', status: 'draft', start_date: `${year + 2}-01-01`, end_date: `${year + 2}-12-31` });
    const boardId = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'giving_board' LIMIT 1").get().id;
    for (const named of [String(closed.id), String(draft.id), String(boardId), '0', '-1', 'abc', '99999', `${promiseId}x`, '']) {
      const res = await submit({ campaign_id: named, amount: '888' });
      assert.equal(res.status, 302);
      if (named === '') continue; // no campaign named: the open campaign is used (below)
      assert.equal(snapshot(), start, `a post naming campaign ${JSON.stringify(named)} saved nothing`);
    }
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_commitments WHERE campaign_id IN (?, ?)', closed.id, draft.id), 0, 'nothing was moved into a different campaign');
    assert.equal(snapshot(), start, 'a member who already holds a commitment cannot change it, whichever campaign the post names (or none)');

    // active campaign accepts a normal submission, including a first one by a member who has none
    const other = await signIn(portal.base, users.memberB.email, f.PASSWORD);
    const otherToken = await other.csrf('/account/password');
    const first = await other.post('/projects/ecaq/faith-promise', { campaign_id: String(promiseId), name: 'Ben MemberB', amount: '25', frequency: 'quarterly' }, { csrf: otherToken });
    await first.text();
    assert.equal(first.status, 302);
    const created = db.prepare('SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = ? AND member_id = ?').get(promiseId, users.memberB.memberId);
    assert.ok(created, 'an active campaign accepts a normal authorized submission');
    assert.equal(created.status, 'not_started');
    assert.equal(count("SELECT COUNT(*) n FROM audit_logs WHERE action = 'ecaq.faith_promise_submitted'"), 1);

    // an administrator can still record one for a member on any campaign (not an ordinary member submission) - unchanged
    setStatus(promiseId, 'closed');
    const adminToken = await admin.csrf('/admin/ecaq/faith-promise/new');
    const viaAdmin = await admin.post('/admin/ecaq/faith-promise/new', { campaign_id: String(promiseId), member_id: String(users.memberA.memberId), amount: '10', frequency: 'monthly', name: 'Anna MemberA' }, { csrf: adminToken });
    await viaAdmin.text();
    assert.equal(viaAdmin.status, 400, 'recording for a member who already has a commitment is refused (an amendment is made on the commitment, with a reason)');
    assert.notEqual(commitmentRow().commitment_amount, 10, 'and the existing commitment was not overwritten');
    setStatus(promiseId, 'active');
    console.log('PASS (A) draft, closed and archived campaigns take no member submission (form hidden, own commitment still visible); with no active campaign the latest is not used; posts naming a closed, draft, Giving Board, zero, negative, junk or unknown campaign save nothing and move nothing; an active campaign accepts normal submissions; the administrator path is unchanged');
  }

  // identity of historical campaigns is untouched by all of it
  const now = JSON.parse(campaignRows());
  const before = JSON.parse(identities);
  for (const row of before) assert.deepEqual(now.find((r) => r.id === row.id), row, `campaign ${row.id} keeps its name, type, year and dates`);
  assert.equal(before.find((r) => r.type === 'giving_board').year, year);
  console.log('PASS (identity) existing campaigns keep their name, type, year and period; no campaign was relabelled, merged or rewritten');

  // ---- atomicity: a failing audit row rolls the whole amendment back ------------------------------------------------------------------------------------------
  {
    const before2 = commitmentRow();
    const paymentsBefore = count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE commitment_id = ?', before2.id);
    const adminToken2 = await admin.csrf('/account/password');
    const amend2 = async (amount) => { const res = await admin.post(`/admin/ecaq/faith-promise/commitments/${before2.id}/amend`, { amount, frequency: before2.frequency, reason: 'Member asked' }, { csrf: adminToken2 }); await res.text(); return res; };
    db.exec(`CREATE TRIGGER fp_audit_refuses BEFORE INSERT ON audit_logs WHEN NEW.action = 'ecaq.faith_promise_amended' BEGIN SELECT RAISE(ABORT, 'audit refused'); END`);
    const res = await amend2('500');
    db.exec('DROP TRIGGER fp_audit_refuses');
    assert.ok(res.status >= 400 || res.status === 302);
    const after = commitmentRow();
    assert.deepEqual(after, before2, 'the amount, expected total, status and timestamps are all as they were');
    assert.equal(count('SELECT COUNT(*) n FROM ecaq_faith_promise_payments WHERE commitment_id = ?', before2.id), paymentsBefore);
    const ok = await amend2('500');
    assert.equal(ok.status, 302);
    assert.equal(commitmentRow().commitment_amount, 500, 'control: with the audit working the same request is a real amendment');
    console.log('PASS (atomic) when the audit row cannot be written the whole amendment (amount, expected total, derived status) is rolled back; with it working the same request changes everything together');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');

function completedCommitment_ifNeeded() {
  const c = db.prepare('SELECT * FROM ecaq_faith_promise_commitments WHERE id = ?').get(ids.commitment);
  if (c.status !== 'completed') {
    const outstanding = Math.max(c.expected_total - c.amount_collected, 0);
    if (outstanding > 0) mods.faith.addPayment(c.id, { received_by: 'Fixture Receiver', amount: outstanding, paid_on: mods.dates.today() }, { userId: users.churchAdmin.id });
  }
}
