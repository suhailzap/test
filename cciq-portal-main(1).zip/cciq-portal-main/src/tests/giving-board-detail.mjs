import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Giving Board, physical-test corrections:
 *   - the Thanksgiving Project is the 2025 board: with a 2025 board and a Faith Promise 2026 the default Giving Board is 2025 (a Faith Promise never stands in for it);
 *   - a Giving Board date is a fixed QAR 300: the constant, the new-campaign default, a blank amount, a claim with no stated amount and the seeded 2025 board all say 300;
 *   - an administrator sees, on a CLAIMED date, the member, Member ID, commitment, received, balance, status and claim time - on hover, on keyboard focus and on a tap (a bottom sheet
 *     on a phone or tablet) - with received / balance / status taken from the payment ledger; a member or a leader gets none of it;
 *   - a payment's date is the day the money was received, kept apart from when it was recorded (a historical payment is not forced to today).
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const f = await buildPortalFixture('cciq-gb-detail-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const one = (sql, ...p) => db.prepare(sql).get(...p);

// ---- the 300 rule -------------------------------------------------------------------------------------------------------------------------------------------------------
assert.equal(mods.ecaq.GIVING_BOARD_SLOT_AMOUNT, 300, 'a Giving Board date is QAR 300');
assert.match(fs.readFileSync(path.join(root, 'src/services/ecaq.js'), 'utf8'), /GIVING_BOARD_SLOT_AMOUNT = 300/, 'the application service defines the shared Giving Board amount');

// ---- the 2025 board: created through the application's own service, with the amount left unstated ---------------------------------------------------------------------------
db.prepare("UPDATE ecaq_campaigns SET status = 'draft' WHERE id = ?").run(ids.board); // the fixture's 2026 board steps aside
const board = mods.ecaq.createCampaign({ name: '2025 Thanksgiving Project (Giving Board)', year: 2025, type: 'giving_board', status: 'active', privacy_mode: 'first_name', currency: 'QAR', start_date: '2025-01-01', end_date: '2025-12-31' });
const dates = mods.ecaq.boardDates(2025);
const member = (first, last) => mods.members.createMember({ first_name: first, last_name: last }, { status: 'active' });
const mA = member('Ada', 'Unpaid'); const mB = member('Bea', 'Partial'); const mC = member('Cy', 'Paid');
const claim = (date, m) => { const r = mods.ecaq.createClaim({ campaignId: board.id, date, memberId: m.id, userId: users.churchAdmin.id }); assert.ok(r.ok, 'claim'); return r.claim; };
const cA = claim(dates[3], mA); const cB = claim(dates[4], mB); const cC = claim(dates[5], mC);
assert.equal(cA.commitment_amount, 300, 'a claim with no stated amount is QAR 300');
// a payment recorded today for a day long ago: payment date and recorded-at stay different
const backlogDate = mods.dates.addDays(today, -200);
const p1 = mods.ecaq.addPayment(cB.id, { amount: 120, paid_on: backlogDate, method: 'cash' }, { userId: users.churchAdmin.id });
assert.equal(p1.payment.paid_on, backlogDate, 'the payment date is the day the money was received');
assert.ok(p1.payment.created_at.slice(0, 10) >= today.slice(0, 4) + '-01-01' && p1.payment.created_at.slice(0, 10) !== backlogDate, 'recorded-at is when it was entered');
mods.ecaq.addPayment(cC.id, { amount: 300, paid_on: mods.dates.addDays(today, -3), method: 'bank_transfer' }, { userId: users.churchAdmin.id });
assert.equal(one('SELECT payment_status s, amount_collected c FROM ecaq_giving_board_claims WHERE id = ?', cB.id).s, 'partially_paid');

const browser = await chromium.launch({ channel: 'msedge', headless: true });
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const memberA = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const token = await admin.csrf('/account/password');
  const text = async (client, url) => { const res = await client.get(url); return { status: res.status, body: await res.text() }; };

  // identity: the default Giving Board is the 2025 project, never the Faith Promise 2026
  {
    const page = await text(admin, '/projects/ecaq/board');
    assert.equal(page.status, 200);
    assert.ok(page.body.includes('aria-current="page">2025<'), 'the default Giving Board year is 2025');
    assert.ok(!page.body.includes('Fixture promise'), 'the Faith Promise is not shown as the Giving Board');
    const form = await text(admin, '/admin/ecaq/campaigns/new');
    assert.match(form.body, /name="amount_per_date"[^>]*value="300"/, 'the new-campaign form starts at QAR 300');
    const created = await admin.post('/admin/ecaq/campaigns', { name: 'Blank amount board', year: '2031', type: 'giving_board', amount_per_date: '', status: 'draft', currency: 'QAR', privacy_mode: 'first_name' }, { csrf: token });
    await created.text();
    assert.equal(one("SELECT amount_per_date a FROM ecaq_campaigns WHERE name = 'Blank amount board'").a, 300, 'a blank amount on a Giving Board is QAR 300');
  }

  // who sees the detail
  {
    const adminPage = await text(admin, '/projects/ecaq/board?year=2025');
    const partial = new RegExp(`id="stub-detail-${cB.id}"[\\s\\S]*?</div>`).exec(adminPage.body)?.[0] || '';
    assert.ok(partial.includes('Bea Partial') && partial.includes(mB.member_code), 'the administrator sees the member and Member ID');
    assert.ok(partial.includes('QAR 300') && partial.includes('QAR 120') && partial.includes('QAR 180'), 'commitment 300, received 120 and balance 180 come from the ledger');
    assert.ok(partial.includes('Partially paid'), 'the status is the ledger-derived one');
    assert.ok(partial.includes(`/admin/ecaq/claims/${cB.id}`), 'with a path into the commitment');
    const paidPartial = new RegExp(`id="stub-detail-${cC.id}"[\\s\\S]*?</div>`).exec(adminPage.body)?.[0] || '';
    assert.ok(paidPartial.includes('Balance</dt><dd>QAR 0') && paidPartial.includes('Paid'), 'a paid date shows a zero balance');
    for (const [who, client] of [['leader', leader], ['member', memberA]]) {
      const page = await text(client, '/projects/ecaq/board?year=2025');
      assert.ok(!page.body.includes('stub__tip--admin') && !page.body.includes('Balance') && !page.body.includes(mB.member_code) && !page.body.includes('Bea Partial'), `${who}: no administrative detail, Member ID, balance or full name`);
    }
  }

  // hover, keyboard and touch, in a real browser
  const cookies = (who) => who.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
  const tileSelector = `#stub-detail-${cB.id}`;
  const probe = (page) => page.evaluate((sel) => {
    const panel = document.querySelector(sel); const r = panel.getBoundingClientRect(); const cs = getComputedStyle(panel);
    return { shown: cs.display !== 'none' && r.width > 0, left: Math.round(r.left), right: Math.round(r.right), top: Math.round(r.top), bottom: Math.round(r.bottom), vw: document.documentElement.clientWidth, vh: innerHeight, over: document.documentElement.scrollWidth - document.documentElement.clientWidth, url: location.pathname + location.search };
  }, tileSelector);
  const tileOf = (page) => page.locator(`li.stub:has(${tileSelector}) button.stub__paper, li.stub:has(${tileSelector}) button.stub__reveal`).first();

  {
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    await context.addCookies(cookies(admin));
    const page = await context.newPage();
    await page.goto(`${portal.base}/projects/ecaq/board?year=2025`, { waitUntil: 'load' });
    assert.equal((await probe(page)).shown, false, 'the card is hidden until asked for');
    await tileOf(page).hover();
    const hovered = await probe(page);
    assert.ok(hovered.shown && hovered.left >= 0 && hovered.right <= hovered.vw && hovered.top >= 0, `hover shows the card inside the window ${JSON.stringify(hovered)}`);
    assert.equal(hovered.over, 0, 'no sideways scroll');
    await page.mouse.move(5, 5);
    await page.keyboard.press('Shift');
    await tileOf(page).focus();
    assert.ok((await probe(page)).shown, 'keyboard focus shows the same card');
    await page.keyboard.press('Tab'); // on to the link inside the card: it stays open
    assert.ok((await probe(page)).shown, 'the card stays while focus is inside it');
    await context.close();
  }
  for (const width of [320, 375, 768]) {
    const context = await browser.newContext({ viewport: { width, height: 800 }, hasTouch: true, isMobile: true });
    await context.addCookies(cookies(admin));
    const page = await context.newPage();
    await page.goto(`${portal.base}/projects/ecaq/board?year=2025`, { waitUntil: 'load' });
    const before = await probe(page);
    assert.equal(before.shown, false);
    await tileOf(page).tap();
    const tapped = await probe(page);
    assert.ok(tapped.shown, `${width}px: a tap opens the details`);
    assert.ok(tapped.left >= 0 && tapped.right <= tapped.vw && tapped.bottom <= tapped.vh, `${width}px: the sheet is inside the window ${JSON.stringify(tapped)}`);
    assert.equal(tapped.over, 0, `${width}px: no sideways scroll`);
    assert.equal(tapped.url, before.url, `${width}px: a tap does not leave the board`);
    assert.equal(await tileOf(page).getAttribute('aria-expanded'), 'true');
    assert.ok((await page.locator(`${tileSelector} [data-stub-close]`).boundingBox()).height >= 44, `${width}px: a Close button of touch size`);
    await page.locator(`${tileSelector} [data-stub-close]`).tap();
    assert.equal((await probe(page)).shown, false, `${width}px: Close closes it`);
    await context.close();
  }
} finally {
  await portal.stop();
  await browser.close();
}
f.db.close();
f.env.cleanup();
console.log('PASS (identity) with a 2025 board and a Faith Promise 2026 the Giving Board is 2025; a Giving Board date is QAR 300 everywhere (constant, form, blank amount, claim, seed)');
console.log('PASS (detail) an administrator sees member, Member ID, commitment, received, balance, status and a way in from ledger figures; members and leaders see none of it');
console.log('PASS (interaction) hover and keyboard focus show the card on a desktop; a tap opens a bottom sheet at 320, 375 and 768 px with a Close button, inside the window, without leaving the board');
console.log('PASS (payment date) a payment entered today for a date months ago keeps its payment date apart from its recorded-at');
console.log('ALL PASS');
