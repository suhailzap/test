import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * A change and the audit row that records it are one act. If the audit row cannot be written, the change must not stay behind with an error on
 * the screen (the person would retry and make it twice, and the log would not know it happened once). The audit table is made to refuse every
 * insert, then each meaningful change is attempted through its real route: the response must be a refusal or an error AND every table in the
 * database must be exactly as it was. A route that succeeds without writing its audit row is a finding as well.
 */

const f = await buildPortalFixture('cciq-audit-atomic-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
mods.setSetting('attendance.tracking_start_date', mods.dates.addDays(ids.friday, -14));
for (const { id, status } of db.prepare('SELECT id, status FROM members').all()) {
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run('2020-01-01T09:00:00.000Z', '2020-01-01', id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(id, status, 'planted', '2020-01-01T09:00:00.000Z');
}
const claim = mods.ecaq.createClaim({ campaignId: ids.board, date: mods.ecaq.boardDates(Number(today.slice(0, 4)))[4], memberId: ids.member.a3, commitmentAmount: 100, userId: users.churchAdmin.id }).claim.id;
const visitor = mods.visitors.createVisitor({ first_name: 'Atomic', last_name: 'Guest', first_visit_date: mods.dates.addDays(today, -10) }, { userId: users.churchAdmin.id });
const payment = mods.ecaq.addPayment(claim, { amount: 5, paid_on: today }, { userId: users.churchAdmin.id }).payment.id;
const extraUser = db.prepare("SELECT id FROM users WHERE username = 'fx_member_b'").get().id;
const env = (await import('../config/env.js')).default;
const portal = await startPortal();
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
const token = await admin.csrf('/');
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").all().map((r) => r.name).filter((n) => !['sessions', 'audit_logs', 'rate_limits'].includes(n));
const snapshot = () => JSON.stringify(tables.map((t) => [t, db.prepare(`SELECT * FROM ${t}`).all()]));
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const docRow = db.prepare('SELECT title, category_id FROM documents WHERE id = ?').get(ids.document);
mods.documents.ensureCategories();
const docTitle = docRow.title; const docCategory = mods.documents.listCategories()[0].id;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const replaceTarget = mods.documents.createDocument({ title: 'Replace me' }, { userId: users.churchAdmin.id, file: { originalname: 'r.png', buffer: png, size: png.length } }).id;
const releaseClaim = mods.ecaq.createClaim({ campaignId: ids.board, date: mods.ecaq.boardDates(Number(today.slice(0, 4)))[9], memberId: ids.member.a2, commitmentAmount: 50, userId: users.churchAdmin.id }).claim.id;
const friday2 = db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(mods.dates.addDays(ids.friday, -7), '2026-01-01T09:00:00.000Z').lastInsertRowid;
const file = { name: 'a.pdf', type: 'application/pdf', buffer: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(300, 32)]) };

const FLOWS = [
  ['add member', '/members', { first_name: 'Atomic', last_name: 'Member', duplicate_override: '1', date_joined: today }],
  ['edit member', `/members/${ids.member.a3}`, { first_name: 'Andre', last_name: 'Changed' }],
  ['member status', `/members/${ids.member.a3}/status`, { status: 'inactive', reason: 'atomicity' }],
  ['member cell group', `/members/${ids.member.free}/cell-group`, { cell_group_id: String(ids.groupA), role_in_group: 'member' }],
  ['record a First Timer', '/visitors', { first_name: 'Never', last_name: 'Saved', first_visit_date: today }],
  ['First Timer visit', `/visitors/${visitor.id}/visits`, { visit_date: today }],
  ['First Timer follow-up', `/visitors/${visitor.id}/follow-up`, { follow_up_state: 'contacted' }],
  ['First Timer status', `/visitors/${visitor.id}/state`, { state: 'declined' }],
  ['First Timer edit', `/visitors/${visitor.id}`, { first_name: 'Atomic', last_name: 'Edited', first_visit_date: mods.dates.addDays(today, -10) }],
  ['Convert', `/visitors/${visitor.id}/convert`, { first_name: 'Atomic', last_name: 'Guest', date_joined: today, duplicate_override: '1' }],
  ['activity', '/activities', { title: 'Atomic activity', scope: 'church', status: 'draft' }],
  ['announcement', '/announcements', { title: 'Atomic notice', body: 'x', audience: 'all', priority: 'normal', status: 'published' }],
  ['ministry', '/ministries', { name: 'Atomic Ministry' }],
  ['ministry member', `/ministries/${ids.ministry}/members`, { member_id: String(ids.member.free), role: 'member' }],
  ['cell group', '/cell-groups', { name: 'Atomic Group', status: 'active' }],
  ['cell group member', `/cell-groups/${ids.groupB}/members`, { member_id: String(ids.member.a3) }],
  ['family group', '/family-groups', { name: 'Atomic Family', first_member_id: String(ids.member.gone) }],
  ['family member', `/family-groups/${ids.family}/members`, { member_id: String(ids.member.b2) }],
  ['attendance marks', `/attendance/sessions/${ids.session}/records`, { [`status_${ids.member.a2}`]: 'present' }],
  ['attendance session', '/attendance/sessions', { title: 'Atomic meeting', service_type: 'cell_group', cell_group_id: String(ids.groupB), service_date: today }],
  ['finalize', `/attendance/sessions/${ids.session}/finalize`, { confirm_no_attendance: 'on' }],
  ['not taken', `/attendance/sessions/${friday2}/not-taken`, { note: 'atomic' }],
  ['ECAQ campaign', '/admin/ecaq/campaigns', { name: 'Atomic Board', year: String(Number(today.slice(0, 4)) + 1), type: 'giving_board', amount_per_date: '50', status: 'draft', currency: 'QAR', privacy_mode: 'first_name' }],
  ['ECAQ payment', `/admin/ecaq/claims/${claim}/payments`, { amount: '10', paid_on: today, method: 'cash' }],
  ['ECAQ payment correction', `/admin/ecaq/payments/${payment}`, { amount: '12', paid_on: today, method: 'cash', reason: 'atomic' }],
  ['ECAQ payment delete', `/admin/ecaq/payments/${payment}/delete`, { reason: 'atomic' }],
  ['ECAQ claim release', `/admin/ecaq/claims/${releaseClaim}/release`, { reason: 'atomic' }],
  ['reminder', `/reminders/${ids.reminder}/state`, { state: 'acknowledged', current_state: 'new' }],
  ['user created', '/admin/users', { email: 'atomic.user@fixture.invalid', display_name: 'Atomic User', username: 'atomic_user', roles: 'member' }],
  ['user disabled', `/admin/users/${extraUser}/status`, { status: 'disabled' }],
  ['user password reset', `/admin/users/${extraUser}/password`, {}],
  ['document archive', `/documents/${ids.document}/archive`, {}],
  ['document delete', `/documents/${ids.document}/delete`, { confirm: docTitle }, { afterFailed: () => assert.ok(fs.existsSync(path.join(env.storageDir, 'documents', String(ids.document))), 'a deletion that was rolled back keeps the file of its document') }],
  ['document upload', '/documents', { title: 'Atomic upload', category_id: String(docCategory) }, { upload: { ...file, field: 'file' } }],
  ['document replace', `/documents/${replaceTarget}/replace`, { note: 'atomic' }, { upload: { ...file, field: 'file' } }],
  ['document category', '/documents/categories', { name: 'Atomic category' }],
  ['settings', '/admin/settings', { section: 'attendance', attendance__followup_threshold: '4' }]
];

const findings = []; const reached = []; const succeededWithoutAudit = []; const invalidPayloads = [];
const TRIGGER = "CREATE TRIGGER fail_every_audit BEFORE INSERT ON audit_logs BEGIN SELECT RAISE(ABORT, 'injected audit failure'); END;";
try {
  for (const [label, url, fields, options = {}] of FLOWS) {
    const send = async () => { const res = options.upload ? await admin.upload(url, options.upload, { field: options.upload.field, fields, csrf: token }) : await admin.post(url, fields, { csrf: token }); res.bodyText = await res.text(); return res; };
    // 1. the audit table refuses: nothing may stay changed
    db.exec(TRIGGER);
    const before = snapshot();
    let res;
    try { res = await send(); } catch (e) { findings.push(`${label}: request failed (${e.message})`); db.exec('DROP TRIGGER IF EXISTS fail_every_audit'); continue; }
    const after = snapshot();
    db.exec('DROP TRIGGER IF EXISTS fail_every_audit');
    if (options.afterFailed) options.afterFailed();
    if (after !== before) {
      if (res.status >= 400) findings.push(`${label}: answered ${res.status} but CHANGED data (the audit row failed after the change was committed)`);
      else succeededWithoutAudit.push(`${label} (${res.status} ${res.headers.get('location') || ''})`);
    } else reached.push(label);
    // 2. the same request for real must change something and write an audit row (so the payload above was a genuine, valid change)
    if (!options.skipReal) {
      const mark = count('SELECT COALESCE(MAX(id), 0) n FROM audit_logs');
      const prior = snapshot();
      const real = await send();
      if (snapshot() === prior || count('SELECT COUNT(*) n FROM audit_logs WHERE id > ?', mark) === 0) {
        // say WHY the real request did nothing, so a wrong payload is easy to correct
        const where = real.headers.get('location');
        const page = where ? await (await admin.get(where)).text() : '';
        const why = (/class="alert alert--(?:error|info)[^>]*>[sS]*?<p>([^<]+)/.exec(page) || [])[1] || '';
        const summary = /data-error-summary[\s\S]*?<\/ul>/.exec(real.bodyText || '')?.[0]?.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ') || '';
        invalidPayloads.push(`${label} (${real.status} ${where || ''} ${why.trim()} ${summary.trim()})`);
      }
    }
  }
} finally {
  db.exec('DROP TRIGGER IF EXISTS fail_every_audit');
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log(`INFO ${reached.length} of ${FLOWS.length} changes left the database untouched when their audit row failed: ${reached.join(', ')}`);
if (succeededWithoutAudit.length) console.log(`FINDING changes that were KEPT although their audit row failed (success shown, no audit): ${succeededWithoutAudit.join('; ')}`);
if (findings.length) console.log(findings.join('\n'));
if (invalidPayloads.length) console.log('INVALID TEST PAYLOADS (the real request changed nothing): ' + invalidPayloads.join('; '));
assert.deepEqual(invalidPayloads, [], 'every flow here is a genuine change when the audit table works');
assert.deepEqual(findings, [], 'no change is left behind by a failed audit write');
assert.deepEqual(succeededWithoutAudit, [], 'no change survives a failed audit write');
console.log('PASS (audit atomicity) every meaningful change is all-or-nothing with its audit row');
console.log('ALL PASS');
