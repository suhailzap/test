import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Backup and restore under conditions the other suites do not use:
 *   - the whole portal living in folders with spaces, accents and brackets (the way a Windows church computer often is);
 *   - several backups started at the same instant;
 *   - a backup folder that has vanished, or that is a file;
 *   - the free-space check when the operating system cannot answer (it must not block a backup it cannot judge);
 *   - a full restore performed by a separate process in that awkward location, ending with the backup's data in place.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-backup-extra-');
// move every data path into folders with spaces, accents and brackets (still under the OS temp folder, still disposable)
const awkward = path.join(os.tmpdir(), `cciq backup éxtra (${process.pid}) ${Date.now()}`);
const dirs = { databaseFile: path.join(awkward, 'data dir', 'cciq dév.sqlite'), storageDir: path.join(awkward, 'störage dir'), backupDir: path.join(awkward, 'back ups [weekly]') };
fs.mkdirSync(path.dirname(dirs.databaseFile), { recursive: true });
Object.assign(process.env, { DATABASE_FILE: dirs.databaseFile, STORAGE_DIR: dirs.storageDir, BACKUP_DIR: dirs.backupDir });

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { createMember } = await import('../services/members.js');
const backups = await import('../services/backups.js');
const space = await import('../lib/disk-space.js');
const { default: db } = await import('../db/index.js');
const config = (await import('../config/env.js')).default;
assert.equal(config.databaseFile, dirs.databaseFile, 'the portal really is using the awkward paths');
fs.mkdirSync(path.join(dirs.storageDir, 'members'), { recursive: true });
fs.writeFileSync(path.join(dirs.storageDir, 'members', 'marker.txt'), 'before');
createMember({ first_name: 'Original', last_name: 'Person' }, { status: 'active' });

try {
  // ---- 1. several backups at the same instant -------------------------------------------------------------------------------------------------
  const results = await Promise.all([1, 2, 3, 4].map((n) => backups.createBackup({ note: `parallel ${n}` })));
  assert.ok(results.every((r) => r.ok), `all four succeed: ${results.map((r) => r.reason || 'ok').join(', ')}`);
  const names = results.map((r) => r.backup.filename);
  assert.equal(new Set(names).size, 4, 'each has its own file name (no two overwrite each other)');
  for (const r of results) {
    assert.ok(fs.existsSync(path.join(dirs.backupDir, r.backup.filename)), 'and its file exists in the awkward folder');
    assert.equal(backups.verifyBackup(r.backup).ok, true, 'and matches its recorded checksum');
    assert.equal((await backups.deepVerifyBackup(r.backup)).ok, true, 'and opens as a real database with its files');
  }
  const leftovers = fs.readdirSync(dirs.backupDir).filter((n) => n.endsWith('.staging') || n === '.restore-extract');
  assert.deepEqual(leftovers, [], 'no staging folder is left behind');
  console.log('PASS (1) four backups started together get four different files, all verify and deep-verify, in a folder with spaces, accents and brackets; nothing is left staged');

  // ---- 2. the free-space probe cannot answer -----------------------------------------------------------------------------------------------------
  {
    const real = fs.statfsSync;
    fs.statfsSync = () => { throw new Error('probe failed'); };
    try {
      assert.equal(space.freeBytesAt(dirs.backupDir), null, 'an unanswerable probe is "unknown", not zero');
      const check = space.checkFreeSpace(dirs.backupDir, 10 * 1024 ** 3);
      assert.deepEqual([check.ok, check.unknown], [true, true], 'and an unknown never blocks');
      const made = await backups.createBackup({ note: 'probe cannot answer' });
      assert.equal(made.ok, true, 'a backup still goes ahead when free space cannot be measured');
    } finally { fs.statfsSync = real; }
    console.log('PASS (2) when the operating system cannot report free space, the check says "unknown" and the backup goes ahead');
  }

  // ---- 3. the backup folder vanishes, or is a file ---------------------------------------------------------------------------------------------------
  {
    fs.rmSync(dirs.backupDir, { recursive: true, force: true });
    const made = await backups.createBackup({ note: 'folder was gone' });
    assert.equal(made.ok, true, 'a missing backup folder is recreated');
    assert.ok(fs.existsSync(path.join(dirs.backupDir, made.backup.filename)));
    fs.rmSync(dirs.backupDir, { recursive: true, force: true });
    fs.writeFileSync(dirs.backupDir, 'a file where the folder should be');
    let outcome; try { outcome = await backups.createBackup({ note: 'folder is a file' }); } catch (err) { outcome = { threw: err }; }
    fs.rmSync(dirs.backupDir, { force: true }); fs.mkdirSync(dirs.backupDir, { recursive: true });
    if (outcome.threw) assert.match(String(outcome.threw.code || outcome.threw.message), /EEXIST|ENOTDIR/, 'creating the folder fails with a plain file-system error, nothing else');
    else assert.equal(outcome.ok, false, 'or the attempt is reported as failed');
    const pending = db.prepare("SELECT COUNT(*) n FROM backups WHERE status = 'pending'").get().n;
    assert.equal(pending, 0, 'no attempt is left "pending"');
    assert.equal((await backups.createBackup({ note: 'after' })).ok, true, 'and the next backup works once the folder is right');
    console.log('PASS (3) a vanished backup folder is recreated; a file in its place fails cleanly, leaves nothing pending, and the next backup works');
  }

  // ---- 4. a real restore by another process, in the awkward location ------------------------------------------------------------------------------
  {
    const target = (await backups.createBackup({ note: 'to restore' })).backup;
    createMember({ first_name: 'After', last_name: 'Backup' }, { status: 'active' });
    fs.writeFileSync(path.join(dirs.storageDir, 'members', 'marker.txt'), 'after');
    const memberCount = () => db.prepare('SELECT COUNT(*) n FROM members').get().n;
    assert.equal(memberCount(), 2);
    db.close(); // the separate process takes over the database (on Windows an open handle would lock the files)
    const script = `
      const { restoreBackup } = await import(${JSON.stringify(pathToFileURL(path.join(root, 'src/services/backups.js')).href)});
      const r = await restoreBackup(${target.id}, { userId: null, reason: 'extra' });
      console.log(JSON.stringify({ ok: r.ok, reason: r.reason || null }));
      process.exit(0);`;
    const run = spawnSync(process.execPath, ['--input-type=module', '-e', script], { encoding: 'utf8', env: process.env, cwd: root });
    const last = (run.stdout || '').trim().split('\n').pop();
    assert.ok(last && JSON.parse(last).ok === true, `the restore succeeded: ${last} ${String(run.stderr).slice(0, 300)}`);
    const Database = (await import('better-sqlite3')).default;
    const conn = new Database(dirs.databaseFile, { readonly: true });
    assert.equal(conn.prepare('SELECT COUNT(*) n FROM members').get().n, 1, 'the database is the backup\'s (one member, not two)');
    assert.equal(conn.prepare("SELECT COUNT(*) n FROM backup_restores WHERE status = 'completed' OR status = 'success'").get().n >= 0, true);
    conn.close();
    assert.equal(fs.readFileSync(path.join(dirs.storageDir, 'members', 'marker.txt'), 'utf8'), 'before', 'the stored files are the backup\'s too');
    assert.deepEqual(fs.readdirSync(path.dirname(dirs.databaseFile)).filter((n) => /restore-staged|\.shadow|\.bak|pre-restore/.test(n)), [], 'no staged database copy is left');
    assert.deepEqual(fs.readdirSync(dirs.storageDir).filter((n) => /pre-restore|\.shadow|restore/.test(n)), [], 'no old or staged storage folder is left');
    assert.ok(fs.readdirSync(dirs.backupDir).some((n) => n.endsWith('.tar.gz')), 'and a safety backup of the pre-restore state exists in the backup folder');
    console.log('PASS (4) a full restore by a separate process, in folders with spaces, accents and brackets, puts the backup\'s database and files back and leaves nothing staged');
  }
  console.log('ALL PASS');
} catch (err) { console.error("TEST ERROR", err); process.exitCode = 1; } finally {
  try { db.close(); } catch { /* the restore closed it in the other process only */ }
  fs.rmSync(awkward, { recursive: true, force: true });
  void env;
}
