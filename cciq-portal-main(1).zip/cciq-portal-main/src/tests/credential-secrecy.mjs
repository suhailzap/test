import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness: independent adversarial review found that every
 * generated-password flow (new member account, admin "Add user", admin
 * password reset) displayed the plaintext credential via req.flash(),
 * which lives in the session object — persisted to the SQLite-backed
 * sessions table by express-session at the end of the request, however
 * briefly. Fixed with a short-lived, single-use, in-memory-only reveal
 * token (src/lib/credential-reveal.js): the redirect after creation/reset
 * carries only an opaque token, never the password itself, and the
 * destination page consumes (and deletes) it on read. This proves the
 * sessions table never contains the plaintext value at any point, that a
 * token cannot be replayed or used against a different account, and that
 * PASSWORD_MIN_LENGTH no longer breaks generation once raised past the old
 * fixed 16-character output.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-credential-secrecy-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser, generateInitialPassword } = await import('../services/users.js');
const { checkPasswordPolicy } = await import('../lib/passwords.js');
const { default: db } = await import('../db/index.js');

// --- Reveal token: single-use and account-scoped, at the module level. ---
{
  const { stashCredential, consumeCredential } = await import('../lib/credential-reveal.js');
  const token = stashCredential(42, 'UnitLevelSecret1234');
  assert.equal(consumeCredential(token, 99), null, 'a token must not reveal its password against the wrong account id');
  // The mismatched attempt above must not have left the token usable
  // afterward either - a wrong-id guess burns it, same as a correct read.
  assert.equal(consumeCredential(token, 42), null, 'a token must be single-use even after a failed (wrong-id) attempt consumed it');

  const token2 = stashCredential(42, 'UnitLevelSecret5678');
  assert.equal(consumeCredential(token2, 42), 'UnitLevelSecret5678', 'a correctly-scoped token must reveal its password exactly once');
  assert.equal(consumeCredential(token2, 42), null, 'a token must not reveal its password a second time');
  console.log('PASS: reveal tokens are single-use and account-scoped, confirmed at the module level');
}

// --- Length robustness at the default policy. ---
{
  const password = generateInitialPassword();
  assert.equal(checkPasswordPolicy(password).length, 0, 'a generated password must satisfy the active password policy');
  console.log('PASS: generateInitialPassword() output satisfies the default password policy');
}

// --- Length robustness against a RAISED policy (config is a per-process
//     singleton, so this runs in its own child process with
//     PASSWORD_MIN_LENGTH set before anything imports config/env.js). ---
{
  const { execFileSync } = await import('node:child_process');
  const script = `
    process.env.PASSWORD_MIN_LENGTH = '40';
    import('${pathToFileURL(path.join(root, 'src/services/users.js')).href}').then(async (users) => {
      const { checkPasswordPolicy } = await import('${pathToFileURL(path.join(root, 'src/lib/passwords.js')).href}');
      const pw = users.generateInitialPassword();
      if (pw.length < 40) throw new Error('generated password shorter than PASSWORD_MIN_LENGTH=40: ' + pw.length);
      if (checkPasswordPolicy(pw).length !== 0) throw new Error('generated password failed policy at length ' + pw.length);
      console.log('CHILD_OK:' + pw.length);
    }).catch((e) => { console.error(e.message); process.exit(1); });
  `;
  const scriptPath = path.join(env.root, 'length-robustness-child.mjs');
  const { writeFileSync } = await import('node:fs');
  writeFileSync(scriptPath, script);
  const out = execFileSync(process.execPath, [scriptPath], { encoding: 'utf8' });
  assert.ok(out.includes('CHILD_OK:'), `expected success marker, got: ${out}`);
  console.log(`PASS: R02 CONFIRMED FIXED — with PASSWORD_MIN_LENGTH=40, generateInitialPassword() still produces a valid password (${out.trim().split(':')[1]} chars), not a fixed 16`);
}

// --- Codex/independent verification (R02 P2): a minimum near the fixed
//     policy maximum (200) must still produce a password within BOTH
//     bounds - not merely "somewhere near" the minimum, since the previous
//     byte-sized-then-base64url-encoded approach could overshoot past the
//     maximum this close to it. ---
{
  const { execFileSync } = await import('node:child_process');
  const script = `
    process.env.PASSWORD_MIN_LENGTH = '195';
    import('${pathToFileURL(path.join(root, 'src/services/users.js')).href}').then(async (users) => {
      const { checkPasswordPolicy } = await import('${pathToFileURL(path.join(root, 'src/lib/passwords.js')).href}');
      const config = (await import('${pathToFileURL(path.join(root, 'src/config/env.js')).href}')).default;
      const pw = users.generateInitialPassword();
      if (pw.length < 195 || pw.length > config.auth.passwordMaxLength) {
        throw new Error('generated password length ' + pw.length + ' outside [195, ' + config.auth.passwordMaxLength + ']');
      }
      if (checkPasswordPolicy(pw).length !== 0) throw new Error('generated password failed policy at length ' + pw.length);
      console.log('CHILD_OK:' + pw.length);
    }).catch((e) => { console.error(e.message); process.exit(1); });
  `;
  const scriptPath = path.join(env.root, 'length-near-max-child.mjs');
  const { writeFileSync } = await import('node:fs');
  writeFileSync(scriptPath, script);
  const out = execFileSync(process.execPath, [scriptPath], { encoding: 'utf8' });
  assert.ok(out.includes('CHILD_OK:'), `expected success marker, got: ${out}`);
  console.log(`PASS: CODEX FINDING CONFIRMED FIXED (R02 P2) — with PASSWORD_MIN_LENGTH=195, generateInitialPassword() stays within both the configured minimum and the fixed policy maximum (${out.trim().split(':')[1]} chars)`);
}

// --- Codex/independent verification (R02 P2): PASSWORD_MIN_LENGTH set
//     ABOVE the fixed policy maximum must fail explicitly at startup
//     (config/env.js import), not silently produce a portal where every
//     generated password fails its own policy the moment someone tries to
//     create a user. ---
{
  const { spawnSync } = await import('node:child_process');
  const script = `
    process.env.PASSWORD_MIN_LENGTH = '250';
    await import('${pathToFileURL(path.join(root, 'src/config/env.js')).href}');
    console.log('UNEXPECTEDLY_SUCCEEDED');
  `;
  const scriptPath = path.join(env.root, 'contradictory-config-child.mjs');
  const { writeFileSync } = await import('node:fs');
  writeFileSync(scriptPath, script);
  const proc = spawnSync(process.execPath, [scriptPath], { encoding: 'utf8' });
  assert.notEqual(proc.status, 0, 'a PASSWORD_MIN_LENGTH above the fixed policy maximum must fail at startup, not succeed');
  assert.ok(!proc.stdout.includes('UNEXPECTEDLY_SUCCEEDED'));
  assert.match(proc.stderr, /PASSWORD_MIN_LENGTH.*cannot exceed/,
    'CODEX FINDING CONFIRMED FIXED (R02 P2): a contradictory PASSWORD_MIN_LENGTH must fail with a message that names the actual contradiction, not a generic later error');
  console.log('PASS: a PASSWORD_MIN_LENGTH above the fixed policy maximum fails explicitly at startup, naming the contradiction');
}

function anySessionContains(substring) {
  const rows = db.prepare('SELECT sess FROM sessions').all();
  return rows.some((row) => row.sess.includes(substring));
}
function anyAuditContains(substring) {
  const rows = db.prepare('SELECT detail FROM audit_logs').all();
  return rows.some((row) => row.detail && row.detail.includes(substring));
}

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;
const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

async function login(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preCookie;
}
async function csrfFor(urlPath, cookie) {
  const page = await fetch(`${base}${urlPath}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

await createUser({ email: 'admin.secrecy@fixture.invalid', password: 'AdminPassw0rd!2026', displayName: 'Admin Secrecy', roleKeys: ['super_admin'], mustChangePassword: false });
const adminCookie = await login('admin.secrecy@fixture.invalid', 'AdminPassw0rd!2026');

// Anchored to the reveal banner's own wording specifically - both
// destination views (user-form.ejs, members/show.ejs) also render other
// <strong> tags (e.g. the account's own username), which a bare
// /<strong>.../ regex would match first and mistake for the password.
function extractRevealedPassword(html) {
  const match = html.match(/One-time password[^<]*<\/p>\s*<p><strong>([^<]+)<\/strong>/);
  return match ? match[1] : null;
}

async function follow(res, cookie) {
  const location = res.headers.get('location');
  assert.ok(location, 'expected a redirect to a reveal URL');
  return fetch(`${base}${location}`, { headers: { Cookie: cookie } });
}

// --- 1. Admin "Add user" flow. ---
{
  const csrf = await csrfFor('/admin/users/new', adminCookie);
  const res = await fetch(`${base}/admin/users`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({
      display_name: 'New Admin Fixture', email: 'newadmin.secrecy@fixture.invalid',
      username: 'newadminsecrecy', roles: 'member', _csrf: csrf
    })
  });
  assert.equal(res.status, 302, 'account creation must still redirect (preserving existing UI navigation)');
  const revealUrl = res.headers.get('location');
  assert.match(revealUrl, /\?reveal=/, 'the redirect must carry a one-time reveal token, not the password itself');

  const page1 = await follow(res, adminCookie);
  const body1 = await page1.text();
  const password = extractRevealedPassword(body1);
  assert.ok(password, 'the password must actually be shown once on the destination page');
  assert.equal(anySessionContains(password), false, 'R02 CONFIRMED FIXED: the generated password must never appear in the sessions table');
  assert.equal(anyAuditContains(password), false, 'the generated password must never appear in audit_logs');

  // Reload the exact same reveal URL: the token is single-use, so it must not show again.
  const page2 = await fetch(`${base}${revealUrl}`, { headers: { Cookie: adminCookie } });
  const body2 = await page2.text();
  assert.equal(extractRevealedPassword(body2), null, 'a reveal token must not display the password a second time (single use)');
  console.log('PASS: "Add user" shows the password once via a single-use token, never touching the sessions table or audit log');
}

// --- 2. Admin password reset (generated). ---
{
  const targetId = await createUser({ email: 'reset.secrecy@fixture.invalid', password: 'ResetPassw0rd!2026', displayName: 'Reset Target', roleKeys: ['member'], mustChangePassword: false });
  const csrf = await csrfFor(`/admin/users/${targetId}`, adminCookie);
  const res = await fetch(`${base}/admin/users/${targetId}/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ _csrf: csrf }) // no manual password -> generated
  });
  assert.equal(res.status, 302);
  const revealUrl = res.headers.get('location');
  assert.match(revealUrl, /\?reveal=/);

  const page = await follow(res, adminCookie);
  const body = await page.text();
  const password = extractRevealedPassword(body);
  assert.ok(password, 'the reset password must be shown once, against the correct account id');
  assert.equal(anySessionContains(password), false, 'R02 CONFIRMED FIXED: a generated reset password must never appear in the sessions table');
  console.log('PASS: admin password reset (generated) shows the password once and never touches the sessions table');
}

// --- 3. Member creation with auto-provisioned account. ---
{
  const csrf = await csrfFor('/members/new', adminCookie);
  const res = await fetch(`${base}/members`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminCookie },
    body: new URLSearchParams({ first_name: 'Secrecy', last_name: 'Fixture', status: 'active', _csrf: csrf })
  });
  assert.equal(res.status, 302, `expected a redirect, got ${res.status}`);
  const revealUrl = res.headers.get('location');
  assert.match(revealUrl, /\?reveal=/);

  const page = await follow(res, adminCookie);
  const body = await page.text();
  const password = extractRevealedPassword(body);
  assert.ok(password, 'the provisioned member account password must be shown once');
  assert.equal(anySessionContains(password), false, 'R02 CONFIRMED FIXED: a provisioned member-account password must never appear in the sessions table');
  console.log('PASS: member creation with account provisioning shows the password once via a single-use token, never touching the sessions table');
}

// --- 4. Codex/independent verification (R02 P2): a Church Admin creating a
//     member (members.create - the default role does not hold admin.users)
//     must still see the one-time credential they just generated. The old
//     code computed the account used for the reveal ONLY when the viewer
//     held admin.users, so a Church Admin without it was redirected to a
//     reveal URL that silently showed nothing - the credential was
//     effectively lost, since the token is never re-shown or re-derivable. ---
{
  await createUser({
    email: 'churchadmin.secrecy@fixture.invalid', password: 'ChurchAdminPassw0rd!2026',
    displayName: 'Church Admin Secrecy', roleKeys: ['church_admin'], mustChangePassword: false
  });
  const churchAdminCookie = await login('churchadmin.secrecy@fixture.invalid', 'ChurchAdminPassw0rd!2026');
  const { loadUserContext, findUserByEmail } = await import('../services/users.js');
  const churchAdminUser = findUserByEmail('churchadmin.secrecy@fixture.invalid');
  assert.equal(loadUserContext(churchAdminUser.id).can('admin.users'), false,
    'sanity: the default Church Admin role must not hold admin.users, or this test proves nothing');

  const csrf = await csrfFor('/members/new', churchAdminCookie);
  const res = await fetch(`${base}/members`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: churchAdminCookie },
    body: new URLSearchParams({ first_name: 'ChurchAdminCreated', last_name: 'Fixture', status: 'active', _csrf: csrf })
  });
  assert.equal(res.status, 302, `expected a redirect, got ${res.status}`);
  const revealUrl = res.headers.get('location');
  assert.match(revealUrl, /\?reveal=/);

  const page = await follow(res, churchAdminCookie);
  const body = await page.text();
  const password = extractRevealedPassword(body);
  assert.ok(password,
    'CODEX FINDING CONFIRMED FIXED (R02 P2): a Church Admin without admin.users must still see the one-time credential for a member account they just created');
  assert.equal(anySessionContains(password), false, 'the provisioned password must still never appear in the sessions table');
  console.log('PASS: a Church Admin without admin.users still sees the one-time credential for a member account they just created');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
