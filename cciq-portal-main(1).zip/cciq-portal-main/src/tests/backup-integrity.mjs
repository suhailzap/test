import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Go-live readiness: a failed or corrupted backup must never be mistaken
 * for a good one, and a bad backup attempt must never destroy an earlier
 * good one. This exercises the real backup/verify/prune/restore code
 * (src/services/backups.js) against corrupted, truncated, and incomplete
 * archives built from a real backup this same suite creates - never
 * against production, never against real production backups.
 */

const env = createIsolatedTestEnv('cciq-backup-integrity-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const {
  createBackup, deepVerifyBackup, verifyBackup, pruneBackups, listBackups, getBackup, resolveBackupFile
} = await import('../services/backups.js');
const { default: db } = await import('../db/index.js');
const config = (await import('../config/env.js')).default;

createMember({ first_name: 'Fixture', last_name: 'Member' }, { status: 'active' });

// --- A real, good backup as the baseline every corruption test starts from. ---
const good = await createBackup({ kind: 'manual', note: 'integrity test fixture' });
assert.ok(good.ok, 'a normal backup must succeed against a healthy database');
const goodFile = resolveBackupFile(good.backup.filename);
assert.ok(fs.existsSync(goodFile), 'the backup file must actually exist on disk');

const goodVerify = await deepVerifyBackup(good.backup);
assert.ok(goodVerify.ok, 'a genuinely good backup must pass deep verification');
assert.ok(goodVerify.migrationVersion, 'deep verification must report a real migration version from inside the archive');
console.log(`PASS: a normal backup is created and passes deep verification (migration ${goodVerify.migrationVersion})`);

// --- Corrupted archive: flip bytes in the middle of a copy of the good file. ---
function makeCorruptCopy(suffix, mutate) {
  const name = good.backup.filename.replace('.tar.gz', `-${suffix}.tar.gz`);
  const dest = path.join(config.backupDir, name);
  fs.copyFileSync(goodFile, dest);
  mutate(dest);
  return name;
}

const corruptName = makeCorruptCopy('corrupt', (dest) => {
  const buf = fs.readFileSync(dest);
  for (let i = 100; i < 200 && i < buf.length; i += 1) buf[i] = buf[i] ^ 0xff;
  fs.writeFileSync(dest, buf);
});
const corruptRow = { ...good.backup, filename: corruptName, checksum: good.backup.checksum }; // stale checksum on purpose
const corruptVerify = await deepVerifyBackup(corruptRow);
assert.equal(corruptVerify.ok, false, 'a byte-corrupted archive must fail verification, never pass');
console.log(`PASS: a corrupted archive fails deep verification (reason: ${corruptVerify.reason})`);

const corruptChecksum = verifyBackup(corruptRow);
assert.equal(corruptChecksum.ok, false, 'checksum verification must also catch the same corruption');
console.log('PASS: checksum verification independently catches the same corruption');

// --- Truncated archive: cut it off partway through. ---
const truncatedName = makeCorruptCopy('truncated', (dest) => {
  const buf = fs.readFileSync(dest);
  fs.writeFileSync(dest, buf.subarray(0, Math.floor(buf.length / 3)));
});
const truncatedVerify = await deepVerifyBackup({ ...good.backup, filename: truncatedName });
assert.equal(truncatedVerify.ok, false, 'a truncated archive must fail verification, never pass');
console.log(`PASS: a truncated archive fails deep verification (reason: ${truncatedVerify.reason})`);

// --- Missing manifest: build an archive with only the database, no manifest.json. ---
{
  const tar = await import('tar');
  const os = await import('node:os');
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-nomani-'));
  // A plain file copy of a WAL-mode database can miss committed data still
  // sitting in the -wal file — the same reason createBackup() uses
  // db.backup() rather than fs.copyFileSync. Matching that here too, so
  // this fixture's database is genuinely valid except for the one thing
  // being tested (the missing manifest).
  await db.backup(path.join(work, 'database.sqlite'));
  const name = 'no-manifest.tar.gz';
  await tar.create({ gzip: true, file: path.join(config.backupDir, name), cwd: work }, ['database.sqlite']);
  fs.rmSync(work, { recursive: true, force: true });
  const result = await deepVerifyBackup({ ...good.backup, filename: name });
  assert.equal(result.ok, false, 'an archive with no manifest must fail verification, never pass');
  assert.equal(result.reason, 'no_manifest');
  console.log('PASS: an archive missing manifest.json fails verification with a clear reason');
}

// --- Damaged database inside an otherwise well-formed archive. ---
{
  const tar = await import('tar');
  const os = await import('node:os');
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-baddb-'));
  const badDb = Buffer.alloc(4096, 0); // looks nothing like a real SQLite file
  fs.writeFileSync(path.join(work, 'database.sqlite'), badDb);
  fs.writeFileSync(path.join(work, 'manifest.json'), JSON.stringify({
    format: 'cciq-portal-archive', version: 1, database: 'database.sqlite', storage_folders: []
  }));
  const name = 'bad-database.tar.gz';
  await tar.create({ gzip: true, file: path.join(config.backupDir, name), cwd: work }, ['manifest.json', 'database.sqlite']);
  fs.rmSync(work, { recursive: true, force: true });
  const result = await deepVerifyBackup({ ...good.backup, filename: name });
  assert.equal(result.ok, false, 'an archive whose database is not a real SQLite file must fail verification');
  console.log(`PASS: a damaged/fake database inside the archive fails verification (reason: ${result.reason})`);
}

// --- Manifest claims a storage folder that isn't actually in the archive. ---
{
  const tar = await import('tar');
  const os = await import('node:os');
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-missingfolder-'));
  await db.backup(path.join(work, 'database.sqlite')); // WAL-safe, see the no-manifest fixture above
  fs.writeFileSync(path.join(work, 'manifest.json'), JSON.stringify({
    format: 'cciq-portal-archive', version: 1, database: 'database.sqlite', storage_folders: ['members']
  }));
  // Deliberately no storage/ directory at all, despite the manifest claiming one.
  const name = 'missing-storage-folder.tar.gz';
  await tar.create({ gzip: true, file: path.join(config.backupDir, name), cwd: work }, ['manifest.json', 'database.sqlite']);
  fs.rmSync(work, { recursive: true, force: true });
  const result = await deepVerifyBackup({ ...good.backup, filename: name });
  assert.equal(result.ok, false, 'a manifest claiming a storage folder that is not present must fail verification');
  assert.match(result.reason, /missing_storage_folders/);
  console.log('PASS: a manifest overclaiming its own storage contents fails verification');
}

// --- A missing file entirely (backup row exists, file does not). ---
{
  const result = await deepVerifyBackup({ ...good.backup, filename: 'does-not-exist.tar.gz' });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'missing');
  console.log('PASS: a backup row pointing at a nonexistent file fails verification cleanly, not a crash');
}

// --- Retention must never remove a backup beyond what is asked, must skip
//     pre_restore copies, and must never touch a corrupted-but-still-listed
//     backup any differently from a good one (pruning is about age, not
//     validity - deepVerifyBackup(), not pruneBackups(), is what judges
//     validity, and a failed scheduled run must skip pruning entirely,
//     which scheduled-backup.mjs already does by only calling it after a
//     successful verification). ---
{
  const before = listBackups({ limit: 1000 }).length;
  const removed = pruneBackups({ keep: before }); // keep everything that exists right now
  assert.equal(removed.length, 0, 'pruning with keep == current count must remove nothing');
  const removedOne = pruneBackups({ keep: before - 1 });
  assert.equal(removedOne.length, 1, 'pruning with keep one less than the current count must remove exactly one');
  console.log('PASS: pruneBackups() removes exactly as many backups as requested, never more');
}

// --- Concurrency: scheduled-backup.mjs's PID lock must prevent two
//     concurrent runs from racing each other, and must recover from a
//     stale lock left by a run that didn't exit cleanly. ---
db.close();
{
  const lockFile = path.join(config.backupDir, '.scheduled-backup.lock');
  fs.writeFileSync(lockFile, '999999999'); // a PID that cannot possibly be a live process
  const out = execSync(`node "${path.join(process.cwd(), 'scripts', 'scheduled-backup.mjs')}"`, {
    env: process.env, encoding: 'utf8'
  });
  assert.match(out, /stale lock/, 'a stale lock (dead PID) must be detected and removed, not block forever');
  assert.match(out, /scheduled backup complete/, 'the run must still complete successfully after clearing a stale lock');
  assert.ok(!fs.existsSync(lockFile) || fs.readFileSync(lockFile, 'utf8').trim() === '',
    'the lock file must not be left behind pointing at a dead PID after a successful run');
  console.log('PASS: a stale lock from a crashed run is detected and does not block a new scheduled backup');
}

env.cleanup();
console.log('ALL PASS');
