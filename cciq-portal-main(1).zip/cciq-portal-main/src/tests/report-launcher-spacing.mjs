import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Reports -> Print a report: every launcher, opened, has one calm rhythm and nothing touches or overlaps.
 *   - the buttons start 16 to 24px below the last field and sit 8 to 12px apart (also when they wrap onto a second line);
 *   - consecutive blocks inside a form never overlap or touch (a helper line sits tight under what it explains, never on top of the buttons);
 *   - the helper line under the Giving buttons keeps clear of them;
 *   - label to control is the shared 6px; no sideways scroll at any width.
 */

const f = await buildPortalFixture('cciq-launcher-spacing-');
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const problems = [];
try {
  const admin = await signIn(portal.base, f.users.superAdmin.email, f.PASSWORD);
  for (const width of [320, 375, 390, 430, 768, 1024, 1280, 1440]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } });
    await context.addCookies(admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.goto(`${portal.base}/reports/print`, { waitUntil: 'load' });
    await page.evaluate(() => document.querySelectorAll('details.report-launcher').forEach((d) => { d.open = true; }));
    const result = await page.evaluate(() => {
      const r = (el) => el.getBoundingClientRect();
      const out = { launchers: 0, scroll: document.documentElement.scrollWidth - document.documentElement.clientWidth, issues: [] };
      for (const d of document.querySelectorAll('details.report-launcher')) {
        out.launchers += 1;
        const name = d.querySelector('.report-launcher__name').textContent.trim();
        const body = d.querySelector('.report-launcher__body');
        const form = body.querySelector('form');
        const kids = [...form.children].filter((el) => el.type !== 'hidden' && r(el).height > 0);
        for (let i = 1; i < kids.length; i += 1) {
          const gap = Math.round(r(kids[i]).top - r(kids[i - 1]).bottom);
          if (gap < 4) out.issues.push(`${name}: block ${i} is only ${gap}px below the one above`);
        }
        const actions = form.querySelector(':scope > .row-actions');
        if (!actions) { out.issues.push(`${name}: no buttons row`); continue; }
        const before = kids[kids.indexOf(actions) - 1];
        if (before) {
          const gap = Math.round(r(actions).top - r(before).bottom);
          if (gap < 16 || gap > 24) out.issues.push(`${name}: buttons are ${gap}px below the last field (want 16-24)`);
        }
        const btns = [...actions.children];
        for (let i = 1; i < btns.length; i += 1) {
          const a = r(btns[i - 1]); const b = r(btns[i]);
          const sameRow = Math.abs(a.top - b.top) < 4;
          const gap = Math.round(sameRow ? b.left - a.right : b.top - a.bottom);
          if (gap < 8 || gap > 12) out.issues.push(`${name}: buttons ${sameRow ? 'side by side' : 'wrapped'} are ${gap}px apart (want 8-12)`);
        }
        for (const label of form.querySelectorAll('.field > label')) {
          const control = label.parentElement.querySelector('select, input:not([type=checkbox]):not([type=hidden])');
          if (control && label.parentElement.contains(control) && r(control).top >= r(label).bottom) {
            const gap = Math.round(r(control).top - r(label).bottom);
            if (gap < 4 || gap > 8) out.issues.push(`${name}: label to control ${gap}px (want 4-8)`);
          }
        }
        const hint = body.querySelector(':scope > .fieldset__hint');
        if (hint) {
          const gap = Math.round(r(hint).top - r(form).bottom);
          if (gap < 12) out.issues.push(`${name}: helper text is ${gap}px below the buttons (want 12 or more)`);
        }
      }
      return out;
    });
    assert.ok(result.launchers >= 6, `launchers present at ${width}px`);
    if (result.scroll > 0) problems.push(`${width}px sideways scroll ${result.scroll}px`);
    for (const issue of result.issues) problems.push(`${width}px ${issue}`);
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('\n'));
  console.log('PASS (rhythm) launcher forms: 16-24px to the buttons, 8-12px between buttons, nothing touching or overlapping, no sideways scroll, 320 to 1440 px');
  console.log('PASS report-launcher-spacing');
} finally { await browser.close(); await portal.stop(); }
