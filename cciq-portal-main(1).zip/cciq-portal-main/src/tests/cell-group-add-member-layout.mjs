import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Cell group > Members > "Add a member to this group", in a real browser at every practical width.
 *
 * The form used to sit inside the generic .filters bar, whose "flex: 1 1 180px" on every .field gave the member picker a 180px HEIGHT: a disconnected
 * search box, a tall empty gap, and the role and button floating away from it. It is now its own grid (.add-member-form):
 *   wide     [ search (takes the width) ] [ role (compact) ] [ Add to group ]     on one row, controls aligned, no empty band
 *   tablet   search on its own row, role and action under it
 *   phone    one column, every control full width and usable
 * Behaviour is exactly what it was: the picker's search, keyboard use and selected state, the role choices, who may add, and the one-group / move / history rules.
 */

const f = await buildPortalFixture('cciq-addmember-layout-');
const { db, ids, users } = f;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const cookiesOf = (session) => session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; });
const url = `${portal.base}/cell-groups/${ids.groupA}?tab=members`;
const problems = [];

try {
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const context = await browser.newContext();
  await context.addCookies(cookiesOf(admin));

  const measure = (page) => page.evaluate(() => {
    const box = (el) => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height, bottom: r.bottom, right: r.right }; };
    const form = document.querySelector('#add-member-form');
    const picker = form.querySelector('[data-member-picker]');
    const input = form.querySelector('[data-picker-input]');
    const role = form.querySelector('#role_in_group');
    const button = form.querySelector('button[type=submit]');
    return {
      form: box(form), picker: box(picker), input: box(input), role: box(role), button: box(button),
      docOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      formOverflow: form.scrollWidth - form.clientWidth
    };
  });

  for (const width of [320, 360, 390, 430, 520, 521, 768, 820, 860, 861, 1024, 1280, 1440, 1920]) {
    const page = await context.newPage();
    await page.setViewportSize({ width, height: 900 });
    await page.goto(url, { waitUntil: 'load' });
    const m = await measure(page);
    const label = `${width}px`;
    if (m.docOverflow > 0) problems.push(`${label}: the page scrolls sideways by ${m.docOverflow}px`);
    if (m.formOverflow > 0) problems.push(`${label}: the form overflows by ${m.formOverflow}px`);
    for (const [name, b] of [['search', m.input], ['role', m.role], ['button', m.button]]) {
      if (b.x < m.form.x - 1 || b.right > m.form.right + 1) problems.push(`${label}: the ${name} control leaves the form`);
      if (b.h < 36) problems.push(`${label}: the ${name} control is only ${Math.round(b.h)}px high`);
    }
    // no giant blank band: the picker is a label plus one control (about 70px), not 180px
    if (m.picker.h > 110) problems.push(`${label}: the member picker is ${Math.round(m.picker.h)}px high (a tall empty gap)`);
    // The layout follows the width of the card (the menu takes room beside it), so the three layouts are told apart by the form's own width.
    if (m.form.w >= 761) {
      const sameRow = Math.abs(m.input.y - m.role.y) < 6 && Math.abs(m.input.y - m.button.y) < 6;
      if (!sameRow) problems.push(`${label}: search, role and button are not on one row (${Math.round(m.input.y)}, ${Math.round(m.role.y)}, ${Math.round(m.button.y)})`);
      if (Math.abs((m.input.y + m.input.h) - (m.role.y + m.role.h)) > 3 || Math.abs((m.input.y + m.input.h) - (m.button.y + m.button.h)) > 3) problems.push(`${label}: the controls' bottoms do not line up`);
      if (m.input.w < m.role.w * 2) problems.push(`${label}: the search (${Math.round(m.input.w)}px) does not get most of the width (role ${Math.round(m.role.w)}px)`);
      if (m.role.w > 260) problems.push(`${label}: the role is not compact (${Math.round(m.role.w)}px)`);
      if (m.form.h > 110) problems.push(`${label}: the whole form is ${Math.round(m.form.h)}px high on a wide screen`);
    } else if (m.form.w > 420) {
      if (m.role.y <= m.input.y + m.input.h - 1) problems.push(`${label}: the role is not under the search on a tablet`);
      if (Math.abs(m.role.y - m.button.y) > 6) problems.push(`${label}: role and button are not on one row on a tablet`);
      if (m.input.w < m.form.w * 0.95) problems.push(`${label}: the search is not full width on a tablet`);
    } else {
      for (const [name, b] of [['search', m.input], ['role', m.role], ['button', m.button]]) {
        if (b.w < m.form.w * 0.95) problems.push(`${label}: the ${name} control is not full width on a phone (${Math.round(b.w)} of ${Math.round(m.form.w)})`);
      }
      if (!(m.input.bottom <= m.role.y && m.role.bottom <= m.button.y + 1)) problems.push(`${label}: the controls are not stacked in order on a phone`);
    }
    await page.close();
  }
  assert.deepEqual(problems, [], problems.join('\n'));
  console.log('PASS (layout) 14 widths from 320 to 1920 px: one aligned row on a wide screen (search takes the width, role compact), search then role+action on a tablet, a full-width stack on a phone; no overflow, no tall empty gap, every control at least 36px high');

  // ---- behaviour is unchanged ---------------------------------------------------------------------------------------------------------------------------------
  const page = await context.newPage();
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(url, { waitUntil: 'load' });
  const searchInput = page.locator('#group_member_id-search');
  // the label belongs to the input
  assert.equal(await page.locator('label[for="group_member_id-search"]').innerText(), 'Member');
  await searchInput.fill('Fred');
  await page.waitForSelector('.member-picker__result', { timeout: 10000 });
  assert.match(await page.locator('.member-picker__result').first().innerText(), /Fred/, 'the picker finds a member by typing');
  // someone already in the group is not offered
  await searchInput.fill('Anna');
  await page.waitForTimeout(700);
  assert.equal(await page.locator('.member-picker__result', { hasText: 'Anna' }).count(), 0, 'a member already in this group is not offered');
  // keyboard: type, arrow down into the results, Enter / click on the focused one selects
  await searchInput.fill('Fred');
  await page.waitForSelector('.member-picker__result', { timeout: 10000 });
  await searchInput.press('ArrowDown');
  assert.equal(await page.evaluate(() => document.activeElement.classList.contains('member-picker__result')), true, 'ArrowDown moves into the results');
  await page.keyboard.press('Enter');
  await page.waitForFunction(() => !document.querySelector('[data-picker-selected]').hidden, null, { timeout: 5000 });
  assert.match(await page.locator('[data-picker-selected-name]').innerText(), /Fred/, 'the selected member is shown');
  assert.equal(await page.locator('#add-member-form [data-picker-value]').inputValue(), String(ids.member.free));
  // the selected state keeps the row tidy (no giant gap, controls still on one row)
  const selected = await measure(page);
  assert.ok(selected.picker.h < 150, `the selected-member card is compact (${Math.round(selected.picker.h)}px)`);
  assert.ok(Math.abs((selected.role.y + selected.role.h) - (selected.button.y + selected.button.h)) < 3, 'role and button stay aligned with each other when someone is selected');
  // Change returns to the search; Clear empties it
  await page.locator('[data-picker-change]').click();
  assert.equal(await page.locator('[data-picker-search-area]').isVisible(), true);
  await searchInput.fill('Fred');
  await page.waitForSelector('.member-picker__result', { timeout: 10000 });
  await page.locator('.member-picker__result').first().click();
  await page.locator('[data-picker-clear]').click();
  assert.equal(await page.locator('#add-member-form [data-picker-value]').inputValue(), '', 'Clear empties the selection');
  // Escape closes the results
  await searchInput.fill('Fred');
  await page.waitForSelector('.member-picker__result', { timeout: 10000 });
  await searchInput.press('Escape');
  assert.equal(await page.locator('[data-picker-results]').isHidden(), true);
  // role choices are the group roles, and submitting adds the member with that role (moving nothing else)
  const options = await page.locator('#role_in_group option').allInnerTexts();
  assert.deepEqual(options, ['Leader', 'Assistant', 'Member'], 'every role choice is still offered');
  assert.equal(await page.locator('#role_in_group').inputValue(), 'member', 'the role defaults to Member, not Leader: Leader is a deliberate choice');
  await searchInput.fill('Fred');
  await page.waitForSelector('.member-picker__result', { timeout: 10000 });
  await page.locator('.member-picker__result').first().click();
  await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.locator('#add-member-form button[type=submit]').click()]);
  const row = db.prepare('SELECT cell_group_id FROM members WHERE id = ?').get(ids.member.free);
  assert.equal(row.cell_group_id, ids.groupA, 'the member was added to the group');
  assert.equal(db.prepare('SELECT role_in_group r FROM cell_group_members WHERE member_id = ? AND left_at IS NULL').get(ids.member.free).r, 'member', 'with the default role, Member');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM cell_group_members WHERE member_id = ? AND left_at IS NULL').get(ids.member.free).n, 1, 'and belongs to exactly one group');
  assert.match(await page.locator('main').innerText(), /Fred/);
  // a validation message still shows when nothing is chosen
  await page.goto(url, { waitUntil: 'load' });
  await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.locator('#add-member-form button[type=submit]').click()]);
  assert.match(await page.locator('main').innerText(), /Choose|select|member/i, 'submitting with nobody chosen says so');
  console.log('PASS (behaviour) search, "already in this group" exclusion, ArrowDown / Enter, Change, Clear, Escape, the role choices, adding with a role (one group only) and the empty-submit message all work as before, with the selected-member state still tidy');
  await page.close();

  // ---- who can see the form is unchanged -----------------------------------------------------------------------------------------------------------------------
  const leader = await signIn(portal.base, users.leaderA.email, f.PASSWORD);
  const leaderContext = await browser.newContext();
  await leaderContext.addCookies(cookiesOf(leader));
  const leaderPage = await leaderContext.newPage();
  await leaderPage.goto(url, { waitUntil: 'load' });
  assert.equal(await leaderPage.locator('#add-member-form').count(), 0, 'a Cell Group Leader (who cannot manage groups) is not offered the form');
  const forged = await leader.post(`/cell-groups/${ids.groupA}/members`, { member_id: String(ids.member.a3), role_in_group: 'member' }, { csrfFrom: `/cell-groups/${ids.groupA}?tab=members` });
  assert.ok([403, 404].includes(forged.status), `and a forged post is refused (${forged.status})`);
  console.log('PASS (authorization) the form is shown only to those who may manage groups; a forged post by a Leader is refused');
} finally {
  await browser.close();
  await portal.stop();
}
db.close();
f.env.cleanup();
console.log('ALL PASS');
