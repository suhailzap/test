import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Ministries -> Who is serving: server-side paging, search, cell group / ministry filters, sort,
 * counts and query state. Ministry business rules (who counts as serving, current population)
 * are unchanged - the figures at the top of the page are asserted to be the same as before.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-serving-list-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const { createGroup } = await import('../services/cell-groups.js');
const ministries = await import('../services/ministries.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Ms${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'serve_admin', email: 'serve.admin@fixture.invalid', password: PASSWORD, displayName: 'Serve Admin', roleKeys: ['church_admin'], mustChangePassword: false });
const groups = [createGroup({ name: 'Serve Group A' }), createGroup({ name: 'Serve Group B' })];
const choir = ministries.createMinistry({ name: 'Choir' });
const ushers = ministries.createMinistry({ name: 'Ushers' });
const media = ministries.createMinistry({ name: 'Media' });
const members = [];
for (let i = 1; i <= 64; i += 1) {
  // Every 10th is historical (not current population) and must never be listed.
  const m = createMember({ first_name: `Serve${String(i).padStart(2, '0')}`, last_name: 'Person', cell_group_id: groups[i % 2].id }, { status: i % 10 === 0 ? 'inactive' : 'active' });
  members.push(m);
}
// Members 1-6 serve in Choir; 3-6 also in Ushers; 5-6 also in Media (so several: 3,4 (two), 5,6 (three)... and 1,2 single).
for (const i of [1, 2, 3, 4, 5, 6]) ministries.addMember(choir.id, members[i - 1].id);
for (const i of [3, 4, 5, 6]) ministries.addMember(ushers.id, members[i - 1].id);
for (const i of [5, 6]) ministries.addMember(media.id, members[i - 1].id);
const current = db.prepare("SELECT COUNT(*) n FROM members WHERE status IN ('active','pending','attendee','bonafide','temporarily_away')").get().n;
const notServingTotal = current - 6;

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'serve.admin@fixture.invalid', password: PASSWORD, _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const html = async (query = '') => {
    const res = await fetch(`${base}/ministries/serving${query ? `?${query}` : ''}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, query);
    return res.text();
  };
  const rowsOf = (markup) => (markup.match(/<tbody>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 1;
  const membersIn = (markup) => [...markup.matchAll(/<td data-label="Member"><a href="\/members\/\d+">([^<]+)<\/a>/g)].map((m) => m[1]);

  // The headline figures are the business rule and did not change.
  let markup = await html();
  assert.match(markup, new RegExp(`of ${current} currently with CCIQ`));
  assert.match(markup, /<p class="stat__label">Serving in several<\/p>\s*<p class="stat__value">4<\/p>/, 'four members serve in two or more ministries');

  // Not yet serving: the default tab.
  assert.equal(rowsOf(markup), 25);
  assert.match(markup, new RegExp(`Showing 1&ndash;25 of ${notServingTotal}`));
  assert.match(markup, /rel="next"/);
  assert.equal(rowsOf(await html('page=3')), notServingTotal - 50);
  assert.equal(rowsOf(await html('page=99')), notServingTotal - 50, 'out-of-range page is clamped');
  assert.equal(rowsOf(await html('page_size=100')), notServingTotal);
  assert.equal(rowsOf(await html('page_size=13')), 25);
  assert.ok(!membersIn(await html('page_size=100')).includes('Serve10 Person'), 'historical statuses are never listed');
  assert.ok(!membersIn(await html('page_size=100')).includes('Serve01 Person'), 'a member who serves is not listed as not serving');
  assert.deepEqual(membersIn(await html('q=Serve17')), ['Serve17 Person'], 'search by name');
  const groupA = db.prepare("SELECT COUNT(*) n FROM members m WHERE m.cell_group_id = ? AND m.status IN ('active','pending','attendee','bonafide','temporarily_away') AND NOT EXISTS (SELECT 1 FROM ministry_members mm WHERE mm.member_id = m.id AND mm.left_at IS NULL)").get(groups[0].id).n;
  assert.match(await html(`cell_group_id=${groups[0].id}`), new RegExp(`Showing 1&ndash;${groupA} of ${groupA}`), 'cell group filter');
  const desc = membersIn(await html('sort=member&direction=desc&page_size=100'));
  const asc = membersIn(await html('sort=member&direction=asc&page_size=100'));
  assert.deepEqual([...asc].reverse(), desc);
  assert.equal(rowsOf(await html('sort=nonsense&page_size=100')), notServingTotal, 'unknown sort keys fall back');
  markup = await html('q=Serve&cell_group_id=' + groups[1].id + '&sort=cell_group&direction=desc');
  const next = markup.match(/href="(\/ministries\/serving\?[^"]*page=2[^"]*)"/)[1].replaceAll('&amp;', '&');
  for (const part of ['q=Serve', `cell_group_id=${groups[1].id}`, 'sort=cell_group', 'direction=desc']) assert.ok(next.includes(part), `Next keeps ${part}`);
  console.log('PASS (not serving) 25 per page, 25/50/100, search, cell group filter, sort, clamped pages, count, and every choice preserved by Next');

  // Serving in several.
  markup = await html('list=several');
  assert.equal(rowsOf(markup), 4);
  assert.match(markup, /Showing 1&ndash;4 of 4/);
  assert.deepEqual(membersIn(markup).slice(0, 2).sort(), ['Serve05 Person', 'Serve06 Person'], 'three ministries first');
  assert.equal(rowsOf(await html(`list=several&ministry_id=${media.id}`)), 2, 'filter: serving in Media');
  assert.equal(rowsOf(await html(`list=several&ministry_id=${ushers.id}`)), 4);
  assert.equal(rowsOf(await html('list=several&q=Serve03')), 1);
  assert.equal(rowsOf(await html('list=several&sort=member&direction=asc')), 4);
  assert.match(markup, /aria-current="page"[^>]*>Serving in several/);
  assert.match(await html(`list=several&ministry_id=${media.id}`), /name="ministry_id"/);
  console.log('PASS (serving in several) tab, ministry filter, search and sort');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
