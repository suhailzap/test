import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { buildPortalFixture } from './lib/portal-fixture.mjs';

/*
 * Stored files the database points at must be in storage, and a backup must say so when they are not.
 *   - the registry of file columns covers every column in the schema that could hold a file (a new one that is in neither list fails here);
 *   - findMissingReferences() names a missing file, an unsafe path and an empty campaign-picture folder, and passes a file that is there;
 *   - a backup records the facts in its manifest and its note, writes a .sha256 beside the archive, and a deep verification reports the missing file as a WARNING (the archive is
 *     faithful, the system was already missing the file) and names a storage folder the portal does not know;
 *   - deleting a backup removes its checksum file too, and nothing is ever hidden: a clean system produces no warning.
 */

const f = await buildPortalFixture('cciq-storage-references-');
const { db, ids } = f;
const refs = await import('../lib/storage-references.js');
const backups = await import('../services/backups.js');
const tar = await import('tar');
const storage = process.env.STORAGE_DIR;

{ // 1. the registry covers the schema
  assert.deepEqual(refs.unclassifiedFileColumns(db), [], 'every column that could hold a file is classified (add a new one to STORED_FILE_COLUMNS or NOT_STORED_FILE_COLUMNS)');
  for (const c of refs.STORED_FILE_COLUMNS) {
    assert.ok(db.prepare(`PRAGMA table_info(${c.table})`).all().some((col) => col.name === c.column), `${c.table}.${c.column} exists in the schema`);
  }
  console.log(`PASS (registry) ${refs.STORED_FILE_COLUMNS.length} stored-file columns known; no unclassified file-like column in the schema`);
}

const memberId = ids.member.a1;
{ // 2. detection
  const clean = refs.findMissingReferences(db, storage);
  assert.deepEqual(clean.missing, [], 'a fixture with no file references has nothing missing');
  const rel = `members/${memberId}/real.png`;
  fs.mkdirSync(path.join(storage, 'members', String(memberId)), { recursive: true });
  fs.writeFileSync(path.join(storage, rel), Buffer.from('x'));
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(rel, memberId);
  assert.deepEqual(refs.findMissingReferences(db, storage).missing, [], 'a file that is there is not reported');
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(`members/${memberId}/gone.jpg`, memberId);
  let r = refs.findMissingReferences(db, storage);
  assert.deepEqual(r.missing.map((m) => [m.table, m.column, m.id, m.why]), [['members', 'photo_path', memberId, 'missing']]);
  assert.match(refs.describeMissing(r.missing), /1 stored file the database points at is not in storage: members\.photo_path #\d+ \(members\/\d+\/gone\.jpg\)/);
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run('../outside.png', memberId);
  assert.equal(refs.findMissingReferences(db, storage).missing[0].why, 'unsafe', 'a path that leaves storage is reported, never followed');
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(path.join(storage, '..', 'abs.png'), memberId);
  assert.equal(refs.findMissingReferences(db, storage).missing[0].why, 'unsafe');
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(`members/${memberId}/gone.jpg`, memberId); // leave one missing for the backup tests
  // a Giving Board picture
  const campaign = db.prepare("SELECT id FROM ecaq_campaigns WHERE type = 'giving_board' LIMIT 1").get();
  if (campaign) {
    db.prepare("UPDATE ecaq_campaigns SET background_image = ? WHERE id = ?").run(`/media/ecaq/${campaign.id}/background`, campaign.id);
    r = refs.findMissingReferences(db, storage);
    assert.ok(r.missing.some((m) => m.table === 'ecaq_campaigns' && m.why === 'empty_folder'), 'a campaign picture with no file behind it is reported');
    db.prepare("UPDATE ecaq_campaigns SET background_image = '/fixtures/campaign-background.png' WHERE id = ?").run(campaign.id);
    assert.ok(!refs.findMissingReferences(db, storage).missing.some((m) => m.table === 'ecaq_campaigns'), 'the shipped default picture is not a stored file');
  }
  console.log('PASS (detection) a missing file, an unsafe path and an empty campaign picture are reported; a present file and a shipped image are not');
}

{ // 3. the backup says so
  fs.mkdirSync(path.join(storage, 'pre-0099'), { recursive: true }); fs.writeFileSync(path.join(storage, 'pre-0099', 'old.sqlite'), 'x');
  const made = await backups.createBackup({ note: 'storage reference test' });
  assert.ok(made.ok);
  const backup = made.backup; const file = path.join(process.env.BACKUP_DIR, backup.filename);
  const side = fs.readFileSync(`${file}.sha256`, 'utf8'); assert.equal(side, `${backup.checksum}  ${backup.filename}\n`, 'the checksum is written beside the archive');
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'), backup.checksum);
  assert.match(backup.notes, /WARNING: 1 stored file the database points at is not in storage/, 'the backup note carries the warning');
  const extract = fs.mkdtempSync(path.join(path.dirname(storage), 'extract-')); await tar.x({ file, cwd: extract });
  const manifest = JSON.parse(fs.readFileSync(path.join(extract, 'manifest.json'), 'utf8'));
  assert.equal(manifest.missing_references, 1); assert.ok(manifest.referenced_files >= 1, 'the manifest records what was referenced and what was missing');
  fs.rmSync(extract, { recursive: true, force: true });
  const deep = await backups.deepVerifyBackup(backup);
  assert.equal(deep.ok, true, 'a missing referenced file does not make the archive corrupt');
  assert.equal(deep.missingReferences.length, 1); assert.ok(deep.warnings.some((w) => /not in storage/.test(w)), 'but it is a warning, not silence');
  assert.ok(deep.warnings.some((w) => /folder\(s\) the portal does not know: pre-0099/.test(w)), 'a storage folder the portal does not know is named');
  // a clean system
  db.prepare('UPDATE members SET photo_path = NULL WHERE id = ?').run(memberId); fs.rmSync(path.join(storage, 'pre-0099'), { recursive: true, force: true });
  const clean = (await backups.createBackup({ note: 'clean' })).backup; assert.ok(!/WARNING/.test(clean.notes));
  const cleanDeep = await backups.deepVerifyBackup(clean); assert.deepEqual(cleanDeep.warnings, [], 'no warning when nothing is missing');
  backups.deleteBackup(backup.id); assert.ok(!fs.existsSync(file) && !fs.existsSync(`${file}.sha256`), 'deleting a backup removes its checksum file');
  console.log('PASS (backup) the checksum file, the manifest facts and the note are written; deep verification warns about a missing referenced file and an unknown folder, and is silent on a clean system');
}
console.log('PASS storage-references');
