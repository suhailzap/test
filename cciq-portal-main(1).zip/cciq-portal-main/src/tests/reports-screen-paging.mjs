import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Report SCREENS are bounded (server-side paging, 25 default, 25/50/100, count, sort and filters
 * kept in the query string) while the CSV keeps every row. Report calculations are not touched:
 * the totals and the chart still describe the whole range.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
createIsolatedTestEnv('cciq-report-paging-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { setSetting } = await import('../lib/settings.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const { createUser } = await import('../services/users.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const PASSWORD = `Rp${crypto.randomBytes(12).toString('base64url')}9!`;
await createUser({ username: 'report_admin', email: 'report.admin@fixture.invalid', password: PASSWORD, displayName: 'Report Admin', roleKeys: ['church_admin'], mustChangePassword: false });
for (let i = 1; i <= 60; i += 1) createMember({ first_name: `Reporter${String(i).padStart(2, '0')}`, last_name: 'Paging' }, { status: 'active' });
// 40 past Fridays (no tracking start date, so they are plain recorded history - cheap to create).
const SERVICE = lastFridayOnOrBefore(today());
const first = addDays(SERVICE, -7 * 39);
for (let n = 0; n < 40; n += 1) {
  const date = addDays(first, 7 * n);
  db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(date, `${date}T09:00:00.000Z`);
}
const someone = db.prepare("SELECT id FROM members ORDER BY id LIMIT 1").get().id;
db.prepare("INSERT INTO attendance_records (session_id, member_id, status, recorded_at, source) SELECT id, ?, 'present', '2026-01-01T00:00:00.000Z', 'manual' FROM attendance_sessions").run(someone);

// The member report only lists members once at least one tracked Friday has been finalized (before that it
// explains why there is nothing to show - see physical-review-corrections.mjs), so track from the first Friday
// and finalize the three most recent ones.
for (const m of db.prepare('SELECT id FROM members').all()) {
  const old = `${addDays(first, -400)}T09:00:00.000Z`;
  db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run(old, m.id);
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare("INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, 'active', 'planted', ?)").run(m.id, old);
}
setSetting('attendance.tracking_start_date', first);
for (const s of db.prepare("SELECT id FROM attendance_sessions ORDER BY service_date DESC LIMIT 3").all()) lifecycle.finalizeAttendance(s.id, { userId: null });

const port = await new Promise((resolve) => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, [path.join(root, 'src/server.js')], { env: { ...process.env, PORT: String(port) } });
try {
  await waitForServerReady(base, server);
  const cookieOf = (res, fallback) => (res.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ') || fallback);
  const page = await fetch(`${base}/login`);
  const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const pre = cookieOf(page, '');
  const login = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre },
    body: new URLSearchParams({ email: 'report.admin@fixture.invalid', password: PASSWORD, _csrf: csrf })
  });
  const cookie = cookieOf(login, pre);
  const fetchText = async (url) => {
    const res = await fetch(`${base}${url}`, { headers: { Cookie: cookie } });
    assert.equal(res.status, 200, url);
    return res.text();
  };
  const rowsOf = (markup) => (markup.match(/<tbody>[\s\S]*?<\/tbody>/) || [''])[0].split('<tr>').length - 1;
  const range = `from=${first}&to=${SERVICE}`;

  // Reports -> Attendance overview: the per-Friday table is bounded; the chart and totals are not.
  let markup = await fetchText(`/reports/attendance?${range}`);
  assert.equal(rowsOf(markup), 25, 'the per-Friday table shows 25 at a time');
  assert.match(markup, /Showing 1&ndash;25 of 40/);
  assert.equal((markup.match(/class="bars__col"/g) || []).length, 40, 'but the trend chart still covers the whole range');
  assert.equal(rowsOf(await fetchText(`/reports/attendance?${range}&page=2`)), 15);
  assert.equal(rowsOf(await fetchText(`/reports/attendance?${range}&page_size=50`)), 40);
  assert.equal(rowsOf(await fetchText(`/reports/attendance?${range}&page=99`)), 15, 'out-of-range pages are clamped');
  markup = await fetchText(`/reports/attendance?${range}&sort=present&direction=asc`);
  const next = markup.match(/href="(\/reports\/attendance\?[^"]*page=2[^"]*)"/)[1].replaceAll('&amp;', '&');
  for (const part of [`from=${first}`, `to=${SERVICE}`, 'sort=present', 'direction=asc']) assert.ok(next.includes(part), `Next keeps ${part}`);
  const csv = await fetchText(`/reports/attendance/export.csv?${range}`);
  assert.equal(csv.trim().split('\n').length, 41, 'the CSV still contains every Friday (header + 40)');
  console.log('PASS (overview) the per-Friday table is paged 25/50/100 with a count and kept query state; the chart, totals and CSV still cover the whole range');

  // Attendance -> Reports: one row per member, paged; the CSV keeps everyone.
  markup = await fetchText(`/attendance/reports?${range}`);
  assert.equal(rowsOf(markup), 25);
  assert.match(markup, /Showing 1&ndash;25 of 60 members/);
  assert.equal(rowsOf(await fetchText(`/attendance/reports?${range}&page=3`)), 10);
  assert.equal(rowsOf(await fetchText(`/attendance/reports?${range}&page_size=100`)), 60);
  markup = await fetchText(`/attendance/reports?${range}&sort=name&direction=desc&statuses_submitted=1&status=active`);
  const next2 = markup.match(/href="(\/attendance\/reports\?[^"]*page=2[^"]*)"/)[1].replaceAll('&amp;', '&');
  for (const part of ['sort=name', 'direction=desc', 'status=active', 'statuses_submitted=1']) assert.ok(next2.includes(part), `Next keeps ${part}`);
  const memberCsv = await fetchText(`/attendance/reports/export.csv?${range}`);
  assert.equal(memberCsv.trim().split('\r\n').length, 61, 'the member CSV still has every member (header + 60)');
  console.log('PASS (member report) paged with a count and kept filters/sort; the CSV still lists everyone');
} finally {
  await terminateAndWait(server);
}
console.log('ALL PASS');
