import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import zlib from 'node:zlib';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Files, beyond upload-download-safety.mjs (which pins image magic bytes, random stored names, oversize, hostile download names and a missing
 * file):
 *   1. a client that walks away mid-download, again and again, never stops the server;
 *   2. a storage folder that cannot be written (a file sits where its folder should be) is a clean refusal: nothing is half-saved, no path
 *      or internals are shown, the old file survives, and the portal carries on;
 *   3. documents: empty, spoofed, hostile-named, very long-named and duplicate-named uploads;
 *   4. spreadsheets: junk, empty, a text file named .xlsx, and a "zip bomb" (a tiny .xlsx that claims to expand to gigabytes) are refused
 *      before anything is inflated.
 */

const f = await buildPortalFixture('cciq-files-extra-');
const { db, ids, users } = f;
const config = (await import('../config/env.js')).default;
const imports = await import('../services/imports.js');
const storage = config.storageDir;
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const portal = await startPortal();
const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
const health = async () => (await fetch(`${portal.base}/healthz`)).status;
const filesUnder = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir, { recursive: true }).filter((p) => fs.statSync(path.join(dir, p)).isFile()).sort() : []);
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
await (await admin.get('/documents/new')).text(); // the document categories are created the first time the form is opened
const categoryId = db.prepare('SELECT id FROM document_categories ORDER BY id LIMIT 1').get().id;
const upload = (url, file, opts = {}) => admin.upload(url, file, { csrfFrom: '/documents/new', field: 'file', ...opts, fields: { category_id: categoryId, ...(opts.fields || {}) } });

try {
  // ---- 1. aborted downloads ------------------------------------------------------------------------------------------------------------------
  {
    const big = Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(6 * 1024 * 1024, 0x20), Buffer.from('\n%%EOF\n')]);
    const res = await upload('/documents', { name: 'big.pdf', type: 'application/pdf', buffer: big }, { fields: { title: 'Big document', document_date: '2026-01-01' } }); const resText = (await res.text()).replace(/<[^>]+>/g, ' ').replace(/s+/g, ' ');
    const bigId = db.prepare("SELECT id FROM documents WHERE title = 'Big document'").get()?.id;
    assert.ok(bigId, `a 6 MB document uploads (${res.status}) ${resText.slice(400, 900)}`);
    let aborted = 0;
    for (let i = 0; i < 25; i += 1) {
      await new Promise((resolve) => {
        const req = http.get(`${portal.base}/documents/${bigId}/file`, { headers: { Cookie: admin.cookie } }, (r) => {
          r.once('data', () => { aborted += 1; req.destroy(); r.destroy(); });
        });
        req.on('error', () => resolve()); req.on('close', () => resolve());
      });
    }
    assert.equal(aborted, 25, 'twenty-five downloads were abandoned after the first chunk');
    assert.equal(await health(), 200, 'the portal is still up after twenty-five abandoned downloads');
    const again = await admin.get(`/documents/${bigId}/file`); const length = (await again.arrayBuffer()).byteLength;
    assert.equal(again.status, 200); assert.equal(length, big.length, 'and the next download is whole');
    // an abandoned PDF report and an abandoned CSV export
    for (const url of ['/reports/directory/pdf?statuses_submitted=1&status=active', '/members/export.csv']) {
      await new Promise((resolve) => { const req = http.get(`${portal.base}${url}`, { headers: { Cookie: admin.cookie } }, (r) => { r.destroy(); req.destroy(); resolve(); }); req.on('error', resolve); });
    }
    assert.equal(await health(), 200, 'and after abandoned PDF and CSV exports');
    console.log('PASS (1) 25 abandoned file downloads, an abandoned PDF and an abandoned CSV leave the server up and the next download whole');
  }

  // ---- 2. a storage folder that cannot be written ---------------------------------------------------------------------------------------------
  {
    const memberDir = path.join(storage, 'members');
    const ok = await admin.upload(`/members/${ids.member.a2}/photo`, { name: 'p.png', type: 'image/png', buffer: PNG }, { field: 'photo', csrfFrom: '/' }); await ok.arrayBuffer();
    const column = () => db.prepare('SELECT photo_path p FROM members WHERE id = ?').get(ids.member.a2).p;
    const before = { column: column(), files: filesUnder(storage) };
    assert.ok(before.column, 'a photo is stored');
    // replace the whole "members" folder by a plain file: every write beneath it must fail
    fs.renameSync(memberDir, `${memberDir}.real`);
    fs.writeFileSync(memberDir, 'not a folder');
    const res = await admin.upload(`/members/${ids.member.a2}/photo`, { name: 'p2.png', type: 'image/png', buffer: PNG }, { field: 'photo', csrfFrom: '/' });
    const text = await res.text();
    fs.rmSync(memberDir, { force: true }); fs.renameSync(`${memberDir}.real`, memberDir);
    assert.ok(res.status >= 300, `the failed write is reported (${res.status})`);
    assert.doesNotMatch(text, /ENOTDIR|ENOENT|EEXIST|EPERM|\bat \w+ \(|node_modules|C:\\\\|storage/i, 'with no path, error code or internals shown');
    assert.equal(column(), before.column, 'the record still points at the previous picture');
    assert.deepEqual(filesUnder(storage), before.files, 'nothing was half-saved: the stored files are exactly as before');
    assert.equal(await health(), 200, 'and the portal carries on');
    const view = await admin.get(`/media/members/${ids.member.a2}/photo`); await view.arrayBuffer();
    assert.equal(view.status, 200, 'the previous picture is still served');
    console.log('PASS (2) when the folder cannot be written the upload is refused cleanly: no path or code shown, the old picture and every stored file untouched, the portal up');
  }

  // ---- 3. document uploads --------------------------------------------------------------------------------------------------------------------
  {
    const documents = () => count('SELECT COUNT(*) n FROM documents');
    const docFiles = () => filesUnder(path.join(storage, 'documents'));
    const before = { documents: documents(), files: docFiles() };
    const refuse = [
      ['an empty file', { name: 'empty.pdf', type: 'application/pdf', buffer: Buffer.alloc(0) }],
      ['text named .pdf', { name: 'a.pdf', type: 'application/pdf', buffer: Buffer.from('this is not a pdf at all, just words') }],
      ['an executable named .png', { name: 'a.png', type: 'image/png', buffer: Buffer.concat([Buffer.from('MZ'), Buffer.alloc(300)]) }],
      ['an HTML file named .pdf', { name: 'a.pdf', type: 'application/pdf', buffer: Buffer.from('<html><script>alert(1)</script></html>        ') }]
    ];
    for (const [what, file] of refuse) {
      const res = await upload('/documents', file, { fields: { title: `Refuse ${what}` } }); await res.arrayBuffer();
      assert.ok(res.status < 500 && res.status >= 300 || res.status === 400, `${what}: refused cleanly (${res.status})`);
    }
    assert.deepEqual({ documents: documents(), files: docFiles() }, before, 'every refused upload left no record and no file');

    // the leading bytes decide, not the declared type: a real PDF sent as text/html is stored as the PDF it is
    const spoof = await upload('/documents', { name: 'real.pdf', type: 'text/html', buffer: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(100)]) }, { fields: { title: 'Declared wrongly' } }); await spoof.arrayBuffer();
    assert.equal(db.prepare("SELECT mime_type FROM documents WHERE title = 'Declared wrongly'").get()?.mime_type, 'application/pdf', 'stored with the detected type, not the claimed one');
    before.documents += 1; before.files = docFiles();

    const pdf = (n) => Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.from(`document ${n}`), Buffer.alloc(100, 0x20)]);
    const hostile = ['../../../../etc/passwd.pdf', '..\\..\\windows\\system.ini.pdf', 'CON.pdf', 'a b  c.pdf', 'Ünï\u00e7ode \u0645\u062d\u0645\u062f.pdf', `${'x'.repeat(300)}.pdf`, 'name\u0000.pdf', 'dup.pdf', 'dup.pdf', '.pdf', 'no-extension', '<script>.pdf'];
    const accepted = [];
    for (const [i, name] of hostile.entries()) {
      const res = await upload('/documents', { name, type: 'application/pdf', buffer: pdf(i) }, { fields: { title: `Hostile name ${i}`, document_date: '2026-01-01' } }); await res.arrayBuffer();
      assert.ok(res.status < 500, `a file named ${JSON.stringify(name.slice(0, 30))} is not a server error (${res.status})`);
      const row = db.prepare('SELECT id, stored_path FROM documents WHERE title = ?').get(`Hostile name ${i}`);
      if (row) accepted.push(row);
    }
    assert.ok(accepted.length >= 8, `most of them are stored (${accepted.length})`);
    const storedNames = accepted.map((r) => r.stored_path);
    assert.equal(new Set(storedNames).size, storedNames.length, 'every file has its own stored path: two uploads called dup.pdf do not overwrite each other');
    for (const p of storedNames) {
      assert.match(p, /^documents[\\/][0-9a-z\-\\/]+\.pdf$/i, `stored under a random name inside storage/documents (${p})`);
      assert.ok(path.resolve(storage, p).startsWith(path.resolve(storage, 'documents') + path.sep), 'and nowhere outside it');
      assert.ok(!/passwd|system\.ini|CON|script|ünï/i.test(p), 'the uploaded name is never part of the stored path');
    }
    const dups = db.prepare("SELECT stored_path FROM documents WHERE title IN ('Hostile name 7', 'Hostile name 8')").all();
    assert.deepEqual(dups.map((r) => fs.readFileSync(path.join(storage, r.stored_path)).toString('latin1').includes('document 7') ? 7 : 8).sort(), [7, 8], 'each duplicate-named upload kept its own content');
    // nothing was written outside storage
    const outside = fs.readdirSync(path.dirname(storage)).filter((n) => /passwd|system\.ini/.test(n));
    assert.deepEqual(outside, [], 'no traversal wrote a file next to storage');
    console.log(`PASS (3) empty, spoofed and mistyped documents are refused with nothing stored; ${accepted.length} hostile, long, Unicode and duplicate file names are stored under unique random paths inside storage, none overwriting another`);
  }

  // ---- 4. spreadsheets -----------------------------------------------------------------------------------------------------------------------
  {
    const crc32 = (buf) => zlib.crc32(buf);
    /** A ZIP holding one entry that inflates to `size` zero bytes. The compressed file stays tiny. */
    const zipBomb = (size) => {
      const chunk = Buffer.alloc(1024 * 1024);
      const deflate = zlib.createDeflateRaw({ level: 9 }); const parts = [];
      deflate.on('data', (d) => parts.push(d));
      return new Promise((resolve) => {
        deflate.on('end', () => {
          const data = Buffer.concat(parts); const name = Buffer.from('xl/worksheets/sheet1.xml');
          let crc = 0; // not verified before inflation by our check; a plausible value is enough
          const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0, 6); local.writeUInt16LE(8, 8);
          local.writeUInt32LE(crc, 14); local.writeUInt32LE(data.length, 18); local.writeUInt32LE(size >>> 0, 22); local.writeUInt16LE(name.length, 26);
          const central = Buffer.alloc(46); central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(8, 10);
          central.writeUInt32LE(crc, 16); central.writeUInt32LE(data.length, 20); central.writeUInt32LE(size >>> 0, 24); central.writeUInt16LE(name.length, 28); central.writeUInt32LE(0, 42);
          const dirStart = local.length + name.length + data.length; const dirSize = central.length + name.length;
          const eocd = Buffer.alloc(22); eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(1, 8); eocd.writeUInt16LE(1, 10); eocd.writeUInt32LE(dirSize, 12); eocd.writeUInt32LE(dirStart, 16);
          resolve(Buffer.concat([local, name, data, central, name, eocd]));
        });
        let written = 0; const write = () => { while (written < size) { const ok = deflate.write(chunk.subarray(0, Math.min(chunk.length, size - written))); written += Math.min(chunk.length, size - written); if (!ok) { deflate.once('drain', write); return; } } deflate.end(); };
        write();
      });
    };
    const bomb = await zipBomb(600 * 1024 * 1024); // 600 MB of zeros
    assert.ok(bomb.length < 2 * 1024 * 1024, `the test file is small (${Math.round(bomb.length / 1024)} KB) yet claims 600 MB`);
    assert.throws(() => imports.readWorkbook(bomb, 'bomb.xlsx'), (err) => err.code === 'SPREADSHEET_UNSAFE' && /cannot be opened safely/.test(err.message), 'the reader refuses it before inflating anything');
    const memoryBefore = process.memoryUsage().rss;
    for (let i = 0; i < 5; i += 1) assert.throws(() => imports.readWorkbook(bomb, 'bomb.xlsx'));
    assert.ok(process.memoryUsage().rss - memoryBefore < 100 * 1024 * 1024, 'and refusing it repeatedly costs no memory');

    const stagedBefore = filesUnder(path.join(storage, 'imports'));
    const importPost = (file) => admin.upload('/admin/import', file, { field: 'file', fields: { kind: 'members' }, csrfFrom: '/admin/import' });
    for (const [what, file] of [
      ['a zip bomb named .xlsx', { name: 'bomb.xlsx', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', buffer: bomb }],
      ['an empty file', { name: 'empty.xlsx', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', buffer: Buffer.alloc(0) }],
      ['random bytes named .xlsx', { name: 'noise.xlsx', type: 'application/octet-stream', buffer: Buffer.from(Array.from({ length: 2000 }, (_, i) => (i * 37) % 251)) }],
      ['a text file named .xlsx', { name: 'text.xlsx', type: 'text/plain', buffer: Buffer.from('this is not a workbook') }],
      ['a truncated zip', { name: 'cut.xlsx', type: 'application/octet-stream', buffer: Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(40)]) }],
      ['a file over the 12 MB limit', { name: 'huge.xlsx', type: 'application/octet-stream', buffer: Buffer.alloc(13 * 1024 * 1024, 0x41) }]
    ]) {
      const res = await importPost(file); const text = await res.text();
      assert.ok(res.status < 500, `${what}: refused cleanly (${res.status})`);
      assert.doesNotMatch(text, /\bat \w+ \(|node_modules|SqliteError/, `${what}: no internals`);
      assert.deepEqual(filesUnder(path.join(storage, 'imports')), stagedBefore, `${what}: nothing was staged`);
    }
    assert.equal(await health(), 200, 'the portal is up after every refused spreadsheet');
    // a real workbook is still accepted
    const XLSX = (await import('xlsx')).default;
    const real = XLSX.write({ SheetNames: ['S'], Sheets: { S: { A1: { t: 's', v: 'First name' }, B1: { t: 's', v: 'Last name' }, A2: { t: 's', v: 'Ann' }, B2: { t: 's', v: 'Real' }, '!ref': 'A1:B2' } } }, { type: 'buffer', bookType: 'xlsx' });
    const okRes = await importPost({ name: 'real.xlsx', type: 'application/octet-stream', buffer: real }); await okRes.arrayBuffer();
    assert.equal(okRes.status, 302); assert.match(okRes.headers.get('location'), /^\/admin\/import\/[a-f0-9]{32}$/, 'a genuine workbook is staged for preview as before');
    console.log('PASS (4) a 600 MB zip bomb inside a 1 KB .xlsx, an empty file, noise, text, a truncated zip and an over-limit file are refused before anything is inflated or staged; a real workbook still imports');
  }
  console.log('ALL PASS');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
