import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Keyboard-only use of the screens that matter most for the First Timer lifecycle and for the people who run the portal on a Friday:
 *   - the skip link is the first stop, is visible when focused and moves focus to the content;
 *   - every control that can be focused can be reached with Tab, in an order that follows the page, with nothing reachable that is hidden;
 *   - every stop has a visible focus indicator and an accessible name; no positive tabindex;
 *   - an invalid form marks the field invalid and ties its message to it, and announces the problem;
 *   - the Kiosk and Express Registration work with the keyboard alone (the desk may have no mouse).
 * A real browser, keyboard events only.
 */

const f = await buildPortalFixture('cciq-keyboard-a11y-');
const { db, ids, users, mods } = f;
const visitor = mods.visitors.createVisitor({ first_name: 'Kay', last_name: 'Board', first_visit_date: mods.dates.today() }, { userId: users.churchAdmin.id });
db.prepare("INSERT INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_service_date, window_json) VALUES (?, 'open', '2026-01-01T00:00:00.000Z', '2026-01-02', ?)")
  .run(visitor.id, JSON.stringify({ rule: '3 of the last 4 eligible Fridays', visits: 3, fridays: [4, 3, 2, 1].map((n, i) => ({ session_id: n, service_date: `2026-01-0${n}`, visited: i !== 1 })) }));
const reviewId = db.prepare('SELECT id FROM visitor_membership_reviews LIMIT 1').get().id;
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });

const TAB_SCRIPT = () => {
  const el = document.activeElement;
  if (!el || el === document.body) return null;
  const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
  const nameOf = () => (el.getAttribute('aria-label') || el.querySelector('img[alt]')?.getAttribute('alt') || (el.labels && [...el.labels].map((l) => l.textContent).join(' ')) || el.textContent || el.getAttribute('title') || el.getAttribute('alt') || el.value || '').trim();
  const labelledBy = el.getAttribute('aria-labelledby');
  const name = labelledBy ? labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent || '').join(' ').trim() || nameOf() : nameOf();
  const ringOn = (node) => { const cs = getComputedStyle(node); return (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0) || (cs.boxShadow && cs.boxShadow !== 'none'); };
  let ring = ringOn(el);
  for (let p = el.parentElement, depth = 0; !ring && p && depth < 3; p = p.parentElement, depth += 1) if (p.matches(':focus-within') && ringOn(p)) ring = true;
  const outline = ring; const shadow = false;
  let hidden = r.width === 0 || r.height === 0 || s.visibility === 'hidden' || s.display === 'none';
  for (let p = el; p && p !== document.body; p = p.parentElement) if (p.getAttribute('aria-hidden') === 'true' || p.hidden) hidden = true;
  const inViewport = r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  const previous = window.__previousStop; window.__previousStop = el;
  const inOrder = !previous || previous === el || Boolean(previous.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
  return { type: el.type || '', html: el.outerHTML.slice(0, 120), inOrder, tag: el.tagName.toLowerCase(), id: el.id, cls: String(el.className).slice(0, 40), name: name.slice(0, 50), focusRing: outline || Boolean(shadow), hidden, inViewport, tabindex: el.getAttribute('tabindex'), top: Math.round(r.top + scrollY), left: Math.round(r.left) };
};
const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]), summary';

const problems = [];
async function sweep(context, label, url, { expectSkip = true } = {}) {
  const open = async () => {
    const page = await context.newPage();
    await page.setViewportSize({ width: 1280, height: 900 });
    const res = await page.goto(portal.base + url, { waitUntil: 'load' });
    assert.ok(res.status() < 400, `${label} opens (${res.status()})`);
    return page;
  };
  /** Back to the very start of the page: some screens focus a field themselves. */
  const toStart = async (page) => { for (let back = 0; back < 300; back += 1) { if (await page.evaluate(() => document.activeElement === document.body)) break; await page.keyboard.press('Shift+Tab'); } };

  // 1. the skip link, on its own page (activating it moves focus, which would spoil the walk)
  if (expectSkip) {
    const page = await open(); await toStart(page);
    await page.keyboard.press('Tab'); await page.waitForTimeout(250); // it slides into view
    const first = await page.evaluate(TAB_SCRIPT);
    if (!first || !/skip/i.test(`${first.cls} ${first.name}`)) problems.push(`${label}: the first Tab stop is not the skip link (${JSON.stringify(first && first.name)})`);
    else {
      if (!first.inViewport || !first.focusRing) problems.push(`${label}: the skip link is not visible when focused`);
      await page.keyboard.press('Enter');
      const landed = await page.evaluate(() => location.hash);
      if (landed !== '#main') problems.push(`${label}: the skip link does not go to the content (${landed})`);
    }
    await page.close();
  }

  // 2. a fresh page, walked from the top
  const page = await open();
  const reachable = await page.evaluate((sel) => {
    const radios = new Set();
    return [...document.querySelectorAll(sel)].filter((el) => {
      const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
      if (r.width === 0 || r.height === 0 || cs.visibility === 'hidden' || cs.display === 'none') return false;
      for (let p = el; p; p = p.parentElement) if (p.hidden || p.getAttribute?.('aria-hidden') === 'true' || p.inert) return false;
      const closed = el.closest('details:not([open])'); if (closed && !(el.tagName === 'SUMMARY' && el.parentElement === closed)) return false;
      if (el.type === 'radio') { if (radios.has(el.name)) return false; radios.add(el.name); }
      return true;
    }).length;
  }, FOCUSABLE);
  await page.evaluate(() => { window.__walk = new Set(); document.addEventListener('focusin', (e) => window.__walk.add(e.target)); });
  await toStart(page);
  await page.keyboard.press('Tab');
  let stop = await page.evaluate(TAB_SCRIPT);
  const seen = []; let dateStops = 0;
  for (let i = 0; i < 400 && stop; i += 1) {
    const key = `${stop.tag}#${stop.id}.${stop.cls}@${stop.top},${stop.left}`;
    if (stop.type === 'date' || stop.type === 'time' || stop.type === 'datetime-local' || stop.type === 'month') {
      // a date field has several stops inside it (day, month, year): they are one control, not a wrap-around
      if (seen.length && seen[seen.length - 1].key === key && (dateStops += 1) < 8) { await page.keyboard.press('Tab'); stop = await page.evaluate(TAB_SCRIPT); continue; }
    }
    dateStops = 0;
    if (seen.some((x) => x.key === key)) break; // wrapped around
    seen.push({ key, ...stop });
    if (process.env.KEYBOARD_DEBUG) console.log(`  ${label}: ${stop.tag}${stop.id ? '#' + stop.id : ''} "${stop.name}" ring=${stop.focusRing}`);
    if (stop.hidden) problems.push(`${label}: Tab reaches a hidden control (${stop.tag} ${stop.name})`);
    if (!stop.focusRing && !/skip/i.test(stop.cls)) problems.push(`${label}: no visible focus on ${stop.tag}.${stop.cls} "${stop.name}"`);
    if (!stop.name && stop.tag !== 'summary') problems.push(`${label}: ${stop.tag}.${stop.cls} has no accessible name when focused: ${stop.html}`);
    if (stop.tabindex && Number(stop.tabindex) > 0) problems.push(`${label}: positive tabindex on ${stop.tag}`);
    if (!stop.inOrder) problems.push(`${label}: focus goes backwards in the page to ${stop.tag} "${stop.name}" (order does not follow the page)`);
    await page.keyboard.press('Tab');
    stop = await page.evaluate(TAB_SCRIPT);
  }
  if (seen.length + 2 < reachable) {
    const missed = await page.evaluate((sel) => {
      const radios = new Set();
      return [...document.querySelectorAll(sel)].filter((el) => {
        const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
        if (r.width === 0 || r.height === 0 || cs.visibility === 'hidden' || cs.display === 'none') return false;
        for (let p = el; p; p = p.parentElement) if (p.hidden || p.getAttribute?.('aria-hidden') === 'true' || p.inert) return false;
        const closed = el.closest('details:not([open])'); if (closed && !(el.tagName === 'SUMMARY' && el.parentElement === closed)) return false;
        if (el.type === 'radio') { if (radios.has(el.name)) return false; radios.add(el.name); }
        return !window.__walk.has(el);
      }).slice(0, 6).map((el) => `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}[${el.type || ''}] "${(el.getAttribute('aria-label') || el.textContent || el.value || '').trim().replace(/s+/g, ' ').slice(0, 25)}"`);
    }, FOCUSABLE);
    problems.push(`${label}: only ${seen.length} of ${reachable} focusable controls can be reached by Tab; not reached: ${missed.join(', ')}`);
  }
  await page.close();
  return seen.length;
}

try {
  const adminSession = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const kioskSession = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const ctx = async (session) => { const c = await browser.newContext(); await c.addCookies(session.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; })); return c; };
  const adminCtx = await ctx(adminSession); const kioskCtx = await ctx(kioskSession);
  const screens = process.env.KEYBOARD_ONLY ? [[process.env.KEYBOARD_ONLY.split('=')[0], process.env.KEYBOARD_ONLY.split('=')[1]]] : [
    ['Dashboard', '/'], ['First Timers', '/visitors'], ['Record a First Timer', '/visitors/new'], ['A First Timer', `/visitors/${visitor.id}`], ['Membership review list', '/visitors/reviews'],
    ['A membership review', `/visitors/reviews/${reviewId}`], ['Convert to member', `/visitors/${visitor.id}/convert`], ['Link to a member', `/visitors/${visitor.id}/link`],
    ['Members', '/members'], ['Add member', '/members/new'], ['Attendance', '/attendance'], ['Friday register', `/attendance/sessions/${ids.session}`], ['Check-in (admin)', '/attendance/checkin'],
    ['Express registration (admin)', '/attendance/checkin/first-timer'], ['Reports', '/reports'], ['Attendance report', '/reports/attendance'], ['ECAQ Projects', '/projects/ecaq'], ['Giving Board', '/projects/ecaq/board']
  ];
  const counts = [];
  for (const [label, url] of screens) counts.push(`${label}:${await sweep(adminCtx, label, url)}`);
  for (const [label, url] of [['Kiosk home', '/kiosk'], ['Kiosk express registration', '/attendance/checkin/first-timer']]) counts.push(`${label}:${await sweep(kioskCtx, label, url, { expectSkip: false })}`);

  // ---- invalid forms: the field is marked, the message is tied to it, the problem is announced -----------------------------------------------
  const invalidForms = [
    ['Record a First Timer (empty)', adminCtx, '/visitors/new', 'main form[method=post] button[type=submit]'],
    ['Express registration (empty)', kioskCtx, '/attendance/checkin/first-timer', 'main form[method=post] button[type=submit]'],
    ['Add member (empty)', adminCtx, '/members/new', 'main form[method=post] button[type=submit]']
  ];
  for (const [label, context, url, submit] of invalidForms) {
    const page = await context.newPage();
    await page.goto(portal.base + url, { waitUntil: 'load' });
    await page.evaluate(() => document.querySelectorAll('[required]').forEach((el) => el.removeAttribute('required'))); // test OUR messages, not the browser's bubble
    await page.focus(submit); await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.keyboard.press('Enter')]);
    const state = await page.evaluate(() => {
      const invalid = [...document.querySelectorAll('[aria-invalid="true"]')];
      const unnamed = invalid.filter((el) => {
        const described = (el.getAttribute('aria-describedby') || '').split(/\s+/).map((id) => document.getElementById(id)?.textContent.trim()).filter(Boolean).join('');
        const sibling = el.closest('.field, .form-row, div')?.querySelector('.field__error, .error, [role=alert]')?.textContent.trim();
        return !described && !sibling;
      }).length;
      return { invalid: invalid.length, unnamed, alert: Boolean(document.querySelector('[role=alert], [role=status]')), url: location.pathname };
    });
    if (state.invalid === 0) problems.push(`${label}: an empty submission marks no field as aria-invalid`);
    if (state.unnamed > 0) problems.push(`${label}: ${state.unnamed} invalid field(s) have no error message tied to them`);
    if (!state.alert) problems.push(`${label}: the problem is not announced (no role=alert region)`);
    await page.close();
  }

  // ---- the Kiosk can be driven with the keyboard alone: search, choose, review ------------------------------------------------------------------
  {
    const page = await kioskCtx.newPage();
    await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
    await page.focus('#checkin-search-input');
    await page.keyboard.type('Board', { delay: 80 }); // a person's typing speed; characters arriving a few milliseconds apart are, deliberately, read as a QR scanner (see kiosk-scan-vs-search)
    await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.keyboard.press('Enter')]);
    const found = await page.locator('input[name=person]').count();
    if (found < 1) problems.push('Kiosk: typing a name and pressing Enter shows no result to choose');
    else {
      await page.focus('input[name=person]'); await page.keyboard.press('Space');
      const checked = await page.evaluate(() => document.querySelector('input[name=person]').checked);
      if (!checked) problems.push('Kiosk: Space does not tick a person');
      const reviewButton = page.getByRole('button', { name: 'Review selected' });
      await reviewButton.focus(); await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.keyboard.press('Enter')]);
      if (!/Review|Confirm|attendance/i.test(await page.textContent('main'))) problems.push('Kiosk: Enter on Review selected does not reach the review step');
    }
    await page.close();
  }

  console.log(`INFO Tab stops walked per screen: ${counts.join(', ')}`);
  console.log(`INFO ${problems.length} keyboard/accessibility problem(s)${problems.length ? '\n   ' + [...new Set(problems)].slice(0, 40).join('\n   ') : ''}`);
  assert.deepEqual([...new Set(problems)], [], 'no keyboard or focus problem on any screen walked');
  console.log(`PASS (keyboard) ${screens.length + 2} screens walked with Tab only: skip link first and visible, every control reachable in page order with a visible focus ring and a name, invalid forms announce and tie their messages, the Kiosk works from the keyboard`);
} finally {
  await browser.close();
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
