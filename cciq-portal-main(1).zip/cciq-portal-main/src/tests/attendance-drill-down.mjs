import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { createIsolatedTestEnv } from './lib/test-env.mjs';
import { startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The attendance drill-down: WHO is behind a number on the Attendance chart or a Friday Service tile.
 *   - one reusable page, /attendance/sessions/:id/people?metric=...; every list is the people the figure was counted from, so its length IS the figure (proved for every figure, three lifecycles);
 *   - a person is counted once (a First Timer who became a member, a First Timer linked to a member who has their own mark);
 *   - searchable, sortable, paged, with validated parameters; server-side access; nothing private beyond name, member ID, type, group, congregation and attendance;
 *   - print: EVERY matching person (not one page), in canonical surname order (last, first, middle name), independent of the screen sort, with identity, service, figure, totals and time;
 *   - the chart bars and the tiles are real links that open the list in a new tab, with hover / focus / keyboard behaviour, and only where the figure can be listed.
 */

const env = createIsolatedTestEnv('cciq-drill-down-');
const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings, setSetting } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { createUser } = await import('../services/users.js');
const visitors = await import('../services/visitors.js');
const lifecycle = await import('../services/attendance-lifecycle.js');
const attendance = await import('../services/attendance.js');
const { today, addDays, lastFridayOnOrBefore } = await import('../lib/dates.js');
const { default: db } = await import('../db/index.js');

const L = lastFridayOnOrBefore(today());
const X = addDays(L, -28); // tracked, finalized
const N = addDays(L, -21); // Attendance Not Taken
const C = addDays(L, -14); // cancelled
const O = addDays(L, -7); // awaiting finalization
const P = addDays(L, -56); // before tracking
const OLD = addDays(X, -400);
const noon = (d) => `${d}T09:00:00.000Z`;
const count = (sql, ...p) => db.prepare(sql).get(...p).n;
const PASSWORD = 'Drill-Down-Passw0rd-long!';

const expectedMember = (first, last, middle = null, extra = {}) => {
  const m = createMember({ first_name: first, middle_name: middle, last_name: last, ...extra }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(noon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'active', 'planted', noon(OLD));
  return m;
};
// A member who is NOT expected at the Friday (their status then was Inactive; they are Active now) but who came anyway: present, off the expected list, history unambiguous.
const newMember = (first, last, middle = null) => {
  const m = createMember({ first_name: first, middle_name: middle, last_name: last }, { status: 'active' });
  db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
  db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(noon(OLD), OLD, m.id);
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, 'inactive', 'planted', noon(OLD));
  db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, ?, ?, ?, ?)').run(m.id, 'inactive', 'active', 'planted', noon(addDays(X, 1)));
  return m;
};
const session = (date) => {
  db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(date, noon(date));
  return db.prepare("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'").get(date);
};
const mark = (sessionId, memberId, status = 'present') => db.prepare("INSERT OR REPLACE INTO attendance_records (session_id, member_id, status, recorded_at, source) VALUES (?, ?, ?, ?, 'manual')").run(sessionId, memberId, status, noon(today()));

// ---- the world ----------------------------------------------------------------------------------------------------------------------------------------------------------
const E1 = expectedMember('Ana', 'Santos'); const E2 = expectedMember('Jose', 'Reyes', 'Maria', { preferred_name: 'Joey' }); const E3 = expectedMember('Maria', 'Dela Cruz');
const E4 = expectedMember('Juan', 'de la Peña'); const E5 = expectedMember('Zoe', 'Abad'); const E6 = expectedMember('Jose', 'Reyes'); const E7 = expectedMember('Ann Marie', 'Santos');
setSetting('attendance.tracking_start_date', X);
const sP = session(P); const sX = session(X); const sN = session(N); const sC = session(C); const sO = session(O);
for (const e of [E1, E2, E6, E7]) mark(sX.id, e.id);
mark(sX.id, E3.id, 'excused'); mark(sX.id, E4.id, 'absent'); // E5: no record at all
const U1 = newMember('Ulysses', 'Zamora'); const U2 = newMember('Pedro', 'Dela Cruz'); const U3 = newMember('Sofia', 'De La Rosa');
for (const u of [U1, U2, U3]) mark(sX.id, u.id); // present, not on the expected list
const bulk = Array.from({ length: 30 }, (_, i) => newMember(`Bulk${String(i + 1).padStart(2, '0')}`, 'Bulk'));
for (const b of bulk) mark(sX.id, b.id);
const V1 = visitors.createVisitor({ first_name: 'Tess', last_name: 'Zapata', first_visit_date: X, session_id: sX.id }, { userId: null });
const V2 = visitors.createVisitor({ first_name: 'Abe', first_visit_date: X }, { userId: null }); // no surname, recorded by date only
const V3 = visitors.createVisitor({ first_name: 'Cora', last_name: 'Villa', first_visit_date: X, session_id: sX.id }, { userId: null });
const V4 = visitors.createVisitor({ first_name: 'Joey', last_name: 'Reyes', first_visit_date: X, session_id: sX.id }, { userId: null });
assert.equal(lifecycle.finalizeAttendance(sX.id, { userId: null, confirmNoAttendance: true }).ok, true);
assert.ok(visitors.convertToMember(V3.id, { userId: null }).member, 'V3 became a member after the Friday');
assert.equal(visitors.linkVisitorToMember(V4.id, E2.id, { userId: null }).ok, true, 'V4 is linked to E2, who has a mark of their own');
// the other lifecycles
mark(sN.id, E1.id); visitors.createVisitor({ first_name: 'Nina', last_name: 'Night', first_visit_date: N, session_id: sN.id }, { userId: null });
assert.equal(lifecycle.markAttendanceNotTaken(sN.id, { userId: null, note: 'power cut', confirmExistingAttendance: true }).ok, true);
db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(sC.id);
mark(sO.id, E1.id); visitors.createVisitor({ first_name: 'Olga', last_name: 'Open', first_visit_date: O, session_id: sO.id }, { userId: null });
visitors.createVisitor({ first_name: 'Pia', last_name: 'Prior', first_visit_date: P }, { userId: null });
mark(sP.id, E2.id);
const groupId = db.prepare("INSERT INTO cell_groups (name, status, created_at, updated_at) VALUES ('Drill Group', 'active', ?, ?)").run(noon(OLD), noon(OLD)).lastInsertRowid;
const meetingId = attendance.createCellGroupMeeting(Number(groupId), { date: X, userId: null }).sessionId;

const mkUser = async (username, roleKeys, memberId = null) => { await createUser({ username, email: `${username}@fixture.invalid`, password: PASSWORD, displayName: username, roleKeys, memberId, mustChangePassword: false }); return `${username}@fixture.invalid`; };
const emails = {
  admin: await mkUser('dd_super', ['super_admin']), church: await mkUser('dd_church', ['church_admin']),
  leader: await mkUser('dd_leader', ['cell_group_leader', 'member'], E1.id), member: await mkUser('dd_member', ['member'], E6.id), kiosk: await mkUser('dd_kiosk', ['kiosk'])
};
const tables = () => JSON.stringify(['attendance_records', 'attendance_expected', 'attendance_sessions', 'visitors', 'visitor_visits', 'members'].map((t) => count(`SELECT COUNT(*) n FROM ${t}`)));
const auditFloor = () => count('SELECT COALESCE(MAX(id), 0) n FROM audit_logs');

const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const admin = await signIn(portal.base, emails.admin, PASSWORD);
  const church = await signIn(portal.base, emails.church, PASSWORD);
  const text = async (who, url) => { const res = await who.get(url); return { status: res.status, html: await res.text() }; };
  const drill = (id, metric, extra = '') => `/attendance/sessions/${id}/people?metric=${metric}${extra}`;
  const rowsOf = (html) => [...(html.split('class="data u-desktop-only attendance-people__table"')[1] || '').matchAll(/<tr>\s*<td data-label="Name">([^<]*)<\/td>\s*<td data-label="Member ID">([^<]*)<\/td>\s*<td data-label="Type">([^<]*)<\/td>\s*<td data-label="Cell group">([^<]*)<\/td>\s*<td data-label="Congregation">([^<]*)<\/td>\s*<td data-label="Attendance">([^<]*)<\/td>/g)]
    .map((m) => ({ name: m[1].replace(/&#39;/g, "'"), code: m[2], type: m[3], group: m[4], congregation: m[5], attendance: m[6] }));
  const printRows = (html) => [...(html.split('attendance-print__table')[1] || '').matchAll(/<tr><td>(\d+)<\/td><td>([^<]*)<\/td><td>([^<]*)<\/td><td>([^<]*)<\/td><td>([^<]*)<\/td><td>([^<]*)<\/td><td>([^<]*)<\/td><\/tr>/g)].map((m) => ({ n: Number(m[1]), name: m[2].replace(/&#39;/g, "'"), code: m[3], type: m[4], attendance: m[7] }));
  const headline = (html) => Number(/<strong>[^<]*<\/strong> &middot; (\d+) (?:person|people)<\/p>/.exec(html)?.[1]);
  const summary = attendance.sessionSummary;

  // ---- 1. every figure reconciles with the number it came from, in each lifecycle ---------------------------------------------------------------------------------------
  const before = tables();
  const auditStart = auditFloor();
  {
    const x = summary(sX.id); const tr = x.tracked;
    assert.equal(x.phase, 'finalized');
    const expectedFigures = { members: x.physical.members, first_timers: x.physical.firstTimers, total: x.physical.total, present_expected: tr.present, vacation: tr.vacation, absent: tr.absent };
    assert.equal(x.physical.members, 4 + 3 + 30 + 0 + 0 + 0, 'sanity: E1, E2, E6, E7, U1-U3 and thirty bulk members');
    assert.equal(x.physical.firstTimers, 3, 'sanity: Tess, Abe and Cora (Joey was linked to a member who has their own mark)');
    for (const [metric, figure] of Object.entries(expectedFigures)) {
      const page = await text(admin, drill(sX.id, metric, '&page_size=100'));
      assert.equal(page.status, 200, metric);
      assert.equal(headline(page.html), figure, `${metric}: the page says ${figure}`);
      const shown = rowsOf(page.html);
      assert.equal(shown.length, Math.min(figure, 100), `${metric}: ${shown.length} rows listed for the figure ${figure}`);
      assert.equal(printRows(page.html).length, figure, `${metric}: the printed list also holds exactly ${figure}`);
      // every figure on the summary strip is the canonical number too
      for (const [other, value] of Object.entries(expectedFigures)) assert.match(page.html, new RegExp(`${other === metric ? 'is-current' : 'attendance-people__figure'}[^>]*>\\s*<span class="stat__label">[^<]+</span>\\s*<span class="stat__value">${value}</span>`));
    }
    // the tiles on the register are links to exactly these figures
    const reg = (await text(admin, `/attendance/sessions/${sX.id}`)).html;
    const tile = (metric) => new RegExp(`<a class="card stat stat--drill" href="/attendance/sessions/${sX.id}/people\\?metric=${metric}" target="_blank" rel="noopener">\\s*<p class="stat__label">([^<]+)</p>\\s*<p class="stat__value">(\\d+)</p>`).exec(reg);
    for (const [metric, figure] of Object.entries(expectedFigures)) { const m = tile(metric); assert.ok(m, `the register has a tile for ${metric}`); assert.equal(Number(m[2]), figure, `the ${metric} tile says ${figure} and its list holds ${figure}`); }
    assert.ok(!new RegExp(`<a class="card stat stat--drill"[^>]*>\s*<p class="stat__label">Expected</p>`).test(reg), 'the static Expected tile is not a link');
    console.log(`PASS (reconcile, finalized) members ${x.physical.members}, First Timers ${x.physical.firstTimers}, total ${x.physical.total}, expected present ${tr.present}, vacation ${tr.vacation}, absent ${tr.absent}: each list and each printed list holds exactly its figure, and each register tile is a new-tab link to its own list`);
  }
  {
    // before tracking: a headcount and nothing derived
    const p = summary(sP.id); assert.equal(p.phase, 'pre_go_live');
    for (const metric of ['members', 'first_timers', 'total']) { const page = await text(admin, drill(sP.id, metric)); assert.equal(page.status, 200); assert.equal(headline(page.html), { members: p.physical.members, first_timers: p.physical.firstTimers, total: p.physical.total }[metric]); }
    for (const metric of ['vacation', 'absent', 'present_expected']) assert.equal((await text(admin, drill(sP.id, metric))).status, 404, `before tracking, ${metric} is not listed (nothing is derived)`);
    const reg = (await text(admin, `/attendance/sessions/${sP.id}`)).html;
    assert.ok(/metric=members/.test(reg) && /metric=first_timers/.test(reg) && /metric=total/.test(reg), 'the headcount tiles are links');
    assert.ok(!/metric=(vacation|absent|present_expected)/.test(reg), 'Vacation, Absent and Not recorded stay plain before tracking');
    // not taken
    const n = summary(sN.id); assert.equal(n.phase, 'not_taken');
    assert.equal(headline((await text(admin, drill(sN.id, 'total'))).html), n.physical.total);
    assert.equal((await text(admin, drill(sN.id, 'vacation'))).status, 404);
    assert.equal((await text(admin, drill(sN.id, 'absent'))).status, 404);
    // awaiting finalization: absent is not shown on the screen, so it has no list; vacation does
    const o = summary(sO.id); assert.equal(o.phase, 'awaiting_finalization');
    assert.equal(headline((await text(admin, drill(sO.id, 'vacation'))).html), o.tracked.vacation);
    assert.equal((await text(admin, drill(sO.id, 'absent'))).status, 404, 'an unfinalized Friday has no Absent figure, so no list');
    assert.equal(headline((await text(admin, drill(sO.id, 'total'))).html), o.physical.total);
    // cancelled, other session types, missing sessions
    assert.equal((await text(admin, drill(sC.id, 'vacation'))).status, 404);
    assert.equal((await text(admin, drill(meetingId, 'total'))).status, 404, 'a cell group meeting has no drill-down');
    assert.equal((await text(admin, drill(999999, 'total'))).status, 404);
    console.log('PASS (reconcile, other lifecycles) before tracking: headcount lists only, nothing derived; Not Taken: total only; awaiting finalization: vacation and totals but no Absent; cancelled, meetings and missing services: 404');
  }

  // ---- 2. one human, one row ------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const all = rowsOf((await text(admin, drill(sX.id, 'total', '&page_size=100'))).html);
    const keys = all.map((r) => `${r.type}|${r.name}|${r.code}`);
    assert.equal(new Set(keys).size, all.length, 'no row appears twice');
    assert.ok(all.some((r) => r.type === 'First Timer' && r.name === 'Cora Villa' && r.attendance === 'First Timer (since a member)' && /^CCIQ-/.test(r.code)), 'a First Timer who became a member afterwards is listed once, as a First Timer, with the member ID they now have');
    assert.equal(all.filter((r) => r.name.includes('Joey') || r.name === 'Jose Reyes' || r.name === 'Joey Reyes').length, 2, 'the linked First Timer is not listed beside the member (Jose Reyes and Joey Reyes are the two members)');
    assert.ok(!all.some((r) => r.type === 'First Timer' && r.name === 'Joey Reyes'), 'Joey, linked to a member who has their own mark, is that member only');
    const ft = rowsOf((await text(admin, drill(sX.id, 'first_timers'))).html);
    assert.deepEqual(ft.map((r) => r.name).sort(), ['Abe', 'Cora Villa', 'Tess Zapata'], 'exactly the three First Timers');
    assert.ok(ft.every((r) => r.type === 'First Timer'));
    const expectedAbsent = rowsOf((await text(admin, drill(sX.id, 'absent'))).html);
    assert.deepEqual(expectedAbsent.map((r) => [r.name, r.attendance]).sort((a, b) => a[0].localeCompare(b[0])), [['Juan de la Peña', 'Absent (marked absent)'], ['Zoe Abad', 'Absent (no record)']], 'absent: the marked one and the one with no record (derived on a finalized Friday)');
    const vac = rowsOf((await text(admin, drill(sX.id, 'vacation'))).html);
    assert.deepEqual(vac.map((r) => r.name), ['Maria Dela Cruz']);
    const unexpected = rowsOf((await text(admin, drill(sX.id, 'members', '&page_size=100'))).html).filter((r) => r.attendance === 'Present, not on the expected list').map((r) => r.name);
    assert.ok(['Ulysses Zamora', 'Pedro Dela Cruz', 'Sofia De La Rosa'].every((n) => unexpected.includes(n)), 'members who were present but not expected are marked as such');
    console.log('PASS (once) a First Timer who became a member is listed once (with their member ID); one linked to a member who has their own mark is that member only; absent distinguishes marked from no record; unexpected members are labelled');
  }

  // ---- 3. search, sort, pagination, validation -------------------------------------------------------------------------------------------------------------------------------
  {
    const q = async (extra) => text(admin, drill(sX.id, 'total', extra));
    const found = rowsOf((await q('&q=reyes')).html);
    assert.ok(found.length === 2 && found.every((r) => /Reyes/.test(r.name)), 'search is case-insensitive and matches surnames');
    assert.equal(headline((await q('&q=reyes')).html), 40, 'the headline stays the figure; the search narrows the list');
    assert.match((await q('&q=reyes')).html, /Showing 1&ndash;2 of 2/);
    const code = found.find((r) => r.code)?.code;
    assert.deepEqual(rowsOf((await q(`&q=${code}`)).html).map((r) => r.code), [code], 'search by Member ID');
    assert.match((await q('&q=zzzzzz')).html, /No one matches that search/);
    for (const hostile of ['%', '_', '%25', "'; DROP TABLE members;--", '<script>alert(1)</script>', 'a'.repeat(500), '\\']) {
      const page = await q(`&q=${encodeURIComponent(hostile)}`);
      assert.ok(page.status === 200, `hostile search ${JSON.stringify(hostile).slice(0, 20)}`);
      assert.ok(!page.html.includes('<script>alert(1)</script>'), 'the typed term is escaped');
      assert.ok(headline(page.html) === 40);
    }
    assert.equal(rowsOf((await q('&q=%25')).html).length, 0, 'a % is a character, not a wildcard');
    // sorting: every key, both directions, an invalid key falls back
    const nameOrder = rowsOf((await q('&page_size=100')).html).map((r) => r.name);
    const desc = rowsOf((await q('&page_size=100&sort=name&dir=desc')).html).map((r) => r.name);
    assert.deepEqual(desc, [...nameOrder].reverse(), 'name descending is the exact reverse');
    for (const key of ['type', 'member_id', 'cell_group', 'congregation', 'classification']) {
      const asc = await q(`&page_size=100&sort=${key}`); const dsc = await q(`&page_size=100&sort=${key}&dir=desc`);
      assert.equal(asc.status, 200); assert.equal(rowsOf(asc.html).length, 40); assert.equal(rowsOf(dsc.html).length, 40, `${key}: nobody lost either way`);
      assert.match(asc.html, new RegExp(`aria-sort="ascending"[^>]*><a class="sortable-column is-active"[^>]*aria-label="Sort by [^"]+, ascending"`), `${key}: the active column says so`);
    }
    const byType = rowsOf((await q('&page_size=100&sort=type')).html).map((r) => r.type);
    assert.deepEqual(byType, [...byType].sort(), 'sorted by type, Member before First Timer');
    assert.deepEqual(rowsOf((await q('&sort=%27%3B%20DROP&dir=sideways&page_size=7')).html).map((r) => r.name), nameOrder.slice(0, 25), 'an invalid sort key, direction and page size fall back to name, ascending, 25');
    // pagination: 40 people, 25 a page
    const page1 = await q(''); const page2 = await q('&page=2');
    assert.equal(rowsOf(page1.html).length, 25); assert.equal(rowsOf(page2.html).length, 15);
    assert.deepEqual([...rowsOf(page1.html), ...rowsOf(page2.html)].map((r) => r.name), nameOrder, 'pages are consecutive slices of one ordered list: nobody twice, nobody missed');
    assert.equal(rowsOf((await q('&page=99999999999999999999')).html).length, 15, 'a huge page number lands on the last page');
    assert.equal(rowsOf((await q('&page=abc')).html).length, 25);
    const sized = await q('&page_size=50'); assert.equal(rowsOf(sized.html).length, 40);
    // search, sort and size survive paging
    const carried = await q('&q=bulk&sort=classification&dir=desc&page_size=25');
    assert.match(carried.html, /href="\/attendance\/sessions\/\d+\/people\?[^"]*q=bulk[^"]*"/, 'the pager carries the search');
    assert.match(carried.html, /page=2/);
    const next = await text(admin, carried.html.match(/href="(\/attendance\/sessions\/\d+\/people\?[^"]*page=2[^"]*)"/)[1].replace(/&amp;/g, '&'));
    assert.equal(rowsOf(next.html).length, 5, 'page 2 of the thirty bulk members (25 + 5), search and sort kept');
    assert.ok(rowsOf(next.html).every((r) => /Bulk/.test(r.name)));
    console.log('PASS (search, sort, paging) case-insensitive name and Member ID search with % and _ as plain characters and hostile input escaped; every sort key both ways; invalid parameters fall back; 40 people over two pages are consecutive slices; search, sort and size survive paging');
  }

  // ---- 4. access ----------------------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const url = drill(sX.id, 'total');
    assert.equal((await text(church, url)).status, 200, 'a Church Administrator may');
    const anon = await fetch(`${portal.base}${url}`, { redirect: 'manual' });
    assert.ok([302, 303].includes(anon.status) && /login/.test(anon.headers.get('location')), 'signed out: sent to sign in'); await anon.text();
    for (const [label, key] of [['a Cell Group Leader', 'leader'], ['a Member', 'member'], ['a Kiosk account', 'kiosk']]) {
      const who = await signIn(portal.base, emails[key], PASSWORD);
      const res = await text(who, url);
      assert.ok([302, 403, 404].includes(res.status), `${label} is refused (${res.status})`); // a Kiosk account is simply sent back to the Kiosk
      assert.ok(!res.html.includes('Zapata') && !res.html.includes('Zamora'), `${label}: no name leaks in the refusal`);
    }
    // a leader is not offered the links (the list would not add up to their number)
    const leader = await signIn(portal.base, emails.leader, PASSWORD);
    const leaderReg = await text(leader, `/attendance/sessions/${sX.id}`);
    if (leaderReg.status === 200) assert.ok(!leaderReg.html.includes('/people?metric='), 'a Leader is not shown drill-down links');
    const leaderLanding = await text(leader, '/attendance');
    if (leaderLanding.status === 200) assert.ok(!leaderLanding.html.includes('/people?metric='), 'nor on the landing chart');
    // invalid figures
    for (const bad of ['abc', '%27', 'TOTAL', 'members;', '../x', '']) {
      const res = await text(admin, `/attendance/sessions/${sX.id}/people?metric=${encodeURIComponent(bad)}`);
      assert.equal(res.status, 400, `metric ${JSON.stringify(bad)} is rejected (${res.status})`);
    }
    assert.equal((await text(admin, `/attendance/sessions/${sX.id}/people`)).status, 200, 'no metric means the total');
    assert.equal((await text(admin, `/attendance/sessions/abc/people?metric=total`)).status, 404);
    // privacy: no contact data, notes, dates of birth in the list
    const html = (await text(admin, drill(sX.id, 'total', '&page_size=100'))).html;
    assert.ok(!/@|phone|\+974|birth|address|notes/i.test(html.slice(html.indexOf('attendance-people__table'), html.indexOf('attendance-print'))), 'only name, Member ID, type, group, congregation and attendance are shown');
    assert.equal(tables(), before, 'viewing any list wrote nothing');
    const audited = db.prepare('SELECT DISTINCT action FROM audit_logs WHERE id > ?').all(auditStart).map((r) => r.action);
    assert.ok(audited.every((a) => /^(auth|access)./.test(a)), `the only audit rows are sign-ins and refused attempts (${audited.join(', ')})`);
    console.log('PASS (access) Super and Church Administrators may; signed out, a Leader, a Member and a Kiosk account are refused with nothing leaked; a Leader is not offered the links; unknown figures are 400; no contact or private data in the list; viewing writes nothing');
  }

  // ---- 5. print: everyone, canonical order -----------------------------------------------------------------------------------------------------------------------------------------
  {
    const page = await text(admin, drill(sX.id, 'total', '&sort=classification&dir=desc&page_size=25&page=2'));
    const printed = printRows(page.html);
    assert.equal(printed.length, 40, 'the printed list holds all 40 people although the screen shows page 2 of 25');
    assert.ok(printed.every((r, i) => r.n === i + 1), 'numbered 1 to 40');
    // an independent expected order: last name, then first name, then middle name
    const people = [
      ['Abe', '', ''], ['Ana', 'Santos', ''], ['Ann Marie', 'Santos', ''], ['Cora', 'Villa', ''], ['Jose', 'Reyes', ''], ['Jose', 'Reyes', 'Maria'], ['Pedro', 'Dela Cruz', ''], ['Sofia', 'De La Rosa', ''],
      ['Tess', 'Zapata', ''], ['Ulysses', 'Zamora', ''], ...bulk.map((b) => [b.first_name, 'Bulk', ''])
    ];
    const c = new Intl.Collator('en', { sensitivity: 'base', numeric: true });
    people.sort((a, b) => c.compare(a[1], b[1]) || c.compare(a[0], b[0]) || c.compare(a[2], b[2]));
    const shownName = (r) => (r.name.includes(', ') ? r.name.split(', ').reverse().join(' ') : r.name);
    const got = printed.map((r) => shownName(r));
    assert.deepEqual(got.slice(0, 4), ['Abe', ...people.slice(1, 4).map((p) => `${p[0]} ${p[1]}`)].slice(0, 4), 'a person with no surname comes first, as in the Members and First Timers lists, then Bulk...');
    const flat = people.map((p) => (p[1] ? `${p[0]} ${p[1]}` : p[0]));
    assert.deepEqual(got, flat, 'the exact canonical order: last name, then first name, then middle name');
    const rosa = got.indexOf('Sofia De La Rosa'); const cruz = got.indexOf('Pedro Dela Cruz');
    assert.ok(rosa >= 0 && cruz >= 0 && cruz < rosa === false, 'the structured surname is used: "De La Rosa" sorts before "Dela Cruz"; a "last word of the display name" rule would put Cruz first');
    const jose = got.indexOf('Jose Reyes'); assert.ok(got.indexOf('Jose Reyes', jose + 1) === jose + 1 || got[jose + 1] === 'Jose Reyes', 'Jose Reyes and Jose Maria Reyes sit together, ordered by middle name');
    const same = printRows((await text(admin, drill(sX.id, 'total', '&sort=type&dir=asc'))).html).map((r) => r.name);
    assert.deepEqual(same, printed.map((r) => r.name), 'the print order does not depend on the screen sort or page');
    // the report states what it is
    assert.match(page.html, /<section class="print-only attendance-print"/);
    assert.match(page.html, /Friday Service Attendance/);
    assert.match(page.html, /Members present: <strong>37<\/strong> &middot; First Timers: <strong>3<\/strong> &middot; Returning: <strong>0<\/strong> &middot; Total present: <strong>40<\/strong>/);
    assert.match(page.html, /Printed \d{1,2} \w+ \d{4}, \d{2}:\d{2} \(Qatar time\)/);
    assert.match(page.html, /Ordered by last name, then first name/);
    // a search prints only the matches, and says so
    const filtered = await text(admin, drill(sX.id, 'total', '&q=bulk'));
    assert.equal(printRows(filtered.html).length, 30);
    assert.match(filtered.html, /filtered by &ldquo;bulk&rdquo;; the figure without the filter is 40/);
    // lifecycle-specific printouts
    const absentPrint = printRows((await text(admin, drill(sX.id, 'absent'))).html);
    assert.equal(absentPrint.length, 2);
    console.log('PASS (print data) the printed list holds all 40 people whatever page or sort is on screen, numbered, in the exact canonical order (last, first, middle name; structured fields, so "De La Rosa" precedes "Dela Cruz"), with totals, the figure, the filter and a Qatar-time stamp');
  }

  // ---- 6. a real browser: print layout, chart bars, tiles, widths ---------------------------------------------------------------------------------------------------------------------
  {
    const context = await browser.newContext();
    await context.addCookies(admin.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const tab = await context.newPage();
    await tab.setViewportSize({ width: 1280, height: 900 });
    await tab.goto(`${portal.base}${drill(sX.id, 'total', '&page_size=25')}`, { waitUntil: 'load' });
    assert.equal(await tab.locator('.attendance-print').isVisible(), false, 'on screen the printed report is hidden');
    await tab.emulateMedia({ media: 'print' });
    assert.equal(await tab.locator('.attendance-print').isVisible(), true, 'in print it is shown');
    const hidden = await tab.evaluate(() => ['.topbar', '.sidenav', '.screen-only', '.pagination', '.filters', '[data-print]', '.breadcrumb'].map((s) => [s, [...document.querySelectorAll(s)].every((e) => getComputedStyle(e).display === 'none' || e.getBoundingClientRect().height === 0)]));
    for (const [selector, gone] of hidden) assert.ok(gone, `print hides ${selector}`);
    const printed = await tab.evaluate(() => ({ rows: document.querySelectorAll('.attendance-print__table tbody tr').length, overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, theadDisplay: getComputedStyle(document.querySelector('.attendance-print__table thead')).display }));
    assert.equal(printed.rows, 40, 'print has all 40 rows, not one page of 25');
    assert.equal(printed.theadDisplay, 'table-header-group', 'the header row repeats on every printed page');
    assert.equal(printed.overflow, 0);
    const pdf = await tab.pdf({ format: 'A4', printBackground: false });
    assert.equal(pdf.subarray(0, 4).toString(), '%PDF');
    await tab.close();

    // the chart: bars are links to the right service, new tab, keyboard and hover
    const landing = await context.newPage();
    await landing.setViewport?.({ width: 1280, height: 900 });
    await landing.setViewportSize({ width: 1280, height: 900 });
    await landing.goto(`${portal.base}/attendance`, { waitUntil: 'load' });
    const bars = await landing.$$eval('.bars__col--link', (els) => els.map((e) => ({ href: e.getAttribute('href'), target: e.target, rel: e.rel, label: e.getAttribute('aria-label'), value: e.querySelector('.bars__value').textContent.trim() })));
    assert.ok(bars.length >= 1, 'the chart has link bars');
    const barX = bars.find((b) => b.href === `/attendance/sessions/${sX.id}/people?metric=total`);
    assert.ok(barX, 'the bar for the finalized Friday links to that service\'s total list');
    assert.equal(barX.target, '_blank'); assert.match(barX.rel, /noopener/);
    assert.equal(barX.value, '40'); assert.match(barX.label, /: 40 present\. Opens the list of who was there in a new tab\./);
    const barLocator = landing.locator(`.bars__col--link[href="/attendance/sessions/${sX.id}/people?metric=total"]`);
    const rest = await barLocator.evaluate((e) => getComputedStyle(e).transform);
    await barLocator.hover(); await landing.waitForTimeout(250);
    const lifted = await barLocator.evaluate((e) => ({ transform: getComputedStyle(e).transform, cursor: getComputedStyle(e).cursor }));
    assert.notEqual(lifted.transform, rest, 'a hovered bar lifts a little');
    assert.equal(lifted.cursor, 'pointer');
    // keyboard: focus it, Enter opens a new tab on the right list
    await landing.mouse.move(0, 0);
    await barLocator.focus();
    const ring = await barLocator.evaluate((e) => { const s = getComputedStyle(e); return s.outlineStyle !== 'none' && parseFloat(s.outlineWidth) >= 2; });
    assert.ok(ring, 'keyboard focus is visible on a bar');
    const [popup] = await Promise.all([context.waitForEvent('page'), landing.keyboard.press('Enter')]);
    await popup.waitForLoadState('load');
    assert.match(popup.url(), new RegExp(`/attendance/sessions/${sX.id}/people\\?metric=total$`), 'Enter opens the list in a new tab');
    assert.equal(landing.url().endsWith('/attendance'), true, 'the Attendance page stayed where it was');
    assert.match(await popup.locator('h1').innerText(), /Friday Service Attendance/);
    await popup.close();

    // a tile: a click opens a new tab, hover lifts, and the figure matches
    const reg = await context.newPage();
    await reg.setViewportSize({ width: 1280, height: 900 });
    await reg.goto(`${portal.base}/attendance/sessions/${sX.id}`, { waitUntil: 'load' });
    const tileLoc = reg.locator(`a.stat--drill[href$="metric=first_timers"]`);
    const tileRest = await tileLoc.evaluate((e) => getComputedStyle(e).transform);
    await tileLoc.hover(); await reg.waitForTimeout(250);
    assert.notEqual(await tileLoc.evaluate((e) => getComputedStyle(e).transform), tileRest, 'a hovered tile lifts a little');
    const [tilePopup] = await Promise.all([context.waitForEvent('page'), tileLoc.click()]);
    await tilePopup.waitForLoadState('load');
    assert.equal(await tilePopup.locator('.attendance-people__figure.is-current .stat__value').innerText(), '3', 'the First Timers tile opens the list of 3');
    await tilePopup.close();
    // other cards do not animate
    assert.equal(await reg.locator('div.card.stat').first().evaluate((e) => getComputedStyle(e).transitionProperty), 'all', 'ordinary cards keep their ordinary style');
    assert.equal(await reg.locator('div.card.stat').first().evaluate((e) => getComputedStyle(e).transform), 'none');
    await reg.close();
    await landing.close();

    // widths: the list page and the register's tiles
    const problems = [];
    for (const width of [320, 360, 390, 430, 600, 768, 820, 1024, 1280, 1440, 1920]) {
      for (const url of [drill(sX.id, 'total', '&page_size=25'), `/attendance/sessions/${sX.id}`, '/attendance']) {
        const t = await context.newPage();
        await t.setViewportSize({ width, height: 800 });
        await t.goto(portal.base + url, { waitUntil: 'load' });
        const m = await t.evaluate(() => ({ overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, tableShown: Boolean(document.querySelector('.attendance-people__table') && document.querySelector('.attendance-people__table').getBoundingClientRect().width > 0),
          cardsShown: [...document.querySelectorAll('.record-list__item')].some((e) => e.getBoundingClientRect().width > 0),
          small: [...document.querySelectorAll('a.stat--drill, a.bars__col--link, .attendance-people__figure')].filter((e) => e.getBoundingClientRect().width > 0).map((e) => { const r = e.getBoundingClientRect(); return { w: r.width, h: r.height, c: e.className.split(' ')[0] }; }),
          clipped: [...document.querySelectorAll('.attendance-people__figure, .stat--drill')].filter((e) => e.scrollWidth > e.clientWidth + 1).length }));
        const tag = `${width}px ${url.split('?')[0].split('/').slice(-2).join('/')}`;
        if (m.overflow > 0) problems.push(`${tag}: sideways scroll ${m.overflow}px`);
        if (m.clipped) problems.push(`${tag}: ${m.clipped} figure(s) clip their text`);
        if (url.includes('/people')) {
          if (width <= 720 && !m.cardsShown) problems.push(`${tag}: no card list on a narrow screen`);
          if (width > 720 && !m.tableShown) problems.push(`${tag}: no table on a wide screen`);
        }
        for (const s of m.small) if (s.h < 40 && s.c !== 'bars__col--link') problems.push(`${tag}: a ${s.c} is only ${Math.round(s.h)}px high to touch`);
        await t.close();
      }
    }
    assert.deepEqual(problems, [], problems.join('\n'));
    await context.close();
    console.log('PASS (browser) print shows all 40 rows with the header repeating and nothing but the report; each bar and tile is a new-tab link to the right list, lifts a little on hover, shows a keyboard focus ring and opens with Enter; other cards stay still; 11 widths from 320 to 1920 px: no overflow, a card list on narrow screens, touch-sized figures');
  }
} finally {
  await browser.close();
  await portal.stop();
}
db.close();
env.cleanup();
console.log('ALL PASS');
