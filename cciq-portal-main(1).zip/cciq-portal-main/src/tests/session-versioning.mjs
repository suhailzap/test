import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness: independent adversarial (Codex) verification found
 * three concrete gaps in the route-specific session-delete approach from an
 * earlier pass (deactivate-then-reactivate without an intervening request,
 * a login racing a concurrent password reset, and a session row
 * resurrected by an unrelated in-flight save racing a delete). Those were
 * fixed with a session-versioning invariant: every session captured
 * password_hash at login and attachUser() compared it live on every
 * request.
 *
 * Second pass (independent/Codex re-verification) found that fix itself
 * insufficient: password_hash only ever moves on a CREDENTIAL change, never
 * on an account STATE transition. A deactivate-then-reactivate cycle left
 * password_hash completely untouched, so:
 *   A. a session resurrected by the save-vs-delete race stayed valid
 *      straight through a full deactivate -> reactivate cycle (not just
 *      "no request during the disabled window", as the first pass tested -
 *      the RESURRECTED row specifically survives reactivation too), and
 *   B. a login whose slow verifyPassword() call straddled a deactivate
 *      immediately followed by a reactivate, both completing before the
 *      post-verification re-check, saw status back at 'active' and
 *      password_hash unchanged - nothing in that re-check caught it.
 *   C. Kiosk sessions authenticate through this exact same login route and
 *      attachUser() middleware, so both attacks apply to them identically.
 *
 * Fixed with security_generation (migration 0028, users.security_generation,
 * see services/users.js): a monotonic counter, independent of password_hash,
 * that advances on a password change/reset AND on both directions of a
 * status change, and is never decremented - reactivation does not restore
 * the pre-disable value. req.session.securityGeneration replaces
 * req.session.authVersion, and attachUser() compares it live on every
 * request.
 *
 * R03 FINAL LEGACY-SESSION CORRECTION (Codex/independent verification):
 * this originally exempted a session with no captured securityGeneration
 * at all from the comparison, to avoid force-logging-out sessions that
 * predated this feature's own deployment. That exemption was itself a gap:
 * combined with the atomic stale-rejection in setPassword() (see routes/
 * auth.js's self-password-change route and b436b40), a self-service
 * password change begun on such a session, racing a concurrent security
 * event that deletes it via destroySessionsForUser(), could have that
 * deleted row resurrected by this same (rejected) request's own
 * end-of-response save (SqliteSessionStore.set() is an upsert) - and the
 * exemption then let that resurrected, still-no-generation session
 * authenticate again, indefinitely. Now that production and development run
 * from entirely separate, independently deployed databases, there is no
 * pre-this-feature session data left to preserve, so the exemption is gone:
 * every authenticated session must carry a securityGeneration matching the
 * user's current one, with no exception for a missing value - see Attack I
 * below. A fresh login always captures the current generation normally.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-session-versioning-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createUser, setUserStatus, setPassword } = await import('../services/users.js');
const { default: db } = await import('../db/index.js');

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;
const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
if (process.env.DEBUG_AUTH_RACE) server.stderr.on('data', (d) => process.stderr.write(d));
await waitForServerReady(base, server);

async function prepareLogin() {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const preCookie = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ');
  return { csrf: csrfMatch[1], cookie: preCookie };
}
function submitLogin({ csrf, cookie }, email, password) {
  return fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ email, password, _csrf: csrf })
  });
}
async function login(email, password) {
  const prepared = await prepareLogin();
  return submitLogin(prepared, email, password);
}
async function cookieOf(loginPost, fallback) {
  return (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || fallback;
}
async function isAuth(cookie, path = '/') {
  const res = await fetch(`${base}${path}`, { headers: { Cookie: cookie }, redirect: 'manual' });
  if (res.status === 200) return true;
  if (res.status === 302 && (res.headers.get('location') || '').includes('/login')) return false;
  throw new Error(`unexpected status ${res.status}`);
}
function sidOf(cookie) {
  return decodeURIComponent(cookie.match(/cciq\.sid=([^;]+)/)[1]).replace(/^s:/, '').split('.')[0];
}
function generationOf(userId) {
  return db.prepare('SELECT security_generation FROM users WHERE id = ?').get(userId).security_generation;
}
async function csrfFor(pagePath, cookie) {
  const page = await fetch(`${base}${pagePath}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

// --- A. Held authenticated response before save -> deactivate -> reactivate
//     -> stale response writes session -> original cookie MUST remain
//     invalid. Reproduces the save-vs-delete race directly (an unrelated
//     in-flight request's own end-of-response save landing AFTER
//     destroySessionsForUser()'s delete - SqliteSessionStore.set() is an
//     upsert, see lib/session-store.js), THEN reactivates - proving the
//     resurrected row does not regain validity even after a full cycle. ---
{
  await createUser({ email: 'attack.a@fixture.invalid', password: 'AttackAPassw0rd!2026', displayName: 'Attack A', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.a@fixture.invalid');
  const loginPost = await login('attack.a@fixture.invalid', 'AttackAPassw0rd!2026');
  const cookie = await cookieOf(loginPost);
  assert.equal(await isAuth(cookie), true, 'sanity: session starts authenticated');

  const sid = sidOf(cookie);
  const rowBeforeDelete = db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid);
  assert.ok(rowBeforeDelete, 'sanity: the session row exists before this test resurrects it');

  setUserStatus(row.id, 'disabled');
  assert.equal(db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid), undefined, 'sanity: deactivation destroyed the session row');

  // The stale in-flight save: resurrects the exact row express-session
  // would have written, still carrying the PRE-DISABLE security_generation.
  db.prepare('INSERT INTO sessions (sid, sess, expires) VALUES (?, ?, ?)').run(sid, rowBeforeDelete.sess, Date.now() + 3600000);
  assert.ok(db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid), 'sanity: the row has been resurrected, simulating the race');

  setUserStatus(row.id, 'active');

  assert.equal(await isAuth(cookie), false,
    'ATTACK A MUST REMAIN CLOSED: a session resurrected by a save-vs-delete race must not regain validity after deactivate -> reactivate');
  console.log('PASS (Attack A): held-response resurrection across a full deactivate -> reactivate cycle leaves the original cookie invalid');
}

// --- B. Login paused during password verification -> deactivate/reactivate
//     entirely within that window -> login resumes -> authentication MUST
//     fail. A genuine race (the login is fired and NOT awaited before the
//     status flips twice against the same fixture database), not simulated. ---
{
  await createUser({ email: 'attack.b@fixture.invalid', password: 'AttackBPassw0rd!2026', displayName: 'Attack B', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.b@fixture.invalid');

  // The CSRF token is fetched (and awaited) BEFORE racing anything, so the
  // toggle below races only against the POST's own server-side processing
  // (row read -> verifyPassword -> re-check) - not against an earlier,
  // unrelated GET round-trip. A short delay before the toggle gives the
  // request time to actually reach the server and begin the deliberately
  // slow scrypt comparison (N=2**15) before the toggle fires - without it,
  // two purely-synchronous DB writes on the test's own side complete before
  // the request has even left the network stack, landing outside the
  // verification window entirely rather than inside it.
  const prepared = await prepareLogin();
  const loginPromise = submitLogin(prepared, 'attack.b@fixture.invalid', 'AttackBPassw0rd!2026');
  await new Promise((resolve) => setTimeout(resolve, 20));
  setUserStatus(row.id, 'disabled');
  setUserStatus(row.id, 'active');
  const loginPost = await loginPromise;

  if (loginPost.status === 302) {
    // The race resolved in the login's favor at the network level (rare,
    // timing-dependent) - the resulting session must still fail the live
    // securityGeneration check on its very next request.
    const cookie = await cookieOf(loginPost);
    assert.equal(await isAuth(cookie), false,
      'ATTACK B MUST REMAIN CLOSED: even if the race resolves at the network level, the resulting session must not remain valid');
  } else {
    assert.equal(loginPost.status, 401,
      'ATTACK B MUST REMAIN CLOSED: a login racing an intervening deactivate+reactivate (both completing before the re-check) must be refused');
  }
  console.log('PASS (Attack B): a login racing an intervening deactivate+reactivate cannot produce a valid session');

  // The account must still work normally afterward, unaffected by the attack.
  const relogin = await login('attack.b@fixture.invalid', 'AttackBPassw0rd!2026');
  assert.equal(relogin.status, 302, 'the account must still be able to log in normally afterward');
}

// --- C. Repeat the stale-session attack (A) with a KIOSK account - kiosk
//     access must remain invalid. Kiosk sessions authenticate through the
//     identical /login route and attachUser() middleware as any other
//     account, so this proves no separate kiosk code path reopened the gap. ---
{
  await createUser({ email: 'attack.c.kiosk@fixture.invalid', password: 'AttackCPassw0rd!2026', displayName: 'Attack C Kiosk', roleKeys: ['kiosk'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.c.kiosk@fixture.invalid');
  const loginPost = await login('attack.c.kiosk@fixture.invalid', 'AttackCPassw0rd!2026');
  const cookie = await cookieOf(loginPost);
  assert.equal(await isAuth(cookie, '/kiosk'), true, 'sanity: the kiosk session starts authenticated');

  const sid = sidOf(cookie);
  const rowBeforeDelete = db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid);
  setUserStatus(row.id, 'disabled');
  assert.equal(db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid), undefined, 'sanity: deactivation destroyed the kiosk session row');
  db.prepare('INSERT INTO sessions (sid, sess, expires) VALUES (?, ?, ?)').run(sid, rowBeforeDelete.sess, Date.now() + 3600000);
  setUserStatus(row.id, 'active');

  assert.equal(await isAuth(cookie, '/kiosk'), false,
    'ATTACK C MUST REMAIN CLOSED: a resurrected KIOSK session must not regain validity after deactivate -> reactivate');
  console.log('PASS (Attack C): the same resurrection attack against a kiosk account leaves kiosk access invalid');
}

// --- D. Password reset while old sessions exist -> old sessions invalid. ---
{
  await createUser({ email: 'attack.d@fixture.invalid', password: 'AttackDOldPassw0rd!2026', displayName: 'Attack D', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.d@fixture.invalid');
  const cookie1 = await cookieOf(await login('attack.d@fixture.invalid', 'AttackDOldPassw0rd!2026'));
  const cookie2 = await cookieOf(await login('attack.d@fixture.invalid', 'AttackDOldPassw0rd!2026'));
  assert.equal(await isAuth(cookie1), true, 'sanity: device 1 starts authenticated');
  assert.equal(await isAuth(cookie2), true, 'sanity: device 2 starts authenticated');

  const generationBefore = generationOf(row.id);
  await setPassword(row.id, 'AttackDNewPassw0rd!2026', {}); // admin-mediated reset, no exceptSid
  assert.equal(generationOf(row.id), generationBefore + 1, 'a password reset must advance security_generation');

  assert.equal(await isAuth(cookie1), false, 'ATTACK D: device 1\'s old session must be invalid after a password reset');
  assert.equal(await isAuth(cookie2), false, 'ATTACK D: device 2\'s old session must be invalid after a password reset');
  console.log('PASS (Attack D): a password reset invalidates every session that existed before it');
}

// --- E. Self password change -> the intended current session continues
//     under the new generation, while every OTHER old session is
//     invalidated. Preserves the exceptSid design intentionally, rather
//     than a blanket sign-out-everyone-including-yourself. ---
{
  await createUser({ email: 'attack.e@fixture.invalid', password: 'AttackEOldPassw0rd!2026', displayName: 'Attack E', roleKeys: ['member'], mustChangePassword: false });
  const currentCookie = await cookieOf(await login('attack.e@fixture.invalid', 'AttackEOldPassw0rd!2026'));
  const otherDeviceCookie = await cookieOf(await login('attack.e@fixture.invalid', 'AttackEOldPassw0rd!2026'));
  assert.equal(await isAuth(currentCookie), true, 'sanity: the current device starts authenticated');
  assert.equal(await isAuth(otherDeviceCookie), true, 'sanity: the other device starts authenticated');

  const csrf = await csrfFor('/account/password', currentCookie);
  const res = await fetch(`${base}/account/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: currentCookie },
    body: new URLSearchParams({
      current_password: 'AttackEOldPassw0rd!2026', password: 'AttackENewPassw0rd!2026',
      confirm_password: 'AttackENewPassw0rd!2026', _csrf: csrf
    })
  });
  assert.equal(res.status, 302, 'a valid self-service password change must succeed');

  assert.equal(await isAuth(currentCookie), true,
    'ATTACK E: the session that performed the self-service change must remain authenticated under the new generation');
  assert.equal(await isAuth(otherDeviceCookie), false,
    'ATTACK E: every OTHER session must be invalidated by a self-service password change');
  console.log('PASS (Attack E): a self-service password change keeps the acting session valid while invalidating every other one');
}

function submitPasswordChange(cookie, csrf, current, password, confirm) {
  return fetch(`${base}/account/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ current_password: current, password, confirm_password: confirm, _csrf: csrf })
  });
}

// --- G. Codex/independent verification (R03 follow-up): a self-service
//     password change begun under generation N, racing a CONCURRENT ADMIN
//     PASSWORD RESET that completes while this request's own slow
//     verifyPassword()/hashPassword() work is still in flight. The stale
//     self-service change must be rejected outright: it must not overwrite
//     the admin's reset password, must not advance/overwrite security
//     state on its own stale authority, and must not restore the acting
//     session to validity. The admin's password remains authoritative. ---
{
  await createUser({ email: 'attack.g@fixture.invalid', password: 'AttackGOldPassw0rd!2026', displayName: 'Attack G', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.g@fixture.invalid');
  const actingCookie = await cookieOf(await login('attack.g@fixture.invalid', 'AttackGOldPassw0rd!2026'));
  assert.equal(await isAuth(actingCookie), true, 'sanity: the acting session starts authenticated');

  const csrf = await csrfFor('/account/password', actingCookie);
  const stalePromise = submitPasswordChange(actingCookie, csrf, 'AttackGOldPassw0rd!2026', 'AttackGStaleSelfPassw0rd!2026', 'AttackGStaleSelfPassw0rd!2026');
  // Lands during the self-service request's own slow verifyPassword()/
  // hashPassword() work - see Attack B above for why a real request needs
  // a short delay here rather than firing the concurrent event immediately.
  await new Promise((resolve) => setTimeout(resolve, 30));
  await setPassword(row.id, 'AttackGAdminResetPassw0rd!2026', {}); // admin-mediated reset, unconditional, no exceptSid
  const staleRes = await stalePromise;

  // R03 FINAL LEGACY-SESSION CORRECTION: the stale-rejection path now
  // destroys the acting session outright and redirects to sign in again,
  // rather than rendering an error on the still-authenticated page - see
  // routes/auth.js.
  assert.equal(staleRes.status, 302,
    'CODEX FINDING CONFIRMED FIXED: a self-service password change racing a concurrent admin reset must be refused, not silently committed');
  assert.match(staleRes.headers.get('location') || '', /\/login/, 'the refusal must redirect to sign in again');

  const loginWithAdminPassword = await login('attack.g@fixture.invalid', 'AttackGAdminResetPassw0rd!2026');
  assert.equal(loginWithAdminPassword.status, 302,
    'the ADMIN\'S reset password must remain authoritative - the stale self-service change must not have overwritten it');
  const loginWithStalePassword = await login('attack.g@fixture.invalid', 'AttackGStaleSelfPassw0rd!2026');
  assert.equal(loginWithStalePassword.status, 401,
    'the stale self-service password must never have taken effect at all');

  assert.equal(await isAuth(actingCookie), false,
    'CODEX FINDING CONFIRMED FIXED: the acting session must not regain access via the stale, rejected self-service change');
  console.log('PASS (Attack G): a self-service password change racing a concurrent admin reset is rejected; the admin\'s reset remains authoritative and the acting session does not regain access');
}

// --- H. Same race, but the concurrent security event is a
//     deactivate/reactivate cycle rather than a password reset - the
//     account's password never changes in this scenario, so the ONLY
//     signal available to catch the stale commit is security_generation
//     having moved. ---
{
  await createUser({ email: 'attack.h@fixture.invalid', password: 'AttackHPassw0rd!2026', displayName: 'Attack H', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.h@fixture.invalid');
  const actingCookie = await cookieOf(await login('attack.h@fixture.invalid', 'AttackHPassw0rd!2026'));
  assert.equal(await isAuth(actingCookie), true, 'sanity: the acting session starts authenticated');

  const csrf = await csrfFor('/account/password', actingCookie);
  const stalePromise = submitPasswordChange(actingCookie, csrf, 'AttackHPassw0rd!2026', 'AttackHStaleSelfPassw0rd!2026', 'AttackHStaleSelfPassw0rd!2026');
  await new Promise((resolve) => setTimeout(resolve, 30));
  setUserStatus(row.id, 'disabled');
  setUserStatus(row.id, 'active');
  const staleRes = await stalePromise;

  assert.equal(staleRes.status, 302,
    'CODEX FINDING CONFIRMED FIXED: a self-service password change racing a concurrent deactivate/reactivate must be refused, not silently committed');
  assert.match(staleRes.headers.get('location') || '', /\/login/, 'the refusal must redirect to sign in again');

  const loginWithOriginalPassword = await login('attack.h@fixture.invalid', 'AttackHPassw0rd!2026');
  assert.equal(loginWithOriginalPassword.status, 302,
    'the original password must remain in effect - neither the deactivate/reactivate nor the stale self-service change altered it');
  const loginWithStalePassword = await login('attack.h@fixture.invalid', 'AttackHStaleSelfPassw0rd!2026');
  assert.equal(loginWithStalePassword.status, 401,
    'the stale self-service password must never have taken effect at all');

  assert.equal(await isAuth(actingCookie), false,
    'CODEX FINDING CONFIRMED FIXED: the acting session must not regain access via the stale, rejected self-service change');
  console.log('PASS (Attack H): a self-service password change racing a concurrent deactivate/reactivate is rejected and the acting session does not regain access');
}

// --- I. R03 FINAL LEGACY-SESSION CORRECTION (Codex/independent
//     verification): the combined case. A. an authenticated session with no
//     captured securityGeneration at all (simulating one that predates this
//     feature, now that there is no real such data left to preserve across
//     the production/development split). B. a self-service password change
//     from that legacy session races a concurrent security event (an admin
//     reset). C. the stale credential update is rejected. D. the acting
//     legacy session must not regain authenticated access - not on its very
//     next request, and not via being resurrected by this rejected
//     request's own end-of-response session save racing the concurrent
//     event's destroySessionsForUser() delete. E. a fresh login afterward
//     succeeds normally and correctly captures the CURRENT generation. ---
{
  await createUser({ email: 'attack.i@fixture.invalid', password: 'AttackIOldPassw0rd!2026', displayName: 'Attack I', roleKeys: ['member'], mustChangePassword: false });
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get('attack.i@fixture.invalid');

  const legacyCookie = await cookieOf(await login('attack.i@fixture.invalid', 'AttackIOldPassw0rd!2026'));
  assert.equal(await isAuth(legacyCookie), true, 'sanity: the session starts authenticated');

  // The CSRF secret lives in the session itself, independent of
  // authentication state - fetched here, while the session is still fully
  // valid, so the POST below carries a genuinely valid token for this exact
  // session even after its securityGeneration is stripped next. Fetching it
  // AFTER stripping would itself be denied by the very fix under test.
  const csrf = await csrfFor('/account/password', legacyCookie);

  // A. Simulate an authenticated session with no captured securityGeneration
  // at all (there is no real such data left after the production/
  // development split - this reproduces what one would look like).
  const sid = sidOf(legacyCookie);
  const sess = JSON.parse(db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(sid).sess);
  delete sess.securityGeneration;
  db.prepare('UPDATE sessions SET sess = ? WHERE sid = ?').run(JSON.stringify(sess), sid);
  assert.equal(await isAuth(legacyCookie), false,
    'ATTACK I.A: an authenticated session with no securityGeneration at all must not receive authenticated access');
  // Restore it for the POST below - isAuth() above ran a real GET / request,
  // which (correctly) already destroyed this session row entirely; this
  // reproduces the same no-generation state again so the exploit's actual
  // entry point (POST /account/password) is what gets exercised next,
  // rather than a row already gone for an unrelated reason.
  db.prepare('INSERT OR IGNORE INTO sessions (sid, sess, expires) VALUES (?, ?, ?)').run(sid, JSON.stringify(sess), Date.now() + 3600000);

  // B/C. That legacy session attempts a self-service password change - its
  // own exploit entry point - concurrently with an unrelated admin reset.
  // Firing the admin reset here matches the reported scenario, though the
  // outcome no longer depends on timing at all: attachUser() now denies a
  // no-securityGeneration session outright, before the request ever reaches
  // setPassword()'s CAS logic, so there is no window left to race.
  const stalePromise = submitPasswordChange(legacyCookie, csrf, 'AttackIOldPassw0rd!2026', 'AttackIStaleSelfPassw0rd!2026', 'AttackIStaleSelfPassw0rd!2026');
  await new Promise((resolve) => setTimeout(resolve, 30));
  await setPassword(row.id, 'AttackIAdminResetPassw0rd!2026', {}); // admin-mediated reset, unconditional, no exceptSid
  const staleRes = await stalePromise;

  assert.equal(staleRes.status, 302,
    'ATTACK I.C: a legacy session\'s self-service password-change attempt must be denied outright (never reaching the credential-update logic at all), not silently committed');
  assert.match(staleRes.headers.get('location') || '', /\/login/, 'the denial must redirect to sign in again');

  const loginWithAdminPassword = await login('attack.i@fixture.invalid', 'AttackIAdminResetPassw0rd!2026');
  assert.equal(loginWithAdminPassword.status, 302, 'the admin\'s reset password must remain authoritative');
  const loginWithStalePassword = await login('attack.i@fixture.invalid', 'AttackIStaleSelfPassw0rd!2026');
  assert.equal(loginWithStalePassword.status, 401, 'the stale self-service password from a legacy session must never have taken effect at all');

  // D. The deleted/legacy session must not regain authenticated access, even
  // though this denied request's own end-of-response save is exactly the
  // kind of upsert that used to be able to resurrect a deleted session row.
  assert.equal(await isAuth(legacyCookie), false,
    'ATTACK I.D: the acting legacy session must not regain authenticated access after the denial, even if its row was resurrected by this request\'s own save');

  // E. A fresh login afterward succeeds normally and captures the CURRENT generation.
  const freshLoginPost = await login('attack.i@fixture.invalid', 'AttackIAdminResetPassw0rd!2026');
  assert.equal(freshLoginPost.status, 302, 'ATTACK I.E: a fresh login after all this must succeed normally');
  const freshCookie = await cookieOf(freshLoginPost);
  assert.equal(await isAuth(freshCookie), true, 'ATTACK I.E: the fresh session must be authenticated');
  const freshSid = sidOf(freshCookie);
  const freshSess = JSON.parse(db.prepare('SELECT sess FROM sessions WHERE sid = ?').get(freshSid).sess);
  assert.equal(freshSess.securityGeneration, generationOf(row.id),
    'ATTACK I.E: the fresh login must capture the user\'s current securityGeneration');
  console.log('PASS (Attack I): a legacy session with no securityGeneration cannot authenticate, its stale self-service change is rejected without ever regaining access, and a fresh login afterward works normally under the current generation');
}

// --- F. Normal login and logout continue to work unaffected by this pass. ---
{
  await createUser({ email: 'attack.f@fixture.invalid', password: 'AttackFPassw0rd!2026', displayName: 'Attack F', roleKeys: ['super_admin'], mustChangePassword: false });
  const loginPost = await login('attack.f@fixture.invalid', 'AttackFPassw0rd!2026');
  assert.equal(loginPost.status, 302, 'a normal login must still succeed');
  const cookie = await cookieOf(loginPost);
  assert.equal(await isAuth(cookie), true, 'a normal freshly-logged-in session must be authenticated');

  const logoutCsrf = await csrfFor('/', cookie);
  const logoutRes = await fetch(`${base}/logout`, {
    method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: cookie },
    body: new URLSearchParams({ _csrf: logoutCsrf })
  });
  assert.equal(logoutRes.status, 302, 'logout must still succeed normally');
  assert.equal(await isAuth(cookie), false, 'a session must be invalid immediately after logout');
  console.log('PASS (Attack F): normal login/logout continue to work unaffected by this pass');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
