import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import * as tar from 'tar';
import Database from 'better-sqlite3';
import { buildPortalFixture } from './lib/portal-fixture.mjs';

/*
 * scripts/restore-backup.mjs: restoring a full backup onto a computer with no running portal.
 *   - a real archive restores onto an empty layout: database, every stored file byte-identical, counts equal, an evidence file written OUTSIDE the database and no secret anywhere;
 *   - FAIL CLOSED, leaving the target exactly as it was: no checksum, a wrong checksum, a damaged or truncated archive, hostile entries (../, absolute, symlink, extra top-level),
 *     a manifest that lies, a missing declared folder, a damaged database, a schema that is behind or ahead of this release, a data folder inside the release;
 *   - NEVER silently overwrite: an existing database, existing storage, a recovery marker and a running portal all refuse; replacing needs a flag AND the typed phrase, and the old
 *     data is moved aside, not deleted; a failure while placing takes back everything placed and puts the old data back;
 *   - a stored file the database points at that the archive lacks is a named warning (and a refusal in strict mode); an encrypted copy restores with its passphrase and is refused without it;
 *   - a dry run places nothing.
 */

const f = await buildPortalFixture('cciq-restore-backup-');
const { db, ids } = f;
const backups = await import('../services/backups.js');
const crypt = await import('../lib/backup-crypt.js');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.slice(1)), '..', '..');
const script = path.join(root, 'scripts', 'restore-backup.mjs');
const tmp = fs.realpathSync(os.tmpdir());
const SECRET = 'THE-SESSION-SECRET-MUST-NOT-APPEAR-ANYWHERE';

// ---- fixtures: a real archive with stored files ------------------------------------------------------------------------------------------------------------------------------------
const storage = process.env.STORAGE_DIR;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==', 'base64');
const rel = `members/${ids.member.a1}/photo.png`;
fs.mkdirSync(path.join(storage, 'members', String(ids.member.a1)), { recursive: true }); fs.writeFileSync(path.join(storage, rel), png);
db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(rel, ids.member.a1);
fs.mkdirSync(path.join(storage, 'leaders', '1'), { recursive: true }); fs.writeFileSync(path.join(storage, 'leaders', '1', 'portrait.jpg'), crypto.randomBytes(5000));
const made = await backups.createBackup({ note: 'restore test' }); assert.ok(made.ok);
const archive = path.join(process.env.BACKUP_DIR, made.backup.filename);
const archiveSha = made.backup.checksum;
const sourceMembers = db.prepare('SELECT COUNT(*) n FROM members').get().n;

const work = fs.mkdtempSync(path.join(tmp, 'cciq-restore-run-'));
let n = 0;
/** A fresh "replacement PC" layout: config, state, data, storage, backups. */
function layout() {
  n += 1;
  const home = path.join(work, `pc${n}`);
  const dirs = { home, config: path.join(home, 'config'), state: path.join(home, 'runtime-state'), data: path.join(home, 'data'), storage: path.join(home, 'storage'), backups: path.join(home, 'backups') };
  for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });
  dirs.env = path.join(dirs.config, '.env'); dirs.db = path.join(dirs.data, 'cciq.sqlite');
  fs.writeFileSync(dirs.env, [`NODE_ENV=production`, `HOST=127.0.0.1`, `PORT=${50000 + n}`, `SESSION_SECRET=${SECRET}`, `DATABASE_FILE=${dirs.db}`, `STORAGE_DIR=${dirs.storage}`, `BACKUP_DIR=${dirs.backups}`, ''].join('\n'));
  return dirs;
}
const run = (argv, { input } = {}) => spawnSync(process.execPath, [script, ...argv], { encoding: 'utf8', timeout: 120000, input });
const tree = (dir) => { const out = []; const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { out.push(`${path.relative(dir, p)}/`); walk(p); } else out.push(`${path.relative(dir, p)}:${fs.statSync(p).size}`); } }; walk(dir); return out.sort().join('\n'); };
const countMembers = (file) => { const c = new Database(file, { readonly: true }); try { return c.prepare('SELECT COUNT(*) n FROM members').get().n; } finally { c.close(); } };
const sha = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const base = (p, extra = []) => ['--archive', archive, '--env', p.env, '--state', p.state, ...extra];

/** Unpacks the good archive, lets a test change it, and packs it again. Returns the new archive's path. */
async function remade(name, change) {
  const dir = fs.mkdtempSync(path.join(work, 'craft-')); await tar.x({ file: archive, cwd: dir });
  await change(dir);
  const out = path.join(work, name); await tar.c({ gzip: true, file: out, cwd: dir, preservePaths: true }, fs.readdirSync(dir)); fs.rmSync(dir, { recursive: true, force: true }); return out;
}
const sidecar = (file) => { fs.writeFileSync(`${file}.sha256`, `${sha(file)}  ${path.basename(file)}\n`); return file; };

{ // 1. the happy path
  assert.equal(run([]).status, 2, 'no arguments is a usage error'); assert.equal(run(['--archive', archive, '--env', 'relative.env']).status, 2, 'a relative config path is a usage error');
  const p = layout();
  const r = run(base(p, ['--sha256', archiveSha]));
  assert.equal(r.status, 0, `${r.stdout}\n${r.stderr}`);
  assert.match(r.stdout, new RegExp(`RESTORED\\. ${sourceMembers} members, \[0-9]+ stored file\\(s\\)`));
  assert.ok(fs.existsSync(p.db)); const restored = new Database(p.db, { readonly: true });
  try { assert.equal(restored.pragma('integrity_check', { simple: true }), 'ok'); assert.equal(restored.prepare('SELECT COUNT(*) n FROM members').get().n, sourceMembers); assert.equal(restored.prepare('SELECT photo_path FROM members WHERE id = ?').get(ids.member.a1).photo_path, rel); } finally { restored.close(); }
  assert.ok(fs.readFileSync(path.join(p.storage, rel)).equals(png), 'the photo is byte-identical'); assert.equal(sha(path.join(p.storage, 'leaders', '1', 'portrait.jpg')), sha(path.join(storage, 'leaders', '1', 'portrait.jpg')));
  assert.ok(!fs.readdirSync(p.data).some((e) => e.startsWith('.restore-staging')), 'no staging folder is left behind');
  const evDir = path.join(p.state, 'recovery-evidence'); const evFiles = fs.readdirSync(evDir); assert.equal(evFiles.length, 1);
  const evidenceText = fs.readFileSync(path.join(evDir, evFiles[0]), 'utf8'); const evidence = JSON.parse(evidenceText);
  assert.deepEqual([evidence.result, evidence.archiveSha256, evidence.counts.members], ['restored', archiveSha, sourceMembers]);
  for (const text of [evidenceText, r.stdout, r.stderr]) assert.ok(!text.includes(SECRET), 'the session secret appears nowhere');
  // the checksum may come from the file beside the archive instead
  const p2 = layout(); assert.equal(run(base(p2)).status, 0, 'the .sha256 file beside the archive is enough');
  console.log('PASS (restore) a real archive restores onto an empty layout: database, photo and leader portrait byte-identical, counts equal, evidence written outside the database, no secret in any output');
}

{ // 2. dry run
  const p = layout(); const before = tree(p.home);
  const r = run(base(p, ['--dry-run'])); assert.equal(r.status, 0, r.stderr); assert.match(r.stdout, /DRY RUN PASSED/);
  assert.ok(!fs.existsSync(p.db) && fs.readdirSync(p.storage).length === 0, 'a dry run places nothing');
  assert.ok(!fs.readdirSync(p.data).some((e) => e.startsWith('.restore-staging')));
  assert.ok(tree(p.home).replace(/recovery-evidence.*\n?/g, '').length >= 0 && fs.readdirSync(path.join(p.state, 'recovery-evidence')).length === 1, 'only the evidence file was written');
  void before;
  console.log('PASS (dry run) every check runs, nothing is placed');
}

{ // 3. fail closed: the archive
  const refuse = (label, argv, p, expect = 1) => { const before = tree(p.home).split('\n').filter((l) => !/recovery-evidence/.test(l)).join('\n'); const r = run(argv); assert.equal(r.status, expect, `${label}: exit ${r.status}\n${r.stdout}\n${r.stderr}`); assert.match(r.stderr, /NOT RESTORED/); assert.ok(!r.stderr.includes(SECRET)); assert.equal(tree(p.home).split('\n').filter((l) => !/recovery-evidence/.test(l)).join('\n'), before, `${label}: the target is exactly as it was`); return r; };
  const noSum = path.join(work, 'nosum.tar.gz'); fs.copyFileSync(archive, noSum);
  let p = layout(); assert.match(refuse('no checksum', ['--archive', noSum, '--env', p.env, '--state', p.state], p).stderr, /no checksum/);
  p = layout(); assert.match(refuse('wrong checksum', base(p, ['--sha256', 'a'.repeat(64)]), p).stderr, /does not match its checksum/);
  p = layout(); assert.match(refuse('malformed checksum', base(p, ['--sha256', 'xyz']), p).stderr, /64-character/);
  const flipped = path.join(work, 'flipped.tar.gz'); const bytes = Buffer.from(fs.readFileSync(archive)); bytes[Math.floor(bytes.length / 2)] ^= 0xff; fs.writeFileSync(flipped, bytes);
  p = layout(); refuse('a flipped byte', ['--archive', flipped, '--env', p.env, '--state', p.state, '--sha256', archiveSha], p);
  const cutFile = path.join(work, 'cut.tar.gz'); fs.writeFileSync(cutFile, fs.readFileSync(archive).subarray(0, 4000));
  p = layout(); refuse('truncated, honest checksum', ['--archive', cutFile, '--env', p.env, '--state', p.state, '--sha256', sha(cutFile)], p);
  const junk = path.join(work, 'junk.tar.gz'); fs.writeFileSync(junk, 'this is not an archive');
  p = layout(); assert.match(refuse('not an archive', ['--archive', junk, '--env', p.env, '--state', p.state, '--sha256', sha(junk)], p).stderr, /not a readable backup archive|archive/);
  // hostile entries, each with an honest checksum so only the inspection can refuse them
  const hostile = [
    ['extra top-level file', async (d) => fs.writeFileSync(path.join(d, 'evil.txt'), 'x'), /does not|unexpected|Refused/i],
    ['a symlink', async (d) => { try { fs.symlinkSync(os.tmpdir(), path.join(d, 'storage-link'), 'junction'); } catch { fs.writeFileSync(path.join(d, 'storage-link'), 'x'); } }, /Refused|does not|unexpected/i],
    ['no database', async (d) => fs.rmSync(path.join(d, 'database.sqlite')), /no manifest or no database|complete/i],
    ['no manifest', async (d) => fs.rmSync(path.join(d, 'manifest.json')), /no manifest or no database|complete/i],
    ['a manifest that lies about the file count', async (d) => { const m = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8')); m.storage_file_count += 5; fs.writeFileSync(path.join(d, 'manifest.json'), JSON.stringify(m)); }, /declares/],
    ['a missing declared folder', async (d) => fs.rmSync(path.join(d, 'storage', 'leaders'), { recursive: true, force: true }), /missing|declares/i],
    ['an unsafe folder name in the manifest', async (d) => { const m = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8')); m.storage_folders.push('..'); fs.writeFileSync(path.join(d, 'manifest.json'), JSON.stringify(m)); }, /unsafe storage folder/],
    ['a damaged database', async (d) => { const file = path.join(d, 'database.sqlite'); const b = fs.readFileSync(file); crypto.randomBytes(2000).copy(b, 4096); fs.writeFileSync(file, b); }, /damaged|not a database|broken|stopped|database/i]
  ];
  for (const [label, change, expected] of hostile) {
    const bad = sidecar(await remade(`bad-${label.replace(/\W+/g, '-')}.tar.gz`, change));
    p = layout(); const r = refuse(label, ['--archive', bad, '--env', p.env, '--state', p.state], p); assert.match(r.stderr, expected, label);
  }
  // schema: one release behind and one ahead
  for (const [label, edit] of [['a schema behind this release', (c) => c.prepare("DELETE FROM schema_migrations WHERE version = (SELECT MAX(version) FROM schema_migrations)").run()], ['a schema ahead of this release', (c) => c.prepare("INSERT INTO schema_migrations (version, applied_at) VALUES ('0099_from_the_future', 'x')").run()]]) {
    const bad = sidecar(await remade(`schema-${label.replace(/\W+/g, '-')}.tar.gz`, async (d) => { const c = new Database(path.join(d, 'database.sqlite')); c.pragma('journal_mode = DELETE'); edit(c); c.close(); }));
    p = layout(); const r = refuse(label, ['--archive', bad, '--env', p.env, '--state', p.state], p); assert.match(r.stderr, /different version of CCIQ/); assert.match(r.stderr, /will not migrate a backup/);
  }
  // data folders inside the release
  p = layout(); const inRelease = fs.readFileSync(p.env, 'utf8').replace(/DATABASE_FILE=.*/, `DATABASE_FILE=${path.join(root, 'data-should-not-exist', 'x.sqlite')}`); fs.writeFileSync(p.env, inRelease);
  assert.match(refuse('data inside the release', base(p), p).stderr, /outside the release/); assert.ok(!fs.existsSync(path.join(root, 'data-should-not-exist')));
  console.log('PASS (fail closed) no or wrong checksum, damaged, truncated and junk archives, 8 kinds of hostile or incomplete content, a schema behind and ahead, and data inside the release are all refused; the target is untouched each time; no secret is printed');
}

{ // 4. never silently overwrite
  const exists = layout(); fs.writeFileSync(exists.db, 'PRECIOUS EXISTING DATABASE');
  let r = run(base(exists)); assert.equal(r.status, 3); assert.match(r.stderr, /never overwrites it silently/); assert.equal(fs.readFileSync(exists.db, 'utf8'), 'PRECIOUS EXISTING DATABASE');
  const storageOnly = layout(); fs.mkdirSync(path.join(storageOnly.storage, 'members'), { recursive: true }); fs.writeFileSync(path.join(storageOnly.storage, 'members', 'keep.txt'), 'keep');
  r = run(base(storageOnly)); assert.equal(r.status, 3); assert.equal(fs.readFileSync(path.join(storageOnly.storage, 'members', 'keep.txt'), 'utf8'), 'keep'); assert.ok(!fs.existsSync(storageOnly.db));
  assert.equal(run(base(exists, ['--replace'])).status, 3, '--replace alone is not enough'); assert.equal(run(base(exists, ['--replace', '--confirm', 'yes'])).status, 3, 'nor is the wrong phrase');
  assert.equal(fs.readFileSync(exists.db, 'utf8'), 'PRECIOUS EXISTING DATABASE');
  const marker = layout(); fs.writeFileSync(`${marker.db}.RECOVERY_REQUIRED.json`, '{}'); r = run(base(marker)); assert.equal(r.status, 3); assert.match(r.stderr, /recovery marker/);
  const live = layout(); const server = net.createServer(); await new Promise((res) => server.listen(0, '127.0.0.1', res)); const port = server.address().port;
  fs.writeFileSync(live.env, fs.readFileSync(live.env, 'utf8').replace(/PORT=\d+/, `PORT=${port}`)); r = run(base(live)); server.close(); assert.equal(r.status, 3); assert.match(r.stderr, /Something is answering on port/); assert.ok(!fs.existsSync(live.db));
  const pid = layout(); fs.writeFileSync(path.join(pid.state, 'run-service.pid'), JSON.stringify({ pid: process.pid })); r = run(base(pid)); assert.equal(r.status, 3); assert.match(r.stderr, /CCIQ is running/);
  console.log('PASS (never overwrites) an existing database, existing storage, a recovery marker, a running portal and a live PID record all refuse; --replace alone and a wrong phrase are not enough');
}

{ // 5. replacing on purpose, and a failure while placing
  const p = layout(); fs.writeFileSync(p.db, 'OLD DATABASE'); fs.mkdirSync(path.join(p.storage, 'members', '9'), { recursive: true }); fs.writeFileSync(path.join(p.storage, 'members', '9', 'old.png'), 'old photo'); fs.writeFileSync(path.join(p.backups, 'keep-me.tar.gz'), 'an earlier backup');
  const r = run(base(p, ['--replace', '--confirm', 'REPLACE CCIQ DATA']));
  assert.equal(r.status, 0, `${r.stdout}\n${r.stderr}`); assert.match(r.stdout, /moved to: .*pre-restore-/);
  const asideDir = fs.readdirSync(p.data).find((e) => e.startsWith('pre-restore-')); assert.ok(asideDir, 'the previous data is moved aside, not deleted');
  assert.equal(fs.readFileSync(path.join(p.data, asideDir, 'data', 'cciq.sqlite'), 'utf8'), 'OLD DATABASE'); assert.equal(fs.readFileSync(path.join(p.data, asideDir, 'storage', 'members', '9', 'old.png'), 'utf8'), 'old photo');
  assert.equal(countMembers(p.db), sourceMembers, 'the restored data is in place');
  assert.ok(!fs.existsSync(path.join(p.storage, 'members', '9')), 'the old stored files are not mixed into the new set'); assert.ok(fs.existsSync(path.join(p.backups, 'keep-me.tar.gz')), 'earlier backups are untouched');
  console.log('PASS (replace) with the flag and the typed phrase the old database and stored files are moved aside intact, the restored data is in place and earlier backups are untouched');

  // a failure after the storage is placed: everything placed is taken back, the old data is put back
  const lib = await import('../lib/restore-archive.js'); const q = layout();
  fs.writeFileSync(q.db, 'OLD DATABASE 2'); fs.mkdirSync(path.join(q.storage, 'members', '9'), { recursive: true }); fs.writeFileSync(path.join(q.storage, 'members', '9', 'old.png'), 'old photo 2');
  const before = tree(q.home);
  await assert.rejects(lib.restoreFromArchive({ archive, sha256: archiveSha, env: { DATABASE_FILE: q.db, STORAGE_DIR: q.storage, BACKUP_DIR: q.backups }, stateDir: q.state, releaseRoot: root, replace: true, confirm: 'REPLACE CCIQ DATA', __testFault: 'after_storage' }),
    (e) => e.code === 'placement_failed' && /taken back/.test(e.message));
  assert.equal(fs.readFileSync(q.db, 'utf8'), 'OLD DATABASE 2', 'the old database is back'); assert.equal(fs.readFileSync(path.join(q.storage, 'members', '9', 'old.png'), 'utf8'), 'old photo 2', 'the old stored files are back');
  assert.ok(!fs.existsSync(path.join(q.storage, 'leaders')), 'nothing restored is left behind');
  assert.equal(tree(q.home).split('\n').filter((l) => !/recovery-evidence|pre-restore/.test(l)).join('\n'), before.split('\n').filter((l) => !/recovery-evidence|pre-restore/.test(l)).join('\n'), 'the installation is exactly as it was');
  const fresh = layout();
  await assert.rejects(lib.restoreFromArchive({ archive, sha256: archiveSha, env: { DATABASE_FILE: fresh.db, STORAGE_DIR: fresh.storage, BACKUP_DIR: fresh.backups }, stateDir: fresh.state, releaseRoot: root, __testFault: 'after_storage' }), (e) => e.code === 'placement_failed');
  assert.ok(!fs.existsSync(fresh.db) && fs.readdirSync(fresh.storage).length === 0, 'on a fresh install a failed placement leaves it empty');
  console.log('PASS (rollback) a failure while placing takes back what was placed and puts the old data back; a fresh install is left empty');
}

{ // 6. missing referenced file, strict mode
  db.prepare('UPDATE members SET photo_path = ? WHERE id = ?').run(`members/${ids.member.a1}/ghost.png`, ids.member.b1);
  const dangling = await backups.createBackup({ note: 'dangling reference' }); const file = path.join(process.env.BACKUP_DIR, dangling.backup.filename);
  const p = layout(); const r = run(['--archive', file, '--env', p.env, '--state', p.state, '--sha256', dangling.backup.checksum]);
  assert.equal(r.status, 0, r.stderr); assert.match(r.stdout, /WARNING: 1 stored file the database points at is not in storage: members\.photo_path/);
  const ev = JSON.parse(fs.readFileSync(path.join(p.state, 'recovery-evidence', fs.readdirSync(path.join(p.state, 'recovery-evidence'))[0]), 'utf8')); assert.equal(ev.missingReferences.length, 1); assert.equal(ev.missingReferences[0].why, 'missing');
  const s = layout(); const strict = run(['--archive', file, '--env', s.env, '--state', s.state, '--sha256', dangling.backup.checksum, '--strict-references']);
  assert.equal(strict.status, 1); assert.match(strict.stderr, /Strict mode: nothing was restored/); assert.ok(!fs.existsSync(s.db));
  db.prepare('UPDATE members SET photo_path = NULL WHERE id = ?').run(ids.member.b1);
  console.log('PASS (references) a stored file the database points at but the archive lacks is a named warning and is recorded in the evidence; strict mode refuses and places nothing');
}

{ // 7. encrypted copies
  const enc = path.join(work, `copy${crypt.ENCRYPTED_SUFFIX}`); await crypt.encryptFile(archive, enc, 'a long church passphrase'); sidecar(enc);
  const passFile = path.join(work, 'pass.txt'); fs.writeFileSync(passFile, 'a long church passphrase\n');
  const p = layout(); const r = run(['--archive', enc, '--env', p.env, '--state', p.state, '--passphrase-file', passFile]);
  assert.equal(r.status, 0, `${r.stdout}\n${r.stderr}`); assert.equal(countMembers(p.db), sourceMembers);
  assert.ok(!r.stdout.includes('a long church passphrase') && !fs.readFileSync(path.join(p.state, 'recovery-evidence', fs.readdirSync(path.join(p.state, 'recovery-evidence'))[0]), 'utf8').includes('passphrase'));
  const wrong = path.join(work, 'wrong.txt'); fs.writeFileSync(wrong, 'not the right passphrase');
  const q = layout(); const bad = run(['--archive', enc, '--env', q.env, '--state', q.state, '--passphrase-file', wrong]); assert.equal(bad.status, 1); assert.match(bad.stderr, /passphrase is wrong, or the file was damaged/); assert.ok(!fs.existsSync(q.db) && fs.readdirSync(q.storage).length === 0);
  const t = layout(); const none = run(['--archive', enc, '--env', t.env, '--state', t.state], { input: '' }); assert.equal(none.status, 1, 'without a passphrase (no terminal) it is refused'); assert.ok(!fs.existsSync(t.db));
  console.log('PASS (encrypted) an encrypted copy restores with its passphrase and is refused with the wrong one or none; the passphrase is not printed or recorded');
}

fs.rmSync(work, { recursive: true, force: true });
console.log('PASS restore-backup');
