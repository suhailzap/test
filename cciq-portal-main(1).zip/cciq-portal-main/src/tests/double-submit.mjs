import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Double clicks, retried requests and two tabs: the same form posted several times at once. For each workflow the outcome is one of
 *   - creates exactly one record (an accidental duplicate is refused or replayed);
 *   - safely repeats (the second submission changes nothing more than the first already did);
 *   - is protected by the database (a unique constraint turns the second into a clean refusal).
 * The suite does not invent a dedupe policy: a repeated *intentional* act (a second, different payment) is left alone.
 */

const f = await buildPortalFixture('cciq-double-submit-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const count = (table, where = '1=1') => db.prepare(`SELECT COUNT(*) n FROM ${table} WHERE ${where}`).get().n;
const today = mods.dates.today();
try {
  const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const superAdmin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const memberA = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const tokens = new Map();
  const burstAs = async (who, url, fields, n = 4) => {
    if (!tokens.has(who)) tokens.set(who, await who.csrf('/'));
    return Promise.all(Array.from({ length: n }, () => who.post(url, fields, { csrf: tokens.get(who) }).then(async (r) => { await r.arrayBuffer(); return r.status; })));
  };
  const burst = (url, fields, n = 4) => burstAs(admin, url, fields, n);
  const results = {};

  // ---- creates -------------------------------------------------------------------------------------------------------------
  let before = count('announcements');
  results.announcement = await burst('/announcements', { title: 'Burst notice', body: 'Once only', audience: 'all', priority: 'normal', status: 'published' });
  results['announcement rows'] = count('announcements') - before;

  before = count('activities');
  results.activity = await burst('/activities', { title: 'Burst activity', scope: 'church', status: 'draft' });
  results['activity rows'] = count('activities') - before;

  before = count('family_groups');
  results.family = await burst('/family-groups', { name: 'Burst Family', first_member_id: String(ids.member.free) });
  results['family rows'] = count('family_groups') - before;
  assert.equal(count('family_group_members', `member_id = ${ids.member.free}`), 1, 'a member is never in two families, however many times the form is posted');

  before = count('ministries');
  results.ministry = await burst('/ministries', { name: 'Burst Ministry' });
  results['ministry rows'] = count('ministries') - before;

  before = count('cell_groups');
  results.cellGroup = await burst('/cell-groups', { name: 'Burst Cell Group', status: 'active' });
  results['cell group rows'] = count('cell_groups') - before;

  before = count('visitors');
  results.visitor = await burst('/visitors', { first_name: 'Burst', last_name: 'Visitor', first_visit_date: today });
  results['visitor rows'] = count('visitors') - before;

  before = count('members');
  results.member = await burst('/members', { first_name: 'Burst', last_name: 'Newmember', status: 'pending' });
  results['member rows'] = count('members') - before;

  before = count('users');
  results.user = await burstAs(superAdmin, '/admin/users', { username: 'burst_user', email: 'burst@fixture.invalid', display_name: 'Burst User', roles: 'member' }, 3);
  results['user rows'] = count('users') - before;

  // ---- acts that must repeat safely ------------------------------------------------------------------------------------------------
  const visitor = mods.visitors.createVisitor({ first_name: 'Repeat', last_name: 'Guest', first_visit_date: mods.dates.addDays(today, -20) });
  await burst(`/visitors/${visitor.id}/visits`, { visit_date: today });
  results['visit rows (same date)'] = count('visitor_visits', `visitor_id = ${visitor.id}`) - 1;
  await burst(`/visitors/${visitor.id}/convert`, { first_name: 'Repeat', last_name: 'Guest', date_joined: today });
  results['conversions -> members'] = count('members', "first_name = 'Repeat'");
  await burst(`/family-groups/${ids.family}/members`, { member_id: String(ids.member.a3) });
  results['family membership rows'] = count('family_group_members', `member_id = ${ids.member.a3}`);
  await burst(`/ministries/${ids.ministry}/members`, { member_id: String(ids.member.a3), role: 'member' });
  results['ministry membership rows'] = count('ministry_members', `ministry_id = ${ids.ministry} AND member_id = ${ids.member.a3} AND left_at IS NULL`);
  await burst(`/cell-groups/${ids.groupA}/members`, { member_id: String(ids.member.free) });
  results['cell group membership rows'] = count('cell_group_members', `cell_group_id = ${ids.groupA} AND member_id = ${ids.member.free} AND left_at IS NULL`);
  await burst(`/attendance/sessions/${ids.session}/records`, { [`status_${ids.member.a2}`]: 'present' });
  results['attendance rows'] = count('attendance_records', `session_id = ${ids.session} AND member_id = ${ids.member.a2}`);
  await burstAs(memberA, `/projects/ecaq/board/claim`, { date: mods.ecaq.boardDates(Number(today.slice(0, 4)))[1], campaign: String(ids.board) });
  results['giving board claims for that date'] = count('ecaq_giving_board_claims', `campaign_id = ${ids.board} AND claim_date = '${mods.ecaq.boardDates(Number(today.slice(0, 4)))[1]}'`);
  const reminder = ids.reminder;
  await burst(`/reminders/${reminder}/state`, { state: 'acknowledged', current_state: 'open' });
  results['reminder final state'] = db.prepare('SELECT state FROM reminders WHERE id = ?').get(reminder).state;

  // a *different* announcement right after is a new act and must not be swallowed by the guard
  before = count('announcements');
  await burst('/announcements', { title: 'Second notice', body: 'Different', audience: 'all', priority: 'normal', status: 'published' }, 1);
  assert.equal(count('announcements') - before, 1, 'a different form right after is saved normally');

  console.log('INFO burst results (status codes, then rows created):\n  ' + Object.entries(results).map(([k, v]) => `${k}: ${JSON.stringify(v)}`).join('\n  '));

  // ---- what must hold ---------------------------------------------------------------------------------------------------------------
  assert.ok(results['visit rows (same date)'] <= 1 && results['visit rows (same date)'] >= 0, 'the same First Timer visit date is stored once');
  assert.equal(results['visit rows (same date)'], 1, 'and exactly once');
  assert.equal(results['conversions -> members'], 1, 'a burst of conversions makes exactly one member');
  assert.equal(results['family membership rows'], 1);
  assert.equal(results['ministry membership rows'], 1);
  assert.equal(results['cell group membership rows'], 1);
  assert.equal(results['attendance rows'], 1, 'the same attendance mark is one row');
  assert.equal(results['giving board claims for that date'], 1, 'two posts for one Giving Board date make exactly one claim');
  assert.equal(results['reminder final state'], 'acknowledged');
  assert.ok(results['member rows'] <= 1, `a burst of the same member form creates at most one member (${results['member rows']})`);
  assert.ok(results['visitor rows'] <= 1, `a burst of the same First Timer form creates at most one (${results['visitor rows']})`);
  assert.ok(results['user rows'] <= 1, `a burst of the same user form creates at most one account (${results['user rows']})`);
  assert.ok(results['family rows'] <= 1, `a burst of the same family form creates at most one group (${results['family rows']})`);
  assert.ok(results['announcement rows'] <= 1, `a burst of the same announcement form creates at most one (${results['announcement rows']})`);
  assert.ok(results['activity rows'] <= 1, `a burst of the same activity form creates at most one (${results['activity rows']})`);
  assert.ok(results['ministry rows'] <= 1, `a burst of the same ministry form creates at most one (${results['ministry rows']})`);
  assert.ok(results['cell group rows'] <= 1, `a burst of the same cell group form creates at most one (${results['cell group rows']})`);
  console.log('PASS (double submit) every create workflow makes at most one record from a burst of identical posts; every repeatable act repeats safely');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
