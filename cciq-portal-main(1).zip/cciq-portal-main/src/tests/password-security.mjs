import assert from 'node:assert/strict';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createIsolatedTestEnv, terminateAndWait, waitForServerReady } from './lib/test-env.mjs';

/*
 * Go-live readiness: two red-team findings closed together, since both are
 * about what a password controls.
 *
 * R02 — every newly provisioned account shared one fixed literal password
 * (CCIQTemp2026@). Combined with a predictable username pattern
 * (suggestMemberUsername), anyone who knew a member's name could sign in as
 * them before they ever had and complete the forced first-login change
 * themselves, locking the real member out. generateInitialPassword() now
 * produces a fresh random value per account.
 *
 * R03 — changing or resetting a password never touched the sessions table,
 * so a device already signed in under the old password kept working
 * indefinitely. setPassword() now calls destroySessionsForUser(), except
 * (for a self-service change only) the session that just proved the
 * current password, so the person changing their own password isn't
 * immediately signed out of the device they're using to do it.
 */

const root = fileURLToPath(new URL('../../', import.meta.url));
const env = createIsolatedTestEnv('cciq-password-security-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const users = await import('../services/users.js');
const { checkPasswordPolicy } = await import('../lib/passwords.js');
const { createMember } = await import('../services/members.js');
const { default: db } = await import('../db/index.js');

// --- R02: generated passwords are random, unique, policy-valid, and hashed. ---
{
  const pw1 = users.generateInitialPassword();
  const pw2 = users.generateInitialPassword();
  assert.notEqual(pw1, pw2, 'two generated initial passwords must not be the same value');
  assert.notEqual(pw1, 'CCIQTemp2026@', 'must not be the old fixed literal');
  assert.equal(checkPasswordPolicy(pw1).length, 0, 'a generated password must satisfy the site password policy');
  console.log('PASS: generateInitialPassword() produces a fresh, policy-valid, unique value each call');
}

{
  const memberA = createMember({ first_name: 'Alpha', last_name: 'Fixture' }, { status: 'active' });
  const memberB = createMember({ first_name: 'Beta', last_name: 'Fixture' }, { status: 'active' });
  const accountA = await users.provisionMemberAccount(memberA, {});
  const accountB = await users.provisionMemberAccount(memberB, {});
  assert.ok(accountA.created && accountB.created);
  // With no configured onboarding override, ordinary accounts get distinct random one-time values.
  assert.notEqual(accountA.password, accountB.password, 'ordinary accounts receive unique one-time passwords');
  assert.notEqual(users.initialPasswordFor(['church_admin']), users.initialPasswordFor(['church_admin']), 'administrator accounts still get random, unique starting passwords');
  assert.notEqual(accountA.password, 'CCIQTemp2026@');

  const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(accountA.user.id);
  assert.notEqual(row.password_hash, accountA.password, 'the stored value must be a hash, never the plaintext password');
  assert.ok(row.password_hash.startsWith('scrypt$'), 'the stored value must be in the expected hashed format');
  assert.equal(accountA.user.must_change_password, 1, 'must_change_password must still be enforced on a provisioned account');
  console.log('PASS: provisioned ordinary accounts get unique random one-time passwords (hashed) and must change them; administrators still get unique random ones');
}

// --- R03: session revocation, via a real spawned server (needs real cookies/HTTP). ---
function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, () => { const p = srv.address().port; srv.close(() => resolve(p)); });
  });
}
const port = await findFreePort();
process.env.PORT = String(port);
const base = `http://127.0.0.1:${port}`;

const server = spawn('node', [path.join(root, 'src/server.js')], { env: process.env });
await waitForServerReady(base, server);

const { createUser } = await import('../services/users.js');

async function loginAndGetCookie(email, password) {
  const loginPage = await fetch(`${base}/login`);
  const csrfMatch = (await loginPage.text()).match(/name="_csrf" value="([^"]+)"/);
  const cookieJar = (loginPage.headers.getSetCookie ? loginPage.headers.getSetCookie() : [loginPage.headers.get('set-cookie')]);
  const preLoginCookie = cookieJar.map((c) => c.split(';')[0]).join('; ');

  const loginPost = await fetch(`${base}/login`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: preLoginCookie },
    body: new URLSearchParams({ email, password, _csrf: csrfMatch[1] })
  });
  const sessionCookie = (loginPost.headers.getSetCookie ? loginPost.headers.getSetCookie() : [loginPost.headers.get('set-cookie')])
    .map((c) => c.split(';')[0]).join('; ') || preLoginCookie;
  assert.equal(loginPost.status, 302, `login must succeed for ${email}`);
  return sessionCookie;
}

async function isAuthenticated(cookie) {
  const res = await fetch(`${base}/`, { headers: { Cookie: cookie }, redirect: 'manual' });
  // An authenticated session reaches the dashboard (200); a dead one is
  // bounced to /login (302 with a Location header pointing there).
  if (res.status === 200) return true;
  if (res.status === 302 && (res.headers.get('location') || '').includes('/login')) return false;
  throw new Error(`unexpected status checking session liveness: ${res.status}`);
}

async function getCsrfFor(path, cookie) {
  const page = await fetch(`${base}${path}`, { headers: { Cookie: cookie } });
  return (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
}

// --- Self-service change: the changing device's own session survives; a second device's does not. ---
{
  const email = 'r03.selfservice@fixture.invalid';
  await createUser({ email, password: 'OldPassw0rd!2026', displayName: 'R03 Self Service', roleKeys: ['super_admin'], mustChangePassword: false });

  const deviceA = await loginAndGetCookie(email, 'OldPassw0rd!2026');
  const deviceB = await loginAndGetCookie(email, 'OldPassw0rd!2026');
  assert.ok(await isAuthenticated(deviceA), 'device A should start authenticated');
  assert.ok(await isAuthenticated(deviceB), 'device B should start authenticated');

  const csrf = await getCsrfFor('/account/password', deviceA);
  const changeRes = await fetch(`${base}/account/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: deviceA },
    body: new URLSearchParams({
      current_password: 'OldPassw0rd!2026',
      password: 'NewPassw0rd!2026',
      confirm_password: 'NewPassw0rd!2026',
      _csrf: csrf
    })
  });
  assert.equal(changeRes.status, 302, 'a valid self-service password change should redirect, not error');

  assert.ok(await isAuthenticated(deviceA), 'R03: the device that performed the change must remain signed in');
  assert.equal(await isAuthenticated(deviceB), false, 'R03 CONFIRMED FIXED: a second device signed in under the old password must be signed out');
  console.log('PASS: self-service password change keeps the changing device signed in and signs out every other device');
}

// --- Admin-mediated reset: the target account's existing session is killed (no session to except). ---
{
  const targetEmail = 'r03.admintarget@fixture.invalid';
  const adminEmail = 'r03.adminactor@fixture.invalid';
  const targetId = await createUser({ email: targetEmail, password: 'TargetPassw0rd!2026', displayName: 'R03 Target', roleKeys: ['member'], mustChangePassword: false });
  await createUser({ email: adminEmail, password: 'AdminPassw0rd!2026', displayName: 'R03 Admin', roleKeys: ['super_admin'], mustChangePassword: false });

  const targetDevice = await loginAndGetCookie(targetEmail, 'TargetPassw0rd!2026');
  const adminDevice = await loginAndGetCookie(adminEmail, 'AdminPassw0rd!2026');
  assert.ok(await isAuthenticated(targetDevice));

  const csrf = await getCsrfFor(`/admin/users/${targetId}`, adminDevice);
  const resetRes = await fetch(`${base}/admin/users/${targetId}/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: adminDevice },
    body: new URLSearchParams({ password: 'AdminSetPassw0rd!2026', _csrf: csrf })
  });
  assert.equal(resetRes.status, 302, 'an admin password reset should redirect, not error');

  assert.equal(await isAuthenticated(targetDevice), false, 'R03: an admin-reset account\'s existing session must be signed out');
  assert.ok(await isAuthenticated(adminDevice), 'the admin\'s own session must be unaffected by resetting someone else\'s password');
  console.log('PASS: an admin-mediated password reset signs out the target account\'s existing session, without affecting the admin\'s own');
}

// --- Kiosk regression check: the same self-except behavior holds for a kiosk-only account. ---
{
  const kioskUsername = 'r03_kiosk_fixture';
  await createUser({ username: kioskUsername, email: 'r03.kiosk@fixture.invalid', password: 'KioskPassw0rd!2026', displayName: 'R03 Kiosk', roleKeys: ['kiosk'], mustChangePassword: false });

  const kioskDeviceA = await loginAndGetCookie(kioskUsername, 'KioskPassw0rd!2026');
  const kioskDeviceB = await loginAndGetCookie(kioskUsername, 'KioskPassw0rd!2026');

  const kioskCheck = async (cookie) => {
    const res = await fetch(`${base}/kiosk`, { headers: { Cookie: cookie }, redirect: 'manual' });
    if (res.status === 200) return true;
    if (res.status === 302 && (res.headers.get('location') || '').includes('/login')) return false;
    throw new Error(`unexpected status checking kiosk session liveness: ${res.status}`);
  };
  assert.ok(await kioskCheck(kioskDeviceA), 'kiosk device A should start authenticated');
  assert.ok(await kioskCheck(kioskDeviceB), 'kiosk device B should start authenticated');

  const csrf = await getCsrfFor('/account/password', kioskDeviceA);
  const changeRes = await fetch(`${base}/account/password`, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: kioskDeviceA },
    body: new URLSearchParams({
      current_password: 'KioskPassw0rd!2026',
      password: 'NewKioskPassw0rd!2026',
      confirm_password: 'NewKioskPassw0rd!2026',
      _csrf: csrf
    })
  });
  assert.equal(changeRes.status, 302);

  assert.ok(await kioskCheck(kioskDeviceA), 'kiosk regression check: the changing kiosk device must remain signed in');
  assert.equal(await kioskCheck(kioskDeviceB), false, 'kiosk regression check: a second kiosk device on the old password must be signed out, same as any other account');
  console.log('PASS: kiosk accounts get the same session-revocation behavior as any other account, with no change to kiosk session policy itself');
}

await terminateAndWait(server);
db.close();
env.cleanup();
console.log('ALL PASS');
