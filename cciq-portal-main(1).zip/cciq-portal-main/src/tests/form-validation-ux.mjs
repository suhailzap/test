import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * Every editable form that re-renders itself with validation errors must say, for EACH failing field, what is wrong and where: a focused
 * summary that links to the field, the message beside the field, aria-invalid and aria-describedby on the control, and no vague
 * "check the highlighted fields". The hostile payload for each form is BUILT FROM ITS OWN VALIDATOR SOURCE, so a validator that is added
 * later is exercised without anyone remembering to add it here: every field the validator mentions is sent in a form that fails it.
 */

const srcDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel) => fs.readFileSync(path.join(srcDir, rel), 'utf8');

/** `v.method('field', {... max: N ...})` calls inside the text between a start marker and the end of its function or handler. */
function validators(rel, marker) {
  const source = read(rel);
  const start = source.indexOf(marker);
  assert.ok(start >= 0, `${rel}: marker ${marker} found`);
  const rest = source.slice(start + marker.length);
  const end = rest.search(/\n}\n|\nrouter\./);
  const block = end >= 0 ? rest.slice(0, end) : rest;
  const found = [];
  for (const m of block.matchAll(/v\.(text|email|date|time|phone|oneOf|integer)\(\s*'(\w+)'([\s\S]*?)\);/g)) {
    const max = /max:\s*(\d+)/.exec(m[3]);
    found.push({ method: m[1], field: m[2], max: max ? Number(max[1]) : 255, required: /required:\s*true/.test(m[3]) });
  }
  return found;
}
const HOSTILE = (f) => {
  switch (f.method) {
    case 'text': return 'x'.repeat(f.max + 1);
    case 'email': return 'not-an-email';
    case 'date': return '2026-13-45';
    case 'time': return '99:99';
    case 'phone': return 'abc';
    case 'oneOf': return 'no-such-choice';
    case 'integer': return '12abc';
    default: return 'x';
  }
};

const f = await buildPortalFixture('cciq-form-validation-');
const { db, ids, users, mods } = f;
const portal = await startPortal();
const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
const memberUser = await signIn(portal.base, users.memberA.email, f.PASSWORD);
let checkedFields = 0; let checkedForms = 0;
const decode = (s) => s.replace(/&#34;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

function assertWellReported(html, label, expectKeys) {
  const issues = [];
  const ok = (cond, message) => { if (!cond) issues.push(message); };
  assert.doesNotMatch(html, /Check the highlighted fields/, `${label}: no vague banner`);
  const summary = /<div class="alert alert--error"[^>]*data-error-summary[\s\S]*?<\/ul>/.exec(html)?.[0];
  assert.ok(summary, `${label}: an error summary is shown`);
  assert.match(html, /<div class="alert alert--error" role="alert" tabindex="-1" data-error-summary/, `${label}: focusable alert`);
  const links = [...summary.matchAll(/<a href="#([^"]*)" data-field="([^"]*)">/g)].map((m) => ({ id: m[1], field: m[2] }));
  assert.ok(links.length > 0, `${label}: the summary lists problems`);
  const shown = new Set(links.map((l) => l.field));
  for (const key of expectKeys) ok(shown.has(key), `the failing field "${key}" is not named in the summary`);
  for (const { id, field } of links) {
    const control = new RegExp(`<(input|select|textarea)\\b[^>]*\\bid="${id}"[^>]*>`).exec(html)?.[0];
    const byName = new RegExp(`<(input|select|textarea)\\b[^>]*\\bname="${field}"[^>]*>`).test(html);
    ok(control || byName, `the summary link for "${field}" reaches no control (#${id} or name=${field})`);
    if (control) {
      ok(/aria-invalid="true"/.test(control), `#${id} (${field}) is not marked aria-invalid`);
      const described = /aria-describedby="([^"]*)"/.exec(control)?.[1] || '';
      const errorId = described.split(/\s+/).find((d) => d.endsWith('-error'));
      ok(errorId, `#${id} (${field}) is not described by an error message`);
      if (errorId) ok(new RegExp(`id="${errorId}"[^>]*>[^<]+`).test(html), `the message "${errorId}" for ${field} is not on the page`);
    }
    checkedFields += 1;
  }
  checkedForms += 1;
  assert.deepEqual(issues, [], `${label}: every failing field is reported properly`);
  return shown;
}

async function attempt(label, { url, csrfFrom, spec, extra = {}, upload = null, expectStatus = 400, skip = [], who = admin, expectKeys = [] }) {
  const sent = { ...extra };
  const keys = [];
  for (const fld of spec) { if (skip.includes(fld.field) || fld.field in extra) continue; sent[fld.field] = HOSTILE(fld); keys.push(fld.field); }
  const res = upload
    ? await who.upload(url, upload.file, { field: upload.field, fields: sent, csrfFrom })
    : await who.post(url, sent, { csrfFrom });
  const html = await res.text();
  assert.equal(res.status, expectStatus, `${label}: refused with ${expectStatus} (got ${res.status})`);
  return assertWellReported(html, label, [...keys, ...expectKeys]);
}

try {
  const M = (rel, marker) => validators(rel, marker);
  const memberSpec = M('lib/member-form.js', 'export function collectMemberInput');
  const member = ids.member.a2;
  const cases = [
    ['Add member', { url: '/members', csrfFrom: '/members/new', spec: memberSpec }],
    ['Edit member', { url: `/members/${member}`, csrfFrom: `/members/${member}/edit`, spec: memberSpec }],
    ['Add activity', { url: '/activities', csrfFrom: '/activities/new', spec: M('routes/activities.js', 'function collectActivityInput') }],
    ['Add group activity', { url: `/cell-groups/${ids.groupA}/activities`, csrfFrom: `/cell-groups/${ids.groupA}/activities/new`, spec: M('routes/activities.js', 'function collectActivityInput') }],
    ['Edit activity', { url: `/activities/${ids.activity}`, csrfFrom: `/activities/${ids.activity}/edit`, spec: M('routes/activities.js', 'function collectActivityInput') }],
    ['Add announcement', { url: '/announcements', csrfFrom: '/announcements/new', spec: M('routes/announcements.js', 'function collectAnnouncementInput') }],
    ['Edit announcement', { url: `/announcements/${ids.announcement}`, csrfFrom: `/announcements/${ids.announcement}/edit`, spec: M('routes/announcements.js', 'function collectAnnouncementInput') }],
    ['Add ministry', { url: '/ministries', csrfFrom: '/ministries/new', spec: M('routes/ministries.js', 'function collectInput') }],
    ['Edit ministry', { url: `/ministries/${ids.ministry}`, csrfFrom: `/ministries/${ids.ministry}/edit`, spec: M('routes/ministries.js', 'function collectInput') }],
    ['Add cell group', { url: '/cell-groups', csrfFrom: '/cell-groups/new', spec: M('routes/cell-groups.js', 'function collectGroupInput') }],
    ['Edit cell group', { url: `/cell-groups/${ids.groupA}`, csrfFrom: `/cell-groups/${ids.groupA}/edit`, spec: M('routes/cell-groups.js', 'function collectGroupInput') }],
    ['Add ECAQ campaign', { url: '/admin/ecaq/campaigns', csrfFrom: '/admin/ecaq/campaigns/new', spec: M('routes/ecaq.js', 'function collectCampaignInput') }],
    ['Add user', { url: '/admin/users', csrfFrom: '/admin/users/new', spec: M('routes/admin-users.js', 'function collectUserInput') }],
    ['New Family Group', { url: '/family-groups', csrfFrom: '/family-groups/new', spec: [{ method: 'text', field: 'name', max: 80 }], extra: {} }],
    ['Edit Family Group', { url: `/family-groups/${ids.family}`, csrfFrom: `/family-groups/${ids.family}/edit`, spec: [{ method: 'text', field: 'name', max: 80 }] }],
    ['New attendance session', { url: '/attendance/sessions', csrfFrom: '/attendance/sessions/new', spec: [{ method: 'text', field: 'title', max: 120 }, { method: 'date', field: 'service_date' }], extra: { service_type: 'cell_group_meeting' } }],
    ['My profile', { who: memberUser, url: '/my/profile', csrfFrom: '/my/profile', spec: [{ method: 'phone', field: 'phone' }, { method: 'email', field: 'email' }] }]
  ];
  // Forms whose rules are written inline rather than as a validator block: the failing fields are named here.
  const pdf = { name: 'x.pdf', type: 'application/pdf', buffer: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(300, 32)]) };
  const documentSpec = M('routes/documents.js', 'function collectInput').filter((x) => x.field !== 'category_id');
  const board = db.prepare('SELECT * FROM ecaq_campaigns WHERE id = ?').get(ids.board);
  const faith = db.prepare('SELECT id FROM ecaq_campaigns WHERE type = ?').get('faith_promise');
  const boardDate = mods.ecaq.boardDates(Number(mods.dates.today().slice(0, 4)))[1]; // the fixture already claimed the first date
  cases.push(
    ['Upload a document', { url: '/documents', csrfFrom: '/documents/new', spec: documentSpec, upload: { file: pdf, field: 'file' }, extra: { category_id: 'abc', amount: 'abc' } }],
    ['Edit a document', { url: `/documents/${ids.document}`, csrfFrom: `/documents/${ids.document}/edit`, spec: documentSpec, extra: { category_id: 'abc', amount: 'abc' } }],
    ['Quick edit (drawer)', { url: `/members/${member}/quick`, csrfFrom: `/members/${member}/edit`, spec: memberSpec.filter((x) => ['first_name', 'last_name', 'preferred_name', 'date_of_birth', 'phone', 'email', 'gender', 'cell_group_id', 'anniversary_date'].includes(x.field)) }],
    ['Faith Promise for a member', { url: '/admin/ecaq/faith-promise/new', csrfFrom: '/admin/ecaq/faith-promise/new', spec: [], extra: { campaign_id: String(faith.id), member_id: '', amount: 'abc', frequency: 'zzz' }, expectKeys: ['member_id'] }],
    ['Claim a date for a member', { url: '/admin/ecaq/claims', csrfFrom: `/admin/ecaq/claims/new?date=${boardDate}`, spec: [], extra: { date: boardDate, member_id: '', commitment_amount: 'abc' }, expectKeys: ['member_id'] }],
    ['Edit ECAQ campaign', { url: `/admin/ecaq/campaigns/${ids.board}`, csrfFrom: `/admin/ecaq/campaigns/${ids.board}/edit`, spec: M('routes/ecaq.js', 'function collectCampaignInput'), skip: ['currency', 'privacy_mode', 'type', 'year'] }],
    ['Edit user', { url: `/admin/users/${users.memberA.id}`, csrfFrom: `/admin/users/${users.memberA.id}/edit`, spec: M('routes/admin-users.js', 'function collectUserInput'), extra: { roles: 'member' }, skip: ['username'] }]
  );
  void board;
  const problems = [];
  for (const [label, c] of cases) {
    try { await attempt(label, c); } catch (error) { problems.push(`${label}: ${Array.isArray(error.actual) ? error.actual.join(' | ') : error.message.split('\n')[0]}`); }
  }
  if (problems.length) { console.log('PROBLEMS\n' + problems.join('\n')); }
  assert.deepEqual(problems, [], 'every form reports each failing field');
  console.log(`PASS (forms) ${checkedForms} forms, ${checkedFields} failing fields: each named in a focused summary, linked, marked aria-invalid, described by its message beside the field; no vague banner`);
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
