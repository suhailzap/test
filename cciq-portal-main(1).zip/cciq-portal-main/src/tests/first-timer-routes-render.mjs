import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The First Timer screens are walked the way a person walks them, through the real routes and the real views (an EJS failure cannot pass here):
 *   A  First Timers -> a one-visit person -> the detail page renders
 *   B  First Timers -> a returning person with several visits -> the detail page renders
 *   C  First Timer follow-up -> the inviter expansion -> an invitee -> the detail page renders
 *   D  First Timers -> Membership review renders when Attendance tracking has NOT started (every tab)
 *   E  the same screens in every review state: zero eligible Fridays, fewer than four, a qualifying person, nobody qualifying, an unfinalized newest Friday,
 *      a cancelled Friday and an Attendance Not Taken Friday
 *   F  every visitor-facing route renders for every kind of First Timer (new, returning, joined, declined, linked) and for each administrator role
 *
 * History this pins: a view was changed to read new locals while the running server still held the older route code, so /visitors/:id and /visitors/reviews
 * answered with the generic error page while the list and the follow-up page kept working. These tests fail if a view reads a local its route does not pass.
 */

const f = await buildPortalFixture('cciq-ft-render-');
const { db, ids, users, mods } = f;
const { today, addDays, lastFridayOnOrBefore } = mods.dates;
const lifecycle = await import('../services/attendance-lifecycle.js');
const review = await import('../services/membership-review.js');
const atNoon = (d) => `${d}T09:00:00.000Z`;
const SERVICE = lastFridayOnOrBefore(today());
const W = (n) => addDays(SERVICE, 7 * n);
const OLD = addDays(SERVICE, -400);
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const one = (sql, ...p) => db.prepare(sql).get(...p);

const sessions = new Map();
function world({ start = null } = {}) {
  db.exec('DELETE FROM visitor_membership_reviews; DELETE FROM visitor_visits; DELETE FROM attendance_records; DELETE FROM attendance_expected; DELETE FROM attendance_sessions; DELETE FROM visitors; DELETE FROM notifications; DELETE FROM reminders;');
  for (const m of db.prepare('SELECT id, status FROM members').all()) {
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    db.prepare('UPDATE members SET created_at = ?, date_joined = ? WHERE id = ?').run(atNoon(OLD), OLD, m.id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)').run(m.id, m.status, 'planted', atNoon(OLD));
  }
  mods.setSetting('attendance.tracking_start_date', start || '');
  sessions.clear();
  for (const n of range(-12, -1)) {
    db.prepare("INSERT INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(W(n), atNoon(W(n)));
    sessions.set(n, one("SELECT * FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service'", W(n)));
  }
}
function person(first, last, visits, { inviter = null, state = null } = {}) {
  const v = mods.visitors.createVisitor({ first_name: first, last_name: last, first_visit_date: W(Math.min(...visits)), phone: null, invited_by_member_id: inviter }, { userId: null });
  for (const n of visits) db.prepare('INSERT OR IGNORE INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at) VALUES (?, ?, ?, ?)').run(v.id, W(n), sessions.get(n).id, atNoon(W(n)));
  if (state) db.prepare('UPDATE visitors SET state = ? WHERE id = ?').run(state, v.id);
  return v.id;
}
const fin = (...ns) => { for (const n of ns) { const r = lifecycle.finalizeAttendance(sessions.get(n).id, { userId: null, confirmNoAttendance: true }); assert.equal(r.ok, true, `finalize W(${n}): ${r.reason}`); } };

let portal = null; let clients = null;
const serve = async () => {
  if (portal) await portal.stop();
  portal = await startPortal();
  clients = {
    super: await signIn(portal.base, users.superAdmin.email, f.PASSWORD),
    church: await signIn(portal.base, users.churchAdmin.email, f.PASSWORD),
    leader: await signIn(portal.base, users.leaderA.email, f.PASSWORD),
    member: await signIn(portal.base, users.memberA.email, f.PASSWORD)
  };
};
const get = async (client, url) => { const r = await client.get(url); const body = await r.text(); return { status: r.status, body, location: r.headers.get('location') }; };
const rendered = (r, label) => { assert.equal(r.status, 200, `${label} -> ${r.status}`); assert.ok(!/Something went wrong/.test(r.body), `${label} is not the error page`); assert.match(r.body, /<\/html>\s*$/, `${label} is a complete page`); };
const links = (body, re) => [...new Set([...body.matchAll(re)].map((m) => m[1]))];
const inviter = ids.member.a1;

try {
  // ---- A, B, C, D: tracking has NOT started (the owner's DEV) ------------------------------------------------------------------------------------------------------------
  world({ start: null });
  const robert = person('Robert', 'Jaworski', [-1], { inviter });
  const isaiah = person('Isaiah', 'Thomas', [-12, -11, -10, -7, -4, -2, -1], { inviter });
  review.evaluateMembershipReviews();
  await serve();
  const list = await get(clients.church, '/visitors'); rendered(list, 'First Timers list');
  const ids1 = links(list.body, /href="\/visitors\/(\d+)"/g);
  assert.ok(ids1.includes(String(robert)) && ids1.includes(String(isaiah)), 'both are in the list');
  { const r = await get(clients.church, `/visitors/${robert}`); rendered(r, 'A: one-visit detail'); assert.match(r.body, /Robert Jaworski/); assert.match(r.body, /Membership review:/); }
  { const r = await get(clients.church, `/visitors/${isaiah}`); rendered(r, 'B: returning detail'); assert.match(r.body, /Isaiah Thomas/); assert.match(r.body, /7 recorded/, 'all seven visits'); assert.match(r.body, /not running yet/); }
  const follow = await get(clients.church, '/visitors/follow-up'); rendered(follow, 'follow-up list');
  const followIds = links(follow.body, /href="\/visitors\/(\d+)"/g);
  assert.ok(followIds.length > 0, 'the follow-up page lists people (including under the inviter expansion)');
  for (const id of followIds) rendered(await get(clients.church, `/visitors/${id}`), `C: follow-up -> invitee ${id}`);
  for (const status of ['', '?status=open', '?status=continued', '?status=converted', '?status=linked', '?status=all']) {
    const r = await get(clients.church, `/visitors/reviews${status}`); rendered(r, `D: membership review ${status || 'open'} (tracking not started)`);
    assert.match(r.body, /Membership review is not running yet/);
  }
  console.log(`PASS (A-D) list -> one-visit and returning detail, follow-up -> invitee (${followIds.length} linked), and Membership review with tracking not started: all render`);

  // ---- E. every review state, rendered ---------------------------------------------------------------------------------------------------------------------------------------
  const states = [
    ['zero eligible Fridays', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-4, -2, -1], { inviter }); }, /Not enough finalized Friday Services yet/, 0],
    ['fewer than four finalized Fridays', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-10, -9], { inviter }); fin(-10, -9, -8); }, /3 so far/, 0],
    ['a qualifying person', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-12, -11, -10, -7, -4, -2, -1], { inviter }); fin(...range(-10, -1)); }, /Checked against the last 4 finalized Friday Services/, 1],
    ['nobody qualifying', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-10, -7], { inviter }); fin(...range(-10, -1)); }, /Checked against the last 4 finalized Friday Services/, 0],
    ['the newest Friday not finalized', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-4, -3, -2], { inviter }); fin(...range(-10, -2)); }, /Checked against the last 4 finalized Friday Services/, 1],
    ['an unfinalized Friday inside the window', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-4, -2, -1], { inviter }); fin(...range(-10, -4), -2, -1); }, /Waiting for/, 0],
    ['a cancelled Friday', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-4, -3, -1], { inviter }); fin(...range(-10, -4), -2, -1); db.prepare("UPDATE attendance_sessions SET status = 'cancelled' WHERE id = ?").run(sessions.get(-3).id); }, /Checked against the last 4 finalized Friday Services/, null],
    ['an Attendance Not Taken Friday', () => { world({ start: W(-10) }); person('Robert', 'Jaworski', [-1], { inviter }); person('Isaiah', 'Thomas', [-4, -3, -1], { inviter }); fin(...range(-10, -4), -3, -1); const nt = lifecycle.markAttendanceNotTaken(sessions.get(-2).id, { userId: null, note: 'Power cut' }); assert.equal(nt.ok, true); }, /Checked against the last 4 finalized Friday Services/, null]
  ];
  for (const [label, build, wording, openExpected] of states) {
    build();
    review.evaluateMembershipReviews();
    await serve();
    const open = db.prepare("SELECT COUNT(*) n FROM visitor_membership_reviews WHERE status = 'open'").get().n;
    if (openExpected !== null) assert.equal(open, openExpected, `${label}: ${open} open`);
    const reviews = await get(clients.church, '/visitors/reviews'); rendered(reviews, `E ${label}: review page`);
    assert.match(reviews.body, wording, `${label}: the explanation`);
    for (const status of ['continued', 'converted', 'linked', 'all']) rendered(await get(clients.church, `/visitors/reviews?status=${status}`), `E ${label}: ${status} tab`);
    for (const { id } of db.prepare('SELECT id FROM visitors').all()) rendered(await get(clients.church, `/visitors/${id}`), `E ${label}: visitor ${id}`);
    for (const { id } of db.prepare('SELECT id FROM visitor_membership_reviews').all()) rendered(await get(clients.church, `/visitors/reviews/${id}`), `E ${label}: review ${id}`);
    rendered(await get(clients.church, '/visitors'), `E ${label}: list`); rendered(await get(clients.church, '/visitors/follow-up'), `E ${label}: follow-up`);
  }
  console.log(`PASS (E) ${states.length} review states render on every route and tab: ${states.map((s) => s[0]).join('; ')}`);

  // ---- F. every kind of First Timer, every visitor route, every role that may see them ------------------------------------------------------------------------------------------
  world({ start: W(-10) }); fin(...range(-10, -1));
  const kinds = {
    new: person('Newa', 'One', [-1], { inviter }), returning: person('Retta', 'Many', [-5, -4, -3, -2, -1], { inviter }),
    declined: person('Dec', 'Lined', [-3, -2, -1], { state: 'declined' }), noReturn: person('Nora', 'Away', [-9], { state: 'not_returned' }),
    anonymousInviter: person('Lone', 'Walker', [-2]), linked: person('Linka', 'Member', [-3, -2, -1])
  };
  review.evaluateMembershipReviews();
  mods.visitors.linkVisitorToMember(kinds.linked, ids.member.free, { userId: users.churchAdmin.id });
  const reviewRows = db.prepare('SELECT id FROM visitor_membership_reviews').all();
  await serve();
  for (const [who, client] of [['Super Admin', clients.super], ['Church Admin', clients.church]]) {
    for (const [kind, id] of Object.entries(kinds)) {
      for (const suffix of ['', '/edit', '/convert', '/link']) {
        const r = await get(client, `/visitors/${id}${suffix}`);
        assert.ok(r.status === 200 || r.status === 302, `F ${who}: ${kind} ${suffix || 'detail'} -> ${r.status}`);
        assert.ok(!/Something went wrong/.test(r.body), `F ${who}: ${kind} ${suffix || 'detail'} is not the error page`);
      }
    }
    for (const { id } of reviewRows) rendered(await get(client, `/visitors/reviews/${id}`), `F ${who}: review ${id}`);
    for (const url of ['/visitors', '/visitors/follow-up', '/visitors/reviews', '/visitors/reviews?status=all', '/visitors/new']) rendered(await get(client, url), `F ${who}: ${url}`);
  }
  // a Member is refused the review screens and never sees an error page on the others
  for (const url of ['/visitors/reviews', `/visitors/${kinds.new}/edit`]) { const r = await get(clients.member, url); assert.equal(r.status, 403, `a Member is refused ${url}`); }
  for (const url of ['/visitors', '/visitors/follow-up', `/visitors/${kinds.returning}`]) { const r = await get(clients.leader, url); assert.ok(r.status < 500 && !/Something went wrong/.test(r.body), `leader ${url} -> ${r.status}`); }
  console.log('PASS (F) every kind of First Timer on every visitor route renders for Super Admin and Church Admin; a Member is refused the review screens and nobody gets an error page');
  console.log('PASS first-timer-routes-render');
} finally {
  if (portal) await portal.stop();
}
