import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { chromium } from 'playwright';
import { pathToFileURL } from 'node:url';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The in-portal Help / User Guide and its offline handover edition: ONE source (src/help), one renderer (src/lib/user-guide.js).
 *   A. the source is whole: every chapter listed has a file and the other way round, every audience parses, every internal link and screenshot resolves, nothing in it breaks the portal's
 *      Content-Security-Policy or reaches the network, no test person or secret is named in it;
 *   B. /help needs a signed-in person (the stylesheet, script, logo and screenshots too), and each ROLE is sent only its own chapters, steps and pictures: the restricted material is not in the
 *      response, so there is nothing to find by guessing a URL, and a screenshot for another role is refused the same way as one that does not exist;
 *   C. the pages work in a real browser: offline search finds a role's own content and can NOT find another role's (it is not in the page), a narrow screen does not scroll sideways, print drops the
 *      controls, every picture loads, no console error;
 *   D. the offline handover edition opens from a plain folder (file://) with every chapter, search and pictures, and says exactly what the Super Admin's in-portal Help says (they cannot drift).
 */

const root = path.join(path.dirname(new URL(import.meta.url).pathname.slice(1)), '..', '..');
const guideLib = await import(new URL('../lib/user-guide.js', import.meta.url));
const buildLib = await import(new URL('../lib/user-guide-build.js', import.meta.url));
const { ROLE_KEYS, parseAudience, loadGuide, visibleGuide, renderGuide } = guideLib;
const helpDir = path.join(root, 'src', 'help');
const read = (...p) => fs.readFileSync(path.join(helpDir, ...p), 'utf8');
const textOf = (html) => html.replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ').trim();

// ---- A. the source -------------------------------------------------------------------------------------------------------------------------------------------------------
{
  const manifest = JSON.parse(read('guide.json'));
  const ids = manifest.sections.map((s) => s.id);
  assert.equal(new Set(ids).size, ids.length, 'chapter ids are unique');
  const files = fs.readdirSync(path.join(helpDir, 'chapters')).filter((n) => n.endsWith('.html')).map((n) => n.replace(/\.html$/, ''));
  assert.deepEqual([...files].sort(), [...ids].sort(), 'every chapter in guide.json has a file, and every file is a chapter');
  assert.ok(ids.length >= 20, 'the retained sanitized chapters are present');
  for (const s of manifest.sections) {
    assert.ok(s.title && s.roles, `${s.id} has a title and a who-it-is-for label`);
    parseAudience([].concat(s.audience).join(' '));
    for (const x of s.screenshots || []) {
      assert.ok(x.stem && x.caption && x.brief, `${s.id}/${x.stem} has a caption`);
      if (x.audience) parseAudience([].concat(x.audience).join(' '));
      const file = path.join(helpDir, 'screenshots', `${x.stem}.png`);
      assert.ok(fs.existsSync(file), `screenshot ${x.stem}.png exists (no placeholder is left in the guide)`);
      const bytes = fs.readFileSync(file);
      assert.deepEqual([...bytes.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10], `${x.stem}.png is a real PNG`);
      assert.ok(bytes.length > 20000 && bytes.length < 1500000, `${x.stem}.png is a sensible size (${bytes.length})`);
    }
  }
  const stems = manifest.sections.flatMap((s) => (s.screenshots || []).map((x) => `${x.stem}.png`));
  const screenshotDir = path.join(helpDir, 'screenshots');
  const onDisk = fs.existsSync(screenshotDir) ? fs.readdirSync(screenshotDir).filter((n) => n.endsWith('.png')) : [];
  assert.deepEqual([...onDisk].sort(), [...stems].sort(), 'no screenshot file is unused and none is missing');
  assert.equal(stems.length, 0, 'member-specific screenshots are excluded from the sanitized source');

  const allText = [read('template.html'), ...files.map((n) => read('chapters', `${n}.html`))].join('\n');
  const links = [...allText.matchAll(/href="#([^"]+)"/g)].map((m) => m[1]).filter((h) => !['top'].includes(h));
  for (const l of links) assert.ok(ids.includes(l) || ['main'].includes(l), `internal link #${l} points at a chapter`);
  assert.doesNotMatch(allText, /\sstyle\s*=|\son[a-z]+\s*=\s*["']|<script(?![^>]*\ssrc=)|javascript:|<iframe|<style/i, 'no inline style, handler, script or frame (the Content-Security-Policy would block them)');
  assert.doesNotMatch(allText, /(?:src|href)\s*=\s*["']\s*(?:https?:)?\/\//i, 'the guide reaches no other site');
  assert.doesNotMatch(read('assets', 'guide.css'), /@import|url\(\s*["']?(?:https?:)?\/\//i, 'the stylesheet imports nothing');
  assert.doesNotMatch(read('assets', 'guide.js'), /fetch\(|XMLHttpRequest|localStorage|sessionStorage|eval\(|document\.write|import\(|WebSocket/, 'the script uses no network, storage or eval');
  assert.doesNotMatch(allText, /SAMPLE_PERSON_NAME|SAMPLE_MEMBER_ID|\bpassword\s*[:=]\s*\S|secret\s*[:=]|api[_-]?key/i, 'no test person, password or secret is written into the guide');

  // the audiences are what the product's role design says
  const view = (roles) => visibleGuide(roles).sections.map((s) => s.id);
  assert.deepEqual(view(['kiosk']), ['kiosk', 'help'], 'the reception terminal is shown the reception chapter and the safe-habits chapter, nothing else');
  assert.deepEqual(view(['member']), ['roles', 'login', 'dashboard', 'projects', 'faith-promise', 'documents', 'communications', 'member', 'help']);
  assert.deepEqual(view(['cell_group_leader']), ['roles', 'login', 'dashboard', 'friday', 'leaders', 'ministries', 'projects', 'faith-promise', 'documents', 'communications', 'member', 'help']);
  for (const role of ['church_admin', 'super_admin']) assert.equal(view([role]).length, ids.length, `${role} is shown every chapter`);
  for (const r of ['member', 'cell_group_leader', 'kiosk']) for (const id of ['handover', 'administration', 'backups', 'computer', 'dob', 'corrections', 'members', 'reports']) assert.ok(!view([r]).includes(id), `${r} is not given ${id}`);
  console.log(`PASS (source) ${ids.length} chapters, ${stems.length} screenshots, audiences resolve, links resolve, CSP-safe and offline-safe, no placeholder, no test person`);
}

// ---- B. /help over HTTP, by role -----------------------------------------------------------------------------------------------------------------------------------------
const f = await buildPortalFixture('cciq-user-guide-');
const portal = await startPortal();
const { users } = f;
const chaptersIn = (html) => [...html.matchAll(/<section class="chapter" id="([^"]+)"/g)].map((m) => m[1]);
const imagesIn = (html) => [...html.matchAll(/<img src="(\/help\/screenshots\/[^"]+)"/g)].map((m) => m[1]);
const sessions = {};
for (const [key, account] of Object.entries({ super_admin: users.superAdmin, church_admin: users.churchAdmin, cell_group_leader: users.leaderA, member: users.memberA, kiosk: users.kiosk })) {
  sessions[key] = await signIn(portal.base, account.email, f.PASSWORD);
  assert.ok([302, 303].includes(sessions[key].loginStatus), `${key} signs in`);
}
const pages = {};
try {
  { // signed out
    for (const p of ['/help', '/help/assets/guide.css', '/help/assets/guide.js', '/help/assets/cciq-logo.png']) {
      const res = await fetch(`${portal.base}${p}`, { redirect: 'manual' });
      assert.equal(res.status, 302, `${p} signed out redirects`);
      assert.match(res.headers.get('location'), /^\/login\?next=/, `${p} goes to the sign-in page`);
      assert.doesNotMatch(await res.text(), /Create backup now|Restore this backup|chapter/, `${p} signed out sends none of the guide`);
    }
    const login = await (await fetch(`${portal.base}/login`)).text();
    assert.doesNotMatch(login, /href="\/help|User Guide|Help \//, 'the public sign-in page has no link to the guide');
    console.log('PASS (signed out) /help and every guide file send a signed-out visitor to sign in, and the sign-in page does not mention the guide');
  }

  for (const [role, s] of Object.entries(sessions)) {
    const res = await s.get('/help');
    assert.equal(res.status, 200, `${role} gets the guide`);
    assert.match(res.headers.get('content-type'), /text\/html/);
    assert.match(res.headers.get('cache-control') || '', /no-store/, 'the guide is not cached by the browser');
    assert.match(res.headers.get('content-security-policy') || '', /script-src 'self'/, 'the portal CSP applies');
    const html = await res.text();
    pages[role] = html;
    assert.deepEqual(chaptersIn(html), visibleGuide([role]).sections.map((x) => x.id), `${role}: the page holds exactly the chapters meant for that role`);
    assert.doesNotMatch(html, /data-audience|<!--audience|\{\{[A-Z_]+\}\}/, `${role}: no markup of the audience system or an unfilled placeholder reaches the page`);
    assert.doesNotMatch(html, /\sstyle\s*=|\son[a-z]+\s*=\s*["']|<script(?![^>]*\ssrc=)/i, `${role}: nothing the CSP would block`);
    assert.match(html, /href="\/help\/assets\/guide\.css"/); assert.match(html, /src="\/help\/assets\/guide\.js"/);
    assert.match(html, /Back to the portal/, 'a way back');
    assert.match(html, role === 'kiosk' ? /href="\/kiosk">← Back/ : /href="\/">← Back/, `${role}: the way back goes to the person's own home`);
  }

  // what each role must NOT be sent: distinctive text from blocks outside its audience
  const guide = loadGuide();
  for (const role of ROLE_KEYS) {
    const mine = textOf(pages[role]);
    let checked = 0;
    for (const sec of guide.sections) for (const b of sec.blocks) {
      if (b.audience.has(role)) continue;
      const t = textOf(b.html); if (t.length < 80) continue;
      const snippet = t.slice(20, 75);
      if (mine.includes(snippet)) continue; // the same sentence also appears in a block this role may read: not a leak
      checked += 1;
      assert.ok(!mine.includes(snippet), `${role} must not receive: ${snippet}`);
    }
    assert.ok(checked > ({ super_admin: -1, church_admin: 2 }[role] ?? 5), `${role}: ${checked} restricted passages were checked`);
  }
  const SENTINELS = {
    admin: ['Review and finalize', 'Confirm the full date of birth', 'Correct attendance', 'Make them a new member', 'Date of birth review'],
    superOnly: ['Change the Attendance Tracking Start Date', 'Roles and permissions', 'Deactivate portal access']
  };
  for (const role of ['member', 'cell_group_leader', 'kiosk']) for (const w of [...SENTINELS.admin, ...SENTINELS.superOnly]) assert.ok(!pages[role].includes(w), `${role} is not sent "${w}"`);
  for (const w of SENTINELS.admin) assert.ok(pages.church_admin.includes(w) && pages.super_admin.includes(w), `both administrators are sent "${w}"`);
  for (const w of SENTINELS.superOnly) { assert.ok(pages.super_admin.includes(w), `the Super Admin is sent "${w}"`); assert.ok(!pages.church_admin.includes(w), `the Church Admin is NOT sent the Super Admin-only "${w}"`); }
  assert.ok(pages.cell_group_leader.includes('Group meetings') && pages.cell_group_leader.includes('Publish an activity'), 'the leader gets the leader routine and the activity steps');
  assert.ok(!pages.cell_group_leader.includes('Maintain ministry teams'), 'but not the ministry administration');
  assert.ok(pages.member.includes('My Commitments') && !pages.member.includes('Record a commitment or payment in the office'), 'the member gets My Commitments but not the finance steps');
  assert.ok(pages.kiosk.includes('Scan the member’s personal attendance QR') && !pages.kiosk.includes('Giving Board'), 'the reception terminal gets the reception steps only');
  assert.ok(!/<li><strong>Office:/.test(pages.member) && /<li><strong>Office:/.test(pages.church_admin) && /<li><strong>Leader:/.test(pages.cell_group_leader) && !/<li><strong>Leader:/.test(pages.member), 'bullets inside a shared chapter are filtered too');
  assert.ok(!/href="#handover"|href="#administration"|href="#backups"/.test(pages.member), 'a link to a chapter the person is not sent is plain text, not a dead link');
  console.log('PASS (roles) Super Admin, Church Admin, Cell Group Leader, Member and Kiosk are each sent only their own chapters, steps and bullets; restricted text is not in the response');

  { // files: assets and screenshots by role
    for (const [role, s] of Object.entries(sessions)) {
      for (const [name, type] of [['guide.css', /text\/css/], ['guide.js', /javascript/], ['cciq-logo.png', /image\/png/]]) {
        const res = await s.get(`/help/assets/${name}`);
        assert.equal(res.status, 200, `${role} /help/assets/${name}`); assert.match(res.headers.get('content-type'), type); await res.arrayBuffer();
      }
      for (const bad of ['../../../.env', '..%2f..%2fsrc%2fserver.js', 'guide.json', 'template.html', '%2e%2e%2fchapters%2fbackups.html', 'x.css', 'guide.css%00.png']) {
        const res = await s.get(`/help/assets/${bad}`); assert.ok([302, 400, 404].includes(res.status), `${role}: /help/assets/${bad} is refused (${res.status})`); assert.doesNotMatch(await res.text(), /SESSION_SECRET|DATABASE_FILE|createServer|<section class="chapter"/);
      }
      for (const bad of ['../x.png', 'chapters.png', 'dashboard.jpg', 'dashboard.png%00', '%2e%2e%2fserver.png', 'nothing.png']) {
        const res = await s.get(`/help/screenshots/${bad}`); assert.ok([302, 400, 404].includes(res.status), `${role}: /help/screenshots/${bad} is refused (${res.status})`); await res.text();
      }
      // Member screenshots were removed from this sanitized source; no page should send one to any role.
      const mine = new Set(imagesIn(pages[role]));
      assert.equal(mine.size, 0, `${role} receives no member screenshots`);
      for (const src of mine) { const res = await s.get(src); assert.equal(res.status, 200, `${role} ${src}`); assert.match(res.headers.get('content-type'), /image\/png/); assert.ok((await res.arrayBuffer()).byteLength > 20000); }
      for (const sec of guide.sections) for (const x of sec.screenshots) {
        const url = `/help/screenshots/${x.stem}.png`; if (mine.has(url)) continue;
        const res = await s.get(url); assert.equal(res.status, 404, `${role} must not receive ${url} (${res.status})`); await res.text();
      }
    }
    const missing = await sessions.member.get('/help/screenshots/nothing.png'); const refused = await sessions.member.get('/help/screenshots/backups.png');
    assert.equal(await missing.text(), await refused.text(), 'a screenshot for another role looks exactly like one that does not exist');
    console.log('PASS (files) stylesheet, script and logo need sign-in; no path trick reaches anything else; each role loads every picture on its own page and is refused every other role\'s picture');
  }

  { // navigation
    const sidebar = (html) => /<nav class="sidenav"[\s\S]*?<\/nav>/.exec(html)?.[0] || '';
    for (const role of ['super_admin', 'church_admin', 'cell_group_leader', 'member']) {
      const home = await (await sessions[role].get('/')).text();
      assert.match(sidebar(home), /href="\/help"[\s\S]{0,200}Help \/ User Guide/, `${role}: the menu offers Help / User Guide`);
      assert.match(sidebar(home), /<a [^>]*href="\/help"[^>]*target="_blank"[^>]*rel="noopener noreferrer"[^>]*>/, `${role}: the Help link opens in a new tab, with rel protection`);
    }
    const kioskHome = await (await sessions.kiosk.get('/kiosk')).text();
    assert.match(kioskHome, /<a [^>]*href="\/help" target="_blank" rel="noopener noreferrer">Help</, 'the reception screen has a Help button that opens in a new tab, with rel protection');
    assert.equal((await sessions.kiosk.get('/help')).status, 200, 'a reception session is allowed its own guide');
    for (const p of ['/members', '/admin/backups', '/admin/users', '/reports', '/documents']) {
      const res = await sessions.kiosk.get(p); assert.equal(res.status, 302, `the reception session is still confined: ${p}`); assert.equal(res.headers.get('location'), '/kiosk');
    }
    for (const p of ['/admin/backups', '/admin/users', '/admin/attendance/tracking-start', '/members/dob-review']) {
      for (const role of ['member', 'cell_group_leader']) { const res = await sessions[role].get(p); assert.ok([302, 403, 404].includes(res.status), `${role} still cannot open ${p} (${res.status})`); await res.text(); }
    }
    console.log('PASS (navigation) the sidebar offers Help to everyone who signs in, the Kiosk has a Help button, the Kiosk stays confined elsewhere, and the administrator screens are still closed to the others');
  }

  // ---- C. in a real browser -----------------------------------------------------------------------------------------------------------------------------------------------
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  try {
    const contextFor = async (role, viewport = { width: 1280, height: 900 }) => {
      const context = await browser.newContext({ viewport });
      await context.addCookies(sessions[role].cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
      return context;
    };
    const errors = [];
    const watch = (page) => { page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); }); page.on('pageerror', (e) => errors.push(String(e))); page.on('requestfailed', (r) => { if (!/\/kiosk\/count$/.test(r.url())) errors.push(`failed ${r.url()}`); }); /* the reception screen's own count poll may be cut off when a tab closes */ };
    const search = async (page, term) => { await page.fill('#guide-query', term); await page.waitForTimeout(150); return { status: (await page.textContent('#search-status')).trim(), hits: await page.locator('#search-results li').count(), text: (await page.textContent('#search-results')) || '' }; };

    { // administrator
      const ctx = await contextFor('church_admin'); const page = await ctx.newPage(); watch(page);
      await page.goto(`${portal.base}/help`, { waitUntil: 'load' });
      assert.equal(await page.locator('section.chapter').count(), loadGuide().sections.length);
      const imgs = await page.evaluate(() => [...document.images].map((i) => ({ src: i.getAttribute('src'), ok: i.complete })));
      await page.evaluate(() => document.querySelectorAll('img[loading=lazy]').forEach((i) => { i.loading = 'eager'; }));
      await page.waitForFunction(() => [...document.images].every((i) => i.complete && i.naturalWidth > 0), null, { timeout: 15000 });
      assert.ok(imgs.length >= 1, `the administrator's page carries the portal logo (${imgs.length})`);
      const found = await search(page, 'Continue as visitor'); assert.ok(found.hits >= 1 && /Continue as visitor/i.test(found.text), 'an administrator finds the Continue as visitor guidance');
      const backups = await search(page, 'Create backup now'); assert.equal(backups.hits, 0, 'church-specific recovery instructions are excluded from the sanitized guide');
      const none = await search(page, 'zzzqqqxx'); assert.equal(none.hits, 0); assert.match(none.status, /No matching/);
      await search(page, 'kiosk'); await page.locator('#search-results a').first().click(); assert.ok((await page.evaluate(() => location.hash)).length > 1, 'a result jumps to its place');
      await page.fill('#guide-query', 'x'); await page.click('#search-clear'); assert.equal(await page.inputValue('#guide-query'), '');
      await page.emulateMedia({ media: 'print' });
      assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('.guide-search')).display), 'none', 'print leaves out the search box');
      assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('.header-actions')).display), 'none', 'and the on-screen buttons');
      await page.emulateMedia({ media: 'screen' });
      await ctx.close();
    }
    { // a member: the search cannot find what was never sent; a phone is not scrolled sideways
      const ctx = await contextFor('member', { width: 375, height: 812 }); const page = await ctx.newPage(); watch(page);
      await page.goto(`${portal.base}/help`, { waitUntil: 'load' });
      assert.equal(await page.locator('section.chapter').count(), 9);
      for (const term of ['Create backup now', 'Review and finalize', 'Date of birth review', 'Attendance Tracking Start Date', 'Reset password under Administration']) {
        const r = await search(page, term); assert.equal(r.hits, 0, `a member's search for "${term}" finds nothing`);
      }
      assert.ok((await search(page, 'My Commitments')).hits >= 1, 'but finds the member steps');
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      assert.ok(overflow <= 1, `no sideways scrolling on a phone (${overflow}px)`);
      await ctx.close();
    }
    { // the reception terminal
      const ctx = await contextFor('kiosk'); const page = await ctx.newPage(); watch(page);
      await page.goto(`${portal.base}/kiosk`, { waitUntil: 'load' });
      const [help] = await Promise.all([ctx.waitForEvent('page'), page.click('a[href="/help"]')]);
      await help.waitForLoadState('load'); watch(help);
      assert.equal(new URL(page.url()).pathname, '/kiosk', 'the reception screen stays open in its own tab');
      assert.equal(new URL(help.url()).pathname, '/help', 'and the guide opens in a new one');
      assert.equal(await help.locator('section.chapter').count(), 2);
      assert.equal((await search(help, 'Create backup now')).hits, 0, 'the reception terminal cannot search its way to the backup steps');
      await Promise.all([help.waitForNavigation({ waitUntil: 'load' }), help.click('a.back-portal')]);
      assert.equal(new URL(help.url()).pathname, '/kiosk', 'and the guide\'s way back goes to the reception screen');
      await ctx.close();
    }
    { // the sidebar link: a new tab, the page the person is on stays put
      const ctx = await contextFor('member'); const page = await ctx.newPage(); watch(page);
      await page.goto(`${portal.base}/`, { waitUntil: 'load' });
      await page.evaluate(() => { document.body.dataset.stay = 'yes'; });
      const [help] = await Promise.all([ctx.waitForEvent('page'), page.click('#sidenav a[href="/help"]')]);
      await help.waitForLoadState('load'); watch(help);
      assert.equal(new URL(help.url()).pathname, '/help', 'the guide opens in a new tab');
      assert.equal(new URL(page.url()).pathname, '/', 'the page the person was on is still there');
      assert.equal(await page.evaluate(() => document.body.dataset.stay), 'yes', 'untouched (not reloaded)');
      assert.equal(await help.evaluate(() => window.opener), null, 'and the new tab cannot reach back into the portal tab (rel protection)');
      await ctx.close();
    }
    assert.deepEqual(errors, [], `no console error and no failed request: ${errors.join(' | ')}`);
    console.log('PASS (browser) search finds a role\'s own content and cannot find another role\'s, pictures load, a phone does not scroll sideways, print drops the controls, the Kiosk guide opens from and returns to the reception screen');

    // ---- D. the offline handover edition ---------------------------------------------------------------------------------------------------------------------------------
    const out = path.join(os.tmpdir(), `cciq-guide-build-${process.pid}`);
    fs.rmSync(out, { recursive: true, force: true });
    const built = buildLib.buildHandoverEdition(out);
    assert.equal(built.chapters, loadGuide().sections.length);
    for (const p of ['index.html', 'README.txt', 'assets/guide.css', 'assets/guide.js', 'assets/cciq-logo.png']) assert.ok(fs.existsSync(path.join(out, p)), `${p} is in the handover folder`);
    assert.equal(fs.readdirSync(path.join(out, 'screenshots')).length, built.screenshots);
    const html = fs.readFileSync(path.join(out, 'index.html'), 'utf8');
    assert.doesNotMatch(html, /\{\{[A-Z_]+\}\}|data-audience|shot-placeholder|Back to the portal/, 'no placeholder, no audience markup, no portal link in the offline edition');
    assert.match(html, /src="assets\/guide\.js"/); assert.match(html, /href="assets\/guide\.css"/);
    assert.deepEqual(chaptersIn(html), loadGuide().sections.map((s) => s.id), 'the handover edition holds every chapter');
    // no drift: the Super Admin's Help says what the handover edition says (the sections themselves are byte for byte the same)
    const body = (h) => (/<main id="main">[\s\S]*<footer>/.exec(h) || [''])[0].replace(/<section class="guide-search"[\s\S]*?<\/section>/, '').replace(/<div class="hero">[\s\S]*?<\/div>\s*<div class="release-note">[\s\S]*?<\/div>/, '').replace(/src="[^"]*screenshots\//g, 'src="S/');
    assert.equal(body(pages.super_admin), body(html), 'the Super Admin\'s in-portal Help and the offline handover edition carry identical chapters');
    // through a plain double-click: file://
    const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); watch(page);
    const requests = []; page.on('request', (r) => requests.push(r.url()));
    await page.goto(pathToFileURL(path.join(out, 'index.html')).href, { waitUntil: 'load' });
      assert.equal(await page.locator('section.chapter').count(), loadGuide().sections.length);
    await page.evaluate(() => document.querySelectorAll('img[loading=lazy]').forEach((i) => { i.loading = 'eager'; }));
    await page.waitForFunction(() => [...document.images].every((i) => i.complete && i.naturalWidth > 0), null, { timeout: 15000 });
    assert.equal((await search(page, 'Restore CCIQ From Backup')).hits, 0, 'offline search does not include excluded church recovery instructions');
    assert.ok((await search(page, 'Continue as visitor')).hits >= 1);
    assert.ok(requests.every((u) => u.startsWith('file:')), `the handover edition touches nothing but its own files: ${requests.filter((u) => !u.startsWith('file:')).join(', ')}`);
    assert.deepEqual(errors, [], `no console error from the offline edition: ${errors.join(' | ')}`);
    // a second build into the same folder is allowed (it is the earlier build); a folder holding other files is refused
    buildLib.buildHandoverEdition(out);
    const other = path.join(os.tmpdir(), `cciq-guide-other-${process.pid}`); fs.mkdirSync(other, { recursive: true }); fs.writeFileSync(path.join(other, 'precious.txt'), 'x');
    assert.throws(() => buildLib.buildHandoverEdition(other), /not empty/, 'a folder with someone else\'s files is never overwritten');
    assert.ok(fs.existsSync(path.join(other, 'precious.txt')));
    fs.rmSync(other, { recursive: true, force: true }); fs.rmSync(out, { recursive: true, force: true });
    console.log('PASS (handover) the offline edition has every chapter and picture, opens from a plain folder with search working and nothing fetched, matches the Super Admin\'s Help exactly, and will not overwrite a folder that is not its own');
  } finally {
    await browser.close();
  }
  // a render with no roles at all returns nothing to read (defence in depth)
  assert.equal(visibleGuide([]).sections.length, 0, 'a person with no role is shown no chapter');
  assert.ok(renderGuide({ roles: ['member'], mode: 'portal' }).chapters.length === 9);
} finally {
  await portal.stop();
}
console.log('PASS user-guide-help');

