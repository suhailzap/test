import assert from 'node:assert/strict';
import { createIsolatedTestEnv } from './lib/test-env.mjs';

/*
 * Regression coverage for a real defect physical production validation
 * found: Print a report -> Friday Service Attendance, filtered to Bonafide
 * only (96 members in production), showed "Members counted: 96" correctly
 * but the "Members present at each service" chart showed values like 133,
 * 106, 134 - impossible for a 96-member population. Root cause: the chart
 * called sessionSummary(sessionId).present, which counts attendance across
 * the WHOLE roster (or whole portal), completely bypassing attendanceReport()'s
 * own status/cell-group filter. A second, identical defect was found in the
 * same fix: the PDF's "congregation breakdown" (both Friday attendance and
 * Member Directory) called congregationCounts() unfiltered, for the same
 * reason.
 *
 * The fix: attendanceReport() now derives a per-session breakdown
 * (`bySession`) from the exact same filtered `members` list used to build
 * the per-member rows, and reports-pdf.js's congregation breakdown is
 * derived from the report's own already-filtered rows
 * (congregationBreakdownFor()), never a second, independently-scoped query.
 *
 * This file is the core invariant test requested: for any selected-status
 * population P, no per-Friday Present/Absent/Vacation/NotRecorded count may
 * exceed P, and a member outside the selected statuses must never appear in
 * any of this report's figures.
 */

const env = createIsolatedTestEnv('cciq-status-consistency-');

const { migrate } = await import('../db/migrate.js'); migrate();
const { seedRolesAndPermissions } = await import('../db/seed.js'); seedRolesAndPermissions();
const { ensureSettings } = await import('../lib/settings.js'); ensureSettings();
const { createMember } = await import('../services/members.js');
const { recordAttendance, attendanceReport, attendanceReportCsv } = await import('../services/attendance.js');
const { execute, default: db } = await import('../db/index.js');

function makeFridaySession(date) {
  const result = execute(
    `INSERT INTO attendance_sessions
       (service_date, service_type, title, status, counts_toward_followup, created_at)
     VALUES (@date, 'friday_service', 'Friday Service', 'held', 1, @date)`,
    { date }
  );
  return Number(result.lastInsertRowid);
}

// --- Fixture: exactly the population mix the bug report specified. ---
const bonafide = [
  createMember({ first_name: 'Bonafide', last_name: '1' }, { status: 'bonafide' }),
  createMember({ first_name: 'Bonafide', last_name: '2' }, { status: 'bonafide' }),
  createMember({ first_name: 'Bonafide', last_name: '3' }, { status: 'bonafide' })
];
const active = [
  createMember({ first_name: 'Active', last_name: '1' }, { status: 'active' }),
  createMember({ first_name: 'Active', last_name: '2' }, { status: 'active' }),
  createMember({ first_name: 'Active', last_name: '3' }, { status: 'active' }),
  createMember({ first_name: 'Active', last_name: '4' }, { status: 'active' })
];
const attendee = [
  createMember({ first_name: 'Attendee', last_name: '1' }, { status: 'attendee' }),
  createMember({ first_name: 'Attendee', last_name: '2' }, { status: 'attendee' })
];
const inactive = [
  createMember({ first_name: 'Inactive', last_name: '1' }, { status: 'inactive' }),
  createMember({ first_name: 'Inactive', last_name: '2' }, { status: 'inactive' })
];
const pending = createMember({ first_name: 'Pending', last_name: '1' }, { status: 'pending' });

const [b1, b2, b3] = bonafide;
const [a1, a2, a3, a4] = active;
const [t1, t2] = attendee;
const [i1, i2] = inactive;

const session1 = makeFridaySession('2026-01-02');
const session2 = makeFridaySession('2026-01-09');

// Session 1: only b1 present among Bonafide; b2 absent; b3 on Vacation.
// i1 (Inactive - NOT in any status selection tested below) also attends,
// specifically to prove an out-of-selection member never leaks into a
// filtered count.
recordAttendance(session1, [
  { memberId: b1.id, status: 'present' },
  { memberId: b2.id, status: 'absent' },
  { memberId: b3.id, status: 'excused' },
  { memberId: a1.id, status: 'present' },
  { memberId: a2.id, status: 'present' },
  { memberId: a3.id, status: 'absent' },
  { memberId: t1.id, status: 'present' },
  { memberId: t2.id, status: 'absent' },
  { memberId: i1.id, status: 'present' },
  { memberId: pending.id, status: 'present' }
  // a4, i2 not recorded for session 1.
]);

// Session 2: all three Bonafide present.
recordAttendance(session2, [
  { memberId: b1.id, status: 'present' },
  { memberId: b2.id, status: 'present' },
  { memberId: b3.id, status: 'present' },
  { memberId: a2.id, status: 'present' },
  { memberId: a3.id, status: 'present' },
  { memberId: a4.id, status: 'present' }
]);

// --- Phase 2C: these Fridays are now tracked and FINALIZED, so the report speaks the
//     canonical model (expected snapshot + outcomes). Without a tracking start date
//     a Friday is "not tracked" and produces no absence or rate at all - see
//     attendance-outcomes.js and tests/attendance-outcomes-consumers.mjs. The
//     filtering invariant this file protects is unchanged: no figure may exceed
//     the selected population, and nobody outside it may leak in. ---
{
  const { setSetting } = await import('../lib/settings.js');
  const { finalizeAttendance } = await import('../services/attendance-lifecycle.js');
  const plantAll = db.prepare('SELECT id, status FROM members').all();
  for (const m of plantAll) {
    db.prepare('DELETE FROM member_status_history WHERE member_id = ?').run(m.id);
    db.prepare('UPDATE members SET created_at = ? WHERE id = ?').run('2025-01-01T09:00:00.000Z', m.id);
    db.prepare('INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at) VALUES (?, NULL, ?, ?, ?)')
      .run(m.id, m.status, 'planted', '2025-01-01T09:00:00.000Z');
  }
  setSetting('attendance.tracking_start_date', '2026-01-02');
  for (const id of [session1, session2]) {
    const result = finalizeAttendance(id, { userId: null });
    assert.equal(result.ok, true, `fixture Friday ${id} finalizes: ${result.reason}`);
  }
}

function invariant(report, populationSize, label) {
  assert.equal(report.rows.length, populationSize, `${label}: Members Counted must be ${populationSize}`);
  for (const s of report.bySession) {
    assert.ok(s.present <= populationSize, `${label}: session ${s.date} present (${s.present}) must not exceed the selected population (${populationSize})`);
    assert.ok(s.absent <= populationSize, `${label}: session ${s.date} absent (${s.absent}) must not exceed the selected population`);
    assert.ok(s.excused <= populationSize, `${label}: session ${s.date} vacation (${s.excused}) must not exceed the selected population`);
    assert.ok(s.notRecorded <= populationSize, `${label}: session ${s.date} not-recorded (${s.notRecorded}) must not exceed the selected population`);
  }
  const totalPresentFromRows = report.rows.reduce((sum, r) => sum + r.present, 0);
  const totalPresentFromSessions = report.bySession.reduce((sum, s) => sum + s.present, 0);
  assert.equal(totalPresentFromRows, totalPresentFromSessions,
    `${label}: total present summed per-member must equal total present summed per-session (one source of truth)`);
}

// --- Bonafide only: Members Counted = 3, no Present > 3, graph/average use only those 3. ---
const bonafideOnly = attendanceReport({ from: '2026-01-01', to: '2026-01-31', statuses: ['bonafide'] });
invariant(bonafideOnly, 3, 'Bonafide only');
const bySessionMap = Object.fromEntries(bonafideOnly.bySession.map((s) => [s.date, s]));
assert.equal(bySessionMap['2026-01-02'].present, 1, 'Bonafide only, session 1: only b1 present (b2 absent, b3 on Vacation)');
assert.equal(bySessionMap['2026-01-02'].excused, 1, 'Bonafide only, session 1: b3 on Vacation must be counted');
assert.equal(bySessionMap['2026-01-09'].present, 3, 'Bonafide only, session 2: all three Bonafide present');
const totalPresent = bonafideOnly.rows.reduce((sum, r) => sum + r.present, 0);
const averagePresent = Math.round(totalPresent / bonafideOnly.sessions.length);
assert.equal(averagePresent, 2, 'Average present for Bonafide only must be computed from the 3-member population alone (4/2=2)');
console.log('PASS: Bonafide-only population reports only Bonafide members in every per-session figure — the exact reported scenario');

// The specific failure mode reported: an out-of-selection member (Inactive)
// attended session 1 and must not inflate the Bonafide-only present count.
assert.ok(bySessionMap['2026-01-02'].present < 5, 'an Inactive member attending must not leak into the Bonafide-only present count');
console.log('PASS: a member outside the selected statuses never appears in a filtered session\'s present count');

// --- Active + Bonafide: Members Counted = 7, every calculation uses those 7. ---
const activeBonafide = attendanceReport({ from: '2026-01-01', to: '2026-01-31', statuses: ['active', 'bonafide'] });
invariant(activeBonafide, 7, 'Active + Bonafide');
const abBySession = Object.fromEntries(activeBonafide.bySession.map((s) => [s.date, s]));
assert.equal(abBySession['2026-01-02'].present, 3, 'Active+Bonafide, session 1: a1, a2, b1 present = 3');
assert.equal(abBySession['2026-01-09'].present, 6, 'Active+Bonafide, session 2: a2,a3,a4,b1,b2,b3 present = 6');
console.log('PASS: Active + Bonafide combination reports exactly the 7-member combined population everywhere');

// --- Inactive only: all components use only the inactive population. ---
const inactiveOnly = attendanceReport({ from: '2026-01-01', to: '2026-01-31', statuses: ['inactive'] });
invariant(inactiveOnly, 2, 'Inactive only');
const ioBySession = Object.fromEntries(inactiveOnly.bySession.map((s) => [s.date, s]));
// Inactive members are not on the expected roster, so an Inactive attendee is HEADCOUNT
// ("unexpected"), never an expected member present - and never absent either.
assert.equal(ioBySession['2026-01-02'].present, 0, 'Inactive only, session 1: nobody expected, so no expected-member present');
assert.equal(ioBySession['2026-01-02'].unexpected, 1, 'Inactive only, session 1: i1 attended without being expected (headcount only)');
assert.equal(ioBySession['2026-01-02'].absent, 0, 'Inactive only: an unexpected member is never absent');
assert.equal(ioBySession['2026-01-09'].unexpected, 0, 'Inactive only, session 2: no inactive member recorded');
console.log('PASS: Inactive-only population reports only the two inactive members');

// --- Default roster statuses (no explicit statuses argument): existing
//     normal behaviour is unaffected by this fix. ---
const rosterDefault = attendanceReport({ from: '2026-01-01', to: '2026-01-31' });
invariant(rosterDefault, 10, 'Default roster (active+pending+attendee+bonafide)');
console.log('PASS: the default Friday roster (no statuses argument) still reports its normal 10-member population, unaffected by this fix');

// --- CSV output must match the same corrected population. ---
const { members: csvMembers } = attendanceReportCsv({ from: '2026-01-01', to: '2026-01-31', statuses: ['bonafide'] });
assert.equal(csvMembers, 3, 'CSV export must report exactly 3 members for Bonafide only, matching the on-screen/PDF population');
console.log('PASS: CSV export population matches the fixed Bonafide-only population exactly');

db.close();
env.cleanup();
console.log('ALL PASS');
