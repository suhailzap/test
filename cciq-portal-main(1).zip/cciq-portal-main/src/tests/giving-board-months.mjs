import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * The Giving Board on a phone or tablet: the dates are real commitments, so the month of every date must be obvious.
 *   - the markup is twelve month sections, each with its own heading and exactly its days;
 *   - up to 1100 px each month is its own block with its name ("JAN") above its date tiles, tiles are touch-sized, nothing scrolls sideways, and the sections do not overlap;
 *   - on a wide screen the month sections dissolve into the one continuous wall (thirty columns) exactly as before, with no sideways scroll;
 *   - a date a member taps leads to a page that names the FULL date, and every tile's accessible name is the full date.
 */

const f = await buildPortalFixture('cciq-gb-months-');
const { db, ids, users, mods } = f;
const year = db.prepare('SELECT year FROM ecaq_campaigns WHERE id = ?').get(ids.board).year;
const daysIn = (month) => new Date(Date.UTC(year, month, 0)).getUTCDate();
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const claimedDays = [3, 31, 45, 200]; // day-of-year positions: row 1, row 2, row 2, row 7 of the wall
for (const i of claimedDays) {
  const m = mods.members.createMember({ first_name: 'Note' + i, last_name: 'Holder' }, { status: 'active' });
  mods.ecaq.createClaim({ campaignId: ids.board, date: mods.ecaq.boardDates(year)[i], memberId: m.id, userId: users.churchAdmin.id });
}
const portal = await startPortal();
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const member = await signIn(portal.base, users.memberA.email, f.PASSWORD);
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);

  // ---- markup ----------------------------------------------------------------------------------------------------------------------------------------------------
  {
    const html = await (await member.get(`/projects/ecaq/board?year=${year}`)).text();
    const sections = html.match(/<section class="board-month"[\s\S]*?<\/section>/g) || [];
    assert.equal(sections.length, 12, 'twelve month sections');
    sections.forEach((section, i) => {
      assert.ok(new RegExp(`<h2 class="board-month__name" id="board-month-${i + 1}">[\\s\\S]*?${MONTHS[i]}`).test(section), `${MONTHS[i]} has its heading`);
      assert.equal((section.match(/<li class="stub/g) || []).length, daysIn(i + 1), `${MONTHS[i]} holds exactly its ${daysIn(i + 1)} days`);
    });
    const label = new RegExp(`aria-label="\\w+, 5 January ${year}, available"`);
    assert.match(html, label, 'a tile\'s accessible name is the full date');
    assert.match(html, new RegExp(`href="/projects/ecaq/board/claim\\?date=${year}-01-05"`));
    // the page a tap leads to names the full date
    const claim = await (await member.get(`/projects/ecaq/board/claim?date=${year}-01-05`)).text();
    assert.match(claim, new RegExp(`<h1>Take \\w+, 5 January ${year}</h1>`), 'the claim page names the full date');
    assert.match(claim, new RegExp(`<dd>\\w+, 5 January ${year}</dd>`));
  }

  // ---- layout in a real browser -------------------------------------------------------------------------------------------------------------------------------------
  const problems = [];
  for (const width of [320, 360, 390, 430, 600, 768, 820, 1024, 1280, 1440]) {
    const context = await browser.newContext({ viewport: { width, height: 900 } });
    await context.addCookies(member.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const page = await context.newPage();
    await page.goto(`${portal.base}/projects/ecaq/board?year=${year}`, { waitUntil: 'load' });
    const m = await page.evaluate(() => {
      const r = (el) => { const b = el.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height, right: b.right, bottom: b.bottom }; };
      const sections = [...document.querySelectorAll('.board-month')].map((s) => {
        const name = s.querySelector('.board-month__name'); const first = s.querySelector('.stub');
        const tiles = [...s.querySelectorAll('.stub')];
        return {
          display: getComputedStyle(s).display, rect: s.getBoundingClientRect().height > 0 ? r(s) : null,
          name: r(name), nameText: name.innerText.replace(/\s+/g, ' ').trim(), nameVisible: name.getBoundingClientRect().width > 4 && getComputedStyle(name).position !== 'absolute',
          firstTop: first.getBoundingClientRect().top, tiles: tiles.length,
          minTile: Math.min(...tiles.map((t) => Math.min(t.getBoundingClientRect().width, t.getBoundingClientRect().height))),
          dayFont: parseFloat(getComputedStyle(tiles[0].querySelector('.stub__day, .stub__paper, .stub__reveal') || tiles[0]).fontSize)
        };
      });
      const stubs = [...document.querySelectorAll('.stub')];
      const cols = new Set(stubs.slice(0, 60).map((s) => Math.round(s.getBoundingClientRect().left)));
      return { sections, overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, columns: cols.size, stubCount: stubs.length, wall: r(document.querySelector('.board-wall')) };
    });
    const tag = `${width}px`;
    if (m.overflow > 0) problems.push(`${tag}: sideways scroll ${m.overflow}px`);
    if (m.stubCount < 365) problems.push(`${tag}: only ${m.stubCount} tiles`);
    if (width <= 1100) {
      m.sections.forEach((s, i) => {
        if (!s.nameVisible) problems.push(`${tag}: ${MONTHS[i]} has no visible heading`);
        if (!/^[A-Z]{3}\b/i.test(s.nameText)) problems.push(`${tag}: heading "${s.nameText}"`);
        if (s.name.bottom > s.firstTop + 1) problems.push(`${tag}: ${MONTHS[i]}'s heading is not above its dates`);
        if (s.minTile < 40) problems.push(`${tag}: ${MONTHS[i]} tiles are ${Math.round(s.minTile)}px (touch targets are at least 40px)`);
        if (s.dayFont < 12) problems.push(`${tag}: day numbers are ${s.dayFont}px`);
        if (s.rect && s.rect.right > width + 1) problems.push(`${tag}: ${MONTHS[i]} runs past the screen`);
      });
      // no overlap: sections in the same row do not intersect
      for (let i = 0; i < m.sections.length; i += 1) {
        for (let j = i + 1; j < m.sections.length; j += 1) {
          const a = m.sections[i].rect; const b = m.sections[j].rect;
          if (a && b && a.x < b.right - 1 && b.x < a.right - 1 && a.y < b.bottom - 1 && b.y < a.bottom - 1) problems.push(`${tag}: ${MONTHS[i]} overlaps ${MONTHS[j]}`);
        }
      }
    } else {
      if (m.sections[0].display !== 'contents') problems.push(`${tag}: the wall should flow (display: contents), it is ${m.sections[0].display}`);
      if (m.columns !== 30) problems.push(`${tag}: ${m.columns} columns, expected the 30-column wall`);
      if (m.sections.some((s) => s.nameVisible)) problems.push(`${tag}: month headings should be visually hidden on the wall`);
    }
    await context.close();
  }
  assert.deepEqual(problems, [], problems.join('\n'));

  // ---- the note on a slip is readable wherever the slip is (desktop hover, keyboard focus, touch) ----------------------------------------------------------------------------------
  {
    const noteProblems = [];
    const fullDate = /^[A-Z][a-z]+day, \d{1,2} [A-Z][a-z]+ \d{4}/;
    for (const [who, label] of [[member, 'member'], [admin, 'admin']]) {
      for (const width of [1280, 1440]) {
        const context = await browser.newContext({ viewport: { width, height: 900 } });
        await context.addCookies(who.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
        const page = await context.newPage();
        await page.goto(portal.base + '/projects/ecaq/board?year=' + year, { waitUntil: 'load' });
        const probe = (index) => page.evaluate((i) => {
          const li = document.querySelectorAll('li.stub')[i]; const tip = li.querySelector('.stub__tip'); const topbar = document.querySelector('.topbar');
          if (!tip) return { none: true };
          const r = tip.getBoundingClientRect(); const cs = getComputedStyle(tip); const c = (e) => document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
          const before = tip.style.pointerEvents; tip.style.pointerEvents = 'auto'; /* (a plain note ignores the mouse; test what is painted on top of it) */ const hit = c(); tip.style.pointerEvents = before; const bar = topbar ? topbar.getBoundingClientRect() : { bottom: 0 };
          return { shown: cs.display !== 'none' && r.width > 0, x: r.x, y: r.y, right: r.right, bottom: r.bottom, vw: document.documentElement.clientWidth, vh: innerHeight, onTop: Boolean(hit && (tip === hit || tip.contains(hit))), hitInfo: hit ? hit.tagName + '.' + hit.className : 'none', underBar: r.y < bar.bottom - 1 && r.y >= 0, font: parseFloat(cs.fontSize), color: cs.color, bg: cs.backgroundColor, text: tip.innerText };
        }, index);
        for (const index of claimedDays) {
          const li = page.locator('li.stub').nth(index);
          await li.scrollIntoViewIfNeeded();
          await li.hover();
          await page.waitForTimeout(120);
          const m = await probe(index);
          const tag = label + ' ' + width + 'px slip ' + index;
          if (m.none || !m.shown) { noteProblems.push(tag + ': no note on hover'); continue; }
          if (!m.onTop) noteProblems.push(tag + ': the note is covered or clipped by ' + m.hitInfo);
          if (m.underBar) noteProblems.push(tag + ': the note runs under the top bar');
          if (m.x < 0 || m.y < 0 || m.right > m.vw + 1) noteProblems.push(tag + ': the note leaves the screen');
          if (m.font < 13) noteProblems.push(tag + ': text is ' + m.font + 'px');
          if (!fullDate.test(m.text)) noteProblems.push(tag + ': the note does not start with the full date ("' + m.text.slice(0, 40) + '")');
          if (!/Taken by|Given by|Note\d+ Holder/.test(m.text)) noteProblems.push(tag + ': no claimant or status in "' + m.text.replace(/\n/g, ' | ') + '"');
          if (label === 'admin' && !(/Commitment/.test(m.text) && /Received/.test(m.text) && /Balance/.test(m.text) && /Open commitment and payments/.test(m.text))) noteProblems.push(tag + ': the administrator card is missing figures or the link');
          if (label === 'member' && /Balance|Commitment/.test(m.text)) noteProblems.push(tag + ': a member is shown money detail');
          // the same information on keyboard focus
          await page.mouse.move(2, 2);
          await page.keyboard.press('Shift');
          await li.locator('button.stub__paper, button.stub__reveal').first().focus();
          const k = await probe(index);
          if (!k.shown) noteProblems.push(tag + ': keyboard focus shows no note');
          else if (k.text !== m.text) noteProblems.push(tag + ': keyboard focus shows different information');
          await page.mouse.move(2, 2); // the mouse takes over again: the keyboard card goes away
          await page.evaluate(() => document.activeElement && document.activeElement.blur());
        }
        await context.close();
      }
    }
    // touch: a tap opens the note (a sheet), fully on screen, without hover
    const touch = await browser.newContext({ viewport: { width: 390, height: 800 }, hasTouch: true, isMobile: true });
    await touch.addCookies(member.cookie.split('; ').map((p) => { const [name, ...rest] = p.split('='); return { name, value: rest.join('='), url: portal.base }; }));
    const tp = await touch.newPage();
    await tp.goto(portal.base + '/projects/ecaq/board?year=' + year, { waitUntil: 'load' });
    await tp.locator('li.stub').nth(31).locator('button.stub__paper').tap();
    const sheet = await tp.evaluate(() => { const tip = [...document.querySelectorAll('li.stub .stub__tip')].find((t) => getComputedStyle(t).display !== 'none'); if (!tip) return null; const r = tip.getBoundingClientRect(); return { x: r.x, right: r.right, bottom: r.bottom, vw: document.documentElement.clientWidth, vh: innerHeight, text: tip.innerText, font: parseFloat(getComputedStyle(tip).fontSize) }; });
    if (!sheet) noteProblems.push('touch: a tap shows no note');
    else {
      if (sheet.x < 0 || sheet.right > sheet.vw + 1 || sheet.bottom > sheet.vh + 1) noteProblems.push('touch: the note is not fully on screen');
      if (sheet.font < 13) noteProblems.push('touch: text is ' + sheet.font + 'px');
      if (!fullDate.test(sheet.text)) noteProblems.push('touch: no full date');
    }
    await touch.close();
    assert.deepEqual(noteProblems, [], noteProblems.join('\n'));
  }

  // ---- an administrator on a phone: the same month structure, and the free date leads to "Claim for a member" ------------------------------------------------------------
  {
    const html = await (await admin.get(`/projects/ecaq/board?year=${year}`)).text();
    assert.match(html, new RegExp(`href="/admin/ecaq/claims/new\\?date=${year}-01-06"`), 'an administrator\'s free date leads to claiming it for a member');
    assert.match(html, /Select to claim it for a member/);
    assert.match(html, /Claim for a member/);
  }
} finally {
  await portal.stop();
  await browser.close();
}
f.db.close();
f.env.cleanup();
console.log('PASS (markup) twelve month sections, each with its heading and exactly its days; every tile\'s name and the claim page carry the full date');
console.log('PASS (layout) 320, 360, 390, 430, 600, 768, 820 and 1024 px: month blocks with the month above the dates, touch-sized tiles, no overlap, no sideways scroll; 1280 and 1440 px: the one thirty-column wall');
console.log('PASS (notes) the note on a slip, on hover, on keyboard focus (the same information) and on a tap, is high-contrast, 13px or more, shows the full date and the claimant (and the money only to an administrator), is never cut off or under the top bar, on rows near the top as well as lower down');
console.log('ALL PASS');
