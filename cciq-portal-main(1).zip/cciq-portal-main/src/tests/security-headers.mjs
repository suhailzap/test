import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * What the portal tells a browser, and how it treats sessions, characterized for the way it is actually deployed: plain HTTP on a trusted
 * church network (so the cookie is NOT marked Secure, and that is stated here rather than assumed). Nothing in this file decides the open
 * policy questions (the wording of login failures, how long a lock-out lasts); it only pins today's behaviour so a change is deliberate.
 */

const f = await buildPortalFixture('cciq-security-headers-');
const { db, ids, users } = f;
const portal = await startPortal();

const headersOf = async (res) => Object.fromEntries([...res.headers.entries()].map(([k, v]) => [k.toLowerCase(), v]));
const csp = (h) => Object.fromEntries((h['content-security-policy'] || '').split(';').map((d) => d.trim()).filter(Boolean).map((d) => { const [name, ...vals] = d.split(/\s+/); return [name, vals]; }));

try {
  // ---- 1. response headers ---------------------------------------------------------------------------------------------------------------
  for (const [label, url] of [['sign-in page', '/login'], ['a static file', '/css/cciq.css'], ['a missing page', '/no-such-page'], ['health check', '/healthz']]) {
    const res = await fetch(`${portal.base}${url}`, { redirect: 'manual' }); await res.arrayBuffer();
    const h = await headersOf(res);
    assert.equal(h['x-content-type-options'], 'nosniff', `${label}: nosniff`);
    assert.equal(h['x-powered-by'], undefined, `${label}: the server does not announce its framework`);
    assert.equal(h['referrer-policy'], 'same-origin', `${label}: referrer stays on this site`);
    assert.equal(h['cross-origin-resource-policy'], 'same-origin', `${label}: other sites cannot embed its files`);
    assert.ok(h['content-security-policy'], `${label}: has a content security policy`);
    const policy = csp(h);
    assert.deepEqual(policy['frame-ancestors'], ["'none'"], `${label}: cannot be framed`);
    assert.deepEqual(policy['script-src'], ["'self'"], `${label}: scripts only from this site (no inline, no eval)`);
    assert.deepEqual(policy['object-src'], ["'none'"]); assert.deepEqual(policy['base-uri'], ["'self'"]); assert.deepEqual(policy['form-action'], ["'self'"]);
    assert.ok(!policy['upgrade-insecure-requests'], `${label}: plain-HTTP deployment: no upgrade-insecure-requests (documented choice)`);
    assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(h['content-security-policy'].replace(/img-src[^;]*data:/, '')), `${label}: no unsafe-inline, unsafe-eval or wildcard`);
    assert.equal(h['strict-transport-security'] === undefined || /max-age/.test(h['strict-transport-security']), true);
  }
  console.log('PASS (1) every response: nosniff, no framework banner, same-origin referrer and resource policy, a CSP with no inline script, eval, wildcard, framing or plugins');

  // ---- 2. the session cookie -----------------------------------------------------------------------------------------------------------
  {
    const page = await fetch(`${portal.base}/login`);
    const csrf = (await page.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    const pre = page.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
    const preAttrs = page.headers.getSetCookie().join(' | ');
    const login = await fetch(`${portal.base}/login`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Cookie: pre }, body: new URLSearchParams({ email: users.memberA.email, password: f.PASSWORD, _csrf: csrf }) });
    const set = login.headers.getSetCookie();
    assert.equal(login.status, 302);
    const cookie = set.find((c) => /^cciq\.sid|^connect\.sid|sid=/i.test(c)) || set[0];
    assert.match(cookie, /HttpOnly/i, 'the session cookie is HttpOnly');
    assert.match(cookie, /SameSite=(Lax|Strict)/i, 'and SameSite');
    assert.match(cookie, /Path=\//i);
    assert.ok(!/Secure/i.test(cookie), 'plain-HTTP deployment: the cookie is not marked Secure (a Secure cookie would never be sent over http://). If the portal is ever served over HTTPS this must become Secure.');
    assert.notEqual(cookie.split(';')[0], pre.split(';')[0], 'a NEW session id is issued at sign-in (no fixation)');
    const preAuthId = pre.split(';')[0];
    const fixation = await fetch(`${portal.base}/`, { headers: { Cookie: preAuthId }, redirect: 'manual' }); await fixation.arrayBuffer();
    assert.equal(fixation.status, 302, 'the pre-sign-in cookie is not a signed-in session');
    assert.ok(preAttrs.length >= 0);
    console.log('PASS (2) the session cookie is HttpOnly, SameSite, path /, not Secure (plain HTTP, stated); sign-in issues a fresh id and the old one stays signed out');
  }

  // ---- 3. two sessions, sign-out, change of password ---------------------------------------------------------------------------------------
  {
    const a = await signIn(portal.base, users.memberB.email, f.PASSWORD);
    const b = await signIn(portal.base, users.memberB.email, f.PASSWORD);
    assert.equal((await a.get('/my/profile')).status, 200, 'concurrent sessions: the first is valid'); assert.equal((await b.get('/my/profile')).status, 200, 'and the second');
    const out = await a.post('/logout', {}, { csrfFrom: '/my/profile' }); await out.text();
    assert.equal((await a.get('/my/profile')).status, 302, 'signing out ends that session');
    assert.equal((await b.get('/my/profile')).status, 200, 'and only that session (the other device is untouched)');
    const stale = await fetch(`${portal.base}/my/profile`, { headers: { Cookie: a.cookie }, redirect: 'manual' }); await stale.arrayBuffer();
    assert.equal(stale.status, 302, 'the signed-out cookie cannot be reused');
    console.log('PASS (3) two devices can be signed in at once; signing one out ends only that session and its cookie is dead');
  }

  // ---- 4. error pages ------------------------------------------------------------------------------------------------------------------------
  {
    const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
    for (const url of ['/members/0', '/members/99999999', '/members/abc', '/visitors/1e3', '/no/such/route', '/members?page=%00', '/attendance/sessions/-1']) {
      const res = await admin.get(url); const text = await res.text();
      assert.ok(res.status < 500, `${url} -> ${res.status}`);
      assert.doesNotMatch(text, /(\bat [A-Za-z]:\\|node_modules|\.js:\d+:\d+|SqliteError|SQLITE_|\bat \S+ \(|TypeError|ReferenceError)/, `${url}: no stack trace, path or SQL in the page`);
    }
    console.log('PASS (4) malformed addresses give a plain 404 or redirect, never a stack trace, path or SQL');
  }
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
