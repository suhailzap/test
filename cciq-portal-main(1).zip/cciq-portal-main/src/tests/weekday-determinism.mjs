import assert from 'node:assert/strict';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

/*
 * The date-sensitive suites must give the same answer on EVERY day of the week, including Friday (the service day), not only on whichever day the suite happens to be run.
 * Two of them once failed only on a Friday:
 *   returning-first-timer   the shared fixture's own First Timer has her first visit TODAY; on a Friday today is the current Friday, so she was counted in the test's Friday headcounts;
 *   browser-flows           the First Timer recorded through the form defaulted to a first visit TODAY; on a Friday that already is the Kiosk's Friday, so the Kiosk said
 *                           "Already checked in" and offered nothing to confirm (correct behaviour) where the test expected a Confirm button.
 * This suite runs them under a test clock (src/tests/lib/fake-clock.mjs: CCIQ_TEST_FAKE_DATE, in the test process, in every server it starts, and in the browser) on all seven weekdays
 * (browser-flows on a Friday, a Saturday and a Wednesday), and proves the clock itself does what it says. The application is not changed: only the date the test process believes it is.
 */

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.slice(1)), '..', '..');
const clock = pathToFileURL(path.join(root, 'src', 'tests', 'lib', 'fake-clock.mjs')).href; // --import wants a file URL on Windows
const run = (script, fake, timeout = 240000) => spawnSync(process.execPath, ['--import', clock, path.join(root, 'src', 'tests', script)], { encoding: 'utf8', timeout, env: { ...process.env, CCIQ_TEST_FAKE_DATE: fake } });
const WEEK = [['Sunday', '2026-10-04'], ['Monday', '2026-10-05'], ['Tuesday', '2026-10-06'], ['Wednesday', '2026-10-07'], ['Thursday', '2026-10-08'], ['Friday', '2026-10-09'], ['Saturday', '2026-10-10']];

{ // the clock itself
  for (const [name, date] of WEEK) {
    const r = spawnSync(process.execPath, ['--import', clock, path.join(root, 'src', 'tests', 'lib', 'clock-probe.mjs')], { encoding: 'utf8', env: { ...process.env, CCIQ_TEST_FAKE_DATE: date } });
    const [day, weekday] = r.stdout.trim().split(' ');
    assert.equal(day, date, `${name}: the process believes it is ${date}`); assert.equal(weekday, String(new Date(`${date}T12:00:00Z`).getUTCDay()), `${name} is the right weekday`);
  }
  assert.equal(new Date('2026-10-09T12:00:00Z').getUTCDay(), 5, 'the Friday in the table is a Friday');
  const real = spawnSync(process.execPath, ['--import', clock, path.join(root, 'src', 'tests', 'lib', 'clock-probe.mjs')], { encoding: 'utf8', env: { ...process.env, CCIQ_TEST_FAKE_DATE: '' } });
  assert.ok(Math.abs(Date.parse(real.stdout.trim().split(' ')[2]) - Date.now()) < 60000, 'without a fake date the real clock is left alone');
  const bad = spawnSync(process.execPath, ['--import', clock, path.join(root, 'src', 'tests', 'lib', 'clock-probe.mjs')], { encoding: 'utf8', env: { ...process.env, CCIQ_TEST_FAKE_DATE: 'tomorrow' } });
  assert.notEqual(bad.status, 0, 'a malformed fake date is refused');
  console.log('PASS (clock) the test clock puts a process on any chosen day, at noon in Qatar, with the clock still running; without it nothing changes; a bad value is refused');
}

{ // returning-first-timer on every weekday
  for (const [name, date] of WEEK) {
    const r = run('returning-first-timer.mjs', date);
    assert.equal(r.status, 0, `returning-first-timer fails on a ${name} (${date}):\n${(r.stdout + r.stderr).slice(-1500)}`);
  }
  console.log('PASS (returning-first-timer) passes on all seven weekdays, Friday included');
}

{ // browser-flows on a Friday and on two other days (a real browser; each run takes about 40 seconds)
  for (const [name, date] of [WEEK[5], WEEK[6], WEEK[3]]) {
    const r = run('browser-flows.mjs', date, 300000);
    assert.equal(r.status, 0, `browser-flows fails on a ${name} (${date}):\n${(r.stdout + r.stderr).slice(-1800)}`);
  }
  console.log('PASS (browser-flows) passes on a Friday, a Saturday and a Wednesday: the Kiosk\'s "already checked in" case and the confirm case are both exercised every day');
}
console.log('PASS weekday-determinism');
