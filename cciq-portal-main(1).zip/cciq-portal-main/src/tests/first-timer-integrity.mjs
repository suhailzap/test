import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';
import { checkInvariants } from '../lib/db-invariants.js';

/*
 * First Timers under the CURRENT semantics (no new policy): input validation, what can and cannot create rows, record-keeping
 * that stays consistent, counts that agree across every screen, and the pieces that must stay inert (markLapsedVisitors is never
 * called; no repeat-visit threshold, no promotion, no notification). Complements first-timer-workflow.mjs and mutation-atomicity.mjs.
 */

const f = await buildPortalFixture('cciq-ft-integrity-');
const { db, ids, users, mods } = f;
const today = mods.dates.today();
const visitorRows = () => db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
const visitRows = () => db.prepare('SELECT COUNT(*) n FROM visitor_visits').get().n;
const portal = await startPortal();
try {
  const admin = await signIn(portal.base, users.churchAdmin.email, f.PASSWORD);
  const token = await admin.csrf('/visitors/new');
  const post = async (url, fields) => { const r = await admin.post(url, fields, { csrf: token }); const text = await r.text(); return { status: r.status, text }; };

  // ---- creating: invalid input creates nothing ------------------------------------------------------------------------------------------
  const good = { first_name: 'Valid', last_name: 'Person', first_visit_date: today, duplicate_override: '1' };
  const bad = [
    ['no first name', { ...good, first_name: '' }],
    ['blank first name', { ...good, first_name: '   ' }],
    ['over-long name', { ...good, first_name: 'x'.repeat(81) }],
    ['over-long notes', { ...good, notes: 'n'.repeat(2001) }],
    ['impossible date', { ...good, first_visit_date: '2026-02-30' }],
    ['future date', { ...good, first_visit_date: mods.dates.addDays(today, 3) }],
    ['text date', { ...good, first_visit_date: 'yesterday' }],
    ['missing date', { ...good, first_visit_date: '' }],
    ['bad email', { ...good, email: 'not-an-email' }],
    ['bad congregation', { ...good, age_group: 'zzz' }],
    ['non-numeric inviter id', { ...good, invited_by_member_id: 'abc' }]
  ];
  for (const [what, fields] of bad) {
    const before = [visitorRows(), visitRows()];
    const r = await post('/visitors', fields);
    assert.ok(r.status === 400 || r.status === 200, `${what}: answered with the form again (${r.status})`);
    assert.deepEqual([visitorRows(), visitRows()], before, `${what}: creates no First Timer and no visit`);
  }
  // an inviter who does not exist must not be a server error
  const before = visitorRows();
  const ghost = await post('/visitors', { ...good, invited_by_member_id: '99999999' });
  assert.ok(ghost.status < 500, `a non-existent "invited by" member is not a server error (${ghost.status})`);
  assert.ok(visitorRows() - before <= 1, 'and at most the one record');
  console.log('PASS (validation) eleven kinds of bad input and a ghost inviter each create nothing (or one clean record) and never a server error');

  // ---- a good one is one visitor and one visit --------------------------------------------------------------------------------------------
  const b0 = [visitorRows(), visitRows()];
  const ok = await post('/visitors', { first_name: 'Nadia', last_name: 'Newcomer', phone: '+974 5550 4242', first_visit_date: today });
  assert.equal(ok.status, 302);
  assert.deepEqual([visitorRows() - b0[0], visitRows() - b0[1]], [1, 1], 'one First Timer and their first visit');
  const nadia = db.prepare("SELECT * FROM visitors WHERE first_name = 'Nadia'").get();
  assert.equal(nadia.state, 'new'); assert.equal(nadia.follow_up_state, 'new'); assert.equal(nadia.member_id, null);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members WHERE first_name = ?').get('Nadia').n, 0, 'registering a First Timer never creates a member');

  // ---- visits ------------------------------------------------------------------------------------------------------------------------------
  for (const [what, date] of [['a future date', mods.dates.addDays(today, 2)], ['an impossible date', '2026-13-40'], ['text', 'soon'], ['nothing', '']]) {
    const v0 = visitRows();
    await post(`/visitors/${nadia.id}/visits`, { visit_date: date });
    assert.equal(visitRows(), v0, `${what} is not recorded as a visit`);
  }
  const last = mods.dates.addDays(today, -7);
  await post(`/visitors/${nadia.id}/visits`, { visit_date: last });
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(nadia.id).state, 'returning', 'a second visit makes a person "came back"');
  await post(`/visitors/${nadia.id}/visits`, { visit_date: last });
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(nadia.id).n, 2, 'the same date twice is stored once');
  const ghostVisit = await post('/visitors/99999999/visits', { visit_date: today });
  assert.equal(ghostVisit.status, 404, 'a visit for a person who does not exist is a 404');

  // ---- outcomes: what the form allows, recorded honestly ---------------------------------------------------------------------------------
  const other = mods.visitors.createVisitor({ first_name: 'Outcome', last_name: 'Tester', first_visit_date: today }, { userId: users.churchAdmin.id });
  await post(`/visitors/${other.id}/state`, { state: 'nonsense' });
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(other.id).state, 'new', 'an unknown outcome is refused');
  // A decision can be recorded by hand; First visit / Came back cannot (they follow the visits), so a forged 'new' or 'returning' is refused.
  for (const state of ['declined', 'not_returned']) {
    await post(`/visitors/${other.id}/state`, { state });
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(other.id).state, state, `status "${state}" is recorded`);
  }
  for (const forgedState of ['returning', 'new']) {
    const refused = await post(`/visitors/${other.id}/state`, { state: forgedState });
    assert.equal(refused.status, 400, `a hand-chosen "${forgedState}" is refused`);
    assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(other.id).state, 'not_returned', 'and nothing changed');
  }
  await post(`/visitors/${other.id}/state`, { state: 'active' });
  assert.equal(db.prepare('SELECT state FROM visitors WHERE id = ?').get(other.id).state, 'new', 'Active hands the status back to the visits (one visit: First visit)');
  // "joined" is no longer something an administrator can type in: a forged post is refused (400) and nothing changes.
  const forged = await post(`/visitors/${other.id}/state`, { state: 'joined' });
  assert.equal(forged.status, 400, 'a forged "joined" outcome is a 400');
  assert.match(forged.text, /cannot be set as a status/i);
  assert.deepEqual(db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(other.id), { state: 'new', member_id: null }, 'and nothing changed');
  assert.ok(!checkInvariants(db).findings.some((x) => x.code === 'visitor.converted_without_member'), 'so no "joined without a member" row can be made');
  const stateForm = await (await admin.get(`/visitors/${other.id}`)).text();
  assert.doesNotMatch(stateForm, /<option value="joined"/, 'the status list does not offer "Became a member"');
  const stateSelect = /<select id="state"[\s\S]*?<\/select>/.exec(stateForm)?.[0] || '';
  assert.ok(stateSelect, 'the status control is present');
  assert.doesNotMatch(stateSelect, /<option value="(new|returning)"/, 'and does not offer First visit or Came back to be chosen by hand');
  for (const label of ['Active [(]follows their visits[)]', 'Has not returned', 'Not continuing']) assert.match(stateForm, new RegExp(label), `the explicit decision "${label}" is still offered`);
  assert.doesNotMatch(stateForm, /What happened/, 'the old Outcome "What happened" control is gone');
  const convertForm = await admin.get(`/visitors/${nadia.id}/convert`);
  const convertHtml = await convertForm.text();
  assert.equal(convertForm.status, 200);
  assert.match(convertHtml, new RegExp(`name="date_joined" value="${today}"`), 'the conversion form proposes today as the join date');
  const converted = await post(`/visitors/${nadia.id}/convert`, { first_name: 'Nadia', last_name: 'Newcomer', phone: '+974 5550 4242', date_joined: today, status: 'active' });
  assert.equal(converted.status, 302);
  const linked = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(nadia.id);
  assert.equal(linked.state, 'joined'); assert.ok(linked.member_id);
  const memberCount = db.prepare('SELECT COUNT(*) n FROM members').get().n;
  const again = await post(`/visitors/${nadia.id}/convert`, { first_name: 'Nadia', last_name: 'Newcomer' });
  assert.equal(again.status, 409, 'a second conversion is refused');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members').get().n, memberCount, 'a second conversion creates no second member');
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(linked.member_id);
  assert.equal(member.first_name, 'Nadia'); assert.equal(member.status, 'pending', 'the new member starts Pending even though the form posted "active"'); assert.equal(member.phone, '+974 5550 4242'); assert.equal(member.date_joined, today, 'joined today, not on the first visit date');
  const hist = db.prepare('SELECT COUNT(*) n FROM member_status_history WHERE member_id = ?').get(member.id).n;
  assert.ok(hist >= 1, 'the new member has a status history row');
  console.log('PASS (records) outcomes, visits and conversion behave as documented; "joined" cannot be typed in; the new member starts Pending, joined today, with a history row');

  // ---- counts agree across screens -----------------------------------------------------------------------------------------------------------
  for (let i = 0; i < 30; i += 1) mods.visitors.createVisitor({ first_name: `Count${i}`, last_name: 'Guest', first_visit_date: mods.dates.addDays(today, -(i % 5)) }, { userId: users.churchAdmin.id });
  const dbTotal = visitorRows();
  const counts = mods.visitors.visitorCounts();
  assert.equal(counts.total, dbTotal, 'visitorCounts() totals every First Timer');
  assert.equal(counts.new + counts.returning + counts.joined + counts.not_returned + counts.declined, dbTotal, 'and every First Timer is in exactly one state');
  const list = await (await admin.get('/visitors')).text();
  assert.match(list, new RegExp(`of ${dbTotal}\\b`), `the list reports all ${dbTotal}`);
  const page3 = await (await admin.get('/visitors?page=2&page_size=25')).text();
  assert.match(page3, new RegExp(`of ${dbTotal}\\b`), 'and so does page 2');
  for (const state of ['new', 'returning', 'joined']) {
    const screen = await (await admin.get(`/visitors?state=${state}`)).text();
    const total = Number((screen.match(/of (\d+)\b/) || [])[1] || (db.prepare('SELECT COUNT(*) n FROM visitors WHERE state = ?').get(state).n > 0 ? -1 : 0));
    assert.equal(total, db.prepare('SELECT COUNT(*) n FROM visitors WHERE state = ?').get(state).n, `the "${state}" filter counts what the database holds`);
  }
  const report = mods.visitors.firstTimersReportData();
  assert.ok(JSON.stringify(report).length > 10, 'the report data builds');
  console.log('PASS (counts) the list total, its filters, visitorCounts() and the database all agree, on every page');

  // ---- what must stay inert --------------------------------------------------------------------------------------------------------------------
  const srcRoot = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
  const callers = [];
  const walk = (dir) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) { if (e.name !== 'tests') walk(p); } else if (e.name.endsWith('.js') || e.name.endsWith('.ejs')) { if (fs.readFileSync(p, 'utf8').includes('markLapsedVisitors') && !p.endsWith(path.join('services', 'visitors.js'))) callers.push(path.relative(srcRoot, p)); } } };
  walk(srcRoot);
  for (const extra of ['../scripts', '../tools']) { const d = path.join(srcRoot, extra); if (fs.existsSync(d)) for (const e of fs.readdirSync(d)) { const p = path.join(d, e); if (fs.statSync(p).isFile() && fs.readFileSync(p, 'utf8').includes('markLapsedVisitors')) callers.push(`${extra}/${e}`); } }
  assert.deepEqual(callers, [], 'markLapsedVisitors() is defined but nothing calls it (it stays disabled until the owner decides)');
  const before2 = db.prepare("SELECT COUNT(*) n FROM visitors WHERE state = 'not_returned'").get().n;
  mods.reminders.generateReminders?.({});
  assert.equal(db.prepare("SELECT COUNT(*) n FROM visitors WHERE state = 'not_returned'").get().n, before2, 'generating reminders never marks anyone "not returned"');
  const types = db.prepare("SELECT DISTINCT reminder_type t FROM reminders").all().map((r) => r.t);
  assert.ok(!types.some((t) => /visit|first|timer/i.test(t)), `no reminder type is about First Timers (${types.join(', ')})`);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM notifications WHERE title LIKE '%first%timer%' OR title LIKE '%visitor%'").get().n, 0, 'and no notification was sent about one');
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  for (const p of ['/visitors', '/visitors/new', `/visitors/${nadia.id}`, '/visitors/follow-up']) {
    const r = await kiosk.get(p); await r.arrayBuffer();
    assert.ok(r.status === 403 || r.status === 302, `the Kiosk cannot open ${p} (${r.status})`);
  }
  console.log('PASS (inert) markLapsedVisitors() has no caller; generating reminders changes no First Timer; no First Timer reminder or notification exists; the Kiosk is shut out of every First Timer page');
} finally {
  await portal.stop();
}
f.db.close();
f.env.cleanup();
console.log('ALL PASS');
