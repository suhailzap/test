import assert from 'node:assert/strict';
import { buildPortalFixture, startPortal, signIn } from './lib/portal-fixture.mjs';

/*
 * A First Timer is a First Timer on their FIRST actual attendance. On later Fridays, before the church has reviewed their membership, they are the same person, found by the same record,
 * shown as "Returning · Review pending" - not as a First Timer again, not promoted to a member by attending, and not counted as a new First Timer in the Friday's figures.
 *   (the Sample Visitor scenario: he came as a First Timer, then on consecutive Fridays, and his review is not done)
 */

const f = await buildPortalFixture('cciq-returning-ft-');
const { db, ids, users, mods } = f;
const { addDays } = mods.dates;
// F3 is the Friday the portal treats as the current one (the last Friday on or before today, which IS today on a Friday); the label "First Timer" below is only true for a person
// whose first visit is on that Friday, so the test needs it to be the real current Friday on every weekday.
const F3 = mods.dates.lastFridayOnOrBefore(mods.dates.today());
const F2 = addDays(F3, -7);
const F1 = addDays(F3, -14);
const sessionOn = (date) => {
  db.prepare("INSERT OR IGNORE INTO attendance_sessions (service_date, service_type, title, status, counts_toward_followup, cell_group_id, created_at) VALUES (?, 'friday_service', 'Friday Service', 'held', 1, 0, ?)").run(date, new Date().toISOString());
  return db.prepare("SELECT id FROM attendance_sessions WHERE service_date = ? AND service_type = 'friday_service' AND cell_group_id = 0").get(date).id;
};
const s1 = sessionOn(F1); const s2 = sessionOn(F2); const s3 = sessionOn(F3);
// The shared fixture holds one First Timer of its own (Vera) whose first visit is TODAY. On a Friday today is F3, so she would be counted in this test's Friday headcounts and the
// figures would be off by one on Fridays only. These headcounts are about the test's own people, so the fixture's unrelated visitor is set aside before anything is counted.
db.prepare('DELETE FROM visitor_visits WHERE visitor_id = ?').run(ids.visitor);
const visitorCount = () => db.prepare('SELECT COUNT(*) n FROM visitors').get().n;
const headcount = (id) => mods.headcount.serviceHeadcount(id);
const labelOf = (term) => mods.attendance.searchPeopleForAttendance(term).find((p) => p.type === 'visitor');

const headcountModule = await import(new URL('../services/service-headcount.js', import.meta.url));
mods.headcount = headcountModule;

// Sample Visitor's lifecycle
const before = visitorCount();
const created = mods.visitors.createVisitor({ first_name: 'Sample Visitor', last_name: 'Example', phone: '+974 5550 4444', first_visit_date: F1 }, { userId: users.churchAdmin.id });
const isaiah = created.visitor || created;
const id = isaiah.id;
mods.visitors.recordVisit(id, { date: F1, sessionId: s1, userId: users.churchAdmin.id });
assert.equal(visitorCount(), before + 1, 'one record for one person');

// ---- 1. on the FIRST visit he is a First Timer ---------------------------------------------------------------------------------------------------------------
{
  // a visit on the very Friday a person is checked in to is not "earlier": with only F1 on file and F1 the Friday in question he is a First Timer.
  db.prepare('DELETE FROM visitor_visits WHERE visitor_id = ? AND visit_date > ?').run(id, F1);
  const h = headcount(s1);
  assert.deepEqual([h.firstTimers, h.returning, h.visitors, h.total], [1, 0, 1, 1], 'F1: First Timer 1, returning 0');
}

// ---- 2. later Fridays: the SAME person, now Returning ----------------------------------------------------------------------------------------------------------
mods.visitors.recordVisit(id, { date: F2, sessionId: s2, userId: users.churchAdmin.id });
mods.visitors.recordVisit(id, { date: F3, sessionId: s3, userId: users.churchAdmin.id });
{
  const h1 = headcount(s1); const h2 = headcount(s2); const h3 = headcount(s3);
  assert.deepEqual([h1.firstTimers, h1.returning, h1.total], [1, 0, 1], 'the first Friday still counts him as a First Timer');
  assert.deepEqual([h2.firstTimers, h2.returning, h2.total], [0, 1, 1], 'the second Friday does NOT add a First Timer: he is returning, and is still counted once among everyone present');
  assert.equal(h3.firstTimers, 0, 'nor the third');
  assert.equal(h3.returning, 1);
  assert.equal(h3.total, h3.members + 1, 'the total present still includes him');
  assert.deepEqual(h2.returningIds, [id]);
  assert.equal(visitorCount(), before + 1, 'visiting again never creates another First Timer record');
  const row = db.prepare('SELECT state, member_id FROM visitors WHERE id = ?').get(id);
  assert.equal(row.member_id, null, 'attending again never promotes him to a member');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM members WHERE first_name = ? AND last_name = ?').get('Sample Visitor', 'Example').n, 0, 'no member record was created');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM visitor_visits WHERE visitor_id = ?').get(id).n, 3, 'all three visits are kept');
}

// ---- 3. search: found by name and by whole number, labelled for what he is now -------------------------------------------------------------------------------------
{
  const byName = labelOf('Sample Visitor');
  assert.ok(byName, 'still found by name');
  assert.match(byName.detail, /^Returning · Review pending/, `"${byName.detail}"`);
  assert.equal(byName.returning, true);
  assert.ok(!/First Timer/.test(byName.detail), 'no longer called a First Timer');
  assert.equal(mods.attendance.searchPeopleForAttendance('Sample Visitor').filter((p) => p.type === 'visitor').length, 1, 'found once');
  const byPhone = mods.attendance.searchPeopleForAttendance('+974 5550 4444').find((p) => p.type === 'visitor');
  assert.match(byPhone.detail, /^Returning · Review pending/, 'the whole mobile number gives the same answer');
  // a brand-new person on their first visit is still a First Timer
  const fresh = mods.visitors.createVisitor({ first_name: 'Newly', last_name: 'Arrived', first_visit_date: F3 }, { userId: users.churchAdmin.id });
  const freshId = (fresh.visitor || fresh).id;
  mods.visitors.recordVisit(freshId, { date: F3, sessionId: s3, userId: users.churchAdmin.id });
  assert.match(labelOf('Newly').detail, /^First Timer/, 'someone on their first visit is a First Timer');
  const h3 = headcount(s3);
  assert.equal(h3.firstTimers, 1, 'only the newly arrived person is a First Timer on the third Friday');
  assert.equal(h3.returning, 1);
}

// ---- 4. the church decides: a declined or continued person is "Returning", not "Review pending" -----------------------------------------------------------------------
{
  mods.visitors.setVisitorState(id, 'declined', { userId: users.churchAdmin.id });
  assert.equal(labelOf('Sample Visitor').detail.startsWith('Returning · Review pending'), false, 'a declined person is not waiting for a review');
  assert.match(labelOf('Sample Visitor').detail, /^Returning/);
  mods.visitors.setVisitorState(id, 'active', { userId: users.churchAdmin.id });
  assert.match(labelOf('Sample Visitor').detail, /^Returning · Review pending/);
}

// ---- 5. screens: the kiosk search, the register tiles and the drill-down -------------------------------------------------------------------------------------------------
const portal = await startPortal();
try {
  const kiosk = await signIn(portal.base, users.kiosk.email, f.PASSWORD);
  const admin = await signIn(portal.base, users.superAdmin.email, f.PASSWORD);
  const kioskPage = await (await kiosk.get('/kiosk?q=Sample Visitor')).text();
  assert.match(kioskPage, /Sample Visitor/);
  assert.match(kioskPage, /Returning &middot; Review pending|Returning · Review pending/, 'the kiosk result says what he is');
  assert.ok(!/Sample Visitor[\s\S]{0,200}First Timer/.test(kioskPage), 'and does not call him a First Timer');
  const kioskHome = await (await kiosk.get('/kiosk')).text();
  assert.match(kioskHome, /Returning &middot; Review pending/, 'the explanation on the search page matches');
  assert.ok(!/Returning First Timers appear in the results too/.test(kioskHome), 'the old wording is gone');

  const register = await (await admin.get(`/attendance/sessions/${s2}`)).text();
  assert.match(register, /<p class="stat__label">Returning<\/p>\s*<p class="stat__value">1<\/p>/, 'the register shows one Returning');
  assert.match(register, /<p class="stat__label">First Timers<\/p>\s*<p class="stat__value">0<\/p>/, 'and no First Timer');
  const drill = await admin.get(`/attendance/sessions/${s2}/people?metric=returning`);
  const drillHtml = await drill.text();
  assert.equal(drill.status, 200);
  assert.match(drillHtml, /Sample Visitor/);
  assert.match(drillHtml, /Returning/);
  const first = await (await admin.get(`/attendance/sessions/${s2}/people?metric=first_timers`)).text();
  assert.ok(!/Sample Visitor/.test(first), 'he is not in the First Timers list of the second Friday');
  const firstFriday = await (await admin.get(`/attendance/sessions/${s1}/people?metric=first_timers`)).text();
  assert.match(firstFriday, /Sample Visitor/, 'he is in the First Timers list of his first Friday');
  const total = await (await admin.get(`/attendance/sessions/${s2}/people?metric=total`)).text();
  assert.match(total, /Sample Visitor/, 'the total present includes him');
  const history = await (await admin.get('/attendance/history')).text();
  assert.match(history, />Returning</, 'the history has a Returning column');
} finally {
  await portal.stop();
}

// ---- 6. when the review is finally done, nothing in the past moves ---------------------------------------------------------------------------------------------------------------
{
  const linkTo = ids.member.free;
  const snapshot = () => JSON.stringify([s1, s2, s3].map((s) => { const h = headcount(s); return [h.firstTimers, h.returning, h.total]; }));
  const beforeLink = snapshot();
  const visitsBefore = db.prepare('SELECT visit_date FROM visitor_visits WHERE visitor_id = ? ORDER BY visit_date').all(id);
  const linked = mods.visitors.linkVisitorToMember(id, linkTo, { userId: users.churchAdmin.id });
  assert.ok(linked.ok !== false, 'the administrator links him to a member record');
  assert.equal(snapshot(), beforeLink, 'linking him later moves nobody in or out of any past Friday');
  assert.deepEqual(db.prepare('SELECT visit_date FROM visitor_visits WHERE visitor_id = ? ORDER BY visit_date').all(id), visitsBefore, 'every visit is preserved');
  assert.equal(visitorCount(), before + 2, 'still one record per person (the two First Timers made above)');
}

f.db.close();
f.env.cleanup();
console.log('PASS (Sample Visitor) first visit = First Timer; later visits = the same person, Returning · Review pending, counted once in everyone present and never again as a First Timer; no second record, no automatic member');
console.log('PASS (search) found by name and by whole mobile number with the right label; a brand-new person is still a First Timer; a declined person is Returning without "Review pending"');
console.log('PASS (screens) kiosk result and explanation, register tiles, drill-down lists and history show First Timers and Returning separately; the total includes both');
console.log('PASS (review done later) linking him to a member moves no past headcount and keeps every visit');
console.log('ALL PASS');
