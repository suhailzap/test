/*
 * A form field named once arrives as text; named twice it arrives as a list (?name=a&name=b, or a hand-made POST). Forms here only
 * expect a list where several boxes share one name; everywhere else a list reaching code that calls .trim(), .charAt() or binds it
 * to SQL is a server error waiting for a crafted request. The one idiom that legitimately repeats a scalar name is a hidden "0"
 * beside a checkbox "1", where the last value is the one the person chose - so for every other field the last value wins.
 * (Multipart bodies are read later, by the upload parser, and their routes read named fields.)
 */
const LISTS = new Set(['roles', 'permissions', 'person', 'date_columns']);

export function collapseRepeatedFields(req, _res, next) {
  const body = req.body;
  if (body && typeof body === 'object' && !Array.isArray(body) && /urlencoded/i.test(req.headers['content-type'] || '')) {
    for (const [key, value] of Object.entries(body)) {
      if (Array.isArray(value) && !LISTS.has(key)) body[key] = value[value.length - 1];
    }
  }
  next();
}
