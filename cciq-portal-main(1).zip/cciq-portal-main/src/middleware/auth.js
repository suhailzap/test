import { loadUserContext } from '../services/users.js';
import { recordAudit, AUDIT } from '../lib/audit.js';
import config from '../config/env.js';
import { safeRedirect } from '../lib/validate.js';
import { isKioskOnlySession, applySessionCookiePolicy, KIOSK_ABSOLUTE_MS } from '../lib/session-policy.js';
import { searchPlaceholder } from '../lib/search-scope.js';

const IDLE_MS = config.session.idleTimeoutMinutes * 60 * 1000;

/*
 * The no-idle-timeout exception is tied to what the session actually IS —
 * the dedicated Attendance Kiosk identity — never to a permission a session
 * merely happens to hold. `attendance.checkin` is also granted to
 * super_admin, church_admin and cell_group_leader (so they can staff the
 * kiosk screen too), and none of those should ever be exempted from the
 * normal idle timeout just because that grant exists. Checking the role set
 * itself, and requiring it to be exactly `kiosk` and nothing else, is what
 * keeps a privileged account from ever landing in the exemption by
 * accident — see CCIQ_DECISIONS.md.
 */

/**
 * Rebuilds the user context on every request and enforces the idle timeout —
 * except for a session authenticated only as the dedicated Attendance Kiosk
 * identity, which is exempt from the idle timeout (see isKioskOnlySession)
 * but still bounded by a long, deliberate absolute lifetime from its own
 * login. Authorisation always derives from the database, never from the
 * cookie, so this re-evaluates every request rather than trusting whatever
 * was true when the session began.
 */
export function attachUser(req, res, next) {
  res.locals.user = null;
  res.locals.currentPath = req.path;

  if (!req.session?.userId) return next();

  const user = loadUserContext(req.session.userId);
  if (!user) {
    return req.session.destroy(() => {
      res.clearCookie(config.session.name);
      res.redirect('/login');
    });
  }

  /*
   * A security event - a password change/reset, a deactivation, OR a
   * reactivation - must invalidate every session issued before it, with no
   * gap a race can slip through: not a stale device that never made a
   * request during a since-reversed deactivation window, not a login whose
   * password check began before a concurrent reset and finished after, and
   * not a session row resurrected by an unrelated in-flight request's own
   * end-of-response save racing a delete (express-session's
   * SqliteSessionStore.set() is an upsert, so a delete can be undone by a
   * save that was already in flight). destroySessionsForUser() closes the
   * first two; this closes the third and is the only check that can,
   * because it runs on every request against the live value rather than
   * trying to delete every possible stale row once.
   *
   * R03 (Codex/independent verification): the previous version of this
   * check compared password_hash alone, which only ever moves on a
   * credential change - a deactivate-then-reactivate cycle left it
   * completely unchanged, so a session resurrected by the exact race
   * described above stayed valid straight through it. security_generation
   * (see setPassword()/setUserStatus() in services/users.js and migration
   * 0028) is a monotonic counter that advances on ALL of these events, in
   * both directions of a status change, and is never decremented -
   * closing that gap for ordinary and kiosk sessions alike, since both
   * authenticate through this same middleware.
   *
   * R03 FINAL LEGACY-SESSION CORRECTION (Codex/independent verification):
   * this used to read `req.session.securityGeneration && ... !== ...`,
   * exempting any session with no captured generation at all from the
   * comparison entirely - meant to spare a session that predated this
   * check's original deployment from being force-logged-out. That exemption
   * itself became the gap: a session with no securityGeneration is
   * authenticated (has a userId) but carries no proof it reflects the
   * user's current security state, and destroySessionsForUser()'s deletes
   * can be undone by an unrelated in-flight request's own end-of-response
   * save (the same upsert race this check exists to close in the first
   * place - see setPassword() in services/users.js and the self-password-
   * change route in routes/auth.js) - resurrecting exactly the kind of
   * session this exemption then let straight through. Now that production
   * and development are on separate, independently deployed databases (no
   * pre-this-feature session data to preserve), the invariant is simply:
   * every authenticated session must carry a securityGeneration matching
   * the user's current one, full stop. A missing value is never silently
   * adopted as current - only a fresh login captures it.
   */
  if (typeof req.session.securityGeneration !== 'number' || req.session.securityGeneration !== user.securityGeneration) {
    return req.session.destroy(() => {
      res.clearCookie(config.session.name);
      res.redirect('/login');
    });
  }

  const kioskOnly = isKioskOnlySession(user);

  if (kioskOnly) {
    // A session that predates this exemption (or was never given a login
    // timestamp for any other reason) gets a fresh absolute window starting
    // now, rather than being treated as already expired.
    if (!req.session.loginAt) req.session.loginAt = Date.now();
    if (Date.now() - req.session.loginAt >= KIOSK_ABSOLUTE_MS) {
      return req.session.destroy(() => {
        res.clearCookie(config.session.name);
        res.redirect('/login');
      });
    }
    // The cookie policy below gives both the persistent cookie and store
    // the remaining absolute lifetime, never a fresh 30 days per request.
  } else {
    const lastSeen = req.session.lastSeenAt || 0;
    if (lastSeen && Date.now() - lastSeen > IDLE_MS) {
      return req.session.destroy(() => {
        res.clearCookie(config.session.name);
        res.redirect('/login?timeout=1');
      });
    }
  }

  applySessionCookiePolicy(req.session, user);
  // An unattended counter refresh must not keep an administrator signed in.
  if (!(req.method === 'GET' && req.path === '/kiosk/count')) {
    req.session.lastSeenAt = Date.now();
  }
  req.user = user;
  res.locals.user = user;
  res.locals.searchPlaceholder = searchPlaceholder(user); // what THIS person can search, in the top-bar box

  /*
   * A password reset only means something if it is actually enforced, not
   * just offered as the page a person lands on right after signing in. This
   * runs on every request, so choosing not to follow that first redirect —
   * a bookmark, a typed URL, a link from an old tab — leads to the same
   * place regardless. Only what is needed to complete the change itself, and
   * the page's own assets, stay reachable.
   */
  if (user.mustChangePassword) {
    const allowed = req.path === '/account/password'
      || req.path === '/logout'
      || req.path.startsWith('/css/')
      || req.path.startsWith('/js/')
      || req.path.startsWith('/branding/');
    if (!allowed) {
      return res.redirect('/account/password');
    }
  }

  /*
   * `attendance.checkin` already blocks a kiosk-only account from every
   * route that checks a permission it doesn't hold — but a handful of
   * routes (the dashboard's own redirect aside) are reachable to anyone
   * merely signed in, with no permission check of their own. Knowing the
   * URL for one of those must not turn a reception terminal into a way to
   * browse the rest of the portal, so a kiosk-only session is confined to
   * exactly the screens and endpoints its own interface actually uses;
   * anything else redirects back to the kiosk home. This is a narrower,
   * additional check on top of — never a replacement for — the permission
   * system itself.
   */
  if (kioskOnly) {
    const allowed = req.path === '/kiosk'
      || req.path === '/kiosk/count'
      || req.path.startsWith('/attendance/checkin')
      || req.path === '/quick-access/info'
      || req.path === '/quick-access/card.png'
      || req.path === '/account/password'
      || req.path === '/logout'
      || req.path === '/help' // the guide: src/routes/help.js gives a reception session the reception chapters only
      || req.path.startsWith('/help/')
      || req.path.startsWith('/media/members/')
      || req.path.startsWith('/css/')
      || req.path.startsWith('/js/')
      || req.path.startsWith('/branding/');
    if (!allowed) {
      return res.redirect('/kiosk');
    }
  }

  return next();
}

export function requireAuth(req, res, next) {
  if (req.user) return next();
  const nextPath = safeRedirect(req.originalUrl, '/');
  return res.redirect(`/login?next=${encodeURIComponent(nextPath)}`);
}

export function requireGuest(req, res, next) {
  if (req.user) return res.redirect('/');
  return next();
}

function deny(req, res, next, permission) {
  recordAudit({
    req,
    action: AUDIT.ACCESS_DENIED,
    entityType: 'route',
    entityId: req.baseUrl + req.path, // the path only: a query string can carry what someone typed into a search box (a phone number, a name)
    result: 'denied',
    detail: { permission }
  });
  const err = new Error('You do not have access to this area of the portal.');
  err.status = 403;
  return next(err);
}

/*
 * WHO MAY OPERATE THE CHECK-IN / ATTENDANCE KIOSK INTERFACE. This is not the same thing as holding an attendance permission: a Cell Group leader holds attendance.record and
 * attendance.checkin because they take attendance for their own group, but the Kiosk interface searches EVERYONE on file (by name, member ID or whole mobile number, any status),
 * checks anyone in, registers First Timers and shows member photos regardless of scope. That is operational functionality for exactly three kinds of sign-in: the dedicated
 * Kiosk account, the Church Admin and the Super Admin. A Cell Group leader or a Member, whatever permissions they hold, is refused every route of it, by the server.
 */
export const CHECKIN_OPERATOR_ROLES = ['kiosk', 'church_admin', 'super_admin'];
export const isCheckinOperator = (user) => Boolean(user) && CHECKIN_OPERATOR_ROLES.some((role) => user.hasRole(role));

export function requireCheckinOperator(req, res, next) {
  if (!req.user) return requireAuth(req, res, next);
  if (!isCheckinOperator(req.user)) return deny(req, res, next, 'check-in operator');
  return next();
}

/** Permission to take attendance AND the standing to operate the check-in interface: the guard on every /kiosk and /attendance/checkin route. */
export const checkinAccess = [
  (req, res, next) => (!req.user ? requireAuth(req, res, next) : (['attendance.record', 'attendance.checkin'].some((p) => req.user.can(p)) ? next() : deny(req, res, next, 'attendance.checkin'))),
  requireCheckinOperator
];

/** Requires every listed permission. */
export function requirePermission(...permissions) {
  return (req, res, next) => {
    if (!req.user) return requireAuth(req, res, next);
    const missing = permissions.find((p) => !req.user.can(p));
    if (missing) return deny(req, res, next, missing);
    return next();
  };
}

/** Requires at least one of the listed permissions. */
export function requireAnyPermission(...permissions) {
  return (req, res, next) => {
    if (!req.user) return requireAuth(req, res, next);
    if (permissions.some((p) => req.user.can(p))) return next();
    return deny(req, res, next, permissions.join(' or '));
  };
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return requireAuth(req, res, next);
    if (roles.some((r) => req.user.hasRole(r))) return next();
    return deny(req, res, next, `role:${roles.join('|')}`);
  };
}
