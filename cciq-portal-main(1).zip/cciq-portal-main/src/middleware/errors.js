import crypto from 'node:crypto';
import { getSetting } from '../lib/settings.js';
import { isKioskOnlySession } from '../lib/session-policy.js';
import { loadUserContext } from '../services/users.js';
import { recordAudit } from '../lib/audit.js';

/** Simple session-backed flash messages. */
export function flashMessages(req, res, next) {
  res.locals.flash = req.session?.flash || null;
  if (req.session?.flash) delete req.session.flash;

  req.flash = (type, message) => {
    if (req.session) req.session.flash = { type, message };
  };
  next();
}

export function notFound(req, res, next) {
  const err = new Error('That page does not exist, or it has moved.');
  err.status = 404;
  next(err);
}

/**
 * The full layout needs a signed-in user for its navigation and header, so an
 * error reaching a signed-out visitor uses the plain layout instead. Without
 * this, a 404 on a public URL would fail while rendering its own error page.
 */
function renderError(res, req, status, view) {
  // Some errors are raised before the layout and the shared template values are installed (a rejected CSRF token is the
  // common one: it fires ahead of them). res.render is not yet the layout-aware one then, so the page would reach the
  // browser as an unstyled fragment. The error page therefore assembles its own layout and carries its own fallbacks.
  const navigationReady = Boolean(req.user && res.locals.navigation && res.locals.church);
  // A reception terminal never sees the administrative shell, not even on an error page: it gets its own layout and a way back to the kiosk.
  let kioskUser = navigationReady && isKioskOnlySession(req.user) ? req.user : null;
  // A refusal that fires before the signed-in person is attached (a rejected CSRF token) must not drop a Kiosk onto the plain page with a
  // link to a dashboard it cannot open: the session is read here, and a reception terminal still gets its own layout.
  if (!navigationReady && !kioskUser && req.session?.userId) {
    try {
      const loaded = loadUserContext(req.session.userId);
      if (loaded && isKioskOnlySession(loaded)) kioskUser = loaded;
    } catch { /* a failure to look the person up leaves the plain page */ }
  }
  const kiosk = Boolean(kioskUser);
  const layout = kiosk ? 'kiosk' : navigationReady ? 'app' : 'plain';
  const locals = {
    ...res.app.locals,
    ...res.locals,
    ...view,
    layout,
    ...(kioskUser && !res.locals.user ? { user: kioskUser } : {}),
    homeHref: kiosk ? '/kiosk' : '/',
    homeLabel: kiosk ? 'Back to the kiosk' : 'Back to dashboard',
    church: res.locals.church || {
      name: getSetting('church.display_name'),
      shortName: getSetting('church.short_name'),
      logoSmall: getSetting('branding.logo_small_path') || getSetting('branding.logo_path')
    },
    assetVersion: res.locals.assetVersion || '',
    csrfToken: res.locals.csrfToken || ''
  };
  return new Promise((resolve) => {
    res.app.render('errors/error', locals, (renderErr, body) => {
      if (renderErr) return resolve(renderErr);
      return res.app.render(`layouts/${layout}`, { ...locals, body }, (layoutErr, html) => {
        if (layoutErr) return resolve(layoutErr);
        res.status(status).send(html);
        return resolve(null);
      });
    });
  });
}

/**
 * Users see a plain explanation. Stack traces, SQL and internal details are
 * logged server-side against a reference code instead of being rendered.
 */
/**
 * A database constraint that a form could only trip with values the page never offered (a forged or stale id, a value outside a
 * fixed list) is a bad request, not a server fault. The surrounding transaction has already rolled back, so nothing is half-written.
 */
const CONSTRAINT_MESSAGES = {
  SQLITE_CONSTRAINT_FOREIGNKEY: [400, 'A record this form refers to no longer exists. Go back, reload the page and try again.'],
  SQLITE_CONSTRAINT_CHECK: [400, 'One of the values is not one the form offers. Go back, reload the page and try again.'],
  SQLITE_CONSTRAINT_NOTNULL: [400, 'A required value is missing. Go back and complete the form.'],
  SQLITE_CONSTRAINT_UNIQUE: [409, 'That already exists. Go back and check before adding it again.']
};

/** Our own guard triggers (migration 0030) refuse an inconsistent First Timer / member link. Any OTHER trigger failure stays a server error. */
const isLinkGuard = (err) => err.code === 'SQLITE_CONSTRAINT_TRIGGER'
  && /^(A First Timer is "joined" if and only if|This member is linked from a First Timer record)/.test(String(err.message));
const LINK_GUARD_MESSAGE = [409, 'That change is not allowed because it would leave the First Timer and member records inconsistent. Go back, reload the page and check before trying again.'];

export function errorHandler(err, req, res, _next) {
  const constraint = !err.status && (isLinkGuard(err) ? LINK_GUARD_MESSAGE : CONSTRAINT_MESSAGES[err.code]);
  if (constraint) { err = Object.assign(new Error(constraint[1]), { status: constraint[0] }); } // eslint-disable-line no-param-reassign
  const status = err.status && err.status >= 400 && err.status < 600 ? err.status : 500;
  const reference = crypto.randomBytes(4).toString('hex');

  if (status >= 500) {
    // The stack trace is server-log-only, never sent to the client (see the
    // doc comment above) — so there is no reason to also drop it from the
    // production log, where it is the main thing that makes a reference code
    // actionable. This previously suppressed it in production specifically,
    // the one place a real incident needs it most.
    console.error(`[error ${reference}]`, {
      path: req.originalUrl.split('?')[0], // never the query string, which can hold what someone typed into a search box
      userId: req.user?.id || null,
      message: err.message,
      stack: err.stack
    });
    // The console line is lost when the process restarts, and the reference on the error page is all a person has to quote. Keep a durable, stack-free
    // record the administrator can find by that reference (Audit log, action system.error; no stack, no query string, and no database error text). Best effort: it must never turn one failure into another.
    // Not when the database itself is busy or locked: the write would only wait out another busy timeout on top of the one that just failed the request.
    if (!/^SQLITE_(BUSY|LOCKED)/.test(String(err.code || ''))) try {
      recordAudit({
        req, userId: req.user?.id || null, action: 'system.error', entityType: 'request', entityId: reference, result: 'failure',
        detail: { reference, method: req.method, path: req.originalUrl.split('?')[0], status, code: String(err.code || '').startsWith('SQLITE') ? 'database' : (err.code || null), message: String(err.code || '').startsWith('SQLITE') ? null : String(err.message || '').slice(0, 300) }
      });
    } catch (auditErr) {
      console.error(`[error ${reference}] could not be recorded in the audit log:`, auditErr.message);
    }
  }

  const heading = status === 403
    ? 'Access not permitted'
    : status === 404
      ? 'Page not found'
      : status === 403 ? 'Access not permitted' : 'Something went wrong';

  const message = status < 500
    ? err.message || 'That request could not be completed.'
    : 'The portal could not complete that request. Try again, and contact your administrator if it continues.';

  if (req.accepts(['html', 'json']) === 'json') {
    return res.status(status).json({ error: message, reference: status >= 500 ? reference : undefined });
  }

  // If the error page itself cannot render, fall back to plain text rather than
  // letting the framework's default handler print internals to the browser.
  return renderError(res, req, status, {
    title: heading,
    status,
    heading,
    message,
    reference: status >= 500 ? reference : null
  }).then((renderErr) => {
    if (!renderErr) return undefined;
    console.error(`[error ${reference}] the error page failed to render:`, renderErr.message);
    if (res.headersSent) return undefined;
    res.type('text/plain');
    return res.status(status).send(`${heading}\n\n${message}${status >= 500 ? `\n\nReference ${reference}` : ''}\n`);
  });
}
