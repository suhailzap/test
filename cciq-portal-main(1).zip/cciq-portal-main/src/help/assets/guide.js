document.getElementById('print').addEventListener('click',()=>window.print());
const contents=document.getElementById('contents');
if(window.matchMedia('(max-width:720px)').matches) contents.open=false;
window.addEventListener('beforeprint',()=>{contents.dataset.wasOpen=String(contents.open);contents.open=true;});
window.addEventListener('afterprint',()=>{contents.open=contents.dataset.wasOpen!=='false';});
const links=[...document.querySelectorAll('nav a')];
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){links.forEach(a=>a.classList.toggle('active',a.hash==='#'+e.target.id));}});},{rootMargin:'-110px 0px -65% 0px'});document.querySelectorAll('.chapter').forEach(s=>observer.observe(s));}

// Index rendered guide content: no fetch, network, storage or external library.
const queryInput=document.getElementById('guide-query');
const resultsList=document.getElementById('search-results');
const searchStatus=document.getElementById('search-status');
const searchIndex=[];
const cleanText=node=>node.textContent.replace(/\s+/g,' ').trim();
document.querySelectorAll('.chapter').forEach(chapter=>{
  const title=cleanText(chapter.querySelector('h2'));
  let group={title,heading:'',target:chapter.id,parts:[]};
  searchIndex.push(group);
  chapter.querySelectorAll('h3,p,li,tr,label').forEach((node,i)=>{
    if(node.tagName==='H3'){
      node.id=node.id||chapter.id+'-topic-'+i;
      node.tabIndex=-1;
      group={title,heading:cleanText(node),target:node.id,parts:[]};
      searchIndex.push(group);
    }else if(!node.closest('figure') && !(node.tagName==='P' && node.closest('li,label'))){
      const text=cleanText(node);if(text)group.parts.push(text);
    }
  });
  chapter.tabIndex=-1;
});
function highlighted(text,term){
  const fragment=document.createDocumentFragment();
  const lower=text.toLowerCase(), needle=term.toLowerCase();
  let start=0,pos;
  while((pos=lower.indexOf(needle,start))!==-1){
    fragment.append(document.createTextNode(text.slice(start,pos)));
    const mark=document.createElement('mark');mark.textContent=text.slice(pos,pos+term.length);
    fragment.append(mark);start=pos+term.length;
  }
  fragment.append(document.createTextNode(text.slice(start)));return fragment;
}
function runGuideSearch(){
  const term=queryInput.value.trim().replace(/\s+/g,' ');
  resultsList.replaceChildren();resultsList.hidden=!term;
  if(!term){searchStatus.textContent='Find a topic, task or phrase. Search works offline.';return;}
  const needle=term.toLowerCase();
  const matches=searchIndex.map(item=>{
    const headingMatch=item.heading.toLowerCase().includes(needle);
    const titleMatch=item.title.toLowerCase().includes(needle);
    const part=item.parts.find(text=>text.toLowerCase().includes(needle));
    return {item,part,score:headingMatch?3:titleMatch?2:part?1:0};
  }).filter(match=>match.score).sort((a,b)=>b.score-a.score);
  searchStatus.textContent=matches.length?matches.length+' matching section'+(matches.length===1?'':'s')+'. Select a result to jump to it.':'No matching sections. Try another word or a shorter phrase.';
  matches.forEach(({item,part})=>{
    const row=document.createElement('li'),link=document.createElement('a');
    link.href='#'+item.target;
    const heading=document.createElement('strong');
    heading.append(highlighted(item.title+(item.heading?' → '+item.heading:''),term));link.append(heading);
    const text=part||item.parts[0]||item.heading||item.title;
    const pos=text.toLowerCase().indexOf(needle),start=Math.max(0,pos-65),end=Math.min(text.length,start+230);
    const excerpt=document.createElement('span');
    excerpt.append(highlighted((start?'…':'')+text.slice(start,end)+(end<text.length?'…':''),term));
    link.append(excerpt);
    link.addEventListener('click',()=>document.getElementById(item.target).focus({preventScroll:true}));
    row.append(link);resultsList.append(row);
  });
}
queryInput.addEventListener('input',runGuideSearch);
document.getElementById('search-clear').addEventListener('click',()=>{queryInput.value='';runGuideSearch();queryInput.focus();});
queryInput.addEventListener('keydown',event=>{if(event.key==='Escape'){queryInput.value='';runGuideSearch();}});
