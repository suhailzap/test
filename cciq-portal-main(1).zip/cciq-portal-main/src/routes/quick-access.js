import express from 'express';
import { asyncRoute } from '../lib/async-route.js';
import { renderQuickAccessCard } from '../services/quick-access-card.js';
import { today, formatDate } from '../lib/dates.js';
import { getSetting } from '../lib/settings.js';

const router = express.Router();

/* Navigation only: the canonical public portal, never credentials or a session.
 * Do not derive this from Host/Forwarded headers or the server's private NIC.
 * Login, RBAC and kiosk session restrictions continue to apply normally.
 */
function currentAccess() {
  return { ok: true, url: 'https://portal.cciqonline.com', ambiguous: false };
}

router.get('/quick-access/info', (req, res) => {
  const access = currentAccess();
  const dateIso = today();
  if (!access.ok) {
    return res.json({ ok: false, dateIso, dateLabel: formatDate(dateIso, 'long') });
  }
  res.json({
    ok: true,
    url: access.url,
    ambiguous: access.ambiguous,
    dateIso,
    dateLabel: formatDate(dateIso, 'long'),
    filename: `CCIQ-Quick-Access-${dateIso}.png`
  });
});

router.get('/quick-access/card.png', asyncRoute(async (req, res, next) => {
  try {
    const access = currentAccess();
    if (!access.ok) return res.status(503).end();

    const dateIso = today();
    const png = await renderQuickAccessCard({
      url: access.url,
      dateLabel: formatDate(dateIso, 'long'),
      churchName: getSetting('church.display_name'),
      churchShortName: getSetting('church.short_name')
    });
    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'no-store');
    res.send(png);
  } catch (err) {
    next(err);
  }
}));

export default router;
