import { atomicRouter } from '../lib/atomic-router.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import {
  listFamilyGroups, getFamilyGroup, createFamilyGroup, renameFamilyGroup, setPrimaryMember,
  addMemberToFamilyGroup, removeMemberFromFamilyGroup, moveMemberToFamilyGroup, deleteFamilyGroup,
  relationshipLabelsFor, suggestFamilyMembers, familyGroupForMember,
  FAMILY_GROUP_SORT_COLUMNS
} from '../services/family-groups.js';
import { getMember, displayName, fullName, pickerCardFor, STATUS_LABELS } from '../services/members.js';
import { parsePaging, serverPaged, pageSizeParam } from '../lib/paging.js';

const router = atomicRouter();

function readFilters(req) {
  const sort = FAMILY_GROUP_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'name';
  const direction = ['asc', 'desc'].includes(req.query.direction) ? req.query.direction : 'asc';
  return { search: String(req.query.q || '').slice(0, 80), sort, direction };
}

router.get('/family-groups', requireAuth, requirePermission('family_groups.view'), (req, res) => {
  const filters = readFilters(req);
  const { result, paging } = serverPaged(({ page, pageSize }) => listFamilyGroups({ ...filters, page, pageSize }), parsePaging(req.query));

  res.render('family-groups/index', {
    title: 'Family Groups',
    result,
    paging,
    pagerParams: { q: filters.search, sort: filters.sort, direction: filters.direction, page_size: pageSizeParam(paging) },
    filters,
    canManage: req.user.can('family_groups.manage')
  });
});

router.get('/family-groups/new', requireAuth, requirePermission('family_groups.manage'), (req, res) => {
  res.render('family-groups/new', {
    title: 'New Family Group',
    values: {},
    errors: {},
    firstMemberSelected: null
  });
});

router.post('/family-groups', requireAuth, requirePermission('family_groups.manage'), (req, res) => {
  const v = new Validator(req.body);
  v.text('name', { required: true, max: 80, label: 'Family name' });
  const firstMemberId = v.integer('first_member_id', { label: 'First member' });

  if (!v.valid) {
    return res.status(400).render('family-groups/new', {
      title: 'New Family Group',
      values: req.body,
      errors: v.errors,
      firstMemberSelected: pickerCardFor(req.body.first_member_id)
    });
  }

  if (firstMemberId && familyGroupForMember(firstMemberId)) {
    return res.status(400).render('family-groups/new', {
      title: 'New Family Group',
      values: req.body,
      errors: { first_member_id: 'This member already belongs to another family group.' },
      firstMemberSelected: pickerCardFor(firstMemberId)
    });
  }

  const group = createFamilyGroup({ name: v.values.name, primaryMemberId: firstMemberId || null }, { userId: req.user.id });
  recordAudit({
    req, action: 'family.created', entityType: 'family_group', entityId: group.id,
    detail: { name: group.name, first_member_id: firstMemberId || null }
  });
  req.flash('success', `${group.name} created.`);
  return res.redirect(`/family-groups/${group.id}`);
});

router.get('/family-groups/:id(\\d+)', requireAuth, requirePermission('family_groups.view'), (req, res, next) => {
  const group = getFamilyGroup(Number(req.params.id));
  if (!group) return next();

  const membersWithLabels = group.members.map((m) => ({
    member: m,
    labels: relationshipLabelsFor(m, group.members)
  }));

  res.render('family-groups/show', {
    title: group.name,
    group,
    membersWithLabels,
    suggestions: suggestFamilyMembers(group.id),
    existingMemberIds: group.members.map((m) => m.id),
    statusLabels: STATUS_LABELS,
    fullName,
    canManage: req.user.can('family_groups.manage')
  });
});

router.get('/family-groups/:id(\\d+)/edit', requireAuth, requirePermission('family_groups.manage'), (req, res, next) => {
  const group = getFamilyGroup(Number(req.params.id));
  if (!group) return next();
  res.render('family-groups/edit', {
    title: `Edit ${group.name}`,
    group,
    values: group,
    errors: {}
  });
});

router.post('/family-groups/:id(\\d+)', requireAuth, requirePermission('family_groups.manage'), (req, res, next) => {
  const group = getFamilyGroup(Number(req.params.id));
  if (!group) return next();

  const v = new Validator(req.body);
  v.text('name', { required: true, max: 80, label: 'Family name' });
  const primaryMemberId = v.integer('primary_member_id', { label: 'Primary/contact member' });

  if (!v.valid) {
    return res.status(400).render('family-groups/edit', {
      title: `Edit ${group.name}`,
      group,
      values: req.body,
      errors: v.errors
    });
  }

  const nameChanged = v.values.name !== group.name;
  if (nameChanged) {
    renameFamilyGroup(group.id, v.values.name);
    recordAudit({
      req, action: 'family.renamed', entityType: 'family_group', entityId: group.id,
      detail: { from: group.name, to: v.values.name }
    });
  }

  if (primaryMemberId !== (group.primary_member_id || null)) {
    const result = setPrimaryMember(group.id, primaryMemberId);
    if (!result.ok) {
      return res.status(400).render('family-groups/edit', {
        title: `Edit ${group.name}`,
        group,
        values: req.body,
        errors: { primary_member_id: 'Choose someone who already belongs to this family group.' }
      });
    }
    recordAudit({
      req, action: 'family.primary_changed', entityType: 'family_group', entityId: group.id,
      detail: { from: group.primary_member_id || null, to: primaryMemberId || null }
    });
  }

  req.flash('success', 'Family Group updated.');
  return res.redirect(`/family-groups/${group.id}`);
});

router.post('/family-groups/:id(\\d+)/delete', requireAuth, requirePermission('family_groups.manage'), (req, res, next) => {
  const group = getFamilyGroup(Number(req.params.id));
  if (!group) return next();

  const result = deleteFamilyGroup(group.id);
  if (!result.ok) {
    req.flash('error', `${group.name} still has members and cannot be deleted. Remove every member first, or keep the Family Group.`);
    return res.redirect(`/family-groups/${group.id}`);
  }

  recordAudit({
    req, action: 'family.deleted', entityType: 'family_group', entityId: group.id,
    detail: { name: group.name }
  });
  req.flash('success', `${group.name} was deleted.`);
  return res.redirect('/family-groups');
});

// --- Family membership -------------------------------------------------

router.post('/family-groups/:id(\\d+)/members', requireAuth, requirePermission('family_groups.manage'),
  (req, res, next) => {
    const group = getFamilyGroup(Number(req.params.id));
    if (!group) return next();

    const v = new Validator(req.body);
    const memberId = v.integer('member_id', { required: true, label: 'Member' });
    const confirmMove = req.body.confirm_move === '1';

    const member = memberId ? getMember(memberId, { type: 'all' }) : null;
    if (!v.valid || !member) {
      req.flash('error', 'Choose a member to add.');
      return res.redirect(`/family-groups/${group.id}`);
    }

    if (confirmMove) {
      const previous = familyGroupForMember(member.id);
      moveMemberToFamilyGroup(group.id, member.id);
      recordAudit({
        req, action: 'family.member_moved', entityType: 'member', entityId: member.id,
        detail: {
          from_family_group_id: previous ? previous.id : null, from_name: previous ? previous.name : null,
          to_family_group_id: group.id, to_name: group.name
        }
      });
      req.flash('success', `${displayName(member)} was moved to ${group.name}.`);
      return res.redirect(`/family-groups/${group.id}`);
    }

    const result = addMemberToFamilyGroup(group.id, member.id);
    if (!result.ok && result.reason === 'already_in_family') {
      return res.render('family-groups/member-conflict', {
        title: 'Member already in a Family Group',
        group,
        member,
        existingFamilyGroup: result.existingFamilyGroup
      });
    }

    if (!result.alreadyMember) {
      recordAudit({
        req, action: 'family.member_added', entityType: 'member', entityId: member.id,
        detail: { family_group_id: group.id, family_group_name: group.name }
      });
      req.flash('success', `${displayName(member)} added to ${group.name}.`);
    }
    return res.redirect(`/family-groups/${group.id}`);
  });

router.post('/family-groups/:id(\\d+)/members/:memberId(\\d+)/remove', requireAuth,
  requirePermission('family_groups.manage'), (req, res, next) => {
    const group = getFamilyGroup(Number(req.params.id));
    const member = getMember(Number(req.params.memberId), { type: 'all' });
    if (!group || !member) return next();

    removeMemberFromFamilyGroup(group.id, member.id);
    recordAudit({
      req, action: 'family.member_removed', entityType: 'member', entityId: member.id,
      detail: { family_group_id: group.id, family_group_name: group.name }
    });
    req.flash('success', `${displayName(member)} is no longer part of ${group.name}. Their member record is unchanged.`);
    return res.redirect(`/family-groups/${group.id}`);
  });

export default router;
