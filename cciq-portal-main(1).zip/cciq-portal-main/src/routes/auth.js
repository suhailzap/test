import express from 'express';
import { asyncRoute } from '../lib/async-route.js';
import rateLimit from 'express-rate-limit';
import { queryOne } from '../db/index.js';
import config from '../config/env.js';
import { verifyPassword, checkPasswordPolicy } from '../lib/passwords.js';

import { recordAudit, AUDIT } from '../lib/audit.js';
import { safeRedirect } from '../lib/validate.js';
import { applySessionCookiePolicy, isKioskOnlySession } from '../lib/session-policy.js';
import { getSetting } from '../lib/settings.js';
import { requireGuest, requireAuth } from '../middleware/auth.js';
import {
  findUserByIdentifier, isLocked, registerFailedAttempt, registerSuccessfulLogin, setPassword,
  rolesForUser
} from '../services/users.js';

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: 'Too many sign-in attempts from this device. Wait a few minutes and try again.'
});

router.get('/login', requireGuest, (req, res) => {
  const nextPath = safeRedirect(req.query.next, '/');
  res.render('auth/login', {
    publicAbout: getSetting('church.public_about') === true,
    title: nextPath === '/kiosk' ? 'Attendance Kiosk Sign In' : 'Sign in',
    kioskIntent: nextPath === '/kiosk',
    layout: 'auth',
    nextPath,
    timedOut: req.query.timeout === '1',
    accountChanged: req.query.accountChanged === '1',
    error: null,
    email: ''
  });
});

router.post('/login', requireGuest, loginLimiter, asyncRoute(async (req, res, next) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const nextPath = safeRedirect(req.body.next, '/');

  const fail = (message) => res.status(401).render('auth/login', {
    title: nextPath === '/kiosk' ? 'Attendance Kiosk Sign In' : 'Sign in',
    kioskIntent: nextPath === '/kiosk',
    layout: 'auth',
    nextPath,
    timedOut: false,
    accountChanged: false,
    error: message,
    // Every render of this page needs the same values, or a failed sign-in
    // breaks instead of showing the message.
    publicAbout: getSetting('church.public_about') === true,
    email
  });

  try {
    // Either a username or an email address is accepted, because some church
    // workers have no email of their own.
    const user = findUserByIdentifier(email);
    const genericError = 'That username or email and password do not match.';

    if (!user) {
      recordAudit({ req, action: AUDIT.LOGIN_FAILED, actorLabel: email, result: 'failure', detail: 'unknown account' });
      await verifyPassword(password, 'scrypt$32768$8$1$AAAA$AAAA'); // keep timing steady
      return fail(genericError);
    }

    if (user.status !== 'active') {
      recordAudit({ req, userId: user.id, action: AUDIT.LOGIN_FAILED, result: 'denied', detail: 'account disabled' });
      return fail('This account is not active. Contact your church administrator.');
    }

    if (isLocked(user)) {
      recordAudit({ req, userId: user.id, action: AUDIT.LOGIN_FAILED, result: 'denied', detail: 'locked' });
      return fail(`Too many failed attempts. Try again in ${config.auth.lockoutMinutes} minutes.`);
    }

    const ok = await verifyPassword(password, user.password_hash);
    if (!ok) {
      const { locked } = registerFailedAttempt(user);
      recordAudit({ req, userId: user.id, action: AUDIT.LOGIN_FAILED, result: 'failure', detail: locked ? 'locked after failures' : 'bad password' });
      return fail(genericError);
    }

    /*
     * verifyPassword() above is a deliberately slow, CPU-bound scrypt
     * comparison against the row read at the top of this handler - if a
     * password reset or a deactivation (or a deactivate-then-reactivate
     * cycle, entirely within this same window) commits to the database
     * while that comparison is still running, it verified correctly
     * against state that no longer applies. Re-reading the row now and
     * requiring it to still match closes that race.
     *
     * R03 (Codex/independent verification): comparing password_hash/status
     * alone only ever catches a race that leaves the database in a
     * DIFFERENT state than when verification began - a deactivate
     * immediately followed by a reactivate, both completing before this
     * re-read, leaves status back at 'active' and password_hash unchanged,
     * so that comparison alone sees nothing wrong. security_generation
     * closes this: it advances on EITHER transition and is never
     * decremented, so a generation that moved at all during verification -
     * regardless of where the account's status or password ended up by the
     * time this re-read runs - can never match the snapshot taken before
     * verification began.
     */
    const fresh = queryOne('SELECT password_hash, status, security_generation FROM users WHERE id = @id', { id: user.id });
    if (!fresh || fresh.password_hash !== user.password_hash || fresh.status !== 'active'
      || fresh.security_generation !== user.security_generation) {
      recordAudit({ req, userId: user.id, action: AUDIT.LOGIN_FAILED, result: 'failure', detail: 'credentials changed during login' });
      return fail(genericError);
    }

    return req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.lastSeenAt = Date.now();
      req.session.loginAt = Date.now();
      // Snapshot of the security generation in effect right now - compared
      // on every subsequent request by attachUser(), so a later password
      // change/reset, deactivation, or reactivation (or a stale session
      // resurrected by an unrelated save-vs-delete race) can never remain
      // valid. See middleware/auth.js and R03.
      req.session.securityGeneration = fresh.security_generation;
      const roles = rolesForUser(user.id);
      const identity = { roles: roles.map((role) => role.key) };
      applySessionCookiePolicy(req.session, identity);
      registerSuccessfulLogin(user.id);
      recordAudit({ req, userId: user.id, actorLabel: user.email, action: AUDIT.LOGIN });
      if (user.must_change_password) return res.redirect('/account/password');
      // A specific destination — a deep link that required signing in first,
      // or the login screen's own "Attendance Kiosk" entry — is honoured
      // ahead of any role-based default. Only when nothing specific was
      // asked for does a restricted kiosk account fall back to the one
      // screen it has anything useful on, rather than the normal dashboard.
      // The Attendance Kiosk entry on the login page is only for those who operate it; anyone else signing in that way simply lands on their own home page.
      if (nextPath === '/kiosk' && !identity.roles.some((role) => ['kiosk', 'church_admin', 'super_admin'].includes(role))) return res.redirect('/');
      if (nextPath && nextPath !== '/') return res.redirect(nextPath);
      if (isKioskOnlySession(identity)) return res.redirect('/kiosk');
      return res.redirect('/');
    });
  } catch (err) {
    return next(err);
  }
}));

router.post('/logout', requireAuth, (req, res) => {
  const userId = req.user.id;
  const email = req.user.email;
  req.session.destroy(() => {
    res.clearCookie(config.session.name);
    recordAudit({ userId, actorLabel: email, action: AUDIT.LOGOUT });
    res.redirect('/login');
  });
});

router.get('/forgot-password', requireGuest, (req, res) => {
  res.render('auth/forgot', { title: 'Reset password', layout: 'auth' });
});

router.get('/account/password', requireAuth, (req, res) => {
  res.render('auth/change-password', { title: 'Change password', problems: [], error: null,
    layout: isKioskOnlySession(req.user) ? 'kiosk' : 'app' });
});

router.post('/account/password', requireAuth, asyncRoute(async (req, res, next) => {
  const current = String(req.body.current_password || '');
  const password = String(req.body.password || '');
  const confirm = String(req.body.confirm_password || '');

  const render = (error, problems = []) => res.status(400).render('auth/change-password', {
    title: 'Change password', problems, error,
    layout: isKioskOnlySession(req.user) ? 'kiosk' : 'app'
  });

  try {
    // Captured now, before the two slow, awaited operations below
    // (verifyPassword() here, hashPassword() inside setPassword()) - this
    // is "the security generation this operation began under", passed
    // through as setPassword()'s expectedGeneration so its own UPDATE can
    // refuse to commit if a concurrent security event (an admin reset, a
    // deactivate/reactivate) moves the account's state during that window.
    // See setPassword() in services/users.js.
    const user = queryOne('SELECT * FROM users WHERE id = @id', { id: req.user.id });
    if (!(await verifyPassword(current, user.password_hash))) {
      return render('Your current password is incorrect.');
    }
    if (password !== confirm) return render('The two passwords do not match.');
    // A temporary password is only a way in: the one chosen must be the person's own, never the one they were given (or the standard starting password).
    if (password === current || password === config.auth.initialPassword) return render('Choose a password of your own: it must be different from the temporary one you were given.');
    const problems = checkPasswordPolicy(password, { email: user.email });
    if (problems.length) return render('Choose a stronger password.', problems);

    const result = await setPassword(user.id, password, { exceptSid: req.sessionID, expectedGeneration: user.security_generation });
    if (!result.ok) {
      // R03 FINAL LEGACY-SESSION CORRECTION (Codex/independent
      // verification): the account's security state changed while this
      // request was in progress - committing this stale change would
      // silently overwrite whatever that newer event established, and
      // refreshing this session's own generation would restore access that
      // event may have specifically meant to revoke. Neither happens. This
      // acting session is also destroyed outright here, rather than merely
      // left with its now-stale generation for attachUser() to catch on
      // some later request: the concurrent event's own destroySessionsForUser()
      // sweep has no reason to except this session's sid (it isn't the one
      // performing that event), so it can already be gone from the sessions
      // table by the time this response is sent - and express-session's own
      // end-of-response save would otherwise resurrect that exact row via
      // its upsert. Destroying it here, before that save happens, closes
      // that window rather than depending on it never mattering in practice.
      recordAudit({ req, action: 'auth.password_change_refused_stale', result: 'denied' });
      return req.session.destroy(() => {
        res.clearCookie(config.session.name);
        res.redirect('/login?accountChanged=1');
      });
    }
    // This session was excepted from the sign-out sweep above, but it still
    // carries the OLD generation as its securityGeneration snapshot from
    // login - without refreshing it here, attachUser() would find a
    // mismatch on this same session's very next request and destroy it
    // anyway, undoing the exception. See middleware/auth.js.
    req.session.securityGeneration = result.securityGeneration;
    recordAudit({ req, action: 'auth.password_changed' });
    req.flash('success', 'Password updated.');
    return res.redirect('/');
  } catch (err) {
    return next(err);
  }
}));

export default router;
