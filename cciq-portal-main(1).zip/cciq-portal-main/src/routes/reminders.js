import { atomicRouter } from '../lib/atomic-router.js';
import { parsePaging, serverPaged, paginateList, pageSizeParam } from '../lib/paging.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator, safeRedirect } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { getSetting } from '../lib/settings.js';
import {
  listReminders, reminderCounts, getReminder, setReminderState, generateReminders,
  notifyNewReminders, listNotifications, markNotificationRead, markAllNotificationsRead, unreadNotificationCount,
  REMINDER_STATES, REMINDER_TYPES, STATE_LABELS, REMINDER_SORT_COLUMNS
} from '../services/reminders.js';

const router = atomicRouter();

// --- Reminder centre -------------------------------------------------------

router.get('/reminders', requireAuth, requirePermission('reminders.view'), (req, res) => {
  const state = ['open', 'all', ...REMINDER_STATES].includes(req.query.state) ? req.query.state : 'open';
  const type = Object.keys(REMINDER_TYPES).includes(req.query.type) ? req.query.type : null;
  const search = String(req.query.q || '').slice(0, 60);
  const sort = REMINDER_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : null;
  const direction = req.query.direction === 'desc' ? 'desc' : 'asc';

  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listReminders({ state, type, search, page, pageSize, sort, direction }),
    parsePaging(req.query)
  );

  res.render('reminders/index', {
    title: 'Reminders',
    result,
    paging,
    pagerParams: { state, type, q: search, sort, direction: sort ? direction : '', page_size: pageSizeParam(paging) },
    pageSizeQuery: pageSizeParam(paging),
    counts: reminderCounts(),
    filters: { state, type, search, sort, direction },
    types: REMINDER_TYPES,
    states: REMINDER_STATES,
    stateLabels: STATE_LABELS,
    birthdayDays: getSetting('reminders.birthday_days'),
    anniversaryDays: getSetting('reminders.anniversary_days'),
    threshold: getSetting('attendance.followup_threshold')
  });
});

/**
 * Reminders are raised automatically each day; this lets an administrator ask
 * for a pass immediately after changing the reminder settings.
 */
router.post('/reminders/generate', requireAuth, requirePermission('reminders.manage'), (req, res) => {
  const created = generateReminders();
  notifyNewReminders(created);
  const total = Object.values(created).reduce((a, b) => a + b, 0);

  recordAudit({ req, action: 'reminder.generated', entityType: 'reminder', detail: created });
  req.flash(total ? 'success' : 'info',
    total ? `${total} new reminder${total === 1 ? '' : 's'} raised.` : 'No new reminders are due.');
  res.redirect('/reminders');
});

router.post('/reminders/:id(\\d+)/state', requireAuth, requirePermission('reminders.manage'), (req, res, next) => {
  const reminder = getReminder(Number(req.params.id));
  if (!reminder) return next();

  const v = new Validator(req.body);
  const state = v.oneOf('state', REMINDER_STATES, { required: true, label: 'State' });
  if (!v.valid) {
    req.flash('error', 'Choose a valid state for the reminder.');
    return res.redirect('/reminders');
  }

  setReminderState(reminder.id, state, { userId: req.user.id });
  recordAudit({
    req, action: 'reminder.state_changed', entityType: 'reminder', entityId: reminder.id,
    detail: { from: reminder.state, to: state, type: reminder.reminder_type }
  });

  req.flash('success', `Reminder marked ${STATE_LABELS[state].toLowerCase()}.`);
  const back = req.body.return_to === 'member' && reminder.member_id
    ? `/members/${reminder.member_id}?tab=reminders`
    : `/reminders?state=${encodeURIComponent(req.body.current_state || 'open')}`;
  return res.redirect(back);
});

// --- Notifications ---------------------------------------------------------

router.get('/notifications', requireAuth, (req, res) => {
  // Every notification the retention window keeps, a page at a time (the old screen silently stopped at 60).
  const all = listNotifications(req.user.id, { limit: 100000 });
  const paging = paginateList(all, parsePaging(req.query));
  res.render('notifications/index', {
    title: 'Notifications',
    notifications: paging.rows,
    total: all.length,
    unread: unreadNotificationCount(req.user.id),
    paging,
    pagerParams: { page_size: pageSizeParam(paging) }
  });
});

router.post('/notifications/:id(\\d+)/read', requireAuth, (req, res) => {
  markNotificationRead(Number(req.params.id), req.user.id);
  // Only an internal path (never //host, /\host, a control character or an absolute URL), and never a non-string.
  res.redirect(safeRedirect(req.body.link, '/notifications'));
});

router.post('/notifications/read-all', requireAuth, (req, res) => {
  const count = markAllNotificationsRead(req.user.id);
  req.flash('info', count ? `${count} notification${count === 1 ? '' : 's'} marked as read.` : 'Nothing unread.');
  res.redirect('/notifications');
});

export default router;
