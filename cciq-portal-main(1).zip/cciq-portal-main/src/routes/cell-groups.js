import { atomicRouter } from '../lib/atomic-router.js';
import { streamFile } from '../lib/stream-file.js';
import { requireAuth, requirePermission, requireAnyPermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import {
  listGroups, getGroup, groupMembers, createGroup, updateGroup, assignMemberToGroup, setGroupPhoto,
  GROUP_STATUSES, GROUP_ROLES, MEETING_DAYS
} from '../services/cell-groups.js';
import { getMember, displayName, pickerCardFor, STATUS_LABELS as MEMBER_STATUS_LABELS } from '../services/members.js';
import {
  cellGroupAttendanceSummary, consecutiveMissedFridays, lastAttendedFriday, trackedFridayContexts,
  createCellGroupMeeting, cellGroupMeetings, cellGroupMeetingSummary
} from '../services/attendance.js';
import { documentsFor, scopeFor as documentScope } from '../services/documents.js';
import fs from 'node:fs';
import { memberPhotoUpload, saveGroupPhoto, resolveStoredFile, contentTypeFor, uploadErrorMessage, pruneSiblings, discardStoredFile } from '../lib/uploads.js';
import { transaction } from '../db/index.js';
import { verifyCsrf } from '../lib/csrf.js';
import { listGroupActivities, groupGallery, groupActivityStats, canManageGroupActivities } from '../services/activities.js';
import { getSetting } from '../lib/settings.js';
import { groupCover } from '../lib/group-cover.js';
import { today } from '../lib/dates.js';
import { recordAudit as auditAction } from '../lib/audit.js';

const router = atomicRouter();

/** Leaders reach only the groups they lead; administrators reach all of them. */
function canReachGroup(user, groupId) {
  if (user.can('cellgroups.view') || user.can('cellgroups.manage')) return true;
  return user.ledCellGroupIds.includes(Number(groupId));
}

// Leader/assistant are now linked via the shared member picker (status-blind,
// like every other relationship link), so there is no more fixed list to
// build for a <select> — just resolve whichever id is already on the form
// into the card the picker partial shows as selected.
function leaderPickerSelections(values) {
  values = values || {};
  return {
    leaderSelected: pickerCardFor(values.leader_member_id),
    assistantSelected: pickerCardFor(values.assistant_member_id)
  };
}

function collectGroupInput(body) {
  const v = new Validator(body);
  v.text('name', { required: true, max: 80, label: 'Group name' });
  v.text('description', { max: 1000, label: 'Description' });
  v.integer('leader_member_id', { label: 'Leader' });
  v.integer('assistant_member_id', { label: 'Assistant leader' });
  v.oneOf('meeting_day', MEETING_DAYS, { label: 'Meeting day' });
  v.time('meeting_time', { label: 'Meeting time' });
  v.text('meeting_location', { max: 200, label: 'Meeting location' });
  v.oneOf('status', GROUP_STATUSES, { required: true, label: 'Status', fallback: 'active' });
  return v;
}

router.get('/cell-groups', requireAuth, requireAnyPermission('cellgroups.view', 'cellgroups.view_own', 'cellgroups.manage_own'),
  (req, res) => {
    const all = listGroups();
    const canSeeAll = req.user.can('cellgroups.view') || req.user.can('cellgroups.manage');
    const visible = canSeeAll
      ? all
      : all.filter((g) => req.user.ledCellGroupIds.includes(g.id) || g.id === req.user.member?.cell_group_id);

    // A dozen or two groups: filtered and sorted in memory (no paging needed), with the choices
    // kept in the query string.
    const search = String(req.query.q || '').slice(0, 60).trim().toLowerCase();
    const status = GROUP_STATUSES.includes(req.query.status) ? req.query.status : null;
    const day = MEETING_DAYS.includes(req.query.day) ? req.query.day : null;
    const sort = ['name', 'leader', 'members', 'meets'].includes(req.query.sort) ? req.query.sort : 'name';
    const direction = req.query.direction === 'desc' ? 'desc' : 'asc';
    const leaderName = (g) => (g.leader_first ? `${g.leader_preferred || g.leader_first} ${g.leader_last || ''}`.trim() : '');
    const filtered = visible.filter((g) => (!status || g.status === status)
      && (!day || g.meeting_day === day)
      && (!search || `${g.name} ${leaderName(g)} ${g.meeting_location || ''}`.toLowerCase().includes(search)));
    const sign = direction === 'desc' ? -1 : 1;
    const dayIndex = (g) => (MEETING_DAYS.indexOf(g.meeting_day) === -1 ? 99 : MEETING_DAYS.indexOf(g.meeting_day));
    const compare = {
      name: (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }),
      leader: (a, b) => (leaderName(a) || '\uffff').localeCompare(leaderName(b) || '\uffff', undefined, { sensitivity: 'base' }),
      members: (a, b) => a.member_count - b.member_count,
      meets: (a, b) => dayIndex(a) - dayIndex(b) || (a.meeting_time || '').localeCompare(b.meeting_time || '')
    }[sort];
    const groups = [...filtered].sort((a, b) => sign * compare(a, b) || a.name.localeCompare(b.name));

    res.render('cell-groups/index', {
      title: 'Cell groups',
      groups,
      totalVisible: visible.length,
      showingAll: canSeeAll,
      filters: { search: String(req.query.q || '').slice(0, 60).trim(), status, day, sort, direction },
      statuses: GROUP_STATUSES,
      days: MEETING_DAYS
    });
  });

router.get('/cell-groups/new', requireAuth, requirePermission('cellgroups.manage'), (req, res) => {
  res.render('cell-groups/form', {
    title: 'Add cell group',
    mode: 'create',
    group: { status: 'active' },
    values: {},
    errors: {},
    ...leaderPickerSelections({}),
    days: MEETING_DAYS,
    statuses: GROUP_STATUSES
  });
});

router.post('/cell-groups', requireAuth, requirePermission('cellgroups.manage'), (req, res) => {
  const v = collectGroupInput(req.body);
  if (!v.valid) {
    return res.status(400).render('cell-groups/form', {
      title: 'Add cell group',
      mode: 'create',
      group: req.body,
      values: req.body,
      errors: v.errors,
      ...leaderPickerSelections(req.body),
      days: MEETING_DAYS,
      statuses: GROUP_STATUSES
    });
  }

  try {
    const group = createGroup(v.values, { userId: req.user.id });
    recordAudit({ req, action: 'cellgroup.created', entityType: 'cell_group', entityId: group.id, detail: { name: group.name } });
    req.flash('success', `${group.name} created.`);
    return res.redirect(`/cell-groups/${group.id}`);
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(400).render('cell-groups/form', {
        title: 'Add cell group',
        mode: 'create',
        group: req.body,
        values: req.body,
        errors: { name: 'A cell group with that name already exists.' },
        ...leaderPickerSelections(req.body),
        days: MEETING_DAYS,
        statuses: GROUP_STATUSES
      });
    }
    throw err;
  }
});

router.get('/cell-groups/:id(\\d+)', requireAuth,
  requireAnyPermission('cellgroups.view', 'cellgroups.view_own', 'cellgroups.manage_own'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const group = getGroup(id);
    if (!group) return next();
    if (!canReachGroup(req.user, id) && req.user.member?.cell_group_id !== id) {
      const err = new Error('You can only view the cell group you belong to or lead.');
      err.status = 403;
      return next(err);
    }

    const canManage = req.user.can('cellgroups.manage');
    const leadsGroup = req.user.ledCellGroupIds.includes(id);
    const canManageActivities = canManageGroupActivities(req.user, id);
    // Attendance and reports carry detail about other people, so they follow
    // the attendance permission rather than simple group membership.
    const canSeeAttendance = req.user.can('attendance.view') || leadsGroup;
    const canSeeReports = req.user.can('reports.view') || (leadsGroup && req.user.can('attendance.view'));

    // Tabs a user cannot open are not offered, and asking for one directly
    // falls back to the overview rather than failing.
    const tabs = ['overview', 'members'];
    if (canSeeAttendance) tabs.push('attendance', 'meetings');
    tabs.push('activities', 'gallery');
    if (canSeeReports) tabs.push('reports');
    const tab = tabs.includes(req.query.tab) ? req.query.tab : 'overview';

    const members = groupMembers(id);
    const attendance = canSeeAttendance
      ? cellGroupAttendanceSummary(id, { lastN: 8 })
      : { sessions: [], members: [], rows: [], averageRate: null };

    // The group's own meetings are tracked separately from the Friday Service.
    const meetings = canSeeAttendance
      ? cellGroupMeetingSummary(id, { lastN: 8 })
      : { meetings: [], rows: [], averageRate: null, totalPresent: 0 };

    let report = null;
    if (tab === 'reports' && canSeeReports) {
      const followUp = [];
      const sequence = trackedFridayContexts();
      for (const member of members) {
        if (member.status === 'archived') continue;
        const result = consecutiveMissedFridays(member.id, { contexts: sequence });
        if (result.flagged) {
          followUp.push({
            member,
            streak: result.streak,
            lastAttended: lastAttendedFriday(member.id),
            message: `Member has not had recorded attendance for ${result.streak} consecutive Friday Services. Follow-up may be appropriate.`
          });
        }
      }
      report = {
        membership: {
          total: members.length,
          active: members.filter((m) => m.status === 'active').length,
          pending: members.filter((m) => m.status === 'pending').length,
          inactive: members.filter((m) => m.status === 'inactive').length
        },
        followUp,
        activities: groupActivityStats(id)
      };
    }

    return res.render('cell-groups/show', {
      title: group.name,
      group,
      cover: groupCover(group),
      tab,
      members,
      canManage,
      canManageOwn: canManage || leadsGroup,
      canManageActivities,
      canSeeReports,
      canSeeAttendance,
      visibleTabs: tabs,
      attendance,
      meetings,
      meetingList: tab === 'meetings' ? cellGroupMeetings(id, { limit: 20 }) : [],
      canRecordMeetings: canManage || leadsGroup,
      documents: req.user.can('documents.view')
        ? documentsFor('cell_group', id, { scope: documentScope(req.user) })
        : [],
      canUploadDocuments: req.user.can('documents.upload'),
      report,
      threshold: getSetting('attendance.followup_threshold') || 3,
      activities: tab === 'activities'
        ? listGroupActivities(id, { includeUnpublished: canManageActivities })
        : [],
      gallery: (tab === 'gallery' || tab === 'reports')
        ? groupGallery(id, { includeUnpublished: canManageActivities })
        : { albums: [], total: 0, photos: 0, videos: 0, documents: 0 },
      statusLabels: { draft: 'Draft', published: 'Published', archived: 'Archived' }, // activity statuses
      memberStatusLabels: MEMBER_STATUS_LABELS,
      groupRoles: GROUP_ROLES
    });
  });

/** Group report as CSV: membership, attendance and follow-up in one sheet. */
router.get('/cell-groups/:id(\\d+)/report.csv', requireAuth, requirePermission('reports.view', 'reports.export'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const group = getGroup(id);
    if (!group) return next();
    if (!canReachGroup(req.user, id)) {
      const err = new Error('You can only export a report for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    const members = groupMembers(id);
    const attendance = cellGroupAttendanceSummary(id, { lastN: 8 });
    const rateByMember = new Map(attendance.rows.map((r) => [r.member.id, r]));
    const cell = (v) => {
      const text = v == null ? '' : String(v);
      const safe = /^[=+\-@]/.test(text) ? `'${text}` : text;
      return `"${safe.replaceAll('"', '""')}"`;
    };

    // Rates are for FINALIZED Friday Services the member was expected at (Vacation
    // excluded); a Friday that is not finalized yet never counts as an absence.
    const header = ['Member ID', 'Member', 'Role in group', 'Membership status', 'Joined',
      'Services counted (Vacation not counted)', 'Present', 'Attendance %',
      'Absences in a row', 'Last attended Friday Service'];
    const sequence = trackedFridayContexts();
    const lines = [header.map(cell).join(',')];

    for (const member of members) {
      const row = rateByMember.get(member.id);
      const streak = consecutiveMissedFridays(member.id, { contexts: sequence });
      const last = lastAttendedFriday(member.id);
      lines.push([
        member.member_code,
        displayName(member),
        member.role_in_group || 'member',
        member.status,
        member.date_joined || '',
        row ? row.rateDenominator : 0,
        row ? row.rateNumerator : 0,
        row && row.rate !== null ? row.rate : '',
        streak.streak,
        last ? last.service_date : ''
      ].map(cell).join(','));
    }

    auditAction({
      req, action: 'report.exported', entityType: 'cell_group', entityId: id,
      detail: { report: 'cell_group', members: members.length }
    });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition',
      `attachment; filename="cell-group-${id}-${today()}.csv"`);
    return res.send(`${lines.join('\r\n')}\r\n`);
  });


/**
 * A leader records their own group's meeting. It is kept apart from the Friday
 * Service, and never counts towards the consecutive-Friday follow-up rule.
 */
router.post('/cell-groups/:id(\\d+)/meetings', requireAuth, requirePermission('attendance.record'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const group = getGroup(id);
    if (!group) return next();

    const leads = req.user.ledCellGroupIds.includes(id);
    if (!leads && !req.user.can('attendance.manage_sessions')) {
      const err = new Error('You can only record meetings for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    const v = new Validator(req.body);
    const date = v.date('meeting_date', { required: true, label: 'Meeting date', notFuture: true });
    const title = v.text('title', { max: 120, label: 'What the group did' });
    const startTime = v.time('start_time', { label: 'Start time' });
    const location = v.text('location', { max: 200, label: 'Where they met' });
    const notes = v.text('notes', { max: 1000, label: 'Notes' });

    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/cell-groups/${id}?tab=meetings`);
    }

    const result = createCellGroupMeeting(id, {
      date, title, startTime, location, notes, userId: req.user.id
    });

    if (!result.ok) {
      req.flash('info', 'A meeting was already recorded for that date. Open it to record who came.');
      return res.redirect(`/attendance/sessions/${result.sessionId}`);
    }

    auditAction({
      req, action: 'cellgroup.meeting_created', entityType: 'attendance_session',
      entityId: result.sessionId, detail: { cell_group_id: id, date }
    });

    req.flash('success', `Meeting on ${date} created. Now mark who came.`);
    return res.redirect(`/attendance/sessions/${result.sessionId}`);
  });


// --- Quick view -------------------------------------------------------------

/**
 * A cell group shown in a drawer, so the About page and lists can open one
 * without navigating away. Members are listed only for those permitted to see
 * member records; everyone else sees the group and how many belong to it.
 */
router.get('/cell-groups/:id(\\d+)/quick', requireAuth, requireAnyPermission('cellgroups.view', 'cellgroups.view_own'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const group = getGroup(id);
    if (!group) return next();

    const seesAll = req.user.can('cellgroups.view');
    const isOwn = req.user.ledCellGroupIds.includes(id)
      || Number(req.user.member?.cell_group_id) === id;
    if (!seesAll && !isOwn) return next();

    const canSeeMembers = req.user.can('members.view') || isOwn;
    return res.render('cell-groups/quick', {
      group,
      cover: groupCover(group),
      members: canSeeMembers ? groupMembers(id) : [],
      memberCount: groupMembers(id).length,
      canSeeMembers,
      canSeeContact: req.user.can('members.view_contact'),
      canOpenMembers: req.user.can('members.view'),
      canManage: req.user.can('cellgroups.manage') || req.user.ledCellGroupIds.includes(id),
      layout: false
    });
  });

/** A group photo, served through a permission check like all other media. */
router.get('/media/groups/:id(\\d+)/photo', requireAuth, (req, res, next) => {
  const group = getGroup(Number(req.params.id));
  if (!group || !group.photo_path) return next();

  const file = resolveStoredFile(group.photo_path);
  if (!file) return next();

  res.setHeader('Content-Type', contentTypeFor(file));
  res.setHeader('Cache-Control', 'private, max-age=600');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return streamFile(res, file, next);
});

router.post('/cell-groups/:id(\\d+)/photo', requireAuth, requirePermission('cellgroups.manage'),
  (req, res, next) => {
    const group = getGroup(Number(req.params.id));
    if (!group) return next();

    return memberPhotoUpload(req, res, (uploadErr) => {
      if (uploadErr) {
        req.flash('error', uploadErrorMessage(uploadErr));
        return res.redirect(`/cell-groups/${group.id}`);
      }
      if (!verifyCsrf(req)) {
        const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
        err.status = 403;
        return next(err);
      }
      if (!req.file) {
        req.flash('error', 'Choose a photo to upload.');
        return res.redirect(`/cell-groups/${group.id}`);
      }

      try {
        const { storedPath } = saveGroupPhoto('group', group.id, req.file);
        try {
          transaction(() => {
            setGroupPhoto(group.id, storedPath);
            recordAudit({
              req, action: 'cellgroup.photo_updated', entityType: 'cell_group', entityId: group.id
            });
          })();
        } catch (dbErr) {
          discardStoredFile(storedPath); // the record still points at the previous photo, which is untouched
          throw dbErr;
        }
        pruneSiblings(storedPath);
        req.flash('success', 'Group photo updated.');
      } catch (err) {
        if (!err.status) return next(err);
        req.flash('error', err.message);
      }
      return res.redirect(`/cell-groups/${group.id}`);
    });
  });

router.get('/cell-groups/:id(\\d+)/edit', requireAuth, requirePermission('cellgroups.manage'), (req, res, next) => {
  const group = getGroup(Number(req.params.id));
  if (!group) return next();
  return res.render('cell-groups/form', {
    title: `Edit ${group.name}`,
    mode: 'edit',
    group,
    values: group,
    errors: {},
    ...leaderPickerSelections(group),
    days: MEETING_DAYS,
    statuses: GROUP_STATUSES
  });
});

router.post('/cell-groups/:id(\\d+)', requireAuth, requirePermission('cellgroups.manage'), (req, res, next) => {
  const id = Number(req.params.id);
  const group = getGroup(id);
  if (!group) return next();

  const v = collectGroupInput(req.body);
  if (!v.valid) {
    return res.status(400).render('cell-groups/form', {
      title: `Edit ${group.name}`,
      mode: 'edit',
      group: { ...group, ...req.body },
      values: req.body,
      errors: v.errors,
      ...leaderPickerSelections(req.body),
      days: MEETING_DAYS,
      statuses: GROUP_STATUSES
    });
  }

  updateGroup(id, v.values, { userId: req.user.id });
  recordAudit({ req, action: 'cellgroup.updated', entityType: 'cell_group', entityId: id });
  req.flash('success', 'Cell group updated.');
  return res.redirect(`/cell-groups/${id}`);
});

router.post('/cell-groups/:id(\\d+)/members', requireAuth, requirePermission('cellgroups.manage'), (req, res, next) => {
  const id = Number(req.params.id);
  const group = getGroup(id);
  if (!group) return next();

  const v = new Validator(req.body);
  const memberId = v.integer('member_id', { required: true, label: 'Member' });
  const role = v.oneOf('role_in_group', GROUP_ROLES, { label: 'Role in group', fallback: 'member' });

  if (!v.valid || !getMember(memberId, { type: 'all' })) {
    req.flash('error', 'Choose a member to add.');
    return res.redirect(`/cell-groups/${id}?tab=members`);
  }

  assignMemberToGroup(memberId, id, { role: role || 'member', userId: req.user.id });
  recordAudit({
    req, action: 'member.group_changed', entityType: 'member', entityId: memberId,
    detail: { to: id, role }
  });
  req.flash('success', 'Member added to the group.');
  return res.redirect(`/cell-groups/${id}?tab=members`);
});

router.post('/cell-groups/:id(\\d+)/members/:memberId(\\d+)/remove', requireAuth, requirePermission('cellgroups.manage'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const memberId = Number(req.params.memberId);
    const group = getGroup(id);
    const member = getMember(memberId, { type: 'all' });
    if (!group || !member) return next();

    assignMemberToGroup(memberId, null, { userId: req.user.id });
    recordAudit({
      req, action: 'member.group_changed', entityType: 'member', entityId: memberId,
      detail: { from: id, to: null }
    });
    req.flash('success', `${displayName(member)} removed from ${group.name}.`);
    return res.redirect(`/cell-groups/${id}?tab=members`);
  });

export default router;
