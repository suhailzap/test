import express from 'express';
import { openReviewCount } from '../services/membership-review.js';
import { requireAuth } from '../middleware/auth.js';
import { getGroup } from '../services/cell-groups.js';
import {
  statusCounts, currentPopulationCount, scopeFor, upcomingBirthdays, upcomingAnniversaries, displayName
} from '../services/members.js';
import {
  getNextFridayService, getLatestFridayService, scheduleStatus, ensureFridaySessions
} from '../services/friday-service.js';
import {
  sessionSummary, followUpList, followUpStatus, memberAttendanceSummary, attendanceTrend, pendingFridayServices
} from '../services/attendance.js';

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const user = req.user;
  // A kiosk account has nothing to see on the normal dashboard — send it
  // straight back to the one screen it is for, rather than rendering a
  // dashboard built around permissions it deliberately does not hold.
  if (user.hasRole('kiosk')) return res.redirect('/kiosk');

  const schedule = scheduleStatus();
  const nextService = getNextFridayService();
  const latestService = getLatestFridayService();

  // Administrators and leaders
  if (user.canAny('members.view', 'attendance.view')) {
    if (user.can('attendance.manage_sessions')) ensureFridaySessions({ userId: user.id });

    const scope = scopeFor(user);
    const counts = statusCounts(scope);
    const currentPopulation = currentPopulationCount(scope);
    const latest = latestService
      ? { session: latestService, summary: sessionSummary(latestService.id) }
      : null;
    const followUps = user.can('attendance.followup') ? followUpList({ limit: 200 }) : [];

    return res.render('dashboard/staff', {
      // Whoever records attendance is told which tracked Fridays still need finalizing
      // (never pre-go-live, cancelled or not-taken Fridays, and never an open one).
      pending: req.user.can('attendance.record') ? pendingFridayServices({ weeks: 8 }).sessions : [],
      followUpIncomplete: user.can('attendance.followup') ? !followUpStatus().complete : false,
      title: 'Dashboard',
      openMembershipReviews: user.can('members.edit') ? openReviewCount() : 0,
      schedule,
      nextService,
      latest,
      counts,
      currentPopulation,
      followUps: followUps.slice(0, 5),
      followUpTotal: followUps.length,
      birthdays: user.can('members.view') ? upcomingBirthdays({ withinDays: 30, limit: 5 }) : [],
      anniversaries: user.can('members.view') ? upcomingAnniversaries({ withinDays: 30, limit: 5 }) : [],
      trend: user.can('attendance.view') ? attendanceTrend({ points: 6 }) : []
    });
  }

  // Members
  const attendance = user.memberId ? memberAttendanceSummary(user.memberId, { lastN: 8 }) : null;
  // The member's OWN cell group (the same record their own group page shows). This used to be passed as null, so every Member was told they had no cell group.
  const cellGroup = user.member?.cell_group_id ? getGroup(user.member.cell_group_id) : null;
  return res.render('dashboard/member', {
    title: 'Dashboard',
    schedule,
    nextService,
    attendance,
    memberName: user.member ? displayName(user.member) : user.displayName,
    cellGroup,
    canOpenCellGroup: Boolean(cellGroup) && user.canAny('cellgroups.view', 'cellgroups.view_own', 'cellgroups.manage_own')
  });
});

export default router;
