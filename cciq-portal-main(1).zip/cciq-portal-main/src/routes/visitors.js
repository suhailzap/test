import { atomicRouter } from '../lib/atomic-router.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { transaction } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { today } from '../lib/dates.js';
import {
  createVisitor, collectInviter, findPossibleDuplicates, getVisitor, updateVisitor, recordVisit, setVisitorState, setFollowUpState,
  convertToMember, linkVisitorToMember, defaultMemberValuesFor, listVisitors, needingFollowUp, visitorCounts, inviterSummary, inviteesFor,
  VISITOR_STATES, MANUAL_OUTCOMES, MANUAL_OUTCOME_LABELS, STATE_LABELS, FOLLOW_UP_STATES, FOLLOW_UP_LABELS, VISITOR_SORT_COLUMNS,
  INVITER_SORT_COLUMNS, FOLLOW_UP_SORT_COLUMNS
} from '../services/visitors.js';
import {
  displayName,
  pickerCardFor,
  nextMemberCode,
  findPossibleDuplicates as findPossibleMemberDuplicates
} from '../services/members.js';
import { collectMemberInput, pickerSelections, formOptions } from '../lib/member-form.js';
import { recordDuplicateOverride } from '../services/member-create.js';
import {
  listReviews, getReview, openReviewForVisitor, openReviewCount, continueAsVisitor, evaluateSafely, reviewEvaluation, visitorStanding, REVIEW_STATUSES, REVIEW_SORT_COLUMNS
} from '../services/membership-review.js';
import { AGE_GROUPS, AGE_GROUP_LABELS } from '../services/congregations.js';
import { listSessions } from '../services/attendance.js';
import { parsePaging, paginateList, serverPaged, pageSizeParam } from '../lib/paging.js';

const router = atomicRouter();

const GRACE_DAYS = () => Number(getSetting('visitors.follow_up_days')) || 21;

/**
 * "Back to First Timers" returns to the list as the person last had it (search, filter, sort, page). The address is remembered in the
 * session by the list itself, and only an address of exactly the shape /visitors or /visitors?plain-query-string is ever used again,
 * so what a request carries can never turn this into a redirect to somewhere else.
 */
const LIST_HREF = /^\/visitors(\?[A-Za-z0-9_=&%.+~*-]{0,400})?$/;
const LIST_KEYS = ['q', 'state', 'follow_up', 'sort', 'dir', 'page', 'page_size'];
function rememberList(req) {
  // Rebuilt from the list's own parameters only (never the raw request address), so nothing else a request carries is ever kept.
  const params = new URLSearchParams();
  for (const key of LIST_KEYS) if (typeof req.query[key] === 'string' && req.query[key]) params.set(key, req.query[key].slice(0, 80));
  const href = params.size ? `/visitors?${params}` : '/visitors';
  if (LIST_HREF.test(href)) req.session.firstTimerListHref = href;
}
function backToListHref(req) {
  const remembered = req.session?.firstTimerListHref;
  return typeof remembered === 'string' && LIST_HREF.test(remembered) ? remembered : '/visitors';
}

// --- List and follow-up ----------------------------------------------------

router.get('/visitors', requireAuth, requirePermission('members.view'), (req, res) => {
  rememberList(req);
  const state = VISITOR_STATES.includes(req.query.state) ? req.query.state : null;
  const followUp = FOLLOW_UP_STATES.includes(req.query.follow_up) ? req.query.follow_up : null;
  const search = String(req.query.q || '').slice(0, 60);

  // Most recent first visit shown first, unless the person has chosen a
  // column of their own.
  const sort = Object.keys(VISITOR_SORT_COLUMNS).includes(req.query.sort) ? req.query.sort : 'first_visit';
  const direction = req.query.dir === 'asc' ? 'asc' : 'desc';

  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listVisitors({ state, followUp, search, page, pageSize, sort, direction }),
    parsePaging(req.query)
  );

  res.render('visitors/index', {
    title: 'First Timers',
    result,
    paging,
    pagerParams: { q: search, state, follow_up: followUp, sort, dir: direction, page_size: pageSizeParam(paging) },
    counts: visitorCounts(),
    filters: { state, followUp, search },
    sort,
    direction,
    states: VISITOR_STATES,
    stateLabels: STATE_LABELS,
    followUpStates: FOLLOW_UP_STATES,
    followUpLabels: FOLLOW_UP_LABELS,
    ageGroupLabels: AGE_GROUP_LABELS,
    canManage: req.user.can('members.edit'),
    openReviews: req.user.can('members.edit') ? openReviewCount() : 0
  });
});

router.get('/visitors/follow-up', requireAuth, requirePermission('members.view'), (req, res) => {
  const graceDays = GRACE_DAYS();

  const followUpSort = FOLLOW_UP_SORT_COLUMNS.includes(req.query.fsort) ? req.query.fsort : null;
  const followUpDirection = req.query.fdir === 'desc' ? 'desc' : 'asc';

  // Two tables, two sets of paging values: the follow-up list uses page / page_size, the inviters table ipage / isize.
  const inviterSort = Object.keys(INVITER_SORT_COLUMNS).includes(req.query.isort) ? req.query.isort : 'invited';
  const inviterDirection = req.query.idir === 'asc' ? 'asc' : 'desc';
  const { result: inviterResult, paging: inviterPaging } = serverPaged(
    ({ page, pageSize }) => inviterSummary({ page, pageSize, sort: inviterSort, direction: inviterDirection }),
    parsePaging({ page: req.query.ipage, page_size: req.query.isize })
  );
  const everyone = needingFollowUp({ graceDays, sort: followUpSort, direction: followUpDirection, limit: 100000 });
  const followUpPaging = paginateList(everyone, parsePaging(req.query));
  const followUpParams = { fsort: followUpSort, fdir: followUpSort ? followUpDirection : null, page_size: pageSizeParam(followUpPaging) };
  const inviterParams = { isort: inviterSort, idir: inviterDirection, isize: pageSizeParam(inviterPaging) };

  // Each inviter's own invitees, ready to show the moment their row is
  // expanded — a handful of members with a few invitees each is cheap
  // enough to fetch up front rather than round-trip on every click.
  const inviteesByMember = {};
  for (const inviter of inviterResult.rows) {
    inviteesByMember[inviter.id] = inviteesFor(inviter.id, { graceDays });
  }

  res.render('visitors/follow-up', {
    title: 'First Timers to follow up',
    graceDays,
    visitors: followUpPaging.rows,
    followUpTotal: everyone.length,
    followUpPaging,
    followUpParams,
    followUpSort,
    followUpDirection,
    inviterResult,
    inviterPaging,
    inviterParams,
    inviteesByMember,
    inviterSort,
    inviterDirection,
    counts: visitorCounts(),
    stateLabels: STATE_LABELS,
    followUpLabels: FOLLOW_UP_LABELS,
    canManage: req.user.can('members.edit')
  });
});

// --- Recording a First Timer ----------------------------------------------

router.get('/visitors/new', requireAuth, requirePermission('members.create'), (req, res) => {
  res.render('visitors/form', {
    title: 'Record a First Timer',
    mode: 'create',
    visitor: { first_visit_date: today() },
    values: {},
    errors: {},
    invitedBySelected: null,
    ageGroups: AGE_GROUPS,
    ageGroupLabels: AGE_GROUP_LABELS
  });
});

function collectVisitorInput(body) {
  const v = new Validator(body);
  v.text('first_name', { required: true, max: 80, label: 'First name' });
  v.text('last_name', { max: 80, label: 'Last name' });
  v.phone('phone');
  v.email('email');
  v.date('first_visit_date', { required: true, label: 'Date of their first visit', notFuture: true });
  v.oneOf('age_group', AGE_GROUPS, { label: 'Congregation' });
  collectInviter(v);
  v.text('invited_by_name', { max: 120, label: 'Invited by (a name not on our records)' });
  v.text('how_heard', { max: 200, label: 'How they heard about the church' });
  v.text('notes', { max: 2000, label: 'Notes' });
  return v;
}

router.post('/visitors', requireAuth, requirePermission('members.create'), (req, res) => {
  const v = collectVisitorInput(req.body);
  if (!v.valid) {
    return res.status(400).render('visitors/form', {
      title: 'Record a First Timer',
      mode: 'create',
      visitor: req.body,
      values: req.body,
      errors: v.errors,
      invitedBySelected: pickerCardFor(req.body.invited_by_member_id),
      ageGroups: AGE_GROUPS,
      ageGroupLabels: AGE_GROUP_LABELS
    });
  }

  // Warn (never block) when this looks like someone already on file; "Record anyway" confirms they are different.
  const overridden = req.body.duplicate_override === '1';
  const duplicates = overridden ? [] : findPossibleDuplicates(v.values);
  if (duplicates.length) {
    return res.render('visitors/form', {
      title: 'Record a First Timer',
      mode: 'create',
      visitor: req.body,
      values: req.body,
      errors: {},
      duplicates,
      invitedBySelected: pickerCardFor(req.body.invited_by_member_id),
      ageGroups: AGE_GROUPS,
      ageGroupLabels: AGE_GROUP_LABELS
    });
  }

  // The record and its audit row are one unit: a failure writing the audit row must not leave a First Timer behind with an error on screen.
  const visitor = transaction(() => {
    const created = createVisitor(v.values, { userId: req.user.id });
    recordAudit({
      req, action: 'visitor.created', entityType: 'visitor', entityId: created.id,
      detail: { first_visit: created.first_visit_date, invited_by: created.invited_by_member_id, duplicate_warning_overridden: overridden }
    });
    return created;
  })();
  req.flash('success', `${visitor.first_name} recorded as a First Timer.`);
  return res.redirect(`/visitors/${visitor.id}`);
});

// --- One visitor -----------------------------------------------------------

/** The First Timer page. `problem` re-shows it with a message and a 400 (a refused action), never a half-applied change. */
function renderVisitor(req, res, visitor, { status = 200, problem = null } = {}) {
  if (problem) res.locals.flash = { type: 'error', message: problem };
  return res.status(status).render('visitors/show', {
    title: `${visitor.first_name} ${visitor.last_name || ''}`.trim(),
    visitor,
    dispositions: MANUAL_OUTCOMES,
    dispositionLabels: MANUAL_OUTCOME_LABELS,
    backHref: backToListHref(req),
    stateLabels: STATE_LABELS,
    followUpStates: FOLLOW_UP_STATES,
    followUpLabels: FOLLOW_UP_LABELS,
    ageGroupLabels: AGE_GROUP_LABELS,
    services: listSessions({ serviceType: 'friday_service', page: 1, pageSize: 12 }).rows,
    canManage: req.user.can('members.edit'),
    canCreateMember: req.user.can('members.create'),
    openReview: req.user.can('members.edit') ? openReviewForVisitor(visitor.id) : null,
    reviewStanding: req.user.can('members.edit') ? visitorStanding(visitor.id) : null,
    graceDays: GRACE_DAYS()
  });
}

router.get('/visitors/:id(\\d+)', requireAuth, requirePermission('members.view'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  return renderVisitor(req, res, visitor);
});

router.get('/visitors/:id(\\d+)/edit', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  return res.render('visitors/form', {
    title: 'Edit First Timer',
    mode: 'edit',
    visitor,
    values: visitor,
    errors: {},
    invitedBySelected: pickerCardFor(visitor.invited_by_member_id),
    ageGroups: AGE_GROUPS,
    ageGroupLabels: AGE_GROUP_LABELS
  });
});

router.post('/visitors/:id(\\d+)', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();

  const v = collectVisitorInput(req.body);
  if (!v.valid) {
    return res.status(400).render('visitors/form', {
      title: 'Edit First Timer',
      mode: 'edit',
      visitor: { ...visitor, ...req.body },
      values: req.body,
      errors: v.errors,
      invitedBySelected: pickerCardFor(req.body.invited_by_member_id),
      ageGroups: AGE_GROUPS,
      ageGroupLabels: AGE_GROUP_LABELS
    });
  }

  transaction(() => {
    updateVisitor(visitor.id, v.values, { userId: req.user.id });
    recordAudit({ req, action: 'visitor.updated', entityType: 'visitor', entityId: visitor.id });
  })();
  req.flash('success', 'Updated.');
  return res.redirect(`/visitors/${visitor.id}`);
});

/** Recording that they came again is what marks someone as returning. */
router.post('/visitors/:id(\\d+)/visits', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();

  const v = new Validator(req.body);
  const date = v.date('visit_date', { required: true, label: 'Visit date', notFuture: true });
  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/visitors/${visitor.id}`);
  }

  const result = transaction(() => {
    const recorded = recordVisit(visitor.id, { date, userId: req.user.id });
    if (recorded.ok) {
      recordAudit({
        req, action: 'visitor.visit_recorded', entityType: 'visitor', entityId: visitor.id,
        detail: { date, visits: recorded.visits }
      });
    }
    return recorded;
  })();
  if (!result.ok) {
    req.flash('info', 'That visit was already recorded.');
    return res.redirect(`/visitors/${visitor.id}`);
  }

  evaluateSafely('manual-visit'); // a visit entered for a past, finalized Friday can complete the 3-of-4 rule
  req.flash('success', `Visit on ${date} recorded.`);
  return res.redirect(`/visitors/${visitor.id}`);
});

router.post('/visitors/:id(\\d+)/state', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();

  const v = new Validator(req.body);
  const state = v.oneOf('state', MANUAL_OUTCOMES, { required: true, label: 'Status' });
  const notes = v.text('follow_up_notes', { max: 1000, label: 'Notes' });
  if (!v.valid) {
    // 'joined' is not a choice: it comes only from making them a member or linking them to one. A forged value is refused, unchanged.
    return renderVisitor(req, res, visitor, {
      status: 400,
      problem: req.body.state === 'joined'
        ? 'Becoming a member cannot be set as a status. Use "Make them a member" or "Link to an existing member".'
        : 'Choose one of the listed statuses.'
    });
  }

  const result = transaction(() => {
    const changed = setVisitorState(visitor.id, state, { userId: req.user.id, notes });
    if (changed.ok) {
      recordAudit({
        req, action: 'visitor.state_changed', entityType: 'visitor', entityId: visitor.id,
        detail: { from: visitor.state, to: changed.visitor.state, chosen: state }
      });
    }
    return changed;
  })();
  if (!result.ok) {
    return renderVisitor(req, res, visitor, {
      status: result.reason === 'is_member' ? 409 : 400,
      problem: result.reason === 'is_member'
        ? 'This person is already a member, so their status is settled and cannot be changed here.'
        : 'That status could not be recorded.'
    });
  }
  req.flash('success', 'Status updated.');
  return res.redirect(`/visitors/${visitor.id}`);
});

router.post('/visitors/:id(\\d+)/follow-up', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();

  const v = new Validator(req.body);
  const state = v.oneOf('follow_up_state', FOLLOW_UP_STATES, { required: true, label: 'Follow-up' });
  const notes = v.text('follow_up_notes', { max: 1000, label: 'Notes' });
  if (!v.valid) {
    req.flash('error', 'Choose a valid follow-up state.');
    return res.redirect(req.body.return_to === 'list' ? '/visitors/follow-up' : `/visitors/${visitor.id}`);
  }

  transaction(() => {
    setFollowUpState(visitor.id, state, { userId: req.user.id, notes });
    recordAudit({
      req, action: 'visitor.follow_up_changed', entityType: 'visitor', entityId: visitor.id,
      detail: { from: visitor.follow_up_state, to: state }
    });
  })();
  req.flash('success', 'Follow-up updated.');
  return res.redirect(req.body.return_to === 'list' ? '/visitors/follow-up' : `/visitors/${visitor.id}`);
});

// --- Make them a member (always a NEW member record) ---------------------------------------------------------------------

function convertFormModel(visitor, values, extra = {}) {
  return {
    title: `Make ${[visitor.first_name, visitor.last_name].filter(Boolean).join(' ')} a member`,
    mode: 'create',
    member: { status: 'pending' },
    memberCode: nextMemberCode(),
    errors: {},
    values,
    extraValues: values,
    formAction: `/visitors/${visitor.id}/convert`,
    convertFrom: { id: visitor.id, name: [visitor.first_name, visitor.last_name].filter(Boolean).join(' ') },
    ...formOptions(),
    ...pickerSelections(values),
    ...extra
  };
}

const CONVERT_REFUSALS = {
  already_a_member: 'This person already has a member record.',
  not_found: 'That First Timer could not be found.'
};

router.get('/visitors/:id(\\d+)/convert', requireAuth, requirePermission('members.create'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  if (visitor.member_id || visitor.state === 'joined') {
    req.flash('info', CONVERT_REFUSALS.already_a_member);
    return res.redirect(`/visitors/${visitor.id}`);
  }
  return res.render('members/form', convertFormModel(visitor, defaultMemberValuesFor(visitor)));
});

router.post('/visitors/:id(\\d+)/convert', requireAuth, requirePermission('members.create'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  if (visitor.member_id || visitor.state === 'joined') {
    return renderVisitor(req, res, visitor, { status: 409, problem: CONVERT_REFUSALS.already_a_member });
  }

  const v = collectMemberInput(req.body);
  if (!v.valid) {
    return res.status(400).render('members/form', convertFormModel(visitor, req.body, { errors: v.errors }));
  }
  if (!v.values.date_joined) v.values.date_joined = today();

  // The same warn-only duplicate check Add member uses. An existing member is most likely the right answer to "who is this?",
  // so the warning points at Link as well as at "continue anyway".
  if (req.body.duplicate_override !== '1') {
    const duplicates = findPossibleMemberDuplicates(v.values);
    if (duplicates.length) {
      return res.render('members/duplicate-warning', {
        title: 'Possible duplicate member',
        action: `/visitors/${visitor.id}/convert`,
        cancelHref: `/visitors/${visitor.id}/convert`,
        duplicates,
        hasStrongMatch: duplicates.some((d) => d.level === 'strong'),
        formBody: req.body,
        alternativeHref: `/visitors/${visitor.id}/link`,
        alternativeLabel: 'This is an existing member: link them instead'
      });
    }
  }

  const result = convertToMember(visitor.id, { userId: req.user.id, req, values: v.values, body: req.body, status: 'pending' });
  if (!result.ok) {
    return renderVisitor(req, res, getVisitor(visitor.id) || visitor, { status: 409, problem: CONVERT_REFUSALS[result.reason] || 'That could not be completed.' });
  }
  // The same audit row Add member writes when a duplicate warning is overridden (the matches are recomputed here, not trusted from the form).
  if (req.body.duplicate_override === '1') recordDuplicateOverride({ req, member: result.member, values: v.values, body: req.body });
  if (result.spouseConflictName) {
    req.flash('error', `${result.spouseConflictName} is already recorded as married to someone else, so the spouse link was not saved.`);
  }
  req.flash('success', `${displayName(result.member)} now has a member record. Their visits stay on the First Timer record.`);
  return res.redirect(`/members/${result.member.id}`);
});

// --- Link to an EXISTING member (explicit choice only; never matched automatically) ----------------------------------------------

const LINK_REFUSALS = {
  already_a_member: 'This person is already linked to a member record.',
  member_not_found: 'That member could not be found. Choose a member from the search.',
  not_found: 'That First Timer could not be found.'
};

function linkModel(visitor, extra = {}) {
  return {
    title: `Link ${[visitor.first_name, visitor.last_name].filter(Boolean).join(' ')} to an existing member`,
    visitor,
    selected: null,
    problem: null,
    ...extra
  };
}

router.get('/visitors/:id(\\d+)/link', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  if (visitor.member_id || visitor.state === 'joined') {
    req.flash('info', LINK_REFUSALS.already_a_member);
    return res.redirect(`/visitors/${visitor.id}`);
  }
  return res.render('visitors/link', linkModel(visitor));
});

router.post('/visitors/:id(\\d+)/link', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const visitor = getVisitor(Number(req.params.id));
  if (!visitor) return next();
  if (visitor.member_id || visitor.state === 'joined') {
    return renderVisitor(req, res, visitor, { status: 409, problem: LINK_REFUSALS.already_a_member });
  }
  const selected = pickerCardFor(req.body.member_id);
  const again = (problem, status = 400) => res.status(status).render('visitors/link', linkModel(visitor, { selected, problem }));
  if (!selected) return again(LINK_REFUSALS.member_not_found);
  if (req.body.confirm !== '1') return again(`Tick the box to confirm that ${[visitor.first_name, visitor.last_name].filter(Boolean).join(' ')} and ${selected.name} are the same person.`);

  const result = linkVisitorToMember(visitor.id, selected.id, { userId: req.user.id, req });
  if (!result.ok) {
    if (result.reason === 'member_already_linked') {
      return again(`${selected.name} is already linked to another First Timer record, so a second one cannot be linked to the same member. Nothing was changed.`, 409);
    }
    return again(LINK_REFUSALS[result.reason] || 'That could not be completed.', result.reason === 'already_a_member' ? 409 : 400);
  }
  req.flash('success', `${[visitor.first_name, visitor.last_name].filter(Boolean).join(' ')} is now linked to ${selected.name}. Their visits stay on the First Timer record.`);
  return res.redirect(`/visitors/${visitor.id}`);
});

// --- Membership Review ---------------------------------------------------------------------------------------------------------------

router.get('/visitors/reviews', requireAuth, requirePermission('members.edit'), (req, res) => {
  const status = REVIEW_STATUSES.includes(req.query.status) ? req.query.status : (req.query.status === 'all' ? 'all' : 'open');
  const sort = Object.keys(REVIEW_SORT_COLUMNS).includes(req.query.sort) ? req.query.sort : 'opened';
  const direction = req.query.dir === 'asc' ? 'asc' : 'desc';
  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listReviews({ status, page, pageSize, sort, direction }),
    parsePaging(req.query)
  );
  res.render('visitors/reviews', {
    title: 'Membership review',
    result,
    paging,
    status,
    statuses: REVIEW_STATUSES,
    sort,
    direction,
    pagerParams: { status: status === 'open' ? '' : status, sort: sort === 'opened' ? '' : sort, dir: direction === 'desc' ? '' : direction, page_size: pageSizeParam(paging) },
    openCount: openReviewCount(),
    evaluation: reviewEvaluation(),
    canCreateMember: req.user.can('members.create')
  });
});

router.get('/visitors/reviews/:id(\\d+)', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const review = getReview(Number(req.params.id));
  if (!review) return next();
  return res.render('visitors/review', { title: 'Membership review', review, canCreateMember: req.user.can('members.create'), stateLabels: STATE_LABELS });
});

router.post('/visitors/reviews/:id(\\d+)/continue', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const review = getReview(Number(req.params.id));
  if (!review) return next();
  if (review.status !== 'open') {
    req.flash('info', 'That review has already been dealt with.');
    return res.redirect('/visitors/reviews');
  }
  if (req.body.confirm !== '1') {
    req.flash('error', 'Tick the box to confirm they should continue as a visitor.');
    return res.redirect(`/visitors/reviews/${review.id}`);
  }
  const v = new Validator(req.body);
  const note = v.text('note', { max: 500, label: 'Note' });
  const result = continueAsVisitor(review.id, { userId: req.user.id, req, note });
  if (!result.ok) {
    req.flash('info', 'That review has already been dealt with.');
    return res.redirect('/visitors/reviews');
  }
  req.flash('success', 'They will continue as a visitor. No new review is suggested until four more Friday Services have been finalized.');
  return res.redirect('/visitors/reviews');
});

export default router;
