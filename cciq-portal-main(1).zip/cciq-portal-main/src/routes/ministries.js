import { atomicRouter } from '../lib/atomic-router.js';
import { streamFile } from '../lib/stream-file.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import {
  listMinistries,
  getMinistry,
  createMinistry,
  updateMinistry,
  deleteMinistry,
  setMinistryPhoto,
  ministryMembers,
  addMember,
  removeMember,
  setRole,
  ministryOverview,
  NOT_SERVING_SORT_COLUMNS,
  searchNotServing,
  searchServingSeveral,
  SERVING_SEVERAL_SORT_COLUMNS,
  MINISTRY_STATUSES,
  MINISTRY_ROLES,
  ROLE_LABELS
} from '../services/ministries.js';
import { getMember, displayName, pickerCardFor } from '../services/members.js';
import fs from 'node:fs';
import {
  memberPhotoUpload, saveGroupPhoto, resolveStoredFile, contentTypeFor, uploadErrorMessage, pruneSiblings, discardStoredFile
} from '../lib/uploads.js';
import { transaction } from '../db/index.js';
import { verifyCsrf } from '../lib/csrf.js';
import { ministryCover } from '../lib/ministry-cover.js';
import { parsePaging, pageWindow } from '../lib/paging.js';
import { activeGroupOptions } from '../services/cell-groups.js';

const router = atomicRouter();

// Leader/assistant are linked via the shared member picker, so there is no
// more fixed member list to build for a <select> — just resolve whichever
// id is already on the form into the card the picker partial shows as
// selected.
function leaderPickerSelections(values) {
  values = values || {};
  return {
    leaderSelected: pickerCardFor(values.leader_member_id),
    assistantSelected: pickerCardFor(values.assistant_member_id)
  };
}

// --- The ministries of the church ------------------------------------------

router.get('/ministries', requireAuth, requirePermission('ministries.view'), (req, res) => {
  const canManage = req.user.can('ministries.manage');
  const overview = ministryOverview();

  res.render('ministries/index', {
    title: 'Ministries',
    overview,
    ministries: canManage ? overview.ministries : overview.ministries.filter((m) => m.status === 'active'),
    canManage
  });
});

router.get('/ministries/new', requireAuth, requirePermission('ministries.manage'), (req, res) => {
  res.render('ministries/form', {
    title: 'Add a ministry',
    mode: 'create',
    ministry: { status: 'active', sort_order: 0 },
    values: {},
    errors: {},
    ...leaderPickerSelections({}),
    statuses: MINISTRY_STATUSES
  });
});

function collectInput(body) {
  const v = new Validator(body);
  v.text('name', { required: true, max: 80, label: 'Ministry name' });
  v.text('description', { max: 2000, label: 'Description' });
  v.integer('leader_member_id', { label: 'Leader' });
  v.integer('assistant_member_id', { label: 'Assistant' });
  v.text('meets', { max: 160, label: 'When it meets or serves' });
  v.text('contact', { max: 160, label: 'Contact' });
  v.oneOf('status', MINISTRY_STATUSES, { label: 'Status', fallback: 'active' });
  v.integer('sort_order', { label: 'Order' });
  return v;
}

router.post('/ministries', requireAuth, requirePermission('ministries.manage'), (req, res) => {
  const v = collectInput(req.body);
  const rerender = (errors) => res.status(400).render('ministries/form', {
    title: 'Add a ministry',
    mode: 'create',
    ministry: req.body,
    values: req.body,
    errors,
    ...leaderPickerSelections(req.body),
    statuses: MINISTRY_STATUSES
  });

  if (!v.valid) return rerender(v.errors);

  try {
    const ministry = createMinistry(v.values, { userId: req.user.id });
    recordAudit({
      req, action: 'ministry.created', entityType: 'ministry', entityId: ministry.id,
      detail: { name: ministry.name }
    });
    req.flash('success', `${ministry.name} added.`);
    return res.redirect(`/ministries/${ministry.id}`);
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return rerender({ name: 'A ministry with that name already exists.' });
    }
    throw err;
  }
});

router.get('/ministries/:id(\\d+)', requireAuth, requirePermission('ministries.view'), (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry) return next();

  const canManage = req.user.can('ministries.manage');
  const serving = ministryMembers(ministry.id);
  const servingIds = new Set(serving.map((m) => m.id));

  res.render('ministries/show', {
    title: ministry.name,
    ministry,
    cover: ministryCover(ministry),
    serving,
    past: canManage
      ? ministryMembers(ministry.id, { includePast: true }).filter((m) => m.left_at)
      : [],
    servingIds: [...servingIds],
    roles: MINISTRY_ROLES,
    roleLabels: ROLE_LABELS,
    canManage,
    canSeeContact: req.user.can('members.view_contact'),
    canSeeMembers: req.user.can('members.view')
  });
});

// --- Quick view -------------------------------------------------------------

/** A ministry shown in a drawer, for the About page and the ministry list. */
router.get('/ministries/:id(\\d+)/quick', requireAuth, requirePermission('ministries.view'),
  (req, res, next) => {
    const ministry = getMinistry(Number(req.params.id));
    if (!ministry) return next();

    const serving = ministryMembers(ministry.id);
    return res.render('ministries/quick', {
      ministry,
      cover: ministryCover(ministry),
      serving: req.user.can('members.view') ? serving : [],
      servingCount: serving.length,
      canSeeMembers: req.user.can('members.view'),
      canSeeContact: req.user.can('members.view_contact'),
      roleLabels: ROLE_LABELS,
      canManage: req.user.can('ministries.manage'),
      layout: false
    });
  });

router.get('/media/ministries/:id(\\d+)/photo', requireAuth, (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry || !ministry.photo_path) return next();

  const file = resolveStoredFile(ministry.photo_path);
  if (!file) return next();

  res.setHeader('Content-Type', contentTypeFor(file));
  res.setHeader('Cache-Control', 'private, max-age=600');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return streamFile(res, file, next);
});

router.post('/ministries/:id(\\d+)/photo', requireAuth, requirePermission('ministries.manage'),
  (req, res, next) => {
    const ministry = getMinistry(Number(req.params.id));
    if (!ministry) return next();

    return memberPhotoUpload(req, res, (uploadErr) => {
      if (uploadErr) {
        req.flash('error', uploadErrorMessage(uploadErr));
        return res.redirect(`/ministries/${ministry.id}`);
      }
      if (!verifyCsrf(req)) {
        const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
        err.status = 403;
        return next(err);
      }
      if (!req.file) {
        req.flash('error', 'Choose a photo to upload.');
        return res.redirect(`/ministries/${ministry.id}`);
      }

      try {
        const { storedPath } = saveGroupPhoto('ministry', ministry.id, req.file);
        try {
          transaction(() => {
            setMinistryPhoto(ministry.id, storedPath);
            recordAudit({
              req, action: 'ministry.photo_updated', entityType: 'ministry', entityId: ministry.id
            });
          })();
        } catch (dbErr) {
          discardStoredFile(storedPath); // the record still points at the previous photo, which is untouched
          throw dbErr;
        }
        pruneSiblings(storedPath);
        req.flash('success', 'Ministry photo updated.');
      } catch (err) {
        if (!err.status) return next(err);
        req.flash('error', err.message);
      }
      return res.redirect(`/ministries/${ministry.id}`);
    });
  });

router.get('/ministries/:id(\\d+)/edit', requireAuth, requirePermission('ministries.manage'), (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry) return next();
  return res.render('ministries/form', {
    title: `Edit ${ministry.name}`,
    mode: 'edit',
    ministry,
    values: ministry,
    errors: {},
    ...leaderPickerSelections(ministry),
    statuses: MINISTRY_STATUSES
  });
});

router.post('/ministries/:id(\\d+)', requireAuth, requirePermission('ministries.manage'), (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry) return next();

  const v = collectInput(req.body);
  if (!v.valid) {
    return res.status(400).render('ministries/form', {
      title: `Edit ${ministry.name}`,
      mode: 'edit',
      ministry: { ...ministry, ...req.body },
      values: req.body,
      errors: v.errors,
      ...leaderPickerSelections(req.body),
      statuses: MINISTRY_STATUSES
    });
  }

  updateMinistry(ministry.id, v.values);
  recordAudit({ req, action: 'ministry.updated', entityType: 'ministry', entityId: ministry.id });
  req.flash('success', 'Ministry updated.');
  return res.redirect(`/ministries/${ministry.id}`);
});

router.post('/ministries/:id(\\d+)/delete', requireAuth, requirePermission('ministries.manage'), (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry) return next();

  deleteMinistry(ministry.id);
  recordAudit({
    req, action: 'ministry.deleted', entityType: 'ministry', entityId: ministry.id,
    detail: { name: ministry.name }
  });
  req.flash('success', `${ministry.name} removed.`);
  return res.redirect('/ministries');
});

// --- Who serves ------------------------------------------------------------

router.post('/ministries/:id(\\d+)/members', requireAuth, requirePermission('ministries.manage'),
  (req, res, next) => {
    const ministry = getMinistry(Number(req.params.id));
    if (!ministry) return next();

    const v = new Validator(req.body);
    const memberId = v.integer('member_id', { required: true, label: 'Member' });
    const role = v.oneOf('role', MINISTRY_ROLES, { label: 'Role', fallback: 'member' });
    const notes = v.text('notes', { max: 300, label: 'Notes' });

    const member = memberId ? getMember(memberId, { type: 'all' }) : null;
    if (!v.valid || !member) {
      req.flash('error', 'Choose a member to add.');
      return res.redirect(`/ministries/${ministry.id}`);
    }

    const result = addMember(ministry.id, member.id, { role: role || 'member', notes });
    recordAudit({
      req, action: 'ministry.member_added', entityType: 'ministry', entityId: ministry.id,
      detail: { member_id: member.id, role, rejoined: result.rejoined }
    });

    req.flash('success', result.rejoined
      ? `${displayName(member)} is serving in ${ministry.name} again.`
      : `${displayName(member)} added to ${ministry.name}.`);
    return res.redirect(`/ministries/${ministry.id}`);
  });

router.post('/ministries/:id(\\d+)/members/:memberId(\\d+)/role', requireAuth,
  requirePermission('ministries.manage'), (req, res, next) => {
    const ministry = getMinistry(Number(req.params.id));
    const member = getMember(Number(req.params.memberId), { type: 'all' });
    if (!ministry || !member) return next();

    const v = new Validator(req.body);
    const role = v.oneOf('role', MINISTRY_ROLES, { required: true, label: 'Role' });
    if (!v.valid) {
      req.flash('error', 'Choose a valid role.');
      return res.redirect(`/ministries/${ministry.id}`);
    }

    setRole(ministry.id, member.id, role);
    recordAudit({
      req, action: 'ministry.role_changed', entityType: 'ministry', entityId: ministry.id,
      detail: { member_id: member.id, role }
    });
    req.flash('success', `${displayName(member)} is now recorded as ${ROLE_LABELS[role].toLowerCase()}.`);
    return res.redirect(`/ministries/${ministry.id}`);
  });

router.post('/ministries/:id(\\d+)/members/:memberId(\\d+)/remove', requireAuth,
  requirePermission('ministries.manage'), (req, res, next) => {
    const ministry = getMinistry(Number(req.params.id));
    const member = getMember(Number(req.params.memberId), { type: 'all' });
    if (!ministry || !member) return next();

    removeMember(ministry.id, member.id);
    recordAudit({
      req, action: 'ministry.member_removed', entityType: 'ministry', entityId: ministry.id,
      detail: { member_id: member.id }
    });
    req.flash('success', `${displayName(member)} is no longer serving in ${ministry.name}. The record is kept.`);
    return res.redirect(`/ministries/${ministry.id}`);
  });

// --- Who is serving, and who is not ----------------------------------------

router.get('/ministries/serving', requireAuth, requirePermission('members.view'), (req, res) => {
  const overview = ministryOverview();
  // One list at a time (a tab), each server-side paged, searchable, filterable and sortable.
  const list = req.query.list === 'several' ? 'several' : 'not_serving';
  const search = String(req.query.q || '').slice(0, 60).trim();
  const cellGroupId = Number.parseInt(req.query.cell_group_id, 10) || null;
  const ministries = listMinistries({ includeInactive: false });
  const ministryId = ministries.some((m) => m.id === Number.parseInt(req.query.ministry_id, 10))
    ? Number.parseInt(req.query.ministry_id, 10) : null;
  const sortColumns = list === 'several' ? SERVING_SEVERAL_SORT_COLUMNS : NOT_SERVING_SORT_COLUMNS;
  const sort = sortColumns.includes(req.query.sort) ? req.query.sort : (list === 'several' ? 'ministries' : 'member');
  const direction = req.query.direction === 'asc' || req.query.direction === 'desc'
    ? req.query.direction : (list === 'several' ? 'desc' : 'asc');
  const requested = parsePaging(req.query);

  const fetchPage = (offset, limit) => (list === 'several'
    ? searchServingSeveral({ search, cellGroupId, ministryId, sort, direction, limit, offset })
    : searchNotServing({ search, cellGroupId, sort, direction, limit, offset }));
  const paging = pageWindow({ total: fetchPage(0, 1).total, ...requested });
  const { rows } = fetchPage(paging.offset, paging.pageSize);

  res.render('ministries/serving', {
    title: 'Who is serving',
    overview,
    several: { length: searchServingSeveral({ limit: 1 }).total },
    list,
    rows,
    paging,
    pagerParams: {
      list: list === 'several' ? 'several' : '', q: search, cell_group_id: cellGroupId, ministry_id: ministryId,
      sort, direction, page_size: paging.pageSize === 25 ? '' : paging.pageSize
    },
    ministries,
    cellGroups: activeGroupOptions(),
    filters: { sort, direction, search, cellGroupId, ministryId },
    canManage: req.user.can('ministries.manage')
  });
});

export default router;
