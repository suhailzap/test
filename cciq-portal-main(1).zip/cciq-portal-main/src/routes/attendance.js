import { atomicRouter } from '../lib/atomic-router.js';
import { requireAuth, requirePermission, requireAnyPermission, checkinAccess } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { looksLikePhone, echoableTerm } from '../lib/phone.js';
import { submitOnce } from '../lib/submit-guard.js';
import { collectExpressInput, registerFirstTimerAtDesk, searchInvitersForDesk, INVITER_SEARCH_MIN } from '../services/express-registration.js';

import { AGE_GROUPS, AGE_GROUP_LABELS, congregationFor, attendanceByCongregation } from '../services/congregations.js';
import { recordAudit, AUDIT } from '../lib/audit.js';
import { today, addDays } from '../lib/dates.js';
import {
  ensureFridaySessions, listFridayServices, getNextFridayService, scheduleStatus, FRIDAY_SERVICE
} from '../services/friday-service.js';
import {
  sessionRoster,
  getSession,
  recordAttendance,
  updateSession,
  createSession,
  listSessions,
  memberAttendanceHistory,
  memberAttendanceSummary,
  cellGroupBreakdown,
  cellGroupAttendanceSummary,
  attendanceReport,
  attendanceReportCsv,
  attendanceOverview,
  ATTENDANCE_REPORT_SORT_COLUMNS,
  sessionSummary,
  followUpList,
  followUpStatus,
  FOLLOWUP_SORT_COLUMNS,
  longAbsenceReview,
  LONG_ABSENCE_SORT_COLUMNS,
  attendanceTrend,
  ATTENDANCE_STATUSES,
  SESSION_STATUSES,
  SESSION_SORT_KEYS,
  searchPeopleForAttendance,
  resolvePeopleForReview,
  existingAttendanceStatus,
  recordAttendanceForPeople,
  familyCheckinContext,
  suggestedFamilyMembersForReview,
  parseAttendanceStatusFilter
} from '../services/attendance.js';
import { activeGroupOptions, getGroup } from '../services/cell-groups.js';
import {
  getMember, scopeFor, displayName, pickerCardFor, MEMBER_STATUSES, STATUS_LABELS, CURRENT_POPULATION_STATUSES
} from '../services/members.js';
import { findMemberByQrToken, checkinSession, confirmCheckin, checkedInState } from '../services/qr-checkin.js';
import { classifySession, hasExpectedSnapshot, isTrackingConfigured } from '../services/attendance-tracking.js';
import { parsePaging, paginateList, serverPaged, pageSizeParam } from '../lib/paging.js';
import { attendanceDrillDown, DRILL_METRICS, DRILL_METRIC_KEYS, DRILL_SORTS } from '../services/attendance-people.js';
import {
  LIFECYCLE_LABELS,
  LIFECYCLE_MESSAGES,
  previewFinalization,
  finalizeAttendance,
  markAttendanceNotTaken,
  reopenAttendance,
  correctFinalizedAttendance,
  changeSessionStatus,
  checkinClosure,
  isServiceDateLocked,
  computeSessionSummary,
  expectedRosterForSession,
  CORRECTION_TARGETS,
  correctionCandidates
} from '../services/attendance-lifecycle.js';

const router = atomicRouter();

// Operator-facing wording for the reasons the shared attendance write service
// (assertSessionMutable() in services/attendance.js) can refuse a write.
const ATTENDANCE_REFUSAL_MESSAGES = {
  ...LIFECYCLE_MESSAGES,
  session_cancelled: 'This service was cancelled. Reinstate it before recording attendance.',
  session_in_future: 'This service has not happened yet.',
  session_not_found: 'That session could not be found.'
};

/** Whether ordinary attendance writes are closed for this session by its lifecycle (finalized / not taken). */
function lifecycleClosed(session) {
  return checkinClosure(session) !== null;
}

/** Leaders may record only for the groups they lead. */
/**
 * Administrators work with the whole roster. A cell group leader works only
 * with the members of the groups they lead, on any session.
 */
function rosterRestriction(user) {
  if (user.can('attendance.manage_sessions') || user.can('cellgroups.view')) return null;
  if (user.can('cellgroups.manage_own')) return user.ledCellGroupIds;
  return [];
}

function canRecordFor(user, session) {
  if (user.can('attendance.manage_sessions')) return true;
  if (!user.can('attendance.record')) return false;
  if (session.service_type === FRIDAY_SERVICE) return true;
  if (session.cell_group_id) return user.ledCellGroupIds.includes(session.cell_group_id);
  return true;
}

// --- Dashboard -------------------------------------------------------------

/** How many rows each landing-page card previews before "See all". */
const LANDING_PREVIEW = { people: 5, cellGroups: 6 };

router.get('/attendance', requireAuth, requirePermission('attendance.view'), (req, res) => {
  const overview = attendanceOverview();
  const schedule = scheduleStatus();
  const breakdownAll = overview.latest ? cellGroupBreakdown(overview.latest.session.id) : [];

  res.render('attendance/index', {
    title: 'Attendance',
    trackingStarted: isTrackingConfigured(),
    schedule,
    fridayTitle: schedule.title || 'CCIQ Friday Service',
    nextService: getNextFridayService(),
    latest: overview.latest,
    // Bounded previews - the full lists live on their own pages ("See all").
    breakdown: breakdownAll.slice(0, LANDING_PREVIEW.cellGroups),
    breakdownTotal: breakdownAll.length,
    flagged: overview.flagged.slice(0, LANDING_PREVIEW.people),
    flaggedTotal: overview.flagged.length,
    longAbsence: req.user.can('attendance.followup')
      ? (() => { const review = longAbsenceReview({ limit: 1000 }); return { ...review, rows: review.rows.slice(0, LANDING_PREVIEW.people), total: review.rows.length }; })()
      : null,
    landingPreview: LANDING_PREVIEW,
    awaiting: overview.awaiting.slice(0, 10),
    awaitingTotal: overview.awaiting.length,
    followUp: overview.followUp,
    canDrillDown: rosterRestriction(req.user) === null,
    trend: attendanceTrend({ points: 8 })
  });
});

// --- QR check-in kiosk -------------------------------------------------------
//
// A scanned code is looked up and shown back — name and photo — before
// anything is recorded, so a wrong or old scan never silently marks the
// wrong person present. Nothing is written until that confirmation step is
// answered explicitly.

// Every check-in route below is guarded by `checkinAccess` (middleware/auth.js): an attendance permission AND the standing to operate the check-in interface (the Kiosk
// account, Church Admin or Super Admin). A Cell Group leader or a Member is refused all of it, whatever permissions they hold.

/**
 * A kiosk-role account never sees the normal admin shell — every render on
 * this shared checkin/review flow uses the restricted layout for that role
 * and falls back to the ordinary one (undefined -> 'app') for every other
 * account, so nothing changes for the humans who already use this screen.
 */
function checkinLayout(req) {
  return req.user.hasRole('kiosk') || req.body?.kiosk === '1' ? 'kiosk' : undefined;
}

function checkinHome(req) {
  return checkinLayout(req) === 'kiosk' ? '/kiosk' : '/attendance/checkin';
}

router.get('/attendance/checkin', requireAuth, checkinAccess, (req, res) => {
  const session = checkinSession();
  const term = String(req.query.q || '').slice(0, 80);
  // A mobile number is never accepted in the address bar (it would live on in browser history and logs); it is searched by POST.
  if (looksLikePhone(term)) return res.redirect('/attendance/checkin');
  const results = session && !checkinClosure(session) && term ? searchPeopleForAttendance(term) : [];

  res.render('attendance/checkin', {
    title: 'Scan to confirm attendance',
    session,
    checkinClosed: checkinClosure(session),
    term,
    searched: Boolean(term),
    canExpressRegister: req.user.can('visitors.express_register'),
    results,
    layout: checkinLayout(req)
  });
});

/**
 * The search box posts here, so a mobile number typed to find a returning First Timer is never part of a URL. The screen is the same
 * one the GET renders; a phone-shaped term is searched but not echoed (no value attribute, no hidden field, no link).
 */
router.post('/attendance/checkin/search', requireAuth, checkinAccess, (req, res) => {
  const session = checkinSession();
  const rawTerm = String(req.body.q || '').slice(0, 80);
  const closure = checkinClosure(session);
  const results = session && !closure && rawTerm ? searchPeopleForAttendance(rawTerm) : [];
  const layout = checkinLayout(req);
  const view = {
    session,
    checkinClosed: closure,
    term: echoableTerm(rawTerm),
    searched: Boolean(rawTerm),
    results,
    selected: new Set(),
    layout
  };
  if (layout === 'kiosk') return res.render('kiosk/home', { ...view, title: 'Attendance Kiosk', checkedIn: checkedInState(), canExpressRegister: req.user.can('visitors.express_register') });
  res.render('attendance/checkin', { ...view, title: 'Scan to confirm attendance', canExpressRegister: req.user.can('visitors.express_register') });
});

/**
 * Express First Timer Registration: register a brand-new First Timer and check them in to today's service in one step. Needs the narrow
 * visitors.express_register permission (the Kiosk role has it). A possible duplicate is never overridable here; see
 * services/express-registration.js for what is deliberately left to the owner.
 */
function renderExpressForm(req, res, { status = 200, values = {}, errors = {}, problem = null, problemKind = 'error' } = {}) {
  const session = checkinSession();
  const closure = checkinClosure(session);
  if (!session || closure) {
    req.flash('error', session ? closure.message : 'There is no Friday Service scheduled for today.');
    return res.redirect(checkinHome(req));
  }
  // The chosen inviter is shown again from the database (never from what the form sent back), so a forged name or id cannot appear on the desk screen.
  const inviter = pickerCardFor(values.invited_by_member_id);
  return res.status(status).render('attendance/checkin-first-timer', {
    title: 'First time here?', session, values, errors, problem, problemKind, layout: checkinLayout(req),
    invitedBySelected: inviter ? { id: inviter.id, name: inviter.name } : null, inviterMinChars: INVITER_SEARCH_MIN
  });
}

router.get('/attendance/checkin/first-timer', requireAuth, requirePermission('visitors.express_register'), checkinAccess,
  (req, res) => renderExpressForm(req, res));

/**
 * The desk's "Invited by" search for Express Registration: names only, three characters or more, eight at most (services/express-registration.js).
 * Needs the same narrow permission as the registration itself, and is reachable from a Kiosk session (it sits under /attendance/checkin).
 */
router.get('/attendance/checkin/inviter-search', requireAuth, requirePermission('visitors.express_register'), checkinAccess, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(searchInvitersForDesk(String(req.query.q || '').slice(0, 80)));
});

/**
 * After a successful registration the registration tab (opened from the desk or from the Kiosk) shows a clean "done" page, in the Kiosk's own layout for a Kiosk;
 * the check-in tab it was opened from is untouched.
 */
router.get('/attendance/checkin/first-timer/done', requireAuth, requirePermission('visitors.express_register'), checkinAccess, (req, res) => {
  const name = req.session.expressRegistered;
  if (!name) return res.redirect(checkinHome(req));
  return res.render('attendance/checkin-first-timer-done', { title: 'Registered and checked in', name, backHref: checkinHome(req), layout: checkinLayout(req) });
});

router.post('/attendance/checkin/first-timer', requireAuth, requirePermission('visitors.express_register'), checkinAccess, submitOnce(), (req, res) => {
  const v = collectExpressInput(req.body);
  if (!v.valid) return renderExpressForm(req, res, { status: 400, values: req.body, errors: v.errors });

  const result = registerFirstTimerAtDesk(v.values, { userId: req.user.id, req });
  if (result.ok) {
    // The registration opened in its own tab (from the kiosk as from the desk): it ends on a clean "done" page, and the check-in tab it was opened from is untouched.
    req.session.expressRegistered = result.visitor.first_name;
    return res.redirect('/attendance/checkin/first-timer/done');
  }
  if (result.reason === 'possible_duplicate') {
    // Deliberately names no one: the desk must not learn who is on file. Nothing was saved.
    return renderExpressForm(req, res, {
      status: 409, values: req.body, problemKind: 'duplicate',
      problem: 'You may already be on file. Please go back and search for your name or your whole mobile number, or ask a welcome-team member for help.'
    });
  }
  if (result.reason === 'inviter_not_found') {
    return renderExpressForm(req, res, { status: 400, values: { ...req.body, invited_by_member_id: '' }, errors: { invited_by_member_id: 'Choose the member from the search results. That member could not be found.' } });
  }
  req.flash('error', result.message || 'Registration is not possible right now.');
  return res.redirect(checkinHome(req));
});

router.post('/attendance/checkin/lookup', requireAuth, checkinAccess, (req, res) => {
  const token = String(req.body.token || '').trim();
  if (!token) return res.status(400).json({ ok: false, error: 'No code was read. Try scanning again.' });

  const member = findMemberByQrToken(token);
  if (!member) return res.status(404).json({ ok: false, error: 'That code does not match any member on file.' });
  if (member.retired) {
    return res.status(410).json({
      ok: false,
      error: 'This code is no longer active \u2014 a newer one was issued. Ask the member to open their QR code page again for their current code.'
    });
  }

  // A member's current membership status never blocks recording their
  // attendance here \u2014 someone away for years can check in again the moment
  // they return, and this screen never reasons about that status either
  // way. See CCIQ_DECISIONS.md.

  const session = checkinSession();
  if (!session) return res.status(409).json({ ok: false, error: 'There is no Friday Service scheduled for today.' });
  const closure = checkinClosure(session);
  if (closure) return res.status(409).json({ ok: false, reason: closure.reason, error: closure.message });

  res.json({
    ok: true,
    member: {
      id: member.id,
      name: displayName(member),
      memberCode: member.member_code,
      // So the kiosk can say "already checked in" instead of offering to confirm someone who is already recorded.
      existingStatus: existingAttendanceStatus(session.id, member.id),
      photoUrl: member.photo_path ? `/media/members/${member.id}/photo` : null
    },
    session: { id: session.id, date: session.service_date },
    // Family membership is only ever a selection convenience here — nothing
    // is written by this lookup, and nobody besides the scanned member is
    // ever assumed present. See familyCheckinContext() in services/attendance.js.
    family: familyCheckinContext(member.id, session.id)
  });
});

router.post('/attendance/checkin/confirm', requireAuth, checkinAccess, (req, res) => {
  const memberId = Number.parseInt(req.body.member_id, 10);
  const sessionId = Number.parseInt(req.body.session_id, 10);
  const member = memberId ? getMember(memberId) : null;
  if (!member || !sessionId) return res.status(400).json({ ok: false, error: 'That check-in could not be found. Scan again.' });

  const result = confirmCheckin(member.id, sessionId, { userId: req.user.id });
  if (!result.ok) {
    // confirmCheckin() refuses any session_id that isn't the live front
    // door's actual current session - a stale tab, a direct POST, or a
    // guessed id all land here rather than silently writing into whatever
    // session was named.
    recordAudit({
      req, action: AUDIT.QR_CHECKIN_CONFIRMED, entityType: 'member', entityId: member.id,
      result: 'failure', detail: { sessionId, reason: result.reason }
    });
    if (result.reason === 'session_finalized' || result.reason === 'session_not_taken') {
      return res.status(409).json({ ok: false, reason: result.reason, error: 'Check-in is closed: attendance for this service has been finalized or marked not taken.' });
    }
    return res.status(409).json({ ok: false, error: 'That check-in session is no longer current. Scan again.' });
  }
  recordAudit({
    req, action: AUDIT.QR_CHECKIN_CONFIRMED, entityType: 'member', entityId: member.id,
    detail: { sessionId, alreadyCheckedIn: result.alreadyCheckedIn }
  });

  res.json({ ok: true, name: displayName(member), alreadyCheckedIn: result.alreadyCheckedIn });
});

/** Turns the raw "type:id" values a selection form posts into typed, validated pairs. */
function parseSelection(body) {
  const raw = Array.isArray(body.person) ? body.person : (body.person ? [body.person] : []);
  const people = [];
  for (const value of raw) {
    const match = /^(member|visitor):(\d+)$/.exec(String(value));
    if (match) people.push({ type: match[1], id: Number(match[2]) });
  }
  return people;
}

/**
 * Search results are only ever the start of the workflow. The person an
 * usher taps is not recorded on that click — their selection is carried
 * forward and re-resolved here, from the database, so the review step
 * always shows the person's actual current name and photo, never whatever
 * the browser happened to submit.
 */
router.post('/attendance/checkin/review', requireAuth, checkinAccess, (req, res) => {
  const session = checkinSession();
  if (!session) {
    req.flash('error', 'There is no Friday Service scheduled for today.');
    return res.redirect(checkinHome(req));
  }
  const closure = checkinClosure(session);
  if (closure) {
    req.flash('error', closure.message);
    return res.redirect(checkinHome(req));
  }

  const term = echoableTerm(String(req.body.q || '').slice(0, 80));
  const selection = parseSelection(req.body);
  const people = resolvePeopleForReview(selection, session.id);

  if (people.length === 0) {
    req.flash('error', 'Choose at least one person before reviewing.');
    const home = checkinHome(req);
    return res.redirect(term ? `${home}?q=${encodeURIComponent(term)}` : home);
  }

  res.render('attendance/checkin-review', {
    title: 'Review before recording attendance',
    session,
    term,
    people,
    suggestions: suggestedFamilyMembersForReview(selection, session.id),
    layout: checkinLayout(req),
    backHref: checkinHome(req),
    isKiosk: checkinLayout(req) === 'kiosk',
    checkedIn: checkinLayout(req) === 'kiosk' ? checkedInState() : null
  });
});

router.post('/attendance/checkin/record', requireAuth, checkinAccess, (req, res) => {
  const wantsJson = req.get('Accept') === 'application/json';
  const session = checkinSession();
  if (!session) {
    if (wantsJson) return res.status(409).json({ ok: false, error: 'No Friday Service is available. Ask an administrator.' });
    req.flash('error', 'There is no Friday Service scheduled for today.');
    return res.redirect(checkinHome(req));
  }

  const selection = parseSelection(req.body);
  if (selection.length === 0) {
    if (wantsJson) return res.status(400).json({ ok: false, error: 'Choose at least one person before confirming.' });
    req.flash('error', 'Choose at least one person before recording attendance.');
    return res.redirect(checkinHome(req));
  }

  const result = recordAttendanceForPeople(session.id, selection, { userId: req.user.id });
  if (!result.ok) {
    // The shared write gate refused (finalized, not taken, cancelled, ...):
    // never report a refused write as recorded.
    const message = ATTENDANCE_REFUSAL_MESSAGES[result.reason] || 'Attendance could not be recorded for this service.';
    recordAudit({
      req, action: 'attendance.quick_recorded', entityType: 'attendance_session', entityId: session.id,
      result: 'failure', detail: { service_date: session.service_date, reason: result.reason }
    });
    if (wantsJson) return res.status(409).json({ ok: false, reason: result.reason, error: message });
    req.flash('error', message);
    return res.redirect(checkinHome(req));
  }
  recordAudit({
    req, action: 'attendance.quick_recorded', entityType: 'attendance_session', entityId: session.id,
    detail: {
      service_date: session.service_date,
      newly: result.newly.map((p) => ({ type: p.type, id: p.id })),
      already: result.already.map((p) => ({ type: p.type, id: p.id }))
    }
  });

  const names = (list) => list.map((p) => p.name);
  if (wantsJson) return res.json({ ok: result.ok, newly: names(result.newly), already: names(result.already) });
  if (result.newly.length === 0 && result.already.length > 0) {
    req.flash('info', `Already recorded: ${names(result.already).join(', ')}.`);
  } else if (result.already.length > 0) {
    req.flash('success',
      `Attendance recorded for ${result.newly.length} ${result.newly.length === 1 ? 'person' : 'people'}: `
      + `${names(result.newly).join(', ')}. Already recorded: ${names(result.already).join(', ')}.`);
  } else {
    req.flash('success',
      `Attendance recorded for ${result.newly.length} ${result.newly.length === 1 ? 'person' : 'people'}: `
      + `${names(result.newly).join(', ')}.`);
  }

  return res.redirect(checkinHome(req));
});

// --- Friday Services -------------------------------------------------------

const UPCOMING_SERVICES_DEFAULT_LIMIT = 3;
const PAST_SERVICES_DEFAULT_LIMIT = 20;

router.get('/attendance/friday', requireAuth, requirePermission('attendance.view'), (req, res) => {
  const schedule = scheduleStatus();
  const showAllUpcoming = req.query.upcoming === 'all';

  /*
   * Upcoming and past are fetched as two separate queries, not one shared
   * top-N-by-date query — a session table that also holds many months of
   * already-generated future 'scheduled' Fridays means a single DESC+LIMIT
   * query has its budget eaten by those future rows, silently pushing real
   * past history out of the result before it ever reaches this page. See
   * CCIQ_DECISIONS.md for the real-portal case this was found from.
   */
  const upcomingAll = listFridayServices({ from: addDays(today(), 1), direction: 'asc', limit: 500 })
    .map((s) => ({ ...s, summary: sessionSummary(s.id) }));
  const pastAll = listFridayServices({ to: today(), direction: 'desc', limit: 500 })
    .map((s) => ({ ...s, summary: sessionSummary(s.id) }));

  res.render('attendance/friday', {
    title: 'Friday Service attendance',
    fridayTitle: schedule.title || 'CCIQ Friday Service',
    schedule,
    upcoming: showAllUpcoming ? upcomingAll : upcomingAll.slice(0, UPCOMING_SERVICES_DEFAULT_LIMIT),
    upcomingTotal: upcomingAll.length,
    showAllUpcoming,
    past: pastAll.slice(0, PAST_SERVICES_DEFAULT_LIMIT),
    pastTotal: pastAll.length
  });
});

router.post('/attendance/friday/generate', requireAuth, requirePermission('attendance.manage_sessions'), (req, res) => {
  const result = ensureFridaySessions({ userId: req.user.id });
  recordAudit({ req, action: 'attendance.schedule_generated', entityType: 'attendance_session', detail: result });
  req.flash(
    result.created ? 'success' : 'info',
    result.created
      ? `${result.created} Friday Service${result.created === 1 ? '' : 's'} added to the schedule.`
      : 'The Friday Service schedule is already complete for the configured period.'
  );
  res.redirect('/attendance/friday');
});

// --- Other sessions --------------------------------------------------------

router.get('/attendance/sessions/new', requireAuth, requirePermission('attendance.manage_sessions'), (req, res) => {
  res.render('attendance/session-form', {
    title: 'Add a session',
    values: { service_date: today(), service_type: 'special_service' },
    errors: {},
    cellGroups: activeGroupOptions()
  });
});

router.post('/attendance/sessions', requireAuth, requirePermission('attendance.manage_sessions'), (req, res) => {
  const v = new Validator(req.body);
  v.text('title', { required: true, max: 120, label: 'Title' });
  v.date('service_date', { required: true, label: 'Date' });
  v.time('start_time', { label: 'Start time' });
  v.text('location', { max: 200, label: 'Location' });
  v.integer('cell_group_id', { label: 'Cell group' });
  v.oneOf('service_type', ['special_service', 'cell_group'], { required: true, label: 'Session type', fallback: 'special_service' });
  v.text('notes', { max: 1000, label: 'Notes' });

  if (!v.valid) {
    return res.status(400).render('attendance/session-form', {
      title: 'Add a session',
      values: req.body,
      errors: v.errors,
      cellGroups: activeGroupOptions()
    });
  }

  const session = createSession(v.values, { userId: req.user.id });
  recordAudit({
    req, action: 'attendance.session_created', entityType: 'attendance_session', entityId: session.id,
    detail: { title: session.title, date: session.service_date, type: session.service_type }
  });
  req.flash('success', 'Session added. It does not affect Friday Service follow-up.');
  return res.redirect(`/attendance/sessions/${session.id}`);
});

// --- Recording sheet -------------------------------------------------------

router.get('/attendance/sessions/:id(\\d+)', requireAuth, requirePermission('attendance.view'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();

  const groupFilter = Number.parseInt(req.query.cell_group_id, 10) || null;
  const search = String(req.query.q || '').slice(0, 60);
  const restrictToGroupIds = rosterRestriction(req.user);
  // The client filters and pages the complete authorized roster. Drafts stay keyed by member ID.
  const roster = sessionRoster(session.id, { restrictToGroupIds })
    .map((m) => ({ ...m, congregation: congregationFor(m) }));

  // The church meets as Kids, Teens and Adults on the same Friday, so the
  // sheet can be narrowed to the congregation being registered.
  const congregation = AGE_GROUPS.includes(req.query.congregation) ? req.query.congregation : null;

  // "Find a member" above only searches the sheet itself — the people
  // normally expected at this service. This second, separate search reaches
  // the whole church record regardless of status, for someone who would not
  // otherwise be on this sheet at all (see CCIQ_DECISIONS.md).
  const addTerm = String(req.query.addq || '').slice(0, 60);
  const addResults = addTerm ? searchPeopleForAttendance(addTerm) : [];

  const lifecycle = classifySession(session);
  res.render('attendance/session-register', {
    title: `${session.title || 'Session'} — ${session.service_date}`,
    session,
    roster,
    summary: sessionSummary(session.id),
    canDrillDown: rosterRestriction(req.user) === null,
    breakdown: session.service_type === FRIDAY_SERVICE ? cellGroupBreakdown(session.id) : [],
    // Ordinary recording is closed once a Friday is finalized or marked not taken.
    canRecord: canRecordFor(req.user, session) && !lifecycleClosed(session),
    lifecycle,
    lifecycleLabel: LIFECYCLE_LABELS[lifecycle.phase],
    lifecycleSummary: lifecycle.tracked && !lifecycle.cancelled
      ? computeSessionSummary(session, expectedRosterForSession(session), lifecycle.phase) : null,
    canFinalize: req.user.can('attendance.finalize'),
    snapshotPreserved: hasExpectedSnapshot(session.id),
    canManage: req.user.can('attendance.manage_sessions'),
    statuses: ATTENDANCE_STATUSES,
    sessionStatuses: SESSION_STATUSES,
    cellGroups: activeGroupOptions(),
    congregations: AGE_GROUPS,
    congregationLabels: AGE_GROUP_LABELS,
    congregationSplit: session.service_type === FRIDAY_SERVICE ? attendanceByCongregation(session.id) : null,
    addTerm,
    addResults,
    filters: { cellGroupId: groupFilter, search, congregation }
  });
});

router.post('/attendance/sessions/:id(\\d+)/records', requireAuth, requirePermission('attendance.record'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();

  if (!canRecordFor(req.user, session)) {
    const err = new Error('You can only record attendance for your own cell group.');
    err.status = 403;
    return next(err);
  }
  if (session.status === 'cancelled') {
    req.flash('error', 'This service was cancelled. Reinstate it before recording attendance.');
    return res.redirect(`/attendance/sessions/${session.id}`);
  }

  // Field names arrive as status_<memberId>, so only members on the sheet are
  // touched, and a leader's submission is limited to their own group whatever
  // the browser sent.
  const restrictToGroupIds = rosterRestriction(req.user);
  const allowedIds = restrictToGroupIds === null
    ? null
    : new Set(sessionRoster(session.id, { restrictToGroupIds }).map((m) => m.id));

  const entries = [];
  let skipped = 0;
  for (const [key, value] of Object.entries(req.body)) {
    if (!key.startsWith('status_')) continue;
    const memberId = Number(key.slice('status_'.length));
    if (!memberId) continue;
    if (allowedIds && !allowedIds.has(memberId)) { skipped += 1; continue; }
    entries.push({
      memberId,
      status: ATTENDANCE_STATUSES.includes(value) ? value : null,
      notes: req.body[`notes_${memberId}`] || null
    });
  }

  const result = recordAttendance(session.id, entries, { userId: req.user.id });
  if (!result.ok) {
    // recordAttendance() is the single authority on whether this session may
    // be written to (cancelled, future-dated, missing). A refusal must never
    // be reported as success - not by a flash, not by a JSON ok, not by an
    // audit row claiming attendance was recorded.
    const message = ATTENDANCE_REFUSAL_MESSAGES[result.reason] || 'Attendance could not be recorded for this service.';
    recordAudit({
      req, action: 'attendance.recorded', entityType: 'attendance_session', entityId: session.id,
      result: 'failure', detail: { service_date: session.service_date, reason: result.reason }
    });
    if (req.get('accept') === 'application/json') {
      return res.status(409).json({ ok: false, reason: result.reason, error: message });
    }
    req.flash('error', message);
    return res.redirect(`/attendance/sessions/${session.id}`);
  }
  recordAudit({
    req, action: 'attendance.recorded', entityType: 'attendance_session', entityId: session.id,
    detail: {
      service_date: session.service_date, saved: result.saved,
      cleared: result.cleared, outside_scope_ignored: skipped
    }
  });

  if (req.get('accept') === 'application/json') {
    return res.json({ ok: true, saved: result.saved, cleared: result.cleared, skipped });
  }
  req.flash('success', `Attendance saved for ${result.saved} member${result.saved === 1 ? '' : 's'}.`);
  return res.redirect(`/attendance/sessions/${session.id}`);
});

/**
 * The search behind /add is deliberately status/scope-blind (see the
 * comment on searchPeopleForAttendance's caller) — this is the one place
 * that must actually enforce a Cell Group Leader's scope, matching what
 * /records already does for the roster form. A selection outside scope is
 * silently dropped (not an error), same pattern as /records' own
 * `skipped` count — a leader clicking a broad search result they shouldn't
 * have reached is not itself suspicious enough to bounce the whole request.
 * Visitors have no cell-group concept until converted to a member record,
 * so they are intentionally left unrestricted here — scoping them would
 * break ordinary visitor check-in for exactly the leaders/ushers who most
 * need this screen to work.
 */
function scopeSelectionForRecording(selection, restrictToGroupIds) {
  if (restrictToGroupIds === null) return { allowed: selection, skipped: [] };
  const allowed = [];
  const skipped = [];
  for (const person of selection) {
    if (person.type === 'visitor') { allowed.push(person); continue; }
    const member = getMember(person.id);
    if (member && restrictToGroupIds.includes(member.cell_group_id)) {
      allowed.push(person);
    } else {
      skipped.push(person);
    }
  }
  return { allowed, skipped };
}

/**
 * Adds someone found through the broader, status-blind search to this one
 * session — reusing the exact same recordAttendanceForPeople() the entrance
 * check-in page uses, so there is one recording path, not two. This never
 * adds the person to any other session's default roster; they simply gain
 * an attendance_records row for this session, which is what makes
 * sessionRoster() show them on this sheet from now on (see
 * services/attendance.js and CCIQ_DECISIONS.md).
 */
router.post('/attendance/sessions/:id(\\d+)/add', requireAuth, requirePermission('attendance.record'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();

  if (!canRecordFor(req.user, session)) {
    const err = new Error('You can only record attendance for your own cell group.');
    err.status = 403;
    return next(err);
  }

  const addTerm = String(req.body.addq || '').slice(0, 60);
  const selection = parseSelection(req.body);
  const redirectTo = `/attendance/sessions/${session.id}${addTerm ? `?addq=${encodeURIComponent(addTerm)}` : ''}`;

  if (selection.length === 0) {
    req.flash('error', 'Choose someone to add before continuing.');
    return res.redirect(redirectTo);
  }

  const { allowed, skipped } = scopeSelectionForRecording(selection, rosterRestriction(req.user));
  if (allowed.length === 0) {
    req.flash('error', 'You can only add members from your own cell group.');
    return res.redirect(redirectTo);
  }

  const result = recordAttendanceForPeople(session.id, allowed, { userId: req.user.id, status: 'present' });
  if (!result.ok) {
    // recordAttendanceForPeople() itself refuses a cancelled or future-dated
    // session - the route has no earlier check of its own for this (unlike
    // /records), so this is the only place it's ever surfaced for /add.
    req.flash('error', ATTENDANCE_REFUSAL_MESSAGES[result.reason] || 'Attendance could not be recorded for this service.');
    return res.redirect(redirectTo);
  }
  recordAudit({
    req, action: 'attendance.added_from_search', entityType: 'attendance_session', entityId: session.id,
    detail: {
      service_date: session.service_date,
      newly: result.newly.map((p) => ({ type: p.type, id: p.id })),
      already: result.already.map((p) => ({ type: p.type, id: p.id })),
      outside_scope_skipped: skipped.map((p) => ({ type: p.type, id: p.id }))
    }
  });

  if (result.newly.length > 0) {
    req.flash('success', `Added ${result.newly.map((p) => p.name).join(', ')} as present for this service.`);
  } else if (result.already.length > 0) {
    req.flash('info', `${result.already.map((p) => p.name).join(', ')} already recorded for this service.`);
  }
  if (skipped.length > 0) {
    req.flash('error', `${skipped.length} selection${skipped.length === 1 ? '' : 's'} outside your cell group were not added.`);
  }
  return res.redirect(redirectTo);
});

router.post('/attendance/sessions/:id(\\d+)/status', requireAuth, requirePermission('attendance.manage_sessions'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();

  const v = new Validator(req.body);
  const status = v.oneOf('status', SESSION_STATUSES, { required: true, label: 'Status' });
  const notes = v.text('notes', { max: 500, label: 'Notes' });
  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/attendance/sessions/${session.id}`);
  }

  // Goes through the lifecycle service: a finalized or not-taken service can
  // never be moved back to Scheduled, cancelling one needs a reason, and the
  // finalization state, snapshot and attendance are preserved either way.
  const changed = changeSessionStatus(session.id, status, { userId: req.user.id, req, notes });
  if (!changed.ok) {
    req.flash('error', ATTENDANCE_REFUSAL_MESSAGES[changed.reason] || 'The service status could not be changed.');
    return res.redirect(`/attendance/sessions/${session.id}`);
  }

  req.flash('success', status === 'cancelled'
    ? 'Service marked as cancelled. It is excluded from Friday Service follow-up.'
    : `Service marked as ${status}.`);
  return res.redirect(`/attendance/sessions/${session.id}`);
});

router.post('/attendance/sessions/:id(\\d+)', requireAuth, requirePermission('attendance.manage_sessions'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();

  const v = new Validator(req.body);
  v.date('service_date', { required: true, label: 'Date' });
  v.time('start_time', { label: 'Start time' });
  v.text('location', { max: 200, label: 'Location' });
  v.text('notes', { max: 1000, label: 'Notes' });
  const counts = req.body.counts_toward_followup === 'on';

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/attendance/sessions/${session.id}`);
  }

  // A finalized (or previously finalized) service is a historical fact tied to
  // its date: its expected-roster snapshot was taken for THAT date.
  if (v.values.service_date !== session.service_date && isServiceDateLocked(session)) {
    req.flash('error', ATTENDANCE_REFUSAL_MESSAGES.date_locked_by_finalization);
    return res.redirect(`/attendance/sessions/${session.id}`);
  }

  updateSession(session.id, { ...v.values, counts_toward_followup: counts });
  recordAudit({
    req, action: 'attendance.session_updated', entityType: 'attendance_session', entityId: session.id,
    detail: { from: session.service_date, to: v.values.service_date, counts_toward_followup: counts }
  });
  req.flash('success', 'Service details updated.');
  return res.redirect(`/attendance/sessions/${session.id}`);
});

// --- History ---------------------------------------------------------------

router.get('/attendance/history', requireAuth, requirePermission('attendance.view'), (req, res) => {
  const filters = {
    serviceType: ['friday_service', 'cell_group', 'special_service'].includes(req.query.type) ? req.query.type : null,
    from: /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : null,
    to: /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : null,
    cellGroupId: Number.parseInt(req.query.cell_group_id, 10) || null,
    status: SESSION_STATUSES.includes(req.query.status) ? req.query.status : null
  };

  // Latest date first unless the person has chosen a column of their own.
  const sort = SESSION_SORT_KEYS.includes(req.query.sort) ? req.query.sort : 'date';
  const direction = req.query.dir === 'asc' ? 'asc' : 'desc';

  /*
   * This page is Attendance HISTORY: an already-generated future-dated
   * session (most commonly a Friday Service scheduled months ahead) must
   * never appear here, however the request asks to sort or filter. The "To"
   * field can still narrow further into the past; it can never push the
   * query past today. See CCIQ_DECISIONS.md for the real-portal case this
   * was found from — sessions were previously shown with no past/future
   * distinction at all.
   */
  const effectiveTo = filters.to && filters.to < today() ? filters.to : today();

  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listSessions({ ...filters, to: effectiveTo, page, pageSize, sort, direction }),
    parsePaging(req.query)
  );

  res.render('attendance/history', {
    title: 'Attendance history',
    result,
    paging,
    pagerParams: {
      type: filters.serviceType, from: filters.from, to: filters.to, cell_group_id: filters.cellGroupId,
      status: filters.status, sort, dir: direction, page_size: pageSizeParam(paging)
    },
    filters,
    sort,
    direction,
    cellGroups: activeGroupOptions(),
    sessionStatuses: SESSION_STATUSES
  });
});

// --- Attendance drill-down: who is behind a number --------------------------------------------------------------------------------
//
// ONE route for every figure on the Attendance chart and the Friday Service tiles. It lists the people the figure was counted from (attendance-people.js; never a second count),
// searchable, sortable and paged, with a print view of every matching person in canonical surname order. It needs the same access as the full register
// (attendance.view with no cell-group restriction): a Cell Group Leader, who sees only their own group's people, is not offered it, because their list would not add up to the number.

router.get('/attendance/sessions/:id(\\d+)/people', requireAuth, requirePermission('attendance.view'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session || session.service_type !== FRIDAY_SERVICE) return next();
  if (rosterRestriction(req.user) !== null) {
    const err = new Error('Listing who makes up an attendance figure needs access to the whole church register.');
    err.status = 403;
    return next(err);
  }
  const metric = req.query.metric === undefined ? 'total' : String(req.query.metric); // none given means the total; one given must be a known figure (an empty one is not)
  if (!DRILL_METRIC_KEYS.includes(metric)) {
    const err = new Error('That attendance figure is not one that can be listed.');
    err.status = 400;
    return next(err);
  }
  const search = String(req.query.q || '').slice(0, 80).trim();
  const sort = DRILL_SORTS.includes(req.query.sort) ? req.query.sort : 'name';
  const direction = req.query.dir === 'desc' ? 'desc' : 'asc';
  const paging = parsePaging(req.query);
  const result = attendanceDrillDown(session, metric, { search, sort, direction, ...paging });
  if (!result) return next(); // a figure this service's lifecycle does not show (for example Absent before finalization) has no list

  const stamp = new Date();
  const printed = `${stamp.toLocaleDateString('en-GB', { timeZone: 'Asia/Qatar', day: 'numeric', month: 'long', year: 'numeric' })}, ${stamp.toLocaleTimeString('en-GB', { timeZone: 'Asia/Qatar', hour: '2-digit', minute: '2-digit', hour12: false })}`;
  return res.render('attendance/people', {
    title: `${result.label} · ${session.service_date}`,
    session,
    result,
    search, sort, direction,
    printedAt: `${printed} (Qatar time)`,
    pagerParams: { metric, q: search, sort: sort === 'name' && direction === 'asc' ? '' : sort, dir: direction === 'asc' ? '' : direction, page_size: result.window.pageSize === 25 ? '' : result.window.pageSize },
    metricKeys: DRILL_METRIC_KEYS,
    metrics: DRILL_METRICS
  });
});

// --- Follow-up -------------------------------------------------------------

router.get('/attendance/follow-up', requireAuth, requirePermission('attendance.followup'), (req, res) => {
  const sort = Object.keys(FOLLOWUP_SORT_COLUMNS).includes(req.query.sort) ? req.query.sort : 'streak';
  const direction = req.query.dir === 'asc' ? 'asc' : 'desc';
  const everyone = followUpList({ limit: 1_000_000, sort, direction });
  const schedule = scheduleStatus();
  const search = String(req.query.q || '').slice(0, 60).trim();
  const cellGroupId = Number.parseInt(req.query.cell_group_id, 10) || null;
  const matches = (item) => (!cellGroupId || item.member.cell_group_id === cellGroupId)
    && (!search || `${item.member.first_name} ${item.member.last_name} ${item.member.preferred_name || ''} ${item.member.member_code || ''}`
      .toLowerCase().includes(search.toLowerCase()));
  const all = everyone.filter(matches);
  const paging = paginateList(all, parsePaging(req.query));

  res.render('attendance/follow-up', {
    title: 'Friday Service follow-up',
    fridayTitle: schedule.title || 'CCIQ Friday Service',
    flagged: paging.rows,
    total: all.length,
    totalUnfiltered: everyone.length,
    paging,
    pagerParams: { q: search, cell_group_id: cellGroupId, sort, dir: direction === 'asc' ? 'asc' : '', page_size: paging.pageSize === 25 ? '' : paging.pageSize },
    filters: { search, cellGroupId },
    cellGroups: activeGroupOptions(),
    sort,
    direction,
    // Follow-up is only complete once every past tracked Friday has been finalized.
    status: followUpStatus(),
    threshold: everyone[0]?.threshold || followUpStatus().threshold
  });
});

router.get('/attendance/long-absence', requireAuth, requirePermission('attendance.followup'), (req, res) => {
  const sort = Object.keys(LONG_ABSENCE_SORT_COLUMNS).includes(req.query.sort) ? req.query.sort : 'days_away';
  const direction = req.query.dir === 'asc' ? 'asc' : 'desc';
  const review = longAbsenceReview({ limit: 1_000_000, sort, direction });
  const search = String(req.query.q || '').slice(0, 60).trim();
  const state = ['long_absent', 'no_tracked_attendance'].includes(req.query.state) ? req.query.state : null;
  const cellGroupId = Number.parseInt(req.query.cell_group_id, 10) || null;
  const list = review.rows.filter((item) => (!state || item.state === state)
    && (!cellGroupId || item.member.cell_group_id === cellGroupId)
    && (!search || `${item.member.first_name} ${item.member.last_name} ${item.member.preferred_name || ''} ${item.member.member_code || ''}`
      .toLowerCase().includes(search.toLowerCase())));
  const paging = paginateList(list, parsePaging(req.query));

  res.render('attendance/long-absence', {
    title: 'Long absence review',
    list: paging.rows,
    review,
    total: list.length,
    paging,
    pagerParams: { q: search, state, cell_group_id: cellGroupId, sort, dir: direction === 'asc' ? 'asc' : '', page_size: paging.pageSize === 25 ? '' : paging.pageSize },
    filters: { search, state, cellGroupId },
    cellGroups: activeGroupOptions(),
    sort,
    direction
  });
});

// --- Reports ---------------------------------------------------------------

router.get('/attendance/reports', requireAuth, requirePermission('reports.view'), (req, res) => {
  const from = /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : addDays(today(), -84);
  const to = /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : today();
  const cellGroupId = Number.parseInt(req.query.cell_group_id, 10) || null;
  const sort = ATTENDANCE_REPORT_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : null;
  const direction = req.query.direction === 'desc' ? 'desc' : 'asc';
  const statuses = parseAttendanceStatusFilter(req.query);

  const report = attendanceReport({ from, to, cellGroupId, sort, direction, statuses });

  // A church with hundreds of members would otherwise render one enormous
  // page. The CSV and PDF exports still cover everyone in the range.
  const paging = paginateList(report.rows, parsePaging(req.query));
  const paged = { ...report, rows: paging.rows };

  res.render('attendance/reports', {
    title: 'Friday Service attendance report',
    report: paged,
    totalRows: report.rows.length,
    paging,
    pagerParams: {
      from, to, cell_group_id: cellGroupId, statuses_submitted: '1', status: report.statuses,
      sort, direction: sort ? direction : '', page_size: paging.pageSize === 25 ? '' : paging.pageSize
    },
    filters: { from, to, cellGroupId, sort, direction, statuses: report.statuses },
    cellGroups: activeGroupOptions(),
    statuses: MEMBER_STATUSES,
    statusLabels: STATUS_LABELS,
    currentStatuses: CURRENT_POPULATION_STATUSES
  });
});

router.get('/attendance/reports/export.csv', requireAuth, requirePermission('reports.view', 'reports.export'), (req, res) => {
  const from = /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : addDays(today(), -84);
  const to = /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : today();
  const cellGroupId = Number.parseInt(req.query.cell_group_id, 10) || null;
  const statuses = parseAttendanceStatusFilter(req.query);

  const { csv, sessions, members } = attendanceReportCsv({ from, to, cellGroupId, statuses });
  recordAudit({
    req, action: 'attendance.exported', entityType: 'attendance_session',
    detail: { from, to, sessions, members }
  });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="cciq-friday-attendance-${from}-to-${to}.csv"`);
  res.send(csv);
});

// --- Cell group attendance -------------------------------------------------

router.get('/attendance/cell-groups/:id(\\d+)', requireAuth,
  requireAnyPermission('attendance.view', 'cellgroups.manage_own'), (req, res, next) => {
    const id = Number(req.params.id);
    const group = getGroup(id);
    if (!group) return next();

    const canSeeAll = req.user.can('attendance.view');
    if (!canSeeAll && !req.user.ledCellGroupIds.includes(id)) {
      const err = new Error('You can only view attendance for the cell group you lead.');
      err.status = 403;
      return next(err);
    }

    res.render('attendance/cell-group', {
      title: `${group.name} — Friday Service attendance`,
      group,
      summary: cellGroupAttendanceSummary(id, { lastN: 8 }),
      sessions: listSessions({ cellGroupId: id, pageSize: 10 }).rows
    });
  });

// --- A member's own attendance ---------------------------------------------

router.get('/attendance/mine', requireAuth, requirePermission('attendance.view_own'), (req, res) => {
  const memberId = req.user.memberId;
  res.render('attendance/mine', {
    title: 'My attendance',
    fridayTitle: scheduleStatus().title || 'CCIQ Friday Service',
    member: memberId ? getMember(memberId, { type: 'all' }) : null,
    summary: memberId ? memberAttendanceSummary(memberId, { lastN: 12 }) : null,
    history: memberId ? memberAttendanceHistory(memberId, { limit: 30 }) : []
  });
});

router.get('/members/:id(\\d+)/attendance', requireAuth, requirePermission('attendance.view'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  return res.render('attendance/member', {
    title: `${displayName(member)} — Friday Service attendance`,
    member,
    summary: memberAttendanceSummary(member.id, { lastN: 12 }),
    history: memberAttendanceHistory(member.id, { limit: 50 })
  });
});

// --- Finalization lifecycle (Church Admin / Super Admin: attendance.finalize) ---------------
//
// Every action re-checks in the service, inside its own transaction; these
// routes only authorize, parse and report.

function refusalMessage(result) {
  return ATTENDANCE_REFUSAL_MESSAGES[result.reason] || 'That could not be done.';
}

router.get('/attendance/sessions/:id(\\d+)/finalize', requireAuth, requirePermission('attendance.finalize'), (req, res, next) => {
  const preview = previewFinalization(Number(req.params.id));
  if (!preview.ok) return next();
  return res.render('attendance/finalize', {
    title: `Finalize attendance — ${preview.session.service_date}`,
    preview,
    messages: ATTENDANCE_REFUSAL_MESSAGES
  });
});

router.post('/attendance/sessions/:id(\\d+)/finalize', requireAuth, requirePermission('attendance.finalize'), (req, res) => {
  const id = Number(req.params.id);
  const result = finalizeAttendance(id, {
    userId: req.user.id, req, confirmNoAttendance: req.body.confirm_no_attendance === 'on'
  });
  if (!result.ok) {
    req.flash('error', refusalMessage(result));
    return res.redirect(result.reason === 'session_not_found' ? '/attendance/friday' : `/attendance/sessions/${id}/finalize`);
  }
  req.flash('success', 'Attendance finalized. Members who were expected and have no record are now counted absent.');
  return res.redirect(`/attendance/sessions/${id}`);
});

router.get('/attendance/sessions/:id(\\d+)/not-taken', requireAuth, requirePermission('attendance.finalize'), (req, res, next) => {
  const preview = previewFinalization(Number(req.params.id));
  if (!preview.ok) return next();
  return res.render('attendance/not-taken', {
    title: `Attendance not taken — ${preview.session.service_date}`,
    preview,
    messages: ATTENDANCE_REFUSAL_MESSAGES
  });
});

router.post('/attendance/sessions/:id(\\d+)/not-taken', requireAuth, requirePermission('attendance.finalize'), (req, res) => {
  const id = Number(req.params.id);
  const result = markAttendanceNotTaken(id, {
    userId: req.user.id, req, note: req.body.note,
    confirmExistingAttendance: req.body.confirm_existing === 'on'
  });
  if (!result.ok) {
    req.flash('error', refusalMessage(result));
    return res.redirect(result.reason === 'session_not_found' ? '/attendance/friday' : `/attendance/sessions/${id}/not-taken`);
  }
  req.flash('success', 'Marked as attendance not taken. No one is counted absent for this service.');
  return res.redirect(`/attendance/sessions/${id}`);
});

router.get('/attendance/sessions/:id(\\d+)/reopen', requireAuth, requirePermission('attendance.finalize'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();
  const classification = classifySession(session);
  return res.render('attendance/reopen', {
    title: `Reopen attendance — ${session.service_date}`,
    session,
    classification,
    lifecycleLabel: LIFECYCLE_LABELS[classification.phase],
    snapshotPreserved: hasExpectedSnapshot(session.id),
    recordCount: computeSessionSummary(session, expectedRosterForSession(session), classification.phase).attendanceRecords
  });
});

router.post('/attendance/sessions/:id(\\d+)/reopen', requireAuth, requirePermission('attendance.finalize'), (req, res) => {
  const id = Number(req.params.id);
  const result = reopenAttendance(id, { userId: req.user.id, req, reason: req.body.reason });
  if (!result.ok) {
    req.flash('error', refusalMessage(result));
    return res.redirect(result.reason === 'session_not_found' ? '/attendance/friday' : `/attendance/sessions/${id}/reopen`);
  }
  req.flash('success', 'Attendance reopened. Recorded attendance and the expected list were kept; finalize again when ready.');
  return res.redirect(`/attendance/sessions/${id}`);
});

router.get('/attendance/sessions/:id(\\d+)/correct', requireAuth, requirePermission('attendance.finalize'), (req, res, next) => {
  const session = getSession(Number(req.params.id));
  if (!session) return next();
  const classification = classifySession(session);
  const term = String(req.query.q || '').slice(0, 60);
  return res.render('attendance/correct', {
    title: `Correct attendance — ${session.service_date}`,
    session,
    classification,
    lifecycleLabel: LIFECYCLE_LABELS[classification.phase],
    term,
    candidates: classification.phase === 'finalized' ? correctionCandidates(session.id, { q: term }) : [],
    targets: CORRECTION_TARGETS
  });
});

router.post('/attendance/sessions/:id(\\d+)/corrections', requireAuth, requirePermission('attendance.finalize'), (req, res) => {
  const id = Number(req.params.id);
  const changes = [];
  for (const [key, value] of Object.entries(req.body || {})) {
    const m = /^to_(\d+)$/.exec(key);
    if (m && String(value || '')) changes.push({ memberId: Number(m[1]), to: String(value) });
  }
  const result = correctFinalizedAttendance(id, changes, { userId: req.user.id, req, reason: req.body.reason });
  if (!result.ok) {
    req.flash('error', refusalMessage(result));
    return res.redirect(result.reason === 'session_not_found' ? '/attendance/friday' : `/attendance/sessions/${id}/correct`);
  }
  req.flash('success', result.changed
    ? `${result.changed} correction${result.changed === 1 ? '' : 's'} recorded. The expected list was not changed.`
    : 'Nothing needed to change.');
  return res.redirect(`/attendance/sessions/${id}`);
});

export default router;
