import fs from 'node:fs';
import { streamFile } from '../lib/stream-file.js';
import { atomicRouter } from '../lib/atomic-router.js';
import { submitOnce } from '../lib/submit-guard.js';
import { parsePaging, serverPaged, pageSizeParam, GALLERY_PAGE_SIZES } from '../lib/paging.js';
import { requireAuth, requirePermission, requireAnyPermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { verifyCsrf } from '../lib/csrf.js';
import {
  activityMediaUpload, saveActivityMedia, removeStoredFile, removeActivityMediaDir,
  resolveStoredFile, mediaContentType, uploadErrorMessage, MAX_MEDIA_BYTES, MAX_MEDIA_FILES
} from '../lib/uploads.js';
import {
  getActivity, listGroupActivities, listActivities, activityCounts, createActivity,
  updateActivity, setActivityStatus,
  deleteActivity, setActivityCover, addMedia, listMedia, getMedia, deleteMedia,
  updateMediaCaption, canManageActivity, canManageGroupActivities, canViewActivity,
  ACTIVITY_STATUSES, STATUS_LABELS
} from '../services/activities.js';
import { getGroup } from '../services/cell-groups.js';

const router = atomicRouter();

function reachableGroup(user, groupId) {
  const group = getGroup(groupId);
  if (!group) return null;
  if (user.can('cellgroups.view') || user.can('cellgroups.manage')) return group;
  if (user.ledCellGroupIds.includes(Number(groupId))) return group;
  if (Number(user.member?.cell_group_id) === Number(groupId)) return group;
  return null;
}

function collectActivityInput(body) {
  const v = new Validator(body);
  v.text('title', { required: true, max: 120, label: 'Title' });
  v.text('description', { max: 4000, label: 'Description' });
  v.text('category', { max: 60, label: 'Category' });
  v.date('activity_date', { label: 'Date' });
  v.time('start_time', { label: 'Start time' });
  v.time('end_time', { label: 'End time' });
  v.text('location', { max: 200, label: 'Location' });
  return v;
}

// --- Church activities -----------------------------------------------------

router.get('/activities', requireAuth, requirePermission('activities.view'), (req, res) => {
  const scope = ['church', 'cell_group'].includes(req.query.scope) ? req.query.scope : null;
  const status = ACTIVITY_STATUSES.includes(req.query.status) ? req.query.status : null;
  const search = String(req.query.q || '').slice(0, 60);
  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listActivities(req.user, { scope, status, search, page, pageSize }),
    parsePaging(req.query, { defaultSize: 12, sizes: GALLERY_PAGE_SIZES })
  );

  res.render('activities/all', {
    title: 'Activities',
    result,
    paging,
    pagerParams: { scope, status, q: search, page_size: pageSizeParam(paging, 12) },
    pageSizeQuery: pageSizeParam(paging, 12),
    counts: activityCounts(req.user),
    filters: { scope, status, search },
    statuses: ACTIVITY_STATUSES,
    statusLabels: STATUS_LABELS,
    canCreate: req.user.can('activities.manage')
  });
});

router.get('/activities/new', requireAuth, requirePermission('activities.manage'), (req, res) => {
  res.render('activities/form', {
    title: 'Add church activity',
    mode: 'create',
    group: null,
    activity: { status: 'draft', scope: 'church' },
    values: {},
    errors: {},
    statuses: ACTIVITY_STATUSES
  });
});

router.post('/activities', requireAuth, requirePermission('activities.manage'), submitOnce(), (req, res) => {
  const v = collectActivityInput(req.body);
  if (!v.valid) {
    return res.status(400).render('activities/form', {
      title: 'Add church activity',
      mode: 'create',
      group: null,
      activity: { ...req.body, scope: 'church' },
      values: req.body,
      errors: v.errors,
      statuses: ACTIVITY_STATUSES
    });
  }

  const status = req.body.publish === 'yes' ? 'published' : 'draft';
  const activity = createActivity(
    { ...v.values, scope: 'church', cell_group_id: null, status },
    { userId: req.user.id }
  );

  recordAudit({
    req, action: 'activity.created', entityType: 'activity', entityId: activity.id,
    detail: { title: activity.title, scope: 'church', status }
  });

  req.flash('success', status === 'published' ? 'Church activity published.' : 'Church activity saved as a draft.');
  return res.redirect(`/activities/${activity.id}`);
});

// --- Cell group activity list ----------------------------------------------


router.get('/cell-groups/:id(\\d+)/activities', requireAuth, requirePermission('activities.view'),
  (req, res, next) => {
    const group = reachableGroup(req.user, Number(req.params.id));
    if (!group) return next();
    const canManage = canManageGroupActivities(req.user, group.id);

    res.render('activities/index', {
      title: `${group.name} activities`,
      group,
      canManage,
      activities: listGroupActivities(group.id, { includeUnpublished: canManage }),
      statusLabels: STATUS_LABELS
    });
  });

// --- Create ----------------------------------------------------------------

router.get('/cell-groups/:id(\\d+)/activities/new', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), submitOnce(), (req, res, next) => {
    const groupId = Number(req.params.id);
    const group = getGroup(groupId);
    if (!group) return next();
    if (!canManageGroupActivities(req.user, groupId)) {
      const err = new Error('You can only create activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    return res.render('activities/form', {
      title: 'Add activity',
      mode: 'create',
      group,
      activity: { status: 'draft' },
      values: {},
      errors: {},
      statuses: ACTIVITY_STATUSES
    });
  });

router.post('/cell-groups/:id(\\d+)/activities', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const groupId = Number(req.params.id);
    const group = getGroup(groupId);
    if (!group) return next();
    if (!canManageGroupActivities(req.user, groupId)) {
      const err = new Error('You can only create activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    const v = collectActivityInput(req.body);
    if (!v.valid) {
      return res.status(400).render('activities/form', {
        title: 'Add activity',
        mode: 'create',
        group,
        activity: req.body,
        values: req.body,
        errors: v.errors,
        statuses: ACTIVITY_STATUSES
      });
    }

    const status = req.body.publish === 'yes' ? 'published' : 'draft';
    const activity = createActivity(
      { ...v.values, scope: 'cell_group', cell_group_id: groupId, status },
      { userId: req.user.id }
    );

    recordAudit({
      req, action: 'activity.created', entityType: 'activity', entityId: activity.id,
      detail: { title: activity.title, cell_group_id: groupId, status }
    });

    req.flash('success', status === 'published' ? 'Activity published.' : 'Activity saved as a draft.');
    return res.redirect(`/activities/${activity.id}`);
  });

// --- Activity page ---------------------------------------------------------

router.get('/activities/:id(\\d+)', requireAuth, requirePermission('activities.view'), (req, res, next) => {
  const activity = getActivity(Number(req.params.id));
  if (!activity) return next();
  if (!canViewActivity(req.user, activity)) {
    const err = new Error('This activity is not available to you.');
    err.status = 403;
    return next(err);
  }

  const media = listMedia(activity.id);
  return res.render('activities/show', {
    title: activity.title,
    activity,
    media,
    albums: [...new Set(media.map((m) => m.album).filter(Boolean))],
    canManage: canManageActivity(req.user, activity),
    statuses: ACTIVITY_STATUSES,
    statusLabels: STATUS_LABELS,
    maxFiles: MAX_MEDIA_FILES,
    maxMb: Math.round(MAX_MEDIA_BYTES / (1024 * 1024))
  });
});

router.get('/activities/:id(\\d+)/edit', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const activity = getActivity(Number(req.params.id));
    if (!activity) return next();
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only edit activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    return res.render('activities/form', {
      title: `Edit ${activity.title}`,
      mode: 'edit',
      group: activity.cell_group_id ? getGroup(activity.cell_group_id) : null,
      activity,
      values: activity,
      errors: {},
      statuses: ACTIVITY_STATUSES
    });
  });

router.post('/activities/:id(\\d+)', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const activity = getActivity(Number(req.params.id));
    if (!activity) return next();
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only edit activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    const v = collectActivityInput(req.body);
    if (!v.valid) {
      return res.status(400).render('activities/form', {
        title: `Edit ${activity.title}`,
        mode: 'edit',
        group: activity.cell_group_id ? getGroup(activity.cell_group_id) : null,
        activity: { ...activity, ...req.body },
        values: req.body,
        errors: v.errors,
        statuses: ACTIVITY_STATUSES
      });
    }

    updateActivity(activity.id, v.values);
    recordAudit({ req, action: 'activity.updated', entityType: 'activity', entityId: activity.id });
    req.flash('success', 'Activity updated.');
    return res.redirect(`/activities/${activity.id}`);
  });

router.post('/activities/:id(\\d+)/status', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const activity = getActivity(Number(req.params.id));
    if (!activity) return next();
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only change activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    const v = new Validator(req.body);
    const status = v.oneOf('status', ACTIVITY_STATUSES, { required: true, label: 'Status' });
    if (!v.valid) {
      req.flash('error', 'Choose a valid status.');
      return res.redirect(`/activities/${activity.id}`);
    }

    setActivityStatus(activity.id, status);
    recordAudit({
      req, action: 'activity.status_changed', entityType: 'activity', entityId: activity.id,
      detail: { from: activity.status, to: status }
    });
    req.flash('success', `Activity ${STATUS_LABELS[status].toLowerCase()}.`);
    return res.redirect(`/activities/${activity.id}`);
  });

router.post('/activities/:id(\\d+)/delete', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const activity = getActivity(Number(req.params.id));
    if (!activity) return next();
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only remove activities for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    removeActivityMediaDir(activity.id);
    deleteActivity(activity.id);
    recordAudit({
      req, action: 'activity.deleted', entityType: 'activity', entityId: activity.id,
      detail: { title: activity.title }
    });
    req.flash('success', `${activity.title} removed.`);
    return res.redirect(activity.cell_group_id ? `/cell-groups/${activity.cell_group_id}/activities` : '/cell-groups');
  });

// --- Media -----------------------------------------------------------------

router.post('/activities/:id(\\d+)/media', requireAuth, requirePermission('media.upload'), (req, res, next) => {
  const activity = getActivity(Number(req.params.id));
  if (!activity) return next();
  if (!canManageActivity(req.user, activity)) {
    const err = new Error('You can only add media to activities for a cell group you lead.');
    err.status = 403;
    return next(err);
  }

  return activityMediaUpload(req, res, (uploadErr) => {
    if (!uploadErr && !verifyCsrf(req)) {
      const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
      err.status = 403;
      return next(err);
    }
    if (uploadErr) {
      req.flash('error', uploadErrorMessage(uploadErr));
      return res.redirect(`/activities/${activity.id}`);
    }
    if (!req.files || req.files.length === 0) {
      req.flash('error', 'Choose at least one file to upload.');
      return res.redirect(`/activities/${activity.id}`);
    }

    const album = String(req.body.album || '').trim().slice(0, 80) || null;
    const caption = String(req.body.caption || '').trim().slice(0, 300) || null;

    const saved = [];
    const rejected = [];
    for (const file of req.files) {
      try {
        saved.push({ ...saveActivityMedia(activity.id, file), album, caption });
      } catch (err) {
        if (!err.status) return next(err);
        rejected.push(err.message);
      }
    }

    if (saved.length) {
      addMedia(activity.id, saved, { userId: req.user.id });
      recordAudit({
        req, action: 'media.uploaded', entityType: 'activity', entityId: activity.id,
        detail: { files: saved.length, rejected: rejected.length, album }
      });
      req.flash('success', `${saved.length} file${saved.length === 1 ? '' : 's'} added.`);
    }
    if (rejected.length) req.flash('error', rejected.join(' '));
    return res.redirect(`/activities/${activity.id}`);
  });
});

router.post('/media/:id(\\d+)/caption', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const media = getMedia(Number(req.params.id));
    if (!media) return next();
    const activity = getActivity(media.activity_id);
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only change media for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    updateMediaCaption(media.id, {
      caption: String(req.body.caption || '').trim().slice(0, 300) || null,
      album: String(req.body.album || '').trim().slice(0, 80) || null
    });
    recordAudit({ req, action: 'media.updated', entityType: 'activity_media', entityId: media.id });
    req.flash('success', 'Caption saved.');
    return res.redirect(`/activities/${media.activity_id}`);
  });

router.post('/media/:id(\\d+)/cover', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const media = getMedia(Number(req.params.id));
    if (!media) return next();
    const activity = getActivity(media.activity_id);
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only change media for a cell group you lead.');
      err.status = 403;
      return next(err);
    }
    if (media.media_type !== 'image') {
      req.flash('error', 'Only a photo can be the cover image.');
      return res.redirect(`/activities/${media.activity_id}`);
    }

    setActivityCover(activity.id, media.file_path);
    recordAudit({ req, action: 'activity.updated', entityType: 'activity', entityId: activity.id, detail: 'cover image' });
    req.flash('success', 'Cover image set.');
    return res.redirect(`/activities/${media.activity_id}`);
  });

router.post('/media/:id(\\d+)/delete', requireAuth,
  requireAnyPermission('activities.manage', 'activities.manage_own_group'), (req, res, next) => {
    const media = getMedia(Number(req.params.id));
    if (!media) return next();
    const activity = getActivity(media.activity_id);
    if (!canManageActivity(req.user, activity)) {
      const err = new Error('You can only remove media for a cell group you lead.');
      err.status = 403;
      return next(err);
    }

    deleteMedia(media.id);
    removeStoredFile(media.file_path);
    recordAudit({
      req, action: 'media.deleted', entityType: 'activity_media', entityId: media.id,
      detail: { activity_id: media.activity_id }
    });
    req.flash('success', 'File removed.');
    return res.redirect(`/activities/${media.activity_id}`);
  });

/** Media is served only after the same visibility check as the activity page. */
router.get('/media/activity/:id(\\d+)', requireAuth, (req, res, next) => {
  const media = getMedia(Number(req.params.id));
  if (!media) return next();

  const activity = getActivity(media.activity_id);
  if (!canViewActivity(req.user, activity)) {
    const err = new Error('This file is not available to you.');
    err.status = 403;
    return next(err);
  }

  const file = resolveStoredFile(media.file_path);
  if (!file) return next();

  const type = mediaContentType(file);
  res.setHeader('Content-Type', type);
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Documents download rather than render in the page.
  res.setHeader(
    'Content-Disposition',
    `${media.media_type === 'document' ? 'attachment' : 'inline'}; filename="activity-${media.id}"`
  );
  return streamFile(res, file, next);
});

export default router;
