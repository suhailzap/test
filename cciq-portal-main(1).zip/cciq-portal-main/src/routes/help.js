import express from 'express';
import path from 'node:path';
import { requireAuth } from '../middleware/auth.js';
import { streamFile } from '../lib/stream-file.js';
import {
  HELP_DIR, ASSET_FILES, guideRoles, renderGuide, canSeeScreenshot
} from '../lib/user-guide.js';

const router = express.Router();

/*
 * Help / User Guide. Everything here needs a signed-in person (requireAuth), there is no public copy, and nothing is chosen by a link that is merely hidden:
 *   - the page contains only the chapters, steps and screenshots whose audience includes one of the person's roles (src/lib/user-guide.js);
 *   - a screenshot file is sent only if its figure would appear on that person's page, so a Member cannot fetch an administrator's screenshot by guessing its name;
 *   - the stylesheet, script and logo are the only other files, by an exact allow-list. No path is ever joined from a request without a strict name check.
 * A reception (Kiosk-only) session is confined by src/middleware/auth.js to its own screens and /help, and /help gives it the reception material only.
 */

router.get('/help', requireAuth, (req, res) => {
  const roles = guideRoles(req.user);
  const kioskOnly = roles.length === 1 && roles[0] === 'kiosk';
  const { html } = renderGuide({ roles, mode: 'portal', backHref: kioskOnly ? '/kiosk' : '/' });
  res.set('Cache-Control', 'no-store');
  res.type('html').send(html);
});

router.get('/help/assets/:name', requireAuth, (req, res, next) => {
  const name = String(req.params.name || '');
  if (!ASSET_FILES.includes(name)) return res.status(404).type('text/plain').send('Not found');
  res.set('Cache-Control', 'private, max-age=300');
  res.type(path.extname(name));
  return streamFile(res, path.join(HELP_DIR, 'assets', name), next);
});

router.get('/help/screenshots/:name', requireAuth, (req, res, next) => {
  const match = /^([a-z0-9-]+)\.png$/.exec(String(req.params.name || ''));
  // The same answer for "no such picture" and "not for your role", so the response does not reveal which administrator pictures exist.
  if (!match || !canSeeScreenshot(guideRoles(req.user), match[1])) return res.status(404).type('text/plain').send('Not found');
  res.set('Cache-Control', 'private, max-age=300');
  res.type('png');
  return streamFile(res, path.join(HELP_DIR, 'screenshots', `${match[1]}.png`), next);
});

export default router;
