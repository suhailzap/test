import { parsePaging, pageWindow, pageSizeParam } from '../lib/paging.js';
import { atomicRouter } from '../lib/atomic-router.js';
import { requireAuth, requirePermission, requireRole } from '../middleware/auth.js';
import { getSettings, setSetting, SETTING_DEFINITIONS } from '../lib/settings.js';
import { recordAudit, AUDIT, listAudit, countAudit, AUDIT_SORT_COLUMNS } from '../lib/audit.js';
import { Validator } from '../lib/validate.js';
import { isValidDate, isFriday, today } from '../lib/dates.js';
import { ensureFridaySessions, applyScheduleDefaultsToUpcoming, listFridayServices } from '../services/friday-service.js';
import { customFields, addCustomField, setCustomFieldActive } from '../services/members.js';
import { trackingStartLock, setTrackingStartDate, trackingReadiness, previewTrackingStart } from '../services/attendance-lifecycle.js';

const router = atomicRouter();

const CATEGORY_ORDER = [
  'friday_service', 'attendance', 'congregations', 'reminders', 'visitors', 'church', 'members', 'giving', 'branding'
];
const CATEGORY_LABELS = {
  friday_service: 'Friday Service',
  attendance: 'Attendance rules',
  congregations: 'Congregations and age boundaries',
  reminders: 'Reminders',
  visitors: 'Visitors',
  church: 'Church information',
  members: 'Members',
  giving: 'Giving Board',
  branding: 'Branding'
};

/**
 * System settings are organised into sections a Church Admin can find. Each editable section is its
 * own form and saves ONLY its own categories, so saving one section can never change another's
 * settings (an unticked checkbox on a hidden section is not a "turn it off"). Sections without
 * categories are information panels that point at the screens that own the work. The order below is
 * the tab order; 'other' keeps the settings that do not belong to a named section reachable.
 */
const SETTINGS_SECTIONS = [
  { key: 'about', label: 'About Our Church', categories: ['church'] },
  { key: 'branding', label: 'Branding', categories: [] },
  { key: 'friday_service', label: 'Friday Service', categories: ['friday_service'] },
  { key: 'attendance', label: 'Attendance', categories: ['attendance'] },
  { key: 'security', label: 'Security & Sessions', categories: [] },
  { key: 'backup', label: 'Backup & Recovery', categories: [] },
  { key: 'other', label: 'Other settings', categories: ['congregations', 'reminders', 'visitors', 'members', 'giving'] }
];
const DEFAULT_SETTINGS_SECTION = 'about';

function settingsSection(key) {
  return SETTINGS_SECTIONS.find((s) => s.key === key) || null;
}

router.get('/admin/settings', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const current = settingsSection(String(req.query.section || '')) || settingsSection(DEFAULT_SETTINGS_SECTION);
  // Retired settings stay in the database but are not offered any more.
  const all = getSettings().filter((s) => !s.definition?.deprecated);
  const grouped = CATEGORY_ORDER
    .filter((category) => current.categories.includes(category))
    .map((category) => ({
      key: category,
      label: CATEGORY_LABELS[category] || category,
      settings: all.filter((s) => s.category === category)
    }))
    .filter((group) => group.settings.length > 0);

  const upcoming = current.key === 'friday_service'
    ? listFridayServices({ from: today(), limit: 500, direction: 'asc' })
    : [];

  res.render('settings/index', {
    title: 'System settings',
    sections: SETTINGS_SECTIONS,
    section: current.key,
    sectionLabel: current.label,
    grouped,
    trackingLock: trackingStartLock(),
    trackingReadiness: trackingReadiness(),
    // The NEXT few services (soonest first), and how many exist in all.
    upcomingServices: upcoming.slice(0, 5),
    upcomingTotal: upcoming.length
  });
});

router.post('/admin/settings', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const changed = [];
  const errors = {};
  // Two passes: every submitted value is checked first and NOTHING is written if any of them is wrong, so a refused form never leaves some
  // settings saved and others not (and every problem is reported, not just the first).
  const writes = [];
  let trackingStart = null;

  /*
   * The two congregation boundaries define each other's edges — Kids Church
   * runs up to one age, Teens Church picks up from there — so they can only
   * be checked together, not as two independent numbers. This never touches
   * a member's date of birth; it only changes where the same DOB is grouped.
   */
  if ('congregation__child_max_age' in req.body && 'congregation__teen_max_age' in req.body) {
    const childMax = Number.parseInt(req.body.congregation__child_max_age, 10);
    const teenMax = Number.parseInt(req.body.congregation__teen_max_age, 10);
    if (Number.isFinite(childMax) && Number.isFinite(teenMax) && childMax >= teenMax) {
      errors['congregation.child_max_age'] = 'Kids Church must end before Teens Church does — '
        + 'lower the first age or raise the second.';
      errors['congregation.teen_max_age'] = errors['congregation.child_max_age'];
    }
  }

  /*
   * "Who should be included in absence follow-up" is presented as a choice
   * between two modes rather than asking an admin to already know that 0 has
   * a special meaning. Both modes still write to the one existing setting,
   * attendance.recent_engagement_days — no new setting, no migration. The
   * "everyone" mode forces 0 regardless of whatever the (disabled, and so
   * possibly entirely absent from the submission) day-count field held.
   */
  if (req.body.attendance__recent_engagement_mode === 'everyone') {
    req.body.attendance__recent_engagement_days = '0';
  }

  // Only the submitted section's settings are touched. (Without a section - an old bookmark or a
  // hand-built request - only the fields actually sent are read; nothing is turned off by omission.)
  const submitted = settingsSection(String(req.body.section || ''));

  for (const def of SETTING_DEFINITIONS) {
    const field = def.key.replaceAll('.', '__');
    if (def.deprecated) continue; // retired: never written from the settings form
    if (errors[def.key]) continue;
    if (submitted && !submitted.categories.includes(def.category)) continue;
    if (!(field in req.body) && !(def.type === 'boolean' && submitted)) continue;

    const v = new Validator(req.body);
    let value;

    if (def.type === 'boolean') {
      value = v.boolean(field);
    } else if (def.type === 'number') {
      value = v.integer(field, { min: 0, max: 100000, label: def.label });
    } else if (def.type === 'json') {
      const raw = String(req.body[field] || '');
      const parsed = raw.split(',').map((s) => Number.parseInt(s.trim(), 10)).filter((n) => Number.isFinite(n) && n >= 0 && n <= 365);
      value = parsed;
    } else if (def.key === 'attendance.tracking_start_date') {
      const raw = String(req.body[field] ?? '').trim();
      // A system-critical control: only a Super Admin changes it (the settings screen does not even offer the field; this refuses a hand-built request).
      if (!req.user.hasRole('super_admin')) {
        if (raw !== String(getSettings().find((x) => x.key === def.key)?.parsed || '')) errors[def.key] = 'Only a Super Admin can change the Attendance Tracking Start Date.';
        continue;
      }
      if (raw && !isValidDate(raw)) {
        errors[def.key] = 'Enter the attendance tracking start date as a real date, such as 2026-11-06, or leave it blank.';
        continue;
      }
      if (raw && !isFriday(raw)) {
        errors[def.key] = 'The Attendance Tracking Start Date must be a Friday.';
        continue;
      }
      // Never written directly: once attendance has been finalized the date is
      // locked, and only the Super Admin override (below) can change it. It is applied after every other value has been checked.
      trackingStart = { key: def.key, raw };
      continue;
    } else if (def.key === 'service.friday.time') {
      const raw = String(req.body[field] || '').trim();
      value = raw;
      if (raw && !/^([01]\d|2[0-3]):[0-5]\d$/.test(raw)) {
        errors[def.key] = 'Enter the time in 24-hour format, such as 18:30.';
        continue;
      }
    } else {
      value = String(req.body[field] ?? '').trim().slice(0, 500);
    }

    if (!v.valid) {
      errors[def.key] = Object.values(v.errors)[0];
      continue;
    }

    writes.push([def.key, value]);
  }

  const back = submitted ? `/admin/settings?section=${submitted.key}` : '/admin/settings';
  if (Object.keys(errors).length) {
    const messages = [...new Set(Object.values(errors))];
    req.flash('error', `${messages.join(' ')} Nothing was saved.`);
    return res.redirect(back);
  }

  for (const [key, value] of writes) {
    setSetting(key, value, req.user.id);
    changed.push(key);
  }
  if (trackingStart) {
    const set = setTrackingStartDate(trackingStart.raw, { userId: req.user.id, req });
    if (!set.ok) {
      req.flash('error', set.reason === 'locked'
        ? 'The attendance tracking start date is locked because attendance has already been finalized. A Super Admin can change it with a recorded reason.'
        : 'The attendance tracking start date could not be changed.');
      if (changed.length) recordAudit({ req, action: AUDIT.SETTING_UPDATED, entityType: 'system_settings', detail: { changed } });
      return res.redirect(back);
    }
    if (set.changed) changed.push(trackingStart.key);
  }

  const touchedSchedule = changed.some((key) => key.startsWith('service.friday'));
  if (touchedSchedule) {
    applyScheduleDefaultsToUpcoming({ userId: req.user.id });
    const { created } = ensureFridaySessions({ userId: req.user.id });
    if (created) {
      recordAudit({ req, action: AUDIT.SESSION_SCHEDULED, entityType: 'attendance_session', detail: { created } });
    }
  }

  recordAudit({ req, action: AUDIT.SETTING_UPDATED, entityType: 'system_settings', detail: { changed } });
  req.flash('success', submitted ? `${submitted.label} saved.` : 'Settings saved.');
  return res.redirect(back);
});

const TRACKING_OVERRIDE_MESSAGES = {
  locked: 'The date is locked.',
  reason_required: 'A reason is required to change the locked tracking start date.',
  cannot_clear_when_locked: 'The tracking start date cannot be cleared once attendance has been finalized.',
  after_finalized_friday: 'The tracking start date cannot be later than a Friday that has already been finalized.',
  invalid_date: 'Enter a real date, such as 2026-11-06.',
  not_friday: 'The Attendance Tracking Start Date must be a Friday.'
};

router.get('/admin/attendance/tracking-start', requireAuth, requirePermission('admin.settings'), requireRole('super_admin'), (req, res) => {
  res.render('settings/tracking-start', {
    title: 'Attendance tracking start date',
    lock: trackingStartLock(),
    readiness: trackingReadiness(),
    // The preview of a proposed date: derived from the real sessions, written nowhere.
    preview: req.query.date ? previewTrackingStart(String(req.query.date)) : null,
    proposed: String(req.query.date || ''),
    current: getSettings().find((x) => x.key === 'attendance.tracking_start_date')?.parsed || ''
  });
});

router.post('/admin/attendance/tracking-start', requireAuth, requirePermission('admin.settings'), requireRole('super_admin'), (req, res) => {
  const result = setTrackingStartDate(String(req.body.tracking_start_date ?? ''), {
    userId: req.user.id, req, override: true, reason: req.body.reason
  });
  if (!result.ok) {
    req.flash('error', TRACKING_OVERRIDE_MESSAGES[result.reason] || 'The tracking start date could not be changed.');
    return res.redirect(`/admin/attendance/tracking-start${isValidDate(String(req.body.tracking_start_date || '')) ? `?date=${req.body.tracking_start_date}` : ''}`);
  }
  req.flash('success', !result.changed
    ? 'The date was already set to that value.'
    : result.newlyTrackedPastFridays
      ? `Tracking start date changed. ${result.newlyTrackedPastFridays} earlier Friday(s) are now tracked and awaiting finalization.`
      : result.newlyHistoricalFridays
        ? `Tracking start date changed. ${result.newlyHistoricalFridays} finalized Friday(s) are now historical only and no longer count.`
        : 'Tracking start date changed.');
  return res.redirect('/admin/settings?section=attendance');
});

router.get('/admin/member-fields', requireAuth, requirePermission('admin.settings'), (req, res) => {
  res.render('settings/member-fields', {
    title: 'Member fields',
    fields: customFields({ activeOnly: false })
  });
});

router.post('/admin/member-fields', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const v = new Validator(req.body);
  const label = v.text('label', { required: true, max: 60, label: 'Field label' });
  const type = v.oneOf('field_type', ['text', 'textarea', 'number', 'date', 'select', 'checkbox'], { required: true, label: 'Field type', fallback: 'text' });
  const visibility = v.oneOf('visibility', ['staff', 'leader', 'member'], { required: true, label: 'Visible to', fallback: 'staff' });
  const options = v.text('options', { max: 500, label: 'Choices' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect('/admin/member-fields');
  }

  const fieldKey = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40);
  if (!fieldKey) {
    req.flash('error', 'Use a label with at least one letter or number.');
    return res.redirect('/admin/member-fields');
  }

  try {
    addCustomField({ label, fieldKey, fieldType: type, options, visibility });
    recordAudit({ req, action: 'settings.member_field_added', entityType: 'member_custom_fields', entityId: fieldKey });
    req.flash('success', `Field "${label}" added.`);
  } catch {
    req.flash('error', 'A field with that name already exists.');
  }
  return res.redirect('/admin/member-fields');
});

router.post('/admin/member-fields/:id/toggle', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const id = Number(req.params.id);
  const active = req.body.active === '1';
  setCustomFieldActive(id, active);
  recordAudit({ req, action: 'settings.member_field_toggled', entityType: 'member_custom_fields', entityId: id, detail: { active } });
  req.flash('success', active ? 'Field is now in use.' : 'Field hidden from forms. Existing values are kept.');
  return res.redirect('/admin/member-fields');
});

router.get('/admin/audit', requireAuth, requirePermission('admin.audit'), (req, res) => {
  const action = req.query.action ? String(req.query.action).slice(0, 60) : null;
  const sort = AUDIT_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'when';
  const direction = req.query.direction === 'asc' ? 'asc' : 'desc';
  const total = countAudit(action);
  const paging = pageWindow({ total, ...parsePaging(req.query) });

  res.render('settings/audit', {
    title: 'Audit log',
    entries: listAudit({ limit: paging.pageSize, offset: paging.offset, action, sort, direction }),
    paging,
    pagerParams: { action, sort, direction, page_size: pageSizeParam(paging) },
    total,
    action: action || '',
    sort,
    direction
  });
});

export default router;
