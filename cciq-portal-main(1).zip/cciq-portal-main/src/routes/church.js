import fs from 'node:fs';
import { streamFile } from '../lib/stream-file.js';
import { atomicRouter } from '../lib/atomic-router.js';
import multer from 'multer';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { verifyCsrf } from '../lib/csrf.js';
import {
  ensureSections, listSections, getSection, saveSection, hasContent,
  listLeaders, leadershipGroups, getLeader, createLeader, updateLeader, setLeaderPhoto,
  deleteLeader, DEFAULT_SECTIONS, LEADERSHIP_GROUPS
} from '../services/church-profile.js';
import { getSetting } from '../lib/settings.js';
import { listMinistries, getMinistry } from '../services/ministries.js';
import { listGroups, getGroup } from '../services/cell-groups.js';

/** The cell groups a user may actually open, for the About page. */
function churchGroupsFor(user) {
  if (user.can('cellgroups.view')) return listGroups({ includeInactive: false });
  if (!user.can('cellgroups.view_own')) return [];

  const reachable = new Set([
    ...(user.ledCellGroupIds || []).map(Number),
    ...(user.member?.cell_group_id ? [Number(user.member.cell_group_id)] : [])
  ]);
  return listGroups({ includeInactive: false }).filter((g) => reachable.has(Number(g.id)));
}
import {
  memberPhotoUpload, saveLeaderPhoto, resolveStoredFile, contentTypeFor, uploadErrorMessage, pruneSiblings, discardStoredFile, UPLOAD_NAME_CHARSET
} from '../lib/uploads.js';
import { transaction } from '../db/index.js';
import {
  readWorkbook, suggestMemberMapping, detectDateColumns, stageImport, loadStagedImport,
  discardStagedImport, previewMembers, commitMembers, previewAttendance, commitAttendance, AttendanceImportRefusedError,
  listImportBatches, MEMBER_FIELDS
} from '../services/imports.js';

const router = atomicRouter();

// A spreadsheet is held in memory, read, then discarded; only the parsed rows
// are written to disk, and only until the import is confirmed or abandoned.
const spreadsheetUpload = multer({
  defParamCharset: UPLOAD_NAME_CHARSET,
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024, files: 1 }
}).single('file');

// --- About our church ------------------------------------------------------


// --- The public About page --------------------------------------------------

/**
 * Anyone may read about the church without an account. What a visitor sees is
 * deliberately narrower than what a member sees: no member names, no contact
 * details, and no cell group meeting addresses, since those are people's homes.
 */
function publicAboutEnabled() {
  return getSetting('church.public_about') === true;
}

function requirePublicAbout(req, res, next) {
  if (publicAboutEnabled()) return next();
  return res.redirect('/login?next=/about');
}

function publicMeeting() {
  return {
    title: getSetting('service.friday.title') || 'CCIQ Friday Service',
    time: getSetting('service.friday.time'),
    endTime: getSetting('service.friday.end_time'),
    location: getSetting('service.friday.location'),
    address: getSetting('church.address'),
    note: getSetting('church.location_note'),
    map: getSetting('church.map_url'),
    motto: getSetting('church.motto')
  };
}

function renderPublicAbout(req, res) {
  ensureSections();
  return res.render('about/public', {
    title: 'About our church',
    sections: listSections({ visibleOnly: true }),
    groups: leadershipGroups({ visibleOnly: true }),
    // Names, the day they meet, and nothing that identifies a member's home.
    cellGroups: getSetting('church.public_cell_groups') === true
      ? listGroups({ includeInactive: false })
      : [],
    ministries: listMinistries(),
    meeting: publicMeeting(),
    layout: 'public'
  });
}

router.get('/about/cell-groups/:id(\\d+)/quick', requirePublicAbout, (req, res, next) => {
  if (getSetting('church.public_cell_groups') !== true) return next();
  const group = getGroup(Number(req.params.id));
  if (!group || group.status !== 'active') return next();
  return res.render('about/public-group', { group, layout: false });
});

router.get('/about/ministries/:id(\\d+)/quick', requirePublicAbout, (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry || ministry.status !== 'active') return next();
  return res.render('about/public-ministry', { ministry, layout: false });
});

/** Photos shown on the public page, and only those. */
function sendPublicImage(res, storedPath, next) {
  const file = resolveStoredFile(storedPath);
  if (!file) return next();
  res.setHeader('Content-Type', contentTypeFor(file));
  res.setHeader('Cache-Control', 'public, max-age=1800');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return streamFile(res, file, next);
}

router.get('/about/leaders/:id(\\d+)/photo', requirePublicAbout, (req, res, next) => {
  const leader = getLeader(Number(req.params.id));
  if (!leader || !leader.is_visible || !leader.photo_path) return next();
  return sendPublicImage(res, leader.photo_path, next);
});

router.get('/about/cell-groups/:id(\\d+)/photo', requirePublicAbout, (req, res, next) => {
  if (getSetting('church.public_cell_groups') !== true) return next();
  const group = getGroup(Number(req.params.id));
  if (!group || group.status !== 'active' || !group.photo_path) return next();
  return sendPublicImage(res, group.photo_path, next);
});

router.get('/about/ministries/:id(\\d+)/photo', requirePublicAbout, (req, res, next) => {
  const ministry = getMinistry(Number(req.params.id));
  if (!ministry || ministry.status !== 'active' || !ministry.photo_path) return next();
  return sendPublicImage(res, ministry.photo_path, next);
});

/** Signed in, the full page; signed out, the visitor's version. */
router.get('/about', (req, res, next) => {
  if (req.user) return next();
  if (!publicAboutEnabled()) return res.redirect('/login?next=/about');
  return renderPublicAbout(req, res);
}, requireAuth, (req, res) => {
  ensureSections();
  res.render('about/index', {
    title: 'About our church',
    sections: listSections({ visibleOnly: true }),
    leaders: listLeaders({ visibleOnly: true }),
    groups: leadershipGroups({ visibleOnly: true }),
    // Both lists come straight from their own modules, so adding a ministry or
    // a cell group anywhere in the portal shows up here without another step.
    ministries: req.user.can('ministries.view') ? listMinistries() : [],
    // Someone who may only see their own group is shown only their own group,
    // so the page never lists something they cannot open.
    cellGroups: churchGroupsFor(req.user),
    meeting: {
      title: getSetting('service.friday.title') || 'CCIQ Friday Service',
      time: getSetting('service.friday.time'),
      endTime: getSetting('service.friday.end_time'),
      location: getSetting('service.friday.location'),
      address: getSetting('church.address'),
      note: getSetting('church.location_note'),
      map: getSetting('church.map_url'),
      motto: getSetting('church.motto')
    },
    canManage: req.user.can('admin.settings'),
    hasContent: hasContent()
  });
});

router.get('/admin/about', requireAuth, requirePermission('admin.settings'), (req, res) => {
  ensureSections();
  res.render('about/edit', {
    title: 'Edit About our church',
    sections: listSections(),
    leaders: listLeaders(),
    defaults: DEFAULT_SECTIONS,
    leadershipGroupOptions: LEADERSHIP_GROUPS,
    publicAbout: Boolean(getSetting('church.public_about'))
  });
});

// Leadership is edited one person at a time on its own page (the list stays compact).
router.get('/admin/about/leaders/new', requireAuth, requirePermission('admin.settings'), (req, res) => {
  res.render('about/leader-form', {
    title: 'Add to leadership',
    mode: 'create',
    leader: { group_label: LEADERSHIP_GROUPS[0], is_visible: 1, sort_order: 0 },
    leadershipGroupOptions: LEADERSHIP_GROUPS
  });
});

router.get('/admin/about/leaders/:id(\\d+)/edit', requireAuth, requirePermission('admin.settings'), (req, res, next) => {
  const leader = getLeader(Number(req.params.id));
  if (!leader) return next();
  return res.render('about/leader-form', {
    title: `Edit ${leader.name}`,
    mode: 'edit',
    leader,
    leadershipGroupOptions: LEADERSHIP_GROUPS
  });
});

router.post('/admin/about', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const keys = listSections().map((s) => s.key);
  const changed = [];

  for (const key of keys) {
    const title = String(req.body[`title_${key}`] ?? '').slice(0, 120).trim();
    const body = String(req.body[`body_${key}`] ?? '').slice(0, 8000);
    const visible = req.body[`visible_${key}`] === 'on';
    const current = getSection(key);
    if (!title) continue;
    if (current.title !== title || (current.body || '') !== body.trim() || Boolean(current.is_visible) !== visible) {
      saveSection(key, { title, body, isVisible: visible }, { userId: req.user.id });
      changed.push(key);
    }
  }

  if (changed.length) {
    recordAudit({
      req, action: 'church.profile_updated', entityType: 'church_page',
      detail: { sections: changed }
    });
  }
  req.flash('success', changed.length ? 'About our church updated.' : 'Nothing changed.');
  return res.redirect('/admin/about');
});

router.post('/admin/about/leaders', requireAuth, requirePermission('admin.settings'), (req, res) => {
  const v = new Validator(req.body);
  v.text('name', { required: true, max: 120, label: 'Name' });
  v.text('role_title', { max: 120, label: 'Role' });
  v.oneOf('group_label', LEADERSHIP_GROUPS, { required: true, label: 'Group' });
  v.text('description', { max: 2000, label: 'Description' });
  v.email('email');
  v.phone('phone');
  v.integer('sort_order', { label: 'Order' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect('/admin/about/leaders/new');
  }

  const leader = createLeader(v.values);
  recordAudit({
    req, action: 'church.leader_added', entityType: 'church_leader', entityId: leader.id,
    detail: { name: leader.name }
  });
  req.flash('success', `${leader.name} added.`);
  return res.redirect('/admin/about');
});

router.post('/admin/about/leaders/:id(\\d+)', requireAuth, requirePermission('admin.settings'), (req, res, next) => {
  const leader = getLeader(Number(req.params.id));
  if (!leader) return next();

  const v = new Validator(req.body);
  v.text('name', { required: true, max: 120, label: 'Name' });
  v.text('role_title', { max: 120, label: 'Role' });
  v.oneOf('group_label', LEADERSHIP_GROUPS, { required: true, label: 'Group' });
  v.text('description', { max: 2000, label: 'Description' });
  v.email('email');
  v.phone('phone');
  v.integer('sort_order', { label: 'Order' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/admin/about/leaders/${leader.id}/edit`);
  }

  updateLeader(leader.id, { ...v.values, isVisible: req.body.is_visible === 'on' });
  recordAudit({ req, action: 'church.leader_updated', entityType: 'church_leader', entityId: leader.id });
  req.flash('success', 'Updated.');
  return res.redirect('/admin/about');
});

router.post('/admin/about/leaders/:id(\\d+)/delete', requireAuth, requirePermission('admin.settings'),
  (req, res, next) => {
    const leader = getLeader(Number(req.params.id));
    if (!leader) return next();
    deleteLeader(leader.id);
    recordAudit({
      req, action: 'church.leader_removed', entityType: 'church_leader', entityId: leader.id,
      detail: { name: leader.name }
    });
    req.flash('success', `${leader.name} removed.`);
    return res.redirect('/admin/about');
  });


/** A leader's photo, uploaded by an administrator. */
router.post('/admin/about/leaders/:id(\\d+)/photo', requireAuth, requirePermission('admin.settings'),
  (req, res, next) => {
    const leader = getLeader(Number(req.params.id));
    if (!leader) return next();

    return memberPhotoUpload(req, res, (uploadErr) => {
      if (uploadErr) {
        req.flash('error', uploadErrorMessage(uploadErr));
        return res.redirect(`/admin/about/leaders/${leader.id}/edit`);
      }
      if (!verifyCsrf(req)) {
        const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
        err.status = 403;
        return next(err);
      }
      if (!req.file) {
        req.flash('error', 'Choose a photo to upload.');
        return res.redirect(`/admin/about/leaders/${leader.id}/edit`);
      }

      try {
        const { storedPath } = saveLeaderPhoto(leader.id, req.file);
        try {
          transaction(() => {
            setLeaderPhoto(leader.id, storedPath);
            recordAudit({
              req, action: 'church.leader_photo_updated', entityType: 'church_leader', entityId: leader.id
            });
          })();
        } catch (dbErr) {
          discardStoredFile(storedPath); // the record still points at the previous photo, which is untouched
          throw dbErr;
        }
        pruneSiblings(storedPath);
        req.flash('success', `Photo updated for ${leader.name}.`);
      } catch (err) {
        if (!err.status) return next(err);
        req.flash('error', err.message);
      }
      return res.redirect(`/admin/about/leaders/${leader.id}/edit`);
    });
  });

/** Leader photos are shown to anyone signed in, as the About page is. */
router.get('/media/leaders/:id(\\d+)', requireAuth, (req, res, next) => {
  const leader = getLeader(Number(req.params.id));
  if (!leader || !leader.photo_path) return next();

  const file = resolveStoredFile(leader.photo_path);
  if (!file) return next();

  res.setHeader('Content-Type', contentTypeFor(file));
  res.setHeader('Cache-Control', 'private, max-age=600');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return streamFile(res, file, next);
});

// --- Spreadsheet import ----------------------------------------------------

router.get('/admin/import', requireAuth, requirePermission('members.create'), (req, res) => {
  res.render('import/index', {
    title: 'Import from a spreadsheet',
    batches: listImportBatches()
  });
});

router.post('/admin/import', requireAuth, requirePermission('members.create'), (req, res, next) => {
  spreadsheetUpload(req, res, (uploadErr) => {
    if (!uploadErr && !verifyCsrf(req)) {
      const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
      err.status = 403;
      return next(err);
    }
    if (uploadErr) {
      req.flash('error', uploadErr.code === 'LIMIT_FILE_SIZE'
        ? 'That file is larger than 12 MB.'
        : 'That file could not be read.');
      return res.redirect('/admin/import');
    }
    if (!req.file) {
      req.flash('error', 'Choose a spreadsheet to upload.');
      return res.redirect('/admin/import');
    }

    const kind = req.body.kind === 'attendance' ? 'attendance' : 'members';

    let workbook;
    try {
      workbook = readWorkbook(req.file.buffer, req.file.originalname);
    } catch (err) {
      req.flash('error', err.code === 'SPREADSHEET_UNSAFE' ? err.message : 'That file could not be read. Save it as .xlsx or .csv and try again.');
      return res.redirect('/admin/import');
    }

    workbook.sheets = workbook.sheets.filter((sheet) => sheet.rowCount > 0); // a sheet with a header and nothing under it is not data
    if (workbook.sheets.length === 0) {
      req.flash('error', 'That file has no readable rows.');
      return res.redirect('/admin/import');
    }

    const token = stageImport({ kind, ...workbook }, { userId: req.user.id });
    return res.redirect(`/admin/import/${token}`);
  });
});

/** Step two: choose the sheet and confirm which column means what. */
router.get('/admin/import/:token([a-f0-9]{32})', requireAuth, requirePermission('members.create'), (req, res, next) => {
  const staged = loadStagedImport(req.params.token, { userId: req.user.id });
  if (!staged) return next();

  const sheetIndex = Math.min(Math.max(Number.parseInt(req.query.sheet, 10) || 0, 0), staged.sheets.length - 1);
  const sheet = staged.sheets[sheetIndex];

  res.render('import/map', {
    title: 'Check the columns',
    token: req.params.token,
    kind: staged.kind,
    filename: staged.filename,
    sheets: staged.sheets,
    sheetIndex,
    sheet,
    sample: sheet.rows.slice(0, 5),
    mapping: suggestMemberMapping(sheet.headers),
    dateColumns: staged.kind === 'attendance' ? detectDateColumns(sheet.headers) : [],
    fields: MEMBER_FIELDS
  });
});

function readMapping(body, headers) {
  const mapping = {};
  for (const field of MEMBER_FIELDS) {
    const raw = body[`map_${field.key}`];
    const index = Number.parseInt(raw, 10);
    if (Number.isInteger(index) && index >= 0 && index < headers.length) mapping[field.key] = index;
  }
  return mapping;
}

/** Step three: show exactly what would happen, before anything is written. */
router.post('/admin/import/:token([a-f0-9]{32})/preview', requireAuth, requirePermission('members.create'),
  (req, res, next) => {
    const staged = loadStagedImport(req.params.token, { userId: req.user.id });
    if (!staged) return next();

    const sheetIndex = Math.min(Math.max(Number.parseInt(req.body.sheet, 10) || 0, 0), staged.sheets.length - 1);
    const sheet = staged.sheets[sheetIndex];
    const mapping = readMapping(req.body, sheet.headers);

    if (staged.kind === 'members') {
      if (mapping.first_name === undefined && mapping.full_name === undefined) {
        req.flash('error', 'Choose which column holds the name before continuing.');
        return res.redirect(`/admin/import/${req.params.token}?sheet=${sheetIndex}`);
      }
      const preview = previewMembers({ headers: sheet.headers, rows: sheet.rows, mapping });
      return res.render('import/preview-members', {
        title: 'Check before importing',
        token: req.params.token,
        filename: staged.filename,
        sheetIndex,
        mapping,
        preview,
        rows: preview.rows.slice(0, 200)
      });
    }

    const chosen = Array.isArray(req.body.date_columns)
      ? req.body.date_columns
      : (req.body.date_columns ? [req.body.date_columns] : []);
    const dateColumns = detectDateColumns(sheet.headers)
      .filter((c) => chosen.length === 0 || chosen.includes(String(c.index)));

    if (dateColumns.length === 0) {
      req.flash('error', 'No service dates were found in the column headings. Check the sheet and column choices.');
      return res.redirect(`/admin/import/${req.params.token}?sheet=${sheetIndex}`);
    }

    const preview = previewAttendance({ headers: sheet.headers, rows: sheet.rows, mapping, dateColumns });
    return res.render('import/preview-attendance', {
      title: 'Check before importing',
      token: req.params.token,
      filename: staged.filename,
      sheetIndex,
      mapping,
      dateColumns,
      preview,
      people: preview.people.slice(0, 200)
    });
  });

/** Step four: write it. */
router.post('/admin/import/:token([a-f0-9]{32})/commit', requireAuth, requirePermission('members.create'),
  (req, res, next) => {
    const staged = loadStagedImport(req.params.token, { userId: req.user.id });
    if (!staged) return next();

    const sheetIndex = Math.min(Math.max(Number.parseInt(req.body.sheet, 10) || 0, 0), staged.sheets.length - 1);
    const sheet = staged.sheets[sheetIndex];
    const mapping = readMapping(req.body, sheet.headers);

    if (staged.kind === 'members') {
      const preview = previewMembers({ headers: sheet.headers, rows: sheet.rows, mapping });
      const counts = commitMembers(preview, {
        userId: req.user.id,
        filename: staged.filename,
        createGroups: req.body.create_groups === 'on',
        updateExisting: req.body.update_existing === 'on'
      });

      recordAudit({
        req, action: 'members.imported', entityType: 'member',
        detail: { filename: staged.filename, ...counts }
      });
      discardStagedImport(req.params.token);

      req.flash('success',
        `${counts.created} member${counts.created === 1 ? '' : 's'} added, `
        + `${counts.updated} updated, ${counts.skipped} left out.`);
      return res.redirect('/members');
    }

    const chosen = Array.isArray(req.body.date_columns)
      ? req.body.date_columns
      : (req.body.date_columns ? [req.body.date_columns] : []);
    const dateColumns = detectDateColumns(sheet.headers)
      .filter((c) => chosen.length === 0 || chosen.includes(String(c.index)));
    const preview = previewAttendance({ headers: sheet.headers, rows: sheet.rows, mapping, dateColumns });
    let counts;
    try {
      counts = commitAttendance(preview, {
        userId: req.user.id,
        filename: staged.filename,
        createSessions: req.body.create_sessions === 'on'
      });
    } catch (err) {
      if (!(err instanceof AttendanceImportRefusedError)) throw err;
      // The attendance service refused part of this register (a cancelled,
      // future-dated, finalized or not-taken service). Nothing was imported - the whole import was
      // rolled back - and the staged file is kept so it can be corrected.
      recordAudit({
        req, action: 'attendance.imported', entityType: 'attendance_session',
        result: 'failure', detail: { filename: staged.filename, refused: err.refused }
      });
      const dates = err.refused.map((r) => r.date || `session ${r.sessionId}`).join(', ');
      req.flash('error',
        `Nothing was imported. Attendance cannot be recorded for: ${dates} `
        + '(the service was cancelled, has not happened yet, no longer exists, or its attendance has been finalized or marked not taken). '
        + 'Remove those dates from the sheet, or fix the service, and try again.');
      return res.redirect('/admin/import');
    }

    recordAudit({
      req, action: 'attendance.imported', entityType: 'attendance_session',
      detail: { filename: staged.filename, ...counts }
    });
    discardStagedImport(req.params.token);

    req.flash('success',
      `${counts.records} attendance record${counts.records === 1 ? '' : 's'} imported across `
      + `${counts.services} new service${counts.services === 1 ? '' : 's'}.`
      + (counts.skippedPeople ? ` ${counts.skippedPeople} row(s) had no matching member and were left out.` : ''));
    return res.redirect('/attendance/history');
  });

router.post('/admin/import/:token([a-f0-9]{32})/discard', requireAuth, requirePermission('members.create'),
  (req, res) => {
    discardStagedImport(req.params.token);
    req.flash('info', 'Import cancelled. Nothing was changed.');
    return res.redirect('/admin/import');
  });

export default router;
