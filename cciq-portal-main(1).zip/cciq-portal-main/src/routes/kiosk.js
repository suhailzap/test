import express from 'express';
import { requireAuth, checkinAccess } from '../middleware/auth.js';
import { searchPeopleForAttendance } from '../services/attendance.js';
import { looksLikePhone } from '../lib/phone.js';
import { checkinSession, checkedInState } from '../services/qr-checkin.js';
import { checkinClosure } from '../services/attendance-lifecycle.js';

const router = express.Router();

/**
 * The entrance kiosk's home screen. Deliberately its own route and its own
 * view (not just the admin /attendance/checkin screen with a different
 * layout) so the presentation can be as simple and touch-friendly as an
 * unattended terminal needs, while every underlying action — search, QR
 * lookup, review, record — goes through the exact same
 * /attendance/checkin/* endpoints and service functions the admin screen
 * already uses. See CCIQ_DECISIONS.md.
 */
router.get('/kiosk', requireAuth, checkinAccess, (req, res) => {
  const session = checkinSession();
  const term = String(req.query.q || '').slice(0, 80);
  // Numbers are searched by POST (/attendance/checkin/search) so they never sit in the address bar or history.
  if (looksLikePhone(term)) return res.redirect('/kiosk');
  const closure = checkinClosure(session);
  const results = session && !closure && term ? searchPeopleForAttendance(term) : [];

  res.render('kiosk/home', {
    title: 'Attendance Kiosk',
    session,
    checkinClosed: closure,
    term,
    searched: Boolean(term),
    canExpressRegister: req.user.can('visitors.express_register'),
    results,
    selected: new Set((Array.isArray(req.query.selected) ? req.query.selected : [req.query.selected]).filter((value) => typeof value === 'string' && /^(member|visitor):\d+$/.test(value))),
    checkedIn: checkedInState(),
    layout: 'kiosk'
  });
});

router.get('/kiosk/count', requireAuth, checkinAccess, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, ...checkedInState() });
});

export default router;
