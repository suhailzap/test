import express from 'express';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { scopeFor } from '../services/members.js';
import { listGroups, activeGroupOptions } from '../services/cell-groups.js';
import { scheduleStatus } from '../services/friday-service.js';
import { currentCampaign, listCampaigns } from '../services/ecaq.js';
import { recordAudit } from '../lib/audit.js';
import { today, addDays, isValidDate } from '../lib/dates.js';
import { AGE_GROUPS, AGE_GROUP_LABELS } from '../services/congregations.js';
import {
  MEMBER_STATUSES, STATUS_LABELS, CURRENT_POPULATION_STATUSES, DEFAULT_ROSTER_STATUSES, normalizeMemberStatuses
} from '../services/members.js';
import {
  attendancePdf, directoryPdf, occasionsPdf, cellGroupsPdf, allYearsGivingPdf, givingPdf,
  firstTimersPdf, faithPromisePdf, longAbsencePdf, REPORTS
} from '../services/reports-pdf.js';
import { LONG_ABSENCE_SORT_COLUMNS, parseAttendanceStatusFilter } from '../services/attendance.js';
import { parsePaging, paginateList } from '../lib/paging.js';
import { VISITOR_STATES, STATE_LABELS, inviterSummary } from '../services/visitors.js';
import { STATUS_LABELS as FP_STATUS_LABELS } from '../services/faith-promise.js';
import {
  fridayAttendanceOverview, fridayAttendanceOverviewCsv, membershipOverview, membershipOverviewCsv,
  cellGroupsOverview, cellGroupsOverviewCsv, parseReportRange, parseCellGroupFilter,
  FRIDAY_SESSION_SORT_COLUMNS, sortFridaySessions, PHASE_LABELS
} from '../services/reports.js';

const router = express.Router();

/**
 * One place to reach every report the portal produces. Each entry links to the
 * screen that owns it, so there is a single implementation behind each report
 * rather than a second copy living here.
 */
router.get('/reports', requireAuth, requirePermission('reports.view'), (req, res) => {
  const canExport = req.user.can('reports.export');
  const schedule = scheduleStatus();
  const campaign = currentCampaign();

  const groups = [
    {
      name: `${schedule.title || 'Friday Service'} attendance`,
      reports: [
        { label: 'Attendance overview', detail: 'Trend and overall rate across a range of Friday Services, with a Friday-by-Friday breakdown.', href: '/reports/attendance', permission: 'reports.view' },
        { label: 'Attendance report', detail: 'Attendance per member across a range of Friday Services.', href: '/attendance/reports', permission: 'reports.view' },
        { label: 'Attendance export', detail: 'The per-member report as a CSV file.', href: '/attendance/reports/export.csv', permission: 'reports.export', download: true },
        { label: 'Follow-up list', detail: 'Members with no recorded attendance for consecutive Friday Services.', href: '/attendance/follow-up', permission: 'attendance.followup' },
        { label: 'Service history', detail: 'Every session, who was present and what was recorded.', href: '/attendance/history', permission: 'attendance.view' }
      ]
    },
    {
      name: 'Membership',
      reports: [
        { label: 'Membership overview', detail: 'Current population vs total records, and the status breakdown behind each figure.', href: '/reports/membership', permission: 'reports.view' },
        { label: 'Member list', detail: 'Search, filter and sort every member record.', href: '/members', permission: 'members.view' },
        { label: 'Active and inactive members', detail: 'Filter the member list by membership status.', href: '/members?status=active', permission: 'members.view' },
        { label: 'Member export', detail: 'Every member matching your filters as a CSV file.', href: '/members/export.csv', permission: 'reports.export', download: true },
        { label: 'Birthday list', detail: 'Upcoming birthdays over a period you choose.', href: '/members/birthdays?days=90', permission: 'members.view' },
        { label: 'Anniversary list', detail: 'Upcoming wedding anniversaries.', href: '/members/anniversaries?days=90', permission: 'members.view' }
      ]
    },
    {
      name: 'Cell groups',
      reports: [
        { label: 'Cell group overview', detail: 'Roster size and recent attendance for every active group, side by side.', href: '/reports/cell-groups', permission: 'reports.view' },
        { label: 'Cell group membership', detail: 'Groups, leaders and how many members each has.', href: '/cell-groups', permission: 'cellgroups.view' },
        ...listGroups({ includeInactive: false }).slice(0, 6).map((g) => ({
          label: `${g.name} report`,
          detail: 'Membership, attendance and follow-up for this group.',
          href: `/cell-groups/${g.id}?tab=reports`,
          permission: 'reports.view'
        }))
      ]
    },
    {
      name: 'Visitors and follow-up',
      reports: [
        { label: 'First Timers and visitors', detail: 'Everyone visiting, their state, and who invited them.', href: '/visitors', permission: 'members.view' },
        { label: 'Visitor follow-up', detail: 'Visitors past the grace period with no follow-up recorded yet.', href: '/visitors/follow-up', permission: 'members.view' },
        { label: 'Attendance follow-up', detail: 'Members with no recorded attendance for consecutive Friday Services.', href: '/attendance/follow-up', permission: 'attendance.followup' }
      ]
    },
    {
      name: 'Operations',
      reports: [
        { label: 'Activity list', detail: 'Church and cell group activities, filtered by type and status.', href: '/activities', permission: 'activities.view' },
        { label: 'Announcements', detail: 'What has been published, to whom, and when it expires.', href: '/announcements', permission: 'announcements.view' },
        ...(campaign ? [
          { label: `${campaign.year} Giving Board progress`, detail: 'Dates claimed, members taking part, commitments and collections.', href: `/admin/ecaq?campaign=${campaign.id}`, permission: 'giving.manage' },
          { label: 'Giving Board claims export', detail: 'Every claim with its commitment, amount collected and payment status.', href: `/admin/ecaq/claims.csv?campaign=${campaign.id}`, permission: 'giving.manage', download: true }
        ] : []),
        { label: 'Audit log', detail: 'Every recorded administrative action.', href: '/admin/audit', permission: 'admin.audit' },
        { label: 'Audit export', detail: 'The audit log as a CSV file.', href: '/admin/audit.csv', permission: 'admin.audit', download: true },
        { label: 'Backup history', detail: 'Backups taken, verified and restored.', href: '/admin/backups', permission: 'admin.backups.view' }
      ]
    }
  ];

  // Nobody is shown a report they cannot open.
  const visible = groups
    .map((group) => ({ ...group, reports: group.reports.filter((r) => req.user.can(r.permission)) }))
    .filter((group) => group.reports.length > 0);

  res.render('reports/index', {
    title: 'Reports',
    printable: Object.entries(REPORTS)
      .filter(([, spec]) => req.user.can(spec.permission))
      .map(([key, spec]) => ({ key, ...spec })),
    groups: visible,
    canExport,
    fridayTitle: schedule.title || 'CCIQ Friday Service'
  });
});

/**
 * The Friday attendance trend and its overall rate over a range the visitor
 * chooses — not a duplicate of /attendance/reports, which is one row per
 * member; this is the aggregate view the previous Reports page never had.
 */
router.get('/reports/attendance', requireAuth, requirePermission('reports.view'), (req, res) => {
  const range = parseReportRange(req.query);
  const cellGroupId = parseCellGroupFilter(req.query);
  const overview = fridayAttendanceOverview({ ...range, cellGroupId });
  const sort = FRIDAY_SESSION_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'date';
  const direction = req.query.direction === 'asc' ? 'asc' : 'desc';
  // The chart and the totals cover the whole range; the per-Friday table is paged on the server
  // (the CSV export still has every Friday).
  const paging = paginateList(sortFridaySessions(overview.sessions, sort, direction), parsePaging(req.query));

  res.render('reports/attendance', {
    title: 'Attendance overview',
    overview,
    sortedSessions: paging.rows,
    paging,
    pagerParams: {
      from: range.from, to: range.to, cell_group_id: cellGroupId, sort, direction,
      page_size: paging.pageSize === 25 ? '' : paging.pageSize
    },
    filters: { ...range, cellGroupId, sort, direction },
    cellGroups: activeGroupOptions(),
    canExport: req.user.can('reports.export'),
    phaseLabels: PHASE_LABELS
  });
});

router.get('/reports/attendance/export.csv', requireAuth, requirePermission('reports.view', 'reports.export'), (req, res) => {
  const range = parseReportRange(req.query);
  const cellGroupId = parseCellGroupFilter(req.query);
  const sort = FRIDAY_SESSION_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'date';
  const direction = req.query.direction === 'asc' ? 'asc' : 'desc';
  const { csv } = fridayAttendanceOverviewCsv({ ...range, cellGroupId, sort, direction });

  recordAudit({ req, action: 'report.exported', entityType: 'report', entityId: 'attendance-overview', detail: { ...range, cellGroupId } });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="cciq-attendance-overview-${range.from}-to-${range.to}.csv"`);
  res.send(csv);
});

/**
 * Current population vs total records, and the status breakdown behind each
 * — the number the old Reports stat card got wrong by showing `active` alone
 * and calling it the church's population.
 */
router.get('/reports/membership', requireAuth, requirePermission('reports.view'), (req, res) => {
  const overview = membershipOverview(scopeFor(req.user));
  res.render('reports/membership', {
    title: 'Membership overview',
    overview,
    canExport: req.user.can('reports.export')
  });
});

router.get('/reports/membership/export.csv', requireAuth, requirePermission('reports.view', 'reports.export'), (req, res) => {
  const { csv } = membershipOverviewCsv(scopeFor(req.user));
  recordAudit({ req, action: 'report.exported', entityType: 'report', entityId: 'membership-overview', detail: {} });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="cciq-membership-overview-${today()}.csv"`);
  res.send(csv);
});

/**
 * One row per active cell group: roster size and recent attendance, side by
 * side, without ranking or a "best/worst" label.
 */
router.get('/reports/cell-groups', requireAuth, requirePermission('reports.view'), (req, res) => {
  const groups = cellGroupsOverview({ scope: scopeFor(req.user) });
  res.render('reports/cell-groups', {
    title: 'Cell group overview',
    groups,
    canExport: req.user.can('reports.export')
  });
});

router.get('/reports/cell-groups/export.csv', requireAuth, requirePermission('reports.view', 'reports.export'), (req, res) => {
  const { csv } = cellGroupsOverviewCsv({ scope: scopeFor(req.user) });
  recordAudit({ req, action: 'report.exported', entityType: 'report', entityId: 'cell-groups-overview', detail: {} });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="cciq-cell-groups-overview-${today()}.csv"`);
  res.send(csv);
});

/** A compact launcher: pick a report, configure it, then open it. */
router.get('/reports/print', requireAuth, requirePermission('reports.view'), (req, res) => {
  res.render('reports/print', {
    title: 'Print a report',
    reports: REPORTS,
    can: (key) => req.user.can(REPORTS[key].permission),
    groups: listGroups({ includeInactive: false }),
    campaigns: listCampaigns().filter((c) => c.type === 'giving_board'),
    faithPromiseCampaigns: listCampaigns().filter((c) => c.type === 'faith_promise'),
    statuses: MEMBER_STATUSES,
    statusLabels: STATUS_LABELS,
    currentStatuses: CURRENT_POPULATION_STATUSES,
    defaultRosterStatuses: DEFAULT_ROSTER_STATUSES,
    congregations: AGE_GROUPS,
    congregationLabels: AGE_GROUP_LABELS,
    visitorStates: VISITOR_STATES,
    visitorStateLabels: STATE_LABELS,
    faithPromiseStatuses: ['not_started', 'in_progress', 'completed'],
    faithPromiseStatusLabels: FP_STATUS_LABELS,
    inviters: inviterSummary({ pageSize: 500 }).rows,
    defaults: {
      from: addDays(today(), -90),
      to: today(),
      aheadFrom: today(),
      aheadTo: addDays(today(), 90)
    },
    canGiving: req.user.can('giving.manage')
  });
});

/**
 * Reports stream straight to the browser as PDF. Each one checks the same
 * permission its on-screen version does.
 */
router.get('/reports/:key/pdf', requireAuth, requirePermission('reports.view'), (req, res, next) => {
  const key = req.params.key;
  const spec = REPORTS[key];
  if (!spec) return next();
  if (!req.user.can(spec.permission)) {
    const err = new Error('That report is not available to your role.');
    err.status = 403;
    return next(err);
  }

  const isDate = (value) => isValidDate(value || ''); // a real calendar date: "0000-00-00" and "9999-99-99" have the right shape and are not dates
  const looksAhead = key === 'occasions';
  const from = isDate(req.query.from) ? req.query.from : (looksAhead ? today() : addDays(today(), -90));
  const to = isDate(req.query.to) ? req.query.to : (looksAhead ? addDays(today(), 90) : today());

  let doc;
  try {
    if (key === 'attendance') {
      doc = attendancePdf({
        from,
        to,
        cellGroupId: Number.parseInt(req.query.cell_group_id, 10) || null,
        statuses: parseAttendanceStatusFilter(req.query)
      });
    } else if (key === 'directory') {
      // No explicit submission (a bookmarked/direct URL) keeps this report's
      // long-standing default of Active only. An explicit submission is
      // honoured literally, even empty — the same "empty means every
      // status" convention Members' own multi-status filter already uses —
      // never silently narrowed back to Active once the user has chosen.
      doc = directoryPdf({
        statuses: req.query.statuses_submitted === '1' ? normalizeMemberStatuses(req.query.status) : ['active'],
        includeContact: req.query.contact === 'yes' && req.user.can('members.view_contact'),
        congregation: AGE_GROUPS.includes(req.query.congregation) ? req.query.congregation : null
      });
    } else if (key === 'occasions') {
      doc = occasionsPdf({
        from,
        to,
        include: ['both', 'birthdays', 'anniversaries'].includes(req.query.include) ? req.query.include : 'both',
        status: req.query.status === 'all' || req.query.status === 'connected' || MEMBER_STATUSES.includes(req.query.status)
          ? req.query.status
          : 'connected'
      });
    } else if (key === 'cell-groups') {
      const raw = Array.isArray(req.query.cell_group_id)
        ? req.query.cell_group_id
        : (req.query.cell_group_id ? [req.query.cell_group_id] : []);
      doc = cellGroupsPdf({
        groupIds: raw,
        includeInactive: req.query.inactive === 'yes',
        rostersOnly: req.query.summary === 'yes'
      });
    } else if (key === 'first-timers') {
      doc = firstTimersPdf({
        from: req.query.from ? from : null,
        to: req.query.to ? to : null,
        state: VISITOR_STATES.includes(req.query.state) ? req.query.state : null,
        inviterId: Number.parseInt(req.query.inviter_id, 10) || null
      });
    } else if (key === 'faith-promise') {
      const fpCampaignId = Number.parseInt(req.query.campaign, 10)
        || listCampaigns().find((c) => c.type === 'faith_promise')?.id;
      doc = faithPromisePdf({
        campaignId: fpCampaignId,
        status: ['not_started', 'in_progress', 'completed'].includes(req.query.status) ? req.query.status : null
      });
    } else if (key === 'long-absence') {
      doc = longAbsencePdf({
        sort: Object.keys(LONG_ABSENCE_SORT_COLUMNS).includes(req.query.sort) ? req.query.sort : 'days_away',
        direction: req.query.dir === 'asc' ? 'asc' : 'desc'
      });
    } else if (req.query.campaign === 'all') {
      // Several years run at once, so the church can ask for all of them on
      // one page with each year kept on its own line.
      doc = allYearsGivingPdf();
    } else {
      doc = givingPdf({ campaignId: Number.parseInt(req.query.campaign, 10) || null });
    }
  } catch (err) {
    return next(err);
  }

  recordAudit({
    req, action: 'report.printed', entityType: 'report', entityId: key,
    detail: { from, to, contact: req.query.contact === 'yes' }
  });

  const stamp = today();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="cciq-${key}-${stamp}.pdf"`);
  doc.pipe(res);
  return undefined;
});

export default router;
