import { atomicRouter } from '../lib/atomic-router.js';
import { campaignLedger, ledgerCsv, periodText, LEDGER_MEMBER_SORTS, LEDGER_PAYMENT_SORTS } from '../services/campaign-ledger.js';
import { streamFile } from '../lib/stream-file.js';
import { parsePaging, paginateList, serverPaged, pageSizeParam } from '../lib/paging.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator, MONEY_PATTERN } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { today, formatDate } from '../lib/dates.js';
import {
  PROJECT_FACTS,
  PRIVACY_MODES,
  PRIVACY_LABELS,
  PAYMENT_STATUSES,
  PAYMENT_LABELS,
  GIVING_BOARD_SLOT_AMOUNT,
  memberClaimCount,
  setClaimDisplayName,
  CAMPAIGN_STATUSES,
  CAMPAIGN_TYPES,
  CAMPAIGN_TYPE_LABELS,
  daysInYear,
  campaignWindow,
  campaignDayCount,
  dateInCampaign,
  listCampaigns,
  getCampaign,
  currentCampaign,
  createCampaign,
  updateCampaign,
  buildBoard,
  campaignProgress,
  createClaim,
  getClaim,
  claimForDate,
  claimsForMember,
  updateClaimFinance,
  releaseClaim,
  listClaims,
  claimsCsv,
  CLAIM_SORT_COLUMNS,
  listProjectUpdates,
  createProjectUpdate,
  setProjectUpdateStatus,
  getProjectUpdate,
  deleteProjectUpdate,
  listProjectMedia,
  formatMoney,
  listPayments,
  addPayment,
  deletePayment,
  updatePayment,
  getPayment,
  memberPaymentSummary,
  campaignPayments,
  outstandingClaims,
  paymentsCsv,
  PAYMENT_METHODS,
  METHOD_LABELS,
  PAYMENT_SORT_COLUMNS,
  OUTSTANDING_SORT_COLUMNS,
  setCampaignBackground,
  DEFAULT_BOARD_BACKGROUND
} from '../services/ecaq.js';
import { getMember, pickerCardFor } from '../services/members.js';
import {
  GIVING_FREQUENCIES, FREQUENCY_LABELS, COMMITMENT_STATUSES as FP_COMMITMENT_STATUSES,
  STATUS_LABELS as FP_STATUS_LABELS, PAYMENT_METHODS as FP_PAYMENT_METHODS,
  getCommitment as fpGetCommitment, commitmentForMember, commitmentsForMember as fpCommitmentsForMember,
  listCommitments as fpListCommitments, COMMITMENT_SORT_COLUMNS,
  submitCommitment, commitmentForSubmitter, knownReceivers, amendCommitment, commitmentHistory, amendedCommitmentIds, listPayments as fpListPayments, getPayment as fpGetPayment,
  addPayment as fpAddPayment, updatePayment as fpUpdatePayment, deletePayment as fpDeletePayment,
  reportData as fpReportData
} from '../services/faith-promise.js';
import fs from 'node:fs';
import path from 'node:path';
import config from '../config/env.js';
import {
  memberPhotoUpload, saveCampaignBackground, resolveStoredFile, contentTypeFor, uploadErrorMessage, pruneSiblings, discardStoredFile
} from '../lib/uploads.js';
import { transaction } from '../db/index.js';
import { verifyCsrf } from '../lib/csrf.js';

const router = atomicRouter();

/** A payment as the audit row keeps it: every field that matters, so a correction or a removal can always be reconstructed from the audit log. */
function paymentSnapshot(p) {
  return {
    id: p.id, amount: p.amount, paid_on: p.paid_on, method: p.method, reference: p.reference || null, notes: p.notes || null,
    // "Received by" (the person who took the money) exists on Faith Promise payments only; "recorded by" is the signed-in administrator who entered it.
    ...(p.received_by !== undefined ? { received_by: p.received_by || null } : {}),
    recorded_at: p.created_at, recorded_by: p.created_by
  };
}

const MOTTO = 'One church. Many members. One commitment. One worship center.';

// --- Project page ----------------------------------------------------------

router.get('/projects/ecaq', requireAuth, requirePermission('ecaq.view'), (req, res) => {
  const canManage = req.user.can('ecaq.manage');
  const campaign = currentCampaign();
  const faithPromiseCampaign = currentFaithPromiseCampaign();

  res.render('ecaq/index', {
    title: 'ECAQ Worship Centre',
    motto: MOTTO,
    facts: PROJECT_FACTS,
    updates: listProjectUpdates({ includeUnpublished: canManage }),
    media: listProjectMedia(),
    campaign,
    progress: campaign ? campaignProgress(campaign) : null,
    faithPromiseCampaign,
    faithPromiseSummary: faithPromiseCampaign ? fpReportData(faithPromiseCampaign.id) : null,
    canManage,
    canSeeBoard: req.user.can('giving.view_board'),
    formatMoney
  });
});

// --- Giving board ----------------------------------------------------------

router.get('/projects/ecaq/board', requireAuth, requirePermission('giving.view_board'), (req, res, next) => {
  // This page is the Giving Board specifically — a campaign of a different
  // type (Faith Promise, or a future custom campaign) has its own page, and
  // never appears here as a year to switch to.
  const campaigns = listCampaigns().filter((c) => c.type === 'giving_board');
  const requestedYear = Number.parseInt(req.query.year, 10);
  const campaign = requestedYear
    ? campaigns.find((c) => c.year === requestedYear) || null
    : currentCampaign();

  /*
   * Each year is its own board, so the tabs list every year the church has
   * opened. A year with no board yet is still shown, so an administrator can
   * see where to start one.
   */
  const years = [...new Set(campaigns.map((c) => c.year))].sort((a, b) => a - b);

  if (!campaign) {
    return res.render('ecaq/board-empty', {
      title: 'CCIQ Giving Board',
      motto: MOTTO,
      years,
      requestedYear: requestedYear || null,
      canManage: req.user.can('giving.manage')
    });
  }

  const forAdmin = req.user.can('giving.manage');
  const board = buildBoard(campaign, { viewerMemberId: req.user.memberId, forAdmin });

  return res.render('ecaq/board', {
    title: 'CCIQ Giving Board',
    motto: MOTTO,
    campaign,
    board,
    dateWindow: campaignWindow(campaign),
    progress: campaignProgress(campaign),
    campaigns,
    years,
    myClaims: req.user.memberId ? claimsForMember(req.user.memberId, { campaignId: campaign.id }) : [],
    canClaim: req.user.can('giving.claim') && Boolean(req.user.memberId) && campaign.status === 'active',
    // Recording a date for someone else, and opening the money side of an
    // existing one, are both administration, whether or not the administrator
    // happens to hold a member record themselves.
    canRecordForMember: req.user.can('giving.manage') && campaign.status === 'active',
    canManage: forAdmin,
    canManageFinance: req.user.can('giving.manage_finance'),
    privacyLabels: PRIVACY_LABELS,
    paymentLabels: PAYMENT_LABELS,
    formatMoney,
    today: today()
  });
});

/** Confirmation step: a claim is never one accidental tap away. */

/**
 * With several years open at once, a date belongs to the board for its own
 * year rather than to whichever board happens to be shown by default.
 */
function campaignForDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || ''))) return null;
  const year = Number(String(date).slice(0, 4));
  return listCampaigns().find((c) => c.year === year && c.status === 'active' && c.type === 'giving_board' && dateInCampaign(c, date)) || null;
}

router.get('/projects/ecaq/board/claim', requireAuth, requirePermission('giving.claim'), (req, res, next) => {
  const date = String(req.query.date || '');
  const campaign = campaignForDate(date);

  if (!campaign) {
    req.flash('error', 'Choose a date from one of the open boards.');
    return res.redirect('/projects/ecaq/board');
  }

  const existing = claimForDate(campaign.id, date);
  if (existing) {
    req.flash('info', 'That date has already been claimed. Please choose another.');
    return res.redirect('/projects/ecaq/board');
  }
  if (!req.user.memberId) {
    req.flash('error', 'Your account is not linked to a member record yet.');
    return res.redirect('/projects/ecaq/board');
  }

  return res.render('ecaq/claim-confirm', {
    title: 'Confirm your commitment',
    motto: MOTTO,
    campaign,
    date,
    alreadyHeld: memberClaimCount(req.user.memberId, campaign.id),
    suggestedName: req.user.member
      ? `${req.user.member.preferred_name || req.user.member.first_name} ${req.user.member.last_name || ''}`.trim()
      : '',
    privacyLabels: PRIVACY_LABELS,
    formatMoney
  });
});

router.post('/projects/ecaq/board/claim', requireAuth, requirePermission('giving.claim'), (req, res) => {
  // The board is decided by the date, so a day in a future year is recorded on
  // that year's board rather than this one's.
  const campaign = campaignForDate(req.body.date);
  if (!campaign) {
    req.flash('error', 'Choose a date from one of the open boards.');
    return res.redirect('/projects/ecaq/board');
  }
  if (!req.user.memberId) {
    req.flash('error', 'Your account is not linked to a member record yet.');
    return res.redirect('/projects/ecaq/board');
  }

  const v = new Validator(req.body);
  const date = v.date('date', { required: true, label: 'Date' });
  const notes = v.text('notes', { max: 300, label: 'Note' });
  const displayAs = v.text('display_as', { max: 60, label: 'Name to show' });
  if (!v.valid) {
    req.flash('error', 'Choose a date from the board.');
    return res.redirect(`/projects/ecaq/board?year=${campaign.year}`);
  }

  const result = createClaim({
    campaignId: campaign.id,
    date,
    memberId: req.user.memberId,
    notes,
    displayAs,
    userId: req.user.id
  });

  if (!result.ok) {
    const messages = {
      already_claimed: 'That date was claimed by someone else a moment ago. Please choose another.',
      campaign_not_active: 'The board is not open for claims at the moment.',
      date_not_in_campaign: 'That date is not part of this campaign.',
      no_campaign: 'There is no campaign open at the moment.'
    };
    req.flash(result.reason === 'already_claimed' ? 'info' : 'error', messages[result.reason] || 'That claim could not be recorded.');
    return res.redirect('/projects/ecaq/board');
  }

  recordAudit({
    req, action: 'giving.claim_created', entityType: 'ecaq_claim', entityId: result.claim.id,
    detail: { date, campaign_id: campaign.id, member_id: req.user.memberId }
  });

  req.flash('success', 'Your commitment is recorded. Thank you.');
  return res.redirect(`/projects/ecaq/board#date-${date}`);
});

router.post('/projects/ecaq/claims/:id(\\d+)/display-name', requireAuth, requirePermission('giving.claim'),
  (req, res, next) => {
    const claim = getClaim(Number(req.params.id));
    if (!claim) return next();

    // A member may only relabel a date they hold themselves.
    if (Number(claim.member_id) !== Number(req.user.memberId) && !req.user.can('giving.manage')) {
      const err = new Error('You can only change the name shown on your own commitment.');
      err.status = 403;
      return next(err);
    }

    setClaimDisplayName(claim.id, req.body.display_as);
    recordAudit({
      req, action: 'giving.claim_display_changed', entityType: 'ecaq_claim', entityId: claim.id,
      detail: { date: claim.claim_date }
    });
    req.flash('success', 'The name shown on the board has been updated.');
    return res.redirect('/projects/ecaq/my-commitments');
  });

/**
 * A member's commitments across every ECAQ campaign they've taken part in —
 * not just the Giving Board. Each campaign type is queried through its own
 * existing service (claimsForMember / commitmentsForMember), the same
 * functions their own dedicated pages already use, so a future campaign year
 * of either type appears here with no further change to this route or view.
 */
router.get('/projects/ecaq/my-commitments', requireAuth, requirePermission('giving.view_board'), (req, res) => {
  const memberId = req.user.memberId;
  const canSeeFaithPromise = req.user.can('ecaq.view');

  res.render('ecaq/my-commitments', {
    title: 'My commitments',
    motto: MOTTO,
    claims: memberId ? claimsForMember(memberId) : [],
    statement: memberId ? memberPaymentSummary(memberId) : null,
    faithPromiseCommitments: memberId && canSeeFaithPromise ? fpCommitmentsForMember(memberId) : [],
    canSeeFaithPromise,
    paymentLabels: PAYMENT_LABELS,
    methodLabels: METHOD_LABELS,
    frequencyLabels: FREQUENCY_LABELS,
    fpStatusLabels: FP_STATUS_LABELS,
    formatMoney
  });
});

// --- Faith Promise -----------------------------------------------------------

/** The current Faith Promise campaign, whichever year it happens to be. */
function currentFaithPromiseCampaign() {
  const campaigns = listCampaigns().filter((c) => c.type === 'faith_promise');
  const thisYear = Number(today().slice(0, 4));
  return campaigns.find((c) => c.year === thisYear && c.status === 'active')
    || campaigns.find((c) => c.status === 'active')
    || campaigns[campaigns.length - 1]
    || null;
}

/**
 * The one campaign a member's own submission can go to: this year's ACTIVE Faith Promise, else another ACTIVE one. Never a draft, closed or archived
 * campaign, and never a fallback to "the latest": a submission that cannot go to an active campaign is refused, not redirected to another one.
 */
function activeFaithPromiseCampaign() {
  const active = listCampaigns().filter((c) => c.type === 'faith_promise' && c.status === 'active');
  const thisYear = Number(today().slice(0, 4));
  return active.find((c) => c.year === thisYear) || active[0] || null;
}

router.get('/projects/ecaq/faith-promise', requireAuth, requirePermission('ecaq.view'), (req, res) => {
  const campaign = currentFaithPromiseCampaign();
  const existing = campaign
    ? commitmentForSubmitter(campaign.id, { memberId: req.user.memberId || null, userId: req.user.id })
    : null;

  res.render('ecaq/faith-promise', {
    title: 'CCIQ Faith Promise',
    campaign,
    accepting: Boolean(campaign && campaign.status === 'active' && activeFaithPromiseCampaign()?.id === campaign.id),
    existing,
    payments: existing ? fpListPayments(existing.id) : [],
    frequencies: GIVING_FREQUENCIES,
    frequencyLabels: FREQUENCY_LABELS,
    formatMoney
  });
});

router.post('/projects/ecaq/faith-promise', requireAuth, requirePermission('ecaq.view'), (req, res) => {
  const campaign = activeFaithPromiseCampaign();
  // A Faith Promise is submitted ONCE. If this person already holds one, nothing is read from the request and nothing is changed: a crafted post to this old
  // "update" address is refused here (and again inside submitCommitment, which never changes an existing commitment). Only an administrator may amend it.
  if (campaign) {
    const already = commitmentForSubmitter(campaign.id, { memberId: req.user.memberId || null, userId: req.user.id });
    if (already) {
      req.flash('error', 'Your Faith Promise has already been recorded, so nothing was changed. To change it, please contact the Church Administration.');
      return res.redirect('/projects/ecaq/faith-promise');
    }
  }
  // The form names the campaign it was shown for. If that is not the open one (it was closed meanwhile, or the post was crafted), nothing is saved and the
  // commitment is NOT moved to another campaign.
  const named = req.body.campaign_id ? Number(req.body.campaign_id) : null;
  if (!campaign || (named !== null && named !== campaign.id)) {
    req.flash('error', 'This Faith Promise is not open for new commitments, so nothing was saved.');
    return res.redirect('/projects/ecaq/faith-promise');
  }

  const v = new Validator(req.body);
  v.text('name', { required: true, max: 120, label: 'Name' });
  v.phone('phone');
  v.email('email');
  v.oneOf('frequency', GIVING_FREQUENCIES, { required: true, label: 'How you will give' });

  const amountRaw = String(req.body.amount ?? '').trim();
  const validAmount = MONEY_PATTERN.test(amountRaw) && Number(amountRaw) > 0;
  if (!validAmount) v.fail('amount', 'Enter an amount using digits only (at most 999,999,999.99).');

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect('/projects/ecaq/faith-promise');
  }
  const amount = Number(amountRaw);

  const result = submitCommitment(campaign.id, {
    member_id: req.user.memberId || null,
    name: v.values.name,
    phone: v.values.phone,
    email: v.values.email,
    amount,
    frequency: v.values.frequency
  }, { userId: req.user.id, requireActive: true });

  if (!result.ok) {
    req.flash('error', result.reason === 'campaign_not_active'
      ? 'This Faith Promise is not open for new commitments, so nothing was saved.'
      : result.reason === 'already_submitted'
        ? 'Your Faith Promise has already been recorded, so nothing was changed. To change it, please contact the Church Administration.'
        : 'That commitment could not be saved. Please check the amount and try again.');
    return res.redirect('/projects/ecaq/faith-promise');
  }

  recordAudit({
    req, action: 'ecaq.faith_promise_submitted',
    entityType: 'faith_promise_commitment', entityId: result.commitment.id,
    detail: { campaign_id: campaign.id, amount: Number(result.commitment.commitment_amount), frequency: result.commitment.frequency, expected_total: Number(result.commitment.expected_total) }
  });
  req.flash('success', 'Thank you — your Faith Promise commitment has been recorded.');
  return res.redirect('/projects/ecaq/faith-promise');
});

/**
 * Not every member has a sign-in account, so an administrator needs to be
 * able to record a Faith Promise for someone directly — the same
 * submitCommitment used by the member's own form, just with the member
 * chosen from a list instead of taken from who is signed in.
 */
router.get('/admin/ecaq/faith-promise/new', requireAuth, requirePermission('giving.manage'), (req, res) => {
  const campaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : currentFaithPromiseCampaign();
  if (!campaign || campaign.type !== 'faith_promise') {
    req.flash('error', 'Choose a Faith Promise campaign first.');
    return res.redirect('/admin/ecaq/faith-promise');
  }

  res.render('ecaq/faith-promise-for-member', {
    title: 'Record a Faith Promise for a member',
    campaign,
    memberSelected: null,
    frequencies: GIVING_FREQUENCIES,
    frequencyLabels: FREQUENCY_LABELS,
    errors: {},
    values: {}
  });
});

router.post('/admin/ecaq/faith-promise/new', requireAuth, requirePermission('giving.manage'), (req, res) => {
  const campaign = req.body.campaign_id ? getCampaign(Number(req.body.campaign_id)) : currentFaithPromiseCampaign();
  const rerender = (errors) => res.status(400).render('ecaq/faith-promise-for-member', {
    title: 'Record a Faith Promise for a member',
    campaign,
    memberSelected: pickerCardFor(req.body.member_id),
    frequencies: GIVING_FREQUENCIES,
    frequencyLabels: FREQUENCY_LABELS,
    errors,
    values: req.body
  });

  if (!campaign || campaign.type !== 'faith_promise') {
    req.flash('error', 'Choose a Faith Promise campaign first.');
    return res.redirect('/admin/ecaq/faith-promise');
  }

  const memberId = Number.parseInt(req.body.member_id, 10);
  if (!memberId) return rerender({ member_id: 'Choose who this commitment is for.' });

  const member = getMember(memberId);
  if (!member) return rerender({ member_id: 'That member could not be found.' });

  if (!GIVING_FREQUENCIES.includes(req.body.frequency)) {
    return rerender({ frequency: 'Choose how they will give.' });
  }

  const amountRaw = String(req.body.amount ?? '').trim();
  if (!MONEY_PATTERN.test(amountRaw) || Number(amountRaw) <= 0) {
    return rerender({ amount: 'Enter an amount using digits only (at most 999,999,999.99).' });
  }

  const result = submitCommitment(campaign.id, {
    member_id: memberId,
    name: req.body.name?.trim() || `${member.first_name} ${member.last_name}`,
    phone: req.body.phone || member.phone,
    email: req.body.email || member.email,
    amount: Number(amountRaw),
    frequency: req.body.frequency
  }, { userId: req.user.id });

  if (!result.ok && result.reason === 'already_submitted') {
    // Recording is for a NEW commitment. Changing an existing one is an amendment (with a reason, kept in its history) made on the commitment itself.
    return rerender({ member_id: `${member.first_name} ${member.last_name} already has a Faith Promise in this campaign. Open it from the list and use Amend commitment to change it.` });
  }
  if (!result.ok) return rerender({ amount: 'That commitment could not be saved.' });

  recordAudit({
    req, action: 'ecaq.faith_promise_submitted_for_member',
    entityType: 'faith_promise_commitment', entityId: result.commitment.id,
    detail: { member_id: memberId, campaign_id: campaign.id, amount: Number(result.commitment.commitment_amount), frequency: result.commitment.frequency, expected_total: Number(result.commitment.expected_total) }
  });
  req.flash('success', `Faith Promise recorded for ${member.first_name} ${member.last_name}.`);
  return res.redirect(`/admin/ecaq/faith-promise/commitments/${result.commitment.id}`);
});

router.get('/admin/ecaq/faith-promise', requireAuth, requirePermission('giving.manage'), (req, res) => {
  const campaigns = listCampaigns().filter((c) => c.type === 'faith_promise');
  const requestedCampaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : null;
  const campaign = requestedCampaign && requestedCampaign.type === 'faith_promise'
    ? requestedCampaign
    : currentFaithPromiseCampaign();
  const status = FP_COMMITMENT_STATUSES.includes(req.query.status) ? req.query.status : null;
  const search = String(req.query.q || '').slice(0, 60);
  const sort = COMMITMENT_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'name';
  const direction = req.query.direction === 'desc' ? 'desc' : 'asc';
  const fpPaged = campaign
    ? serverPaged(({ page, pageSize }) => fpListCommitments({ campaignId: campaign.id, status, search, page, pageSize, sort, direction }),
      parsePaging(req.query, { defaultSize: 50 }))
    : { result: { rows: [], total: 0, page: 1, pages: 1 }, paging: paginateList([], parsePaging(req.query, { defaultSize: 50 })) };

  res.render('ecaq/faith-promise-admin', {
    title: 'Faith Promise administration',
    campaigns,
    campaign,
    // The four figures at the top describe the WHOLE campaign, straight from the payment ledger - never just the rows on this page.
    ledger: campaign ? campaignLedger(campaign).headline : null,
    canManageFinance: req.user.can('giving.manage_finance'),
    paging: fpPaged.paging,
    pagerParams: { campaign: campaign ? campaign.id : null, status, q: search, sort, direction, page_size: pageSizeParam(fpPaged.paging, 50) },
    result: fpPaged.result,
    amendedIds: campaign ? amendedCommitmentIds(campaign.id) : new Set(),
    filters: { status, search, sort, direction },
    statuses: FP_COMMITMENT_STATUSES,
    statusLabels: FP_STATUS_LABELS,
    frequencyLabels: FREQUENCY_LABELS,
    formatMoney
  });
});

router.get('/admin/ecaq/faith-promise/commitments/:id(\\d+)', requireAuth, requirePermission('giving.manage'), (req, res, next) => {
  const commitment = fpGetCommitment(Number(req.params.id));
  if (!commitment) return next();
  res.render('ecaq/faith-promise-commitment', {
    title: 'Faith Promise commitment',
    commitment,
    payments: fpListPayments(commitment.id),
    history: commitmentHistory(commitment),
    frequencies: GIVING_FREQUENCIES,
    frequencyLabels: FREQUENCY_LABELS,
    statusLabels: FP_STATUS_LABELS,
    methodLabels: METHOD_LABELS,
    paymentMethods: FP_PAYMENT_METHODS,
    receivers: knownReceivers(),
    canManageFinance: req.user.can('giving.manage_finance'),
    formatMoney
  });
});

// An administrator's amendment of an existing commitment: a reason is required, and the audit row keeps who, when, why and the commitment before and after. The
// payments are not touched; Received stays the sum of them and Outstanding follows from the new commitment.
router.post('/admin/ecaq/faith-promise/commitments/:id(\\d+)/amend',
  requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
    const commitment = fpGetCommitment(Number(req.params.id));
    if (!commitment) return next();
    const back = `/admin/ecaq/faith-promise/commitments/${commitment.id}#amend`;

    const v = new Validator(req.body);
    const reason = v.text('reason', { required: true, max: 300, label: 'Reason for the change' });
    v.oneOf('frequency', GIVING_FREQUENCIES, { required: true, label: 'How they will give' });
    const amountRaw = String(req.body.amount ?? '').trim();
    if (!MONEY_PATTERN.test(amountRaw) || Number(amountRaw) <= 0) v.fail('amount', 'Enter an amount using digits only (at most 999,999,999.99).');
    if (!v.valid) { req.flash('error', Object.values(v.errors)[0]); return res.redirect(back); }

    const result = amendCommitment(commitment.id, { amount: Number(amountRaw), frequency: v.values.frequency, reason }, { userId: req.user.id });
    if (!result.ok) {
      req.flash('error', result.reason === 'no_change' ? 'Nothing was changed: the amount and how they give are the same as now.' : 'That change could not be saved.');
      return res.redirect(back);
    }
    recordAudit({
      req, action: 'ecaq.faith_promise_amended', entityType: 'faith_promise_commitment', entityId: commitment.id,
      detail: { reason, before: result.before, after: result.after, received: result.received, status: result.totals.status, member_id: commitment.member_id || null }
    });
    req.flash('success', `Commitment amended: ${formatMoney(result.before.expected_total, commitment.currency || 'QAR')} for the year (${result.before.frequency.replace('_', ' ')}) is now ${formatMoney(result.after.expected_total, commitment.currency || 'QAR')} (${result.after.frequency.replace('_', ' ')}). Payments are unchanged.`);
    return res.redirect(back);
  });

router.post('/admin/ecaq/faith-promise/commitments/:id(\\d+)/payments',
  requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
    const commitment = fpGetCommitment(Number(req.params.id));
    if (!commitment) return next();

    const v = new Validator(req.body);
    v.date('paid_on', { required: true, label: 'Payment date', notFuture: true });
    const receivedBy = v.text('received_by', { required: true, max: 120, label: 'Received by' });
    const amountRaw = String(req.body.amount ?? '').trim();
    const validAmount = MONEY_PATTERN.test(amountRaw) && Number(amountRaw) > 0;
    if (!validAmount) v.fail('amount', 'Enter an amount using digits only (at most 999,999,999.99).');
    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/faith-promise/commitments/${commitment.id}`);
    }
    const amount = Number(amountRaw);

    const result = fpAddPayment(commitment.id, {
      amount, paid_on: v.values.paid_on, method: req.body.method, reference: req.body.reference, notes: req.body.notes, received_by: receivedBy
    }, { userId: req.user.id });

    if (!result.ok) {
      req.flash('error', 'That payment could not be recorded.');
      return res.redirect(`/admin/ecaq/faith-promise/commitments/${commitment.id}`);
    }

    recordAudit({
      req, action: 'ecaq.faith_promise_payment_recorded', entityType: 'faith_promise_commitment', entityId: commitment.id,
      detail: { amount, paid_on: v.values.paid_on, method: result.payment.method, reference: result.payment.reference || null, received_by: result.payment.received_by, now_received: result.totals.collected, status: result.totals.status }
    });
    req.flash('success', `Payment of ${formatMoney(amount, commitment.currency || 'QAR')} recorded.`);
    return res.redirect(`/admin/ecaq/faith-promise/commitments/${commitment.id}`);
  });

router.post('/admin/ecaq/faith-promise/payments/:id(\\d+)',
  requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
    const payment = fpGetPayment(Number(req.params.id));
    if (!payment) return next();

    const v = new Validator(req.body);
    v.date('paid_on', { required: true, label: 'Payment date', notFuture: true });
    const reason = v.text('reason', { required: true, max: 300, label: 'Reason for the correction' });
    const reference = v.text('reference', { max: 100, label: 'Reference' });
    const notes = v.text('notes', { max: 500, label: 'Notes' });
    // Received by: required whenever the payment has one (it cannot be erased); a payment from before the field existed may stay blank, never invented.
    // (a request that does not send the field at all leaves it as it is; one that sends it blank is trying to erase it)
    const receivedBy = req.body.received_by === undefined ? undefined : v.text('received_by', { required: Boolean(payment.received_by), max: 120, label: 'Received by' });
    const amountRaw = String(req.body.amount ?? '').trim();
    const validAmount = MONEY_PATTERN.test(amountRaw) && Number(amountRaw) > 0;
    if (!validAmount) v.fail('amount', 'Enter an amount using digits only (at most 999,999,999.99).');
    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/faith-promise/commitments/${payment.commitment_id}`);
    }
    const amount = Number(amountRaw);

    // The audit row keeps the whole payment as it was and as it became, with the reason. The correction and its audit row are one transaction.
    const before = paymentSnapshot(payment);
    const result = fpUpdatePayment(payment.id, {
      amount, paid_on: v.values.paid_on, method: req.body.method, reference, notes, received_by: receivedBy
    }, { userId: req.user.id });
    if (!result.ok) {
      req.flash('error', result.reason === 'received_by_required' ? 'Enter who received the payment.' : 'That payment could not be corrected.');
      return res.redirect(`/admin/ecaq/faith-promise/commitments/${payment.commitment_id}`);
    }

    recordAudit({
      req, action: 'ecaq.faith_promise_payment_corrected', entityType: 'faith_promise_payment', entityId: payment.id,
      detail: { commitment_id: payment.commitment_id, reason, before, after: paymentSnapshot(result.payment), now_received: result.totals.collected }
    });
    req.flash('success', 'Payment updated.');
    return res.redirect(`/admin/ecaq/faith-promise/commitments/${payment.commitment_id}`);
  });

router.post('/admin/ecaq/faith-promise/payments/:id(\\d+)/delete',
  requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
    const payment = fpGetPayment(Number(req.params.id));
    if (!payment) return next();
    const v = new Validator(req.body);
    const reason = v.text('reason', { required: true, max: 300, label: 'Reason for removing the payment' });
    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/faith-promise/commitments/${payment.commitment_id}`);
    }
    const removed = fpDeletePayment(payment.id);
    recordAudit({
      req, action: 'ecaq.faith_promise_payment_deleted', entityType: 'faith_promise_payment', entityId: payment.id,
      detail: { commitment_id: payment.commitment_id, reason, removed: paymentSnapshot(payment), now_received: removed.totals.collected }
    });
    req.flash('success', 'Payment removed.');
    return res.redirect(`/admin/ecaq/faith-promise/commitments/${payment.commitment_id}`);
  });

// --- Campaign ledger report ------------------------------------------------
// One report for a Giving Board or a Faith Promise campaign, built only from the payment ledger (services/campaign-ledger.js). Needs the finance
// permission: it lists what each member paid. The campaign is always named by its own id, so the two campaigns can never be mixed.

const isoDate = (value) => (/^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) && !Number.isNaN(Date.parse(value)) ? String(value) : null);

function ledgerRequest(req) {
  const campaign = getCampaign(Number(req.params.id));
  if (!campaign || !['giving_board', 'faith_promise'].includes(campaign.type)) return null;
  let from = isoDate(req.query.from);
  let to = isoDate(req.query.to);
  let rangeError = null;
  if (from && to && from > to) {
    rangeError = 'The "from" date is after the "to" date, so the period was not applied.';
    from = null;
    to = null;
  }
  const search = String(req.query.q || '').slice(0, 80).trim();
  const memberSort = LEDGER_MEMBER_SORTS.includes(req.query.msort) ? req.query.msort : 'name';
  const memberDirection = req.query.mdir === 'desc' ? 'desc' : 'asc';
  const paymentSort = LEDGER_PAYMENT_SORTS.includes(req.query.psort) ? req.query.psort : 'payment_date';
  const paymentDirection = req.query.pdir === 'asc' ? 'asc' : 'desc';
  const report = campaignLedger(campaign, { from, to, search, memberSort, memberDirection, paymentSort, paymentDirection });
  return { campaign, report, from, to, search, memberSort, memberDirection, paymentSort, paymentDirection, rangeError };
}

router.get('/admin/ecaq/campaigns/:id(\\d+)/ledger', requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
  const ctx = ledgerRequest(req);
  if (!ctx) return next();
  const { campaign, report } = ctx;

  const memberPaging = paginateList(report.members, parsePaging({ page: req.query.mpage, page_size: req.query.msize }));
  const paymentPaging = paginateList(report.payments, parsePaging({ page: req.query.ppage, page_size: req.query.psize }));
  const stamp = new Date();
  const printed = `${stamp.toLocaleDateString('en-GB', { timeZone: 'Asia/Qatar', day: 'numeric', month: 'long', year: 'numeric' })}, ${stamp.toLocaleTimeString('en-GB', { timeZone: 'Asia/Qatar', hour: '2-digit', minute: '2-digit', hour12: false })}`;

  return res.render('ecaq/ledger', {
    title: `${campaign.name} \u00B7 ledger`,
    campaign,
    report,
    filters: { from: ctx.from, to: ctx.to, search: ctx.search, memberSort: ctx.memberSort, memberDirection: ctx.memberDirection, paymentSort: ctx.paymentSort, paymentDirection: ctx.paymentDirection },
    rangeError: ctx.rangeError,
    members: memberPaging.rows,
    memberPaging,
    payments: paymentPaging.rows,
    paymentPaging,
    period: periodText(ctx.from, ctx.to),
    // The campaign's own dates (not just its year), so a campaign that runs across two years or part of one says exactly what it covers.
    campaignPeriod: campaign.start_date && campaign.end_date ? `${formatDate(campaign.start_date, 'medium')} to ${formatDate(campaign.end_date, 'medium')}` : '',
    printedAt: `${printed} (Qatar time)`,
    methodLabels: METHOD_LABELS,
    manageHref: campaign.type === 'faith_promise' ? `/admin/ecaq/faith-promise?campaign=${campaign.id}` : `/admin/ecaq?campaign=${campaign.id}`,
    formatMoney
  });
});

router.get('/admin/ecaq/campaigns/:id(\\d+)/ledger.csv', requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
  const ctx = ledgerRequest(req);
  if (!ctx) return next();
  const view = req.query.view === 'payments' ? 'payments' : 'members';
  const { csv, count } = ledgerCsv(ctx.report, view);
  recordAudit({
    req, action: 'ecaq.ledger_exported', entityType: 'ecaq_campaign', entityId: ctx.campaign.id,
    detail: { view, count, from: ctx.from, to: ctx.to, search: ctx.search || null }
  });
  const slug = ctx.campaign.type === 'faith_promise' ? 'faith-promise' : 'giving-board';
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${slug}-${ctx.campaign.year}-${view}.csv"`);
  return res.send(csv);
});

// --- Administration --------------------------------------------------------

router.get('/admin/ecaq', requireAuth, requirePermission('giving.manage'), (req, res) => {
  // The Giving Board's own administration page — a Faith Promise or custom
  // campaign is managed on its own page, never mixed into this switcher.
  const campaigns = listCampaigns().filter((c) => c.type === 'giving_board');
  const requestedCampaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : null;
  const campaign = requestedCampaign && requestedCampaign.type === 'giving_board'
    ? requestedCampaign
    : currentCampaign();

  // 'outstanding' is the working list "still has a balance to collect" (not paid or part paid, never a waived one); the others are the ledger-derived statuses.
  const paymentStatus = PAYMENT_STATUSES.includes(req.query.payment) || req.query.payment === 'outstanding' ? req.query.payment : null;
  const search = String(req.query.q || '').slice(0, 60);
  const sort = CLAIM_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'date';
  const direction = req.query.direction === 'desc' ? 'desc' : 'asc';
  const claimsPaged = campaign
    ? serverPaged(({ page, pageSize }) => listClaims({ campaignId: campaign.id, search, paymentStatus, page, pageSize, sort, direction }),
      parsePaging(req.query, { defaultSize: 25 }))
    : { result: { rows: [], total: 0, page: 1, pages: 1 }, paging: paginateList([], parsePaging(req.query, { defaultSize: 25 })) };

  res.render('ecaq/admin', {
    title: 'Giving Board administration',
    campaigns,
    campaign,
    progress: campaign ? campaignProgress(campaign) : null,
    paging: claimsPaged.paging,
    pagerParams: { campaign: campaign ? campaign.id : null, q: search, payment: paymentStatus, sort, direction, page_size: pageSizeParam(claimsPaged.paging, 25) },
    result: claimsPaged.result,
    filters: { search, paymentStatus, sort, direction },
    paymentStatuses: PAYMENT_STATUSES,
    paymentLabels: PAYMENT_LABELS,
    privacyLabels: PRIVACY_LABELS,
    canManageFinance: req.user.can('giving.manage_finance'),
    formatMoney
  });
});

/**
 * A single, campaign-agnostic entry point for ECAQ administration — every
 * campaign, whatever its type, with a link to the page that actually manages
 * it. This page holds no claim/commitment/payment logic of its own; it only
 * lists what listCampaigns() already returns and routes to the existing
 * type-specific administration screen, so a future campaign (any year, either
 * existing type) appears here automatically with no change to this route.
 */
router.get('/admin/ecaq/campaigns', requireAuth, requirePermission('giving.manage'), (req, res) => {
  res.render('ecaq/campaigns', {
    title: 'ECAQ Projects Administration',
    campaigns: listCampaigns(),
    canManageFinance: req.user.can('giving.manage_finance'),
    campaignTypeLabels: CAMPAIGN_TYPE_LABELS
  });
});

function collectCampaignInput(body) {
  const v = new Validator(body);
  v.text('name', { required: true, max: 120, label: 'Campaign name' });
  v.integer('year', { required: true, min: 1970, max: 2200, label: 'Year' });
  v.oneOf('type', CAMPAIGN_TYPES, { label: 'Campaign type', fallback: 'giving_board' });
  v.text('description', { max: 2000, label: 'Description' });
  v.text('currency', { max: 8, label: 'Currency' });
  v.oneOf('privacy_mode', PRIVACY_MODES, { label: 'Privacy', fallback: 'first_name' });
  v.oneOf('status', CAMPAIGN_STATUSES, { label: 'Status', fallback: 'draft' });
  v.date('start_date', { label: 'Start date' });
  v.date('end_date', { label: 'End date' });

  for (const field of ['target_amount', 'amount_per_date']) {
    const raw = String(body[field] ?? '').trim();
    if (raw === '') {
      // A Giving Board date is a fixed QAR 300 commitment: left blank, it is that.
      v.values[field] = field === 'amount_per_date' && body.type === 'giving_board' ? GIVING_BOARD_SLOT_AMOUNT : null;
    } else if (!MONEY_PATTERN.test(raw)) {
      v.fail(field, 'Enter an amount using digits only (at most 999,999,999.99), for example 500 or 500.50.');
    } else {
      v.values[field] = Number(raw);
    }
  }
  return v;
}

router.get('/admin/ecaq/campaigns/new', requireAuth, requirePermission('giving.manage'), (req, res) => {
  const year = Number(today().slice(0, 4));
  res.render('ecaq/campaign-form', {
    title: 'New campaign',
    mode: 'create',
    campaign: {
      year,
      type: 'giving_board',
      currency: 'QAR',
      amount_per_date: GIVING_BOARD_SLOT_AMOUNT,
      privacy_mode: 'first_name',
      status: 'draft',
      background_image: null,
      start_date: `${year}-01-01`,
      end_date: `${year}-12-31`
    },
    values: {},
    errors: {},
    privacyModes: PRIVACY_MODES,
    privacyLabels: PRIVACY_LABELS,
    statuses: CAMPAIGN_STATUSES,
    campaignTypes: CAMPAIGN_TYPES,
    campaignTypeLabels: CAMPAIGN_TYPE_LABELS,
    daysInYear
  });
});

router.post('/admin/ecaq/campaigns', requireAuth, requirePermission('giving.manage'), (req, res) => {
  const v = collectCampaignInput(req.body);
  if (!v.valid) {
    return res.status(400).render('ecaq/campaign-form', {
      title: 'New campaign',
      mode: 'create',
      campaign: req.body,
      values: req.body,
      errors: v.errors,
      privacyModes: PRIVACY_MODES,
      privacyLabels: PRIVACY_LABELS,
      statuses: CAMPAIGN_STATUSES,
      campaignTypes: CAMPAIGN_TYPES,
      campaignTypeLabels: CAMPAIGN_TYPE_LABELS,
      daysInYear
    });
  }

  try {
    const campaign = createCampaign(v.values);
    recordAudit({
      req, action: 'giving.campaign_created', entityType: 'ecaq_campaign', entityId: campaign.id,
      detail: { year: campaign.year, status: campaign.status, type: campaign.type }
    });
    req.flash('success', campaign.type === 'giving_board'
      ? `${campaign.name} created with ${campaignDayCount(campaign)} dates.`
      : `${campaign.name} created.`);
    return res.redirect(
      campaign.type === 'faith_promise' ? `/admin/ecaq/faith-promise?campaign=${campaign.id}`
        : campaign.type === 'giving_board' ? `/admin/ecaq?campaign=${campaign.id}`
        : `/admin/ecaq/campaigns/${campaign.id}/edit`
    );
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(400).render('ecaq/campaign-form', {
        title: 'New campaign',
        mode: 'create',
        campaign: req.body,
        values: req.body,
        errors: { year: 'A campaign with that name already exists for that year.' },
        privacyModes: PRIVACY_MODES,
        privacyLabels: PRIVACY_LABELS,
        statuses: CAMPAIGN_STATUSES,
        campaignTypes: CAMPAIGN_TYPES,
        campaignTypeLabels: CAMPAIGN_TYPE_LABELS,
        daysInYear
      });
    }
    throw err;
  }
});

router.get('/admin/ecaq/campaigns/:id(\\d+)/edit', requireAuth, requirePermission('giving.manage'),
  (req, res, next) => {
    const campaign = getCampaign(Number(req.params.id));
    if (!campaign) return next();
    return res.render('ecaq/campaign-form', {
      title: `Edit ${campaign.name}`,
      mode: 'edit',
      campaign,
      values: campaign,
      errors: {},
      privacyModes: PRIVACY_MODES,
      privacyLabels: PRIVACY_LABELS,
      statuses: CAMPAIGN_STATUSES,
      campaignTypes: CAMPAIGN_TYPES,
      campaignTypeLabels: CAMPAIGN_TYPE_LABELS,
      daysInYear
    });
  });

router.post('/admin/ecaq/campaigns/:id(\\d+)', requireAuth, requirePermission('giving.manage'), (req, res, next) => {
  const campaign = getCampaign(Number(req.params.id));
  if (!campaign) return next();

  const v = collectCampaignInput(req.body);
  if (!v.valid) {
    return res.status(400).render('ecaq/campaign-form', {
      title: `Edit ${campaign.name}`,
      mode: 'edit',
      campaign: { ...campaign, ...req.body },
      values: req.body,
      errors: v.errors,
      privacyModes: PRIVACY_MODES,
      privacyLabels: PRIVACY_LABELS,
      statuses: CAMPAIGN_STATUSES,
      campaignTypes: CAMPAIGN_TYPES,
      campaignTypeLabels: CAMPAIGN_TYPE_LABELS,
      daysInYear
    });
  }

  // The picture is uploaded separately, so editing the other fields must never touch it.
  updateCampaign(campaign.id, { ...v.values, background_image: campaign.background_image });
  recordAudit({
    req, action: 'giving.campaign_updated', entityType: 'ecaq_campaign', entityId: campaign.id,
    detail: { privacy_mode: v.values.privacy_mode, status: v.values.status }
  });
  req.flash('success', 'Campaign updated.');
  return res.redirect('/admin/ecaq?campaign=' + campaign.id);
});

/**
 * The picture behind a board year. Uploaded on its own, the same way a cell
 * group or ministry photo is, rather than being typed as a raw file path —
 * nobody running a church should need to know where the file lives on disk.
 */
router.post('/admin/ecaq/campaigns/:id(\\d+)/background', requireAuth, requirePermission('giving.manage'),
  (req, res, next) => {
    const campaign = getCampaign(Number(req.params.id));
    if (!campaign) return next();

    return memberPhotoUpload(req, res, (uploadErr) => {
      if (uploadErr) {
        req.flash('error', uploadErrorMessage(uploadErr));
        return res.redirect(`/admin/ecaq/campaigns/${campaign.id}/edit`);
      }
      if (!verifyCsrf(req)) {
        const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
        err.status = 403;
        return next(err);
      }
      if (!req.file) {
        req.flash('error', 'Choose an image to upload.');
        return res.redirect(`/admin/ecaq/campaigns/${campaign.id}/edit`);
      }

      try {
        const { storedPath } = saveCampaignBackground(campaign.id, req.file);
        try {
          transaction(() => {
            setCampaignBackground(campaign.id, `/media/ecaq/${campaign.id}/background`);
            recordAudit({
              req, action: 'giving.campaign_background_updated', entityType: 'ecaq_campaign', entityId: campaign.id
            });
          })();
        } catch (dbErr) {
          discardStoredFile(storedPath); // the board keeps its previous picture
          throw dbErr;
        }
        pruneSiblings(storedPath);
        req.flash('success', 'Board picture updated.');
      } catch (err) {
        if (!err.status) return next(err);
        req.flash('error', err.message);
      }
      return res.redirect(`/admin/ecaq/campaigns/${campaign.id}/edit`);
    });
  });

router.post('/admin/ecaq/campaigns/:id(\\d+)/background/reset', requireAuth, requirePermission('giving.manage'),
  (req, res, next) => {
    const campaign = getCampaign(Number(req.params.id));
    if (!campaign) return next();

    setCampaignBackground(campaign.id, DEFAULT_BOARD_BACKGROUND);
    recordAudit({
      req, action: 'giving.campaign_background_reset', entityType: 'ecaq_campaign', entityId: campaign.id
    });
    req.flash('success', 'Board picture reset to the default.');
    return res.redirect(`/admin/ecaq/campaigns/${campaign.id}/edit`);
  });

/**
 * The uploaded file itself. Anyone who can see the board is entitled to see
 * the picture on it, so this checks the same permission the board page does,
 * not the stricter one needed to change it.
 *
 * Exactly one file is ever kept per campaign — saveCampaignBackground removes
 * the previous one on every upload — so the directory is read rather than a
 * filename being stored anywhere. The stored background_image value is only
 * ever set to this route's own URL after a real upload, so a mismatch here
 * means the file was removed by hand rather than through the portal.
 */
router.get('/media/ecaq/:id(\\d+)/background', requireAuth, requirePermission('giving.view_board'),
  (req, res, next) => {
    const campaign = getCampaign(Number(req.params.id));
    if (!campaign) return next();

    const expected = `/media/ecaq/${campaign.id}/background`;
    if (campaign.background_image !== expected) return next();

    const dir = path.join(config.storageDir, 'ecaq-boards', String(campaign.id));
    if (!fs.existsSync(dir)) return next();
    const files = fs.readdirSync(dir);
    if (files.length === 0) return next();

    const file = resolveStoredFile(path.posix.join('ecaq-boards', String(campaign.id), files[0]));
    if (!file) return next();

    res.setHeader('Content-Type', contentTypeFor(file));
    res.setHeader('Cache-Control', 'private, max-age=600');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    return streamFile(res, file, next);
  });

/** Financial fields are separate from the claim and need their own permission. */
router.post('/admin/ecaq/claims/:id(\\d+)', requireAuth, requirePermission('giving.manage_finance'),
  (req, res, next) => {
    const claim = getClaim(Number(req.params.id));
    if (!claim) return next();

    const v = new Validator(req.body);
    // The payment status is derived from the payment ledger and is not typed: a posted payment_status is ignored (the claim keeps the status its payments give it).
    const paymentStatus = undefined;
    const notes = v.text('notes', { max: 500, label: 'Notes' });

    // Received money comes only from the payment ledger: an amount_collected field in the request is ignored, never stored.
    const amounts = {};
    {
      const raw = String(req.body.commitment_amount ?? '').trim();
      if (raw === '') amounts.commitment_amount = null;
      else if (!MONEY_PATTERN.test(raw)) v.fail('commitment_amount', 'Enter an amount using digits only (at most 999,999,999.99).');
      else amounts.commitment_amount = Number(raw);
    }

    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect('/admin/ecaq?campaign=' + claim.campaign_id);
    }

    updateClaimFinance(claim.id, {
      commitmentAmount: amounts.commitment_amount,
      paymentStatus,
      notes,
      userId: req.user.id
    });

    recordAudit({
      req, action: 'giving.claim_updated', entityType: 'ecaq_claim', entityId: claim.id,
      detail: {
        date: claim.claim_date,
        payment_status: paymentStatus,
        commitment: amounts.commitment_amount
      }
    });

    req.flash('success', `Commitment for ${formatDate(claim.claim_date, 'long')} updated.`);
    return res.redirect('/admin/ecaq?campaign=' + claim.campaign_id);
  });

/** Correcting an administrative error frees the date for someone else. */
router.post('/admin/ecaq/claims/:id(\\d+)/release', requireAuth, requirePermission('giving.manage'),
  (req, res, next) => {
    const claim = getClaim(Number(req.params.id));
    if (!claim) return next();

    const reason = String(req.body.reason || '').slice(0, 300) || null;
    const outcome = releaseClaim(claim.id, { userId: req.user.id, reason });
    if (outcome.refused) {
      req.flash('error', `${formatDate(claim.claim_date, 'long')} has ${outcome.payments} recorded payment${outcome.payments === 1 ? '' : 's'}, so it cannot be released. Remove the payment${outcome.payments === 1 ? '' : 's'} from the claim's payments page first.`);
      return res.redirect('/admin/ecaq?campaign=' + claim.campaign_id);
    }

    recordAudit({
      req, action: 'giving.claim_released', entityType: 'ecaq_claim', entityId: claim.id,
      detail: { date: claim.claim_date, member_id: claim.member_id, reason }
    });

    req.flash('success', `${formatDate(claim.claim_date, 'long')} is available again.`);
    return res.redirect('/admin/ecaq?campaign=' + claim.campaign_id);
  });

/**
 * Recording a date for a member who is not doing it themselves — a phone call
 * to the church office, or someone without portal access. This is a board
 * action, not a money one, so it sits behind `giving.manage` rather than the
 * finance permission: the amount defaults to the campaign's daily rate and can
 * be corrected afterwards from the claim's own page.
 */
router.get('/admin/ecaq/claims/new', requireAuth, requirePermission('giving.manage'), (req, res, next) => {
  const date = String(req.query.date || '');
  const campaign = campaignForDate(date);
  if (!campaign) {
    req.flash('error', 'Choose a date from one of the open boards.');
    return res.redirect('/projects/ecaq/board');
  }

  const existing = claimForDate(campaign.id, date);
  if (existing) {
    req.flash('info', 'That date is already taken.');
    return res.redirect(req.user.can('giving.manage_finance')
      ? `/admin/ecaq/claims/${existing.id}`
      : `/projects/ecaq/board?year=${campaign.year}`);
  }

  return res.render('ecaq/claim-for-member', {
    title: `Claim ${formatDate(date, 'long')} for a member`,
    campaign,
    date,
    // Coming back from the review step keeps who was chosen and the notes.
    memberSelected: pickerCardFor(req.query.member_id),
    errors: {},
    values: { notes: String(req.query.notes || '').slice(0, 300) },
    formatMoney
  });
});

router.post('/admin/ecaq/claims', requireAuth, requirePermission('giving.manage'), (req, res, next) => {
  const date = String(req.body.date || '');
  const campaign = campaignForDate(date);
  if (!campaign) {
    req.flash('error', 'Choose a date from one of the open boards.');
    return res.redirect('/projects/ecaq/board');
  }

  const rerender = (errors) => res.status(400).render('ecaq/claim-for-member', {
    title: `Claim ${formatDate(date, 'long')} for a member`,
    campaign,
    date,
    memberSelected: pickerCardFor(req.body.member_id),
    errors,
    values: req.body,
    formatMoney
  });

  const memberId = Number.parseInt(req.body.member_id, 10);
  if (!memberId) return rerender({ member_id: 'Choose who this date is for.' });
  const member = getMember(memberId);
  if (!member) return rerender({ member_id: 'Choose who this date is for.' });
  if (claimForDate(campaign.id, date)) return rerender({ member_id: 'That date was just taken by someone else. Choose another.' });

  const notes = String(req.body.notes || '').slice(0, 300) || null;
  // A Giving Board date is a fixed commitment (the campaign's amount, QAR 300): it is never typed here, whatever the request says.
  const commitmentAmount = Number(campaign.amount_per_date) || GIVING_BOARD_SLOT_AMOUNT;

  // Step 1 -> review: the full date, who it is for and what they commit to, before anything is written.
  if (req.body.confirm !== '1') {
    return res.render('ecaq/claim-for-member-review', {
      title: `Review ${formatDate(date, 'long')}`,
      campaign,
      date,
      member,
      memberCard: pickerCardFor(member.id),
      commitmentAmount,
      notes,
      formatMoney
    });
  }

  const result = createClaim({
    campaignId: campaign.id,
    date,
    memberId,
    commitmentAmount,
    notes,
    userId: req.user.id
  });

  if (!result.ok) {
    const message = result.reason === 'already_claimed'
      ? 'That date was just taken by someone else. Choose another.'
      : 'That date could not be recorded.';
    return rerender({ member_id: message });
  }

  recordAudit({
    req, action: 'giving.claim_recorded_by_admin', entityType: 'ecaq_claim', entityId: result.claim.id,
    // The claim belongs to the member; the administrator who recorded it is the actor of this audit row and the claim's created_by.
    detail: { date, member_id: memberId, recorded_by: req.user.id, commitment: commitmentAmount, campaign_id: campaign.id }
  });

  req.flash('success', `${formatDate(date, 'long')} recorded for ${[member.preferred_name || member.first_name, member.last_name].filter(Boolean).join(' ')}.`);
  return res.redirect(req.user.can('giving.manage_finance')
    ? `/admin/ecaq/claims/${result.claim.id}`
    : `/projects/ecaq/board?year=${campaign.year}`);
});

router.get('/admin/ecaq/claims.csv', requireAuth, requirePermission('giving.manage'), (req, res, next) => {
  const campaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : currentCampaign();
  if (!campaign) return next();

  const { csv, count } = claimsCsv(campaign);
  recordAudit({
    req, action: 'giving.claims_exported', entityType: 'ecaq_campaign', entityId: campaign.id,
    detail: { count }
  });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="giving-board-${campaign.year}.csv"`);
  return res.send(csv);
});

// --- Payments against a commitment -----------------------------------------

/** The office view: every payment received, and what is still outstanding. */
router.get('/admin/ecaq/payments', requireAuth, requirePermission('giving.manage_finance'), (req, res) => {
  const requestedCampaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : null;
  const campaign = requestedCampaign && requestedCampaign.type === 'giving_board'
    ? requestedCampaign
    : currentCampaign();
  // Before any campaign exists there is nothing to pay towards, which is a
  // normal state rather than a missing page.
  if (!campaign) {
    const years = [...new Set(
      listCampaigns().filter((c) => c.type === 'giving_board').map((c) => c.year)
    )].sort((a, b) => a - b);
    return res.render('ecaq/board-empty', {
      title: 'Giving Board payments',
      motto: MOTTO,
      years,
      requestedYear: null,
      canManage: req.user.can('giving.manage')
    });
  }

  const from = /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : null;
  const to = /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : null;
  const paySort = PAYMENT_SORT_COLUMNS.includes(req.query.paySort) ? req.query.paySort : 'received';
  const payDirection = req.query.payDirection === 'asc' ? 'asc' : 'desc';
  const outSort = OUTSTANDING_SORT_COLUMNS.includes(req.query.outSort) ? req.query.outSort : 'date';
  const outDirection = req.query.outDirection === 'desc' ? 'desc' : 'asc';

  // The totals always describe EVERY payment and commitment; only the rows on screen are paged. (The default cap of
  // campaignPayments() is lifted here, as the CSV does, so a large campaign can never understate a total.)
  const payments = campaignPayments(campaign.id, { from, to, sort: paySort, direction: payDirection, limit: 100000 });
  const outstanding = outstandingClaims(campaign.id, { sort: outSort, direction: outDirection });
  const payPaging = paginateList(payments, parsePaging({ page: req.query.ppage, page_size: req.query.psize }));
  const outPaging = paginateList(outstanding, parsePaging({ page: req.query.opage, page_size: req.query.osize }));

  return res.render('ecaq/payments', {
    title: 'Giving Board payments',
    campaign,
    campaigns: listCampaigns().filter((c) => c.type === 'giving_board'),
    payments: payPaging.rows,
    outstanding: outPaging.rows,
    paymentTotal: payments.length,
    outstandingTotal: outstanding.length,
    payPaging,
    outPaging,
    received: payments.reduce((sum, p) => sum + Number(p.amount), 0),
    owed: outstanding.reduce((sum, c) => sum + c.outstanding, 0),
    filters: { from, to, paySort, payDirection, outSort, outDirection },
    methodLabels: METHOD_LABELS,
    paymentLabels: PAYMENT_LABELS,
    formatMoney
  });
});

router.get('/admin/ecaq/payments.csv', requireAuth, requirePermission('giving.manage_finance'), (req, res, next) => {
  const campaign = req.query.campaign ? getCampaign(Number(req.query.campaign)) : currentCampaign();
  if (!campaign) return next();

  const { csv, count } = paymentsCsv(campaign);
  recordAudit({
    req, action: 'giving.payments_exported', entityType: 'ecaq_campaign', entityId: campaign.id,
    detail: { count }
  });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="giving-board-payments-${campaign.year}.csv"`);
  return res.send(csv);
});

/** One commitment, its payment history, and the form to record another. */
router.get('/admin/ecaq/claims/:id(\\d+)', requireAuth, requirePermission('giving.manage_finance'),
  (req, res, next) => {
    const claim = getClaim(Number(req.params.id));
    if (!claim) return next();

    const payments = listPayments(claim.id);
    const paid = payments.reduce((sum, p) => sum + Number(p.amount), 0);

    return res.render('ecaq/claim', {
      title: `Commitment for ${formatDate(claim.claim_date, 'long')}`,
      claim,
      payments,
      paid,
      outstanding: Math.max((Number(claim.commitment_amount) || 0) - paid, 0),
      methods: PAYMENT_METHODS,
      methodLabels: METHOD_LABELS,
      paymentStatuses: PAYMENT_STATUSES,
      paymentLabels: PAYMENT_LABELS,
      today: today(),
      canCorrect: true, // this page itself needs giving.manage_finance, the permission that corrects payments
      formatMoney
    });
  });

router.post('/admin/ecaq/claims/:id(\\d+)/payments', requireAuth, requirePermission('giving.manage_finance'),
  (req, res, next) => {
    const claim = getClaim(Number(req.params.id));
    if (!claim) return next();

    const v = new Validator(req.body);
    const paidOn = v.date('paid_on', { required: true, label: 'Date received', notFuture: true });
    const method = v.oneOf('method', PAYMENT_METHODS, { label: 'Method', fallback: 'cash' });
    const reference = v.text('reference', { max: 100, label: 'Reference' });
    const receivedByName = v.text('received_by_name', { max: 120, label: 'Received by' });
    const notes = v.text('notes', { max: 500, label: 'Notes' });

    const raw = String(req.body.amount ?? '').trim();
    if (!MONEY_PATTERN.test(raw) || Number(raw) <= 0) {
      v.fail('amount', 'Enter the amount received, using digits only (at most 999,999,999.99).');
    }

    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/claims/${claim.id}`);
    }

    const result = addPayment(claim.id, {
      amount: Number(raw),
      paid_on: paidOn,
      method,
      reference,
      received_by_name: receivedByName,
      notes
    }, { userId: req.user.id });

    if (!result.ok) {
      req.flash('error', 'That payment could not be recorded.');
      return res.redirect(`/admin/ecaq/claims/${claim.id}`);
    }

    recordAudit({
      req, action: 'giving.payment_recorded', entityType: 'ecaq_claim', entityId: claim.id,
      detail: {
        amount: Number(raw), paid_on: paidOn, method,
        received_by: receivedByName || req.user.displayName,
        now_collected: result.totals.collected, status: result.totals.status
      }
    });

    req.flash('success', result.totals.outstanding > 0
      ? `Payment recorded. ${formatMoney(result.totals.outstanding, claim.currency)} still outstanding.`
      : 'Payment recorded. This commitment is fully paid.');
    return res.redirect(`/admin/ecaq/claims/${claim.id}`);
  });

/**
 * Correcting a payment: the date it was received, the amount, the method, the reference. A reason is required and the audit row keeps the payment
 * as it was and as it became. Who recorded it and when it was recorded (created_by / created_at) are never changed by a correction.
 */
router.post('/admin/ecaq/payments/:id(\\d+)', requireAuth, requirePermission('giving.manage_finance'),
  (req, res, next) => {
    const payment = getPayment(Number(req.params.id));
    if (!payment) return next();

    const v = new Validator(req.body);
    const paidOn = v.date('paid_on', { required: true, label: 'Payment date', notFuture: true });
    const method = v.oneOf('method', PAYMENT_METHODS, { label: 'Method', fallback: payment.method });
    const reference = v.text('reference', { max: 100, label: 'Reference' });
    const notes = v.text('notes', { max: 500, label: 'Notes' });
    const reason = v.text('reason', { required: true, max: 300, label: 'Reason for the correction' });
    const raw = String(req.body.amount ?? '').trim();
    if (!MONEY_PATTERN.test(raw) || Number(raw) <= 0) {
      v.fail('amount', 'Enter the amount received, using digits only (at most 999,999,999.99).');
    }
    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/claims/${payment.claim_id}`);
    }

    const result = updatePayment(payment.id, { amount: Number(raw), paid_on: paidOn, method, reference, notes }, { userId: req.user.id });
    if (!result.ok) {
      req.flash('error', 'That payment could not be corrected.');
      return res.redirect(`/admin/ecaq/claims/${payment.claim_id}`);
    }

    recordAudit({
      req, action: 'giving.payment_corrected', entityType: 'ecaq_claim', entityId: payment.claim_id,
      detail: { payment_id: payment.id, reason, before: paymentSnapshot(payment), after: paymentSnapshot(result.payment), now_collected: result.totals.collected, status: result.totals.status }
    });
    req.flash('success', 'Payment corrected and the commitment recalculated.');
    return res.redirect(`/admin/ecaq/claims/${payment.claim_id}`);
  });

router.post('/admin/ecaq/payments/:id(\\d+)/delete', requireAuth, requirePermission('giving.manage_finance'),
  (req, res, next) => {
    const existing = getPayment(Number(req.params.id));
    if (!existing) return next();
    const v = new Validator(req.body);
    const reason = v.text('reason', { required: true, max: 300, label: 'Reason for removing the payment' });
    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect(`/admin/ecaq/claims/${existing.claim_id}`);
    }
    const result = deletePayment(existing.id);
    if (!result) return next();

    recordAudit({
      req, action: 'giving.payment_removed', entityType: 'ecaq_claim', entityId: result.payment.claim_id,
      detail: { amount: result.payment.amount, paid_on: result.payment.paid_on, payment_id: existing.id, reason, removed: paymentSnapshot(result.payment), now_collected: result.totals.collected }
    });
    req.flash('success', 'Payment removed and the commitment recalculated.');
    return res.redirect(`/admin/ecaq/claims/${result.payment.claim_id}`);
  });

// --- Project updates -------------------------------------------------------

router.get('/admin/ecaq/updates', requireAuth, requirePermission('ecaq.manage'), (req, res) => {
  res.render('ecaq/updates', {
    title: 'Project updates',
    updates: listProjectUpdates({ includeUnpublished: true })
  });
});

router.post('/admin/ecaq/updates', requireAuth, requirePermission('ecaq.manage'), (req, res) => {
  const v = new Validator(req.body);
  v.text('title', { required: true, max: 140, label: 'Title' });
  v.text('body', { required: true, max: 4000, label: 'Update' });
  v.text('source', { max: 200, label: 'Source' });
  v.date('update_date', { label: 'Date' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect('/admin/ecaq/updates');
  }

  const status = req.body.publish === 'yes' ? 'published' : 'draft';
  const update = createProjectUpdate({ ...v.values, status }, { userId: req.user.id });
  recordAudit({
    req, action: 'ecaq.update_created', entityType: 'ecaq_update', entityId: update.id,
    detail: { title: update.title, status }
  });
  req.flash('success', status === 'published' ? 'Update published.' : 'Update saved as a draft.');
  return res.redirect('/admin/ecaq/updates');
});

router.post('/admin/ecaq/updates/:id(\\d+)/status', requireAuth, requirePermission('ecaq.manage'),
  (req, res, next) => {
    const update = getProjectUpdate(Number(req.params.id));
    if (!update) return next();

    const v = new Validator(req.body);
    const status = v.oneOf('status', ['draft', 'published', 'archived'], { required: true, label: 'Status' });
    if (!v.valid) {
      req.flash('error', 'Choose a valid status.');
      return res.redirect('/admin/ecaq/updates');
    }

    setProjectUpdateStatus(update.id, status);
    recordAudit({
      req, action: 'ecaq.update_status_changed', entityType: 'ecaq_update', entityId: update.id,
      detail: { from: update.status, to: status }
    });
    req.flash('success', 'Update changed.');
    return res.redirect('/admin/ecaq/updates');
  });

router.post('/admin/ecaq/updates/:id(\\d+)/delete', requireAuth, requirePermission('ecaq.manage'),
  (req, res, next) => {
    const update = getProjectUpdate(Number(req.params.id));
    if (!update) return next();
    deleteProjectUpdate(update.id);
    recordAudit({
      req, action: 'ecaq.update_deleted', entityType: 'ecaq_update', entityId: update.id,
      detail: { title: update.title }
    });
    req.flash('success', 'Update removed.');
    return res.redirect('/admin/ecaq/updates');
  });

export default router;
