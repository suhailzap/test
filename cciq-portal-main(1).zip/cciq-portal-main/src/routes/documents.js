import fs from 'node:fs';
import { streamFile } from '../lib/stream-file.js';
import { atomicRouter } from '../lib/atomic-router.js';
import { runAtomically } from '../lib/atomic.js';
import { parsePaging, serverPaged, pageSizeParam, GALLERY_PAGE_SIZES } from '../lib/paging.js';
import multer from 'multer';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator, MONEY_PATTERN } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { resolveStoredFile, uploadErrorMessage, UPLOAD_NAME_CHARSET } from '../lib/uploads.js';
import { verifyCsrf } from '../lib/csrf.js';
import { today } from '../lib/dates.js';
import {
  ensureCategories, listCategories, getCategory, createCategory, updateCategory, deleteCategory,
  scopeFor, canSee, getDocument, createDocument, updateDocument, replaceFile, versionsFor,
  setStatus, destroyDocument, listDocuments, libraryStats, expiringDocuments,
  popularTags, parseTags, suggestFromFilename, formatSize,
  parseAudienceInput, audienceSummary, rolesAllowedByCategory, AUDIENCE_ROLES, AUDIENCE_ROLE_LABELS,
  MAX_DOCUMENT_BYTES, RELATION_TYPES, RELATION_LABELS, AUDIENCES, AUDIENCE_LABELS
} from '../services/documents.js';
import { pickerCardFor } from '../services/members.js';
import { listGroups } from '../services/cell-groups.js';
import { listActivities } from '../services/activities.js';
import { listMinistries } from '../services/ministries.js';
import { listCampaigns } from '../services/ecaq.js';
import { listUsersDetailed } from '../services/users.js';

const router = atomicRouter();

// Held in memory, checked by its leading bytes, then written under storage.
const documentUpload = multer({
  defParamCharset: UPLOAD_NAME_CHARSET,
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_DOCUMENT_BYTES, files: 1 }
}).single('file');

function relationOptions(user) {
  return {
    groups: listGroups({ includeInactive: false }),
    activities: listActivities(user, { status: 'published', page: 1, pageSize: 200 }).rows || [],
    ministries: listMinistries(),
    campaigns: listCampaigns()
  };
}

// The "related member" field only ever links one member, even though the
// underlying relationships table could hold several — matching the single
// native <select> this replaced. Resolves whichever of the create-mode
// prefill or edit-mode selected-ids the caller has for 'member' into the
// one card the picker partial needs to show as selected.
function memberRelationSelected(selected, prefill) {
  const fromSelected = selected && Array.isArray(selected.member) ? selected.member[0] : selected && selected.member;
  const id = fromSelected || (prefill && prefill.member) || null;
  return pickerCardFor(id);
}

function readRelations(body) {
  const relations = [];
  for (const type of RELATION_TYPES) {
    const raw = body[`related_${type}`];
    const values = Array.isArray(raw) ? raw : (raw ? [raw] : []);
    for (const value of values) {
      const id = Number.parseInt(value, 10);
      if (Number.isInteger(id) && id > 0) relations.push({ type, id });
    }
  }
  return relations;
}

function filtersFrom(query) {
  const isDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v || '');
  return {
    search: String(query.q || '').slice(0, 80),
    categoryId: Number.parseInt(query.category, 10) || null,
    kind: ['pdf', 'image'].includes(query.kind) ? query.kind : null,
    tag: query.tag ? String(query.tag).slice(0, 60) : null,
    from: isDate(query.from) ? query.from : null,
    to: isDate(query.to) ? query.to : null,
    uploadedBy: Number.parseInt(query.uploader, 10) || null,
    sort: ['newest', 'oldest', 'updated', 'name_az', 'name_za'].includes(query.sort) ? query.sort : 'newest',
    view: query.view === 'list' ? 'list' : 'grid',
    expiringWithin: query.expiring === 'yes' ? 30 : null
  };
}

// --- The library -----------------------------------------------------------

function renderLibrary(req, res, { status, title, heading, uploadedBy = null }) {
  ensureCategories();
  const scope = scopeFor(req.user);
  const filters = filtersFrom(req.query);
  // The list view is a plain table (25 / 50 / 100); the grid is a gallery of cards (12 / 24 / 48, 24 by default).
  const listView = filters.view === 'list';
  const requested = listView ? parsePaging(req.query) : parsePaging(req.query, { defaultSize: 24, sizes: GALLERY_PAGE_SIZES });
  const defaultSize = listView ? 25 : 24;
  const { result, paging } = serverPaged(({ page, pageSize }) => listDocuments({
    ...filters,
    scope,
    status,
    uploadedBy: uploadedBy ?? filters.uploadedBy,
    page,
    pageSize
  }), requested);

  res.render('documents/index', {
    title,
    heading,
    status,
    result,
    paging,
    pageSizeQuery: pageSizeParam(paging, defaultSize),
    pagerSizes: listView ? [25, 50, 100] : GALLERY_PAGE_SIZES,
    filters: { ...filters, uploadedBy: uploadedBy ?? filters.uploadedBy },
    fixedUploader: uploadedBy !== null,
    categories: listCategories({ scope }),
    tags: popularTags({ limit: 20, scope }),
    uploaders: req.user.can('documents.manage') ? listUsersDetailed() : [],
    stats: libraryStats({ scope }),
    canUpload: req.user.can('documents.upload'),
    canManage: req.user.can('documents.manage'),
    formatSize
  });
}

router.get('/documents', requireAuth, requirePermission('documents.view'), (req, res) => {
  renderLibrary(req, res, {
    status: 'active',
    title: 'Documents and records',
    heading: 'Documents and records'
  });
});

router.get('/documents/recent', requireAuth, requirePermission('documents.view'), (req, res) => {
  req.query.sort = 'updated';
  renderLibrary(req, res, {
    status: 'active',
    title: 'Recent documents',
    heading: 'Recent documents'
  });
});

router.get('/documents/mine', requireAuth, requirePermission('documents.view'), (req, res) => {
  renderLibrary(req, res, {
    status: 'active',
    title: 'My uploads',
    heading: 'My uploads',
    uploadedBy: req.user.id
  });
});

router.get('/documents/archived', requireAuth, requirePermission('documents.manage'), (req, res) => {
  renderLibrary(req, res, {
    status: 'archived',
    title: 'Archived documents',
    heading: 'Archived documents'
  });
});

router.get('/documents/expiring', requireAuth, requirePermission('documents.view'), (req, res) => {
  const scope = scopeFor(req.user);
  res.render('documents/expiring', {
    title: 'Expiring documents',
    documents: expiringDocuments({ scope, withinDays: 90 }),
    today: today(),
    stats: libraryStats({ scope })
  });
});

// --- Categories ------------------------------------------------------------

router.get('/documents/categories', requireAuth, requirePermission('documents.view'), (req, res) => {
  ensureCategories();
  const scope = scopeFor(req.user);
  res.render('documents/categories', {
    title: 'Document categories',
    categories: listCategories({ includeArchived: req.user.can('documents.categories'), scope }),
    audiences: AUDIENCES,
    audienceLabels: AUDIENCE_LABELS,
    canManage: req.user.can('documents.categories'),
    stats: libraryStats({ scope })
  });
});

router.post('/documents/categories', requireAuth, requirePermission('documents.categories'), (req, res) => {
  const v = new Validator(req.body);
  v.text('name', { required: true, max: 60, label: 'Category name' });
  v.text('description', { max: 300, label: 'Description' });
  v.oneOf('audience', AUDIENCES, { label: 'Who can see it', fallback: 'staff' });
  v.integer('sort_order', { label: 'Order' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect('/documents/categories');
  }

  try {
    const category = createCategory({ ...v.values, is_financial: Boolean(req.body.is_financial) });
    recordAudit({
      req, action: 'document.category_created', entityType: 'document_category',
      entityId: category.id, detail: { name: category.name, is_financial: Boolean(req.body.is_financial) }
    });
    req.flash('success', `${category.name} added.`);
  } catch (err) {
    if (!String(err.message).includes('UNIQUE')) throw err;
    req.flash('error', 'A category with that name already exists.');
  }
  return res.redirect('/documents/categories');
});

router.post('/documents/categories/:id(\\d+)', requireAuth, requirePermission('documents.categories'),
  (req, res, next) => {
    const category = getCategory(Number(req.params.id));
    if (!category) return next();

    const v = new Validator(req.body);
    v.text('name', { required: true, max: 60, label: 'Category name' });
    v.text('description', { max: 300, label: 'Description' });
    v.oneOf('audience', AUDIENCES, { label: 'Who can see it', fallback: 'staff' });
    v.integer('sort_order', { label: 'Order' });

    if (!v.valid) {
      req.flash('error', Object.values(v.errors)[0]);
      return res.redirect('/documents/categories');
    }

    updateCategory(category.id, {
      ...v.values,
      status: req.body.status === 'archived' ? 'archived' : 'active',
      is_financial: Boolean(req.body.is_financial)
    });
    recordAudit({
      req, action: 'document.category_updated', entityType: 'document_category', entityId: category.id
    });
    req.flash('success', 'Category updated.');
    return res.redirect('/documents/categories');
  });

router.post('/documents/categories/:id(\\d+)/delete', requireAuth, requirePermission('documents.categories'),
  (req, res, next) => {
    const category = getCategory(Number(req.params.id));
    if (!category) return next();

    const result = deleteCategory(category.id);
    if (!result.ok) {
      req.flash('error', `${category.name} still holds ${result.count} document(s). `
        + 'Move them to another category first.');
      return res.redirect('/documents/categories');
    }

    recordAudit({
      req, action: 'document.category_deleted', entityType: 'document_category',
      entityId: category.id, detail: { name: category.name }
    });
    req.flash('success', `${category.name} removed.`);
    return res.redirect('/documents/categories');
  });

// --- Uploading -------------------------------------------------------------

/** What the "Who can view this?" control needs: the roles on offer (never the Kiosk), and which roles each category can reach. */
function audienceLocals(categories) {
  return {
    audienceRoles: AUDIENCE_ROLES,
    audienceLabels: AUDIENCE_ROLE_LABELS,
    categoryRoles: Object.fromEntries(categories.map((c) => [c.id, rolesAllowedByCategory(c.audience)]))
  };
}

router.get('/documents/new', requireAuth, requirePermission('documents.upload'), (req, res) => {
  ensureCategories();
  res.render('documents/form', {
    ...audienceLocals(listCategories()),
    title: 'Upload a document',
    mode: 'create',
    document: { document_date: today() },
    values: {},
    errors: {},
    categories: listCategories(),
    options: relationOptions(req.user),
    relationTypes: RELATION_TYPES,
    relationLabels: RELATION_LABELS,
    maxSize: formatSize(MAX_DOCUMENT_BYTES),
    selected: { member: null, cell_group: null, activity: null, ministry: null, project: null },
    prefill: {
      member: Number.parseInt(req.query.member, 10) || null,
      cell_group: Number.parseInt(req.query.cell_group, 10) || null,
      activity: Number.parseInt(req.query.activity, 10) || null,
      project: Number.parseInt(req.query.project, 10) || null
    },
    memberSelected: pickerCardFor(Number.parseInt(req.query.member, 10) || null)
  });
});

function collectInput(body, user) {
  const v = new Validator(body);
  v.text('title', { required: true, max: 160, label: 'Document title' });
  v.text('description', { max: 2000, label: 'Description' });
  v.integer('category_id', { required: true, label: 'Category' });
  v.date('document_date', { label: 'Document date' });
  v.date('expiry_date', { label: 'Expiry date' });
  v.text('notes', { max: 1000, label: 'Notes' });
  v.text('vendor', { max: 120, label: 'Vendor or payee' });
  v.text('currency', { max: 8, label: 'Currency' });

  const amountRaw = String(body.amount ?? '').trim();
  if (amountRaw) {
    if (!MONEY_PATTERN.test(amountRaw)) {
      v.fail('amount', 'Enter the amount using digits only (at most 999,999,999.99), for example 350 or 350.00.');
    } else {
      v.values.amount = Number(amountRaw);
    }
  } else {
    v.values.amount = null;
  }

  v.values.tags = parseTags(body.tags);
  v.values.relations = readRelations(body);

  /*
   * Receipt fields only belong to a financial category. Whatever was typed
   * into them for any other category is dropped here rather than stored —
   * the form hides the section by category, and the server holds the same
   * line so a value can never slip through with JavaScript disabled or the
   * request built by hand.
   */
  const category = v.values.category_id ? getCategory(Number(v.values.category_id)) : null;
  // Who can view this: stricter only. Read against the CHOSEN category's ceiling; a request naming a role the category does not allow is refused, never stored.
  if (category) {
    const audience = parseAudienceInput(body, { category, user });
    if (!audience.ok) v.fail('audience', audience.error); else v.values.audience = audience;
  }
  if (!category || !category.is_financial) {
    v.values.amount = null;
    v.values.currency = null;
    v.values.vendor = null;
    v.values.notes = null;
  }

  return v;
}

/**
 * The upload callbacks run after the route handler has returned, outside Express's own error handling: anything they throw would be an uncaught exception that ends the
 * process. A request built by hand (an odd field shape, say) must end as an ordinary error page, so each callback body runs inside this.
 */
const safely = (next, fn) => { try { return fn(); } catch (err) { return next(err); } };

router.post('/documents', requireAuth, requirePermission('documents.upload'), (req, res, next) => {
  documentUpload(req, res, (uploadErr) => safely(next, () => {
    const rerender = (errors, message = null) => {
      if (message) req.flash('error', message);
      return res.status(400).render('documents/form', {
        ...audienceLocals(listCategories()),
        title: 'Upload a document',
        mode: 'create',
        document: req.body,
        values: req.body,
        errors,
        categories: listCategories(),
        options: relationOptions(req.user),
        relationTypes: RELATION_TYPES,
        relationLabels: RELATION_LABELS,
        maxSize: formatSize(MAX_DOCUMENT_BYTES),
        selected: { member: null, cell_group: null, activity: null, ministry: null, project: null },
        prefill: {},
        memberSelected: null
      });
    };

    if (uploadErr) return rerender({}, uploadErrorMessage(uploadErr, MAX_DOCUMENT_BYTES));
    // Multipart bodies are parsed here, so the CSRF check belongs here too.
    if (!verifyCsrf(req)) {
      const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
      err.status = 403;
      return next(err);
    }
    if (!req.file) return rerender({ file: 'Choose a file to upload.' });

    const v = collectInput(req.body, req.user);
    if (!v.valid) return rerender(v.errors);

    // The upload callback runs after the route handler has returned, so the document, its file and its audit row are made one unit here.
    let document;
    try {
      document = runAtomically(() => {
        const created = createDocument(v.values, { userId: req.user.id, file: req.file });
        recordAudit({
          req, action: 'document.uploaded', entityType: 'document', entityId: created.id,
          detail: {
            title: created.title,
            category: created.category_name,
            size: created.file_size,
            type: created.mime_type,
            audience: { mode: created.audience_mode, roles: created.audience_roles }
          }
        });
        return created;
      });
    } catch (err) {
      if (!err.status) return next(err);
      return rerender({ file: err.message });
    }

    req.flash('success', `${document.title} uploaded.`);
    return res.redirect(`/documents/${document.id}`);
  }));
});

/** Suggestions offered after a file is chosen, for the person to accept or change. */
router.post('/documents/suggest', requireAuth, requirePermission('documents.upload'), (req, res) => {
  const suggestion = suggestFromFilename(String(req.body.filename || ''), listCategories());
  res.json(suggestion);
});

// --- One document ----------------------------------------------------------

router.get('/documents/:id(\\d+)', requireAuth, requirePermission('documents.view'), (req, res, next) => {
  const document = getDocument(Number(req.params.id));
  if (!document || document.status === 'deleted') return next();
  if (!canSee(req.user, document)) return next();

  res.render('documents/show', {
    title: document.title,
    document,
    versions: versionsFor(document.id),
    audienceText: audienceSummary(document),
    canEdit: req.user.can('documents.upload')
      && (req.user.can('documents.manage') || document.uploaded_by === req.user.id),
    canManage: req.user.can('documents.manage'),
    canDelete: req.user.can('documents.delete'),
    today: today()
  });
});

/**
 * The file itself. Permission is checked before a single byte is sent, and the
 * type is fixed from what was detected at upload rather than the file name.
 */
router.get('/documents/:id(\\d+)/file', requireAuth, requirePermission('documents.view'), (req, res, next) => {
  const document = getDocument(Number(req.params.id));
  if (!document || document.status === 'deleted') return next();
  if (!canSee(req.user, document)) return next();

  const wanted = Number.parseInt(req.query.version, 10);
  let storedPath = document.stored_path;
  let filename = document.original_filename;
  let mime = document.mime_type;

  if (wanted && req.user.can('documents.view')) {
    const version = versionsFor(document.id).find((v) => v.version === wanted);
    if (!version) return next();
    storedPath = version.stored_path;
    filename = version.original_filename;
    mime = version.mime_type;
  }

  const file = resolveStoredFile(storedPath);
  if (!file) return next();

  const download = req.query.download === '1';
  if (download) {
    recordAudit({
      req, action: 'document.downloaded', entityType: 'document', entityId: document.id,
      detail: { version: wanted || document.version }
    });
  }

  const safeName = String(filename).replace(/[^\w.\- ]+/g, '_');
  // The plain name above is the fallback for old browsers; filename* (RFC 5987) carries the real Unicode name, percent-encoded so it can contain nothing
  // that could end the header or start another.
  const encodedName = encodeURIComponent(String(filename)).replace(/['()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  res.setHeader('Content-Type', mime);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Content-Security-Policy', "default-src 'none'; object-src 'none'; sandbox");
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.setHeader(
    'Content-Disposition',
    `${download ? 'attachment' : 'inline'}; filename="${safeName}"; filename*=UTF-8''${encodedName}`
  );
  return streamFile(res, file, next);
});

router.get('/documents/:id(\\d+)/edit', requireAuth, requirePermission('documents.upload'), (req, res, next) => {
  const document = getDocument(Number(req.params.id));
  if (!document || document.status === 'deleted') return next();
  if (!canSee(req.user, document)) return next();
  if (!req.user.can('documents.manage') && document.uploaded_by !== req.user.id) {
    const err = new Error('You can only edit a document you uploaded.');
    err.status = 403;
    return next(err);
  }

  const selected = {};
  for (const type of RELATION_TYPES) {
    selected[type] = document.relationships.filter((r) => r.related_type === type).map((r) => r.related_id);
  }

  return res.render('documents/form', {
    ...audienceLocals(listCategories()),
    title: `Edit ${document.title}`,
    mode: 'edit',
    document,
    values: { ...document, tags: document.tags.map((t) => t.name).join(', ') },
    errors: {},
    categories: listCategories(),
    options: relationOptions(req.user),
    relationTypes: RELATION_TYPES,
    relationLabels: RELATION_LABELS,
    maxSize: formatSize(MAX_DOCUMENT_BYTES),
    selected,
    prefill: {},
    memberSelected: memberRelationSelected(selected, {})
  });
});

router.post('/documents/:id(\\d+)', requireAuth, requirePermission('documents.upload'), (req, res, next) => {
  const document = getDocument(Number(req.params.id));
  if (!document || document.status === 'deleted') return next();
  // Matches the GET edit form's own check: a document moved to a more
  // restrictive audience since upload must not remain editable via a
  // direct POST just because the actor happens to still know its id.
  if (!canSee(req.user, document)) return next();
  if (!req.user.can('documents.manage') && document.uploaded_by !== req.user.id) {
    const err = new Error('You can only edit a document you uploaded.');
    err.status = 403;
    return next(err);
  }

  const v = collectInput(req.body, req.user);
  if (!v.valid) {
    const selected = {};
    for (const type of RELATION_TYPES) {
      selected[type] = document.relationships.filter((r) => r.related_type === type).map((r) => r.related_id);
    }
    return res.status(400).render('documents/form', {
      ...audienceLocals(listCategories()),
      title: `Edit ${document.title}`,
      mode: 'edit',
      document,
      values: req.body,
      errors: v.errors,
      categories: listCategories(),
      options: relationOptions(req.user),
      relationTypes: RELATION_TYPES,
      relationLabels: RELATION_LABELS,
      maxSize: formatSize(MAX_DOCUMENT_BYTES),
      selected,
      prefill: {},
      memberSelected: memberRelationSelected(selected, {})
    });
  }

  const updated = updateDocument(document.id, v.values);
  recordAudit({
    req, action: 'document.updated', entityType: 'document', entityId: document.id,
    detail: {
      title: updated.title,
      category_changed: document.category_id !== updated.category_id ? updated.category_name : undefined
    }
  });
  // A change of who can view the document is its own audit row, with the roles before and after.
  if (document.audience_mode !== updated.audience_mode || JSON.stringify(document.audience_roles) !== JSON.stringify(updated.audience_roles)) {
    recordAudit({
      req, action: 'document.audience_changed', entityType: 'document', entityId: document.id,
      detail: { before: { mode: document.audience_mode, roles: document.audience_roles }, after: { mode: updated.audience_mode, roles: updated.audience_roles } }
    });
  }
  req.flash('success', 'Document updated.');
  return res.redirect(`/documents/${document.id}`);
});

router.post('/documents/:id(\\d+)/replace', requireAuth, requirePermission('documents.upload'),
  (req, res, next) => {
    const document = getDocument(Number(req.params.id));
    if (!document || document.status === 'deleted') return next();
    // See the equivalent check on the main edit route above.
    if (!canSee(req.user, document)) return next();
    if (!req.user.can('documents.manage') && document.uploaded_by !== req.user.id) {
      const err = new Error('You can only replace a file you uploaded.');
      err.status = 403;
      return next(err);
    }

    return documentUpload(req, res, (uploadErr) => safely(next, () => {
      if (uploadErr) {
        req.flash('error', uploadErrorMessage(uploadErr, MAX_DOCUMENT_BYTES));
        return res.redirect(`/documents/${document.id}`);
      }
      if (!verifyCsrf(req)) {
        const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
        err.status = 403;
        return next(err);
      }
      if (!req.file) {
        req.flash('error', 'Choose the replacement file.');
        return res.redirect(`/documents/${document.id}`);
      }

      let result;
      try {
        result = runAtomically(() => {
          const replaced = replaceFile(document.id, req.file, {
            userId: req.user.id,
            note: String(req.body.note || '').slice(0, 200) || null
          });
          recordAudit({
            req, action: 'document.file_replaced', entityType: 'document', entityId: document.id,
            detail: { version: replaced.version }
          });
          return replaced;
        });
      } catch (err) {
        if (!err.status) return next(err);
        req.flash('error', err.message);
        return res.redirect(`/documents/${document.id}`);
      }
      req.flash('success', `File replaced. This is now version ${result.version}, and the previous one is kept.`);
      return res.redirect(`/documents/${document.id}`);
    }));
  });

router.post('/documents/:id(\\d+)/archive', requireAuth, requirePermission('documents.manage'),
  (req, res, next) => {
    const document = getDocument(Number(req.params.id));
    if (!document) return next();
    if (!canSee(req.user, document)) return next();

    setStatus(document.id, 'archived', { userId: req.user.id });
    recordAudit({
      req, action: 'document.archived', entityType: 'document', entityId: document.id,
      detail: { title: document.title }
    });
    req.flash('success', `${document.title} archived. It stays searchable for administrators.`);
    return res.redirect('/documents');
  });

router.post('/documents/:id(\\d+)/restore', requireAuth, requirePermission('documents.manage'),
  (req, res, next) => {
    const document = getDocument(Number(req.params.id));
    if (!document) return next();
    if (!canSee(req.user, document)) return next();

    setStatus(document.id, 'active', { userId: req.user.id });
    recordAudit({
      req, action: 'document.restored', entityType: 'document', entityId: document.id,
      detail: { title: document.title }
    });
    req.flash('success', `${document.title} restored to the library.`);
    return res.redirect(`/documents/${document.id}`);
  });

router.post('/documents/:id(\\d+)/delete', requireAuth, requirePermission('documents.delete'),
  (req, res, next) => {
    const document = getDocument(Number(req.params.id));
    if (!document) return next();

    if (req.body.confirm !== document.title) {
      req.flash('error', 'Type the document title exactly to confirm permanent deletion.');
      return res.redirect(`/documents/${document.id}`);
    }

    destroyDocument(document.id);
    // The document is gone; the record of its removal is not.
    recordAudit({
      req, action: 'document.deleted', entityType: 'document', entityId: document.id,
      detail: {
        title: document.title,
        category: document.category_name,
        original_filename: document.original_filename,
        uploaded_by: document.uploaded_by_name
      }
    });
    req.flash('success', `${document.title} was permanently deleted. The audit record remains.`);
    return res.redirect('/documents');
  });

export default router;
