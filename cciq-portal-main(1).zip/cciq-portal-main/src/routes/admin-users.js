import { atomicRouter } from '../lib/atomic-router.js';
import fs from 'node:fs';
import { streamFile } from '../lib/stream-file.js';
import { likePattern } from '../lib/like.js';
import { asyncRoute } from '../lib/async-route.js';
import { requireAuth, requirePermission, requireRole } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { checkPasswordPolicy } from '../lib/passwords.js';
import { parsePaging, pageWindow } from '../lib/paging.js';
import { stashCredential, consumeCredential } from '../lib/credential-reveal.js';
import {
  searchUsers,
  USER_SORT_COLUMNS,
  USER_STATUS_FILTERS,
  USER_LINK_FILTERS,
  getUserDetailed,
  createUser,
  updateUserProfile,
  setUserStatus,
  unlockUser,
  setUserRoles,
  setPassword,
  countUsersWithPermission,
  listRoles,
  getRole,
  permissionsForRole,
  allPermissions,
  setRolePermissions,
  generateInitialPassword, initialPasswordFor
} from '../services/users.js';
import { displayName, pickerCardFor } from '../services/members.js';
import {
  listBackups, getBackup, listRestores, createBackup, restoreBackup, deleteBackup,
  verifyBackup, resolveBackupFile, formatBytes
} from '../services/backups.js';
import { query, queryOne } from '../db/index.js';
import { today } from '../lib/dates.js';
import { csvCell } from '../lib/csv.js';

const router = atomicRouter();

// --- Users -----------------------------------------------------------------

function roleLists() {
  return { churchRoles: listRoles() };
}

/**
 * The same Super Admin protection already applied to granting/removing the
 * role itself (below): a non-Super-Admin actor must never be able to act on
 * a Super Admin target, however they came to hold admin.users. Delegating
 * admin.users to a narrower role (e.g. an office administrator who should
 * only manage ordinary user accounts) must not implicitly hand that role
 * power over the actual Super Admins - centralized here so status changes
 * and password resets enforce the identical rule the role-change route
 * already does.
 */
function isSuperAdmin(account) {
  return account.roles.some((role) => role.key === 'super_admin');
}

/**
 * The one check every route touching an EXISTING user account's admin.users
 * mutations must run first: a non-Super-Admin actor must never perform ANY
 * administrative mutation against a Super Admin target - not just the role
 * toggle this was originally written for. Codex's independent verification
 * found that a per-route, per-field version of this check left every OTHER
 * mutation on the same target unprotected: the profile-edit route (display
 * name/email/linked member) had no check at all, the status route only
 * checked the disable direction (a delegated actor could still reactivate a
 * disabled Super Admin), and /unlock had no check at all. Applying one
 * shared guard to every mutation route, rather than a bespoke condition per
 * route, is what actually closes this - a future route added to this file
 * inherits the same protection by calling this, rather than needing its
 * own reasoning about whether it needs to.
 */
function refuseIfProtectedTarget(req, res, account) {
  if (!isSuperAdmin(account) || req.user.roles.includes('super_admin')) return false;
  req.flash('error', 'Only a Super Admin can make changes to a Super Admin account.');
  res.redirect(`/admin/users/${account.id}`);
  return true;
}

router.get('/admin/users', requireAuth, requirePermission('admin.users'), (req, res) => {
  const roles = listRoles();
  const search = String(req.query.q || '').slice(0, 60);
  const status = USER_STATUS_FILTERS.includes(req.query.status) ? req.query.status : null;
  const role = roles.some((r) => r.key === req.query.role) ? req.query.role : null;
  const passwordDue = req.query.password_due === '1';
  const linked = USER_LINK_FILTERS.includes(req.query.linked) ? req.query.linked : null;
  const sort = USER_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'name';
  const direction = req.query.dir === 'desc' ? 'desc' : 'asc';
  const requested = parsePaging(req.query);

  // Count first so an out-of-range page is clamped, then fetch just that window.
  const { total } = searchUsers({ search, status, role, passwordDue, linked, sort, direction, limit: 1, offset: 0 });
  const paging = pageWindow({ total, ...requested });
  const { rows } = searchUsers({ search, status, role, passwordDue, linked, sort, direction, limit: paging.pageSize, offset: paging.offset });

  res.render('admin/users', {
    title: 'Users',
    users: rows,
    paging,
    filters: { search, status, role, passwordDue, linked, sort, direction },
    pagerParams: {
      q: search, status, role, password_due: passwordDue ? '1' : '', linked, sort, dir: direction === 'desc' ? 'desc' : '', page_size: paging.pageSize === 25 ? '' : paging.pageSize
    },
    roles
  });
});

router.get('/admin/users/new', requireAuth, requirePermission('admin.users'), (req, res) => {
  res.render('admin/user-form', {
    title: 'Add user',
    mode: 'create',
    account: { status: 'active' },
    values: {},
    errors: {},
    ...roleLists(),
    assignedRoles: ['member'],
    isSelf: false,
    memberSelected: null
  });
});

function collectUserInput(body) {
  const v = new Validator(body);
  v.text('display_name', { required: true, max: 120, label: 'Name' });
  v.email('email', { required: true, label: 'Email' });
  v.integer('member_id', { label: 'Member record' });
  // Only used when creating an account — an existing username is never
  // changed from this form, so this is simply unused on an edit submit.
  v.text('username', { max: 40, label: 'Username' });
  return v;
}

/**
 * An admin can type their own username at creation time instead of accepting
 * the auto-generated cciq_<initial><lastname> suggestion. Left blank,
 * createUser() falls back to that suggestion exactly as before this field
 * existed. The same character set the auto-generator already produces is
 * enforced here so a typed username behaves identically at sign-in.
 */
function validateNewUsername(v) {
  if (!v.values.username) return;
  const username = v.values.username.toLowerCase();
  v.values.username = username;
  if (!/^[a-z0-9._-]+$/.test(username)) {
    v.fail('username', 'Use only lowercase letters, numbers, dots, hyphens and underscores.');
    return;
  }
  if (queryOne('SELECT id FROM users WHERE LOWER(username) = @u', { u: username })) {
    v.fail('username', 'That username is already taken.');
  }
}

function chosenRoles(body, roles) {
  const valid = new Set(roles.map((r) => r.key));
  const raw = Array.isArray(body.roles) ? body.roles : (body.roles ? [body.roles] : []);
  return raw.filter((key) => valid.has(key));
}

router.post('/admin/users', requireAuth, requirePermission('admin.users'), asyncRoute(async (req, res) => {
  const roles = listRoles();
  const v = collectUserInput(req.body);
  const assignedRoles = chosenRoles(req.body, roles);
  if (assignedRoles.length === 0) v.fail('roles', 'Choose at least one role.');

  // A Super Admin can only be created by a Super Admin.
  if (assignedRoles.includes('super_admin') && !req.user.roles.includes('super_admin')) {
    v.fail('roles', 'Only a Super Admin can grant the Super Admin role.');
  }

  validateNewUsername(v);

  const rerender = (errors) => res.status(400).render('admin/user-form', {
    title: 'Add user',
    mode: 'create',
    account: req.body,
    values: req.body,
    errors,
    ...roleLists(),
    assignedRoles,
    isSelf: false,
    memberSelected: pickerCardFor(req.body.member_id)
  });

  if (!v.valid) return rerender(v.errors);

  // A new account starts with a temporary password (the approved one for an ordinary Member or leader account, a random one for administrators and the Kiosk), shown once
  // below, and must change it immediately at first sign-in.
  const password = initialPasswordFor(assignedRoles, { email: v.values.email });
  try {
    const userId = await createUser({
      email: v.values.email,
      username: v.values.username || undefined,
      password,
      displayName: v.values.display_name,
      roleKeys: assignedRoles,
      memberId: v.values.member_id || null,
      mustChangePassword: true,
      createdBy: req.user.id,
      // inside the account's own transaction: no account without its audit row
      onCreated: (newId) => recordAudit({
        req, action: 'admin.user_created', entityType: 'user', entityId: newId,
        detail: { email: v.values.email, roles: assignedRoles }
      })
    });

    req.flash('success', `Account created for ${v.values.display_name}.`);
    // The password itself never goes through req.flash() (the SQLite-backed
    // sessions table) - a one-time in-memory token carries it through this
    // redirect instead. See src/lib/credential-reveal.js.
    const reveal = stashCredential(userId, password);
    return res.redirect(`/admin/users/${userId}?reveal=${reveal}`);
  } catch (err) {
    if (String(err.message).includes('UNIQUE') && String(err.message).includes('username')) {
      return rerender({ username: 'That username is already taken.' });
    }
    if (String(err.message).includes('UNIQUE')) {
      return rerender({ email: 'An account with that email already exists.' });
    }
    throw err;
  }
}));

router.get('/admin/users/:id(\\d+)', requireAuth, requirePermission('admin.users'), (req, res, next) => {
  const account = getUserDetailed(Number(req.params.id));
  if (!account) return next();

  return res.render('admin/user-form', {
    title: account.display_name,
    mode: 'edit',
    account,
    values: account,
    errors: {},
    ...roleLists(),
    assignedRoles: account.roles.map((role) => role.key),
    memberSelected: pickerCardFor(account.member_id),
    isSelf: account.id === req.user.id,
    // One-time reveal: see src/lib/credential-reveal.js. Never persisted -
    // consumeCredential() deletes it from memory on this very read, so a
    // reload or a shared link shows nothing the second time.
    revealedPassword: consumeCredential(req.query.reveal, account.id)
  });
});

router.post('/admin/users/:id(\\d+)', requireAuth, requirePermission('admin.users'), (req, res, next) => {
  const account = getUserDetailed(Number(req.params.id));
  if (!account) return next();
  if (refuseIfProtectedTarget(req, res, account)) return undefined;

  const roles = listRoles();
  const v = collectUserInput(req.body);
  const assignedRoles = chosenRoles(req.body, roles);
  if (assignedRoles.length === 0) v.fail('roles', 'Choose at least one role.');

  const currentRoles = account.roles.map((role) => role.key);
  const wasSuperAdmin = isSuperAdmin(account);
  const willBeSuperAdmin = assignedRoles.includes('super_admin');
  // refuseIfProtectedTarget() above already covers a non-Super-Admin acting
  // on an existing Super Admin target; this remaining check is for the
  // opposite direction - a non-Super-Admin actor GRANTING the role to
  // someone who doesn't have it yet.
  if (!wasSuperAdmin && willBeSuperAdmin && !req.user.roles.includes('super_admin')) {
    v.fail('roles', 'Only a Super Admin can grant the Super Admin role.');
  }

  // The portal must never be left without an administrator who can manage users.
  if (wasSuperAdmin && !willBeSuperAdmin
    && countUsersWithPermission('admin.users', { excludeUserId: account.id }) === 0) {
    v.fail('roles', 'This is the only account that can manage users. Give another account that role first.');
  }

  if (!v.valid) {
    return res.status(400).render('admin/user-form', {
      title: account.display_name,
      mode: 'edit',
      account: { ...account, ...req.body, roles: account.roles },
      values: req.body,
      errors: v.errors,
      ...roleLists(),
      assignedRoles,
      memberSelected: pickerCardFor(req.body.member_id),
      isSelf: account.id === req.user.id
    });
  }

  updateUserProfile(account.id, {
    displayName: v.values.display_name,
    email: v.values.email,
    memberId: v.values.member_id
  });
  setUserRoles(account.id, assignedRoles, { assignedBy: req.user.id });

  recordAudit({
    req, action: 'admin.user_updated', entityType: 'user', entityId: account.id,
    detail: { roles_from: currentRoles, roles_to: assignedRoles }
  });

  req.flash('success', 'Account updated.');
  return res.redirect(`/admin/users/${account.id}`);
});

router.post('/admin/users/:id(\\d+)/status', requireAuth, requirePermission('admin.users'), (req, res, next) => {
  const account = getUserDetailed(Number(req.params.id));
  if (!account) return next();
  if (refuseIfProtectedTarget(req, res, account)) return undefined;

  const v = new Validator(req.body);
  const status = v.oneOf('status', ['active', 'disabled'], { required: true, label: 'Status' });
  if (!v.valid) {
    req.flash('error', 'Choose a valid status.');
    return res.redirect(`/admin/users/${account.id}`);
  }

  if (account.id === req.user.id && status === 'disabled') {
    req.flash('error', 'You cannot deactivate your own account.');
    return res.redirect(`/admin/users/${account.id}`);
  }
  if (status === 'disabled' && countUsersWithPermission('admin.users', { excludeUserId: account.id }) === 0) {
    req.flash('error', 'This is the only account that can manage users, so it cannot be deactivated.');
    return res.redirect(`/admin/users/${account.id}`);
  }

  setUserStatus(account.id, status);
  recordAudit({
    req, action: 'admin.user_status_changed', entityType: 'user', entityId: account.id,
    detail: { from: account.status, to: status }
  });
  req.flash('success', `Portal access ${status === 'active' ? 'reactivated' : 'deactivated'}. The linked member record and history are unchanged.`);
  return res.redirect(`/admin/users/${account.id}`);
});

router.post('/admin/users/:id(\\d+)/unlock', requireAuth, requirePermission('admin.users'), (req, res, next) => {
  const account = getUserDetailed(Number(req.params.id));
  if (!account) return next();
  if (refuseIfProtectedTarget(req, res, account)) return undefined;
  unlockUser(account.id);
  recordAudit({ req, action: 'admin.user_unlocked', entityType: 'user', entityId: account.id });
  req.flash('success', 'Sign-in attempts cleared.');
  return res.redirect(`/admin/users/${account.id}`);
});

/**
 * Two ways to reset a password: generate one, or type a specific one — for
 * example, to write it on a slip of paper for someone who is standing at the
 * desk right now. Either way the account is exactly the same afterwards: a
 * new hash, must_change_password set, and the change on the audit trail. The
 * password itself is never what gets logged.
 */
router.post('/admin/users/:id(\\d+)/password', requireAuth, requirePermission('admin.users'),
  asyncRoute(async (req, res, next) => {
    const account = getUserDetailed(Number(req.params.id));
    if (!account) return next();
    if (refuseIfProtectedTarget(req, res, account)) return undefined;

    const manual = String(req.body.password || '').trim();
    const isManual = manual.length > 0;
    const password = isManual ? manual : generateInitialPassword();

    const problems = checkPasswordPolicy(password, { email: account.email });
    if (problems.length) {
      if (isManual) {
        req.flash('error', problems[0]);
      } else {
        req.flash('error', 'Could not generate a password. Try again.');
      }
      recordAudit({
        req, action: 'admin.user_password_reset', entityType: 'user', entityId: account.id,
        result: 'failure', detail: { method: isManual ? 'manual' : 'generated' }
      });
      return res.redirect(`/admin/users/${account.id}`);
    }

    await setPassword(account.id, password, {
      mustChange: true,
      onChanged: () => recordAudit({
        req, action: 'admin.user_password_reset', entityType: 'user', entityId: account.id,
        detail: { method: isManual ? 'manual' : 'generated' }
      })
    });
    if (isManual) {
      req.flash('success', `Password set for ${account.display_name}. It must be changed at next sign-in.`);
      return res.redirect(`/admin/users/${account.id}`);
    }
    req.flash('success', `Password reset for ${account.display_name}.`);
    // See the "Add user" route above: the password itself never goes
    // through req.flash(), only this one-time in-memory token.
    const reveal = stashCredential(account.id, password);
    return res.redirect(`/admin/users/${account.id}?reveal=${reveal}`);
  }));

// --- Roles and permissions -------------------------------------------------

router.get('/admin/roles', requireAuth, requirePermission('admin.roles'), (req, res) => {
  const roles = listRoles();
  const permissions = allPermissions();

  const byCategory = new Map();
  for (const permission of permissions) {
    if (!byCategory.has(permission.category)) byCategory.set(permission.category, []);
    byCategory.get(permission.category).push(permission);
  }

  res.render('admin/roles', {
    title: 'Roles and permissions',
    roles: roles.map((role) => ({ ...role, permissions: permissionsForRole(role.id) })),
    categories: [...byCategory.entries()].map(([name, items]) => ({ name, items })),
    totalPermissions: permissions.length
  });
});

router.get('/admin/roles/:id(\\d+)/edit', requireAuth, requirePermission('admin.roles'), (req, res, next) => {
  const role = getRole(Number(req.params.id));
  if (!role) return next();

  const permissions = allPermissions();
  const byCategory = new Map();
  for (const permission of permissions) {
    if (!byCategory.has(permission.category)) byCategory.set(permission.category, []);
    byCategory.get(permission.category).push(permission);
  }

  return res.render('admin/role-form', {
    title: `Edit ${role.name}`,
    role,
    assigned: permissionsForRole(role.id),
    categories: [...byCategory.entries()].map(([name, items]) => ({ name, items })),
    locked: role.key === 'super_admin'
  });
});

router.post('/admin/roles/:id(\\d+)', requireAuth, requirePermission('admin.roles'), (req, res, next) => {
  const role = getRole(Number(req.params.id));
  if (!role) return next();

  if (role.key === 'super_admin') {
    req.flash('error', 'The Super Admin role always holds every permission and cannot be edited.');
    return res.redirect('/admin/roles');
  }

  const valid = new Set(allPermissions().map((p) => p.key));
  const raw = Array.isArray(req.body.permissions) ? req.body.permissions : (req.body.permissions ? [req.body.permissions] : []);
  const chosen = raw.filter((key) => valid.has(key));
  const before = permissionsForRole(role.id);

  const result = setRolePermissions(role.id, chosen);
  if (!result || result.ok === false) {
    req.flash('error', 'That role cannot be changed.');
    return res.redirect('/admin/roles');
  }

  const added = chosen.filter((k) => !before.includes(k));
  const removed = before.filter((k) => !chosen.includes(k));
  recordAudit({
    req, action: 'admin.permissions_changed', entityType: 'role', entityId: role.id,
    detail: { role: role.key, added, removed }
  });

  req.flash('success', `${role.name} updated. Changes apply on the next request each user makes.`);
  return res.redirect('/admin/roles');
});

// --- Backups ---------------------------------------------------------------

router.get('/admin/backups', requireAuth, requirePermission('admin.backups.view'), (req, res) => {
  const backups = listBackups().map((backup) => ({
    ...backup,
    present: Boolean(resolveBackupFile(backup.filename)),
    sizeLabel: formatBytes(backup.file_size)
  }));

  res.render('admin/backups', {
    title: 'Backups',
    backups,
    restores: listRestores(),
    canCreate: req.user.can('admin.backups.create'),
    canRestore: req.user.can('admin.backups.restore'),
    isSuperAdmin: req.user.roles.includes('super_admin')
  });
});

router.post('/admin/backups', requireAuth, requirePermission('admin.backups.create'), asyncRoute(async (req, res) => {
  const note = String(req.body.note || '').slice(0, 300) || null;
  const result = await createBackup({ userId: req.user.id, note, kind: 'manual' });

  recordAudit({
    req,
    action: 'admin.backup_created',
    entityType: 'backup',
    entityId: result.backup ? result.backup.id : null,
    result: result.ok ? 'success' : 'failure',
    detail: result.ok
      ? { filename: result.backup.filename, size: result.backup.file_size }
      : { reason: result.reason }
  });

  if (result.ok) {
    req.flash('success', `Backup created: ${result.backup.filename} (${formatBytes(result.backup.file_size)}).`);
  } else {
    req.flash('error', result.reason === 'insufficient_disk_space'
      ? result.message
      : 'The backup could not be completed. The attempt is recorded in the backup history.');
  }
  return res.redirect('/admin/backups');
}));

router.get('/admin/backups/:id(\\d+)/download', requireAuth, requirePermission('admin.backups.view'),
  (req, res, next) => {
    const backup = getBackup(Number(req.params.id));
    if (!backup) return next();

    const file = resolveBackupFile(backup.filename);
    if (!file) {
      req.flash('error', 'That backup file is no longer on the server.');
      return res.redirect('/admin/backups');
    }

    recordAudit({
      req, action: 'admin.backup_downloaded', entityType: 'backup', entityId: backup.id,
      detail: { filename: backup.filename }
    });

    res.setHeader('Content-Type', 'application/gzip');
    res.setHeader('Content-Disposition', `attachment; filename="${backup.filename}"`);
    return streamFile(res, file, next);
  });

router.post('/admin/backups/:id(\\d+)/verify', requireAuth, requirePermission('admin.backups.view'),
  (req, res, next) => {
    const backup = getBackup(Number(req.params.id));
    if (!backup) return next();

    const result = verifyBackup(backup);
    recordAudit({
      req, action: 'admin.backup_verified', entityType: 'backup', entityId: backup.id,
      result: result.ok ? 'success' : 'failure', detail: result
    });

    const messages = {
      missing: 'The backup file is no longer on the server.',
      no_checksum: 'That backup has no checksum recorded.',
      checksum_mismatch: 'The file does not match its recorded checksum and should not be restored.'
    };
    req.flash(result.ok ? 'success' : 'error',
      result.ok ? 'The backup file matches its checksum.' : messages[result.reason]);
    return res.redirect('/admin/backups');
  });

/**
 * Restoring replaces the whole database, so it is restricted to Super Admin by
 * both permission and role, and needs the filename typed to confirm.
 */
router.post('/admin/backups/:id(\\d+)/restore', requireAuth,
  requirePermission('admin.backups.restore'), requireRole('super_admin'), asyncRoute(async (req, res, next) => {
    const backup = getBackup(Number(req.params.id));
    if (!backup) return next();

    if (String(req.body.confirm || '').trim() !== backup.filename) {
      req.flash('error', 'Type the backup filename exactly to confirm a restore.');
      return res.redirect('/admin/backups');
    }

    const reason = String(req.body.reason || '').slice(0, 300) || null;

    // Audited before the swap, because afterwards this database is the old one.
    recordAudit({
      req, action: 'admin.backup_restore_started', entityType: 'backup', entityId: backup.id,
      detail: { filename: backup.filename, reason }
    });

    const result = await restoreBackup(backup.id, { userId: req.user.id, reason });

    if (!result.ok) {
      // A failure this late closed the shared database connection before
      // rolling the file back — that connection cannot be reopened in this
      // process regardless of the successful file-level rollback, so
      // anything else that touches the database (recordAudit, req.flash's
      // session write) would itself throw here. Render a plain,
      // session-independent page and exit, exactly like a successful
      // restore does, rather than a flash+redirect this process can no
      // longer reliably perform.
      if (result.processRestartRequired) {
        // Fatal (database or storage) now always implies processRestartRequired
        // - see restoreBackup()'s fatal_unrecovered paths - so this one branch
        // covers both: a fatal outcome renders the honest restore-fatal page
        // and writes a recovery interlock (see lib/recovery-interlock.js) that
        // blocks the NEXT ordinary startup until tools/clear-recovery-interlock.mjs
        // verifies recovery; a non-fatal restart-required outcome (a clean,
        // verified rollback) keeps the existing, reassuring restore-failed page.
        res.render(result.fatal ? 'admin/restore-fatal' : 'admin/restore-failed', {
          title: result.fatal ? 'Restore requires immediate attention' : 'Restore did not complete',
          backup, recoveryHint: result.recoveryHint, layout: 'plain'
        });
        setTimeout(() => process.exit(0), 500);
        return undefined;
      }

      const messages = {
        missing: 'That backup file is no longer on the server.',
        not_complete: 'That backup did not finish, so it cannot be restored.',
        checksum_mismatch: 'The file does not match its checksum and was not restored.',
        invalid_backup: 'The file is not a readable database and was not restored.',
        insufficient_disk_space: 'There is not enough free disk space to restore safely. Free up space on the drive that holds the backups and try again. Nothing was changed.',
        safety_backup_failed: 'A safety copy of the current database could not be taken, so nothing was changed.',
        restore_in_progress: 'A restore is already running. Wait for it to finish; nothing was changed by this request.',
        stale_shadow_artifacts: 'An earlier restore did not finish cleanly and left files behind. Nothing was changed this time - contact your system administrator before trying again.',
        incomplete_archive: 'That backup archive is missing part of what it claims to contain and was not restored.',
        incompatible_backup_schema: 'That backup was made by a different version of the portal (its database structure does not match this version), so it was not restored and nothing was changed. Contact your technical person.'
      };
      recordAudit({
        req, action: 'admin.backup_restored', entityType: 'backup', entityId: backup.id,
        result: 'failure', detail: { reason: result.reason }
      });
      req.flash('error', messages[result.reason] || 'The restore did not complete. Nothing was changed.');
      return res.redirect('/admin/backups');
    }

    // The database handle is closed and the file replaced, so this process must
    // restart to serve the restored data.
    res.render('admin/restored', {
      title: 'Restore complete',
      backup,
      safety: result.safety,
      // A leftover shadow file that couldn't be cleaned up automatically
      // doesn't mean the restore failed - it succeeded and was verified -
      // but it does need a person to remove it by hand before the next
      // restore can run (see staleShadowArtifacts() in services/backups.js).
      cleanupIncomplete: result.cleanupIncomplete || false,
      layout: 'plain'
    });

    setTimeout(() => process.exit(0), 500);
    return undefined;
  }));

router.post('/admin/backups/:id(\\d+)/delete', requireAuth,
  requirePermission('admin.backups.create'), requireRole('super_admin'), (req, res, next) => {
    const backup = getBackup(Number(req.params.id));
    if (!backup) return next();

    deleteBackup(backup.id);
    recordAudit({
      req, action: 'admin.backup_deleted', entityType: 'backup', entityId: backup.id,
      detail: { filename: backup.filename }
    });
    req.flash('success', 'Backup removed.');
    return res.redirect('/admin/backups');
  });

// --- Audit log export ------------------------------------------------------

router.get('/admin/audit.csv', requireAuth, requirePermission('admin.audit'), (req, res) => {
  const action = String(req.query.action || '').slice(0, 60);
  const rows = query(
    `SELECT a.*, u.display_name AS user_name
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      WHERE (@action = '' OR a.action LIKE @like ESCAPE '\\')
      ORDER BY a.created_at DESC, a.id DESC`,
    { action, like: likePattern(action) }
  );

  // Every matching row is exported: the export is the record, so it is never cut off at a round number.
  const cell = csvCell;
  const lines = [['When', 'User', 'Action', 'Record type', 'Record', 'Result', 'Detail', 'IP address']
    .map(cell).join(',')];
  for (const row of rows) {
    lines.push([row.created_at, row.user_name || row.actor_label || '', row.action, row.entity_type || '',
      row.entity_id || '', row.result, row.detail || '', row.ip_address || ''].map(cell).join(','));
  }

  recordAudit({ req, action: 'admin.audit_exported', detail: { rows: rows.length, filter: action } });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition',
    `attachment; filename="cciq-audit-${today()}.csv"`);
  return res.send(`${lines.join('\r\n')}\r\n`);
});

export default router;
