import { atomicRouter } from '../lib/atomic-router.js';
import { asyncRoute } from '../lib/async-route.js';
import { transaction } from '../db/index.js';
import { requireAuth, requirePermission, requireRole } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit, AUDIT } from '../lib/audit.js';
import { verifyCsrf } from '../lib/csrf.js';
import { memberPhotoUpload, saveMemberPhoto, pruneMemberPhotos, discardStoredFile, removeMemberPhoto, uploadErrorMessage } from '../lib/uploads.js';
import {
  listMembers,
  getMember,
  updateMember,
  changeStatus,
  statusHistory,
  statusCounts,
  scopeFor,
  nextMemberCode,
  customFieldValues,
  saveCustomFieldValues,
  displayName,
  fullName,
  memberTimeline,
  membersCsv,
  setMemberPhoto,
  upcomingBirthdays,
  upcomingAnniversaries,
  searchMembersForPicker,
  setSpouse,
  findPossibleDuplicates,
  canDeleteMember,
  deleteMemberRecord,
  DELETE_REASONS,
  DELETE_REASON_LABELS,
  MEMBER_STATUSES,
  STATUS_LABELS,
  GENDERS,
  MARITAL_STATUSES,
  PARENTS_ATTEND_LABELS,
  DEPARTURE_STATUSES,
  NOT_EXPECTED_STATUSES,
  describeStatus,
  destinationCountries,
  MEMBER_SORT_COLUMNS,
  CURRENT_POPULATION_STATUSES,
  normalizeMemberStatuses
} from '../services/members.js';
import { COUNTRIES, isCountry } from '../lib/countries.js';
import { parsePaging, serverPaged, paginateList, pageSizeParam, paramsFromQueryString } from '../lib/paging.js';
import { memberAttendanceSummary } from '../services/attendance.js';
import { regenerateQrToken } from '../services/qr-checkin.js';
import { memberCardPng } from '../services/member-card.js';
import { provisionMemberAccount, findUserByMemberId } from '../services/users.js';
import { stashCredential, consumeCredential } from '../lib/credential-reveal.js';
import { remindersForMember, STATE_LABELS as REMINDER_STATE_LABELS } from '../services/reminders.js';
import { ministriesForMember, ROLE_LABELS as MINISTRY_ROLE_LABELS } from '../services/ministries.js';
import { familyGroupForMember } from '../services/family-groups.js';
import { documentsFor, scopeFor as documentScope } from '../services/documents.js';
import { today } from '../lib/dates.js';
import { dobNotice, dobReviewCounts, CATEGORY_LABELS as DOB_CATEGORY_LABELS, REASON_TEXT as DOB_REASON_TEXT, REVIEW_LABELS as DOB_REVIEW_LABELS } from '../services/dob-quality.js';
import { dobReviewRows, dobReviewContext, checkDecision, applyDobDecision, describeDecision, DECISIONS as DOB_DECISIONS, DECISION_LABELS as DOB_DECISION_LABELS } from '../services/dob-review.js';
import { collectMemberInput, pickerSelections, formOptions } from '../lib/member-form.js';
import { createMemberRecord, recordDuplicateOverride } from '../services/member-create.js';
import { preMembershipHistory } from '../services/visitors.js';
import {
  AGE_GROUPS, AGE_GROUP_LABELS, describeCongregation, setAgeGroup, setGuardian,
  dependantsOf, guardianOf, childrenOf, congregationCounts,
  reviewCongregations, followAgeAgain
} from '../services/congregations.js';
import {
  activeGroupOptions,
  getGroup,
  membershipHistory,
  assignMemberToGroup,
  GROUP_ROLES
} from '../services/cell-groups.js';

const router = atomicRouter();

const PROFILE_TABS = ['overview', 'church', 'attendance', 'cell-group', 'activities', 'reminders', 'history'];

function readFilters(req) {
  const sort = MEMBER_SORT_COLUMNS.includes(req.query.sort) ? req.query.sort : 'name';
  // A bookmarked/typed URL with no explicit direction should behave exactly
  // as this sort always did before column-header sorting existed: "Date
  // joined" showed most-recently-joined first, everything else was
  // ascending. A header click always states its own direction explicitly.
  const direction = ['asc', 'desc'].includes(req.query.direction)
    ? req.query.direction
    : (sort === 'joined' ? 'desc' : 'asc');
  // Who the list shows. With no status chosen it is everyone currently with CCIQ (the same
  // CURRENT_POPULATION_STATUSES the Dashboard and Ministries use); `status=all` shows every status
  // including historical ones; otherwise exactly the statuses chosen. The mode travels with
  // paging, sorting and the CSV export so the file always matches the screen.
  const rawStatus = [].concat(req.query.status === undefined ? [] : req.query.status);
  const chosen = normalizeMemberStatuses(rawStatus);
  let statusMode = 'chosen';
  let status = chosen;
  if (rawStatus.includes('all')) { statusMode = 'all'; status = []; }
  else if (chosen.length === 0) { statusMode = 'default'; status = [...CURRENT_POPULATION_STATUSES]; }
  return {
    search: String(req.query.q || '').slice(0, 80),
    status,
    statusMode,
    cellGroupId: Number.parseInt(req.query.cell_group_id, 10) || null,
    destinationCountry: isCountry(req.query.country) ? String(req.query.country).trim() : null,
    sort,
    direction
  };
}

// One representation for export, sorting and pagination: repeated status keys.
function memberQuery(filters, overrides = {}) {
  const values = { ...filters, ...overrides };
  const params = new URLSearchParams();
  if (values.search) params.set('q', values.search);
  const mode = overrides.status !== undefined && overrides.statusMode === undefined ? 'chosen' : values.statusMode;
  if (mode === 'all') params.append('status', 'all');
  else if (mode !== 'default') normalizeMemberStatuses(values.status).forEach((status) => params.append('status', status));
  if (values.cellGroupId) params.set('cell_group_id', values.cellGroupId);
  if (values.destinationCountry) params.set('country', values.destinationCountry);
  params.set('sort', values.sort);
  params.set('direction', values.direction);
  if (values.pageSize) params.set('page_size', values.pageSize);
  if (values.page) params.set('page', values.page);
  return params.toString();
}

// --- Shared searchable member picker ----------------------------------------
//
// The backend for the reusable member-picker widget used wherever an existing
// member must be linked (spouse, father, mother, guardian, and other
// locations audited in CCIQ_DECISIONS.md). Returns only what a picker needs
// to tell two people apart safely: formal name, member code, cell group and
// photo — never membership status, phone, or email.

router.get('/members/picker-search', requireAuth, requirePermission('members.view'), (req, res) => {
  const term = String(req.query.q || '').slice(0, 80);
  const excludeId = Number.parseInt(req.query.exclude, 10) || null;
  const excludeCellGroupId = Number.parseInt(req.query.excludeCellGroup, 10) || null;
  const excludeIds = String(req.query.excludeIds || '').split(',').map((s) => Number.parseInt(s, 10));
  res.json(searchMembersForPicker(term, { excludeId, excludeCellGroupId, excludeIds }));
});

// --- List, dates and export ------------------------------------------------

router.get('/members', requireAuth, requirePermission('members.view'), (req, res) => {
  const scope = scopeFor(req.user);
  const filters = readFilters(req);
  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listMembers({ scope, ...filters, page, pageSize }),
    parsePaging(req.query)
  );
  const linkFilters = { ...filters, pageSize: pageSizeParam(paging) };

  res.render('members/index', {
    title: 'Members',
    result,
    paging,
    pagerParams: { ...paramsFromQueryString(memberQuery(linkFilters)), page: undefined },
    counts: statusCounts(scope),
    currentStatuses: CURRENT_POPULATION_STATUSES,
    memberQuery: (overrides) => memberQuery(linkFilters, overrides),
    filters,
    cellGroups: activeGroupOptions(),
    statuses: MEMBER_STATUSES,
    statusLabels: STATUS_LABELS,
    countriesInUse: destinationCountries(),
    departureStatuses: DEPARTURE_STATUSES
  });
});

router.get('/members/congregations', requireAuth, requirePermission('members.view'), (req, res) => {
  const review = reviewCongregations();
  // Two queues that can grow, each paged on its own (mpage / upage) so neither hides the other.
  const movesPaging = paginateList(review.moves, parsePaging({ page: req.query.mpage, page_size: req.query.msize }));
  const upcomingPaging = paginateList(review.upcoming, parsePaging({ page: req.query.upage, page_size: req.query.usize }));
  res.render('members/congregations', {
    title: 'Congregations',
    counts: congregationCounts(),
    review,
    movesPaging,
    upcomingPaging,
    movesPagerParams: { upage: upcomingPaging.page > 1 ? upcomingPaging.page : null, usize: pageSizeParam(upcomingPaging), msize: pageSizeParam(movesPaging) },
    upcomingPagerParams: { mpage: movesPaging.page > 1 ? movesPaging.page : null, msize: pageSizeParam(movesPaging), usize: pageSizeParam(upcomingPaging) },
    ageGroups: AGE_GROUPS,
    ageGroupLabels: AGE_GROUP_LABELS,
    canManage: req.user.can('members.edit')
  });
});

router.post('/members/:id(\\d+)/congregation', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  const action = req.body.action === 'follow_age' ? 'follow_age' : 'set';
  if (action === 'follow_age') {
    followAgeAgain(member.id, { userId: req.user.id });
    recordAudit({
      req, action: 'member.congregation_changed', entityType: 'member', entityId: member.id,
      detail: { from: member.age_group, to: 'follows the date of birth' }
    });
    req.flash('success', `${displayName(member)} now follows their date of birth.`);
    return res.redirect(req.body.return_to === 'review' ? '/members/congregations' : `/members/${member.id}`);
  }

  const v = new Validator(req.body);
  const group = v.oneOf('age_group', AGE_GROUPS, { required: true, label: 'Congregation' });
  if (!v.valid) {
    req.flash('error', 'Choose a congregation.');
    return res.redirect(`/members/${member.id}`);
  }

  setAgeGroup(member.id, group, { userId: req.user.id });
  recordAudit({
    req, action: 'member.congregation_changed', entityType: 'member', entityId: member.id,
    detail: { from: member.age_group, to: group }
  });
  req.flash('success', `${displayName(member)} moved to ${AGE_GROUP_LABELS[group]}.`);
  return res.redirect(req.body.return_to === 'review' ? '/members/congregations' : `/members/${member.id}`);
});

// The Date of birth review (before any /members/:id route): every date of birth that is invalid, needs verification, should be checked against the source, or already has a decision on it.
// Only a Church Admin or Super Admin may open it or act on it. Opening it never changes anything.
router.get('/members/dob-review', requireAuth, requirePermission('members.edit'), requireRole('church_admin', 'super_admin'), (req, res) => {
  const category = ['A', 'B', 'C', 'E'].includes(req.query.category) ? req.query.category : '';
  const state = ['undecided', 'verified', 'unverified', 'month_day_only'].includes(req.query.state) ? req.query.state : '';
  // The filter value is a hyphenated slug (never an internal code); it is turned back into the reason it names.
  const reasonKey = String(req.query.reason || '').replace(/-/g, '_');
  const reason = Object.keys(DOB_REASON_TEXT).includes(reasonKey) ? reasonKey : '';
  const q = String(req.query.q || '').trim().slice(0, 80);
  const all = dobReviewRows({ category, state, reason, search: q });
  const paging = paginateList(all, parsePaging(req.query));
  res.render('members/dob-review', {
    title: 'Date of birth review', counts: dobReviewCounts(), category, state, reason, q, categoryLabels: DOB_CATEGORY_LABELS, reasonText: DOB_REASON_TEXT, reviewLabels: DOB_REVIEW_LABELS,
    paging, rows: paging.rows,
    pagerParams: { category: category || null, state: state || null, reason: reason ? reason.replace(/_/g, '-') : null, q: q || null, page_size: pageSizeParam(paging) }
  });
});

const dobDecisionInput = (body) => ({
  decision: DOB_DECISIONS.includes(body.decision) ? body.decision : '',
  newDob: String(body.new_dob || '').trim(),
  markVerified: body.mark_verified === '1',
  reason: String(body.reason || '').trim().slice(0, 300),
  expectedDob: body.expected_dob === undefined ? undefined : String(body.expected_dob),
  expectedReview: body.expected_review === undefined ? undefined : String(body.expected_review)
});

router.get('/members/:id(\\d+)/dob-review', requireAuth, requirePermission('members.edit'), requireRole('church_admin', 'super_admin'), (req, res, next) => {
  const context = dobReviewContext(Number(req.params.id));
  if (!context) return next();
  res.render('members/dob-review-member', {
    title: `Date of birth review: ${context.name}`, ...context, decisions: DOB_DECISIONS, decisionLabels: DOB_DECISION_LABELS, reviewLabels: DOB_REVIEW_LABELS, values: {}, errors: {}
  });
});

// Two steps: the first POST checks the choice and shows exactly what will happen; only the second (confirmed=1) writes anything.
router.post('/members/:id(\\d+)/dob-review', requireAuth, requirePermission('members.edit'), requireRole('church_admin', 'super_admin'), (req, res, next) => {
  const id = Number(req.params.id);
  const context = dobReviewContext(id);
  if (!context) return next();
  const input = dobDecisionInput(req.body);
  const check = checkDecision(id, { decision: input.decision, newDob: input.newDob, expectedDob: input.expectedDob, expectedReview: input.expectedReview });

  if (!check.ok) {
    res.status(check.reason === 'changed' ? 409 : 422);
    return res.render('members/dob-review-member', {
      title: `Date of birth review: ${context.name}`, ...context, decisions: DOB_DECISIONS, decisionLabels: DOB_DECISION_LABELS, reviewLabels: DOB_REVIEW_LABELS,
      values: { decision: input.decision, new_dob: input.newDob, mark_verified: input.markVerified ? '1' : '', reason: input.reason }, errors: { form: check.message }
    });
  }

  if (req.body.confirmed !== '1') {
    return res.render('members/dob-review-confirm', {
      title: `Confirm: ${context.name}`, ...context, input, decisionLabel: DOB_DECISION_LABELS[input.decision],
      summary: describeDecision(input.decision, { stored: check.stored, newDob: check.newDob, markVerified: input.markVerified })
    });
  }

  const result = applyDobDecision(id, input, { userId: req.user.id, req });
  if (!result.ok) {
    req.flash('error', result.message);
    return res.redirect(`/members/${id}/dob-review`);
  }
  req.flash('success', `${displayName(result.member)}: ${DOB_DECISION_LABELS[input.decision].toLowerCase()} - saved.`);
  return res.redirect('/members/dob-review');
});

router.get('/members/birthdays', requireAuth, requirePermission('members.view'), (req, res) => {
  const days = Math.min(Math.max(Number.parseInt(req.query.days, 10) || 30, 1), 365);
  // Everything in the window (a whole year can hold more than the old silent cap of 500), a page at a time.
  const all = upcomingBirthdays({ withinDays: days, limit: 100000 });
  const paging = paginateList(all, parsePaging(req.query));
  res.render('members/dates', {
    title: 'Birthdays',
    kind: 'birthday',
    heading: 'Upcoming birthdays',
    days,
    total: all.length,
    paging,
    pagerPath: '/members/birthdays',
    pagerParams: { days: days === 30 ? null : days, page_size: pageSizeParam(paging) },
    dobNotListed: dobReviewCounts().birthdayHidden,
    entries: paging.rows
  });
});

router.get('/members/anniversaries', requireAuth, requirePermission('members.view'), (req, res) => {
  const days = Math.min(Math.max(Number.parseInt(req.query.days, 10) || 30, 1), 365);
  const all = upcomingAnniversaries({ withinDays: days, limit: 100000 });
  const paging = paginateList(all, parsePaging(req.query));
  res.render('members/dates', {
    title: 'Anniversaries',
    kind: 'anniversary',
    heading: 'Upcoming anniversaries',
    days,
    total: all.length,
    paging,
    pagerPath: '/members/anniversaries',
    pagerParams: { days: days === 30 ? null : days, page_size: pageSizeParam(paging) },
    entries: paging.rows
  });
});

router.get('/members/export.csv', requireAuth, requirePermission('members.view', 'reports.export'), (req, res) => {
  const filters = readFilters(req);
  const { csv, count } = membersCsv({
    scope: scopeFor(req.user),
    includeContact: req.user.can('members.view_contact'),
    filters
  });

  recordAudit({
    req, action: 'member.exported', entityType: 'member',
    detail: { count, filters, contact_included: req.user.can('members.view_contact') }
  });

  const stamp = today();
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="cciq-members-${stamp}.csv"`);
  res.send(csv);
});

// --- Create ----------------------------------------------------------------

router.get('/members/new', requireAuth, requirePermission('members.create'), (req, res) => {
  res.render('members/form', {
    title: 'Add member',
    mode: 'create',
    member: { status: 'pending' },
    memberCode: nextMemberCode(),
    errors: {},
    values: {},
    extraValues: {},
    ...formOptions(),
    ...pickerSelections({})
  });
});

router.post('/members', requireAuth, requirePermission('members.create'), asyncRoute(async (req, res) => {
  const v = collectMemberInput(req.body);
  const status = MEMBER_STATUSES.includes(req.body.status) ? req.body.status : 'pending';

  if (!v.valid) {
    return res.status(400).render('members/form', {
      title: 'Add member',
      mode: 'create',
      member: { ...req.body, status },
      memberCode: nextMemberCode(),
      errors: v.errors,
      values: req.body,
      extraValues: req.body,
      ...formOptions(),
      ...pickerSelections(req.body)
    });
  }

  const overridden = req.body.duplicate_override === '1';
  if (!overridden) {
    const duplicates = findPossibleDuplicates(v.values);
    if (duplicates.length) {
      return res.render('members/duplicate-warning', {
        title: 'Possible duplicate member',
        action: '/members',
        cancelHref: '/members/new',
        duplicates,
        hasStrongMatch: duplicates.some((d) => d.level === 'strong'),
        formBody: req.body
      });
    }
  }

  // One unit (see services/member-create.js): the member, their extra fields, age group, guardian, cell group, spouse link and the
  // audit entry are written together; a failure part-way leaves no half-created member.
  const { member, spouseConflictName } = createMemberRecord({ values: v.values, body: req.body, status, userId: req.user.id, req, reason: 'Record created' });

  if (overridden) recordDuplicateOverride({ req, member, values: v.values, body: req.body });

  if (spouseConflictName) {
    req.flash('error',
      `${spouseConflictName} is already recorded as married to someone else, so the spouse link was `
      + 'not saved. Resolve which record is correct, then link the spouse again.');
  }

  // A sign-in account is created alongside the member, so nobody has to
  // remember a separate step. It always carries the Member role to start.
  const account = await provisionMemberAccount(member, { createdBy: req.user.id });
  if (account.created) {
    recordAudit({
      req, action: 'admin.member_account_created', entityType: 'user', entityId: account.user.id,
      detail: { member_id: member.id, username: account.user.username }
    });
    req.flash('success',
      `${displayName(member)} added. Sign-in created — username: ${account.user.username}.`);
    // The password itself never goes through req.flash() (the SQLite-backed
    // sessions table) - a one-time in-memory token carries it through this
    // redirect instead. See src/lib/credential-reveal.js.
    const reveal = stashCredential(account.user.id, account.password);
    return res.redirect(`/members/${member.id}?reveal=${reveal}`);
  }

  req.flash('success', `${displayName(member)} added.`);
  return res.redirect(`/members/${member.id}`);
}));

// --- Profile ---------------------------------------------------------------

router.get('/members/:id(\\d+)', requireAuth, requirePermission('members.view'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  const tab = PROFILE_TABS.includes(req.query.tab) ? req.query.tab : 'overview';
  // Looked up unconditionally so the one-time credential reveal below works
  // regardless of the viewer's general admin.users visibility into linked
  // accounts - member creation only ever requires members.create (see
  // POST /members above), so a Default Church Admin who just created this
  // member and was handed a one-time reveal token must be able to see the
  // credential they generated, even without admin.users. The token itself
  // is what actually gates the reveal (consumeCredential() only returns a
  // password when the token both exists and matches this exact account),
  // so this unconditional lookup is safe on its own; `linkedAccount` below
  // stays admin.users-gated for the separate decision of showing this
  // member's account DETAILS in the page.
  const accountForMember = findUserByMemberId(member.id);
  const linkedAccount = req.user.can('admin.users') ? accountForMember : null;

  return res.render('members/show', {
    title: displayName(member),
    member,
    dobFlag: member.date_of_birth ? dobNotice(member.id) : null,
    fullName: fullName(member),
    tab,
    attendance: memberAttendanceSummary(member.id, { lastN: 8 }),
    history: statusHistory(member.id),
    timeline: tab === 'history' ? memberTimeline(member.id) : [],
    groups: membershipHistory(member.id),
    group: member.cell_group_id ? getGroup(member.cell_group_id) : null,
    cellGroups: activeGroupOptions(),
    groupRoles: GROUP_ROLES,
    extraValues: customFieldValues(member.id),
    reminders: req.user.can('reminders.view') && tab === 'reminders'
      ? remindersForMember(member.id)
      : [],
    reminderStateLabels: REMINDER_STATE_LABELS,
    congregation: describeCongregation(member),
    statusInfo: describeStatus(member),
    departureStatuses: DEPARTURE_STATUSES,
    notExpectedStatuses: NOT_EXPECTED_STATUSES,
    countries: COUNTRIES,
    ministries: req.user.can('ministries.view') ? ministriesForMember(member.id) : [],
    documents: req.user.can('documents.view')
      ? documentsFor('member', member.id, { scope: documentScope(req.user) })
      : [],
    canUploadDocuments: req.user.can('documents.upload'),
    ministryRoleLabels: MINISTRY_ROLE_LABELS,
    spouse: member.spouse_member_id ? getMember(member.spouse_member_id, { type: 'all' }) : null,
    father: member.father_member_id ? getMember(member.father_member_id, { type: 'all' }) : null,
    mother: member.mother_member_id ? getMember(member.mother_member_id, { type: 'all' }) : null,
    parentsAttendLabels: PARENTS_ATTEND_LABELS,
    dependants: dependantsOf(member.id),
    guardian: guardianOf(member.id),
    children: childrenOf(member.id),
    statuses: MEMBER_STATUSES,
    linkedAccount,
    familyGroup: req.user.can('family_groups.view') ? familyGroupForMember(member.id) : null,
    beforeMembership: tab === 'overview' ? preMembershipHistory(member.id) : null,
    // One-time reveal: see src/lib/credential-reveal.js. Never persisted.
    revealedPassword: accountForMember ? consumeCredential(req.query.reveal, accountForMember.id) : null
  });
});

// --- QR check-in code --------------------------------------------------------

router.get('/members/:id(\\d+)/qr', requireAuth, requirePermission('members.view'), asyncRoute(async (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  res.render('members/qr', {
    title: `QR code · ${displayName(member)}`,
    member,
    canRegenerate: req.user.can('members.edit')
  });
}));

router.get('/members/:id(\\d+)/qr/card.png', requireAuth, requirePermission('members.view'), asyncRoute(async (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  try {
    const png = await memberCardPng(member);
    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'private, no-cache');
    res.send(png);
  } catch (err) {
    next(err);
  }
}));

router.post('/members/:id(\\d+)/qr/regenerate', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  regenerateQrToken(member.id);
  recordAudit({
    req, action: AUDIT.MEMBER_QR_REGENERATED, entityType: 'member', entityId: member.id
  });
  req.flash('success', `A new QR code was issued for ${displayName(member)}. Their old code no longer works.`);
  res.redirect(`/members/${member.id}/qr`);
});

// --- Edit ------------------------------------------------------------------

router.get('/members/:id(\\d+)/edit', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();

  const extraValues = {};
  for (const field of customFieldValues(member.id)) {
    extraValues[`custom_${field.field_key}`] = field.value;
  }

  return res.render('members/form', {
    title: `Edit ${displayName(member)}`,
    mode: 'edit',
    member,
    dobFlag: member.date_of_birth ? dobNotice(member.id) : null,
    memberCode: member.member_code,
    errors: {},
    values: member,
    extraValues,
    ...formOptions(),
    ...pickerSelections(member)
  });
});

router.post('/members/:id(\\d+)', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const id = Number(req.params.id);
  const existing = getMember(id, scopeFor(req.user));
  if (!existing) return next();

  const v = collectMemberInput(req.body, id);
  if (!v.valid) {
    const extraValues = {};
    for (const [key, value] of Object.entries(req.body)) {
      if (key.startsWith('custom_')) extraValues[key] = value;
    }
    return res.status(400).render('members/form', {
      title: `Edit ${displayName(existing)}`,
      mode: 'edit',
      member: { ...existing, ...req.body },
      memberCode: existing.member_code,
      errors: v.errors,
      values: req.body,
      extraValues,
      ...formOptions(),
      ...pickerSelections(req.body)
    });
  }

  // Only re-check when an identity field actually changed — editing an
  // unrelated field (phone, cell group, notes) on a record that already
  // legitimately overlaps someone else should not re-surface the same
  // warning every time.
  const identityFields = ['first_name', 'middle_name', 'last_name', 'date_of_birth'];
  const identityChanged = identityFields.some((field) => (v.values[field] || null) !== (existing[field] || null));
  const overridden = req.body.duplicate_override === '1';

  if (identityChanged && !overridden) {
    const duplicates = findPossibleDuplicates(v.values, { excludeId: id });
    if (duplicates.length) {
      const extraValues = {};
      for (const [key, value] of Object.entries(req.body)) {
        if (key.startsWith('custom_')) extraValues[key] = value;
      }
      return res.render('members/duplicate-warning', {
        title: 'Possible duplicate member',
        action: `/members/${id}`,
        cancelHref: `/members/${id}/edit`,
        duplicates,
        hasStrongMatch: duplicates.some((d) => d.level === 'strong'),
        formBody: req.body
      });
    }
  }

  // One unit (see the create route): the record, its extra fields, relationships, cell group and audit entries together.
  const previousGroup = existing.cell_group_id || null;
  const nextGroup = v.values.cell_group_id || null;
  const spouseResult = transaction(() => {
    updateMember(id, v.values, { userId: req.user.id });
    saveCustomFieldValues(id, req.body);
    setAgeGroup(id, v.values.age_group, { userId: req.user.id });
    // Self-guardian is already refused above in collectMemberInput(), so
    // guardian_member_id can never equal id by the time execution reaches here.
    setGuardian(id, v.values.guardian_member_id, { userId: req.user.id });

    const result = setSpouse(id, v.values.spouse_member_id, { userId: req.user.id });

    if (previousGroup !== nextGroup) {
      assignMemberToGroup(id, nextGroup, { userId: req.user.id });
      recordAudit({
        req, action: 'member.group_changed', entityType: 'member', entityId: id,
        detail: { from: previousGroup, to: nextGroup }
      });
    }

    recordAudit({ req, action: AUDIT.MEMBER_UPDATED, entityType: 'member', entityId: id });
    return result;
  })();

  if (identityChanged && overridden) {
    const matches = findPossibleDuplicates(v.values, { excludeId: id });
    recordAudit({
      req, action: AUDIT.MEMBER_DUPLICATE_WARNING_OVERRIDDEN, entityType: 'member', entityId: id,
      detail: {
        edited_member: { id, member_code: existing.member_code, name: displayName(existing) },
        possible_matches: matches.map((m) => ({ id: m.member.id, member_code: m.member.memberCode, level: m.level })),
        override_reason: String(req.body.override_reason || '').slice(0, 200) || null
      }
    });
  }

  if (!spouseResult.ok && spouseResult.reason === 'conflict') {
    const conflictMember = getMember(spouseResult.conflictMemberId);
    const conflictName = conflictMember ? displayName(conflictMember) : 'another member';
    req.flash('success', 'Member record updated.');
    req.flash('error',
      `${conflictName} is already recorded as married to someone else, so the spouse link was not `
      + 'saved. Resolve which record is correct, then link the spouse again.');
  } else {
    req.flash('success', 'Member record updated.');
  }
  return res.redirect(`/members/${id}`);
});

// --- Permanent deletion ------------------------------------------------------
//
// Reserved for a record that should never have existed (a duplicate, a
// mistake, a test entry) — the normal action for someone genuinely no
// longer active is Archive (members.archive, the existing status change
// flow), which this never bypasses or replaces.

router.get('/members/:id(\\d+)/delete', requireAuth, requirePermission('members.delete'), (req, res, next) => {
  const member = getMember(Number(req.params.id), { type: 'all' });
  if (!member) return next();

  const check = canDeleteMember(member.id);
  res.render('members/delete-confirm', {
    title: `Delete ${displayName(member)}?`,
    member,
    canDelete: check.safe,
    summary: check.summary,
    reasons: DELETE_REASONS,
    reasonLabels: DELETE_REASON_LABELS,
    errors: {}
  });
});

router.post('/members/:id(\\d+)/delete', requireAuth, requirePermission('members.delete'), (req, res, next) => {
  const member = getMember(Number(req.params.id), { type: 'all' });
  if (!member) return next();

  const v = new Validator(req.body);
  const reason = v.oneOf('reason', DELETE_REASONS, { required: true, label: 'Reason' });
  let explanation = null;
  if (reason === 'other') {
    explanation = v.text('explanation', { required: true, max: 300, label: 'Explanation' });
  }

  // Re-checked here rather than trusted from the confirmation page, so a
  // dependency created between opening that page and submitting this form
  // (or a hand-crafted request) can never slip through.
  const check = canDeleteMember(member.id);

  if (!v.valid || !check.safe) {
    if (!check.safe) {
      v.fail('reason', 'This member has linked historical records and cannot be permanently deleted safely.');
    }
    return res.status(400).render('members/delete-confirm', {
      title: `Delete ${displayName(member)}?`,
      member,
      canDelete: check.safe,
      summary: check.summary,
      reasons: DELETE_REASONS,
      reasonLabels: DELETE_REASON_LABELS,
      errors: v.errors
    });
  }

  // Written before the row is gone, so the record can still be identified
  // afterward — exactly what a permanent deletion needs its audit trail to
  // preserve, and nothing more (no notes, contact details or other content
  // that has no bearing on what was deleted or why).
  recordAudit({
    req, action: AUDIT.MEMBER_DELETED, entityType: 'member', entityId: member.id,
    detail: {
      member_id: member.id,
      member_code: member.member_code,
      name: displayName(member),
      reason,
      explanation,
      dependency_check: check.summary
    }
  });

  const result = deleteMemberRecord(member.id, { userId: req.user.id });
  if (!result.ok) {
    req.flash('error', 'This member could not be deleted — it now has linked historical records. Archive it instead.');
    return res.redirect(`/members/${member.id}`);
  }

  req.flash('success', `${displayName(member)} (${member.member_code}) was permanently deleted.`);
  return res.redirect('/members');
});

// --- Status ----------------------------------------------------------------

router.post('/members/:id(\\d+)/status', requireAuth, requirePermission('members.change_status'), (req, res, next) => {
  const id = Number(req.params.id);
  const member = getMember(id, scopeFor(req.user));
  if (!member) return next();

  const v = new Validator(req.body);
  const status = v.oneOf('status', MEMBER_STATUSES, { required: true, label: 'Status' });
  const reason = v.text('reason', { max: 500, label: 'Reason' });
  const departureNotes = v.text('departure_notes', { max: 500, label: 'Departure notes' });

  // A move to another country is only useful if the country is recorded.
  let destinationCountry = null;
  if (DEPARTURE_STATUSES.includes(status)) {
    const chosen = String(req.body.destination_country || '').trim();
    if (!chosen) {
      v.fail('destination_country', 'Choose the country the member has moved to.');
    } else if (!isCountry(chosen)) {
      v.fail('destination_country', 'Choose a country from the list.');
    } else {
      destinationCountry = chosen;
    }
  }

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/members/${id}?tab=church`);
  }

  // Archiving takes a member out of day-to-day lists, so it has its own permission.
  if (status === 'archived' && !req.user.can('members.archive')) {
    const err = new Error('Archiving a member record is not permitted for your role.');
    err.status = 403;
    return next(err);
  }

  const result = changeStatus(id, status, {
    userId: req.user.id, reason, destinationCountry, departureNotes
  });
  if (result && result.previous) {
    if (status === 'archived') assignMemberToGroup(id, null, { userId: req.user.id });
    recordAudit({
      req, action: AUDIT.MEMBER_STATUS_CHANGED, entityType: 'member', entityId: id,
      detail: { from: result.previous, to: result.next, reason }
    });
    req.flash('success', `Status changed to ${status}.`);
  } else {
    req.flash('info', 'Status unchanged.');
  }
  return res.redirect(`/members/${id}?tab=history`);
});

// --- Cell group assignment -------------------------------------------------

router.post('/members/:id(\\d+)/cell-group', requireAuth, requirePermission('cellgroups.manage'), (req, res, next) => {
  const id = Number(req.params.id);
  const member = getMember(id, { type: 'all' });
  if (!member) return next();

  /*
   * The form always requires an explicit choice for both fields — no blank
   * submission is treated as "leave it as it is" or "the ordinary default."
   * "No cell group" is its own explicit option (value "none"), kept separate
   * from an empty/missing field, so a crafted or incomplete request can never
   * be mistaken for a deliberate unassignment, and never falls back to
   * Leader — see CCIQ_DECISIONS.md.
   */
  const v = new Validator(req.body);
  const rawGroup = String(req.body.cell_group_id || '');
  let groupId = null;
  if (!rawGroup) {
    v.fail('cell_group_id', 'Choose a cell group, or choose "No cell group" to remove the assignment.');
  } else if (rawGroup !== 'none') {
    groupId = v.integer('cell_group_id', { required: true, label: 'Cell group' });
  }
  const role = v.oneOf('role_in_group', GROUP_ROLES, { required: true, label: 'Role in group' });

  if (!v.valid) {
    req.flash('error', Object.values(v.errors)[0]);
    return res.redirect(`/members/${id}?tab=cell-group`);
  }
  if (groupId && !getGroup(groupId)) {
    req.flash('error', 'That cell group no longer exists.');
    return res.redirect(`/members/${id}?tab=cell-group`);
  }

  assignMemberToGroup(id, groupId, { role, userId: req.user.id });
  recordAudit({
    req, action: 'member.group_changed', entityType: 'member', entityId: id,
    detail: { from: member.cell_group_id, to: groupId, role }
  });

  req.flash('success', groupId ? 'Cell group updated.' : 'Member removed from their cell group.');
  return res.redirect(`/members/${id}?tab=cell-group`);
});

// --- Photo -----------------------------------------------------------------

router.post('/members/:id(\\d+)/photo', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const id = Number(req.params.id);
  const member = getMember(id, scopeFor(req.user));
  if (!member) return next();

  return memberPhotoUpload(req, res, (uploadErr) => {
    // Multipart bodies are parsed here, so the token is checked here too.
    if (!verifyCsrf(req)) {
      const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
      err.status = 403;
      return next(err);
    }
    if (uploadErr) {
      req.flash('error', uploadErrorMessage(uploadErr));
      return res.redirect(`/members/${id}/edit`);
    }
    if (!req.file) {
      req.flash('error', 'Choose an image to upload.');
      return res.redirect(`/members/${id}/edit`);
    }

    let storedPath = null;
    try {
      ({ storedPath } = saveMemberPhoto(id, req.file));
      transaction(() => {
        setMemberPhoto(id, storedPath, { userId: req.user.id });
        recordAudit({
          req, action: 'member.photo_updated', entityType: 'member', entityId: id,
          detail: { size: req.file.size }
        });
      })();
      pruneMemberPhotos(id, storedPath);
      req.flash('success', 'Profile photo updated.');
    } catch (err) {
      if (storedPath) discardStoredFile(storedPath); // the record still points at the previous photo
      if (!err.status) return next(err);
      req.flash('error', err.message);
    }
    return res.redirect(`/members/${id}/edit`);
  });
});

router.post('/members/:id(\\d+)/photo/remove', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const id = Number(req.params.id);
  const member = getMember(id, scopeFor(req.user));
  if (!member) return next();

  removeMemberPhoto(id);
  setMemberPhoto(id, null, { userId: req.user.id });
  recordAudit({ req, action: 'member.photo_updated', entityType: 'member', entityId: id, detail: 'removed' });
  req.flash('success', 'Profile photo removed.');
  return res.redirect(`/members/${id}/edit`);
});

// --- Quick view from the attendance sheet ----------------------------------

/**
 * A compact profile rendered as a fragment, so the attendance page can show it
 * in a drawer without navigating away. It reuses the same scoping, permission
 * checks, validation and update functions as the full member pages: nothing
 * about a member is decided twice.
 */
function quickViewModel(req, member) {
  const summary = req.user.can('attendance.view')
    ? memberAttendanceSummary(member.id, { lastN: 6 })
    : null;

  return {
    member,
    statusInfo: describeStatus(member),
    congregation: describeCongregation(member),
    summary,
    counts: summary
      ? {
        present: summary.services.filter((s) => s.status === 'present' || s.status === 'visitor').length,
        absent: summary.services.filter((s) => s.status === 'absent').length,
        excused: summary.services.filter((s) => s.status === 'excused').length,
        notRecorded: summary.services.filter((s) => s.status === 'not_recorded').length
      }
      : null,
    canSeeContact: req.user.can('members.view_contact'),
    canSeeNotes: req.user.can('members.view_notes'),
    canEdit: req.user.can('members.edit'),
    canChangeStatus: req.user.can('members.change_status'),
    canArchive: req.user.can('members.archive'),
    statuses: MEMBER_STATUSES,
    statusLabels: STATUS_LABELS,
    departureStatuses: DEPARTURE_STATUSES,
    countries: COUNTRIES,
    cellGroups: activeGroupOptions(),
    genders: GENDERS,
    maritalStatuses: MARITAL_STATUSES,
    errors: {},
    values: {},
    saved: false
  };
}

function renderQuickView(req, res, member, extra = {}) {
  return res.render('members/quick-view', {
    ...quickViewModel(req, member),
    ...extra,
    layout: false
  });
}

router.get('/members/:id(\\d+)/quick', requireAuth, requirePermission('members.view'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();
  return renderQuickView(req, res, member);
});

router.get('/members/:id(\\d+)/quick/edit', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const member = getMember(Number(req.params.id), scopeFor(req.user));
  if (!member) return next();
  return res.render('members/quick-edit', {
    ...quickViewModel(req, member),
    layout: false
  });
});

/**
 * The drawer edits a handful of fields, so the submitted values are laid over
 * the record's current ones before validation. Without that, a field absent
 * from the compact form would be saved as empty.
 */
function mergeWithExisting(existing, body) {
  const merged = { ...existing };
  merged.is_baptized = existing.is_baptized ? '1' : '';
  for (const [key, value] of Object.entries(body)) {
    if (key === '_csrf') continue;
    merged[key] = value;
  }
  return merged;
}

router.post('/members/:id(\\d+)/quick', requireAuth, requirePermission('members.edit'), (req, res, next) => {
  const id = Number(req.params.id);
  const existing = getMember(id, scopeFor(req.user));
  if (!existing) return next();

  const v = collectMemberInput(mergeWithExisting(existing, req.body));
  if (!v.valid) {
    return res.status(400).render('members/quick-edit', {
      ...quickViewModel(req, { ...existing, ...req.body }),
      errors: v.errors,
      values: req.body,
      layout: false
    });
  }

  updateMember(id, v.values, { userId: req.user.id });
  setAgeGroup(id, v.values.age_group, { userId: req.user.id });
  recordAudit({
    req, action: 'member.updated', entityType: 'member', entityId: id,
    detail: { via: 'attendance quick view' }
  });

  const updated = getMember(id, scopeFor(req.user));
  return renderQuickView(req, res, updated, { saved: true });
});

router.post('/members/:id(\\d+)/quick/status', requireAuth, requirePermission('members.change_status'),
  (req, res, next) => {
    const id = Number(req.params.id);
    const member = getMember(id, scopeFor(req.user));
    if (!member) return next();

    const v = new Validator(req.body);
    const status = v.oneOf('status', MEMBER_STATUSES, { required: true, label: 'Status' });
    const reason = v.text('reason', { max: 500, label: 'Reason' });
    const departureNotes = v.text('departure_notes', { max: 500, label: 'Departure notes' });

    let destinationCountry = null;
    if (DEPARTURE_STATUSES.includes(status)) {
      const chosen = String(req.body.destination_country || '').trim();
      if (!chosen) {
        v.fail('destination_country', 'Choose the country the member has moved to.');
      } else if (!isCountry(chosen)) {
        v.fail('destination_country', 'Choose a country from the list.');
      } else {
        destinationCountry = chosen;
      }
    }

    if (status === 'archived' && !req.user.can('members.archive')) {
      const err = new Error('Archiving a member record is not permitted for your role.');
      err.status = 403;
      return next(err);
    }

    if (!v.valid) {
      return res.status(400).render('members/quick-view', {
        ...quickViewModel(req, member),
        errors: v.errors,
        values: req.body,
        layout: false
      });
    }

    const result = changeStatus(id, status, {
      userId: req.user.id, reason, destinationCountry, departureNotes
    });
    if (result && result.previous !== result.next) {
      if (status === 'archived') assignMemberToGroup(id, null, { userId: req.user.id });
      recordAudit({
        req, action: 'member.status_changed', entityType: 'member', entityId: id,
        detail: { from: result.previous, to: result.next, via: 'attendance quick view' }
      });
    }

    return renderQuickView(req, res, getMember(id, scopeFor(req.user)), { saved: true });
  });

export default router;
