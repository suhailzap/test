import { atomicRouter } from '../lib/atomic-router.js';
import { streamFile } from '../lib/stream-file.js';
import { transaction } from '../db/index.js';
import fs from 'node:fs';
import { requireAuth, requirePermission, isCheckinOperator } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { verifyCsrf } from '../lib/csrf.js';
import {
  getMember, updateOwnDetails, customFieldValues, fullName, setMemberPhoto, scopeFor
} from '../services/members.js';
import { memberAttendanceSummary } from '../services/attendance.js';
import { getGroup } from '../services/cell-groups.js';
import {
  memberPhotoUpload, saveMemberPhoto, pruneMemberPhotos, discardStoredFile, uploadErrorMessage, resolveStoredFile, contentTypeFor
} from '../lib/uploads.js';

const router = atomicRouter();

/** A member may see their own record even without members.view. */
router.get('/my/profile', requireAuth, requirePermission('profile.view_own'), (req, res) => {
  const member = req.user.memberId ? getMember(req.user.memberId, { type: 'all' }) : null;

  res.render('account/profile', {
    title: 'My profile',
    member,
    fullName: member ? fullName(member) : null,
    attendance: member ? memberAttendanceSummary(member.id, { lastN: 8 }) : null,
    group: member?.cell_group_id ? getGroup(member.cell_group_id) : null,
    extraValues: member ? customFieldValues(member.id, { audience: 'member' }) : [],
    errors: {},
    values: member || {}
  });
});

router.post('/my/profile', requireAuth, requirePermission('profile.edit_own'), (req, res, next) => {
  const member = req.user.memberId ? getMember(req.user.memberId, { type: 'all' }) : null;
  if (!member) {
    req.flash('error', 'Your account is not linked to a member record yet.');
    return res.redirect('/my/profile');
  }

  const v = new Validator(req.body);
  v.text('preferred_name', { max: 80, label: 'Preferred name' });
  v.phone('phone');
  v.email('email');
  v.text('address', { max: 400, label: 'Address' });
  v.text('emergency_contact_name', { max: 120, label: 'Emergency contact name' });
  v.phone('emergency_contact_phone', { label: 'Emergency contact number' });
  v.text('emergency_contact_relation', { max: 60, label: 'Relationship' });

  if (!v.valid) {
    return res.status(400).render('account/profile', {
      title: 'My profile',
      member,
      fullName: fullName(member),
      attendance: memberAttendanceSummary(member.id, { lastN: 8 }),
      group: member.cell_group_id ? getGroup(member.cell_group_id) : null,
      extraValues: customFieldValues(member.id, { audience: 'member' }),
      errors: v.errors,
      values: { ...member, ...req.body }
    });
  }

  updateOwnDetails(member.id, v.values, { userId: req.user.id });
  recordAudit({ req, action: 'member.self_updated', entityType: 'member', entityId: member.id });
  req.flash('success', 'Your details have been updated.');
  return res.redirect('/my/profile');
});

router.post('/my/profile/photo', requireAuth, requirePermission('profile.edit_own'), (req, res, next) => {
  const memberId = req.user.memberId;
  if (!memberId) {
    req.flash('error', 'Your account is not linked to a member record yet.');
    return res.redirect('/my/profile');
  }

  return memberPhotoUpload(req, res, (uploadErr) => {
    if (!verifyCsrf(req)) {
      const err = new Error('Your session expired before this form was submitted. Sign in again and retry.');
      err.status = 403;
      return next(err);
    }
    if (uploadErr || !req.file) {
      req.flash('error', uploadErr ? uploadErrorMessage(uploadErr) : 'Choose an image to upload.');
      return res.redirect('/my/profile');
    }
    let storedPath = null;
    try {
      ({ storedPath } = saveMemberPhoto(memberId, req.file));
      transaction(() => {
        setMemberPhoto(memberId, storedPath, { userId: req.user.id });
        recordAudit({ req, action: 'member.photo_updated', entityType: 'member', entityId: memberId });
      })();
      pruneMemberPhotos(memberId, storedPath);
      req.flash('success', 'Your photo has been updated.');
    } catch (err) {
      if (storedPath) discardStoredFile(storedPath); // the record still points at the previous photo
      if (!err.status) return next(err);
      req.flash('error', err.message);
    }
    return res.redirect('/my/profile');
  });
});

/**
 * Member photos are stored outside the public folder, so every request for one
 * passes through this check first.
 */
router.get('/media/members/:id(\\d+)/photo', requireAuth, (req, res, next) => {
  const id = Number(req.params.id);
  const isOwn = req.user.memberId === id;
  /*
   * The check-in search (searchPeopleForAttendance) is deliberately
   * status-blind and already returns a photoUrl pointing straight at this
   * route for any member it finds, regardless of the caller's scope — that
   * is how a bonafide/inactive/temporarily-away member walking in still
   * shows their photo on the confirm screen. Requiring members.view here as
   * well would silently break that photo for anyone whose only permission
   * is attendance.checkin (both dedicated Kiosk terminals included), even
   * though the search that led them here already assumed this was fine.
   */
  // Only those who operate the check-in interface (the Kiosk account, Church Admin, Super Admin): a leader's attendance permission does not open every member's photo.
  const isCheckin = isCheckinOperator(req.user) && req.user.can('attendance.checkin');

  if (!isOwn && !isCheckin && !req.user.can('members.view')) {
    const err = new Error('You do not have permission to view this photo.');
    err.status = 403;
    return next(err);
  }

  // Leaders only reach photos of members they can already see; check-in and
  // a member's own photo are resolved the same status/scope-blind way the
  // search itself already works.
  const member = (isOwn || isCheckin) ? getMember(id, { type: 'all' }) : getMember(id, scopeFor(req.user));
  if (!member || !member.photo_path) return next();

  const file = resolveStoredFile(member.photo_path);
  if (!file) return next();

  res.setHeader('Content-Type', contentTypeFor(file));
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.setHeader('Content-Disposition', `inline; filename="member-${id}"`);
  return streamFile(res, file, next);
});


export default router;
