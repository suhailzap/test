import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import { search } from '../services/search.js';
import { searchScopeText, canSearchPeople } from '../lib/search-scope.js';

const router = express.Router();

/**
 * Search is available to anyone signed in, but every source inside it applies
 * its own permission rules, so a member searching only ever finds what their
 * own screens would show them.
 */
router.get('/search', requireAuth, (req, res) => {
  const term = String(req.query.q || '').slice(0, 80);
  const perKind = 8;
  const results = search(req.user, term, { perKind });

  res.render('search/index', {
    title: term ? `Search: ${term}` : 'Search',
    results,
    perKind,
    term,
    scopeText: searchScopeText(req.user),
    canSearchPeople: canSearchPeople(req.user)
  });
});

export default router;
