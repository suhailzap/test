import { atomicRouter } from '../lib/atomic-router.js';
import { submitOnce } from '../lib/submit-guard.js';
import { parsePaging, serverPaged, pageSizeParam } from '../lib/paging.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { Validator } from '../lib/validate.js';
import { recordAudit } from '../lib/audit.js';
import { getSetting } from '../lib/settings.js';
import { today } from '../lib/dates.js';
import { monthGrid, agenda, EVENT_KINDS } from '../services/calendar.js';
import { scheduleStatus, getNextFridayService } from '../services/friday-service.js';
import {
  listAnnouncements, getAnnouncement, createAnnouncement, updateAnnouncement,
  setAnnouncementStatus, deleteAnnouncement, canViewAnnouncement, canManage,
  audienceUserIds, isLive, AUDIENCES, PRIORITIES, ANNOUNCEMENT_STATUSES,
  PRIORITY_LABELS, STATUS_LABELS
} from '../services/announcements.js';
import { notifyUsers } from '../services/reminders.js';

const router = atomicRouter();

// --- Calendar --------------------------------------------------------------

router.get('/calendar', requireAuth, requirePermission('calendar.view'), (req, res) => {
  const now = today();
  const view = ['month', 'list'].includes(req.query.view)
    ? req.query.view
    : (getSetting('calendar.default_view') === 'list' ? 'list' : 'month');

  const year = Math.min(Math.max(Number.parseInt(req.query.year, 10) || Number(now.slice(0, 4)), 1970), 2200);
  const month = Math.min(Math.max(Number.parseInt(req.query.month, 10) || Number(now.slice(5, 7)), 1), 12);

  const grid = monthGrid(req.user, { year, month });
  const schedule = scheduleStatus();

  res.render('calendar/index', {
    title: 'Calendar',
    view,
    grid,
    agenda: view === 'list' ? agenda(req.user, { from: now, days: 60 }) : [],
    kinds: EVENT_KINDS,
    schedule,
    nextService: getNextFridayService(now),
    canManageEvents: req.user.can('attendance.manage_sessions') || req.user.can('activities.manage')
  });
});

// --- Announcements ---------------------------------------------------------

function collectAnnouncementInput(body) {
  const v = new Validator(body);
  v.text('title', { required: true, max: 140, label: 'Title' });
  v.text('body', { required: true, max: 6000, label: 'Message' });
  v.oneOf('priority', PRIORITIES, { label: 'Priority', fallback: 'normal' });
  v.oneOf('audience', Object.keys(AUDIENCES), { label: 'Audience', fallback: 'all' });
  v.date('publish_at', { label: 'Publish from' });
  v.date('expires_at', { label: 'Expires' });
  return v;
}

router.get('/announcements', requireAuth, requirePermission('announcements.view'), (req, res) => {
  const status = ANNOUNCEMENT_STATUSES.includes(req.query.status) ? req.query.status : null;
  const search = String(req.query.q || '').slice(0, 60);
  const { result, paging } = serverPaged(
    ({ page, pageSize }) => listAnnouncements(req.user, { status, search, page, pageSize }),
    parsePaging(req.query)
  );

  res.render('announcements/index', {
    title: 'Announcements',
    result,
    paging,
    pagerParams: { status, q: search, page_size: pageSizeParam(paging) },
    filters: { status, search },
    canManage: canManage(req.user),
    statuses: ANNOUNCEMENT_STATUSES,
    statusLabels: STATUS_LABELS,
    priorityLabels: PRIORITY_LABELS,
    audiences: AUDIENCES,
    isLive
  });
});

router.get('/announcements/new', requireAuth, requirePermission('announcements.manage'), (req, res) => {
  res.render('announcements/form', {
    title: 'New announcement',
    mode: 'create',
    announcement: { priority: 'normal', audience: 'all', status: 'draft' },
    values: {},
    errors: {},
    priorities: PRIORITIES,
    priorityLabels: PRIORITY_LABELS,
    audiences: AUDIENCES
  });
});

router.post('/announcements', requireAuth, requirePermission('announcements.manage'), submitOnce(), (req, res) => {
  const v = collectAnnouncementInput(req.body);
  if (!v.valid) {
    return res.status(400).render('announcements/form', {
      title: 'New announcement',
      mode: 'create',
      announcement: req.body,
      values: req.body,
      errors: v.errors,
      priorities: PRIORITIES,
      priorityLabels: PRIORITY_LABELS,
      audiences: AUDIENCES
    });
  }

  const status = req.body.publish === 'yes' ? 'published' : 'draft';
  const announcement = createAnnouncement({ ...v.values, status }, { userId: req.user.id });

  recordAudit({
    req, action: 'announcement.created', entityType: 'announcement', entityId: announcement.id,
    detail: { title: announcement.title, status, audience: announcement.audience }
  });

  if (status === 'published' && isLive(announcement)) {
    notifyAudience(announcement, req.user.id);
  }

  req.flash('success', status === 'published' ? 'Announcement published.' : 'Announcement saved as a draft.');
  return res.redirect(`/announcements/${announcement.id}`);
});

router.get('/announcements/:id(\\d+)', requireAuth, requirePermission('announcements.view'), (req, res, next) => {
  const announcement = getAnnouncement(Number(req.params.id));
  if (!announcement) return next();
  if (!canViewAnnouncement(req.user, announcement)) {
    const err = new Error('This announcement is not available to you.');
    err.status = 403;
    return next(err);
  }

  return res.render('announcements/show', {
    title: announcement.title,
    announcement,
    canManage: canManage(req.user),
    statusLabels: STATUS_LABELS,
    priorityLabels: PRIORITY_LABELS,
    audiences: AUDIENCES,
    live: isLive(announcement)
  });
});

router.get('/announcements/:id(\\d+)/edit', requireAuth, requirePermission('announcements.manage'), (req, res, next) => {
  const announcement = getAnnouncement(Number(req.params.id));
  if (!announcement) return next();
  return res.render('announcements/form', {
    title: `Edit ${announcement.title}`,
    mode: 'edit',
    announcement,
    values: announcement,
    errors: {},
    priorities: PRIORITIES,
    priorityLabels: PRIORITY_LABELS,
    audiences: AUDIENCES
  });
});

router.post('/announcements/:id(\\d+)', requireAuth, requirePermission('announcements.manage'), (req, res, next) => {
  const announcement = getAnnouncement(Number(req.params.id));
  if (!announcement) return next();

  const v = collectAnnouncementInput(req.body);
  if (!v.valid) {
    return res.status(400).render('announcements/form', {
      title: `Edit ${announcement.title}`,
      mode: 'edit',
      announcement: { ...announcement, ...req.body },
      values: req.body,
      errors: v.errors,
      priorities: PRIORITIES,
      priorityLabels: PRIORITY_LABELS,
      audiences: AUDIENCES
    });
  }

  updateAnnouncement(announcement.id, v.values);
  recordAudit({ req, action: 'announcement.updated', entityType: 'announcement', entityId: announcement.id });
  req.flash('success', 'Announcement updated.');
  return res.redirect(`/announcements/${announcement.id}`);
});

router.post('/announcements/:id(\\d+)/status', requireAuth, requirePermission('announcements.manage'),
  (req, res, next) => {
    const announcement = getAnnouncement(Number(req.params.id));
    if (!announcement) return next();

    const v = new Validator(req.body);
    const status = v.oneOf('status', ANNOUNCEMENT_STATUSES, { required: true, label: 'Status' });
    if (!v.valid) {
      req.flash('error', 'Choose a valid status.');
      return res.redirect(`/announcements/${announcement.id}`);
    }

    const updated = setAnnouncementStatus(announcement.id, status);
    recordAudit({
      req, action: 'announcement.status_changed', entityType: 'announcement', entityId: announcement.id,
      detail: { from: announcement.status, to: status }
    });

    // Notify only when it becomes live, and only the first time.
    if (status === 'published' && announcement.status !== 'published' && isLive(updated)) {
      notifyAudience(updated, req.user.id);
    }

    req.flash('success', `Announcement ${STATUS_LABELS[status].toLowerCase()}.`);
    return res.redirect(`/announcements/${announcement.id}`);
  });

router.post('/announcements/:id(\\d+)/delete', requireAuth, requirePermission('announcements.manage'),
  (req, res, next) => {
    const announcement = getAnnouncement(Number(req.params.id));
    if (!announcement) return next();

    deleteAnnouncement(announcement.id);
    recordAudit({
      req, action: 'announcement.deleted', entityType: 'announcement', entityId: announcement.id,
      detail: { title: announcement.title }
    });
    req.flash('success', 'Announcement removed.');
    return res.redirect('/announcements');
  });

/** Sends an internal notification to the audience, never to anyone outside it. */
function notifyAudience(announcement, actorId) {
  const recipients = audienceUserIds(announcement.audience).filter((id) => id !== actorId);
  if (recipients.length === 0) return 0;
  return notifyUsers(recipients, {
    title: announcement.priority === 'high'
      ? `Important: ${announcement.title}`
      : announcement.title,
    body: announcement.body.length > 160 ? `${announcement.body.slice(0, 160)}…` : announcement.body,
    link: `/announcements/${announcement.id}`,
    category: 'announcement'
  });
}

export default router;
