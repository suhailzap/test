import { query, queryOne, execute } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { today, nowIso, addDays } from '../lib/dates.js';
import { DEFAULT_ROSTER_STATUSES, CURRENT_POPULATION_STATUSES } from './members.js';
import { classifySession } from './attendance-tracking.js';
import { trustedDob, dobNotice } from './dob-quality.js';
import { buildFridayContexts, memberOutcomeAt } from './attendance-outcomes.js';

const ROSTER_STATUS_SQL = DEFAULT_ROSTER_STATUSES.map((s) => `'${s}'`).join(',');
const CURRENT_POPULATION_SQL = CURRENT_POPULATION_STATUSES.map((s) => `'${s}'`).join(',');

/**
 * CCIQ gathers as one church on a Friday but meets in three congregations.
 * A member's congregation follows their age, using boundaries the church sets,
 * and can be overridden where a birth date is unknown or the church decides
 * otherwise. Nothing here is fixed in code.
 */
export const AGE_GROUPS = ['child', 'teen', 'adult'];

export const AGE_GROUP_LABELS = {
  child: 'Kids Church',
  teen: 'Teens Church',
  adult: 'Adults'
};

export function ageOn(dateOfBirth, asOf = today()) {
  if (!dateOfBirth) return null;
  const born = new Date(`${dateOfBirth}T00:00:00Z`);
  const at = new Date(`${asOf}T00:00:00Z`);
  if (Number.isNaN(born.getTime()) || Number.isNaN(at.getTime())) return null;
  let age = at.getUTCFullYear() - born.getUTCFullYear();
  const monthDiff = at.getUTCMonth() - born.getUTCMonth();
  if (monthDiff < 0 || (monthDiff === 0 && at.getUTCDate() < born.getUTCDate())) age -= 1;
  return age >= 0 ? age : null;
}

export function boundaries() {
  return {
    childMax: Number(getSetting('congregation.child_max_age')) || 12,
    teenMax: Number(getSetting('congregation.teen_max_age')) || 17
  };
}

export function groupForAge(age) {
  if (age === null || age === undefined) return null;
  const { childMax, teenMax } = boundaries();
  if (age <= childMax) return 'child';
  if (age <= teenMax) return 'teen';
  return 'adult';
}

/**
 * The congregation a member belongs to. An explicit setting always wins; a
 * birth date decides otherwise; with neither, nothing is assumed.
 */
export function congregationFor(member, asOf = today()) {
  if (!member) return null;
  if (member.age_group && AGE_GROUPS.includes(member.age_group)) return member.age_group;
  // Only a date of birth that can be trusted decides a congregation (see dob-quality.js); one that needs verification decides nothing.
  return groupForAge(ageOn(trustedDob(member), asOf));
}

export function describeCongregation(member, asOf = today()) {
  const group = congregationFor(member, asOf);
  if (!group) return { group: null, label: 'Not set', age: null, derived: false, dobNotice: member.date_of_birth ? dobNotice(member.id) : null };
  const age = ageOn(trustedDob(member), asOf);
  return {
    group,
    label: AGE_GROUP_LABELS[group],
    age,
    derived: !member.age_group && age !== null
  };
}

export function setAgeGroup(memberId, group, { userId = null } = {}) {
  const value = AGE_GROUPS.includes(group) ? group : null;
  execute(
    'UPDATE members SET age_group = @group, updated_at = @at, updated_by = @by WHERE id = @id',
    { id: memberId, group: value, at: nowIso(), by: userId }
  );
  return value;
}

export function setGuardian(memberId, guardianId, { userId = null } = {}) {
  execute(
    'UPDATE members SET guardian_member_id = @guardian, updated_at = @at, updated_by = @by WHERE id = @id',
    { id: memberId, guardian: guardianId || null, at: nowIso(), by: userId }
  );
}

/**
 * Members this member is the recorded guardian for — the reverse side of
 * their guardian_member_id link. Named "dependants" for the existing "Parent
 * or guardian who brings them" relationship specifically; a guardian is
 * never assumed to be a parent (see childrenOf() below for the biological/
 * explicit father-or-mother side, which is a separate concept and never
 * combined with this one).
 */
export function dependantsOf(memberId) {
  return query(
    `SELECT * FROM members WHERE guardian_member_id = @id AND status != 'archived'
      ORDER BY date_of_birth DESC, last_name COLLATE NOCASE`,
    { id: memberId }
  );
}

export function guardianOf(memberId) {
  const row = queryOne('SELECT guardian_member_id FROM members WHERE id = @id', { id: memberId });
  if (!row || !row.guardian_member_id) return null;
  return queryOne('SELECT * FROM members WHERE id = @id', { id: row.guardian_member_id }) || null;
}

/**
 * Members whose father_member_id or mother_member_id explicitly points to
 * this member — the reverse side of an administrator explicitly linking a
 * child to a parent. Never inferred from surname, address, cell group or
 * any other proxy — only the explicit link the admin selected. Kept
 * completely separate from dependantsOf() above: a guardian relationship
 * never implies a parent one, or vice versa.
 */
export function childrenOf(memberId) {
  return query(
    `SELECT * FROM members
      WHERE (father_member_id = @id OR mother_member_id = @id) AND status != 'archived'
      ORDER BY date_of_birth DESC, last_name COLLATE NOCASE`,
    { id: memberId }
  );
}

/**
 * How many members sit in each congregation, for dashboards and reports.
 * Defaults to everyone currently with CCIQ (CURRENT_POPULATION_STATUSES),
 * not lifecycle status 'active' alone — a congregation breakdown is meant to
 * describe the church's current age-group makeup, not just its most
 * strictly-classified members.
 */
export function congregationCounts({ statuses = CURRENT_POPULATION_STATUSES } = {}) {
  const rows = query(
    `SELECT id, date_of_birth, age_group FROM members
      WHERE status IN (${statuses.map((_, i) => `@s${i}`).join(',')})`,
    Object.fromEntries(statuses.map((s, i) => [`s${i}`, s]))
  );

  const counts = { child: 0, teen: 0, adult: 0, unknown: 0, total: rows.length };
  for (const row of rows) {
    const group = congregationFor(row);
    if (group) counts[group] += 1; else counts.unknown += 1;
  }
  return counts;
}

/**
 * Attendance at one Friday service, split by congregation.
 *
 * For a TRACKED Friday the split is of the EXPECTED roster (the stored
 * snapshot once finalized) using the canonical outcomes, so a later status
 * change never rewrites it: `total` is who was expected, `present` /
 * `excused` / `absent` follow the outcome resolver (absent includes derived
 * absence once finalized), `notRecorded` is expected members not yet
 * decided (open or awaiting finalization), and `unexpected` counts people who
 * attended without being expected (headcount only, never in the rate).
 * `rate` = present / (total - excused), and only for a FINALIZED Friday;
 * otherwise null. Before Go-Live only recorded rows are counted, with no
 * not-recorded figure and no rate.
 *
 * A member's congregation follows their CURRENT date of birth / age group -
 * the snapshot does not store it - so the split by congregation is not
 * historically fixed; the church-wide expected roster is.
 */
export function attendanceByCongregation(sessionId) {
  const blank = () => ({
    present: 0, absent: 0, excused: 0, visitor: 0, notRecorded: 0, unexpected: 0, total: 0,
    numerator: 0, denominator: 0, rate: null
  });
  const result = { child: blank(), teen: blank(), adult: blank(), unknown: blank() };

  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  const classification = session ? classifySession(session) : null;
  const people = new Map(query('SELECT id, date_of_birth, age_group, status FROM members').map((m) => [m.id, m]));
  const groupOf = (memberId) => {
    const m = people.get(memberId);
    return m ? (congregationFor(m) || 'unknown') : 'unknown';
  };

  if (classification && classification.tracked && !['cancelled', 'not_taken'].includes(classification.phase)) {
    const [ctx] = buildFridayContexts({ from: session.service_date, to: session.service_date }).filter((c) => c.id === session.id);
    for (const memberId of ctx.roster ? ctx.roster.keys() : []) {
      const bucket = result[groupOf(memberId)];
      const r = memberOutcomeAt(ctx, memberId);
      bucket.total += 1;
      if (r.state === 'present') bucket.present += 1;
      else if (r.state === 'vacation') bucket.excused += 1;
      else if (r.state === 'absent') bucket.absent += 1;
      else bucket.notRecorded += 1;
      if (ctx.phase === 'finalized') {
        if (r.rateNumerator) bucket.numerator += 1;
        if (r.rateDenominator) bucket.denominator += 1;
      }
    }
    for (const [memberId, status] of ctx.rows) {
      if (ctx.roster && ctx.roster.has(memberId)) continue;
      if (status === 'present' || status === 'visitor') result[groupOf(memberId)].unexpected += 1;
    }
    if (ctx.phase === 'finalized') {
      for (const bucket of Object.values(result)) {
        bucket.rate = bucket.denominator > 0 ? Math.round((bucket.numerator / bucket.denominator) * 100) : null;
      }
    }
    return result;
  }

  // Not tracked (or not taken / cancelled): what was recorded, nothing inferred.
  const rows = query(
    `SELECT r.member_id, r.status FROM attendance_records r WHERE r.session_id = @sessionId`,
    { sessionId }
  );
  for (const row of rows) {
    const bucket = result[groupOf(row.member_id)];
    bucket.total += 1;
    if (row.status === 'present' || row.status === 'visitor') bucket.present += 1;
    else if (row.status === 'excused') bucket.excused += 1;
    else if (row.status === 'absent') bucket.absent += 1;
  }
  return result;
}

/**
 * Members whose congregation no longer matches their age. A child turning 13
 * moves to Teens Church automatically, because the congregation follows the
 * birth date. A member whose congregation was set by hand does not move on
 * their own, so those are listed here for someone to confirm.
 */
export function reviewCongregations({ asOf = today() } = {}) {
  const rows = query(
    `SELECT id, member_code, first_name, middle_name, last_name, preferred_name,
            date_of_birth, age_group, status
       FROM members
      WHERE status IN ('active', 'pending')
        AND date_of_birth IS NOT NULL
        AND age_group IS NOT NULL`
  );

  const moves = [];
  for (const member of rows) {
    const trusted = trustedDob(member);
    const byAge = groupForAge(ageOn(trusted, asOf));
    if (byAge && byAge !== member.age_group) {
      moves.push({
        member,
        age: ageOn(trusted, asOf),
        current: member.age_group,
        currentLabel: AGE_GROUP_LABELS[member.age_group],
        suggested: byAge,
        suggestedLabel: AGE_GROUP_LABELS[byAge]
      });
    }
  }

  // Those about to cross a boundary, so a move is never a surprise.
  const { childMax, teenMax } = boundaries();
  const upcoming = query(
    `SELECT id, member_code, first_name, last_name, preferred_name, date_of_birth, age_group
       FROM members
      WHERE status IN ('active', 'pending') AND date_of_birth IS NOT NULL`
  ).map((member) => {
    const trusted = trustedDob(member);
    const age = ageOn(trusted, asOf);
    const inNinety = ageOn(trusted, addDays(asOf, 90));
    if (age === null || inNinety === null || inNinety === age) return null;
    const from = groupForAge(age);
    const to = groupForAge(inNinety);
    if (from === to) return null;
    return {
      member,
      age,
      turning: inNinety,
      fromLabel: AGE_GROUP_LABELS[from],
      toLabel: AGE_GROUP_LABELS[to],
      on: `${asOf.slice(0, 4)}-${member.date_of_birth.slice(5)}`
    };
  }).filter(Boolean);

  return { moves, upcoming, boundaries: { childMax, teenMax } };
}

/** Clears a hand-set congregation so the member follows their age again. */
export function followAgeAgain(memberId, { userId = null } = {}) {
  return setAgeGroup(memberId, null, { userId });
}
