import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso, today, formatDate } from '../lib/dates.js';
import { csvCell } from '../lib/csv.js';

export const PRIVACY_MODES = ['full_name', 'first_name', 'claimed', 'private'];
export const PRIVACY_LABELS = {
  full_name: 'Full name',
  first_name: 'First name only',
  claimed: 'Claimed (no name)',
  private: 'Private (visible only to administrators)'
};

/** Every Giving Board date (slot) is a fixed commitment of QAR 300. New campaigns, the seeded 2025 board and a claim with no stated amount all start from this. */
export const GIVING_BOARD_SLOT_AMOUNT = 300;

export const PAYMENT_STATUSES = ['not_paid', 'partially_paid', 'paid', 'waived', 'pending_verification'];
export const PAYMENT_LABELS = {
  not_paid: 'Not paid',
  partially_paid: 'Partially paid',
  paid: 'Paid',
  waived: 'Waived',
  pending_verification: 'Pending verification'
};

export const CAMPAIGN_STATUSES = ['draft', 'active', 'closed', 'archived'];

/**
 * What a campaign actually is. The status (draft/active/closed/archived) is
 * a separate question from this — a Giving Board and a Faith Promise can
 * both be active at once, in different years, each with its own status.
 */
export const CAMPAIGN_TYPES = ['giving_board', 'faith_promise', 'custom'];
export const CAMPAIGN_TYPE_LABELS = {
  giving_board: 'Giving Board',
  faith_promise: 'Faith Promise',
  custom: 'Custom campaign'
};
export const CLAIM_STATUSES = ['active', 'released', 'cancelled'];

/**
 * The factual record of the project, taken from ECAQ's own published
 * information. Nothing here is inferred, and everything a church might want to
 * add later is an administrator-managed project update instead.
 */
export const PROJECT_FACTS = {
  organisation: 'Evangelical Churches Alliance Qatar (ECAQ)',
  buildingName: 'ECAQ Worship Centre',
  alsoKnownAs: 'The House of the Lord',
  mandate: 'ECAQ\u2019s mandate includes constructing the ECAQ Worship Centre.',
  milestones: [
    { date: '2023-11', label: 'Replacement plot of 18,720 sqm awarded', source: 'ECAQ project update' },
    { date: '2025-01-24', label: 'Project groundbreaking', source: 'ECAQ project update' }
  ]
};

export function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

export function daysInYear(year) {
  return isLeapYear(year) ? 366 : 365;
}

// --- Campaigns -------------------------------------------------------------

export function listCampaigns() {
  return query(
    `SELECT c.*,
            (SELECT COUNT(*) FROM ecaq_giving_board_claims k
              WHERE k.campaign_id = c.id AND k.status = 'active') AS claimed_count
       FROM ecaq_campaigns c
      ORDER BY c.year DESC, c.name`
  );
}

export function getCampaign(id) {
  return queryOne('SELECT * FROM ecaq_campaigns WHERE id = @id', { id }) || null;
}

export function getCampaignByYear(year) {
  return queryOne('SELECT * FROM ecaq_campaigns WHERE year = @year ORDER BY id LIMIT 1', { year }) || null;
}

/** The campaign the board shows by default: the active one, else the newest. */
/**
 * The board to open by default. With several years running at once, the one
 * the church is actually in is the useful one, so the current year wins if it
 * has a board; otherwise the most recent open year.
 */
/**
 * The board to open by default.
 *
 * This is deliberately not "the calendar year we happen to be in" — a church
 * still filling in 2025 does not want to land on 2026 just because the date
 * on the wall says so. The earliest open year that still has a day left to
 * take is where the church's attention actually is; only once every day up
 * to it has been claimed does the default move on to the next year.
 */
/**
 * The board shown when nobody has asked for a specific year. With several
 * years open at once, "the earliest one with room" is not what a person
 * means by that — in practice they mean the year the church is actually in
 * right now, so that is checked first. Only when the current year has no
 * board at all does this fall back to the earliest open year with room, and
 * finally to the most recent campaign of any status, so there is always
 * something to show.
 */
export function currentCampaign() {
  const open = query(
    `SELECT * FROM ecaq_campaigns WHERE status = 'active' AND type = 'giving_board' ORDER BY year ASC`
  );

  const thisYear = Number(today().slice(0, 4));
  const forThisYear = open.find((c) => c.year === thisYear);
  if (forThisYear) return forThisYear;

  for (const campaign of open) {
    const progress = campaignProgress(campaign);
    if (progress.claimed < progress.totalDates) return campaign;
  }

  // Every open board is fully claimed, or none is open yet: fall back to the
  // most recent Giving Board campaign of any status, so there is still
  // something to show — never a campaign of a different type, which would
  // have none of the fields this page needs.
  if (open.length > 0) return open[open.length - 1];
  return queryOne(
    `SELECT * FROM ecaq_campaigns WHERE type = 'giving_board' ORDER BY year DESC, id DESC LIMIT 1`
  ) || null;
}

export function createCampaign(data) {
  const at = nowIso();
  const year = Number(data.year);
  const type = CAMPAIGN_TYPES.includes(data.type) ? data.type : 'giving_board';
  const result = execute(
    `INSERT INTO ecaq_campaigns
       (name, year, type, description, target_amount, amount_per_date, currency, background_image,
        privacy_mode, status, start_date, end_date, created_at, updated_at)
     VALUES (@name, @year, @type, @description, @target_amount, @amount_per_date, @currency, @background_image,
             @privacy_mode, @status, @start_date, @end_date, @at, @at)`,
    {
      name: data.name,
      year,
      type,
      description: data.description ?? null,
      target_amount: data.target_amount ?? null,
      // A Giving Board date is a fixed QAR 300 commitment unless a campaign is created with another amount on purpose.
      amount_per_date: data.amount_per_date ?? (type === 'giving_board' ? GIVING_BOARD_SLOT_AMOUNT : null),
      currency: data.currency || 'QAR',
      // A Giving Board needs a background picture to reveal; other campaign
      // types simply never reference this field.
      background_image: type === 'giving_board' ? (data.background_image || null) : null,
      privacy_mode: PRIVACY_MODES.includes(data.privacy_mode) ? data.privacy_mode : 'first_name',
      status: CAMPAIGN_STATUSES.includes(data.status) ? data.status : 'draft',
      start_date: data.start_date || `${year}-01-01`,
      end_date: data.end_date || `${year}-12-31`,
      at
    }
  );
  return getCampaign(Number(result.lastInsertRowid));
}

/**
 * Sets or clears the picture behind a board year. Kept separate from the main
 * campaign edit form, exactly as a group or ministry photo is: the picture
 * changes on its own, without touching the amount, the privacy setting, or
 * anything else about the campaign.
 */
export function setCampaignBackground(id, url) {
  execute(
    'UPDATE ecaq_campaigns SET background_image = @url, updated_at = @at WHERE id = @id',
    { id, url, at: nowIso() }
  );
  return getCampaign(id);
}

export const DEFAULT_BOARD_BACKGROUND = null;

export function updateCampaign(id, data) {
  execute(
    `UPDATE ecaq_campaigns SET
       name = @name, description = @description, target_amount = @target_amount,
       amount_per_date = @amount_per_date, currency = @currency, background_image = @background_image,
       privacy_mode = @privacy_mode, status = @status, start_date = @start_date, end_date = @end_date,
       updated_at = @at
     WHERE id = @id`,
    {
      id,
      name: data.name,
      description: data.description ?? null,
      target_amount: data.target_amount ?? null,
      amount_per_date: data.amount_per_date ?? null,
      currency: data.currency || 'QAR',
      background_image: data.background_image || null,
      privacy_mode: PRIVACY_MODES.includes(data.privacy_mode) ? data.privacy_mode : 'first_name',
      status: CAMPAIGN_STATUSES.includes(data.status) ? data.status : 'draft',
      start_date: data.start_date || null,
      end_date: data.end_date || null,
      at: nowIso()
    }
  );
  return getCampaign(id);
}

// --- The board -------------------------------------------------------------

function pad(n) {
  return String(n).padStart(2, '0');
}

/** Every date of the campaign year: 365 stubs, or 366 in a leap year. */
export function boardDates(year) {
  const dates = [];
  for (let month = 1; month <= 12; month += 1) {
    const last = new Date(Date.UTC(year, month, 0)).getUTCDate();
    for (let day = 1; day <= last; day += 1) {
      dates.push(`${year}-${pad(month)}-${pad(day)}`);
    }
  }
  return dates;
}

/**
 * THE DATES A GIVING BOARD COVERS. A board is a wall of the days of its own calendar year (campaign.year); the campaign's own start and end dates say which of those days are
 * actually part of it. A campaign that runs the whole year (the default, and every board so far) has every day; one that runs 15 Mar to 15 Sep has only those; a campaign whose dates
 * run past the year is clipped to that year (a board is one calendar year's wall, so the days beyond it are not part of this board, and nothing outside the campaign's dates is ever
 * offered, counted or reported). Dates that are missing or contradictory fall back to the whole year rather than to nothing.
 */
const isIsoDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value || ''));
export function campaignWindow(campaign) {
  const yearStart = `${campaign.year}-01-01`;
  const yearEnd = `${campaign.year}-12-31`;
  let from = isIsoDate(campaign.start_date) ? campaign.start_date : yearStart;
  let to = isIsoDate(campaign.end_date) ? campaign.end_date : yearEnd;
  if (from > to) { from = yearStart; to = yearEnd; }
  from = from < yearStart ? yearStart : from;
  to = to > yearEnd ? yearEnd : to;
  if (from > to) return { from: yearStart, to: yearEnd, whole: true };
  return { from, to, whole: from === yearStart && to === yearEnd };
}

/** The dates of this board: the days of its year that fall inside the campaign's own dates. */
export function campaignDates(campaign) {
  const { from, to } = campaignWindow(campaign);
  return boardDates(campaign.year).filter((date) => date >= from && date <= to);
}

export const campaignDayCount = (campaign) => campaignDates(campaign).length;

/** True when a date is one of this board's dates. */
export const dateInCampaign = (campaign, date) => {
  if (!isIsoDate(date) || !date.startsWith(`${campaign.year}-`)) return false;
  if (new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) !== date) return false; // 30 Feb and the like are not days
  const { from, to } = campaignWindow(campaign);
  return date >= from && date <= to;
};

export function claimsForCampaign(campaignId) {
  return query(
    `SELECT k.*, m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
      WHERE k.campaign_id = @id
      ORDER BY k.claim_date`,
    { id: campaignId }
  );
}

/**
 * How a claimant is shown on the public board, following the campaign's
 * privacy setting. Administrators managing the board always see the name; the
 * board itself never reveals more than the setting allows.
 */
export function displayClaimant(claim, privacyMode, { forAdmin = false, forOwner = false } = {}) {
  if (!claim) return null;
  const full = [claim.preferred_name || claim.first_name, claim.last_name].filter(Boolean).join(' ');

  // Administrators always see the member behind a claim, whatever is displayed.
  if (forAdmin) return full || 'Unknown member';
  if (forOwner) return 'Your commitment';

  /*
   * Some members would rather appear as initials, a family name, or something
   * else entirely. Where they have chosen a label it is used, so long as the
   * campaign is showing names at all.
   */
  const chosen = (claim.display_as || '').trim();
  if (privacyMode === 'claimed' || privacyMode === 'private') return 'Claimed';
  if (chosen) return chosen;
  if (privacyMode === 'full_name') return full || 'Claimed';
  if (privacyMode === 'first_name') return claim.preferred_name || claim.first_name || 'Claimed';
  return 'Claimed';
}

/** The label a member has chosen for a date, if any. */
export function setClaimDisplayName(claimId, displayAs) {
  const value = String(displayAs || '').trim().slice(0, 60) || null;
  execute('UPDATE ecaq_giving_board_claims SET display_as = @value, updated_at = @at WHERE id = @id',
    { id: claimId, value, at: nowIso() });
  return getClaim(claimId);
}

/**
 * The board as months of dates, each stub carrying only what the viewer is
 * allowed to know. A claimed stub is "revealed": the artwork behind it shows
 * through, and it stays that way because the claim is in the database.
 */
/**
 * The board as the church knows it physically: one continuous run of paper
 * stubs for every day of the year, pinned over a picture of the worship centre.
 *
 * The stubs are returned in date order with no month grouping, because the
 * board is a wall of slips rather than a calendar. Each stub carries the
 * position it occupies, so the picture behind it lines up: when a stub is
 * claimed it is simply not drawn, and that part of the building shows through.
 */
export function buildBoard(campaign, { viewerMemberId = null, forAdmin = false } = {}) {
  const claims = new Map(claimsForCampaign(campaign.id)
    .filter((c) => c.status === 'active')
    .map((c) => [c.claim_date, c]));

  const monthNames = [];
  for (let m = 0; m < 12; m += 1) {
    monthNames.push(new Intl.DateTimeFormat('en-GB', { month: 'short', timeZone: 'UTC' })
      .format(new Date(Date.UTC(campaign.year, m, 1))).toUpperCase().replace('.', ''));
  }

  const stubs = [];
  const months = [];
  const window = campaignWindow(campaign);

  for (let month = 1; month <= 12; month += 1) {
    const last = new Date(Date.UTC(campaign.year, month, 0)).getUTCDate();
    const monthStubs = [];

    for (let day = 1; day <= last; day += 1) {
      const date = `${campaign.year}-${pad(month)}-${pad(day)}`;
      if (date < window.from || date > window.to) continue; // a day outside the campaign's own dates is not on this board
      const claim = claims.get(date) || null;
      const isOwn = Boolean(claim && viewerMemberId && Number(claim.member_id) === Number(viewerMemberId));

      /*
       * A slip only comes off the board when the day has actually been paid.
       * Taking a day covers it in a promise; the building shows through when
       * the promise is kept. A part payment keeps the slip on the wall and
       * marks it, so the picture never overstates what the church has received.
       */
      const collected = claim ? Number(claim.amount_collected) || 0 : 0;
      const commitment = claim
        ? Number(claim.commitment_amount) || Number(campaign.amount_per_date) || 0
        : Number(campaign.amount_per_date) || 0;
      const settled = Boolean(claim) && ['paid', 'waived'].includes(claim.payment_status);
      const partial = Boolean(claim) && !settled && collected > 0;

      const stub = {
        date,
        day,
        month,
        // "JAN" and "2025", as printed on the paper slips.
        monthLabel: monthNames[month - 1],
        year: campaign.year,
        claimed: Boolean(claim),
        // Only a settled day is taken off the wall.
        revealed: settled,
        partial,
        awaitingPayment: Boolean(claim) && !settled && collected === 0,
        paymentStatus: claim ? claim.payment_status : null,
        collected,
        commitment,
        paidPercent: commitment > 0 ? Math.min(Math.round((collected / commitment) * 100), 100) : 0,
        isOwn,
        claimId: claim ? claim.id : null,
        claimedAt: claim ? claim.claimed_at : null,
        // What an administrator sees on a claimed date. Received, balance and status come from the claim, which is recalculated from the payment ledger
        // (recalculateClaim) - never typed. Only built for an administrator; a member's board never carries it.
        adminDetail: forAdmin && claim ? {
          memberName: [claim.preferred_name || claim.first_name, claim.last_name].filter(Boolean).join(' ') || 'Unknown member',
          memberCode: claim.member_code || '',
          received: collected,
          balance: claim.payment_status === 'waived' ? 0 : Math.max(commitment - collected, 0),
          statusLabel: PAYMENT_LABELS[claim.payment_status] || claim.payment_status
        } : null,
        label: claim
          ? (campaign.privacy_mode === 'private' && !forAdmin && !isOwn
            ? 'Claimed'
            : displayClaimant(claim, campaign.privacy_mode, { forAdmin, forOwner: isOwn }))
          : null
      };

      stubs.push(stub);
      monthStubs.push(stub);
    }

    if (monthStubs.length === 0) continue;
    months.push({
      month,
      name: new Intl.DateTimeFormat('en-GB', { month: 'long', timeZone: 'UTC' })
        .format(new Date(Date.UTC(campaign.year, month - 1, 1))),
      stubs: monthStubs
    });
  }

  const claimed = stubs.filter((s) => s.claimed).length;
  const revealed = stubs.filter((s) => s.revealed).length;
  const partial = stubs.filter((s) => s.partial).length;

  return {
    stubs,
    months,
    total: stubs.length,
    claimed,
    revealed,
    partial,
    awaitingPayment: stubs.filter((s) => s.awaitingPayment).length,
    remaining: stubs.length - claimed,
    // The picture uncovers as days are settled, not as they are promised.
    revealedPercent: stubs.length ? Math.round((revealed / stubs.length) * 100) : 0,
    claimedPercent: stubs.length ? Math.round((claimed / stubs.length) * 100) : 0
  };
}

export function campaignProgress(campaign) {
  const totals = queryOne(
    `SELECT COUNT(*) AS claimed,
            COALESCE(SUM(commitment_amount), 0) AS committed,
            COALESCE(SUM(amount_collected), 0) AS collected
       FROM ecaq_giving_board_claims
      WHERE campaign_id = @id AND status = 'active'`,
    { id: campaign.id }
  );

  const byPayment = Object.fromEntries(
    query(
      `SELECT payment_status, COUNT(*) AS n
         FROM ecaq_giving_board_claims
        WHERE campaign_id = @id AND status = 'active'
        GROUP BY payment_status`,
      { id: campaign.id }
    ).map((r) => [r.payment_status, r.n])
  );

  const total = campaignDayCount(campaign); // the days of THIS campaign, not always 365
  const claimed = totals.claimed || 0;
  // What is still to collect: every active, not-waived commitment with a balance, from the ledger-derived received amount.
  const owed = queryOne(
    `SELECT COUNT(*) AS n,
            COALESCE(SUM(COALESCE(commitment_amount, 0) - amount_collected), 0) AS amount
       FROM ecaq_giving_board_claims
      WHERE campaign_id = @id AND status = 'active' AND payment_status NOT IN ('paid', 'waived')
        AND COALESCE(commitment_amount, 0) - amount_collected > 0`,
    { id: campaign.id }
  );

  return {
    totalDates: total,
    claimed,
    available: total - claimed,
    percentClaimed: total ? Math.round((claimed / total) * 100) : 0,
    committed: totals.committed || 0,
    collected: totals.collected || 0,
    outstandingCount: owed.n || 0,
    outstandingAmount: Math.round((owed.amount || 0) * 100) / 100,
    target: campaign.target_amount,
    percentCollected: campaign.target_amount
      ? Math.round(((totals.collected || 0) / campaign.target_amount) * 100)
      : null,
    byPayment,
    participants: queryOne(
      `SELECT COUNT(DISTINCT member_id) AS n FROM ecaq_giving_board_claims
        WHERE campaign_id = @id AND status = 'active'`,
      { id: campaign.id }
    ).n
  };
}

// --- Claims ----------------------------------------------------------------

export function getClaim(id) {
  return queryOne(
    `SELECT k.*, m.first_name, m.last_name, m.preferred_name, m.member_code,
            c.name AS campaign_name, c.year, c.currency, c.privacy_mode,
            cu.display_name AS recorded_by_name, cu.member_id AS recorded_by_member_id
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
       JOIN ecaq_campaigns c ON c.id = k.campaign_id
       LEFT JOIN users cu ON cu.id = k.created_by
      WHERE k.id = @id`,
    { id }
  ) || null;
}

export function claimForDate(campaignId, date) {
  return queryOne(
    `SELECT * FROM ecaq_giving_board_claims
      WHERE campaign_id = @campaignId AND claim_date = @date`,
    { campaignId, date }
  ) || null;
}

/** A member may take as many dates as they wish; this counts them. */
export function memberClaimCount(memberId, campaignId) {
  return queryOne(
    `SELECT COUNT(*) AS n FROM ecaq_giving_board_claims
      WHERE member_id = @memberId AND campaign_id = @campaignId AND status = 'active'`,
    { memberId, campaignId }
  ).n;
}

export function claimsForMember(memberId, { campaignId = null } = {}) {
  return query(
    `SELECT k.*, c.name AS campaign_name, c.year, c.currency
       FROM ecaq_giving_board_claims k
       JOIN ecaq_campaigns c ON c.id = k.campaign_id
      WHERE k.member_id = @memberId
        AND (@campaignId IS NULL OR k.campaign_id = @campaignId)
      ORDER BY k.claim_date`,
    { memberId, campaignId }
  );
}

/**
 * Records a commitment against a date. The unique index on
 * (campaign_id, claim_date) is what actually prevents two members claiming the
 * same date, so a race between two people ends with one clear failure rather
 * than a duplicate.
 */
export function createClaim({ campaignId, date, memberId, commitmentAmount = null, notes = null, displayAs = null, userId = null }) {
  const at = nowIso();
  const campaign = getCampaign(campaignId);
  if (!campaign) return { ok: false, reason: 'no_campaign' };
  if (campaign.status !== 'active') return { ok: false, reason: 'campaign_not_active' };
  if (!dateInCampaign(campaign, date)) return { ok: false, reason: 'date_not_in_campaign' };

  try {
    const claimId = transaction(() => {
      const result = execute(
        `INSERT INTO ecaq_giving_board_claims
           (campaign_id, claim_date, year, member_id, claimed_at, commitment_amount, amount_collected,
            payment_status, status, notes, created_at, updated_at, created_by)
         VALUES (@campaignId, @date, @year, @memberId, @at, @commitment, 0,
                 'not_paid', 'active', @notes, @at, @at, @by)`,
        {
          campaignId,
          date,
          year: campaign.year,
          memberId,
          at,
          commitment: commitmentAmount ?? campaign.amount_per_date ?? GIVING_BOARD_SLOT_AMOUNT,
          notes,
          by: userId
        }
      );
      const id = Number(result.lastInsertRowid);
      if (displayAs) setClaimDisplayName(id, displayAs);
      return id;
    })();
    return { ok: true, claim: getClaim(claimId) };
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) return { ok: false, reason: 'already_claimed' };
    throw err;
  }
}

/**
 * Administrative correction: financial fields are separate from the claim. What was RECEIVED is never typed here: it is the sum of the
 * payment ledger (recalculateClaim, in the same transaction), so a typed figure can neither overwrite nor contradict the payments.
 */
export function updateClaimFinance(id, { commitmentAmount, paymentStatus, notes, userId = null }) {
  // The payment status follows the payment ledger (recalculateClaim below). It is only ever passed through for the two administrative decisions that the
  // ledger does not decide (waived, pending verification), and never set to "paid" or "partly paid" by hand.
  const current = getClaim(id);
  const keepStatus = current ? current.payment_status : 'not_paid';
  execute(
    `UPDATE ecaq_giving_board_claims SET
       commitment_amount = @commitment,
       payment_status = @paymentStatus,
       notes = @notes,
       updated_at = @at,
       updated_by = @by
     WHERE id = @id`,
    {
      id,
      commitment: commitmentAmount ?? null,
      paymentStatus: PAYMENT_STATUSES.includes(paymentStatus) ? paymentStatus : keepStatus,
      notes: notes ?? null,
      at: nowIso(),
      by: userId
    }
  );
  recalculateClaim(id);
  return getClaim(id);
}

/**
 * Releasing a date frees it for someone else; the audit row keeps who held it and why it was released.
 * A claim that has payments recorded is refused: deleting the claim row would delete its payment ledger with it
 * (payments cascade), and releasing a date is a board action that does not need finance permission. The payments
 * are removed, deliberately and one by one, from the claim's payments page first.
 */
export function releaseClaim(id, { userId = null, reason = null } = {}) {
  const claim = getClaim(id);
  if (!claim) return null;
  return transaction(() => {
    const payments = queryOne('SELECT COUNT(*) AS n FROM ecaq_payments WHERE claim_id = @id', { id }).n;
    if (payments > 0) return { refused: 'has_payments', payments, released: null, reason, by: userId };
    execute('DELETE FROM ecaq_giving_board_claims WHERE id = @id', { id });
    return { released: claim, reason, by: userId };
  })();
}

export const CLAIM_SORT_COLUMNS = ['date', 'member', 'claimed'];

export function listClaims({
  campaignId, search = '', paymentStatus = null, page = 1, pageSize = 50, sort = 'date', direction = 'asc'
} = {}) {
  const params = {
    campaignId,
    search: search || '',
    like: likePattern(search),
    paymentStatus,
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  const where = `
    WHERE k.campaign_id = @campaignId
      AND (@paymentStatus IS NULL
           OR (@paymentStatus = 'outstanding' AND k.payment_status NOT IN ('paid', 'waived') AND COALESCE(k.commitment_amount, 0) - k.amount_collected > 0)
           OR k.payment_status = @paymentStatus)
      AND (@search = '' OR m.first_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\'
           OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\'
           OR m.member_code LIKE @like ESCAPE '\\' OR k.claim_date LIKE @like ESCAPE '\\')`;

  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const orderBy = {
    date: `k.claim_date ${dir}`,
    member: `m.last_name COLLATE NOCASE ${dir}, m.first_name COLLATE NOCASE ${dir}`,
    claimed: `k.claimed_at ${dir}`
  }[sort] || `k.claim_date ${dir}`;

  const rows = query(
    `SELECT k.*, m.first_name, m.last_name, m.preferred_name, m.member_code,
            u.display_name AS updated_by_name,
            cu.display_name AS recorded_by_name, cu.member_id AS recorded_by_member_id,
            (SELECT MAX(p.paid_on) FROM ecaq_payments p WHERE p.claim_id = k.id) AS last_paid_on,
            (SELECT COUNT(*) FROM ecaq_payments p WHERE p.claim_id = k.id) AS payment_count
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
       LEFT JOIN users u ON u.id = k.updated_by
       LEFT JOIN users cu ON cu.id = k.created_by
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    params
  );

  const total = queryOne(
    `SELECT COUNT(*) AS n FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id ${where}`,
    params
  ).n;

  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

export function claimsCsv(campaign) {
  const { rows } = listClaims({ campaignId: campaign.id, pageSize: 1000 });
  const cell = csvCell;
  const header = ['Date', 'Member ID', 'Member', 'Claimed at', `Commitment (${campaign.currency})`,
    `Collected (${campaign.currency})`, `Balance (${campaign.currency})`, 'Payment status',
    'Status', 'Updated by', 'Notes'];
  const lines = [header.map(cell).join(',')];
  for (const r of rows) {
    const balance = Math.max(Number(r.commitment_amount ?? 0) - Number(r.amount_collected ?? 0), 0);
    lines.push([
      r.claim_date,
      r.member_code,
      [r.preferred_name || r.first_name, r.last_name].filter(Boolean).join(' '),
      r.claimed_at,
      r.commitment_amount ?? '',
      r.amount_collected ?? 0,
      r.commitment_amount != null ? balance : '',
      PAYMENT_LABELS[r.payment_status] || r.payment_status,
      r.status,
      r.updated_by_name || '',
      r.notes ?? ''
    ].map(cell).join(','));
  }
  return { csv: `${lines.join('\r\n')}\r\n`, count: rows.length };
}

// --- Project updates and gallery -------------------------------------------

export function listProjectUpdates({ includeUnpublished = false, limit = 50 } = {}) {
  return query(
    `SELECT u.*, us.display_name AS created_by_name
       FROM ecaq_project_updates u
       LEFT JOIN users us ON us.id = u.created_by
      WHERE (@includeUnpublished = 1 OR u.status = 'published')
      ORDER BY u.update_date IS NULL, u.update_date DESC, u.id DESC
      LIMIT @limit`,
    { includeUnpublished: includeUnpublished ? 1 : 0, limit }
  );
}

export function getProjectUpdate(id) {
  return queryOne('SELECT * FROM ecaq_project_updates WHERE id = @id', { id }) || null;
}

export function createProjectUpdate(data, { userId = null } = {}) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO ecaq_project_updates (title, body, update_date, source, status, created_at, updated_at, created_by)
     VALUES (@title, @body, @update_date, @source, @status, @at, @at, @by)`,
    {
      title: data.title,
      body: data.body,
      update_date: data.update_date || today(),
      source: data.source ?? null,
      status: ['draft', 'published', 'archived'].includes(data.status) ? data.status : 'draft',
      at,
      by: userId
    }
  );
  return getProjectUpdate(Number(result.lastInsertRowid));
}

export function updateProjectUpdate(id, data) {
  execute(
    `UPDATE ecaq_project_updates SET title = @title, body = @body, update_date = @update_date,
            source = @source, updated_at = @at
      WHERE id = @id`,
    {
      id,
      title: data.title,
      body: data.body,
      update_date: data.update_date || null,
      source: data.source ?? null,
      at: nowIso()
    }
  );
  return getProjectUpdate(id);
}

export function setProjectUpdateStatus(id, status) {
  if (!['draft', 'published', 'archived'].includes(status)) return null;
  execute('UPDATE ecaq_project_updates SET status = @status, updated_at = @at WHERE id = @id',
    { id, status, at: nowIso() });
  return getProjectUpdate(id);
}

export function deleteProjectUpdate(id) {
  return execute('DELETE FROM ecaq_project_updates WHERE id = @id', { id }).changes;
}

export function listProjectMedia() {
  return query(
    `SELECT m.*, u.display_name AS uploaded_by_name
       FROM ecaq_project_media m
       LEFT JOIN users u ON u.id = m.uploaded_by
      ORDER BY m.sort_order, m.id`
  );
}

export function getProjectMedia(id) {
  return queryOne('SELECT * FROM ecaq_project_media WHERE id = @id', { id }) || null;
}

export function addProjectMedia(items, { userId = null } = {}) {
  const at = nowIso();
  const added = [];
  transaction(() => {
    for (const item of items) {
      const result = execute(
        `INSERT INTO ecaq_project_media (media_type, file_path, caption, sort_order, uploaded_at, uploaded_by)
         VALUES (@mediaType, @filePath, @caption, @sortOrder, @at, @by)`,
        {
          mediaType: item.mediaType,
          filePath: item.storedPath,
          caption: item.caption || null,
          sortOrder: item.sortOrder || 0,
          at,
          by: userId
        }
      );
      added.push(Number(result.lastInsertRowid));
    }
  })();
  return added;
}

export function deleteProjectMedia(id) {
  const media = getProjectMedia(id);
  if (!media) return null;
  execute('DELETE FROM ecaq_project_media WHERE id = @id', { id });
  return media;
}

export function formatMoney(amount, currency = 'QAR') {
  if (amount === null || amount === undefined || amount === '') return null;
  const value = Number(amount);
  if (!Number.isFinite(value)) return null;
  return `${currency} ${value.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

export function formatClaimDate(date) {
  return formatDate(date, 'medium');
}

// ---------------------------------------------------------------------------
// Payments against a commitment
// ---------------------------------------------------------------------------

export const PAYMENT_METHODS = ['cash', 'bank_transfer', 'cheque', 'card', 'other'];
export const METHOD_LABELS = {
  cash: 'Cash',
  bank_transfer: 'Bank transfer',
  cheque: 'Cheque',
  card: 'Card',
  other: 'Other'
};

/**
 * A commitment can be settled in one go or paid off month by month, so each
 * payment is its own record: how much, when, how, and who received it. The
 * claim's total and payment status are recalculated from those records rather
 * than typed in, so the two can never drift apart.
 */
export function listPayments(claimId) {
  return query(
    `SELECT p.*, u.display_name AS recorded_by_name
       FROM ecaq_payments p
       LEFT JOIN users u ON u.id = p.created_by
      WHERE p.claim_id = @claimId
      ORDER BY p.paid_on, p.id`,
    { claimId }
  );
}

export function getPayment(id) {
  return queryOne('SELECT * FROM ecaq_payments WHERE id = @id', { id }) || null;
}

function toCents(value) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

/** Recalculates a claim from its payments. Never trusts a typed-in total. */
export function recalculateClaim(claimId) {
  const claim = queryOne('SELECT * FROM ecaq_giving_board_claims WHERE id = @id', { id: claimId });
  if (!claim) return null;

  // Summed in floating point, ten payments of 0.10 come to 0.9999999999999999 and would leave a fully paid
  // commitment "partially paid" with a phantom balance, so the total is held to whole cents.
  const total = toCents(queryOne(
    'SELECT COALESCE(SUM(amount), 0) AS paid FROM ecaq_payments WHERE claim_id = @claimId',
    { claimId }
  ).paid);

  const commitment = Number(claim.commitment_amount) || 0;
  let status = claim.payment_status;

  // Waived and pending verification are decisions an administrator makes, so
  // they are left alone; everything else follows the arithmetic.
  if (!['waived', 'pending_verification'].includes(claim.payment_status)) {
    if (total <= 0) status = 'not_paid';
    else if (commitment > 0 && total >= commitment) status = 'paid';
    else status = 'partially_paid';
  }

  execute(
    `UPDATE ecaq_giving_board_claims
        SET amount_collected = @total, payment_status = @status, updated_at = @at
      WHERE id = @id`,
    { id: claimId, total, status, at: nowIso() }
  );

  return { collected: total, commitment, status, outstanding: Math.max(commitment - total, 0) };
}

export function addPayment(claimId, data, { userId = null } = {}) {
  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };

  const claim = queryOne('SELECT * FROM ecaq_giving_board_claims WHERE id = @id', { id: claimId });
  if (!claim) return { ok: false, reason: 'not_found' };

  const at = nowIso();
  // The payment row and the claim's recalculated total are one unit: a failure in between must not leave a
  // payment on file that the commitment does not know about.
  return transaction(() => {
    const result = execute(
      `INSERT INTO ecaq_payments
         (claim_id, amount, paid_on, method, reference, notes, received_by, received_by_name, created_at, created_by)
       VALUES (@claimId, @amount, @paidOn, @method, @reference, @notes, @receivedBy, @receivedByName, @at, @by)`,
      {
        claimId,
        amount,
        paidOn: data.paid_on || today(),
        method: PAYMENT_METHODS.includes(data.method) ? data.method : 'cash',
        reference: data.reference || null,
        notes: data.notes || null,
        receivedBy: data.received_by || userId,
        receivedByName: data.received_by_name || null,
        at,
        by: userId
      }
    );

    const totals = recalculateClaim(claimId);
    return { ok: true, payment: getPayment(Number(result.lastInsertRowid)), totals };
  })();
}

/**
 * Corrects a payment already on file — most often the actual date it was
 * received, since that is not always the day it was entered into the
 * portal. Only ever changes the payment itself and its claim's recalculated
 * total; who changed it and when belongs on the audit log, not here.
 */
export function updatePayment(id, data, { userId = null } = {}) {
  const payment = getPayment(id);
  if (!payment) return { ok: false, reason: 'not_found' };

  const amount = data.amount !== undefined ? Number(data.amount) : payment.amount;
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };

  const at = nowIso();
  return transaction(() => {
    execute(
      `UPDATE ecaq_payments
          SET amount = @amount, paid_on = @paidOn, method = @method, reference = @reference,
              notes = @notes, updated_at = @at, updated_by = @by
        WHERE id = @id`,
      {
        id, amount, paidOn: data.paid_on || payment.paid_on,
        method: PAYMENT_METHODS.includes(data.method) ? data.method : payment.method,
        reference: data.reference !== undefined ? data.reference : payment.reference,
        notes: data.notes !== undefined ? data.notes : payment.notes,
        at, by: userId
      }
    );
    const totals = recalculateClaim(payment.claim_id);
    return { ok: true, payment: getPayment(id), totals };
  })();
}

export function deletePayment(id) {
  const payment = getPayment(id);
  if (!payment) return null;
  return transaction(() => {
    execute('DELETE FROM ecaq_payments WHERE id = @id', { id });
    const totals = recalculateClaim(payment.claim_id);
    return { payment, totals };
  })();
}

/** A member's own statement: what they committed, paid and still owe. */
export function memberPaymentSummary(memberId, { campaignId = null } = {}) {
  const claims = query(
    `SELECT k.*, c.name AS campaign_name, c.year, c.currency, c.amount_per_date
       FROM ecaq_giving_board_claims k
       JOIN ecaq_campaigns c ON c.id = k.campaign_id
      WHERE k.member_id = @memberId
        AND (@campaignId IS NULL OR k.campaign_id = @campaignId)
      ORDER BY k.claim_date`,
    { memberId, campaignId }
  );

  let committed = 0;
  let collected = 0;
  const rows = claims.map((claim) => {
    const payments = listPayments(claim.id);
    const paid = payments.reduce((sum, p) => sum + Number(p.amount), 0);
    const commitment = Number(claim.commitment_amount) || 0;
    committed += commitment;
    collected += paid;
    return {
      ...claim,
      payments,
      paid,
      outstanding: Math.max(commitment - paid, 0),
      instalments: payments.length
    };
  });

  return {
    rows,
    committed,
    collected,
    outstanding: Math.max(committed - collected, 0),
    currency: claims[0]?.currency || 'QAR'
  };
}

/** Every payment in a campaign, for the church office and its records. */
export const PAYMENT_SORT_COLUMNS = ['received', 'member', 'for_date', 'amount', 'method'];

export function campaignPayments(campaignId, { from = null, to = null, limit = 500, sort = 'received', direction = 'desc' } = {}) {
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  const orderBy = {
    received: `p.paid_on ${dir}, p.id ${dir}`,
    member: `m.last_name COLLATE NOCASE ${dir}, m.first_name COLLATE NOCASE ${dir}`,
    for_date: `k.claim_date ${dir}`,
    amount: `p.amount ${dir}`,
    method: `p.method COLLATE NOCASE ${dir}`
  }[sort] || `p.paid_on DESC, p.id DESC`;

  return query(
    `SELECT p.*, k.claim_date, k.commitment_amount,
            m.first_name, m.last_name, m.preferred_name, m.member_code,
            u.display_name AS recorded_by_name
       FROM ecaq_payments p
       JOIN ecaq_giving_board_claims k ON k.id = p.claim_id
       LEFT JOIN members m ON m.id = k.member_id
       LEFT JOIN users u ON u.id = p.created_by
      WHERE k.campaign_id = @campaignId
        AND (@from IS NULL OR p.paid_on >= @from)
        AND (@to IS NULL OR p.paid_on <= @to)
      ORDER BY ${orderBy}
      LIMIT @limit`,
    { campaignId, from, to, limit }
  );
}

export const OUTSTANDING_SORT_COLUMNS = ['date', 'member', 'committed', 'paid', 'outstanding', 'status'];

/** Commitments with something still outstanding. */
export function outstandingClaims(campaignId, { sort = 'date', direction = 'asc' } = {}) {
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  // 'paid' and 'outstanding' are computed after the query runs (outstanding
  // depends on a correlated-subquery sum), so those two sorts are applied to
  // the JS array below rather than in the ORDER BY.
  const sqlOrderBy = {
    date: `k.claim_date ${dir}`,
    member: `m.last_name COLLATE NOCASE ${dir}, m.first_name COLLATE NOCASE ${dir}`,
    committed: `k.commitment_amount ${dir}`,
    status: `k.payment_status COLLATE NOCASE ${dir}`
  }[sort] || `k.claim_date ASC`;

  const rows = query(
    `SELECT k.*, m.first_name, m.last_name, m.preferred_name, m.member_code, m.phone,
            COALESCE((SELECT SUM(p.amount) FROM ecaq_payments p WHERE p.claim_id = k.id), 0) AS paid
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
      WHERE k.campaign_id = @campaignId
        AND k.status = 'active'
        AND k.payment_status NOT IN ('paid', 'waived')
      ORDER BY ${sqlOrderBy}`,
    { campaignId }
  ).map((claim) => ({
    ...claim,
    outstanding: Math.max((Number(claim.commitment_amount) || 0) - Number(claim.paid), 0)
  }));

  if (sort === 'paid' || sort === 'outstanding') {
    const dirMul = direction === 'desc' ? -1 : 1;
    rows.sort((a, b) => (a[sort] - b[sort]) * dirMul);
  }
  return rows;
}

/**
 * Every commitment on a board, whatever its balance. A day that has been paid
 * in full is still part of the Giving Board's history and belongs in a
 * complete record just as much as one still owing — this is the version that
 * does not quietly drop a row once its balance reaches zero.
 */
export function allClaimsWithBalance(campaignId) {
  return query(
    `SELECT k.*, m.first_name, m.last_name, m.preferred_name, m.member_code, m.phone,
            u.display_name AS claimed_by_name,
            COALESCE((SELECT SUM(p.amount) FROM ecaq_payments p WHERE p.claim_id = k.id), 0) AS paid
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
       LEFT JOIN users u ON u.id = k.created_by
      WHERE k.campaign_id = @campaignId
        AND k.status = 'active'
      ORDER BY k.claim_date`,
    { campaignId }
  ).map((claim) => ({
    ...claim,
    outstanding: Math.max((Number(claim.commitment_amount) || 0) - Number(claim.paid), 0)
  }));
}

export function paymentsCsv(campaign) {
  const rows = campaignPayments(campaign.id, { limit: 1_000_000_000 }); // every payment
  const cell = csvCell;
  const header = ['Paid on', 'Member ID', 'Member', 'Commitment date', `Amount (${campaign.currency})`,
    'Method', 'Reference', 'Received by', 'Recorded by', 'Notes'];
  const lines = [header.map(cell).join(',')];
  for (const r of rows) {
    lines.push([
      r.paid_on,
      r.member_code,
      [r.preferred_name || r.first_name, r.last_name].filter(Boolean).join(' '),
      r.claim_date,
      r.amount,
      METHOD_LABELS[r.method] || r.method,
      r.reference || '',
      r.received_by_name || r.recorded_by_name || '',
      r.recorded_by_name || '',
      r.notes || ''
    ].map(cell).join(','));
  }
  return { csv: `${lines.join('\r\n')}\r\n`, count: rows.length };
}

/**
 * Every board side by side, for the years running at once.
 *
 * Each year is counted on its own and the totals are a sum of those years, so
 * a day taken on the 2028 board can never be counted towards 2026. Only boards
 * in the same currency are added together; if the church ever runs a board in
 * another currency, that is shown rather than quietly added up.
 */
export function allCampaignsProgress() {
  // Only GIVING BOARD campaigns are boards: a Faith Promise (or any other) campaign has no days to take and must never appear as a board year with "0 of 365".
  const campaigns = listCampaigns().filter((campaign) => campaign.type === 'giving_board');
  const years = campaigns.map((campaign) => {
    const progress = campaignProgress(campaign);
    return {
      campaign,
      year: campaign.year,
      name: campaign.name,
      status: campaign.status,
      currency: campaign.currency,
      ...progress
    };
  }).sort((a, b) => a.year - b.year);

  const currencies = [...new Set(years.map((y) => y.currency))];
  const mixedCurrency = currencies.length > 1;

  const totals = years.reduce((sum, y) => ({
    days: sum.days + (y.totalDates || 0),
    claimed: sum.claimed + (y.claimed || 0),
    committed: sum.committed + (Number(y.committed) || 0),
    collected: sum.collected + (Number(y.collected) || 0)
  }), { days: 0, claimed: 0, committed: 0, collected: 0 });

  totals.outstanding = totals.committed - totals.collected;
  totals.claimedPercent = totals.days ? Math.round((totals.claimed / totals.days) * 100) : 0;
  totals.collectedPercent = totals.committed
    ? Math.round((totals.collected / totals.committed) * 100)
    : 0;

  return { years, totals, mixedCurrency, currency: currencies[0] || 'QAR' };
}
