import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso, today } from '../lib/dates.js';

export const ACTIVITY_STATUSES = ['draft', 'published', 'archived'];
export const ACTIVITY_SCOPES = ['church', 'cell_group'];
export const STATUS_LABELS = {
  draft: 'Draft',
  published: 'Published',
  archived: 'Archived'
};

/**
 * What a given user may do with a given activity. Leaders manage only the
 * groups they lead; everyone else needs the church-wide permission.
 */
export function canManageActivity(user, activity) {
  if (!user) return false;
  if (user.can('activities.manage')) return true;
  if (!user.can('activities.manage_own_group')) return false;
  if (activity.scope !== 'cell_group' || !activity.cell_group_id) return false;
  return user.ledCellGroupIds.includes(Number(activity.cell_group_id));
}

export function canManageGroupActivities(user, cellGroupId) {
  if (!user) return false;
  if (user.can('activities.manage')) return true;
  return user.can('activities.manage_own_group') && user.ledCellGroupIds.includes(Number(cellGroupId));
}

/**
 * Whether a user may see an activity at all. Drafts and archived activities
 * stay with the people who manage them; published cell group activities are
 * visible to that group, and to administrators.
 */
export function canViewActivity(user, activity) {
  if (!user || !activity) return false;
  if (canManageActivity(user, activity)) return true;
  if (activity.status !== 'published') return false;
  if (activity.scope === 'church') return user.can('activities.view');
  if (!user.can('activities.view')) return false;
  if (user.can('cellgroups.view')) return true;
  const groupId = Number(activity.cell_group_id);
  return user.ledCellGroupIds.includes(groupId) || Number(user.member?.cell_group_id) === groupId;
}

export function getActivity(id) {
  return queryOne(
    `SELECT a.*, g.name AS cell_group_name, u.display_name AS created_by_name,
            (SELECT COUNT(*) FROM activity_media m WHERE m.activity_id = a.id) AS media_count
       FROM activities a
       LEFT JOIN cell_groups g ON g.id = a.cell_group_id
       LEFT JOIN users u ON u.id = a.created_by
      WHERE a.id = @id`,
    { id }
  ) || null;
}

/**
 * Activities for one cell group. Callers that cannot manage the group only
 * ever receive published entries.
 */
export function listGroupActivities(cellGroupId, { includeUnpublished = false, limit = 100 } = {}) {
  return query(
    `SELECT a.*, u.display_name AS created_by_name,
            (SELECT COUNT(*) FROM activity_media m WHERE m.activity_id = a.id) AS media_count,
            (SELECT COUNT(*) FROM activity_media m WHERE m.activity_id = a.id AND m.media_type = 'image') AS photo_count
       FROM activities a
       LEFT JOIN users u ON u.id = a.created_by
      WHERE a.scope = 'cell_group'
        AND a.cell_group_id = @id
        AND (@includeUnpublished = 1 OR a.status = 'published')
      ORDER BY a.activity_date IS NULL, a.activity_date DESC, a.id DESC
      LIMIT @limit`,
    { id: cellGroupId, includeUnpublished: includeUnpublished ? 1 : 0, limit }
  );
}

export function createActivity(data, { userId = null } = {}) {
  const at = nowIso();
  const status = ACTIVITY_STATUSES.includes(data.status) ? data.status : 'draft';
  const result = execute(
    `INSERT INTO activities
       (scope, cell_group_id, title, description, category, activity_date, start_time, end_time,
        location, status, created_at, updated_at, created_by)
     VALUES (@scope, @cell_group_id, @title, @description, @category, @activity_date, @start_time,
             @end_time, @location, @status, @at, @at, @by)`,
    {
      scope: ACTIVITY_SCOPES.includes(data.scope) ? data.scope : 'cell_group',
      cell_group_id: data.cell_group_id ?? null,
      title: data.title,
      description: data.description ?? null,
      category: data.category ?? null,
      activity_date: data.activity_date ?? null,
      start_time: data.start_time ?? null,
      end_time: data.end_time ?? null,
      location: data.location ?? null,
      status,
      at,
      by: userId
    }
  );
  return getActivity(Number(result.lastInsertRowid));
}

export function updateActivity(id, data) {
  execute(
    `UPDATE activities SET
       title = @title, description = @description, category = @category,
       activity_date = @activity_date, start_time = @start_time, end_time = @end_time,
       location = @location, updated_at = @at
     WHERE id = @id`,
    {
      id,
      title: data.title,
      description: data.description ?? null,
      category: data.category ?? null,
      activity_date: data.activity_date ?? null,
      start_time: data.start_time ?? null,
      end_time: data.end_time ?? null,
      location: data.location ?? null,
      at: nowIso()
    }
  );
  return getActivity(id);
}

export function setActivityStatus(id, status) {
  if (!ACTIVITY_STATUSES.includes(status)) return null;
  execute('UPDATE activities SET status = @status, updated_at = @at WHERE id = @id',
    { id, status, at: nowIso() });
  return getActivity(id);
}

export function deleteActivity(id) {
  return execute('DELETE FROM activities WHERE id = @id', { id }).changes;
}

export function setActivityCover(id, mediaPath) {
  execute('UPDATE activities SET cover_image = @path, updated_at = @at WHERE id = @id',
    { id, path: mediaPath, at: nowIso() });
  return getActivity(id);
}

// --- Media -----------------------------------------------------------------

export function addMedia(activityId, items, { userId = null } = {}) {
  const at = nowIso();
  const added = [];
  transaction(() => {
    for (const item of items) {
      const result = execute(
        `INSERT INTO activity_media
           (activity_id, album, media_type, file_path, caption, file_size, mime_type, uploaded_at, uploaded_by)
         VALUES (@activityId, @album, @mediaType, @filePath, @caption, @size, @mimeType, @at, @by)`,
        {
          activityId,
          album: item.album || null,
          mediaType: item.mediaType,
          filePath: item.storedPath,
          caption: item.caption || null,
          size: item.size || null,
          mimeType: item.mimeType || null,
          at,
          by: userId
        }
      );
      added.push(Number(result.lastInsertRowid));
    }
  })();
  return added;
}

export function listMedia(activityId, { kind = null } = {}) {
  return query(
    `SELECT m.*, u.display_name AS uploaded_by_name
       FROM activity_media m
       LEFT JOIN users u ON u.id = m.uploaded_by
      WHERE m.activity_id = @id
        AND (@kind IS NULL OR m.media_type = @kind)
      ORDER BY m.album IS NULL, m.album COLLATE NOCASE, m.uploaded_at, m.id`,
    { id: activityId, kind }
  );
}

export function getMedia(mediaId) {
  return queryOne(
    `SELECT m.*, a.id AS activity_id, a.scope, a.cell_group_id, a.status AS activity_status, a.title AS activity_title
       FROM activity_media m
       JOIN activities a ON a.id = m.activity_id
      WHERE m.id = @id`,
    { id: mediaId }
  ) || null;
}

export function deleteMedia(mediaId) {
  const media = getMedia(mediaId);
  if (!media) return null;
  execute('DELETE FROM activity_media WHERE id = @id', { id: mediaId });
  execute('UPDATE activities SET cover_image = NULL WHERE cover_image = @path', { path: media.file_path });
  return media;
}

export function updateMediaCaption(mediaId, { caption = null, album = null }) {
  execute('UPDATE activity_media SET caption = @caption, album = @album WHERE id = @id',
    { id: mediaId, caption, album });
  return getMedia(mediaId);
}

/** The whole gallery for a group, grouped into albums for display. */
export function groupGallery(cellGroupId, { includeUnpublished = false } = {}) {
  const rows = query(
    `SELECT m.*, a.title AS activity_title, a.activity_date, a.status AS activity_status,
            u.display_name AS uploaded_by_name
       FROM activity_media m
       JOIN activities a ON a.id = m.activity_id
       LEFT JOIN users u ON u.id = m.uploaded_by
      WHERE a.scope = 'cell_group'
        AND a.cell_group_id = @id
        AND (@includeUnpublished = 1 OR a.status = 'published')
      ORDER BY a.activity_date IS NULL, a.activity_date DESC, m.album COLLATE NOCASE, m.id`,
    { id: cellGroupId, includeUnpublished: includeUnpublished ? 1 : 0 }
  );

  const albums = new Map();
  for (const item of rows) {
    const key = item.album || item.activity_title || 'Uncategorised';
    if (!albums.has(key)) albums.set(key, { name: key, activityId: item.activity_id, items: [] });
    albums.get(key).items.push(item);
  }

  return {
    albums: [...albums.values()],
    total: rows.length,
    photos: rows.filter((r) => r.media_type === 'image').length,
    videos: rows.filter((r) => r.media_type === 'video').length,
    documents: rows.filter((r) => r.media_type === 'document').length
  };
}

/** Counts for the group activity summary card. */
export function groupActivityStats(cellGroupId) {
  const counts = queryOne(
    `SELECT
       SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) AS published,
       SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft,
       SUM(CASE WHEN status = 'archived' THEN 1 ELSE 0 END) AS archived,
       COUNT(*) AS total,
       MAX(activity_date) AS latest_date
     FROM activities WHERE scope = 'cell_group' AND cell_group_id = @id`,
    { id: cellGroupId }
  );
  const upcoming = queryOne(
    `SELECT COUNT(*) AS n FROM activities
      WHERE scope = 'cell_group' AND cell_group_id = @id
        AND status = 'published' AND activity_date >= @today`,
    { id: cellGroupId, today: today() }
  ).n;
  return {
    published: counts?.published || 0,
    draft: counts?.draft || 0,
    archived: counts?.archived || 0,
    total: counts?.total || 0,
    latestDate: counts?.latest_date || null,
    upcoming
  };
}

// ---------------------------------------------------------------------------
// Church-wide activities
// ---------------------------------------------------------------------------

/**
 * Cell group activities a user may see, used by the church activity list and
 * the calendar. Administrators see every group; a leader sees the groups they
 * lead; a member sees their own group. Drafts stay with their managers.
 */
function visibleGroupIds(user) {
  if (!user) return [];
  if (user.can('cellgroups.view') || user.can('cellgroups.manage')) return null; // all
  const ids = new Set(user.ledCellGroupIds.map(Number));
  if (user.member?.cell_group_id) ids.add(Number(user.member.cell_group_id));
  return [...ids];
}

/**
 * One list covering both scopes, filtered to what the user may see. Unpublished
 * activities appear only where the user manages them.
 */
export function listActivities(user, {
  scope = null, status = null, search = '', from = null, to = null,
  page = 1, pageSize = 20
} = {}) {
  const manageAll = user.can('activities.manage');
  const groupIds = visibleGroupIds(user);
  const ledIds = user.ledCellGroupIds.map(Number);

  const params = {
    scope,
    status,
    search: search || '',
    like: likePattern(search),
    from,
    to,
    manageAll: manageAll ? 1 : 0,
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  // Which cell group activities are in reach at all.
  let groupReach = '1 = 1';
  if (groupIds !== null) {
    if (groupIds.length === 0) {
      groupReach = '0 = 1';
    } else {
      groupReach = `a.cell_group_id IN (${groupIds.map((id, i) => {
        params[`vg${i}`] = id;
        return `@vg${i}`;
      }).join(',')})`;
    }
  }

  // Which unpublished activities the user manages.
  let manageClause = '@manageAll = 1';
  if (!manageAll && user.can('activities.manage_own_group') && ledIds.length) {
    manageClause = `a.cell_group_id IN (${ledIds.map((id, i) => {
      params[`lg${i}`] = id;
      return `@lg${i}`;
    }).join(',')})`;
  } else if (!manageAll) {
    manageClause = '0 = 1';
  }

  const where = `
    WHERE (@scope IS NULL OR a.scope = @scope)
      AND (@status IS NULL OR a.status = @status)
      AND (@search = '' OR a.title LIKE @like ESCAPE '\\' OR a.description LIKE @like ESCAPE '\\' OR a.location LIKE @like ESCAPE '\\')
      AND (@from IS NULL OR a.activity_date >= @from)
      AND (@to IS NULL OR a.activity_date <= @to)
      AND (a.scope = 'church' OR ${groupReach})
      AND (a.status = 'published' OR ${manageClause})`;

  const rows = query(
    `SELECT a.*, g.name AS cell_group_name, u.display_name AS created_by_name,
            (SELECT COUNT(*) FROM activity_media m WHERE m.activity_id = a.id) AS media_count,
            (SELECT COUNT(*) FROM activity_media m WHERE m.activity_id = a.id AND m.media_type = 'image') AS photo_count,
            (SELECT m.id FROM activity_media m
              WHERE m.activity_id = a.id AND m.file_path = a.cover_image LIMIT 1) AS cover_media_id
       FROM activities a
       LEFT JOIN cell_groups g ON g.id = a.cell_group_id
       LEFT JOIN users u ON u.id = a.created_by
       ${where}
      ORDER BY a.activity_date IS NULL, a.activity_date DESC, a.id DESC
      LIMIT @limit OFFSET @offset`,
    params
  );

  const total = queryOne(`SELECT COUNT(*) AS n FROM activities a ${where}`, params).n;
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/** Published activities in a date range, for the calendar. */
export function activitiesInRange(user, { from, to }) {
  return listActivities(user, { from, to, pageSize: 500 }).rows;
}

export function activityCounts(user) {
  const all = listActivities(user, { pageSize: 1000 }).rows;
  return {
    total: all.length,
    church: all.filter((a) => a.scope === 'church').length,
    cellGroup: all.filter((a) => a.scope === 'cell_group').length,
    draft: all.filter((a) => a.status === 'draft').length,
    published: all.filter((a) => a.status === 'published').length,
    archived: all.filter((a) => a.status === 'archived').length
  };
}
