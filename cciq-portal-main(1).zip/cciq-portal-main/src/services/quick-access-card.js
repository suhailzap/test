import path from 'node:path';
import sharp from 'sharp';
import QRCode from 'qrcode';
import { ROOT } from '../config/env.js';

/* A shareable public portal URL only; no account, session or attendance token. */

const LOGO_PATH = path.join(ROOT, 'src', 'public', 'branding', 'cciq-logo-256.png');
const CARD_WIDTH = 960;
const CARD_HEIGHT = 1400;

function escapeXml(text) {
  return String(text ?? '').replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
}

let cachedLogoDataUri = null;
async function logoDataUri() {
  if (cachedLogoDataUri) return cachedLogoDataUri;
  const buf = await sharp(LOGO_PATH).resize(216, 216, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } }).png().toBuffer();
  cachedLogoDataUri = `data:image/png;base64,${buf.toString('base64')}`;
  return cachedLogoDataUri;
}

/** Render the public portal QR. The date records generation, not expiry. */
export async function renderQuickAccessCard({ url, dateLabel, churchName, churchShortName }) {
  const qrSize = 560;
  const qrBuffer = await QRCode.toBuffer(url, {
    errorCorrectionLevel: 'M',
    margin: 1,
    width: qrSize,
    color: { dark: '#0a2547', light: '#ffffff' }
  });
  const qrDataUri = `data:image/png;base64,${qrBuffer.toString('base64')}`;

  const cx = CARD_WIDTH / 2;
  const headerBottom = 300;
  const safeUrl = escapeXml(url);
  const safeDate = escapeXml(dateLabel);
  const safeShortName = escapeXml(churchShortName || 'CCIQ');
  const safeName = escapeXml(churchName || 'Christian Church in Qatar');

  const svg = `
<svg width="${CARD_WIDTH}" height="${CARD_HEIGHT}" viewBox="0 0 ${CARD_WIDTH} ${CARD_HEIGHT}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="header" x1="0%" y1="0%" x2="100%" y2="120%">
      <stop offset="0%" stop-color="#0a2547"/>
      <stop offset="55%" stop-color="#10355f"/>
      <stop offset="140%" stop-color="#861F41"/>
    </linearGradient>
    <clipPath id="cardClip"><rect x="0" y="0" width="${CARD_WIDTH}" height="${CARD_HEIGHT}" rx="56"/></clipPath>
  </defs>

  <g clip-path="url(#cardClip)">
    <rect width="${CARD_WIDTH}" height="${CARD_HEIGHT}" fill="#ffffff"/>
    <rect width="${CARD_WIDTH}" height="${headerBottom}" fill="url(#header)"/>

    <circle cx="${cx}" cy="112" r="62" fill="#ffffff"/>
    <image href="${await logoDataUri()}" x="${cx - 54}" y="58" width="108" height="108"/>

    <text x="${cx}" y="228" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="46" font-weight="800" letter-spacing="4" fill="#ffffff">${safeShortName} PORTAL</text>
    <text x="${cx}" y="264" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="24" font-weight="600" letter-spacing="1" fill="#c7d2e0">Quick Access</text>

    <rect x="${cx - qrSize / 2 - 36}" y="${headerBottom + 46}" width="${qrSize + 72}" height="${qrSize + 72}" rx="26" fill="#fbfcfd" stroke="#eef1f5" stroke-width="2"/>
    <image href="${qrDataUri}" x="${cx - qrSize / 2}" y="${headerBottom + 82}" width="${qrSize}" height="${qrSize}"/>

    <text x="${cx}" y="${headerBottom + qrSize + 168}" text-anchor="middle" font-family="Consolas, 'Courier New', monospace"
          font-size="34" font-weight="700" fill="#0a2547">${safeUrl}</text>

    <text x="${cx}" y="${headerBottom + qrSize + 214}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="24" font-weight="600" fill="#5a6b7d">Scan using Wi-Fi or mobile data to open the portal.</text>

    <rect x="${cx - 220}" y="${headerBottom + qrSize + 246}" width="440" height="52" rx="26" fill="#fdf1e0"/>
    <text x="${cx}" y="${headerBottom + qrSize + 280}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="24" font-weight="800" letter-spacing="1" fill="#8a5a10">PORTAL SIGN-IN REQUIRED</text>

    <text x="${cx}" y="${CARD_HEIGHT - 46}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="22" font-weight="600" fill="#8896a8">${safeName} &#183; ${safeDate}</text>
  </g>
</svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}
