import { transaction, queryOne } from '../db/index.js';
import { recordAudit } from '../lib/audit.js';
import { Validator } from '../lib/validate.js';
import { checkinClosure } from './attendance-lifecycle.js';
import { checkinSession } from './qr-checkin.js';
import { assertSessionMutable } from './attendance.js';
import { createVisitor, findPossibleDuplicates, collectInviter } from './visitors.js';
import { searchMembersForPicker } from './members.js';

/*
 * Express First Timer Registration at the check-in desk (Kiosk or usher).
 *
 * What it is: register a brand-new First Timer and check them in to today's Friday Service in ONE step, using as little as a first
 * name. The First Timer record and its first visit (tied to today's service) are created together or not at all.
 *
 * What it is deliberately NOT, pending owner decisions (docs/FIRST-TIMER-LIFECYCLE.md, "Owner decisions"):
 *   - the minimum fields are not settled: only the first name is required here; surname, mobile number and the rest are optional;
 *   - whether a Kiosk may override a duplicate warning is not settled: it MAY NOT. Any possible duplicate (a member or another
 *     First Timer with the same name or the same mobile number) stops the registration with a message that names nobody, and sends
 *     the person to search for themselves or to an usher. The administrative First Timer screen keeps its "record anyway" choice;
 *   - it never creates a member, never links to a member, and never reads or writes anything about membership.
 *
 * "Invited by" is optional and means exactly what it means on the administrative form: a chosen member becomes visitors.invited_by_member_id,
 * and choosing nobody leaves it NULL (the screens print NULL as "Came on their own"; no member or name is ever invented for it).
 *
 * It needs the narrow permission visitors.express_register, which is enforced by the route.
 */

export function collectExpressInput(body) {
  const v = new Validator(body);
  v.text('first_name', { required: true, max: 80, label: 'First name' });
  v.text('last_name', { max: 80, label: 'Last name' });
  v.phone('phone', { label: 'Mobile number' });
  collectInviter(v);
  return v;
}

/**
 * The desk's "Invited by" search: the SAME match as the administrative member picker (searchMembersForPicker), but it hands the desk only what
 * is needed to choose someone, a name. No Member ID, cell group, photo, phone or status, so a reception terminal never becomes a member
 * directory. At least three characters are needed, and at most eight names come back.
 */
export const INVITER_SEARCH_MIN = 3;
export const INVITER_SEARCH_LIMIT = 8;
export function searchInvitersForDesk(term) {
  const clean = String(term || '').trim();
  if (clean.length < INVITER_SEARCH_MIN) return [];
  return searchMembersForPicker(clean, { limit: INVITER_SEARCH_LIMIT }).map((m) => ({ id: m.id, name: m.name }));
}

/**
 * @returns {{ok:true, visitor, session}|{ok:false, reason:'no_session'|'closed'|'not_writable'|'possible_duplicate'|'inviter_not_found', message?:string}}
 */
export function registerFirstTimerAtDesk(values, { userId = null, req = null } = {}) {
  const session = checkinSession();
  if (!session) return { ok: false, reason: 'no_session', message: 'There is no Friday Service scheduled for today.' };
  const closure = checkinClosure(session);
  if (closure) return { ok: false, reason: 'closed', message: closure.message };

  return transaction(() => {
    // Read again inside the immediate transaction: a finalization committed since checkinSession() was read must still refuse this registration.
    const mutable = assertSessionMutable(queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: session.id }));
    if (!mutable.ok) return { ok: false, reason: 'not_writable', message: 'Attendance cannot be recorded for this service right now.' };

    // Never overridable from here. Nothing about the match is returned: the desk learns only that a match exists.
    if (findPossibleDuplicates({ first_name: values.first_name, last_name: values.last_name ?? null, phone: values.phone ?? null }).length > 0) {
      return { ok: false, reason: 'possible_duplicate' };
    }

    // The member could have been removed since the form was checked: say so rather than store nothing or fail on the foreign key.
    if (values.invited_by_member_id != null && !queryOne('SELECT 1 AS x FROM members WHERE id = @id', { id: values.invited_by_member_id })) {
      return { ok: false, reason: 'inviter_not_found' };
    }

    const visitor = createVisitor({
      first_name: values.first_name,
      last_name: values.last_name ?? null,
      phone: values.phone ?? null,
      invited_by_member_id: values.invited_by_member_id ?? null,
      first_visit_date: session.service_date,
      session_id: session.id
    }, { userId });

    recordAudit({
      req, action: 'visitor.express_registered', entityType: 'visitor', entityId: visitor.id,
      detail: { session_id: session.id, service_date: session.service_date, has_phone: Boolean(visitor.phone), has_last_name: Boolean(visitor.last_name), invited_by: visitor.invited_by_member_id }
    });
    return { ok: true, visitor, session };
  }).immediate();
}
