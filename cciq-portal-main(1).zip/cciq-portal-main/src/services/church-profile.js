import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso } from '../lib/dates.js';

/**
 * The sections of the About page. Titles and wording belong to the church, so
 * these are created empty and filled in through the portal rather than being
 * written into the code.
 */
export const DEFAULT_SECTIONS = [
  { key: 'welcome', title: 'Welcome', sort_order: 10, hint: 'A short greeting for members opening the portal.' },
  { key: 'mission', title: 'Our mission', sort_order: 20, hint: 'Why the church exists.' },
  { key: 'vision', title: 'Our vision', sort_order: 30, hint: 'What the church is working towards.' },
  { key: 'beliefs', title: 'What we believe', sort_order: 40, hint: 'A statement of faith, if the church has one.' },
  { key: 'history', title: 'Our story', sort_order: 50, hint: 'How the church began and where it has been.' },
  { key: 'ministries', title: 'Ministries', sort_order: 60, hint: 'The ministries and groups within the church.' },
  { key: 'contact', title: 'Contact us', sort_order: 70, hint: 'How to reach the church office.' }
];

/** Creates any section that does not exist yet, leaving existing text alone. */
export function ensureSections() {
  const at = nowIso();
  transaction(() => {
    for (const section of DEFAULT_SECTIONS) {
      execute(
        `INSERT INTO church_pages (key, title, body, sort_order, is_visible, updated_at)
         VALUES (@key, @title, NULL, @sort_order, 1, @at)
         ON CONFLICT(key) DO NOTHING`,
        { key: section.key, title: section.title, sort_order: section.sort_order, at }
      );
    }
  })();
}

export function listSections({ visibleOnly = false } = {}) {
  const rows = query(
    `SELECT * FROM church_pages
      WHERE (@visibleOnly = 0 OR (is_visible = 1 AND body IS NOT NULL AND TRIM(body) != ''))
      ORDER BY sort_order, key`,
    { visibleOnly: visibleOnly ? 1 : 0 }
  );
  const hints = Object.fromEntries(DEFAULT_SECTIONS.map((s) => [s.key, s.hint]));
  return rows.map((row) => ({ ...row, hint: hints[row.key] || null }));
}

export function getSection(key) {
  return queryOne('SELECT * FROM church_pages WHERE key = @key', { key }) || null;
}

export function saveSection(key, { title, body, isVisible }, { userId = null } = {}) {
  execute(
    `UPDATE church_pages SET title = @title, body = @body, is_visible = @visible,
            updated_at = @at, updated_by = @by
      WHERE key = @key`,
    {
      key,
      title,
      body: body && body.trim() ? body.trim() : null,
      visible: isVisible ? 1 : 0,
      at: nowIso(),
      by: userId
    }
  );
  return getSection(key);
}

/** True once the church has written at least one section. */
export function hasContent() {
  return queryOne(
    "SELECT COUNT(*) AS n FROM church_pages WHERE body IS NOT NULL AND TRIM(body) != ''"
  ).n > 0;
}

// --- Leadership ------------------------------------------------------------

export function listLeaders({ visibleOnly = false } = {}) {
  return query(
    `SELECT * FROM church_leaders
      WHERE (@visibleOnly = 0 OR is_visible = 1)
      ORDER BY sort_order, id`,
    { visibleOnly: visibleOnly ? 1 : 0 }
  );
}

export function getLeader(id) {
  return queryOne('SELECT * FROM church_leaders WHERE id = @id', { id }) || null;
}

export function createLeader(data) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO church_leaders (name, role_title, group_label, description, email, phone, sort_order, is_visible, created_at, updated_at)
     VALUES (@name, @role_title, @group_label, @description, @email, @phone, @sort_order, 1, @at, @at)`,
    {
      name: data.name,
      role_title: data.role_title ?? null,
      group_label: data.group_label ?? null,
      description: data.description ?? null,
      email: data.email ?? null,
      phone: data.phone ?? null,
      sort_order: Number(data.sort_order) || 0,
      at
    }
  );
  return getLeader(Number(result.lastInsertRowid));
}

export function updateLeader(id, data) {
  execute(
    `UPDATE church_leaders SET name = @name, role_title = @role_title, group_label = @group_label,
            description = @description, email = @email, phone = @phone, sort_order = @sort_order,
            is_visible = @visible, updated_at = @at
      WHERE id = @id`,
    {
      id,
      name: data.name,
      role_title: data.role_title ?? null,
      group_label: data.group_label ?? null,
      description: data.description ?? null,
      email: data.email ?? null,
      phone: data.phone ?? null,
      sort_order: Number(data.sort_order) || 0,
      visible: data.isVisible ? 1 : 0,
      at: nowIso()
    }
  );
  return getLeader(id);
}

export function setLeaderPhoto(id, photoPath) {
  execute('UPDATE church_leaders SET photo_path = @path, updated_at = @at WHERE id = @id',
    { id, path: photoPath, at: nowIso() });
  return getLeader(id);
}

export function deleteLeader(id) {
  const leader = getLeader(id);
  if (!leader) return null;
  execute('DELETE FROM church_leaders WHERE id = @id', { id });
  return leader;
}

/** Leadership arranged under the headings the church uses. */
/**
 * The church's own governing bodies, in the order the church actually
 * observes it: the Board of Elders, who are its Pastors, then the Council of
 * Deacons. This is not alphabetical and not left to however leaders happen to
 * be entered — it is fixed, so it can never come out the wrong way round no
 * matter what order individual leaders were added in.
 */
export const LEADERSHIP_GROUPS = ['Board of Elders (Pastors)', 'Council of Deacons'];

export function leadershipGroups({ visibleOnly = true } = {}) {
  const leaders = listLeaders({ visibleOnly });
  const groups = [];

  const groupFor = (label) => {
    let group = groups.find((g) => g.label === label);
    if (!group) {
      group = { label, leaders: [] };
      groups.push(group);
    }
    return group;
  };

  // The two recognised groups always exist and always come first, in this
  // order, whether or not anyone has been placed in them yet.
  LEADERSHIP_GROUPS.forEach((label) => groupFor(label));

  for (const leader of leaders) {
    const label = leader.group_label || 'Church leadership';
    groupFor(label).leaders.push(leader);
  }

  // A group nobody has been added to yet, or a name from before this
  // structure existed, is dropped only if it is genuinely empty; anything
  // with people in it stays visible, just placed after the two main groups.
  return groups.filter((g) => g.leaders.length > 0 || LEADERSHIP_GROUPS.includes(g.label));
}
