import { query, queryOne, execute, transaction } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import {
  today, nowIso, addDays, fridaysBetween, nextFridayOnOrAfter, lastFridayOnOrBefore, isFriday
} from '../lib/dates.js';

export const FRIDAY_SERVICE = 'friday_service';

/**
 * The Friday Service is the church's regular weekly service, so the schedule is
 * generated rather than entered by hand. Existing rows are never overwritten:
 * a service an administrator cancelled or edited stays as they left it.
 */
export function ensureFridaySessions({ userId = null, weeksAhead = null } = {}) {
  if (!getSetting('service.friday.enabled')) return { created: 0 };

  const horizon = weeksAhead ?? getSetting('service.friday.weeks_ahead') ?? 12;
  const from = lastFridayOnOrBefore(today());
  const to = addDays(today(), horizon * 7);
  const title = getSetting('service.friday.title') || 'CCIQ Friday Service';
  const startTime = getSetting('service.friday.time') || null;
  const location = getSetting('service.friday.location') || null;
  const at = nowIso();

  const insert = `
    INSERT OR IGNORE INTO attendance_sessions
      (service_date, service_type, title, start_time, location, cell_group_id, status, counts_toward_followup, created_at, created_by)
    VALUES (@date, '${FRIDAY_SERVICE}', @title, @time, @location, 0, 'scheduled', 1, @at, @by)`;

  let created = 0;
  transaction(() => {
    for (const date of fridaysBetween(from, to)) {
      const result = execute(insert, { date, title, time: startTime, location, at, by: userId });
      created += result.changes;
    }
  })();

  return { created };
}

/** Applies changed service time or location to services not yet held. */
export function applyScheduleDefaultsToUpcoming({ userId = null } = {}) {
  return execute(
    `UPDATE attendance_sessions
        SET start_time = @time, location = @location, title = @title
      WHERE service_type = @type
        AND status = 'scheduled'
        AND service_date >= @today`,
    {
      time: getSetting('service.friday.time') || null,
      location: getSetting('service.friday.location') || null,
      title: getSetting('service.friday.title') || 'CCIQ Friday Service',
      type: FRIDAY_SERVICE,
      today: today()
    }
  ).changes;
}

export function getNextFridayService(fromDate = today()) {
  return queryOne(
    `SELECT * FROM attendance_sessions
      WHERE service_type = @type AND status != 'cancelled' AND service_date >= @from
      ORDER BY service_date ASC LIMIT 1`,
    { type: FRIDAY_SERVICE, from: fromDate }
  ) || null;
}

export function getLatestFridayService(toDate = today()) {
  return queryOne(
    `SELECT * FROM attendance_sessions
      WHERE service_type = @type AND status != 'cancelled' AND service_date <= @to
      ORDER BY service_date DESC LIMIT 1`,
    { type: FRIDAY_SERVICE, to: toDate }
  ) || null;
}

/**
 * The Friday Service session eligible for a check-in write RIGHT NOW - the
 * exact calendar-current Friday, never a fallback to an older week. A
 * red-team review found the front door's own use of getLatestFridayService()
 * (this file's other lookup, kept unbounded for read-only displays such as
 * latestServiceOverview()) let a cancelled current-week Friday cause a
 * walk-in check-in to silently write attendance into a session weeks old.
 * Mirrors isOperationalFridaySession() in services/attendance.js as a
 * self-contained query here, rather than importing that validator, since
 * attendance.js already imports from this file and importing back would be
 * circular.
 */
export function getCurrentOperationalFridayService() {
  return queryOne(
    `SELECT * FROM attendance_sessions
      WHERE service_type = @type AND status != 'cancelled' AND service_date = @date`,
    { type: FRIDAY_SERVICE, date: lastFridayOnOrBefore(today()) }
  ) || null;
}

export function listFridayServices({ from = null, to = null, limit = 26, direction = 'desc' } = {}) {
  // `direction` only ever comes from this file's own callers (never request
  // input), so interpolating it is safe — the same pattern `listSessions`
  // already uses for its own fixed, internally-chosen ORDER BY direction.
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  return query(
    `SELECT * FROM attendance_sessions
      WHERE service_type = @type
        AND (@from IS NULL OR service_date >= @from)
        AND (@to IS NULL OR service_date <= @to)
      ORDER BY service_date ${dir}
      LIMIT @limit`,
    { type: FRIDAY_SERVICE, from, to, limit }
  );
}

export function scheduleStatus() {
  const enabled = Boolean(getSetting('service.friday.enabled'));
  const time = getSetting('service.friday.time');
  const location = getSetting('service.friday.location');
  return {
    enabled,
    time: time || null,
    location: location || null,
    title: getSetting('service.friday.title'),
    needsConfiguration: !time || !location,
    nextDate: nextFridayOnOrAfter(today()),
    isServiceDay: isFriday(today())
  };
}
