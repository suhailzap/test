import crypto from 'node:crypto';
import { queryOne, execute, transaction } from '../db/index.js';
import { getCurrentOperationalFridayService } from './friday-service.js';
import { nowIso } from '../lib/dates.js';
import { serviceHeadcount } from './service-headcount.js';
import { maybeReturnFromTemporarilyAway, assertSessionMutable, isOperationalFridaySession } from './attendance.js';

/**
 * A member's QR token is a long random string, never their member ID or
 * record number — nothing about it can be guessed or forged by trying
 * nearby values. It is generated the first time it is needed and can be
 * replaced (a lost or shared printout) without affecting the member record
 * itself; only the old code stops working.
 */
function generateToken() {
  return crypto.randomBytes(24).toString('base64url');
}

/** Returns the member's existing token, generating one on first use. */
export function ensureQrToken(memberId) {
  const member = queryOne('SELECT id, qr_token FROM members WHERE id = @id', { id: memberId });
  if (!member) return null;
  if (member.qr_token) return member.qr_token;

  const token = generateToken();
  execute('UPDATE members SET qr_token = @token WHERE id = @id', { token, id: memberId });
  return token;
}

/** Issues a fresh token, invalidating whatever the member had before. */
export function regenerateQrToken(memberId) {
  const previous = queryOne('SELECT qr_token FROM members WHERE id = @id', { id: memberId });
  const token = generateToken();

  transaction(() => {
    execute('UPDATE members SET qr_token = @token WHERE id = @id', { token, id: memberId });
    if (previous?.qr_token) {
      execute(
        `INSERT INTO qr_token_history (member_id, old_token, retired_at) VALUES (@memberId, @oldToken, @at)
         ON CONFLICT(old_token) DO UPDATE SET member_id = @memberId, retired_at = @at`,
        { memberId, oldToken: previous.qr_token, at: nowIso() }
      );
    }
  })();

  return token;
}

/**
 * Finds the member a scanned token belongs to. Returns null if the code is
 * simply not recognised at all, or { retired: true } if it once worked but
 * was replaced by a newer one -- deliberately without naming whose code it
 * was, since telling someone a code is out of date does not require that.
 */
export function findMemberByQrToken(token) {
  if (!token) return null;
  const clean = token.trim();

  const member = queryOne(
    `SELECT id, member_code, first_name, last_name, preferred_name, photo_path, status, cell_group_id
       FROM members WHERE qr_token = @token`,
    { token: clean }
  );
  if (member) return member;

  const retired = queryOne('SELECT id FROM qr_token_history WHERE old_token = @token', { token: clean });
  if (retired) return { retired: true };

  return null;
}

/**
 * The Friday Service a walk-in check-in should count against right now.
 * Codex/independent verification: this previously fell back to the most
 * recent non-cancelled Friday from any earlier week when the current week's
 * own session was cancelled - the front door's lookup/review/record routes
 * (and the kiosk, which shares this same function) would then silently
 * record today's arrivals into a session weeks old, exactly the class of
 * defect isOperationalFridaySession() already exists to prevent for QR
 * confirmation. Bounded to the exact calendar-current Friday now, with no
 * fallback; a cancelled or missing current Friday means there is nothing to
 * check into here, full stop. A genuinely historical correction remains
 * possible only through the dedicated, explicitly-authorized session/records
 * edit screens, never through this front-door path.
 */
export function checkinSession() {
  return getCurrentOperationalFridayService();
}

/** Reception count, using the same service resolution and successful-arrival
 * states as recordAttendanceForPeople. Union prevents counting a converted
 * visitor twice if their member attendance also exists for this service. */
export function checkedInState() {
  const session = checkinSession();
  if (!session) return { sessionId: null, serviceDate: null, count: null };
  // The same definition as every other headcount (service-headcount.js), so the desk's live count and the Friday's own figures cannot disagree.
  return { sessionId: session.id, serviceDate: session.service_date, count: serviceHeadcount(session.id).total };
}

/**
 * Marks the member present for the given session and logs the scan. Safe to
 * call more than once for the same member and session — a second scan
 * updates nothing and is reported back as already checked in, rather than
 * erroring or creating a duplicate record.
 */
export function confirmCheckin(memberId, sessionId, { userId = null } = {}) {
  // sessionId here is client-supplied (round-tripped from /checkin/lookup's
  // response), so it is not guaranteed to still be legitimate — a stale
  // tab left open across the week boundary, a direct POST, or a
  // guessed/forged id could name a past, future, or wrong-type (cell-group)
  // session entirely. This is the one entry point whose entire purpose is
  // "confirm attendance at the front door, right now", so it is checked
  // against isOperationalFridaySession() - the same *bounded* definition
  // recordAttendance()/recordAttendanceForPeople() use - rather than
  // checkinSession()'s own unbounded "most recent non-cancelled Friday"
  // fallback: a red-team review found that fallback let a cancelled
  // current-week Friday cause a write into a session weeks old. If this
  // week's own Friday is missing or cancelled, there is nothing to confirm
  // against, full stop - never an older week. See CCIQ_DECISIONS.md.
  const target = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  const mutable = assertSessionMutable(target);
  if (!mutable.ok || !isOperationalFridaySession(target)) {
    return { ok: false, reason: mutable.ok ? 'not_current_session' : mutable.reason, alreadyCheckedIn: false };
  }

  /*
   * CONCURRENCY. The gate check above is a cheap early refusal, but it is NOT what makes the write safe: the transaction below begins IMMEDIATE
   * (it holds the database's write lock) and re-reads the session before it writes, exactly as finalizeAttendance() does inside its own
   * immediate transaction. So a check-in cannot slip into a Friday that another process finalized between the check and the write
   * (proved across processes by race-attendance-finalize.mjs). Within the single application process the synchronous access already
   * serializes them; this closes the gap for a second process (a maintenance script, a stray second copy).
   */
  const existing = queryOne(
    'SELECT id FROM qr_checkins WHERE member_id = @memberId AND session_id = @sessionId',
    { memberId, sessionId }
  );
  if (existing) return { ok: true, alreadyCheckedIn: true };

  const at = nowIso();
  let refusedLate = null;
  transaction(() => {
    // The gate above was read before this write lock was taken. A finalization (or "attendance not taken") committed by another process in between must
    // still stop this write, so the session is read again HERE, inside the immediate transaction, and refused if it is no longer writable.
    const fresh = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
    const again = assertSessionMutable(fresh);
    if (!again.ok) { refusedLate = again.reason; return; }
    execute(
      `INSERT INTO attendance_records (session_id, member_id, status, source, recorded_at, recorded_by)
       VALUES (@sessionId, @memberId, 'present', 'qr_checkin', @at, @userId)
       ON CONFLICT(session_id, member_id) DO UPDATE SET status = 'present', source = 'qr_checkin', recorded_at = @at, recorded_by = @userId`,
      { sessionId, memberId, at, userId }
    );
    execute(
      'INSERT INTO qr_checkins (member_id, session_id, checked_in_at, confirmed_by) VALUES (@memberId, @sessionId, @at, @userId)',
      { memberId, sessionId, at, userId }
    );
    // The session is already confirmed current above, so the auto-return
    // rule's own "is this current" requirement is satisfied unconditionally
    // here; the transition-order check inside maybeReturnFromTemporarilyAway
    // itself still applies. See maybeReturnFromTemporarilyAway().
    maybeReturnFromTemporarilyAway(memberId, target.service_date, { userId });
  })();
  if (refusedLate) return { ok: false, reason: refusedLate, alreadyCheckedIn: false };
  return { ok: true, alreadyCheckedIn: false };
}
