import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import sharp from 'sharp';
import QRCode from 'qrcode';
import config, { ROOT } from '../config/env.js';
import { resolveStoredFile } from '../lib/uploads.js';
import { ensureQrToken } from './qr-checkin.js';
import { displayName } from './members.js';

const LOGO_PATH = path.join(ROOT, 'src', 'public', 'branding', 'cciq-logo-256.png');
const CARD_WIDTH = 960;
const CARD_HEIGHT = 1680;

function cardCacheDir() {
  return path.join(config.storageDir, 'member-cards');
}

/*
 * A short fingerprint of everything that changes what the card looks like.
 * The leading "v2" marks the fix that stopped the card showing a member's
 * nickname instead of their formal name — bumping it forces every
 * previously-cached card to regenerate under the corrected rendering, even
 * for a member whose own fields haven't changed since.
 */
function fingerprintFor(member, token) {
  const raw = ['v2', member.photo_path || '', member.first_name, member.last_name, member.preferred_name || '', token].join('|');
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 16);
}

/** The CCIQ crest composited into the center of a high-error-correction QR code. */
async function brandedQrPng(token, sizePx) {
  const qrBuffer = await QRCode.toBuffer(token, {
    errorCorrectionLevel: 'H',
    margin: 1,
    width: sizePx,
    color: { dark: '#0a2547', light: '#ffffff' }
  });

  const logoSize = Math.round(sizePx * 0.2);
  const logo = await sharp(LOGO_PATH)
    .resize(logoSize, logoSize, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } })
    .toBuffer();

  const backingSize = Math.round(logoSize * 1.22);
  const backing = Buffer.from(
    `<svg width="${backingSize}" height="${backingSize}"><circle cx="${backingSize / 2}" cy="${backingSize / 2}" r="${backingSize / 2}" fill="white"/></svg>`
  );

  return sharp(qrBuffer)
    .composite([{ input: backing, gravity: 'center' }, { input: logo, gravity: 'center' }])
    .png()
    .toBuffer();
}

/** The member's photo, or their first initial, as a square PNG ready to be circle-cropped in SVG. */
async function memberPhotoSquarePng(member, sizePx) {
  const storedFile = member.photo_path ? resolveStoredFile(member.photo_path) : null;
  if (storedFile) {
    try {
      return await sharp(storedFile).resize(sizePx, sizePx, { fit: 'cover' }).png().toBuffer();
    } catch {
      // The file exists but isn't a readable image (corrupted, truncated,
      // or an unsupported format that slipped past the upload check) --
      // falling through to the initial below is far better than a broken
      // download for something the member has no way to fix themselves.
    }
  }

  const initial = (member.first_name || member.last_name || '?').trim().charAt(0).toUpperCase();
  const svg = `
    <svg width="${sizePx}" height="${sizePx}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${sizePx}" height="${sizePx}" fill="#0a2547"/>
      <text x="50%" y="53%" text-anchor="middle" dominant-baseline="middle"
            font-family="Segoe UI, Arial, sans-serif" font-size="${Math.round(sizePx * 0.42)}"
            font-weight="700" fill="#ffffff">${initial}</text>
    </svg>`;
  return sharp(Buffer.from(svg)).png().toBuffer();
}

function escapeXml(text) {
  return String(text ?? '').replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
}

/**
 * Renders a member's personalized check-in card: CCIQ branding, their photo,
 * their name, and a QR code with the church crest in the center. Built
 * entirely with SVG and raster compositing rather than a browser, since the
 * portal avoids bundling a full Chromium install just to produce one image.
 */
export async function renderMemberCard(member) {
  const token = ensureQrToken(member.id);
  const cardName = escapeXml(displayName(member));

  const qrSize = 620;
  const photoSize = 340;
  const [qrPng, photoPng] = await Promise.all([
    brandedQrPng(token, qrSize),
    memberPhotoSquarePng(member, photoSize)
  ]);

  const qrDataUri = `data:image/png;base64,${qrPng.toString('base64')}`;
  const photoDataUri = `data:image/png;base64,${photoPng.toString('base64')}`;

  const cx = CARD_WIDTH / 2;
  const headerBottom = 470;
  const photoR = photoSize / 2;
  const photoCenterY = headerBottom;
  const ringR = photoR + 10;
  const photoBottom = photoCenterY + ringR;

  const svg = `
<svg width="${CARD_WIDTH}" height="${CARD_HEIGHT}" viewBox="0 0 ${CARD_WIDTH} ${CARD_HEIGHT}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="header" x1="0%" y1="0%" x2="100%" y2="120%">
      <stop offset="0%" stop-color="#0a2547"/>
      <stop offset="55%" stop-color="#10355f"/>
      <stop offset="140%" stop-color="#861F41"/>
    </linearGradient>
    <linearGradient id="ring" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#dfa523"/>
      <stop offset="100%" stop-color="#861F41"/>
    </linearGradient>
    <clipPath id="photoClip"><circle cx="${cx}" cy="${photoCenterY}" r="${photoR}"/></clipPath>
    <clipPath id="cardClip"><rect x="0" y="0" width="${CARD_WIDTH}" height="${CARD_HEIGHT}" rx="56"/></clipPath>
  </defs>

  <g clip-path="url(#cardClip)">
    <rect width="${CARD_WIDTH}" height="${CARD_HEIGHT}" fill="#ffffff"/>
    <rect width="${CARD_WIDTH}" height="${headerBottom + 60}" fill="url(#header)"/>
    <path d="M 0,${headerBottom - 10} Q ${cx},${headerBottom + 70} ${CARD_WIDTH},${headerBottom - 10} L ${CARD_WIDTH},${CARD_HEIGHT} L 0,${CARD_HEIGHT} Z" fill="#ffffff"/>

    <circle cx="${cx}" cy="130" r="62" fill="#ffffff"/>
    <image href="${await logoDataUri()}" x="${cx - 54}" y="76" width="108" height="108"/>

    <text x="${cx}" y="248" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="58" font-weight="800" letter-spacing="6" fill="#ffffff">CCIQ</text>
    <text x="${cx}" y="286" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="24" font-weight="600" letter-spacing="2" fill="#c7d2e0">CHRISTIAN CHURCH IN QATAR</text>

    <circle cx="${cx}" cy="${photoCenterY}" r="${ringR}" fill="url(#ring)"/>
    <circle cx="${cx}" cy="${photoCenterY}" r="${photoR + 4}" fill="#ffffff"/>
    <image href="${photoDataUri}" x="${cx - photoR}" y="${photoCenterY - photoR}" width="${photoSize}" height="${photoSize}" clip-path="url(#photoClip)"/>

    <text x="${cx}" y="${photoBottom + 70}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="54" font-weight="800" fill="#0a2547">${cardName}</text>
    <text x="${cx}" y="${photoBottom + 108}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="26" font-weight="600" fill="#8896a8">Member Check-In Card</text>

    <line x1="64" y1="${photoBottom + 170}" x2="${cx - 130}" y2="${photoBottom + 170}" stroke="#e5e9ef" stroke-width="2"/>
    <line x1="${cx + 130}" y1="${photoBottom + 170}" x2="${CARD_WIDTH - 64}" y2="${photoBottom + 170}" stroke="#e5e9ef" stroke-width="2"/>
    <text x="${cx}" y="${photoBottom + 178}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="21" font-weight="700" letter-spacing="3" fill="#9aa7b8">SCAN AT THE ENTRANCE</text>

    <rect x="${cx - qrSize / 2 - 40}" y="${photoBottom + 210}" width="${qrSize + 80}" height="${qrSize + 80}" rx="28" fill="#fbfcfd" stroke="#eef1f5" stroke-width="2"/>
    <image href="${qrDataUri}" x="${cx - qrSize / 2}" y="${photoBottom + 250}" width="${qrSize}" height="${qrSize}"/>

    <text x="${cx}" y="${CARD_HEIGHT - 60}" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif"
          font-size="26" font-weight="600" fill="#5a6b7d">Keep this in your photo gallery</text>
  </g>
</svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

let cachedLogoDataUri = null;
async function logoDataUri() {
  if (cachedLogoDataUri) return cachedLogoDataUri;
  const buf = await sharp(LOGO_PATH).resize(216, 216, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } }).png().toBuffer();
  cachedLogoDataUri = `data:image/png;base64,${buf.toString('base64')}`;
  return cachedLogoDataUri;
}

/**
 * Returns the member's card PNG, generating and caching it if this is the
 * first time or if anything the card shows (photo, name, QR token) has
 * changed since it was last built.
 */
export async function memberCardPng(member) {
  const token = ensureQrToken(member.id);
  const fingerprint = fingerprintFor(member, token);
  const dir = cardCacheDir();
  const target = path.join(dir, `${member.id}-${fingerprint}.png`);

  if (fs.existsSync(target)) return fs.readFileSync(target);

  const png = await renderMemberCard(member);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(target, png, { mode: 0o640 });

  // Clear out any older cached card for this member so they don't pile up.
  for (const existing of fs.readdirSync(dir)) {
    if (existing.startsWith(`${member.id}-`) && existing !== `${member.id}-${fingerprint}.png`) {
      fs.rmSync(path.join(dir, existing), { force: true });
    }
  }

  return png;
}
