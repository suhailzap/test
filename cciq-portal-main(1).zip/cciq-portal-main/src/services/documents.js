import fs from 'node:fs';
import { likePattern } from '../lib/like.js';
import path from 'node:path';
import crypto from 'node:crypto';
import config from '../config/env.js';
import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso, today, addDays } from '../lib/dates.js';
import { sniffMediaType, cleanUploadName } from '../lib/uploads.js';
import { afterCommit, onRollback } from '../lib/atomic.js';
import { displayName } from './members.js';

/**
 * The church's document library. Files are written outside the public folder
 * and only ever reach a browser through a route that checks permission first,
 * which is why nothing here returns a URL — only a stored path the media route
 * resolves.
 */

// Only formats a church actually files. Anything executable is refused by the
// absence of a rule here, not by a blocklist that could be worked around.
export const ALLOWED_TYPES = {
  'application/pdf': { ext: '.pdf', label: 'PDF', kind: 'pdf' },
  'image/jpeg': { ext: '.jpg', label: 'JPG', kind: 'image' },
  'image/png': { ext: '.png', label: 'PNG', kind: 'image' },
  'image/webp': { ext: '.webp', label: 'WEBP', kind: 'image' }
};

export const DOCUMENT_STATUSES = ['active', 'archived', 'deleted'];

export const RELATION_TYPES = ['member', 'cell_group', 'activity', 'ministry', 'project'];
export const RELATION_LABELS = {
  member: 'Member',
  cell_group: 'Cell group',
  activity: 'Activity',
  ministry: 'Ministry',
  project: 'Project'
};

export const AUDIENCES = ['staff', 'leaders', 'members'];

/*
 * Per-document audience ("Who can view this?"). The CATEGORY's audience is the maximum; a document can only narrow it, to the portal roles below (the Kiosk is never an
 * audience). A document with no choice of its own ('category' mode) behaves exactly as it always has.
 */
export const AUDIENCE_ROLES = ['super_admin', 'church_admin', 'cell_group_leader', 'member'];
export const AUDIENCE_ROLE_LABELS = { super_admin: 'Super Admin', church_admin: 'Church Admin', cell_group_leader: 'Cell Group leaders', member: 'Members' };
const CATEGORY_ROLES = {
  staff: ['super_admin', 'church_admin'],
  leaders: ['super_admin', 'church_admin', 'cell_group_leader'],
  members: ['super_admin', 'church_admin', 'cell_group_leader', 'member']
};
/** The roles a category could ever be shared with: the most a document in it may be opened to. */
export const rolesAllowedByCategory = (audience) => CATEGORY_ROLES[audience] || CATEGORY_ROLES.staff;
export const AUDIENCE_LABELS = {
  staff: 'Church administration only',
  leaders: 'Administration and cell group leaders',
  members: 'Everyone signed in'
};

/**
 * The categories a church of this kind actually files under. They are created
 * once and then belong to the church: rename, reorder, archive or add more.
 */
export const DEFAULT_CATEGORIES = [
  { name: 'Church Administration', audience: 'staff' },
  { name: 'Financial Records', audience: 'staff', financial: true },
  { name: 'Receipts', audience: 'staff', financial: true },
  { name: 'Forms', audience: 'staff' },
  { name: 'Meeting Documents', audience: 'staff' },
  { name: 'Church Activities', audience: 'members' },
  { name: 'Cell Groups', audience: 'leaders' },
  { name: 'Membership', audience: 'staff' },
  { name: 'Attendance', audience: 'staff' },
  { name: 'ECAQ Worship Centre', audience: 'members' },
  { name: 'Projects', audience: 'staff' },
  { name: 'Ministry', audience: 'leaders' },
  { name: 'Correspondence', audience: 'staff' },
  { name: 'Reports', audience: 'staff' },
  { name: 'Other', audience: 'staff' }
];

const slugify = (value) => String(value).toLowerCase().trim()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);

// --- Categories ------------------------------------------------------------

export function ensureCategories() {
  const at = nowIso();
  transaction(() => {
    DEFAULT_CATEGORIES.forEach((category, index) => {
      execute(
        `INSERT INTO document_categories (name, slug, audience, sort_order, status, is_financial, created_at, updated_at)
         VALUES (@name, @slug, @audience, @sort, 'active', @financial, @at, @at)
         ON CONFLICT(slug) DO NOTHING`,
        {
          name: category.name, slug: slugify(category.name), audience: category.audience,
          sort: (index + 1) * 10, financial: category.financial ? 1 : 0, at
        }
      );
    });
  })();
}

export function listCategories({ includeArchived = false, scope = null } = {}) {
  // With a scope, a category's count is the documents THAT PERSON may open (never the hidden ones); without one it is every active document (administration only).
  const { sql: scopeSql, params: scopeParams } = scope ? scopeClause(scope) : { sql: '1 = 1', params: {} };
  return query(
    `SELECT c.*,
            (SELECT COUNT(*) FROM documents d
              WHERE d.category_id = c.id AND d.status = 'active' AND ${scopeSql}) AS document_count
       FROM document_categories c
      WHERE (@includeArchived = 1 OR c.status = 'active')
      ORDER BY c.sort_order, c.name COLLATE NOCASE`,
    { includeArchived: includeArchived ? 1 : 0, ...scopeParams }
  );
}

export function getCategory(id) {
  return queryOne('SELECT * FROM document_categories WHERE id = @id', { id }) || null;
}

export function createCategory(data) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO document_categories (name, slug, description, audience, sort_order, status, is_financial, created_at, updated_at)
     VALUES (@name, @slug, @description, @audience, @sort, 'active', @financial, @at, @at)`,
    {
      name: data.name,
      slug: slugify(data.name),
      description: data.description ?? null,
      audience: AUDIENCES.includes(data.audience) ? data.audience : 'staff',
      sort: Number(data.sort_order) || 0,
      financial: data.is_financial ? 1 : 0,
      at
    }
  );
  return getCategory(Number(result.lastInsertRowid));
}

export function updateCategory(id, data) {
  execute(
    `UPDATE document_categories
        SET name = @name, description = @description, audience = @audience,
            sort_order = @sort, status = @status, is_financial = @financial, updated_at = @at
      WHERE id = @id`,
    {
      id,
      name: data.name,
      description: data.description ?? null,
      audience: AUDIENCES.includes(data.audience) ? data.audience : 'staff',
      sort: Number(data.sort_order) || 0,
      status: data.status === 'archived' ? 'archived' : 'active',
      financial: data.is_financial ? 1 : 0,
      at: nowIso()
    }
  );
  return getCategory(id);
}

/** A category still holding documents cannot be removed until they are moved. */
export function deleteCategory(id) {
  const inUse = queryOne(
    "SELECT COUNT(*) AS n FROM documents WHERE category_id = @id AND status != 'deleted'",
    { id }
  ).n;
  if (inUse > 0) return { ok: false, reason: 'in_use', count: inUse };

  execute('DELETE FROM document_categories WHERE id = @id', { id });
  return { ok: true };
}

// --- Visibility ------------------------------------------------------------

/**
 * What a user may see. Church administration and finance are never opened up
 * to a cell group leader or a member simply because they hold a link: the rule
 * is applied in SQL on every query, including search.
 */
export function scopeFor(user) {
  if (!user || !user.can('documents.view')) return { type: 'none' };
  // The roles that count as an audience (a user may hold several, e.g. leader and member).
  const roles = (user.roles || []).filter((r) => AUDIENCE_ROLES.includes(r));
  // The Super Admin can always open every document (so none can ever be orphaned by a narrowing).
  if (roles.includes('super_admin')) return { type: 'all' };
  // Every other administrator reaches every category, but a document narrowed to roles they do not hold is not theirs to open.
  if (user.can('documents.manage')) {
    return { type: 'manager', audiences: ['staff', 'leaders', 'members'], roles, userId: user.id, memberId: user.memberId || null };
  }

  if (user.can('cellgroups.manage_own')) {
    return {
      type: 'leader',
      audiences: ['members', 'leaders'],
      roles,
      cellGroupIds: (user.ledCellGroupIds || []).map(Number),
      userId: user.id,
      memberId: user.memberId || null
    };
  }

  return {
    type: 'member',
    audiences: ['members'],
    roles,
    userId: user.id,
    memberId: user.memberId || null
  };
}

/**
 * Builds the WHERE fragment for a scope. Audience is the authorization
 * boundary, and nothing else — mandatory, and never independently
 * overridden, per the owner's explicit decision: a document's category
 * audience ('staff'/'members'/'leaders') decides who may see it at all,
 * and nothing narrows that decision further except by being stricter.
 *
 * A document_relationships link to a member or cell group (set independently
 * of category when a document is uploaded — see routes/documents.js) is
 * organizational metadata only: it powers "documents about this group/
 * member" narrowing elsewhere (documentsFor(), via listDocuments()'s own
 * relatedType/relatedId filter, applied on top of this same scope clause) —
 * it must never be treated as an additional grant of visibility here. A
 * 'staff'-audience document linked to a cell group must remain invisible to
 * that group's leader; a 'staff'-audience document linked to a member must
 * remain invisible to that member.
 *
 * `uploaded_by` is likewise NOT an independent grant, even though the
 * uploader themselves is asking. An earlier version of this scope treated
 * "you uploaded it" as reason enough regardless of category, reasoned as
 * safe because you already had the source file — a red-team review found
 * the actual gap: a document's *content* is mutable after upload (an
 * admin can replace the file, or edit its category to something more
 * restrictive), so the original uploader's role in that changed document
 * is no longer "I already have this file" but "I can still see whatever
 * this became." A leader who uploaded a routine attachment retaining
 * access after an admin quietly replaces it with a confidential file is
 * exactly the escalation the owner's rule forbids. Uploaders reach their
 * own documents the same way anyone in an audience-appropriate category
 * does — visible immediately after upload (uploads default to a category
 * the uploader can already see), and no longer visible if a later edit
 * moves it somewhere they can't. See CCIQ_DECISIONS.md.
 */
function scopeClause(scope) {
  if (scope.type === 'all') return { sql: '1 = 1', params: {} };
  if (scope.type === 'none') return { sql: '1 = 0', params: {} };

  const params = {};
  const audiences = scope.audiences.map((a, i) => {
    params[`aud${i}`] = a;
    return `@aud${i}`;
  }).join(',');

  // STRICTER ONLY: the category's audience is the ceiling AND, when the document is narrowed to roles, the person must hold one of them. Both are tested here, on every
  // query, so a hand-written row or a later category change can never widen a document beyond its category.
  const roles = (scope.roles || []).map((r, i) => {
    params[`role${i}`] = r;
    return `@role${i}`;
  }).join(',');
  const narrowed = roles
    ? `(d.audience_mode = 'category' OR (d.audience_mode = 'roles' AND EXISTS (SELECT 1 FROM document_audience_roles dar WHERE dar.document_id = d.id AND dar.role_key IN (${roles}))))`
    : "d.audience_mode = 'category'";
  // A manager has always reached a document with no category at all (it cannot be reached by anyone else).
  const categoryOk = scope.type === 'manager' ? `(c.audience IN (${audiences}) OR c.id IS NULL)` : `c.audience IN (${audiences})`;

  return { sql: `(${categoryOk} AND ${narrowed})`, params };
}

/** The roles a document is narrowed to, in the portal's own order ([] = the category's audience decides). */
export function audienceRolesFor(documentId) {
  const rows = query('SELECT role_key FROM document_audience_roles WHERE document_id = @id', { id: documentId }).map((r) => r.role_key);
  return AUDIENCE_ROLES.filter((r) => rows.includes(r));
}

/** The words for a document's audience, for the people who may edit it. */
export function audienceSummary(document) {
  const roles = document.audience_roles || [];
  if (document.audience_mode !== 'roles' || roles.length === 0) return 'Everyone allowed by this category';
  return roles.map((r) => AUDIENCE_ROLE_LABELS[r]).join(', ');
}

/**
 * Reads "Who can view this?" from a submitted form. Returns { ok, mode, roles } or { ok: false, error }.
 *   - "Everyone allowed by this category" (or nothing chosen) = mode 'category'; if it is ticked, any individual roles posted with it are ignored, so no contradictory
 *     combination is ever stored;
 *   - otherwise only roles from the portal's own list, and only roles the CATEGORY already allows (a category's audience is the ceiling), are accepted;
 *   - the person saving must still be able to open the document themselves (the Super Admin always can).
 */
export function parseAudienceInput(body, { category, user }) {
  // Only plain text values are read: a field posted as an object or a list of objects (a hand-built request) is refused, never coerced.
  const raw = [].concat(body.audience_roles ?? []);
  if (raw.some((r) => typeof r !== 'string')) return { ok: false, error: 'Choose who can view this from the roles offered.' };
  const posted = raw;
  if (typeof body.audience_all === 'string' && body.audience_all === '1' || posted.length === 0) return { ok: true, mode: 'category', roles: [] };
  if (posted.some((r) => !AUDIENCE_ROLES.includes(r))) return { ok: false, error: 'Choose who can view this from the roles offered.' };
  const allowed = rolesAllowedByCategory(category?.audience);
  const beyond = posted.filter((r) => !allowed.includes(r));
  if (beyond.length) {
    return { ok: false, error: `This category cannot be shared with ${beyond.map((r) => AUDIENCE_ROLE_LABELS[r]).join(', ')}. A document can be restricted further than its category, but not shared more widely.` };
  }
  const roles = AUDIENCE_ROLES.filter((r) => posted.includes(r));
  const mine = user?.roles || [];
  if (!mine.includes('super_admin') && !roles.some((r) => mine.includes(r))) {
    return { ok: false, error: 'You would not be able to open this document yourself. Include your own role in who can view it.' };
  }
  return { ok: true, mode: 'roles', roles };
}

function setAudience(documentId, audience) {
  const mode = audience && audience.mode === 'roles' && audience.roles?.length ? 'roles' : 'category';
  execute('UPDATE documents SET audience_mode = @mode WHERE id = @id', { id: documentId, mode });
  execute('DELETE FROM document_audience_roles WHERE document_id = @id', { id: documentId });
  if (mode === 'roles') {
    for (const role of audience.roles) {
      if (!AUDIENCE_ROLES.includes(role)) continue;
      execute('INSERT OR IGNORE INTO document_audience_roles (document_id, role_key) VALUES (@id, @role)', { id: documentId, role });
    }
  }
}

export function canSee(user, document) {
  const scope = scopeFor(user);
  if (scope.type === 'none') return false;
  if (scope.type === 'all') return true;
  const found = queryOne(
    `SELECT d.id FROM documents d
       LEFT JOIN document_categories c ON c.id = d.category_id
      WHERE d.id = @id AND ${scopeClause(scope).sql}`,
    { id: document.id, ...scopeClause(scope).params }
  );
  return Boolean(found);
}

// --- Storing files ---------------------------------------------------------

function documentDir(documentId) {
  return path.join(config.storageDir, 'documents', String(documentId));
}

export const MAX_DOCUMENT_BYTES = config.uploads.maxMediaBytes;

/**
 * Writes an uploaded file after checking what it actually is. The stored name
 * is generated, so a crafted filename cannot escape the folder or pretend to
 * be a different type.
 */
export function storeFile(documentId, file) {
  const detected = sniffMediaType(file.buffer);
  const spec = detected ? ALLOWED_TYPES[detected] : null;
  if (!spec) {
    throw Object.assign(
      new Error('That file type is not accepted. Upload a PDF, JPG, PNG or WEBP.'),
      { status: 400 }
    );
  }
  if (file.size > MAX_DOCUMENT_BYTES) {
    throw Object.assign(
      new Error(`That file is larger than ${Math.round(MAX_DOCUMENT_BYTES / (1024 * 1024))} MB.`),
      { status: 400 }
    );
  }

  const dir = documentDir(documentId);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const filename = `${crypto.randomBytes(16).toString('hex')}${spec.ext}`;
  fs.writeFileSync(path.join(dir, filename), file.buffer, { mode: 0o640 });

  return {
    storedPath: path.posix.join('documents', String(documentId), filename),
    mimeType: detected,
    extension: spec.ext.replace('.', ''),
    size: file.size
  };
}

export function fileKind(mimeType) {
  return ALLOWED_TYPES[mimeType]?.kind || 'file';
}

export function typeLabel(mimeType) {
  return ALLOWED_TYPES[mimeType]?.label || 'File';
}

export function formatSize(bytes) {
  const size = Number(bytes) || 0;
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

// --- Tags ------------------------------------------------------------------

export function parseTags(input) {
  return String(input || '')
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t) => t.slice(0, 40))
    .slice(0, 12);
}

function setTags(documentId, names) {
  const at = nowIso();
  execute('DELETE FROM document_tag_links WHERE document_id = @id', { id: documentId });
  for (const name of names) {
    const slug = slugify(name);
    if (!slug) continue;
    execute(
      'INSERT INTO document_tags (name, slug, created_at) VALUES (@name, @slug, @at) ON CONFLICT(slug) DO NOTHING',
      { name, slug, at }
    );
    const tag = queryOne('SELECT id FROM document_tags WHERE slug = @slug', { slug });
    if (tag) {
      execute(
        'INSERT INTO document_tag_links (document_id, tag_id) VALUES (@doc, @tag) ON CONFLICT DO NOTHING',
        { doc: documentId, tag: tag.id }
      );
    }
  }
}

export function tagsFor(documentId) {
  return query(
    `SELECT t.* FROM document_tags t
       JOIN document_tag_links l ON l.tag_id = t.id
      WHERE l.document_id = @id
      ORDER BY t.name COLLATE NOCASE`,
    { id: documentId }
  );
}

export function popularTags({ limit = 30, scope = null } = {}) {
  // Only the tags (and the counts) of documents the person may open: a tag from a hidden document must not exist for them.
  const { sql: scopeSql, params: scopeParams } = scope ? scopeClause(scope) : { sql: '1 = 1', params: {} };
  return query(
    `SELECT t.name, t.slug, COUNT(*) AS uses
       FROM document_tags t
       JOIN document_tag_links l ON l.tag_id = t.id
       JOIN documents d ON d.id = l.document_id AND d.status = 'active'
       LEFT JOIN document_categories c ON c.id = d.category_id
      WHERE ${scopeSql}
      GROUP BY t.id
      ORDER BY uses DESC, t.name COLLATE NOCASE
      LIMIT @limit`,
    { limit, ...scopeParams }
  );
}

// --- Relationships ---------------------------------------------------------

function setRelationships(documentId, relations) {
  const at = nowIso();
  execute('DELETE FROM document_relationships WHERE document_id = @id', { id: documentId });
  for (const relation of relations) {
    if (!RELATION_TYPES.includes(relation.type) || !relation.id) continue;
    execute(
      `INSERT INTO document_relationships (document_id, related_type, related_id, created_at)
       VALUES (@doc, @type, @rel, @at) ON CONFLICT DO NOTHING`,
      { doc: documentId, type: relation.type, rel: Number(relation.id), at }
    );
  }
}

export function relationshipsFor(documentId) {
  const rows = query('SELECT * FROM document_relationships WHERE document_id = @id', { id: documentId });
  return rows.map((row) => {
    let label = null;
    if (row.related_type === 'member') {
      const m = queryOne('SELECT first_name, last_name, preferred_name, member_code FROM members WHERE id = @id', { id: row.related_id });
      label = m ? displayName(m) : null;
    } else if (row.related_type === 'cell_group') {
      label = queryOne('SELECT name FROM cell_groups WHERE id = @id', { id: row.related_id })?.name || null;
    } else if (row.related_type === 'activity') {
      label = queryOne('SELECT title FROM activities WHERE id = @id', { id: row.related_id })?.title || null;
    } else if (row.related_type === 'ministry') {
      label = queryOne('SELECT name FROM ministries WHERE id = @id', { id: row.related_id })?.name || null;
    } else if (row.related_type === 'project') {
      label = queryOne('SELECT name FROM ecaq_campaigns WHERE id = @id', { id: row.related_id })?.name || null;
    }
    const href = {
      member: `/members/${row.related_id}`,
      cell_group: `/cell-groups/${row.related_id}`,
      activity: `/activities/${row.related_id}`,
      ministry: `/ministries/${row.related_id}`,
      project: '/projects/ecaq'
    }[row.related_type];

    return { ...row, label: label || 'No longer on record', href, typeLabel: RELATION_LABELS[row.related_type] };
  });
}

// --- Documents -------------------------------------------------------------

export function getDocument(id) {
  const document = queryOne(
    `SELECT d.*, c.name AS category_name, c.audience AS category_audience, c.slug AS category_slug,
            u.display_name AS uploaded_by_name
       FROM documents d
       LEFT JOIN document_categories c ON c.id = d.category_id
       LEFT JOIN users u ON u.id = d.uploaded_by
      WHERE d.id = @id`,
    { id }
  );
  if (!document) return null;
  return {
    ...document,
    audience_roles: audienceRolesFor(id),
    tags: tagsFor(id),
    relationships: relationshipsFor(id),
    kind: fileKind(document.mime_type),
    typeLabel: typeLabel(document.mime_type),
    sizeLabel: formatSize(document.file_size)
  };
}

/** Removes a file this module just wrote when the database write that would have referenced it fails (no stray files). */
function discardStored(stored) {
  if (!stored || !stored.storedPath) return;
  const full = path.resolve(config.storageDir, stored.storedPath);
  const base = path.resolve(config.storageDir);
  if (full.startsWith(base + path.sep)) fs.rmSync(full, { force: true });
}

export function createDocument(data, { userId = null, file }) {
  const at = nowIso();
  let writtenFile = null;

  try {
    return createDocumentTransaction(data, { userId, file, at }, (stored) => { writtenFile = stored; });
  } catch (err) {
    discardStored(writtenFile); // the row was rolled back; so is the file
    throw err;
  }
}

function createDocumentTransaction(data, { userId, file, at }, onStored) {
  return transaction(() => {
    const result = execute(
      `INSERT INTO documents
         (title, description, category_id, original_filename, stored_path, mime_type,
          file_extension, file_size, document_date, expiry_date, notes, amount, currency,
          vendor, status, version, uploaded_by, created_at, updated_at)
       VALUES (@title, @description, @categoryId, @originalName, '', '', '', 0,
               @documentDate, @expiryDate, @notes, @amount, @currency, @vendor,
               'active', 1, @userId, @at, @at)`,
      {
        title: data.title,
        description: data.description ?? null,
        categoryId: data.category_id ?? null,
        originalName: cleanUploadName(file.originalname),
        documentDate: data.document_date ?? null,
        expiryDate: data.expiry_date ?? null,
        notes: data.notes ?? null,
        amount: data.amount ?? null,
        currency: data.currency ?? null,
        vendor: data.vendor ?? null,
        userId,
        at
      }
    );

    const id = Number(result.lastInsertRowid);
    const stored = storeFile(id, file);
    onStored(stored);
    onRollback(() => discardStored(stored)); // if the request that holds this row is rolled back later (its audit row failed), so is the file

    execute(
      `UPDATE documents SET stored_path = @path, mime_type = @mime, file_extension = @ext,
              file_size = @size, updated_at = @at
        WHERE id = @id`,
      { id, path: stored.storedPath, mime: stored.mimeType, ext: stored.extension, size: stored.size, at }
    );

    execute(
      `INSERT INTO document_versions
         (document_id, version, original_filename, stored_path, mime_type, file_size, note, created_at, created_by)
       VALUES (@id, 1, @originalName, @path, @mime, @size, 'First upload', @at, @userId)`,
      { id, originalName: cleanUploadName(file.originalname), path: stored.storedPath, mime: stored.mimeType, size: stored.size, at, userId }
    );

    setTags(id, data.tags || []);
    setRelationships(id, data.relations || []);
    setAudience(id, data.audience);
    return getDocument(id);
  })();
}

export function updateDocument(id, data) {
  execute(
    `UPDATE documents SET title = @title, description = @description, category_id = @categoryId,
            document_date = @documentDate, expiry_date = @expiryDate, notes = @notes,
            amount = @amount, currency = @currency, vendor = @vendor, updated_at = @at
      WHERE id = @id`,
    {
      id,
      title: data.title,
      description: data.description ?? null,
      categoryId: data.category_id ?? null,
      documentDate: data.document_date ?? null,
      expiryDate: data.expiry_date ?? null,
      notes: data.notes ?? null,
      amount: data.amount ?? null,
      currency: data.currency ?? null,
      vendor: data.vendor ?? null,
      at: nowIso()
    }
  );
  setTags(id, data.tags || []);
  setRelationships(id, data.relations || []);
  if (data.audience) setAudience(id, data.audience);
  return getDocument(id);
}

/** Replacing a file keeps the one it replaced as an earlier version. */
export function replaceFile(id, file, { userId = null, note = null } = {}) {
  const document = getDocument(id);
  if (!document) return { ok: false, reason: 'not_found' };

  const at = nowIso();
  const stored = storeFile(id, file);
  onRollback(() => discardStored(stored)); // see createDocument
  const nextVersion = document.version + 1;

  try {
    replaceFileRows(id, file, { userId, note, at, stored, nextVersion });
  } catch (err) {
    discardStored(stored); // the version row was rolled back; so is the new file (the current file is untouched)
    throw err;
  }

  return { ok: true, document: getDocument(id), version: nextVersion };
}

function replaceFileRows(id, file, { userId, note, at, stored, nextVersion }) {
  transaction(() => {
    execute(
      `UPDATE documents SET stored_path = @path, mime_type = @mime, file_extension = @ext,
              file_size = @size, original_filename = @originalName, version = @version, updated_at = @at
        WHERE id = @id`,
      {
        id, path: stored.storedPath, mime: stored.mimeType, ext: stored.extension,
        size: stored.size, originalName: cleanUploadName(file.originalname), version: nextVersion, at
      }
    );
    execute(
      `INSERT INTO document_versions
         (document_id, version, original_filename, stored_path, mime_type, file_size, note, created_at, created_by)
       VALUES (@id, @version, @originalName, @path, @mime, @size, @note, @at, @userId)`,
      {
        id, version: nextVersion, originalName: cleanUploadName(file.originalname),
        path: stored.storedPath, mime: stored.mimeType, size: stored.size,
        note: note || 'File replaced', at, userId
      }
    );
  })();
}

export function versionsFor(documentId) {
  return query(
    `SELECT v.*, u.display_name AS created_by_name
       FROM document_versions v
       LEFT JOIN users u ON u.id = v.created_by
      WHERE v.document_id = @id
      ORDER BY v.version DESC`,
    { id: documentId }
  ).map((v) => ({ ...v, sizeLabel: formatSize(v.file_size), typeLabel: typeLabel(v.mime_type) }));
}

export function setStatus(id, status, { userId = null } = {}) {
  if (!DOCUMENT_STATUSES.includes(status)) return null;
  const at = nowIso();
  execute(
    `UPDATE documents SET status = @status, updated_at = @at,
            archived_at = CASE WHEN @status = 'archived' THEN @at ELSE NULL END,
            deleted_at = CASE WHEN @status = 'deleted' THEN @at ELSE NULL END
      WHERE id = @id`,
    { id, status, at }
  );
  return getDocument(id);
}

/**
 * Permanent removal. The files go, including every earlier version, but the
 * audit record of what happened stays.
 */
export function destroyDocument(id) {
  const document = getDocument(id);
  if (!document) return null;

  // The row goes first and the files only after the whole request has committed (lib/atomic.js), so a deletion that is rolled back
  // (its audit row could not be written) never leaves a document whose file is gone.
  execute('DELETE FROM documents WHERE id = @id', { id });
  afterCommit(() => {
    const dir = documentDir(id);
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  });
  return document;
}

// --- Listing and searching -------------------------------------------------

export function listDocuments({
  scope, search = '', categoryId = null, kind = null, tag = null,
  from = null, to = null, uploadedBy = null, status = 'active',
  relatedType = null, relatedId = null, expiringWithin = null,
  sort = 'newest', page = 1, pageSize = 24
} = {}) {
  const { sql: scopeSql, params: scopeParams } = scopeClause(scope);

  const params = {
    ...scopeParams,
    search: search || '',
    like: likePattern(search),
    categoryId, kind, tag, from, to, uploadedBy, status,
    relatedType, relatedId,
    expiringBefore: expiringWithin ? addDays(today(), Number(expiringWithin)) : null,
    todayDate: today(),
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  const kindClause = kind === 'pdf'
    ? "AND d.mime_type = 'application/pdf'"
    : kind === 'image'
      ? "AND d.mime_type LIKE 'image/%'"
      : '';

  const where = `
    WHERE d.status = @status
      AND ${scopeSql}
      ${kindClause}
      AND (@categoryId IS NULL OR d.category_id = @categoryId)
      AND (@from IS NULL OR COALESCE(d.document_date, substr(d.created_at, 1, 10)) >= @from)
      AND (@to IS NULL OR COALESCE(d.document_date, substr(d.created_at, 1, 10)) <= @to)
      AND (@uploadedBy IS NULL OR d.uploaded_by = @uploadedBy)
      AND (@expiringBefore IS NULL OR (d.expiry_date IS NOT NULL AND d.expiry_date <= @expiringBefore))
      AND (@tag IS NULL OR EXISTS (
            SELECT 1 FROM document_tag_links l JOIN document_tags t ON t.id = l.tag_id
             WHERE l.document_id = d.id AND t.slug = @tag))
      AND (@relatedType IS NULL OR EXISTS (
            SELECT 1 FROM document_relationships r
             WHERE r.document_id = d.id AND r.related_type = @relatedType
               AND (@relatedId IS NULL OR r.related_id = @relatedId)))
      AND (@search = '' OR d.title LIKE @like ESCAPE '\\' OR d.description LIKE @like ESCAPE '\\'
           OR d.original_filename LIKE @like ESCAPE '\\' OR d.vendor LIKE @like ESCAPE '\\' OR d.notes LIKE @like ESCAPE '\\'
           OR c.name LIKE @like ESCAPE '\\' OR u.display_name LIKE @like ESCAPE '\\'
           OR EXISTS (SELECT 1 FROM document_tag_links l JOIN document_tags t ON t.id = l.tag_id
                       WHERE l.document_id = d.id AND t.name LIKE @like ESCAPE '\\'))`;

  const order = {
    newest: 'COALESCE(d.document_date, substr(d.created_at, 1, 10)) DESC, d.id DESC',
    oldest: 'COALESCE(d.document_date, substr(d.created_at, 1, 10)) ASC, d.id ASC',
    updated: 'd.updated_at DESC, d.id DESC',
    name_az: 'd.title COLLATE NOCASE ASC, d.id ASC',
    name_za: 'd.title COLLATE NOCASE DESC, d.id DESC'
  }[sort] || 'd.created_at DESC, d.id DESC';

  const rows = query(
    `SELECT d.*, c.name AS category_name, c.slug AS category_slug,
            u.display_name AS uploaded_by_name
       FROM documents d
       LEFT JOIN document_categories c ON c.id = d.category_id
       LEFT JOIN users u ON u.id = d.uploaded_by
       ${where}
      ORDER BY ${order}
      LIMIT @limit OFFSET @offset`,
    params
  ).map((row) => ({
    ...row,
    kind: fileKind(row.mime_type),
    typeLabel: typeLabel(row.mime_type),
    sizeLabel: formatSize(row.file_size),
    tags: tagsFor(row.id),
    expiringSoon: row.expiry_date ? row.expiry_date <= addDays(today(), 30) : false,
    expired: row.expiry_date ? row.expiry_date < today() : false
  }));

  const total = queryOne(
    `SELECT COUNT(*) AS n
       FROM documents d
       LEFT JOIN document_categories c ON c.id = d.category_id
       LEFT JOIN users u ON u.id = d.uploaded_by
       ${where}`,
    params
  ).n;

  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/** Documents attached to one record, for the tabs on other pages. */
export function documentsFor(relatedType, relatedId, { scope, limit = 20 } = {}) {
  return listDocuments({
    scope, relatedType, relatedId, pageSize: limit, sort: 'newest'
  }).rows;
}

export function libraryStats({ scope }) {
  const { sql: scopeSql, params } = scopeClause(scope);
  const base = `FROM documents d LEFT JOIN document_categories c ON c.id = d.category_id WHERE ${scopeSql}`;

  const count = (extra, more = {}) => queryOne(
    `SELECT COUNT(*) AS n ${base} ${extra}`, { ...params, ...more }
  ).n;

  const receipts = queryOne(
    `SELECT COUNT(*) AS n ${base} AND d.status = 'active' AND c.slug = 'receipts'`, params
  ).n;
  const forms = queryOne(
    `SELECT COUNT(*) AS n ${base} AND d.status = 'active' AND c.slug = 'forms'`, params
  ).n;

  const bytes = queryOne(
    `SELECT COALESCE(SUM(d.file_size), 0) AS total ${base} AND d.status != 'deleted'`, params
  ).total;

  return {
    active: count("AND d.status = 'active'"),
    archived: count("AND d.status = 'archived'"),
    recent: count("AND d.status = 'active' AND d.created_at >= @since", { since: addDays(today(), -30) }),
    receipts,
    forms,
    expiring: count(
      "AND d.status = 'active' AND d.expiry_date IS NOT NULL AND d.expiry_date <= @soon",
      { soon: addDays(today(), 30) }
    ),
    storageBytes: bytes,
    storageLabel: formatSize(bytes)
  };
}

export function expiringDocuments({ scope, withinDays = 30, limit = 50 } = {}) {
  return listDocuments({
    scope, expiringWithin: withinDays, sort: 'oldest', pageSize: limit
  }).rows;
}

/**
 * A gentle suggestion from the file name, never applied on its own. The person
 * uploading sees it filled in and can change it before saving.
 */
export function suggestFromFilename(filename, categories) {
  const base = String(filename || '').replace(/\.[^.]+$/, '');
  const words = base.split(/[^A-Za-z0-9]+/).filter(Boolean);
  const lower = words.map((w) => w.toLowerCase());

  const title = words
    .map((w) => (w.length > 2 ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(' ')
    .slice(0, 120);

  let category = null;
  for (const candidate of categories) {
    const name = candidate.name.toLowerCase();
    const singular = name.replace(/s$/, '');
    if (lower.some((w) => w === name || w === singular)) {
      category = candidate;
      break;
    }
  }

  const tags = [];
  for (const word of words) {
    if (/^(19|20)\d{2}$/.test(word)) tags.push(word);
    if (word.toUpperCase() === 'ECAQ') tags.push('ECAQ');
    if (word.toUpperCase() === 'CCIQ') tags.push('CCIQ');
  }

  return { title, categoryId: category ? category.id : null, tags: [...new Set(tags)] };
}
