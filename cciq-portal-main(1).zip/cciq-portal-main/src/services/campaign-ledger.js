/**
 * The campaign ledger report: one account of a campaign's money for the church office, built ONLY from the payment ledgers
 * (ecaq_payments for the Giving Board, ecaq_faith_promise_payments for Faith Promise).
 *
 *   Committed   what members promised (Giving Board commitments of active dates / Faith Promise expected totals)
 *   Received    the sum of the payments on the ledger - never a typed or stored figure
 *   Outstanding Committed minus Received, per commitment and never below zero; a waived Giving Board date owes nothing
 *
 * A payment has a PAYMENT DATE (paid_on: when the money was actually received, entered by the person recording it, never in the future) and a
 * RECORDED AT / RECORDED BY (created_at / created_by: set by the system at the moment of entry). A period filter always means the payment date,
 * so a backlog payment lands in the period it belongs to, whenever it was keyed in. The headline "Received to date" and "Outstanding" always
 * describe the whole campaign; "Received in the period" is the filtered figure.
 */
import { query } from '../db/index.js';
import { csvCell } from '../lib/csv.js';

export const LEDGER_MEMBER_SORTS = ['name', 'committed', 'received', 'outstanding', 'last_payment'];
export const LEDGER_PAYMENT_SORTS = ['payment_date', 'member', 'amount', 'method', 'recorded'];

const cents = (value) => Math.round((Number(value) || 0) * 100) / 100;

function displayName(row) {
  return [row.preferred_name || row.first_name, row.last_name].filter(Boolean).join(' ') || row.name || '';
}

/** Canonical order for names: last name, first name, then id (so equal names never swap places between page loads). */
function nameKey(row) {
  return [String(row.lastName || '').toLowerCase(), String(row.firstName || '').toLowerCase(), row.sortId];
}

function compareNames(a, b) {
  const ka = nameKey(a);
  const kb = nameKey(b);
  for (let i = 0; i < ka.length; i += 1) {
    if (ka[i] < kb[i]) return -1;
    if (ka[i] > kb[i]) return 1;
  }
  return 0;
}

function loadGivingBoard(campaignId) {
  const claims = query(
    `SELECT k.id, k.member_id, k.claim_date, k.commitment_amount, k.payment_status,
            m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_giving_board_claims k
       LEFT JOIN members m ON m.id = k.member_id
      WHERE k.campaign_id = @campaignId AND k.status = 'active'`,
    { campaignId }
  );
  const payments = query(
    `SELECT p.id, p.claim_id AS commitment_id, p.amount, p.paid_on, p.method, p.reference, p.notes, p.created_at, p.updated_at,
            u.display_name AS recorded_by_name, k.member_id, k.claim_date,
            m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_payments p
       JOIN ecaq_giving_board_claims k ON k.id = p.claim_id
       LEFT JOIN members m ON m.id = k.member_id
       LEFT JOIN users u ON u.id = p.created_by
      WHERE k.campaign_id = @campaignId`,
    { campaignId }
  );
  // One entry per commitment (a date), then folded per member.
  const commitments = claims.map((k) => ({
    id: k.id,
    memberKey: `m${k.member_id}`,
    memberId: k.member_id,
    memberCode: k.member_code || '',
    firstName: k.first_name || '',
    lastName: k.last_name || '',
    name: displayName(k),
    committed: cents(k.commitment_amount),
    waived: k.payment_status === 'waived',
    label: k.claim_date
  }));
  return { commitments, payments };
}

function loadFaithPromise(campaignId) {
  const rows = query(
    `SELECT c.id, c.member_id, c.name, c.expected_total,
            m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_faith_promise_commitments c
       LEFT JOIN members m ON m.id = c.member_id
      WHERE c.campaign_id = @campaignId`,
    { campaignId }
  );
  const payments = query(
    `SELECT p.id, p.commitment_id, p.amount, p.paid_on, p.method, p.reference, p.notes, p.received_by, p.created_at, p.updated_at,
            u.display_name AS recorded_by_name, c.member_id, c.name,
            m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_faith_promise_payments p
       JOIN ecaq_faith_promise_commitments c ON c.id = p.commitment_id
       LEFT JOIN members m ON m.id = c.member_id
       LEFT JOIN users u ON u.id = p.created_by
      WHERE c.campaign_id = @campaignId`,
    { campaignId }
  );
  const commitments = rows.map((c) => ({
    id: c.id,
    memberKey: `c${c.id}`,
    memberId: c.member_id,
    memberCode: c.member_code || '',
    firstName: c.first_name || c.name || '',
    lastName: c.last_name || '',
    name: displayName(c),
    committed: cents(c.expected_total),
    waived: false,
    label: null
  }));
  return { commitments, payments };
}

/**
 * The report. type is the campaign's type ('giving_board' | 'faith_promise'); a custom campaign has no ledger and reports empty.
 * Paging is the caller's concern (the print view and the CSV take every row), so this returns every row, sorted.
 */
export function campaignLedger(campaign, {
  from = null, to = null, search = '', memberSort = 'name', memberDirection = 'asc', paymentSort = 'payment_date', paymentDirection = 'desc'
} = {}) {
  const loaded = campaign.type === 'giving_board' ? loadGivingBoard(campaign.id)
    : campaign.type === 'faith_promise' ? loadFaithPromise(campaign.id)
      : { commitments: [], payments: [] };

  const inPeriod = (p) => (!from || p.paid_on >= from) && (!to || p.paid_on <= to);

  // Per commitment: received to date (whole ledger) so a commitment's outstanding never depends on the period filter.
  const receivedByCommitment = new Map();
  for (const p of loaded.payments) {
    receivedByCommitment.set(p.commitment_id, cents((receivedByCommitment.get(p.commitment_id) || 0) + Number(p.amount)));
  }

  // Fold commitments into one row per member (Giving Board: every date a member holds; Faith Promise: the member's one commitment).
  const byMember = new Map();
  for (const c of loaded.commitments) {
    const row = byMember.get(c.memberKey) || {
      key: c.memberKey, memberId: c.memberId, memberCode: c.memberCode, firstName: c.firstName, lastName: c.lastName, name: c.name,
      sortId: c.id, commitments: 0, committed: 0, received: 0, outstanding: 0, periodReceived: 0, payments: 0, lastPayment: null
    };
    const got = receivedByCommitment.get(c.id) || 0;
    row.commitments += 1;
    row.committed = cents(row.committed + c.committed);
    row.received = cents(row.received + got);
    row.outstanding = cents(row.outstanding + (c.waived ? 0 : Math.max(c.committed - got, 0)));
    byMember.set(c.memberKey, row);
  }
  const commitmentMember = new Map(loaded.commitments.map((c) => [c.id, c.memberKey]));
  for (const p of loaded.payments) {
    const row = byMember.get(commitmentMember.get(p.commitment_id));
    if (!row) continue; // a payment on a commitment that is not an active date (released/cancelled) is not part of this report
    row.payments += 1;
    if (!row.lastPayment || p.paid_on > row.lastPayment) row.lastPayment = p.paid_on;
    if (inPeriod(p)) row.periodReceived = cents(row.periodReceived + Number(p.amount));
  }

  // Only payments on commitments the report covers; the same set the member rows were folded from.
  const counted = loaded.payments.filter((p) => commitmentMember.has(p.commitment_id));

  const needle = String(search || '').trim().toLowerCase();
  let members = [...byMember.values()];
  if (needle) {
    members = members.filter((r) => r.name.toLowerCase().includes(needle) || r.memberCode.toLowerCase().includes(needle));
  }
  const mdir = memberDirection === 'desc' ? -1 : 1;
  members.sort((a, b) => {
    let result;
    if (memberSort === 'committed') result = a.committed - b.committed;
    else if (memberSort === 'received') result = a.received - b.received;
    else if (memberSort === 'outstanding') result = a.outstanding - b.outstanding;
    else if (memberSort === 'last_payment') result = String(a.lastPayment || '').localeCompare(String(b.lastPayment || ''));
    else result = compareNames(a, b);
    return (result || compareNames(a, b)) * mdir;
  });

  let payments = counted.filter(inPeriod).map((p) => ({
    id: p.id,
    commitmentId: p.commitment_id,
    memberId: p.member_id,
    memberCode: p.member_code || '',
    firstName: p.first_name || p.name || '',
    lastName: p.last_name || '',
    sortId: p.id,
    name: displayName(p),
    forDate: p.claim_date || null,
    amount: cents(p.amount),
    paidOn: p.paid_on,
    method: p.method,
    reference: p.reference || '',
    receivedBy: p.received_by || '',
    notes: p.notes || '',
    recordedAt: p.created_at,
    recordedBy: p.recorded_by_name || '',
    correctedAt: p.updated_at || null
  }));
  if (needle) payments = payments.filter((p) => p.name.toLowerCase().includes(needle) || p.memberCode.toLowerCase().includes(needle));
  const pdir = paymentDirection === 'asc' ? 1 : -1;
  payments.sort((a, b) => {
    let result;
    if (paymentSort === 'member') result = compareNames(a, b);
    else if (paymentSort === 'amount') result = a.amount - b.amount;
    else if (paymentSort === 'method') result = String(a.method).localeCompare(String(b.method));
    else if (paymentSort === 'recorded') result = String(a.recordedAt).localeCompare(String(b.recordedAt));
    else result = a.paidOn.localeCompare(b.paidOn);
    return (result || (a.id - b.id)) * pdir;
  });

  // Headline figures describe the WHOLE campaign (no search, no period), straight from the ledger rows above.
  const committed = cents(loaded.commitments.reduce((sum, c) => sum + c.committed, 0));
  const received = cents(counted.reduce((sum, p) => sum + Number(p.amount), 0));
  const receivedInPeriod = cents(counted.filter(inPeriod).reduce((sum, p) => sum + Number(p.amount), 0));
  const outstanding = cents([...byMember.values()].reduce((sum, r) => sum + r.outstanding, 0));

  return {
    campaign,
    filters: { from, to, search: String(search || '') },
    headline: {
      commitments: loaded.commitments.length,
      members: byMember.size,
      committed,
      received,
      receivedInPeriod,
      outstanding,
      payments: counted.length,
      paymentsInPeriod: counted.filter(inPeriod).length,
      membersWhoPaid: [...byMember.values()].filter((r) => r.payments > 0).length
    },
    members,
    payments
  };
}

/** The CSV of one table of the report. Every cell goes through csvCell, so a name or a reference starting with = + - @ cannot become a formula. */
export function ledgerCsv(report, view = 'members') {
  const cur = report.campaign.currency;
  const lines = [];
  if (view === 'payments') {
    const showFor = report.campaign.type === 'giving_board';
    lines.push(['Payment date', 'Member ID', 'Member', ...(showFor ? ['Commitment date'] : []), `Amount (${cur})`, 'Method', 'Reference', ...(showFor ? [] : ['Received by']), 'Recorded at', 'Recorded by']
      .map(csvCell).join(','));
    // "Received by" (who took the money) is a Faith Promise fact; "Recorded by" is the administrator who entered it. A blank cell means it was not recorded.
    for (const p of report.payments) {
      lines.push([p.paidOn, p.memberCode, p.name, ...(showFor ? [p.forDate || ''] : []), p.amount.toFixed(2), p.method, p.reference, ...(showFor ? [] : [p.receivedBy]), p.recordedAt, p.recordedBy]
        .map(csvCell).join(','));
    }
    return { csv: `${lines.join('\r\n')}\r\n`, count: report.payments.length };
  }
  lines.push(['Member ID', 'Member', `Committed (${cur})`, `Received (${cur})`, `Outstanding (${cur})`, 'Payments', 'Last payment date', `Received in period (${cur})`]
    .map(csvCell).join(','));
  for (const r of report.members) {
    lines.push([r.memberCode, r.name, r.committed.toFixed(2), r.received.toFixed(2), r.outstanding.toFixed(2), r.payments, r.lastPayment || '', r.periodReceived.toFixed(2)]
      .map(csvCell).join(','));
  }
  return { csv: `${lines.join('\r\n')}\r\n`, count: report.members.length };
}

/** Wording shared by the screen and print view, so the two never describe a figure differently. */
export function periodText(from, to) {
  if (from && to) return `Payments dated ${from} to ${to}`;
  if (from) return `Payments dated ${from} onward`;
  if (to) return `Payments dated up to ${to}`;
  return 'All payments';
}
