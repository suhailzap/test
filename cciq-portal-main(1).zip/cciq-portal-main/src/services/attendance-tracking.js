import { query, queryOne, execute, transaction } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { today, isValidDate, lastFridayOnOrBefore } from '../lib/dates.js';
import { evaluateExpectation as evaluateExpectationPure } from '../lib/status-as-of.js';
import { DEFAULT_ROSTER_STATUSES } from './members.js';

/*
 * The foundation of Attendance Go-Live & Finalization: the questions every
 * later feature must answer the SAME way, in one place, instead of each route
 * and report re-deriving them.
 *
 *   - Has attendance tracking started, and is this Friday on or after it?
 *   - What lifecycle phase is a session in?
 *   - Was a member expected at a given Friday - as they were THEN?
 *   - The stored, permanent record of who was expected (the snapshot).
 *
 * Nothing here changes how attendance is recorded, displayed or reported today;
 * no existing consumer calls it yet. See CCIQ_PROJECT_STATUS.md.
 */

/** The statuses whose members are expected at a Friday (and so may become absent). */
export const EXPECTED_ROSTER_STATUSES = DEFAULT_ROSTER_STATUSES;

export const FINALIZATION_STATES = ['finalized', 'not_taken'];
export const TRACKING_START_SETTING = 'attendance.tracking_start_date';

// ---------------------------------------------------------------------------
// Go-Live date and session classification
// ---------------------------------------------------------------------------

/**
 * The Attendance Tracking Start date (YYYY-MM-DD), or null when tracking has
 * not started. Blank means "not started" - there is no fallback to any older
 * behaviour. A stored value that is not a real calendar date is treated the
 * same way (never guessed at), so a bad value can only ever mean "not
 * started", never "started at some date the code picked".
 */
export function trackingStartDate() {
  const value = getSetting(TRACKING_START_SETTING);
  return typeof value === 'string' && isValidDate(value) ? value : null;
}

export function isTrackingConfigured() {
  return trackingStartDate() !== null;
}

export function isFridayService(session) {
  return Boolean(session) && session.service_type === 'friday_service';
}

/** Is `serviceDate` on or after the Go-Live date? False whenever tracking has not started. */
export function isOnOrAfterGoLive(serviceDate, goLive = trackingStartDate()) {
  return goLive !== null && typeof serviceDate === 'string' && serviceDate >= goLive;
}

/**
 * A "tracked" Friday: a Friday Service on or after the Go-Live date. Being
 * tracked says nothing about whether it happened, was cancelled or has been
 * finalized - see classifySession() for that.
 */
export function isTrackedFriday(session, { goLive = trackingStartDate() } = {}) {
  return isFridayService(session) && isOnOrAfterGoLive(session.service_date, goLive);
}

export function finalizationStateOf(session) {
  return session && FINALIZATION_STATES.includes(session.finalization_state) ? session.finalization_state : null;
}

/**
 * Where a session stands. `phase` is the single answer; the booleans are the
 * same facts for callers that ask one question.
 *
 *   not_applicable         not a Friday Service (cell group, special service, ...)
 *   not_started            a Friday, but attendance tracking has not started
 *   pre_go_live            a Friday before the Go-Live date: kept in history, never
 *                          creates an absence, follow-up or long-absence consequence
 *   cancelled              tracked, but cancelled (whatever its finalization state)
 *   finalized              tracked, attendance finalized
 *   not_taken              tracked, marked "Attendance not taken"
 *   scheduled              tracked, dated in the future
 *   open                   tracked, not finalized, and the current operational Friday
 *                          (the Friday through the following Thursday, matching
 *                          isOperationalFridaySession)
 *   awaiting_finalization  tracked, not finalized, and an earlier Friday
 *
 * Cancellation is independent of finalization: a cancelled session keeps its
 * finalization_state, and reinstating it restores its phase.
 */
export function classifySession(session, { asOf = today(), goLive = trackingStartDate() } = {}) {
  const finalizationState = finalizationStateOf(session);
  const cancelled = Boolean(session) && session.status === 'cancelled';
  const base = {
    isFriday: isFridayService(session),
    trackingConfigured: goLive !== null,
    tracked: isTrackedFriday(session, { goLive }),
    cancelled,
    finalizationState
  };
  const result = (phase) => ({
    phase,
    ...base,
    finalized: phase === 'finalized',
    notTaken: phase === 'not_taken',
    open: phase === 'open',
    awaitingFinalization: phase === 'awaiting_finalization',
    // Tracked, counts as a real service, and nobody has finalized or waived it yet.
    unfinalized: ['scheduled', 'open', 'awaiting_finalization'].includes(phase)
  });

  if (!base.isFriday) return result('not_applicable');
  if (!base.trackingConfigured) return result('not_started');
  if (!base.tracked) return result('pre_go_live');
  if (cancelled) return result('cancelled');
  if (finalizationState === 'finalized') return result('finalized');
  if (finalizationState === 'not_taken') return result('not_taken');
  if (session.service_date > asOf) return result('scheduled');
  return result(session.service_date === lastFridayOnOrBefore(asOf) ? 'open' : 'awaiting_finalization');
}

// ---------------------------------------------------------------------------
// Eligibility: who was expected at a Friday, as they were then
// ---------------------------------------------------------------------------

/**
 * Was this member expected at the Friday on `serviceDate`?
 *
 *   expected  = the member's status THAT day was one of the four expected
 *               statuses AND they had joined by then (date_joined <= service
 *               date, or no join date recorded - the existing sheet rule).
 *
 * Being outside the expected roster never stops anyone attending; it only
 * means no absence can be derived for them.
 *
 * Returns { eligible, statusAtService, certainty, basis }:
 *   - certainty 'exact' | 'inferred' | 'ambiguous' (see status-as-of.js).
 *   - eligible is NEVER true on the strength of an ambiguous answer, and an
 *     ambiguous member is never quietly treated as expected OR as safely
 *     excluded - callers get certainty:'ambiguous' to surface it (the
 *     finalization preview). A join date after the service date settles the
 *     question by itself, so it is reported as exact whatever the history says.
 */
export function evaluateExpectation({ history, currentStatus, createdAt = null, dateJoined = null, serviceDate }) {
  return evaluateExpectationPure({
    history, currentStatus, createdAt, dateJoined, serviceDate, expectedStatuses: EXPECTED_ROSTER_STATUSES
  });
}

/**
 * Everyone considered for the Friday on `serviceDate`, split into who is
 * expected, who could not be classified with certainty, and a count of the
 * rest. Read-only: it writes nothing (this is what a finalization preview
 * shows before anyone presses Finalize).
 */
export function resolveExpectedRoster(serviceDate) {
  const members = query('SELECT id, status, date_joined, created_at FROM members ORDER BY id');
  const historyByMember = new Map();
  for (const row of query(
    'SELECT id, member_id, previous_status, new_status, changed_at FROM member_status_history'
  )) {
    if (!historyByMember.has(row.member_id)) historyByMember.set(row.member_id, []);
    historyByMember.get(row.member_id).push(row);
  }

  const expected = [];
  const ambiguous = [];
  let excluded = 0;
  for (const member of members) {
    const result = evaluateExpectation({
      history: historyByMember.get(member.id) || [],
      currentStatus: member.status,
      createdAt: member.created_at,
      dateJoined: member.date_joined,
      serviceDate
    });
    if (result.certainty === 'ambiguous') {
      ambiguous.push({ memberId: member.id, reason: result.basis, currentStatus: member.status });
    } else if (result.eligible) {
      expected.push({
        memberId: member.id,
        statusAtService: result.statusAtService,
        certainty: result.certainty,
        basis: result.basis
      });
    } else {
      excluded += 1;
    }
  }
  return { serviceDate, expected, ambiguous, excludedCount: excluded, consideredCount: members.length };
}

// ---------------------------------------------------------------------------
// The expected-roster snapshot (attendance_expected)
// ---------------------------------------------------------------------------
//
// One row per member expected at one finalized Friday, written once, at
// finalization, and never rebuilt from today's member statuses. There is
// deliberately no function here that updates or removes snapshot rows.

export function hasExpectedSnapshot(sessionId) {
  return Boolean(queryOne('SELECT 1 AS x FROM attendance_expected WHERE session_id = @id LIMIT 1', { id: sessionId }));
}

export function getExpectedSnapshot(sessionId) {
  return query(
    'SELECT member_id, status_at_service FROM attendance_expected WHERE session_id = @id ORDER BY member_id',
    { id: sessionId }
  );
}

export function expectedSnapshotCount(sessionId) {
  return queryOne('SELECT COUNT(*) AS n FROM attendance_expected WHERE session_id = @id', { id: sessionId }).n;
}

/** Was this member in the historical expected roster of that session? */
export function isMemberInExpectedSnapshot(sessionId, memberId) {
  return Boolean(queryOne(
    'SELECT 1 AS x FROM attendance_expected WHERE session_id = @sessionId AND member_id = @memberId',
    { sessionId, memberId }
  ));
}

/**
 * Inserts snapshot rows for one session as a SINGLE transaction: either every
 * row is written or none is (a failure part-way - for example a member id that
 * no longer exists - rolls the whole insert back). Plain INSERT, never an
 * upsert: an existing row makes it fail rather than be overwritten.
 */
export function insertExpectedRows(sessionId, rows) {
  transaction(() => {
    for (const row of rows) {
      execute(
        'INSERT INTO attendance_expected (session_id, member_id, status_at_service) VALUES (@sessionId, @memberId, @status)',
        { sessionId, memberId: row.memberId, status: row.statusAtService }
      );
    }
  })();
  return rows.length;
}

/**
 * What finalizing this session would snapshot, without writing anything. If a
 * snapshot already exists it is authoritative and is what is returned - the
 * live computation is not shown as though it could replace it.
 */
export function previewExpectedSnapshot(sessionId) {
  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  if (!session) return { ok: false, reason: 'session_not_found' };
  if (hasExpectedSnapshot(sessionId)) {
    return {
      ok: true, existing: true, serviceDate: session.service_date,
      expected: getExpectedSnapshot(sessionId).map((r) => ({ memberId: r.member_id, statusAtService: r.status_at_service })),
      ambiguous: [], excludedCount: null
    };
  }
  return { ok: true, existing: false, ...resolveExpectedRoster(session.service_date) };
}

/**
 * Creates the historical expected-roster snapshot for a tracked Friday. Called
 * by finalization (a later phase); it does not itself finalize anything.
 *
 *   - Refuses a session that is not a tracked Friday, is cancelled, or is dated
 *     in the future.
 *   - If a snapshot already exists it is REUSED, untouched (`reused: true`) -
 *     reopening and re-finalizing a service must never rebuild history from
 *     today's statuses.
 *   - Members whose status that day cannot be established with certainty are
 *     never silently included or excluded: creation is refused
 *     (`ambiguous_history`, listing them, writing nothing) until the caller
 *     acknowledges them (`acknowledgeAmbiguous: true`), in which case they are
 *     left OUT - an uncertain history never manufactures an expectation, and
 *     so never an absence.
 *   - All rows are written in one transaction, re-checking for an existing
 *     snapshot inside it.
 */
export function createExpectedSnapshot(sessionId, { acknowledgeAmbiguous = false, asOf = today() } = {}) {
  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  if (!session) return { ok: false, reason: 'session_not_found' };
  if (!isFridayService(session)) return { ok: false, reason: 'not_friday_service' };
  if (session.status === 'cancelled') return { ok: false, reason: 'session_cancelled' };
  if (!isTrackedFriday(session)) return { ok: false, reason: 'not_tracked' };
  if (session.service_date > asOf) return { ok: false, reason: 'session_in_future' };

  if (hasExpectedSnapshot(sessionId)) {
    return { ok: true, created: false, reused: true, count: expectedSnapshotCount(sessionId) };
  }

  const roster = resolveExpectedRoster(session.service_date);
  if (roster.ambiguous.length > 0 && !acknowledgeAmbiguous) {
    return { ok: false, reason: 'ambiguous_history', ambiguous: roster.ambiguous };
  }

  return transaction(() => {
    if (hasExpectedSnapshot(sessionId)) {
      return { ok: true, created: false, reused: true, count: expectedSnapshotCount(sessionId) };
    }
    insertExpectedRows(sessionId, roster.expected);
    return {
      ok: true, created: true, reused: false,
      count: roster.expected.length,
      excludedAmbiguous: roster.ambiguous
    };
  })();
}
