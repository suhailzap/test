import { query, queryOne } from '../db/index.js';
import {
  MEMBER_STATUSES, STATUS_LABELS, CURRENT_POPULATION_STATUSES, DEFAULT_ROSTER_STATUSES,
  statusCounts, currentPopulationCount, scopeClause
} from './members.js';
import { cellGroupAttendanceSummary } from './attendance.js';
import { buildFridayContexts, memberOutcomeAt, pooledRate } from './attendance-outcomes.js';
import { listGroups } from './cell-groups.js';
import { today, addDays } from '../lib/dates.js';
import { csvCell } from '../lib/csv.js';
import { serviceHeadcounts } from './service-headcount.js';

const ROSTER_SQL = DEFAULT_ROSTER_STATUSES.map((s) => `'${s}'`).join(',');
const CURRENT_SQL = CURRENT_POPULATION_STATUSES.map((s) => `'${s}'`).join(',');
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** Lifecycle wording for the per-Friday reports and exports. */
export const PHASE_LABELS = {
  finalized: 'Finalized', open: 'Open', scheduled: 'Scheduled', awaiting_finalization: 'Awaiting finalization',
  not_taken: 'Attendance not taken', cancelled: 'Cancelled', pre_go_live: 'Not tracked (before tracking start)',
  not_started: 'Not tracked (tracking not started)'
};

/**
 * One whitelisted date-range parser reused by every new report route
 * (previously each route reimplemented this same regex-and-default check —
 * see the pre-existing copies in routes/attendance.js and routes/reports.js,
 * left as they are since they predate this workstream and are not broken).
 * Only a value matching YYYY-MM-DD is ever accepted from the query string;
 * anything else falls back to the default, so this can never reach a SQL
 * query with an unexpected shape.
 */
export function parseReportRange(query = {}, { defaultDays = 84 } = {}) {
  const from = DATE_RE.test(query.from || '') ? query.from : addDays(today(), -defaultDays);
  const to = DATE_RE.test(query.to || '') ? query.to : today();
  return { from, to };
}

/** Same whitelisting for the cell-group filter every new report route shares. */
export function parseCellGroupFilter(query = {}) {
  return Number.parseInt(query.cell_group_id, 10) || null;
}

/**
 * The Friday attendance trend and its aggregate rate over a date range.
 *
 * Every figure comes from the canonical outcome resolver
 * (attendance-outcomes.js), in bulk - one pass over the range, no per-session
 * queries. Per Friday:
 *   - FINALIZED, tracked: the historical expected snapshot is the roster;
 *     present = expected members with positive attendance (a member-linked
 *     Visitor row counts); absent = recorded + derived absence; the Friday's
 *     own rate = present / (expected - Vacation); null when nothing is
 *     measurable (never 0% and never a divide-by-zero).
 *   - open / awaiting finalization: reported with their state, counts of what
 *     is recorded, and NO rate and no absence - they are not final.
 *   - Attendance Not Taken and cancelled: labelled, no rate, no absence.
 *   - before tracking (or tracking not started): recorded history, labelled
 *     not tracked, no rate, no absence.
 *
 * The overall rate is WEIGHTED across the finalized Fridays:
 * SUM(expected who attended) / SUM(expected - Vacation) - never an average of
 * each Friday's own percentage. People who attended without being expected are
 * counted as `unexpected` (headcount) and never enter the rate.
 *
 * A cell-group filter uses members' CURRENT cell group (the snapshot records who
 * was expected, not which group they belonged to), so a per-group split is not
 * historically stable; the church-wide figures are.
 */
export function fridayAttendanceOverview({ from, to, cellGroupId = null } = {}) {
  const groupFilter = cellGroupId || null;
  const every = buildFridayContexts({ from: from || null, to: to || null, countingOnly: true });
  const contexts = every.filter((c) => c.phase !== 'cancelled').reverse();
  const cancelled = every.length - contexts.length;

  const inGroup = groupFilter
    ? new Set(query('SELECT id FROM members WHERE cell_group_id = @g', { g: groupFilter }).map((m) => m.id))
    : null;
  const allowed = (memberId) => !inGroup || inGroup.has(memberId);

  // First Timers per Friday come from the one headcount definition (service-headcount.js), the same one the register, history and dashboard use.
  const headcounts = serviceHeadcounts(contexts.map((c) => c.id));

  const totals = { present: 0, excused: 0, visitors: 0, absent: 0, unexpected: 0, total: 0 };
  const lifecycle = { finalized: 0, unsettled: 0, notTaken: 0, beforeTracking: 0, cancelled };
  const parts = [];
  let latestRoster = null;

  const sessions = contexts.map((ctx) => {
    const row = {
      sessionId: ctx.id, date: ctx.date, phase: ctx.phase,
      final: ctx.phase === 'finalized',
      present: 0, excused: 0, visitors: groupFilter ? 0 : (headcounts.get(ctx.id)?.visitors || 0),
      absent: 0, notRecorded: 0, unexpected: 0, expected: 0,
      numerator: 0, denominator: 0, rate: null, total: 0
    };

    if (ctx.phase === 'not_started' || ctx.phase === 'pre_go_live') {
      lifecycle.beforeTracking += 1;
      for (const [memberId, status] of ctx.rows) {
        if (!allowed(memberId)) continue;
        if (status === 'present' || status === 'visitor') row.present += 1;
        else if (status === 'excused') row.excused += 1;
        else if (status === 'absent') row.absent += 1;
      }
      row.notRecorded = null; // not tracked: nothing is "missing"
      row.total = row.present + row.visitors;
      return row;
    }
    if (ctx.phase === 'not_taken') {
      lifecycle.notTaken += 1;
      for (const [memberId, status] of ctx.rows) {
        if (allowed(memberId) && (status === 'present' || status === 'visitor')) row.present += 1;
      }
      row.notRecorded = null;
      row.total = row.present + row.visitors;
      return row;
    }

    if (ctx.phase === 'finalized') lifecycle.finalized += 1; else lifecycle.unsettled += 1;
    for (const memberId of ctx.roster ? ctx.roster.keys() : []) {
      if (!allowed(memberId)) continue;
      row.expected += 1;
      const r = memberOutcomeAt(ctx, memberId);
      if (r.state === 'present') row.present += 1;
      else if (r.state === 'vacation') row.excused += 1;
      else if (r.state === 'absent') { if (row.final || ctx.rows.get(memberId) === 'absent') row.absent += 1; }
      else row.notRecorded += 1;
      if (row.final) {
        if (r.rateNumerator) row.numerator += 1;
        if (r.rateDenominator) row.denominator += 1;
      }
    }
    for (const [memberId, status] of ctx.rows) {
      if (!allowed(memberId) || (ctx.roster && ctx.roster.has(memberId))) continue;
      if (status === 'present' || status === 'visitor') row.unexpected += 1;
    }
    // Total present: everyone who was there (expected members present, members who were not expected, First Timers). First Timers never enter the rate.
    row.total = row.present + row.unexpected + row.visitors;
    if (row.final) {
      row.rate = row.denominator > 0 ? Math.round((row.numerator / row.denominator) * 100) : null;
      parts.push({ numerator: row.numerator, denominator: row.denominator });
      latestRoster = row.expected;
      totals.present += row.present;
      totals.excused += row.excused;
      totals.absent += row.absent;
      totals.visitors += row.visitors;
      totals.unexpected += row.unexpected;
      totals.total += row.total;
    }
    return row;
  });

  const overall = pooledRate(parts);
  return {
    sessions,
    // The expected roster of the most recent finalized Friday in the range (null if none).
    rosterSize: latestRoster,
    rate: overall.rate,
    rateNumerator: overall.numerator,
    rateDenominator: overall.denominator,
    totalPresent: totals.present,
    totalVisitors: totals.visitors,
    totalAbsent: totals.absent,
    totalExcused: totals.excused,
    totalUnexpected: totals.unexpected,
    totalHeadcount: totals.total,
    lifecycle
  };
}

/**
 * Whitelisted sort keys for the "By Friday Service" table — never pass a
 * query-string column name straight into a comparator or, worse, SQL.
 * `date` is the only column also meaningful to the trend chart above the
 * table, but the chart always renders chronologically regardless of this;
 * this sort affects the table only, so the chart is never reversed by it.
 */
export const FRIDAY_SESSION_SORT_COLUMNS = ['date', 'present', 'excused', 'visitors', 'total', 'absent', 'notRecorded', 'rate'];

/** Sorted copy of fridayAttendanceOverview()'s sessions, for the table only — the chart keeps its own chronological copy. */
export function sortFridaySessions(sessions, sort = 'date', direction = 'desc') {
  const key = FRIDAY_SESSION_SORT_COLUMNS.includes(sort) ? sort : 'date';
  const dirMul = direction === 'asc' ? 1 : -1;
  return [...sessions].sort((a, b) => {
    const av = a[key];
    const bv = b[key];
    if (av === null && bv === null) return 0;
    if (av === null) return 1;
    if (bv === null) return -1;
    if (av < bv) return -1 * dirMul;
    if (av > bv) return 1 * dirMul;
    return 0;
  });
}

/**
 * Current vs total population, and the current population's distribution
 * across the authoritative lifecycle statuses — the numbers the existing
 * Reports landing page's stat card got wrong by showing only `active` and
 * calling it representative. Nothing here invents a status; every count
 * comes from the same statusCounts()/currentPopulationCount() every other
 * screen already uses.
 */
export function membershipOverview(scope) {
  const counts = statusCounts(scope);
  const current = currentPopulationCount(scope);
  const currentByStatus = CURRENT_POPULATION_STATUSES.map((key) => ({
    key, label: STATUS_LABELS[key], count: counts[key] || 0
  })).filter((row) => row.count > 0);
  const historicalByStatus = MEMBER_STATUSES.filter((s) => !CURRENT_POPULATION_STATUSES.includes(s))
    .map((key) => ({ key, label: STATUS_LABELS[key], count: counts[key] || 0 }))
    .filter((row) => row.count > 0);

  // Scoped the same way statusCounts()/getMember() are — otherwise a
  // cell_group_leader's "unassigned members" figure would leak the
  // portal-wide count instead of being restricted to their own scope.
  const clause = scopeClause(scope);
  const unassigned = queryOne(
    `SELECT COUNT(*) AS n FROM members m
      WHERE m.status IN (${CURRENT_SQL}) AND (m.cell_group_id IS NULL OR m.cell_group_id = 0)
        AND ${clause.sql}`,
    clause.params
  ).n;

  return {
    total: counts.total,
    current,
    historical: counts.total - current,
    currentByStatus,
    historicalByStatus,
    unassigned
  };
}

/**
 * One row per active cell group: current roster size and a recent
 * attendance rate, reusing cellGroupAttendanceSummary()'s existing
 * per-group calculation rather than a new one — 20-ish groups is a small,
 * bounded number, so one call per group stays well inside the "reasonable
 * growth" this was built for, without a leaderboard or ranking (never
 * sorted by rate, only ever by name).
 *
 * Scoped the same way member queries are: a cell_group_leader's scope
 * restricts this to only the group(s) they lead, not the whole portal.
 */
export function cellGroupsOverview({ lastN = 8, scope = { type: 'all' } } = {}) {
  let groups = listGroups({ includeInactive: false });
  if (scope.type === 'cell_group') {
    const ids = new Set((scope.cellGroupIds || []).map(Number));
    groups = groups.filter((g) => ids.has(g.id));
  } else if (scope.type === 'self' || scope.type === 'none') {
    groups = [];
  }
  return groups.map((g) => {
    const rosterCount = queryOne(
      `SELECT COUNT(*) AS n FROM members WHERE status IN (${ROSTER_SQL}) AND cell_group_id = @id`,
      { id: g.id }
    ).n;
    const summary = rosterCount > 0 ? cellGroupAttendanceSummary(g.id, { lastN }) : null;
    return {
      id: g.id,
      name: g.name,
      leaderName: [g.leader_preferred || g.leader_first, g.leader_last].filter(Boolean).join(' ') || null,
      memberCount: g.member_count,
      rosterCount,
      recentRate: summary ? summary.averageRate : null,
      recentServices: summary ? summary.sessions.length : 0
    };
  });
}

/**
 * CSV twin of fridayAttendanceOverview()'s trend, reusing the centralized
 * csvCell escaping. `sort`/`direction` mirror the on-screen table's own
 * whitelisted sort, so the export always matches whatever order the user
 * was looking at rather than always exporting chronological order.
 */
export function fridayAttendanceOverviewCsv({ sort = 'date', direction = 'desc', ...options } = {}) {
  const overview = fridayAttendanceOverview(options);
  const rows = sortFridaySessions(overview.sessions, sort, direction);
  const header = ['Date', 'Status', 'Expected', 'Present', 'Vacation', 'Visitors', 'Absent', 'Pending', 'Others present', 'Total present', 'Attendance %'];
  const lines = [header.map(csvCell).join(',')];
  for (const row of rows) {
    lines.push([
      row.date, PHASE_LABELS[row.phase] || row.phase, row.expected || '', row.present, row.excused, row.visitors,
      row.absent, row.notRecorded == null ? '' : row.notRecorded, row.unexpected || '', row.total,
      row.rate == null ? '' : row.rate
    ].map(csvCell).join(','));
  }
  return { csv: lines.join('\n'), overview };
}

/** CSV twin of membershipOverview()'s status breakdown. */
export function membershipOverviewCsv(scope) {
  const overview = membershipOverview(scope);
  const header = ['Status', 'Count', 'Population'];
  const lines = [header.map(csvCell).join(',')];
  for (const row of overview.currentByStatus) {
    lines.push([row.label, row.count, 'Current'].map(csvCell).join(','));
  }
  for (const row of overview.historicalByStatus) {
    lines.push([row.label, row.count, 'Historical'].map(csvCell).join(','));
  }
  return { csv: lines.join('\n'), overview };
}

/** CSV twin of cellGroupsOverview(). */
export function cellGroupsOverviewCsv(options = {}) {
  const groups = cellGroupsOverview(options);
  const header = ['Cell group', 'Leader', 'Members', 'On Friday roster', 'Recent attendance %', 'Recent services'];
  const lines = [header.map(csvCell).join(',')];
  for (const g of groups) {
    lines.push([
      g.name, g.leaderName || '', g.memberCount, g.rosterCount,
      g.recentRate == null ? '' : g.recentRate, g.recentServices
    ].map(csvCell).join(','));
  }
  return { csv: lines.join('\n'), groups };
}
