import { query } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { congregationFor, AGE_GROUP_LABELS } from './congregations.js';
import { scopeFor, displayName } from './members.js';
import { canViewAnnouncement } from './announcements.js';
import { listDocuments, scopeFor as documentScope } from './documents.js';
import { buildNavigation } from '../lib/navigation.js';
import { phoneDigitsSql, phoneFragmentLike } from '../lib/phone.js';

/**
 * One search box reaching everything a user is allowed to see. Each source
 * applies its own permission rules, exactly as its own screen does, so search
 * can never become a way around them.
 */
export const RESULT_KINDS = {
  member: { label: 'Members', icon: 'people' },
  visitor: { label: 'First Timers', icon: 'person' },
  cell_group: { label: 'Cell groups', icon: 'group' },
  activity: { label: 'Activities', icon: 'calendar-star' },
  announcement: { label: 'Announcements', icon: 'megaphone' },
  ministry: { label: 'Ministries', icon: 'group' },
  service: { label: 'Services', icon: 'calendar' },
  claim: { label: 'Giving Board', icon: 'building' },
  document: { label: 'Documents', icon: 'folder' },
  page: { label: 'Pages', icon: 'home' }
};

function like(term) {
  return likePattern(term);
}

function memberResults(user, term, limit) {
  if (!user.can('members.view')) return [];
  const scope = scopeFor(user);

  // The same scoping the member list uses: leaders see their groups, a member
  // sees only themselves.
  let scopeClause = '1 = 1';
  const params = { like: like(term), limit };
  if (scope.type === 'none') return [];
  if (scope.type === 'self') {
    scopeClause = 'm.id = @selfId';
    params.selfId = scope.memberId || 0;
  } else if (scope.type === 'cell_group') {
    const ids = scope.cellGroupIds || [];
    if (ids.length === 0) return [];
    scopeClause = `m.cell_group_id IN (${ids.map((id, i) => {
      params[`g${i}`] = id;
      return `@g${i}`;
    }).join(',')})`;
  }

  const showContact = user.can('members.view_contact');

  return query(
    `SELECT m.id, m.member_code, m.first_name, m.middle_name, m.last_name, m.preferred_name,
            m.status, m.date_of_birth, m.age_group, m.phone, m.email, m.company,
            g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE ${scopeClause}
        AND (m.first_name LIKE @like ESCAPE '\\' OR m.middle_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\'
             OR m.preferred_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
             OR (@showContact = 1 AND (m.phone LIKE @like ESCAPE '\\' OR m.email LIKE @like ESCAPE '\\'
                                       OR (@phoneLike IS NOT NULL AND ${phoneDigitsSql('m.phone')} LIKE @phoneLike)))
             OR m.company LIKE @like ESCAPE '\\'
             OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\')
      ORDER BY m.status = 'active' DESC, m.last_name COLLATE NOCASE
      LIMIT @limit`,
    // A number or an address is only a way to FIND someone for a person who may see contact details: otherwise a search for it would still confirm who holds it.
    { ...params, showContact: showContact ? 1 : 0, phoneLike: phoneFragmentLike(term) }
  ).map((m) => {
    const congregation = congregationFor(m);
    const detail = [
      m.member_code,
      m.cell_group_name,
      congregation ? AGE_GROUP_LABELS[congregation] : null,
      showContact ? m.phone : null
    ].filter(Boolean).join(' · ');

    return {
      kind: 'member',
      title: displayName(m),
      detail,
      status: m.status,
      href: `/members/${m.id}`
    };
  });
}

function visitorResults(user, term, limit) {
  if (!user.can('members.view')) return [];
  return query(
    `SELECT v.id, v.first_name, v.last_name, v.phone, v.state, v.first_visit_date,
            m.first_name AS inviter_first, m.last_name AS inviter_last
       FROM visitors v
       LEFT JOIN members m ON m.id = v.invited_by_member_id
      WHERE v.first_name LIKE @like ESCAPE '\\' OR v.last_name LIKE @like ESCAPE '\\'
         OR (@showContact = 1 AND (v.phone LIKE @like ESCAPE '\\' OR (@phoneLike IS NOT NULL AND ${phoneDigitsSql('v.phone')} LIKE @phoneLike)))
         OR v.invited_by_name LIKE @like ESCAPE '\\'
      ORDER BY v.first_visit_date DESC
      LIMIT @limit`,
    { like: like(term), limit, showContact: user.can('members.view_contact') ? 1 : 0, phoneLike: phoneFragmentLike(term) }
  ).map((v) => ({
    kind: 'visitor',
    title: [v.first_name, v.last_name].filter(Boolean).join(' '),
    detail: [
      `First visited ${v.first_visit_date}`,
      v.inviter_first ? `invited by ${v.inviter_first} ${v.inviter_last || ''}`.trim() : null
    ].filter(Boolean).join(' · '),
    href: `/visitors/${v.id}`
  }));
}

function cellGroupResults(user, term, limit) {
  const seesAll = user.can('cellgroups.view') || user.can('cellgroups.manage');
  const reachable = new Set([
    ...(user.ledCellGroupIds || []).map(Number),
    ...(user.member?.cell_group_id ? [Number(user.member.cell_group_id)] : [])
  ]);
  if (!seesAll && reachable.size === 0) return [];

  return query(
    `SELECT g.id, g.name, g.meeting_day, g.meeting_location, g.status,
            l.first_name AS leader_first, l.last_name AS leader_last,
            (SELECT COUNT(*) FROM members m WHERE m.cell_group_id = g.id AND m.status != 'archived') AS member_count
       FROM cell_groups g
       LEFT JOIN members l ON l.id = g.leader_member_id
      WHERE g.name LIKE @like ESCAPE '\\' OR g.meeting_location LIKE @like ESCAPE '\\'
         OR l.first_name LIKE @like ESCAPE '\\' OR l.last_name LIKE @like ESCAPE '\\'
      ORDER BY g.name COLLATE NOCASE
      LIMIT @limit`,
    { like: like(term), limit }
  )
    .filter((g) => seesAll || reachable.has(Number(g.id)))
    .map((g) => ({
      kind: 'cell_group',
      title: g.name,
      detail: [
        g.leader_first ? `led by ${g.leader_first} ${g.leader_last || ''}`.trim() : null,
        `${g.member_count} member${g.member_count === 1 ? '' : 's'}`,
        g.meeting_day
      ].filter(Boolean).join(' · '),
      href: `/cell-groups/${g.id}`
    }));
}

function activityResults(user, term, limit) {
  if (!user.can('activities.view')) return [];
  const manageAll = user.can('activities.manage');
  const seesAllGroups = user.can('cellgroups.view') || user.can('cellgroups.manage');
  const reachable = new Set([
    ...(user.ledCellGroupIds || []).map(Number),
    ...(user.member?.cell_group_id ? [Number(user.member.cell_group_id)] : [])
  ]);

  return query(
    `SELECT a.id, a.title, a.scope, a.cell_group_id, a.activity_date, a.status, a.location,
            g.name AS cell_group_name
       FROM activities a
       LEFT JOIN cell_groups g ON g.id = a.cell_group_id
      WHERE a.title LIKE @like ESCAPE '\\' OR a.description LIKE @like ESCAPE '\\' OR a.location LIKE @like ESCAPE '\\'
      ORDER BY a.activity_date IS NULL, a.activity_date DESC
      LIMIT @limit`,
    { like: like(term), limit }
  )
    .filter((a) => {
      // Drafts belong to whoever manages them; published cell group activities
      // to that group.
      const managesThis = manageAll
        || (user.can('activities.manage_own_group') && (user.ledCellGroupIds || []).includes(Number(a.cell_group_id)));
      if (a.status !== 'published') return managesThis;
      if (a.scope === 'church') return true;
      return seesAllGroups || reachable.has(Number(a.cell_group_id)) || managesThis;
    })
    .map((a) => ({
      kind: 'activity',
      title: a.title,
      detail: [
        a.scope === 'church' ? 'Church activity' : a.cell_group_name,
        a.activity_date,
        a.status !== 'published' ? a.status : null
      ].filter(Boolean).join(' · '),
      href: `/activities/${a.id}`
    }));
}

function announcementResults(user, term, limit) {
  if (!user.can('announcements.view')) return [];

  return query(
    `SELECT id, title, body, audience, status, publish_at, expires_at, priority
       FROM announcements
      WHERE title LIKE @like ESCAPE '\\' OR body LIKE @like ESCAPE '\\'
      ORDER BY COALESCE(publish_at, created_at) DESC
      LIMIT @limit`,
    { like: like(term), limit }
  )
    // Codex/R07: this used to reimplement its own copy of the status/date/
    // audience checks inline, including its own 'administrators' ->
    // members.view predicate that never got the fix applied to
    // canSeeAudience() - a default Cell Group Leader could discover an
    // Administrators-only announcement's title through search even though
    // the main list and direct view were both correctly protected.
    // canViewAnnouncement() is the one place this logic lives now; every
    // discovery path (list, direct view, search) calls it, so a future
    // fix to audience rules only ever needs to happen once.
    .filter((a) => canViewAnnouncement(user, a))
    .map((a) => ({
      kind: 'announcement',
      title: a.title,
      detail: [a.priority === 'high' ? 'Important' : null, a.status !== 'published' ? a.status : null]
        .filter(Boolean).join(' · ') || 'Announcement',
      href: `/announcements/${a.id}`
    }));
}

function ministryResults(user, term, limit) {
  if (!user.can('ministries.view')) return [];
  return query(
    `SELECT m.id, m.name, m.status, m.meets,
            l.first_name AS leader_first, l.last_name AS leader_last,
            (SELECT COUNT(*) FROM ministry_members mm
              WHERE mm.ministry_id = m.id AND mm.left_at IS NULL) AS member_count
       FROM ministries m
       LEFT JOIN members l ON l.id = m.leader_member_id
      WHERE m.name LIKE @like ESCAPE '\\' OR m.description LIKE @like ESCAPE '\\'
         OR l.first_name LIKE @like ESCAPE '\\' OR l.last_name LIKE @like ESCAPE '\\'
      ORDER BY m.sort_order, m.name COLLATE NOCASE
      LIMIT @limit`,
    { like: like(term), limit }
  ).map((m) => ({
    kind: 'ministry',
    title: m.name,
    detail: [
      m.leader_first ? `led by ${m.leader_first} ${m.leader_last || ''}`.trim() : null,
      `${m.member_count} serving`,
      m.meets
    ].filter(Boolean).join(' · '),
    href: `/ministries/${m.id}`
  }));
}

function serviceResults(user, term, limit) {
  if (!user.can('attendance.view')) return [];
  return query(
    `SELECT id, service_date, service_type, title, status, location
       FROM attendance_sessions
      WHERE (title LIKE @like ESCAPE '\\' OR service_date LIKE @like ESCAPE '\\' OR location LIKE @like ESCAPE '\\')
        AND cell_group_id = 0
      ORDER BY service_date DESC
      LIMIT @limit`,
    { like: like(term), limit }
  ).map((s) => ({
    kind: 'service',
    title: `${s.title || 'Service'} — ${s.service_date}`,
    detail: [s.status, s.location].filter(Boolean).join(' · '),
    href: `/attendance/sessions/${s.id}`
  }));
}

function claimResults(user, term, limit) {
  if (!user.can('giving.manage')) return [];
  return query(
    `SELECT k.id, k.claim_date, k.payment_status, k.display_as, c.year,
            m.first_name, m.last_name, m.preferred_name, m.member_code
       FROM ecaq_giving_board_claims k
       JOIN ecaq_campaigns c ON c.id = k.campaign_id
       LEFT JOIN members m ON m.id = k.member_id
      WHERE k.claim_date LIKE @like ESCAPE '\\' OR k.display_as LIKE @like ESCAPE '\\'
         OR m.first_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
      ORDER BY k.claim_date
      LIMIT @limit`,
    { like: like(term), limit }
  ).map((k) => ({
    kind: 'claim',
    title: `${k.claim_date} — ${[k.preferred_name || k.first_name, k.last_name].filter(Boolean).join(' ') || 'Unassigned'}`,
    detail: [`${k.year} campaign`, k.payment_status.replace('_', ' ')].join(' · '),
    href: `/admin/ecaq/claims/${k.id}`
  }));
}

/**
 * Documents: exactly the library's own search, through the library's own audience rule (documents.js scopeFor / scopeClause). A document a person may not open is
 * never matched, so no title, snippet or count of it exists in their results.
 */
function documentResults(user, term, limit) {
  if (!user.can('documents.view')) return [];
  const scope = documentScope(user);
  if (scope.type === 'none') return [];
  return listDocuments({ scope, search: term, pageSize: limit, sort: 'newest' }).rows.map((d) => ({
    kind: 'document',
    title: d.title,
    detail: [d.category_name, d.typeLabel].filter(Boolean).join(' · '),
    href: `/documents/${d.id}`
  }));
}

/** The portal's own pages by name, from the one navigation definition after it has been filtered by permission: a page the person cannot open is never offered. */
function pageResults(user, term, limit) {
  const needle = String(term || '').trim().toLowerCase();
  if (!needle) return [];
  const seen = new Set();
  const out = [];
  for (const item of buildNavigation(user, '')) {
    for (const entry of [item, ...(item.children || [])]) {
      if (!entry.href || entry.href.includes('?') || seen.has(entry.href)) continue;
      if (!String(entry.label || '').toLowerCase().includes(needle)) continue;
      seen.add(entry.href);
      out.push({ kind: 'page', title: entry.label, detail: entry === item ? 'Section' : `In ${item.label}`, href: entry.href });
    }
  }
  return out.slice(0, limit);
}

export function search(user, term, { perKind = 6 } = {}) {
  const clean = String(term || '').trim();
  if (clean.length < 2) return { term: clean, groups: [], total: 0, tooShort: clean.length > 0 };

  const groups = [
    { kind: 'member', results: memberResults(user, clean, perKind) },
    { kind: 'visitor', results: visitorResults(user, clean, perKind) },
    { kind: 'cell_group', results: cellGroupResults(user, clean, perKind) },
    { kind: 'ministry', results: ministryResults(user, clean, perKind) },
    { kind: 'activity', results: activityResults(user, clean, perKind) },
    { kind: 'announcement', results: announcementResults(user, clean, perKind) },
    { kind: 'service', results: serviceResults(user, clean, perKind) },
    { kind: 'claim', results: claimResults(user, clean, perKind) },
    { kind: 'document', results: documentResults(user, clean, perKind) },
    { kind: 'page', results: pageResults(user, clean, perKind) }
  ].filter((group) => group.results.length > 0);

  return {
    term: clean,
    groups: groups.map((group) => ({ ...group, ...RESULT_KINDS[group.kind] })),
    total: groups.reduce((sum, group) => sum + group.results.length, 0),
    tooShort: false
  };
}
