import { query, queryOne, execute } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso, today } from '../lib/dates.js';

export const ANNOUNCEMENT_STATUSES = ['draft', 'published', 'archived'];
export const PRIORITIES = ['low', 'normal', 'high'];

/**
 * Who an announcement is for. Each audience maps to a permission, so targeting
 * follows the same rules as the rest of the portal rather than a second set.
 */
export const AUDIENCES = {
  all: { label: 'Everyone', permission: 'announcements.view' },
  members: { label: 'Members', permission: 'announcements.view' },
  leaders: { label: 'Cell group leaders', permission: 'cellgroups.manage_own' },
  // admin.settings, not members.view: every default Cell Group Leader
  // already holds members.view for ordinary roster duties, which meant
  // "Administrators"-audience announcements were reaching every leader too.
  // admin.settings is held by church_admin/super_admin by default and not
  // by LEADER, so it actually represents the label. Also read directly by
  // audienceUserIds() below to decide who gets notified.
  administrators: { label: 'Administrators', permission: 'admin.settings' }
};

export const PRIORITY_LABELS = { low: 'Low', normal: 'Normal', high: 'Important' };
export const STATUS_LABELS = { draft: 'Draft', published: 'Published', archived: 'Archived' };

/** An announcement reaches a user when its audience matches their role. */
export function canSeeAudience(user, audience) {
  if (!user) return false;
  if (audience === 'all' || audience === 'members') return user.can('announcements.view');
  if (audience === 'leaders') return user.can('cellgroups.manage_own') || user.can('announcements.manage');
  if (audience === 'administrators') return user.can('announcements.manage') || user.can(AUDIENCES.administrators.permission);
  return false;
}

export function canManage(user) {
  return Boolean(user && user.can('announcements.manage'));
}

/** Published, within its dates, and aimed at this user. */
export function isLive(announcement, asOf = today()) {
  if (announcement.status !== 'published') return false;
  const startsOn = (announcement.publish_at || '').slice(0, 10);
  const endsOn = (announcement.expires_at || '').slice(0, 10);
  if (startsOn && startsOn > asOf) return false;
  if (endsOn && endsOn < asOf) return false;
  return true;
}

export function canViewAnnouncement(user, announcement) {
  if (!announcement) return false;
  if (canManage(user)) return true;
  return isLive(announcement) && canSeeAudience(user, announcement.audience);
}

export function getAnnouncement(id) {
  return queryOne(
    `SELECT a.*, u.display_name AS created_by_name
       FROM announcements a
       LEFT JOIN users u ON u.id = a.created_by
      WHERE a.id = @id`,
    { id }
  ) || null;
}

export function listAnnouncements(user, { status = null, search = '', page = 1, pageSize = 20 } = {}) {
  const manage = canManage(user);
  const asOf = today();
  const params = {
    status,
    search: search || '',
    like: likePattern(search),
    manage: manage ? 1 : 0,
    asOf,
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  // Everyone else sees only live announcements aimed at them.
  const audiences = Object.keys(AUDIENCES).filter((key) => canSeeAudience(user, key));
  const audienceClause = manage
    ? '1 = 1'
    : audiences.length
      ? `a.audience IN (${audiences.map((key, i) => {
        params[`aud${i}`] = key;
        return `@aud${i}`;
      }).join(',')})`
      : '0 = 1';

  const where = `
    WHERE (@status IS NULL OR a.status = @status)
      AND (@search = '' OR a.title LIKE @like ESCAPE '\\' OR a.body LIKE @like ESCAPE '\\')
      AND (@manage = 1 OR (
            a.status = 'published'
            AND (a.publish_at IS NULL OR substr(a.publish_at, 1, 10) <= @asOf)
            AND (a.expires_at IS NULL OR substr(a.expires_at, 1, 10) >= @asOf)
            AND ${audienceClause}
          ))`;

  const rows = query(
    `SELECT a.*, u.display_name AS created_by_name
       FROM announcements a
       LEFT JOIN users u ON u.id = a.created_by
       ${where}
      ORDER BY
        CASE a.priority WHEN 'high' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,
        COALESCE(a.publish_at, a.created_at) DESC, a.id DESC
      LIMIT @limit OFFSET @offset`,
    params
  );

  const total = queryOne(`SELECT COUNT(*) AS n FROM announcements a ${where}`, params).n;
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

export function createAnnouncement(data, { userId = null } = {}) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO announcements
       (title, body, priority, audience, publish_at, expires_at, status, created_at, updated_at, created_by)
     VALUES (@title, @body, @priority, @audience, @publish_at, @expires_at, @status, @at, @at, @by)`,
    {
      title: data.title,
      body: data.body,
      priority: PRIORITIES.includes(data.priority) ? data.priority : 'normal',
      audience: Object.keys(AUDIENCES).includes(data.audience) ? data.audience : 'all',
      publish_at: data.publish_at || null,
      expires_at: data.expires_at || null,
      status: ANNOUNCEMENT_STATUSES.includes(data.status) ? data.status : 'draft',
      at,
      by: userId
    }
  );
  return getAnnouncement(Number(result.lastInsertRowid));
}

export function updateAnnouncement(id, data) {
  execute(
    `UPDATE announcements SET
       title = @title, body = @body, priority = @priority, audience = @audience,
       publish_at = @publish_at, expires_at = @expires_at, updated_at = @at
     WHERE id = @id`,
    {
      id,
      title: data.title,
      body: data.body,
      priority: PRIORITIES.includes(data.priority) ? data.priority : 'normal',
      audience: Object.keys(AUDIENCES).includes(data.audience) ? data.audience : 'all',
      publish_at: data.publish_at || null,
      expires_at: data.expires_at || null,
      at: nowIso()
    }
  );
  return getAnnouncement(id);
}

export function setAnnouncementStatus(id, status) {
  if (!ANNOUNCEMENT_STATUSES.includes(status)) return null;
  execute('UPDATE announcements SET status = @status, updated_at = @at WHERE id = @id',
    { id, status, at: nowIso() });
  return getAnnouncement(id);
}

export function deleteAnnouncement(id) {
  return execute('DELETE FROM announcements WHERE id = @id', { id }).changes;
}

/** User ids an announcement should notify, based on its audience. */
export function audienceUserIds(audience) {
  const spec = AUDIENCES[audience] || AUDIENCES.all;
  return query(
    `SELECT DISTINCT u.id
       FROM users u
       JOIN user_roles ur ON ur.user_id = u.id
       JOIN role_permissions rp ON rp.role_id = ur.role_id
       JOIN permissions p ON p.id = rp.permission_id
      WHERE p.key = @permission AND u.status = 'active'`,
    { permission: spec.permission }
  ).map((r) => r.id);
}
