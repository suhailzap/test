import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso } from '../lib/dates.js';
import { CURRENT_POPULATION_STATUSES } from './members.js';

/*
 * "Who is serving" and its denominators measure participation across
 * everyone currently with CCIQ, not just members whose lifecycle status is
 * literally 'active' — a Worship Ministry member classified attendee,
 * bonafide, or temporarily away is still serving. See
 * CURRENT_POPULATION_STATUSES in services/members.js and CCIQ_DECISIONS.md.
 */
const CURRENT_POPULATION_SQL = `(${CURRENT_POPULATION_STATUSES.map((s) => `'${s}'`).join(',')})`;

/**
 * A ministry is a team serving the church — music, ushering, children's work
 * and so on. Unlike a cell group, which a member belongs to once, a member may
 * serve in several ministries at the same time, so membership is a list rather
 * than a field on the member record.
 */
export const MINISTRY_STATUSES = ['active', 'inactive', 'archived'];

export const MINISTRY_ROLES = ['leader', 'assistant', 'member', 'trainee'];
export const ROLE_LABELS = {
  leader: 'Leader',
  assistant: 'Assistant',
  member: 'Serving',
  trainee: 'In training'
};

const ROLE_ORDER = "CASE role WHEN 'leader' THEN 0 WHEN 'assistant' THEN 1 WHEN 'member' THEN 2 ELSE 3 END";

export function listMinistries({ includeInactive = false } = {}) {
  return query(
    `SELECT m.*,
            (SELECT COUNT(*) FROM ministry_members mm
              JOIN members mem ON mem.id = mm.member_id
             WHERE mm.ministry_id = m.id AND mm.left_at IS NULL AND mem.status != 'archived') AS member_count,
            leader.first_name AS leader_first, leader.last_name AS leader_last,
            leader.preferred_name AS leader_preferred, leader.phone AS leader_phone,
            assistant.first_name AS assistant_first, assistant.last_name AS assistant_last,
            assistant.preferred_name AS assistant_preferred
       FROM ministries m
       LEFT JOIN members leader ON leader.id = m.leader_member_id
       LEFT JOIN members assistant ON assistant.id = m.assistant_member_id
      WHERE (@includeInactive = 1 OR m.status = 'active')
      ORDER BY m.sort_order, m.name COLLATE NOCASE`,
    { includeInactive: includeInactive ? 1 : 0 }
  );
}

export function getMinistry(id) {
  return queryOne(
    `SELECT m.*,
            leader.first_name AS leader_first, leader.last_name AS leader_last,
            leader.preferred_name AS leader_preferred, leader.phone AS leader_phone,
            assistant.first_name AS assistant_first, assistant.last_name AS assistant_last,
            assistant.preferred_name AS assistant_preferred
       FROM ministries m
       LEFT JOIN members leader ON leader.id = m.leader_member_id
       LEFT JOIN members assistant ON assistant.id = m.assistant_member_id
      WHERE m.id = @id`,
    { id }
  ) || null;
}

/** One unit: the row and the leadership/membership it implies are written together, or not at all. */
export function createMinistry(data, { userId = null } = {}) {
  return transaction(() => createMinistryWrites(data, { userId }))();
}

function createMinistryWrites(data, { userId = null } = {}) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO ministries
       (name, description, leader_member_id, assistant_member_id, meets, contact, status,
        sort_order, created_at, updated_at, created_by)
     VALUES (@name, @description, @leader, @assistant, @meets, @contact, @status, @sortOrder, @at, @at, @by)`,
    {
      name: data.name,
      description: data.description ?? null,
      leader: data.leader_member_id ?? null,
      assistant: data.assistant_member_id ?? null,
      meets: data.meets ?? null,
      contact: data.contact ?? null,
      status: MINISTRY_STATUSES.includes(data.status) ? data.status : 'active',
      sortOrder: Number(data.sort_order) || 0,
      at,
      by: userId
    }
  );
  const id = Number(result.lastInsertRowid);
  syncLeadership(id, data.leader_member_id, data.assistant_member_id);
  return getMinistry(id);
}

/** One unit: the row and the leadership/membership it implies are written together, or not at all. */
export function updateMinistry(id, data) {
  return transaction(() => updateMinistryWrites(id, data))();
}

function updateMinistryWrites(id, data) {
  execute(
    `UPDATE ministries SET
       name = @name, description = @description, leader_member_id = @leader,
       assistant_member_id = @assistant, meets = @meets, contact = @contact,
       status = @status, sort_order = @sortOrder, updated_at = @at
     WHERE id = @id`,
    {
      id,
      name: data.name,
      description: data.description ?? null,
      leader: data.leader_member_id ?? null,
      assistant: data.assistant_member_id ?? null,
      meets: data.meets ?? null,
      contact: data.contact ?? null,
      status: MINISTRY_STATUSES.includes(data.status) ? data.status : 'active',
      sortOrder: Number(data.sort_order) || 0,
      at: nowIso()
    }
  );
  syncLeadership(id, data.leader_member_id, data.assistant_member_id);
  return getMinistry(id);
}

/** Whoever is named as leader or assistant is also serving in the ministry. */
function syncLeadership(ministryId, leaderId, assistantId) {
  for (const [memberId, role] of [[leaderId, 'leader'], [assistantId, 'assistant']]) {
    if (memberId) addMember(ministryId, memberId, { role });
  }
  execute(
    `UPDATE ministry_members SET role = 'member'
      WHERE ministry_id = @ministryId AND left_at IS NULL
        AND role IN ('leader','assistant')
        AND member_id NOT IN (@leaderId, @assistantId)`,
    { ministryId, leaderId: leaderId || 0, assistantId: assistantId || 0 }
  );
}

export function deleteMinistry(id) {
  const ministry = getMinistry(id);
  if (!ministry) return null;
  execute('DELETE FROM ministries WHERE id = @id', { id });
  return ministry;
}

// --- Who serves ------------------------------------------------------------

export function ministryMembers(ministryId, { includePast = false } = {}) {
  return query(
    `SELECT mem.*, mm.role, mm.joined_at, mm.left_at, mm.notes AS service_notes,
            g.name AS cell_group_name
       FROM ministry_members mm
       JOIN members mem ON mem.id = mm.member_id
       LEFT JOIN cell_groups g ON g.id = mem.cell_group_id
      WHERE mm.ministry_id = @id
        AND (@includePast = 1 OR mm.left_at IS NULL)
      ORDER BY mm.left_at IS NOT NULL, ${ROLE_ORDER.replaceAll('role', 'mm.role')},
               mem.last_name COLLATE NOCASE, mem.first_name COLLATE NOCASE`,
    { id: ministryId, includePast: includePast ? 1 : 0 }
  );
}

/** Every ministry a member serves in. */
export function ministriesForMember(memberId, { includePast = false } = {}) {
  return query(
    `SELECT m.id, m.name, m.status, mm.role, mm.joined_at, mm.left_at
       FROM ministry_members mm
       JOIN ministries m ON m.id = mm.ministry_id
      WHERE mm.member_id = @id
        AND (@includePast = 1 OR mm.left_at IS NULL)
      ORDER BY mm.left_at IS NOT NULL, m.sort_order, m.name COLLATE NOCASE`,
    { id: memberId, includePast: includePast ? 1 : 0 }
  );
}

/**
 * Adds a member to a ministry. Someone who served before and is returning has
 * their record reopened rather than duplicated, so the history stays intact.
 */
export function addMember(ministryId, memberId, { role = 'member', notes = null } = {}) {
  const at = nowIso();
  const chosenRole = MINISTRY_ROLES.includes(role) ? role : 'member';

  return transaction(() => {
    const existing = queryOne(
      'SELECT * FROM ministry_members WHERE ministry_id = @ministryId AND member_id = @memberId',
      { ministryId, memberId }
    );

    if (existing) {
      execute(
        `UPDATE ministry_members
            SET role = @role, left_at = NULL, notes = COALESCE(@notes, notes),
                joined_at = CASE WHEN left_at IS NOT NULL THEN @at ELSE joined_at END
          WHERE ministry_id = @ministryId AND member_id = @memberId`,
        { ministryId, memberId, role: chosenRole, notes, at }
      );
      return { ok: true, rejoined: Boolean(existing.left_at) };
    }

    execute(
      `INSERT INTO ministry_members (ministry_id, member_id, role, joined_at, notes)
       VALUES (@ministryId, @memberId, @role, @at, @notes)`,
      { ministryId, memberId, role: chosenRole, at, notes }
    );
    return { ok: true, rejoined: false };
  })();
}

/** Someone stepping down keeps their record, closed with the date. */
export function removeMember(ministryId, memberId) {
  const at = nowIso();
  // One unit: a member is never recorded as having left while still named as the ministry's leader.
  transaction(() => {
    execute(
      `UPDATE ministry_members SET left_at = @at
        WHERE ministry_id = @ministryId AND member_id = @memberId AND left_at IS NULL`,
      { ministryId, memberId, at }
    );
    // A leader who steps down is no longer named as leader of the ministry.
    execute(
      `UPDATE ministries SET leader_member_id = NULL, updated_at = @at
        WHERE id = @ministryId AND leader_member_id = @memberId`,
      { ministryId, memberId, at }
    );
    execute(
      `UPDATE ministries SET assistant_member_id = NULL, updated_at = @at
        WHERE id = @ministryId AND assistant_member_id = @memberId`,
      { ministryId, memberId, at }
    );
  })();
  return true;
}

export function setRole(ministryId, memberId, role) {
  if (!MINISTRY_ROLES.includes(role)) return null;
  execute(
    `UPDATE ministry_members SET role = @role
      WHERE ministry_id = @ministryId AND member_id = @memberId AND left_at IS NULL`,
    { ministryId, memberId, role }
  );
  return role;
}

/** Figures for the ministries overview and reports. */
export function ministryOverview() {
  const ministries = listMinistries({ includeInactive: true });
  const serving = queryOne(
    `SELECT COUNT(DISTINCT mm.member_id) AS n
       FROM ministry_members mm
       JOIN members mem ON mem.id = mm.member_id
      WHERE mm.left_at IS NULL AND mem.status IN ${CURRENT_POPULATION_SQL}`
  ).n;
  const currentMembers = queryOne(`SELECT COUNT(*) AS n FROM members WHERE status IN ${CURRENT_POPULATION_SQL}`).n;

  return {
    ministries,
    active: ministries.filter((m) => m.status === 'active').length,
    total: ministries.length,
    withLeader: ministries.filter((m) => m.leader_member_id).length,
    serving,
    currentMembers,
    notServing: Math.max(currentMembers - serving, 0),
    servingRate: currentMembers ? Math.round((serving / currentMembers) * 100) : null
  };
}

/** Members currently with CCIQ who are not serving anywhere, for the ministry report. */
export const NOT_SERVING_SORT_COLUMNS = ['member', 'cell_group', 'joined'];

export function membersNotServing({ limit = 500, sort = 'member', direction = 'asc' } = {}) {
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const orderBy = {
    member: `mem.last_name COLLATE NOCASE ${dir}, mem.first_name COLLATE NOCASE ${dir}`,
    cell_group: `g.name COLLATE NOCASE ${dir}`,
    joined: `mem.date_joined ${dir}`
  }[sort] || `mem.last_name COLLATE NOCASE ASC, mem.first_name COLLATE NOCASE ASC`;

  return query(
    `SELECT mem.*, g.name AS cell_group_name
       FROM members mem
       LEFT JOIN cell_groups g ON g.id = mem.cell_group_id
      WHERE mem.status IN ${CURRENT_POPULATION_SQL}
        AND NOT EXISTS (
          SELECT 1 FROM ministry_members mm
           WHERE mm.member_id = mem.id AND mm.left_at IS NULL
        )
      ORDER BY ${orderBy}
      LIMIT @limit`,
    { limit }
  );
}

const SEARCH_SQL = `(@search = '' OR mem.first_name LIKE @like ESCAPE '\\' OR mem.last_name LIKE @like ESCAPE '\\' OR mem.preferred_name LIKE @like ESCAPE '\\'
        OR mem.member_code LIKE @like ESCAPE '\\' OR (mem.first_name || ' ' || mem.last_name) LIKE @like ESCAPE '\\')`;

/**
 * "Not yet serving anywhere", filtered, sorted and PAGED on the server. Same population and rule as
 * membersNotServing() (current population, no open ministry membership) - only how much of it is
 * fetched changes. Returns { rows, total }.
 */
export function searchNotServing({
  search = '', cellGroupId = null, sort = 'member', direction = 'asc', limit = 25, offset = 0
} = {}) {
  const params = { search: search || '', like: likePattern(search), cellGroupId };
  const where = `
      WHERE mem.status IN ${CURRENT_POPULATION_SQL}
        AND ${SEARCH_SQL}
        AND (@cellGroupId IS NULL OR mem.cell_group_id = @cellGroupId)
        AND NOT EXISTS (
          SELECT 1 FROM ministry_members mm WHERE mm.member_id = mem.id AND mm.left_at IS NULL
        )`;
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const orderBy = {
    member: `mem.last_name COLLATE NOCASE ${dir}, mem.first_name COLLATE NOCASE ${dir}`,
    cell_group: `g.name IS NULL, g.name COLLATE NOCASE ${dir}, mem.last_name COLLATE NOCASE`,
    joined: `mem.date_joined IS NULL, mem.date_joined ${dir}, mem.last_name COLLATE NOCASE`
  }[NOT_SERVING_SORT_COLUMNS.includes(sort) ? sort : 'member'];
  const total = queryOne(`SELECT COUNT(*) AS n FROM members mem ${where}`, params).n;
  const rows = query(
    `SELECT mem.*, g.name AS cell_group_name
       FROM members mem LEFT JOIN cell_groups g ON g.id = mem.cell_group_id
       ${where}
      ORDER BY ${orderBy}, mem.id
      LIMIT @limit OFFSET @offset`,
    { ...params, limit, offset }
  );
  return { rows, total };
}

export const SERVING_SEVERAL_SORT_COLUMNS = ['member', 'ministries'];

/**
 * "Serving in more than one ministry", filtered (search, cell group, a particular ministry),
 * sorted and PAGED on the server. Returns { rows, total }.
 */
export function searchServingSeveral({
  minimum = 2, search = '', cellGroupId = null, ministryId = null, sort = 'ministries', direction = 'desc', limit = 25, offset = 0
} = {}) {
  const params = { minimum, search: search || '', like: likePattern(search), cellGroupId, ministryId };
  const inner = `
      FROM ministry_members mm
      JOIN members mem ON mem.id = mm.member_id
      JOIN ministries m ON m.id = mm.ministry_id
     WHERE mm.left_at IS NULL AND mem.status IN ${CURRENT_POPULATION_SQL} AND m.status = 'active'
       AND ${SEARCH_SQL}
       AND (@cellGroupId IS NULL OR mem.cell_group_id = @cellGroupId)
       AND (@ministryId IS NULL OR EXISTS (
             SELECT 1 FROM ministry_members x WHERE x.member_id = mem.id AND x.ministry_id = @ministryId AND x.left_at IS NULL))
     GROUP BY mem.id
    HAVING COUNT(*) >= @minimum`;
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  const orderBy = SERVING_SEVERAL_SORT_COLUMNS.includes(sort) && sort === 'member'
    ? `mem.last_name COLLATE NOCASE ${dir === 'ASC' ? 'ASC' : 'DESC'}, mem.first_name COLLATE NOCASE`
    : `ministries ${dir}, mem.last_name COLLATE NOCASE`;
  const total = queryOne(`SELECT COUNT(*) AS n FROM (SELECT mem.id ${inner})`, params).n;
  const rows = query(
    `SELECT mem.id, mem.member_code, mem.first_name, mem.last_name, mem.preferred_name,
            COUNT(*) AS ministries, GROUP_CONCAT(m.name, ', ') AS ministry_names
       ${inner}
      ORDER BY ${orderBy}, mem.id
      LIMIT @limit OFFSET @offset`,
    { ...params, limit, offset }
  );
  return { rows, total };
}

/** Members serving in more than one ministry, so no one is quietly overloaded. */
export function membersServingSeveral({ minimum = 2 } = {}) {
  return query(
    `SELECT mem.id, mem.member_code, mem.first_name, mem.last_name, mem.preferred_name,
            COUNT(*) AS ministries,
            GROUP_CONCAT(m.name, ', ') AS ministry_names
       FROM ministry_members mm
       JOIN members mem ON mem.id = mm.member_id
       JOIN ministries m ON m.id = mm.ministry_id
      WHERE mm.left_at IS NULL AND mem.status IN ${CURRENT_POPULATION_SQL} AND m.status = 'active'
      GROUP BY mem.id
     HAVING COUNT(*) >= @minimum
      ORDER BY ministries DESC, mem.last_name COLLATE NOCASE`,
    { minimum }
  );
}

/** Stores the path to a ministry's photo. */
export function setMinistryPhoto(ministryId, storedPath) {
  execute('UPDATE ministries SET photo_path = @path, updated_at = @at WHERE id = @id',
    { id: ministryId, path: storedPath, at: nowIso() });
  return getMinistry(ministryId);
}
