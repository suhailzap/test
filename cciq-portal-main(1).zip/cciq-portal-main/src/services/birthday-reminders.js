import { query, execute } from '../db/index.js';
import { nowIso } from '../lib/dates.js';
import { recordAudit } from '../lib/audit.js';

/*
 * What happens to an OPEN birthday reminder when a member's date of birth is corrected.
 *
 * A reminder ("has a birthday in 3 days") was worked out from the date of birth the member had then. Once that date is corrected the reminder is about a birthday that is not theirs, so it is
 * DISMISSED (never deleted): its row, its text and its history stay; it records who made the correction and says why; and an audit entry names the reminder, the member, the old and the new date.
 * Its de-duplication key is renamed (the old key plus ":superseded:<id>") so the ordinary reminder generation is free to raise a fresh reminder for the corrected date when that date comes
 * round; this module never creates one.
 *
 * Only a correction does this. A reminder a person already completed or dismissed is history and is left alone. Opening the review screen or changing a review decision does not touch a reminder:
 * a decision that makes the birthday unusable (not verified) simply hides it, exactly as before, and it returns if the date is later confirmed.
 *
 * It lives in its own file because members.js (the ordinary edit) and dob-review.js (the review screen's correction) both need it and reminders.js already imports members.js.
 */

export function openBirthdayReminders(memberId) {
  return query(
    "SELECT id, title, due_date, dedupe_key FROM reminders WHERE member_id = @id AND reminder_type = 'birthday' AND state IN ('new','acknowledged') ORDER BY id",
    { id: memberId }
  );
}

/** Dismisses the member's open birthday reminders because their date of birth was corrected. Returns how many were dismissed. */
export function supersedeBirthdayReminders(memberId, { userId = null, previousDob = null, newDob = null } = {}) {
  const open = openBirthdayReminders(memberId);
  const at = nowIso();
  for (const r of open) {
    execute(
      `UPDATE reminders
          SET state = 'dismissed', handled_by = @by, handled_at = @at, updated_at = @at,
              dedupe_key = CASE WHEN dedupe_key IS NULL THEN NULL ELSE dedupe_key || ':superseded:' || id END,
              detail = COALESCE(detail || ' ', '') || '(Dismissed automatically: the date of birth was corrected, so this reminder was about the previous date.)'
        WHERE id = @id AND state IN ('new','acknowledged')`,
      { id: r.id, by: userId, at }
    );
    recordAudit({
      userId, action: 'reminder.birthday_superseded', entityType: 'reminder', entityId: r.id,
      detail: { member_id: memberId, reminder: r.title, due_date: r.due_date, previous_dob: previousDob, new_dob: newDob, reason: 'the date of birth was corrected' }
    });
  }
  return open.length;
}
