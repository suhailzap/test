import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso } from '../lib/dates.js';

export const GROUP_STATUSES = ['active', 'inactive', 'archived'];
export const GROUP_ROLES = ['leader', 'assistant', 'member'];
export const MEETING_DAYS = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

/**
 * A member's current group is held on the member record so lists and filters
 * stay fast, while cell_group_members keeps the joined and left dates that the
 * member history is built from. Both are written in the same transaction.
 */
export function listGroups({ includeInactive = true } = {}) {
  return query(
    `SELECT g.*,
            (SELECT COUNT(*) FROM members m WHERE m.cell_group_id = g.id AND m.status != 'archived') AS member_count,
            leader.first_name AS leader_first, leader.last_name AS leader_last,
            leader.preferred_name AS leader_preferred,
            assistant.first_name AS assistant_first, assistant.last_name AS assistant_last,
            assistant.preferred_name AS assistant_preferred
       FROM cell_groups g
       LEFT JOIN members leader ON leader.id = g.leader_member_id
       LEFT JOIN members assistant ON assistant.id = g.assistant_member_id
      WHERE (@includeInactive = 1 OR g.status = 'active')
      ORDER BY g.status = 'active' DESC, g.name COLLATE NOCASE`,
    { includeInactive: includeInactive ? 1 : 0 }
  );
}

export function activeGroupOptions() {
  return query("SELECT id, name FROM cell_groups WHERE status = 'active' ORDER BY name COLLATE NOCASE");
}

export function getGroup(id) {
  return queryOne(
    `SELECT g.*,
            leader.first_name AS leader_first, leader.last_name AS leader_last,
            leader.preferred_name AS leader_preferred,
            assistant.first_name AS assistant_first, assistant.last_name AS assistant_last,
            assistant.preferred_name AS assistant_preferred
       FROM cell_groups g
       LEFT JOIN members leader ON leader.id = g.leader_member_id
       LEFT JOIN members assistant ON assistant.id = g.assistant_member_id
      WHERE g.id = @id`,
    { id }
  ) || null;
}

export function groupMembers(groupId) {
  return query(
    `SELECT m.*, gm.role_in_group, gm.joined_at
       FROM members m
       LEFT JOIN cell_group_members gm
              ON gm.member_id = m.id AND gm.cell_group_id = @id AND gm.left_at IS NULL
      WHERE m.cell_group_id = @id
      ORDER BY
        CASE COALESCE(gm.role_in_group, 'member')
          WHEN 'leader' THEN 0 WHEN 'assistant' THEN 1 ELSE 2 END,
        m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE`,
    { id: groupId }
  );
}

/** One unit: the row and the leadership/membership it implies are written together, or not at all. */
export function createGroup(data, { userId = null } = {}) {
  return transaction(() => createGroupWrites(data, { userId }))();
}

function createGroupWrites(data, { userId = null } = {}) {
  const at = nowIso();
  const result = execute(
    `INSERT INTO cell_groups
       (name, description, leader_member_id, assistant_member_id, meeting_day, meeting_time,
        meeting_location, status, created_at, updated_at)
     VALUES (@name, @description, @leader_member_id, @assistant_member_id, @meeting_day, @meeting_time,
             @meeting_location, @status, @at, @at)`,
    {
      name: data.name,
      description: data.description ?? null,
      leader_member_id: data.leader_member_id ?? null,
      assistant_member_id: data.assistant_member_id ?? null,
      meeting_day: data.meeting_day ?? null,
      meeting_time: data.meeting_time ?? null,
      meeting_location: data.meeting_location ?? null,
      status: data.status || 'active',
      at
    }
  );
  const id = Number(result.lastInsertRowid);
  syncLeadershipMembership(id, data.leader_member_id, data.assistant_member_id, userId);
  return getGroup(id);
}

/** One unit: the row and the leadership/membership it implies are written together, or not at all. */
export function updateGroup(id, data, { userId = null } = {}) {
  return transaction(() => updateGroupWrites(id, data, { userId }))();
}

function updateGroupWrites(id, data, { userId = null } = {}) {
  execute(
    `UPDATE cell_groups SET
       name = @name, description = @description,
       leader_member_id = @leader_member_id, assistant_member_id = @assistant_member_id,
       meeting_day = @meeting_day, meeting_time = @meeting_time,
       meeting_location = @meeting_location, status = @status, updated_at = @at
     WHERE id = @id`,
    {
      id,
      name: data.name,
      description: data.description ?? null,
      leader_member_id: data.leader_member_id ?? null,
      assistant_member_id: data.assistant_member_id ?? null,
      meeting_day: data.meeting_day ?? null,
      meeting_time: data.meeting_time ?? null,
      meeting_location: data.meeting_location ?? null,
      status: data.status || 'active',
      at: nowIso()
    }
  );
  syncLeadershipMembership(id, data.leader_member_id, data.assistant_member_id, userId);
  return getGroup(id);
}

/** A named leader or assistant is always a member of the group they lead. */
function syncLeadershipMembership(groupId, leaderId, assistantId, userId) {
  for (const [memberId, role] of [[leaderId, 'leader'], [assistantId, 'assistant']]) {
    if (!memberId) continue;
    assignMemberToGroup(memberId, groupId, { role, userId });
  }
  execute(
    `UPDATE cell_group_members SET role_in_group = 'member'
      WHERE cell_group_id = @groupId AND left_at IS NULL
        AND role_in_group IN ('leader','assistant')
        AND member_id NOT IN (@leaderId, @assistantId)`,
    { groupId, leaderId: leaderId || 0, assistantId: assistantId || 0 }
  );
}

/**
 * Moves a member into a group, or out of every group when groupId is null.
 * The previous membership is closed rather than deleted so the change stays
 * visible in the member's history.
 */
export function assignMemberToGroup(memberId, groupId, { role = 'member', userId = null } = {}) {
  const at = nowIso();
  const current = queryOne('SELECT cell_group_id FROM members WHERE id = @id', { id: memberId });
  if (!current) return null;
  const target = groupId ? Number(groupId) : null;

  return transaction(() => {
    execute(
      `UPDATE cell_group_members SET left_at = @at
        WHERE member_id = @memberId AND left_at IS NULL
          AND (@target IS NULL OR cell_group_id != @target)`,
      { memberId, at, target }
    );

    if (target) {
      const open = queryOne(
        `SELECT 1 AS found FROM cell_group_members
          WHERE member_id = @memberId AND cell_group_id = @target AND left_at IS NULL`,
        { memberId, target }
      );
      if (open) {
        execute(
          `UPDATE cell_group_members SET role_in_group = @role
            WHERE member_id = @memberId AND cell_group_id = @target AND left_at IS NULL`,
          { memberId, target, role }
        );
      } else {
        execute(
          `INSERT INTO cell_group_members (cell_group_id, member_id, role_in_group, joined_at, left_at)
           VALUES (@target, @memberId, @role, @at, NULL)
           ON CONFLICT(cell_group_id, member_id)
           DO UPDATE SET role_in_group = excluded.role_in_group, joined_at = excluded.joined_at, left_at = NULL`,
          { target, memberId, role, at }
        );
      }
    }

    execute(
      'UPDATE members SET cell_group_id = @target, updated_at = @at, updated_by = @by WHERE id = @memberId',
      { memberId, target, at, by: userId }
    );

    return { memberId, from: current.cell_group_id, to: target };
  })();
}

/** Every group a member has belonged to, most recent first. */
export function membershipHistory(memberId) {
  return query(
    `SELECT gm.*, g.name AS group_name
       FROM cell_group_members gm
       JOIN cell_groups g ON g.id = gm.cell_group_id
      WHERE gm.member_id = @id
      ORDER BY gm.joined_at DESC`,
    { id: memberId }
  );
}

export function groupName(group) {
  return group ? group.name : null;
}

/** Stores the path to a group's photo. The file itself lives under storage. */
export function setGroupPhoto(groupId, storedPath) {
  execute('UPDATE cell_groups SET photo_path = @path, updated_at = @at WHERE id = @id',
    { id: groupId, path: storedPath, at: nowIso() });
  return getGroup(groupId);
}
