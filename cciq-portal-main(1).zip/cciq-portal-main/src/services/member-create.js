import { transaction } from '../db/index.js';
import { recordAudit, AUDIT } from '../lib/audit.js';
import { createMember, saveCustomFieldValues, setSpouse, getMember, displayName, findPossibleDuplicates } from './members.js';
import { setAgeGroup, setGuardian } from './congregations.js';
import { assignMemberToGroup } from './cell-groups.js';

/**
 * Records that an administrator created a member despite a possible-duplicate warning. The matches are recomputed here rather than trusted
 * from the warning page's hidden fields, so the audit row always reflects what actually matched at the moment of creation. Add member and
 * Convert a First Timer both call this, so the override is audited identically whichever way the member was created.
 */
export function recordDuplicateOverride({ req, member, values, body }) {
  const matches = findPossibleDuplicates(values, { excludeId: member.id });
  recordAudit({
    req, action: AUDIT.MEMBER_DUPLICATE_WARNING_OVERRIDDEN, entityType: 'member', entityId: member.id,
    detail: {
      new_member: { id: member.id, member_code: member.member_code, name: displayName(member) },
      possible_matches: matches.map((m) => ({ id: m.member.id, member_code: m.member.memberCode, level: m.level })),
      override_reason: String(body?.override_reason || '').slice(0, 200) || null
    }
  });
}

/**
 * The one way a new member record is created from validated form values (see lib/member-form.js for the validation). Used by
 * Add member and by converting a First Timer, so the two can never drift apart.
 *
 * One unit: the member, their extra fields, age group, guardian, cell group, spouse link, the audit entry and anything the caller
 * needs written with them (`alsoInTransaction(created)`, for example linking a First Timer) are committed together or not at all.
 * A failure anywhere - including in `alsoInTransaction` - leaves no half-created member and no audit entry for a creation that was
 * rolled back.
 *
 * Returns { member, spouseConflictName }.
 */
export function createMemberRecord({ values, body = {}, status = 'pending', userId = null, req = null, reason = 'Record created', auditDetail = {}, alsoInTransaction = null }) {
  let spouseConflictName = null;
  const member = transaction(() => {
    const created = createMember(values, { userId, status, reason });
    saveCustomFieldValues(created.id, body);
    setAgeGroup(created.id, values.age_group, { userId });
    setGuardian(created.id, values.guardian_member_id, { userId });
    if (values.cell_group_id) assignMemberToGroup(created.id, values.cell_group_id, { userId });

    if (values.spouse_member_id) {
      const spouseResult = setSpouse(created.id, values.spouse_member_id, { userId });
      if (!spouseResult.ok && spouseResult.reason === 'conflict') {
        const conflictMember = getMember(spouseResult.conflictMemberId);
        spouseConflictName = conflictMember ? displayName(conflictMember) : 'another member';
      }
    }

    if (alsoInTransaction) alsoInTransaction(created);

    recordAudit({
      req, userId, action: AUDIT.MEMBER_CREATED, entityType: 'member', entityId: created.id,
      detail: { member_code: created.member_code, status, ...auditDetail }
    });
    return created;
  }).immediate(); // the write lock is taken up front, so a read at the start can never be upgraded from a stale snapshot
  return { member, spouseConflictName };
}
