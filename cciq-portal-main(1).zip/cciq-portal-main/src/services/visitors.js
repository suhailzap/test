import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { phoneMatches, phoneFragmentLike, phoneDigitsSql } from '../lib/phone.js';
import { nowIso, today, addDays } from '../lib/dates.js';
import { createMemberRecord } from './member-create.js';
import { recordAudit } from '../lib/audit.js';
import { AGE_GROUPS } from './congregations.js';

/**
 * A first-time visitor is not a member record. They are tracked separately
 * until they either keep coming and join, or stop coming, in which case the
 * person who invited them is the natural one to check in with.
 */
/**
 * Validates the optional "Invited by" choice on a Validator (both the administrative form and Express Registration use it). A chosen inviter must be a
 * real member; no choice at all is NULL, which every screen prints as "Came on their own". Nothing is invented for it.
 */
export function collectInviter(v) {
  const id = v.integer('invited_by_member_id', { min: 1, label: 'Invited by a member' });
  if (id !== null && !v.errors.invited_by_member_id && !queryOne('SELECT 1 AS x FROM members WHERE id = @id', { id })) {
    v.fail('invited_by_member_id', 'Choose the member from the search results. That member could not be found.');
  }
  return id;
}

export const VISITOR_STATES = ['new', 'returning', 'joined', 'not_returned', 'declined'];

/**
 * What an administrator may record by hand: a DECISION, never an attendance fact.
 *   active        no decision. The status shown (First visit / Came back) follows the recorded visits.
 *   not_returned  recorded as "Has not returned"
 *   declined      recorded as "Not continuing"
 * 'new' and 'returning' are deliberately not choices: whether someone is still on their first visit or has come back is derived from the
 * visits (createVisitor, recordVisit), so nobody can contradict the visit list by hand. 'joined' is not a choice either: a First Timer is
 * joined if and only if they are linked to a member record, and the only things that can make that true are converting them to a new
 * member or linking them to an existing one (convertToMember / linkVisitorToMember below). The database enforces the same rule (0030).
 * Nothing here is ever set automatically from absence.
 */
export const MANUAL_OUTCOMES = ['active', 'not_returned', 'declined'];

export const MANUAL_OUTCOME_LABELS = {
  active: 'Active (follows their visits)',
  not_returned: 'Has not returned',
  declined: 'Not continuing'
};

/** The status to show for a First Timer: an explicit decision or membership if there is one, otherwise First visit / Came back from the visits. */
export function displayState(visitor, visitCount) {
  if (visitor.member_id || visitor.state === 'joined') return 'joined';
  if (visitor.state === 'declined' || visitor.state === 'not_returned') return visitor.state;
  return Number(visitCount) > 1 ? 'returning' : 'new';
}

export const STATE_LABELS = {
  new: 'First visit',
  returning: 'Came back',
  joined: 'Became a member',
  not_returned: 'Has not returned',
  declined: 'Not continuing'
};

export const FOLLOW_UP_STATES = ['new', 'acknowledged', 'contacted', 'completed', 'dismissed'];

export const FOLLOW_UP_LABELS = {
  new: 'Not yet contacted',
  acknowledged: 'Acknowledged',
  contacted: 'Contacted',
  completed: 'Completed',
  dismissed: 'Dismissed'
};

export function getVisitor(id) {
  const visitor = queryOne(
    `SELECT v.*,
            m.first_name AS inviter_first, m.last_name AS inviter_last,
            m.preferred_name AS inviter_preferred, m.phone AS inviter_phone,
            m.email AS inviter_email, m.member_code AS inviter_code,
            j.member_code AS joined_code
       FROM visitors v
       LEFT JOIN members m ON m.id = v.invited_by_member_id
       LEFT JOIN members j ON j.id = v.member_id
      WHERE v.id = @id`,
    { id }
  );
  if (!visitor) return null;
  const visits = visitsFor(id);
  return { ...visitor, visits, display_state: displayState(visitor, visits.length) };
}

export function visitsFor(visitorId) {
  return query(
    'SELECT * FROM visitor_visits WHERE visitor_id = @id ORDER BY visit_date DESC',
    { id: visitorId }
  );
}

export function createVisitor(data, { userId = null } = {}) {
  const at = nowIso();
  const firstVisit = data.first_visit_date || today();

  const id = transaction(() => {
    const result = execute(
      `INSERT INTO visitors
         (first_name, last_name, phone, email, age_group, first_visit_date, congregation,
          invited_by_member_id, invited_by_name, how_heard, notes, state, follow_up_state,
          created_at, updated_at, created_by)
       VALUES (@first_name, @last_name, @phone, @email, @age_group, @first_visit_date, @congregation,
               @invited_by_member_id, @invited_by_name, @how_heard, @notes, 'new', 'new',
               @at, @at, @by)`,
      {
        first_name: data.first_name,
        last_name: data.last_name ?? null,
        phone: data.phone ?? null,
        email: data.email ?? null,
        age_group: AGE_GROUPS.includes(data.age_group) ? data.age_group : null,
        first_visit_date: firstVisit,
        congregation: data.congregation ?? null,
        invited_by_member_id: data.invited_by_member_id ?? null,
        invited_by_name: data.invited_by_name ?? null,
        how_heard: data.how_heard ?? null,
        notes: data.notes ?? null,
        at,
        by: userId
      }
    );
    const newId = Number(result.lastInsertRowid);
    execute(
      `INSERT INTO visitor_visits (visitor_id, visit_date, session_id, recorded_at, recorded_by)
       VALUES (@id, @date, @sessionId, @at, @by)`,
      { id: newId, date: firstVisit, sessionId: data.session_id ?? null, at, by: userId }
    );
    return newId;
  })();

  return getVisitor(id);
}

export function updateVisitor(id, data, { userId = null } = {}) {
  execute(
    `UPDATE visitors SET
       first_name = @first_name, last_name = @last_name, phone = @phone, email = @email,
       age_group = @age_group, congregation = @congregation,
       invited_by_member_id = @invited_by_member_id, invited_by_name = @invited_by_name,
       how_heard = @how_heard, notes = @notes, updated_at = @at
     WHERE id = @id`,
    {
      id,
      first_name: data.first_name,
      last_name: data.last_name ?? null,
      phone: data.phone ?? null,
      email: data.email ?? null,
      age_group: AGE_GROUPS.includes(data.age_group) ? data.age_group : null,
      congregation: data.congregation ?? null,
      invited_by_member_id: data.invited_by_member_id ?? null,
      invited_by_name: data.invited_by_name ?? null,
      how_heard: data.how_heard ?? null,
      notes: data.notes ?? null,
      at: nowIso()
    }
  );
  return getVisitor(id);
}

/**
 * Records that a visitor came again. The second visit is what turns a first
 * timer into someone who is returning.
 */
export function recordVisit(visitorId, { date, sessionId = null, notes = null, userId = null }) {
  const at = nowIso();
  // The visit and the "came back" state change are one unit.
  try {
    transaction(() => {
      execute(
        `INSERT INTO visitor_visits (visitor_id, visit_date, session_id, notes, recorded_at, recorded_by)
         VALUES (@id, @date, @sessionId, @notes, @at, @by)`,
        { id: visitorId, date, sessionId, notes, at, by: userId }
      );
      const visitor = queryOne('SELECT state FROM visitors WHERE id = @id', { id: visitorId });
      if (visitor && ['new', 'not_returned'].includes(visitor.state)) {
        execute("UPDATE visitors SET state = 'returning', updated_at = @at WHERE id = @id",
          { id: visitorId, at });
      }
    })();
  } catch (err) {
    if (!String(err.message).includes('UNIQUE')) throw err;
    // The visit for that date already exists. One recorded by hand on the day itself (the administrative form) has no service attached; checking the person
    // in at the door ties it to that Friday so the Friday's First Timer count includes them. A visit that already names a service is never moved.
    if (sessionId) {
      execute('UPDATE visitor_visits SET session_id = @sessionId WHERE visitor_id = @id AND visit_date = @date AND session_id IS NULL', { id: visitorId, date, sessionId });
    }
    return { ok: false, reason: 'already_recorded' };
  }
  return { ok: true, visits: visitsFor(visitorId).length };
}

/**
 * Records an outcome by hand. Returns { ok, reason?, visitor? }.
 *   joined_not_manual  'joined' can only come from converting or linking, never from this
 *   invalid_state      not one of MANUAL_OUTCOMES ('active' puts the visit-derived status back)
 *   is_member          the First Timer already is a member (state 'joined', member linked): their outcome is settled and read-only
 *   not_found
 */
export function setVisitorState(id, state, { userId = null, notes = null } = {}) {
  if (state === 'joined') return { ok: false, reason: 'joined_not_manual' };
  if (!MANUAL_OUTCOMES.includes(state)) return { ok: false, reason: 'invalid_state' };
  const current = queryOne('SELECT id, state, member_id FROM visitors WHERE id = @id', { id });
  if (!current) return { ok: false, reason: 'not_found' };
  if (current.member_id || current.state === 'joined') return { ok: false, reason: 'is_member' };
  // 'active' hands the status back to the visits.
  const stored = state === 'active' ? (visitsFor(id).length > 1 ? 'returning' : 'new') : state;
  execute(
    'UPDATE visitors SET state = @state, follow_up_notes = COALESCE(@notes, follow_up_notes), updated_at = @at WHERE id = @id AND member_id IS NULL',
    { id, state: stored, notes, at: nowIso() }
  );
  return { ok: true, visitor: getVisitor(id) };
}

export function setFollowUpState(id, state, { userId = null, notes = null } = {}) {
  if (!FOLLOW_UP_STATES.includes(state)) return null;
  execute(
    `UPDATE visitors SET follow_up_state = @state,
            follow_up_notes = COALESCE(@notes, follow_up_notes), updated_at = @at
      WHERE id = @id`,
    { id, state, notes, at: nowIso() }
  );
  return getVisitor(id);
}

/** Closes a visitor's open Membership Review in the caller's transaction. Returns the review id, or null if none was open. */
function closeOpenReview(visitorId, status, { userId, memberId, note = null }) {
  const open = queryOne("SELECT id FROM visitor_membership_reviews WHERE visitor_id = @visitorId AND status = 'open'", { visitorId });
  if (!open) return null;
  const closed = execute(
    `UPDATE visitor_membership_reviews
        SET status = @status, closed_at = @at, closed_by = @by, member_id = @memberId, note = COALESCE(@note, note)
      WHERE id = @id AND status = 'open'`,
    { id: open.id, status, at: nowIso(), by: userId, memberId, note }
  );
  return closed.changes === 1 ? open.id : null;
}

/** The member values a conversion starts from when an administrator has not edited them (programmatic use, tests). */
export function defaultMemberValuesFor(visitor) {
  return {
    first_name: visitor.first_name,
    last_name: visitor.last_name || visitor.first_name,
    phone: visitor.phone ?? null,
    email: visitor.email ?? null,
    age_group: visitor.age_group ?? null,
    date_joined: today(), // the day they were made a member - NOT the day they first visited
    notes: visitor.invited_by_name || visitor.inviter_first
      ? `First visited ${visitor.first_visit_date}, invited by ${visitor.invited_by_name || `${visitor.inviter_first} ${visitor.inviter_last}`}.`
      : `First visited ${visitor.first_visit_date}.`
  };
}

/**
 * Converts a First Timer into a NEW member. Explicit administrator action only; always creates a new member (linking to an
 * existing one is linkVisitorToMember). `values` are the validated member form values (lib/member-form.js collectMemberInput); when
 * omitted they are built from the visitor. The new member starts Pending and joined today unless the form says otherwise.
 *
 * One unit - the member, their status history, the link, state 'joined', the closing of an open Membership Review and the audit entries -
 * so a failure anywhere leaves no member, no link and no closed review. The First Timer's visits are never touched and are never
 * turned into member attendance. No QR code is issued here (it is created lazily by the normal member workflow).
 *
 * Returns { ok: true, member, visitor, reviewId, spouseConflictName } or { ok: false, reason }.
 */
export function convertToMember(id, { userId = null, req = null, values = null, body = {}, status = 'pending' } = {}) {
  const visitor = getVisitor(id);
  if (!visitor) return { ok: false, reason: 'not_found' };
  if (visitor.member_id || visitor.state === 'joined') return { ok: false, reason: 'already_a_member' };

  const memberValues = { ...(values || defaultMemberValuesFor(visitor)) };
  if (!memberValues.date_joined) memberValues.date_joined = today();
  let reviewId = null;
  try {
    const created = createMemberRecord({
      values: memberValues, body, status, userId, req, reason: 'Joined after visiting',
      auditDetail: { from_first_timer: id },
      alsoInTransaction: (member) => {
        // Re-check inside the write lock so two simultaneous conversions (or a conversion racing a link) cannot both pass the check above.
        const moved = execute(
          "UPDATE visitors SET member_id = @memberId, state = 'joined', updated_at = @at WHERE id = @id AND member_id IS NULL AND state != 'joined'",
          { id, memberId: member.id, at: nowIso() }
        );
        if (moved.changes !== 1) throw Object.assign(new Error('already a member'), { code: 'FIRST_TIMER_ALREADY_LINKED' });
        reviewId = closeOpenReview(id, 'converted', { userId, memberId: member.id });
        recordAudit({
          req, userId, action: 'visitor.became_member', entityType: 'visitor', entityId: id,
          detail: { member_id: member.id, via: 'convert', membership_review_id: reviewId }
        });
      }
    });
    return { ok: true, member: created.member, visitor: getVisitor(id), reviewId, spouseConflictName: created.spouseConflictName };
  } catch (err) {
    if (err.code === 'FIRST_TIMER_ALREADY_LINKED') return { ok: false, reason: 'already_a_member' };
    throw err;
  }
}

/**
 * Links a First Timer to an EXISTING member the administrator has explicitly chosen. Never matches by name or phone, never creates
 * or edits a member, never copies visits. Returns { ok, reason?, ... }:
 *   not_found / member_not_found
 *   already_a_member        the First Timer is already linked / joined
 *   member_already_linked   that member already belongs to another First Timer (otherVisitorId): refused, not merged
 * One transaction with the closing of an open review and the audit entry; the guarded UPDATE means two simultaneous links of the same
 * First Timer, or a link racing a conversion, produce exactly one result.
 */
export function linkVisitorToMember(visitorId, memberId, { userId = null, req = null } = {}) {
  const wanted = Number.parseInt(memberId, 10);
  if (!Number.isSafeInteger(wanted) || wanted <= 0) return { ok: false, reason: 'member_not_found' };
  try {
    return transaction(() => {
      const visitor = queryOne('SELECT id, state, member_id FROM visitors WHERE id = @id', { id: visitorId });
      if (!visitor) return { ok: false, reason: 'not_found' };
      if (visitor.member_id || visitor.state === 'joined') return { ok: false, reason: 'already_a_member' };
      if (!queryOne('SELECT id FROM members WHERE id = @id', { id: wanted })) return { ok: false, reason: 'member_not_found' };
      const other = queryOne('SELECT id FROM visitors WHERE member_id = @memberId', { memberId: wanted });
      if (other) return { ok: false, reason: 'member_already_linked', otherVisitorId: other.id };

      const moved = execute(
        "UPDATE visitors SET member_id = @memberId, state = 'joined', updated_at = @at WHERE id = @id AND member_id IS NULL AND state != 'joined'",
        { id: visitorId, memberId: wanted, at: nowIso() }
      );
      if (moved.changes !== 1) return { ok: false, reason: 'already_a_member' };
      const reviewId = closeOpenReview(visitorId, 'linked', { userId, memberId: wanted });
      recordAudit({
        req, userId, action: 'visitor.linked_to_member', entityType: 'visitor', entityId: visitorId,
        detail: { member_id: wanted, previous_state: visitor.state, membership_review_id: reviewId }
      });
      return { ok: true, visitor: getVisitor(visitorId), memberId: wanted, reviewId };
    }).immediate();
  } catch (err) {
    if (err && err.code === 'SQLITE_CONSTRAINT_UNIQUE') return { ok: false, reason: 'member_already_linked' };
    throw err;
  }
}

/** Read-only: the First Timer a member came from and the visits that were recorded before they were a member. Null if none. */
export function preMembershipHistory(memberId) {
  const visitor = queryOne(
    'SELECT id, first_name, last_name, first_visit_date, invited_by_name, invited_by_member_id FROM visitors WHERE member_id = @memberId',
    { memberId }
  );
  if (!visitor) return null;
  const visits = query(
    `SELECT vv.id, vv.visit_date, vv.session_id, s.service_type, s.title
       FROM visitor_visits vv LEFT JOIN attendance_sessions s ON s.id = vv.session_id
      WHERE vv.visitor_id = @id ORDER BY vv.visit_date ASC, vv.id ASC`,
    { id: visitor.id }
  );
  return { visitor, visits };
}

/** Splits a SQL fragment on commas that are not inside parentheses. */
function splitTopLevel(expression) {
  const parts = [];
  let depth = 0;
  let current = '';
  for (const char of expression) {
    if (char === '(') depth += 1;
    if (char === ')') depth -= 1;
    if (char === ',' && depth === 0) {
      parts.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  parts.push(current);
  return parts;
}

/** What the First Timers table may be sorted by, and the SQL each maps to. */
export const VISITOR_SORT_COLUMNS = {
  name: 'v.last_name COLLATE NOCASE, v.first_name COLLATE NOCASE',
  first_visit: 'v.first_visit_date',
  visits: 'visit_count',
  invited_by: "COALESCE(m.last_name, v.invited_by_name) COLLATE NOCASE",
  status: 'v.state'
};

export function listVisitors({
  state = null, followUp = null, search = '', from = null, to = null,
  inviterId = null, page = 1, pageSize = 25, sort = 'first_visit', direction = 'desc'
} = {}) {
  const params = {
    state, followUp, from, to, inviterId,
    search: search || '',
    like: likePattern(search),
    phoneLike: phoneFragmentLike(search),
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  const where = `
    WHERE (@state IS NULL OR v.state = @state)
      AND (@followUp IS NULL OR v.follow_up_state = @followUp)
      AND (@from IS NULL OR v.first_visit_date >= @from)
      AND (@to IS NULL OR v.first_visit_date <= @to)
      AND (@inviterId IS NULL OR v.invited_by_member_id = @inviterId)
      AND (@search = '' OR v.first_name LIKE @like ESCAPE '\\' OR v.last_name LIKE @like ESCAPE '\\'
           OR (v.first_name || ' ' || COALESCE(v.last_name, '')) LIKE @like ESCAPE '\\'
           OR v.phone LIKE @like ESCAPE '\\' OR (@phoneLike IS NOT NULL AND ${phoneDigitsSql('v.phone')} LIKE @phoneLike) OR v.invited_by_name LIKE @like ESCAPE '\\'
           OR m.first_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\')`;

  /*
   * The column and direction come from a fixed lookup, never dropped straight
   * into the query, so a sort request can never become a way to inject SQL.
   * The first visit date is always the tie-breaker, so two First Timers
   * sorted by, say, status still fall back to date order within each group.
   */
  const column = VISITOR_SORT_COLUMNS[sort] || VISITOR_SORT_COLUMNS.first_visit;
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  // A sort key can be more than one column (name is last name, then first
  // name) — direction has to apply to every part of it, not just whichever
  // one happens to be written last, or reversing the sort would only ever
  // flip the tie-breaker while the main column stayed pinned one way. The
  // split only happens at the top level, so a comma inside a function call
  // like COALESCE(a, b) is left alone rather than torn in two.
  const columnWithDirection = splitTopLevel(column).map((part) => `${part.trim()} ${dir}`).join(', ');
  const orderBy = column === VISITOR_SORT_COLUMNS.first_visit
    ? `v.first_visit_date ${dir}, v.id ${dir}`
    : `${columnWithDirection}, v.first_visit_date DESC, v.id DESC`;

  const rows = query(
    `SELECT v.*,
            m.first_name AS inviter_first, m.last_name AS inviter_last,
            m.preferred_name AS inviter_preferred, m.phone AS inviter_phone,
            (SELECT COUNT(*) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS visit_count,
            (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS last_visit
       FROM visitors v
       LEFT JOIN members m ON m.id = v.invited_by_member_id
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    params
  );

  const total = queryOne(
    `SELECT COUNT(*) AS n FROM visitors v LEFT JOIN members m ON m.id = v.invited_by_member_id ${where}`,
    params
  ).n;

  for (const row of rows) row.display_state = displayState(row, row.visit_count);
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/**
 * First Timers who have not been seen since, past the grace period. These are
 * the ones worth a word with whoever invited them.
 */
export const FOLLOW_UP_SORT_COLUMNS = ['name', 'last_visit', 'inviter'];

export function needingFollowUp({ graceDays = 21, limit = 200, sort = null, direction = 'asc' } = {}) {
  const cutoff = addDays(today(), -graceDays);
  const rows = query(
    `SELECT v.*,
            m.first_name AS inviter_first, m.last_name AS inviter_last,
            m.preferred_name AS inviter_preferred, m.phone AS inviter_phone,
            m.email AS inviter_email, m.id AS inviter_id,
            (SELECT COUNT(*) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS visit_count,
            (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS last_visit
       FROM visitors v
       LEFT JOIN members m ON m.id = v.invited_by_member_id
      WHERE v.state IN ('new', 'not_returned', 'returning')
        AND v.member_id IS NULL
        AND v.follow_up_state NOT IN ('completed', 'dismissed')
        -- A First Timer who has never had a later visit logged has no row in
        -- visitor_visits at all; falling back to their first visit date means
        -- that most common case is judged by the grace period too, instead
        -- of a missing date silently excusing them from ever being flagged.
        AND COALESCE(
          (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = v.id),
          v.first_visit_date
        ) < @cutoff
      ORDER BY last_visit DESC, v.id DESC
      LIMIT @limit`,
    { cutoff, limit }
  ).map((visitor) => ({
    ...visitor,
    message: visitor.visit_count === 1
      ? `First visited on ${visitor.first_visit_date} and has not been recorded since.`
      : `Last recorded visit was ${visitor.last_visit}, after ${visitor.visit_count} visits.`,
    inviterLabel: visitor.invited_by_name
      || (visitor.inviter_first ? `${visitor.inviter_preferred || visitor.inviter_first} ${visitor.inviter_last || ''}`.trim() : null)
  }));

  // 'inviterLabel' only exists after the map() above, so a sort by it (or by
  // name, for consistency with every other sortable column in this file)
  // happens here rather than in the SQL.
  if (sort && FOLLOW_UP_SORT_COLUMNS.includes(sort)) {
    const dirMul = direction === 'desc' ? -1 : 1;
    const valueFor = {
      name: (v) => `${v.last_name || ''} ${v.first_name || ''}`.toLowerCase(),
      last_visit: (v) => v.last_visit || '',
      inviter: (v) => (v.inviterLabel || '').toLowerCase()
    }[sort];
    rows.sort((a, b) => {
      const av = valueFor(a);
      const bv = valueFor(b);
      if (av < bv) return -1 * dirMul;
      if (av > bv) return 1 * dirMul;
      return 0;
    });
  }

  return rows;
}

/** Marks visitors as not returned once the grace period has passed. */
export function markLapsedVisitors({ graceDays = 21 } = {}) {
  const cutoff = addDays(today(), -graceDays);
  const result = execute(
    `UPDATE visitors SET state = 'not_returned', updated_at = @at
      WHERE state = 'new' AND member_id IS NULL
        AND (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = visitors.id) < @cutoff`,
    { cutoff, at: nowIso() }
  );
  return result.changes;
}

export function visitorCounts({ from = null, to = null } = {}) {
  const rows = query(
    `SELECT state, COUNT(*) AS n FROM visitors
      WHERE (@from IS NULL OR first_visit_date >= @from)
        AND (@to IS NULL OR first_visit_date <= @to)
      GROUP BY state`,
    { from, to }
  );
  const counts = { new: 0, returning: 0, joined: 0, not_returned: 0, declined: 0 };
  for (const row of rows) counts[row.state] = row.n;
  counts.total = Object.values(counts).reduce((a, b) => a + b, 0);
  counts.stillVisiting = counts.new + counts.returning;
  return counts;
}

/** Who invites people, and how many of them stay. */
/** What the "Who is inviting people" table may be sorted by. */
export const INVITER_SORT_COLUMNS = {
  member: 'm.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE',
  invited: 'invited',
  still_visiting: 'still_visiting',
  joined: 'joined',
  lapsed: 'lapsed'
};

/**
 * One row per member who has invited someone, with how those visits turned
 * out. Sorted and paginated the same careful way as everywhere else in the
 * portal: a fixed column lookup, direction applied to every part of a
 * compound key, and the count kept independent of the sort or the page.
 */
export function inviterSummary({ page = 1, pageSize = 20, sort = 'invited', direction = 'desc' } = {}) {
  const column = INVITER_SORT_COLUMNS[sort] || INVITER_SORT_COLUMNS.invited;
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  const columnWithDirection = splitTopLevel(column).map((part) => `${part.trim()} ${dir}`).join(', ');
  const orderBy = column === INVITER_SORT_COLUMNS.invited
    ? `invited ${dir}, m.last_name COLLATE NOCASE`
    : `${columnWithDirection}, invited DESC`;

  const rows = query(
    `SELECT m.id, m.first_name, m.last_name, m.preferred_name, m.member_code,
            COUNT(v.id) AS invited,
            SUM(CASE WHEN v.state = 'joined' THEN 1 ELSE 0 END) AS joined,
            SUM(CASE WHEN v.state IN ('new','returning') THEN 1 ELSE 0 END) AS still_visiting,
            SUM(CASE WHEN v.state IN ('not_returned','declined') THEN 1 ELSE 0 END) AS lapsed
       FROM visitors v
       JOIN members m ON m.id = v.invited_by_member_id
      GROUP BY m.id
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    { limit: pageSize, offset: (page - 1) * pageSize }
  );

  const total = queryOne(
    `SELECT COUNT(DISTINCT v.invited_by_member_id) AS n
       FROM visitors v WHERE v.invited_by_member_id IS NOT NULL`
  ).n;

  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/**
 * Everyone one particular member has invited, in the order that matters most
 * for actually following up: whoever genuinely needs it first (the same
 * rule as the main follow-up list — not seen again within the grace period,
 * and nobody has closed the matter), then whoever is still visiting, then
 * whoever was invited most recently, with people who have already become
 * members or who did not continue at the end. Their record is kept either
 * way; it just does not compete for attention against people who need it.
 */
export function inviteesFor(inviterId, { graceDays = 21 } = {}) {
  const cutoff = addDays(today(), -graceDays);

  const needsFollowUp = `(
    v.state IN ('new', 'not_returned', 'returning')
    AND v.member_id IS NULL
    AND v.follow_up_state NOT IN ('completed', 'dismissed')
    AND COALESCE(
      (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = v.id),
      v.first_visit_date
    ) < @cutoff
  )`;

  const priority = `CASE
    WHEN ${needsFollowUp} THEN 0
    WHEN v.state IN ('new', 'returning') THEN 1
    WHEN v.state = 'joined' THEN 2
    WHEN v.state IN ('not_returned', 'declined') THEN 3
    ELSE 1
  END`;

  return query(
    `SELECT v.*,
            (SELECT COUNT(*) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS visit_count,
            (SELECT MAX(vv.visit_date) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS last_visit,
            ${needsFollowUp} AS needs_follow_up
       FROM visitors v
      WHERE v.invited_by_member_id = @inviterId
      ORDER BY ${priority}, v.first_visit_date DESC`,
    { inviterId, cutoff }
  ).map((row) => ({ ...row, display_state: displayState(row, row.visit_count) }));
}


/**
 * Everything the First Timers report needs, computed from one filtered set
 * of records so the headline totals and the per-inviter breakdown can never
 * quietly disagree with each other. The same grace-period rule used
 * throughout this module decides who still needs follow-up.
 */
export function firstTimersReportData({ from = null, to = null, state = null, inviterId = null, graceDays = 21 } = {}) {
  const rows = listVisitors({ from, to, state, inviterId, pageSize: 100000 }).rows;
  const cutoff = addDays(today(), -graceDays);

  const byState = { new: 0, returning: 0, joined: 0, not_returned: 0, declined: 0 };
  const byFollowUp = { new: 0, acknowledged: 0, contacted: 0, completed: 0, dismissed: 0 };
  let returnedAtLeastOnce = 0;
  let needsFollowUpCount = 0;

  const inviterTotals = new Map();

  for (const v of rows) {
    byState[v.state] = (byState[v.state] || 0) + 1;
    byFollowUp[v.follow_up_state] = (byFollowUp[v.follow_up_state] || 0) + 1;
    if (v.visit_count > 1) returnedAtLeastOnce += 1;

    const lastSeen = v.last_visit || v.first_visit_date;
    const stillOpen = ['new', 'not_returned', 'returning'].includes(v.state)
      && !v.member_id
      && !['completed', 'dismissed'].includes(v.follow_up_state)
      && lastSeen < cutoff;
    if (stillOpen) needsFollowUpCount += 1;

    if (v.invited_by_member_id) {
      const key = v.invited_by_member_id;
      const label = [v.inviter_preferred || v.inviter_first, v.inviter_last].filter(Boolean).join(' ') || 'Unknown';
      const existing = inviterTotals.get(key) || { id: key, name: label, invited: 0, joined: 0, stillVisiting: 0, lapsed: 0 };
      existing.invited += 1;
      if (v.state === 'joined') existing.joined += 1;
      if (['new', 'returning'].includes(v.state)) existing.stillVisiting += 1;
      if (['not_returned', 'declined'].includes(v.state)) existing.lapsed += 1;
      inviterTotals.set(key, existing);
    }
  }

  const total = rows.length;
  const stillVisiting = byState.new + byState.returning;
  const didNotContinue = byState.not_returned + byState.declined;
  const pct = (n) => (total ? Math.round((n / total) * 100) : 0);

  return {
    total,
    byState,
    byFollowUp,
    stillVisiting,
    returnedAtLeastOnce,
    joined: byState.joined,
    didNotContinue,
    needsFollowUp: needsFollowUpCount,
    conversionRate: pct(byState.joined),
    retentionRate: pct(stillVisiting + byState.joined),
    inviters: [...inviterTotals.values()].sort((a, b) => b.invited - a.invited)
  };
}
/*
 * Possible duplicates for a First Timer about to be recorded. WARN ONLY: it never blocks, merges or links anything
 * (whether a matching person is "the same person" is the administrator's call). It uses identifiers that already
 * exist - a phone number and the written name - against other First Timers and against member records.
 */
export function findPossibleDuplicates({ first_name: first, last_name: last = null, phone = null }, { excludeVisitorId = null } = {}) {
  const firstName = String(first || '').trim().toLowerCase();
  const lastName = String(last || '').trim().toLowerCase();
  const matches = [];
  if (!firstName) return matches;

  // The phone comparison is the portal's one canonical rule (lib/phone.js): +974 7701 7992, 97477017992 and 77017992 are the same number.
  for (const v of query(
    `SELECT id, first_name, last_name, phone, state, member_id FROM visitors
      WHERE (@exclude IS NULL OR id <> @exclude)
        AND ((LOWER(TRIM(first_name)) = @first AND LOWER(TRIM(COALESCE(last_name, ''))) = @last)
             OR (@hasPhone = 1 AND phone IS NOT NULL AND TRIM(phone) <> ''))
      ORDER BY id`,
    { exclude: excludeVisitorId, first: firstName, last: lastName, hasPhone: phone ? 1 : 0 }
  ).filter((v) => (String(v.first_name || '').trim().toLowerCase() === firstName && String(v.last_name || '').trim().toLowerCase() === lastName) || phoneMatches(v.phone, phone)).slice(0, 10)) {
    const sameName = String(v.first_name || '').trim().toLowerCase() === firstName
      && String(v.last_name || '').trim().toLowerCase() === lastName;
    const samePhone = phoneMatches(v.phone, phone);
    matches.push({
      type: 'visitor', id: v.id, name: [v.first_name, v.last_name].filter(Boolean).join(' '),
      detail: v.member_id ? 'First Timer, already has a member record' : 'First Timer',
      reason: [sameName ? 'same name' : null, samePhone ? 'same phone number' : null].filter(Boolean).join(' and '),
      href: `/visitors/${v.id}`
    });
  }

  for (const m of query(
    `SELECT id, member_code, first_name, last_name, phone, status FROM members
      WHERE (LOWER(TRIM(first_name)) = @first AND LOWER(TRIM(last_name)) = @last)
         OR (@hasPhone = 1 AND phone IS NOT NULL AND TRIM(phone) <> '')
      ORDER BY id`,
    { first: firstName, last: lastName, hasPhone: phone ? 1 : 0 }
  ).filter((m) => (String(m.first_name || '').trim().toLowerCase() === firstName && String(m.last_name || '').trim().toLowerCase() === lastName) || phoneMatches(m.phone, phone)).slice(0, 10)) {
    const sameName = String(m.first_name || '').trim().toLowerCase() === firstName
      && String(m.last_name || '').trim().toLowerCase() === lastName;
    const samePhone = phoneMatches(m.phone, phone);
    matches.push({
      type: 'member', id: m.id, name: [m.first_name, m.last_name].filter(Boolean).join(' '),
      detail: `Member ${m.member_code}`,
      reason: [sameName ? 'same name' : null, samePhone ? 'same phone number' : null].filter(Boolean).join(' and '),
      href: `/members/${m.id}`
    });
  }
  return matches;
}
