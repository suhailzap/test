import { query, queryOne } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { today, addDays, diffInDays } from '../lib/dates.js';
import { csvCell } from '../lib/csv.js';
import { serviceHeadcount } from './service-headcount.js';
import { getLatestFridayService, FRIDAY_SERVICE } from './friday-service.js';
import { displayName, DEFAULT_ROSTER_STATUSES, normalizeMemberStatuses } from './members.js';
import {
  classifySession, trackingStartDate, isTrackingConfigured, isFridayService
} from './attendance-tracking.js';
import {
  STATE_LABELS, buildFridayContexts, memberOutcomeAt, memberTimeline, memberRate, pooledRate,
  consecutiveAbsenceRun, followUpRules, followUpCompleteness, lastPositiveAttendance,
  expectedRosterForSession, computeSessionSummary
} from './attendance-outcomes.js';

/*
 * The attendance read models: everything that turns attendance rows into
 * numbers or lists a person reads - follow-up, Long Absence, member history,
 * session and cell-group summaries, the attendance report and its CSV.
 *
 * They contain NO rule of their own about what a missing row means. For a
 * tracked Friday every answer comes from attendance-outcomes.js (tracking
 * start date + session lifecycle + the historical expected snapshot +
 * the attendance row + cancellation). Non-Friday sessions (cell group
 * meetings, special services) are not interpreted there and keep their
 * existing semantics.
 *
 * Cell group attribution: attendance_expected snapshots WHO was expected, not
 * which cell group they belonged to. A member's cell group in any figure below
 * is therefore their CURRENT one (the existing model); the church-wide
 * expected roster and rate are historically stable, per-group splits are not.
 */

const ROSTER_STATUS_SQL = DEFAULT_ROSTER_STATUSES.map((s) => `'${s}'`).join(',');

// ---------------------------------------------------------------------------
// Shared context helpers
// ---------------------------------------------------------------------------

/**
 * Prepared, newest-first counting Fridays since the tracking start date - the
 * tracked sequence follow-up is evaluated over. Empty when tracking has not
 * started. Build it ONCE and pass it to every per-member call in a loop.
 */
export function trackedFridayContexts() {
  const goLive = trackingStartDate();
  if (!goLive) return [];
  return buildFridayContexts({ from: goLive, to: today(), countingOnly: true });
}

const NOT_STARTED_RUN = () => ({
  ...consecutiveAbsenceRun(0, []),
  endedBy: 'not_started'
});

/**
 * The member's current run of consecutive absences from tracked, finalized
 * Fridays. Signature-compatible with the previous implementation; the extra
 * `contexts` option lets loops share one prepared sequence.
 */
export function consecutiveMissedFridays(memberId, { contexts = null } = {}) {
  if (!isTrackingConfigured()) return NOT_STARTED_RUN();
  return consecutiveAbsenceRun(memberId, contexts || trackedFridayContexts());
}

/** Latest Friday with positive attendance evidence for a member (any era), for display and engagement. */
export function lastAttendedFriday(memberId) {
  return lastPositiveAttendance(memberId);
}

// ---------------------------------------------------------------------------
// Member attendance summary and history
// ---------------------------------------------------------------------------

/** The label for a resolved state, including the "not tracked" wording. */
function labelFor(state) {
  return STATE_LABELS[state] || state;
}

/**
 * Recent Friday Services for one member with canonical outcomes. `status` is
 * the display key ('present', 'excused', 'absent', 'pending',
 * 'awaiting_finalization', 'not_expected', 'not_taken', 'not_tracked') so the
 * existing strips and pills render it unchanged; `state` and `derived` carry
 * the canonical meaning.
 */
export function memberAttendanceSummary(memberId, { lastN = 8 } = {}) {
  const contexts = buildFridayContexts({ countingOnly: true, limit: lastN + 12 })
    .filter((c) => c.phase !== 'cancelled')
    .slice(0, lastN);
  const consecutive = consecutiveMissedFridays(memberId);
  if (contexts.length === 0) {
    return { services: [], presentCount: 0, rate: null, rateServices: 0, lastAttended: lastAttendedFriday(memberId), consecutive };
  }
  const services = memberTimeline(memberId, contexts).map((t) => ({
    id: t.sessionId,
    date: t.date,
    status: t.token,
    state: t.state,
    label: labelFor(t.state),
    derived: t.derived,
    phase: t.phase,
    tracked: !['not_started', 'pre_go_live'].includes(t.phase)
  }));
  const presentCount = services.filter((s) => s.state === 'present').length;
  const measured = memberRate(memberId, contexts);
  return {
    services,
    presentCount,
    // Only finalized tracked Fridays at which the member was expected can produce a rate.
    rate: measured.rate,
    rateServices: measured.sessions,
    lastAttended: lastAttendedFriday(memberId),
    consecutive
  };
}

/** Attendance for one member across sessions, newest first, with canonical Friday outcomes. */
export function memberAttendanceHistory(memberId, { limit = 50 } = {}) {
  const rows = query(
    `SELECT s.id, s.service_date, s.service_type, s.title, s.status AS session_status,
            s.counts_toward_followup, r.status, r.notes, r.recorded_at,
            u.display_name AS recorded_by_name
       FROM attendance_sessions s
       LEFT JOIN attendance_records r ON r.session_id = s.id AND r.member_id = @id
       LEFT JOIN users u ON u.id = r.recorded_by
      WHERE (s.status != 'cancelled' OR s.service_type = 'friday_service')
        AND (s.cell_group_id = 0 OR s.cell_group_id IS NULL
             OR s.cell_group_id = (SELECT cell_group_id FROM members WHERE id = @id))
      ORDER BY s.service_date DESC
      LIMIT @limit`,
    { id: memberId, limit }
  );
  const fridayDates = rows.filter((r) => r.service_type === FRIDAY_SERVICE).map((r) => r.service_date);
  const byId = new Map();
  if (fridayDates.length) {
    const from = fridayDates.reduce((a, b) => (a < b ? a : b));
    for (const ctx of buildFridayContexts({ from, to: fridayDates.reduce((a, b) => (a > b ? a : b)) })) byId.set(ctx.id, ctx);
  }
  return rows.map((row) => {
    const ctx = byId.get(row.id);
    if (!ctx) return { ...row, status: row.status || 'not_recorded', state: null, derived: false };
    const r = memberOutcomeAt(ctx, memberId);
    return { ...row, status: r.token, state: r.state, stateLabel: labelFor(r.state), derived: r.derived, phase: ctx.phase };
  });
}

// ---------------------------------------------------------------------------
// Session summary
// ---------------------------------------------------------------------------

function rawCounts(sessionId) {
  return queryOne(
    `SELECT
       SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
       SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent,
       SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) AS excused,
       SUM(CASE WHEN status = 'visitor' THEN 1 ELSE 0 END) AS visitor,
       COUNT(*) AS recorded
     FROM attendance_records WHERE session_id = @id`,
    { id: sessionId }
  );
}

/**
 * Cell group meetings and other non-Friday sessions: the existing semantics,
 * against the current expected roster.
 */
function legacySessionSummary(sessionId, counts) {
  const rosterCounts = queryOne(
    `SELECT
       SUM(CASE WHEN r.status = 'present' THEN 1 ELSE 0 END) AS present,
       SUM(CASE WHEN r.status = 'excused' THEN 1 ELSE 0 END) AS excused,
       COUNT(*) AS recorded
     FROM attendance_records r
     JOIN members m ON m.id = r.member_id
    WHERE r.session_id = @id AND m.status IN (${ROSTER_STATUS_SQL})`,
    { id: sessionId }
  );
  const activeMembers = queryOne(`SELECT COUNT(*) AS n FROM members WHERE status IN (${ROSTER_STATUS_SQL})`).n;
  const rosterPresent = rosterCounts?.present || 0;
  const rosterExcused = rosterCounts?.excused || 0;
  const rosterRecorded = rosterCounts?.recorded || 0;
  const rateDenominator = Math.max(activeMembers - rosterExcused, 0);
  return {
    present: counts?.present || 0,
    absent: counts?.absent || 0,
    excused: counts?.excused || 0,
    visitor: counts?.visitor || 0,
    recorded: counts?.recorded || 0,
    activeMembers,
    notRecorded: Math.max(activeMembers - rosterRecorded, 0),
    rate: rateDenominator ? Math.round((rosterPresent / rateDenominator) * 100) : null,
    phase: 'not_applicable',
    tracked: null,
    physical: serviceHeadcount(sessionId)
  };
}

/**
 * Summary counts for one session.
 *
 * The raw fields (`present`, `absent`, `excused`, `visitor`, `recorded`) are
 * always the recorded facts. For a FRIDAY the lifecycle-aware picture is in:
 *   phase / lifecycleLabel
 *   tracked   null when the Friday is not tracked (before Go-Live, or tracking
 *             not started) - such a Friday reports what was recorded and nothing
 *             else: no expected count, no not-recorded count, no rate, no absence.
 *             Otherwise { expected, present, vacation, recordedAbsent,
 *             derivedAbsent, absent, pending, unexpected, firstTimeVisitors,
 *             headcount, rate, final, notTaken, cancelled }.
 * `rate` is only ever the FINAL rate of a finalized Friday, else null.
 * Not-taken and cancelled Fridays carry no roster and no rate.
 */
export function sessionSummary(sessionId) {
  return withFigures(sessionSummaryCore(sessionId));
}

/**
 * The few numbers a list row shows, decided ONCE here so every list (Friday
 * list, sessions history, landing) says the same thing for the same Friday:
 * present / vacation / absent / pending / rate, each null when it does not
 * apply, plus a plain-language `register` state. A Friday that is not
 * finalized never shows an absence or a rate; a Friday before tracking shows
 * only what was recorded.
 */
function withFigures(summary) {
  const t = summary.tracked;
  // members / firstTimers / total are the physical headcount (service-headcount.js) and are present whatever the lifecycle phase; `present` below is the
  // member figure of that phase (expected members present while tracked) and is not a headcount.
  const physical = summary.physical || { members: 0, firstTimers: 0, returning: 0, visitors: 0, total: 0 };
  const figures = {
    present: null, vacation: null, absent: null, pending: null, rate: null, register: null, registerTone: 'inactive',
    members: physical.members, firstTimers: physical.firstTimers, returning: physical.returning, total: physical.total
  };
  if (t) {
    if (t.cancelled) { figures.register = 'Cancelled'; }
    else if (t.notTaken) {
      figures.present = t.headcount; figures.register = 'Attendance not taken'; figures.registerTone = 'archived';
    } else {
      figures.present = t.present; figures.vacation = t.vacation;
      if (t.final) {
        figures.absent = t.absent; figures.pending = 0; figures.rate = t.rate;
        figures.register = 'Finalized'; figures.registerTone = 'active';
      } else {
        figures.pending = t.pending;
        figures.register = t.phase === 'awaiting_finalization' ? 'Awaiting finalization' : (t.phase === 'scheduled' ? 'Scheduled' : 'Open');
        figures.registerTone = 'pending';
      }
    }
  } else if (summary.phase === 'pre_go_live' || summary.phase === 'not_started') {
    figures.present = (summary.present || 0) + (summary.visitor || 0);
    figures.vacation = summary.excused; figures.absent = summary.absent;
    figures.register = 'Not tracked';
  } else {
    figures.present = summary.present; figures.vacation = summary.excused; figures.absent = summary.absent;
    figures.pending = summary.notRecorded; figures.rate = summary.rate;
    figures.register = summary.recorded === 0 ? 'Not started' : (summary.notRecorded > 0 ? summary.notRecorded + ' still to mark' : 'Complete');
    figures.registerTone = summary.recorded === 0 ? 'inactive' : (summary.notRecorded > 0 ? 'pending' : 'active');
  }
  return { ...summary, figures };
}

function sessionSummaryCore(sessionId) {
  const counts = rawCounts(sessionId);
  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  if (!session || !isFridayService(session)) return legacySessionSummary(sessionId, counts);

  const classification = classifySession(session);
  const physical = serviceHeadcount(sessionId);
  const base = {
    present: counts?.present || 0,
    absent: counts?.absent || 0,
    excused: counts?.excused || 0,
    visitor: counts?.visitor || 0,
    recorded: counts?.recorded || 0,
    activeMembers: null,
    notRecorded: null,
    rate: null,
    phase: classification.phase,
    tracked: null,
    physical
  };
  if (!classification.tracked) return base;

  const visitors = physical.visitors;
  if (classification.phase === 'cancelled' || classification.phase === 'not_taken') {
    return {
      ...base,
      tracked: {
        phase: classification.phase, final: false,
        notTaken: classification.phase === 'not_taken', cancelled: classification.phase === 'cancelled',
        expected: null, present: null, vacation: null, recordedAbsent: null, derivedAbsent: 0, absent: null,
        pending: 0, unexpected: null, firstTimeVisitors: visitors, headcount: physical.total,
        rate: null, rateNumerator: 0, rateDenominator: 0, rosterSource: null
      }
    };
  }

  const roster = expectedRosterForSession(session);
  const s = computeSessionSummary(session, roster, classification.phase);
  return {
    ...base,
    activeMembers: s.expected,
    notRecorded: s.pending,
    rate: s.finalRate,
    tracked: {
      phase: classification.phase,
      final: s.final,
      notTaken: false,
      cancelled: false,
      expected: s.expected,
      present: s.presentExpected,
      vacation: s.vacation,
      recordedAbsent: s.absentRecorded,
      derivedAbsent: s.derivedAbsent,
      absent: s.final ? s.absentTotal : s.absentRecorded,
      pending: s.pending,
      unexpected: s.unexpectedAttendees,
      firstTimeVisitors: s.firstTimeVisitors,
      headcount: s.actualHeadcount,
      rate: s.finalRate,
      rateNumerator: s.rateNumerator,
      rateDenominator: s.rateDenominator,
      rosterSource: roster.source
    }
  };
}

// ---------------------------------------------------------------------------
// Follow-up list
// ---------------------------------------------------------------------------

/** What the follow-up table may be sorted by, and how to compare two rows by it. */
export const FOLLOWUP_SORT_COLUMNS = {
  member: (a, b) => `${a.member.last_name} ${a.member.first_name}`
    .localeCompare(`${b.member.last_name} ${b.member.first_name}`, undefined, { sensitivity: 'base' }),
  streak: (a, b) => a.streak - b.streak,
  last_attended: (a, b) => (a.lastAttended?.service_date || '').localeCompare(b.lastAttended?.service_date || ''),
  missed: (a, b) => a.missed.length - b.missed.length
};

/**
 * Members whose current consecutive absence run - over tracked, FINALIZED
 * Fridays at which they were expected - has reached the configured threshold
 * (attendance.followup_threshold). Derived from current lifecycle truth on
 * every call, never from stored reminder rows. Until attendance tracking has
 * started the list is empty: nothing is absent yet.
 *
 * An unsettled past Friday is a barrier the run is never evaluated across;
 * see followUpStatus() for whether the list can be called complete.
 */
export function followUpList({ limit = 100, sort = 'streak', direction = 'desc', contexts = null } = {}) {
  if (!isTrackingConfigured()) return [];
  const goLive = trackingStartDate();
  const sequence = contexts || trackedFridayContexts();
  const members = query(
    `SELECT id, member_code, first_name, last_name, preferred_name, date_joined, cell_group_id
       FROM members
      WHERE status IN (${ROSTER_STATUS_SQL})
      ORDER BY last_name, first_name
      LIMIT @limit`,
    { limit }
  );
  const recentEngagementDays = Number(getSetting('attendance.recent_engagement_days')) || 0;
  const flagged = [];
  for (const member of members) {
    const result = consecutiveAbsenceRun(member.id, sequence);
    if (!result.flagged) continue;

    const lastAttended = lastAttendedFriday(member.id);
    // Reaching the threshold of finalized eligible absences is what qualifies a member
    // for follow-up. A member does NOT need a prior Present: someone expected and absent
    // at three finalized Fridays since Go-Live qualifies even if they have never checked
    // in, and attendance from BEFORE Go-Live is never a prerequisite (after the reset it
    // will not exist). The engagement window (attendance.recent_engagement_days) only
    // steps aside for someone whose last TRACKED-era attendance is older than the window:
    // they went quiet long ago, which is what the Long Absence review is for, not this
    // weekly list. `lastAttended` above (any era) is for display only.
    if (recentEngagementDays > 0) {
      const trackedLast = lastPositiveAttendance(member.id, { since: goLive });
      if (trackedLast && diffInDays(trackedLast.service_date, today()) > recentEngagementDays) continue;
    }

    flagged.push({
      member,
      streak: result.streak,
      threshold: result.threshold,
      missed: result.missed,
      runStart: result.runStart,
      episodeSessionIds: result.episodeSessionIds,
      lastAttended,
      message: `Member has not had recorded attendance for ${result.streak} consecutive Friday Services. Follow-up may be appropriate.`
    });
  }

  const comparator = FOLLOWUP_SORT_COLUMNS[sort] || FOLLOWUP_SORT_COLUMNS.streak;
  const sign = direction === 'asc' ? 1 : -1;
  return flagged.sort((a, b) => sign * comparator(a, b));
}

/**
 * Can follow-up be called complete? `complete` is false while any past tracked
 * Friday is still awaiting finalization - members' runs may be understated
 * until it is settled, and Church Admins must not be told otherwise.
 */
export function followUpStatus({ contexts = null } = {}) {
  const configured = isTrackingConfigured();
  if (!configured) return { configured: false, complete: true, awaitingFridays: [], threshold: followUpRules().threshold };
  const status = followUpCompleteness(contexts || trackedFridayContexts());
  return { configured: true, ...status, threshold: followUpRules().threshold };
}

// ---------------------------------------------------------------------------
// Long Absence review
// ---------------------------------------------------------------------------

/** What the long-absence report may be sorted by. */
export const LONG_ABSENCE_SORT_COLUMNS = {
  member: (a, b) => `${a.member.last_name} ${a.member.first_name}`
    .localeCompare(`${b.member.last_name} ${b.member.first_name}`, undefined, { sensitivity: 'base' }),
  last_attended: (a, b) => (a.lastAttended?.service_date || '').localeCompare(b.lastAttended?.service_date || ''),
  days_away: (a, b) => a.daysAway - b.daysAway
};

/**
 * Long Absence for the tracked era. The rule, exactly:
 *
 *  1. Tracking not started        -> status 'not_started', nobody listed.
 *  2. Observation window W = attendance.recent_engagement_days (56 if unset/0).
 *     Fewer than W days since the tracking start date
 *                                 -> status 'insufficient_history', nobody listed:
 *                                    the window is not yet covered by tracked
 *                                    attendance, so no one is called long absent.
 *  3. Otherwise a member of the current expected roster statuses is long absent
 *     when they have NO positive attendance (Present, or a member-linked Visitor
 *     row) on any non-cancelled Friday within the last W days. Positive evidence
 *     from any Friday counts - finalized or not, tracked or earlier - so it can
 *     only ever remove someone from the list, never add them.
 *       - no positive attendance at all on record -> 'no_tracked_attendance'
 *         (never "never attended": records from before tracking may simply not exist)
 *       - otherwise 'long_absent', with their last attended Friday and days away.
 *  4. If any past tracked Friday inside the window is still awaiting
 *     finalization, `complete` is false: a missing check-in there may yet be entered.
 *
 * Returns { status, goLive, trackedDays, requiredDays, complete, awaitingFridays, rows }.
 */
export function longAbsenceReview({ limit = 500, sort = 'days_away', direction = 'desc' } = {}) {
  const windowDays = Number(getSetting('attendance.recent_engagement_days')) || 56;
  const goLive = trackingStartDate();
  const empty = (status, trackedDays = 0) => ({
    status, goLive, trackedDays, requiredDays: windowDays, complete: true, awaitingFridays: [], rows: []
  });
  if (!goLive) return empty('not_started');
  const trackedDays = Math.max(diffInDays(goLive, today()), 0);
  if (trackedDays < windowDays) return empty('insufficient_history', trackedDays);

  const members = query(
    `SELECT m.id, m.member_code, m.first_name, m.last_name, m.preferred_name, m.date_joined,
            m.cell_group_id, m.status, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.status IN (${ROSTER_STATUS_SQL})
      ORDER BY m.last_name, m.first_name
      LIMIT @limit`,
    { limit }
  );

  const rows = [];
  for (const member of members) {
    const lastAttended = lastAttendedFriday(member.id);
    const daysAway = lastAttended ? diffInDays(lastAttended.service_date, today()) : null;
    if (daysAway !== null && daysAway <= windowDays) continue;
    rows.push({
      member,
      lastAttended,
      daysAway: daysAway === null ? Infinity : daysAway,
      neverAttended: daysAway === null,
      state: daysAway === null ? 'no_tracked_attendance' : 'long_absent'
    });
  }

  const comparator = LONG_ABSENCE_SORT_COLUMNS[sort] || LONG_ABSENCE_SORT_COLUMNS.days_away;
  const sign = direction === 'asc' ? 1 : -1;
  const awaiting = trackedFridayContexts()
    .filter((c) => c.phase === 'awaiting_finalization' && c.date >= addDays(today(), -windowDays))
    .map((c) => ({ id: c.id, date: c.date }));
  return {
    status: 'ready', goLive, trackedDays, requiredDays: windowDays,
    complete: awaiting.length === 0, awaitingFridays: awaiting,
    rows: rows.sort((a, b) => sign * comparator(a, b))
  };
}

/** The Long Absence rows only (empty unless the review is ready). */
export function longAbsenceList(options = {}) {
  return longAbsenceReview(options).rows;
}

// ---------------------------------------------------------------------------
// Landing, dashboard and trend
// ---------------------------------------------------------------------------

export function latestServiceOverview() {
  const session = getLatestFridayService(today());
  if (!session) return null;
  return { session, summary: sessionSummary(session.id) };
}

/**
 * Attendance per recent Friday for the trend charts. Rates and counts here are
 * only ever for SETTLED Fridays: finalized tracked ones, plus history from
 * before tracking (recorded facts, labelled by phase). Open, awaiting,
 * not-taken and cancelled Fridays are left out - they are not final numbers.
 * `present` is positive attendance (Present or a member-linked Visitor row).
 */
export function attendanceTrend({ points = 8 } = {}) {
  const contexts = buildFridayContexts({ countingOnly: true, limit: points + 24 })
    .filter((c) => ['finalized', 'pre_go_live', 'not_started'].includes(c.phase))
    .slice(0, points)
    .reverse();
  return contexts.map((ctx) => {
    const summary = sessionSummary(ctx.id);
    const positive = (summary.present || 0) + (summary.visitor || 0);
    return { date: ctx.date, sessionId: ctx.id, phase: ctx.phase, ...summary, present: positive, headcount: summary.physical.total };
  });
}

/**
 * Past tracked Fridays that are still awaiting finalization: the one thing
 * that is genuinely pending operationally. Pre-go-live, cancelled and
 * not-taken Fridays are never listed, and a Friday with an empty register is
 * not a problem in itself - it either gets finalized or marked not taken.
 */
export function awaitingFinalizationFridays({ contexts = null } = {}) {
  return (contexts || trackedFridayContexts())
    .filter((c) => c.phase === 'awaiting_finalization')
    .map((c) => ({
      ...c.session,
      recorded: c.rows.size,
      expectedCount: c.roster ? c.roster.size : 0,
      daysAgo: diffInDays(c.date, today())
    }));
}

/** Counts for the attendance landing page. */
export function attendanceOverview() {
  const latest = latestServiceOverview();
  const contexts = trackedFridayContexts(); // built once and shared by everything below
  const flagged = followUpList({ limit: 1_000_000, contexts });
  const upcoming = query(
    `SELECT * FROM attendance_sessions
      WHERE status = 'scheduled' AND service_date >= @today
      ORDER BY service_date ASC LIMIT 5`,
    { today: today() }
  );
  const awaiting = awaitingFinalizationFridays({ contexts });
  return { latest, flagged, upcoming, awaiting, followUp: followUpStatus({ contexts }) };
}

/**
 * Friday Services waiting to be finalized, for whoever records attendance.
 * (The name is kept for existing callers.) `state` says whether a register has
 * been started ('partial') or not ('none').
 */
export function pendingFridayServices({ weeks = 8 } = {}) {
  const since = addDays(today(), -7 * weeks);
  const pending = awaitingFinalizationFridays()
    .filter((s) => s.service_date >= since)
    .map((s) => ({ ...s, activeMembers: s.expectedCount, state: s.recorded === 0 ? 'none' : 'partial' }));
  return {
    sessions: pending,
    total: pending.length,
    latest: pending[0] || null,
    anyUnstarted: pending.some((s) => s.state === 'none')
  };
}

// ---------------------------------------------------------------------------
// Cell groups
// ---------------------------------------------------------------------------

/**
 * Attendance by cell group for one session. Groups are the members' CURRENT
 * groups (see the note at the top of this file). For a tracked Friday the
 * counts are of the EXPECTED roster only (snapshot once finalized) and follow
 * the canonical outcomes; before Go-Live only recorded facts are counted.
 */
export function cellGroupBreakdown(sessionId) {
  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  const classification = session ? classifySession(session) : null;

  if (!classification || !classification.isFriday) {
    return query(
      `SELECT COALESCE(g.name, 'No cell group') AS group_name,
              g.id AS group_id,
              COUNT(m.id) AS members,
              SUM(CASE WHEN r.status IN ('present','visitor') THEN 1 ELSE 0 END) AS present,
              SUM(CASE WHEN r.status = 'absent' THEN 1 ELSE 0 END) AS absent,
              SUM(CASE WHEN r.status = 'excused' THEN 1 ELSE 0 END) AS excused,
              SUM(CASE WHEN r.id IS NULL THEN 1 ELSE 0 END) AS not_recorded
         FROM members m
         LEFT JOIN cell_groups g ON g.id = m.cell_group_id
         LEFT JOIN attendance_records r ON r.member_id = m.id AND r.session_id = @sessionId
        WHERE m.status IN (${ROSTER_STATUS_SQL})
        GROUP BY g.id
        ORDER BY g.name IS NULL, g.name COLLATE NOCASE`,
      { sessionId }
    );
  }

  const phase = classification.phase;
  if (!classification.tracked || phase === 'cancelled' || phase === 'not_taken') {
    // Recorded facts only: no expected roster, so nothing can be "not recorded".
    return query(
      `SELECT COALESCE(g.name, 'No cell group') AS group_name, g.id AS group_id,
              COUNT(r.id) AS members,
              SUM(CASE WHEN r.status IN ('present','visitor') THEN 1 ELSE 0 END) AS present,
              SUM(CASE WHEN r.status = 'absent' THEN 1 ELSE 0 END) AS absent,
              SUM(CASE WHEN r.status = 'excused' THEN 1 ELSE 0 END) AS excused,
              0 AS not_recorded
         FROM attendance_records r
         JOIN members m ON m.id = r.member_id
         LEFT JOIN cell_groups g ON g.id = m.cell_group_id
        WHERE r.session_id = @sessionId
        GROUP BY g.id
        ORDER BY g.name IS NULL, g.name COLLATE NOCASE`,
      { sessionId }
    );
  }

  const [ctx] = buildFridayContexts({ from: session.service_date, to: session.service_date })
    .filter((c) => c.id === session.id);
  const groups = new Map();
  const bucket = (id, name) => {
    const key = id || 0;
    if (!groups.has(key)) groups.set(key, { group_name: name || 'No cell group', group_id: id || null, members: 0, present: 0, absent: 0, excused: 0, not_recorded: 0 });
    return groups.get(key);
  };
  const info = new Map(query(
    `SELECT m.id, m.cell_group_id, g.name AS group_name FROM members m LEFT JOIN cell_groups g ON g.id = m.cell_group_id`
  ).map((m) => [m.id, m]));
  for (const memberId of ctx.roster ? ctx.roster.keys() : []) {
    const r = memberOutcomeAt(ctx, memberId);
    const m = info.get(memberId);
    const b = bucket(m?.cell_group_id, m?.group_name);
    b.members += 1;
    if (r.state === 'present') b.present += 1;
    else if (r.state === 'vacation') b.excused += 1;
    else if (r.state === 'absent') b.absent += 1;
    else b.not_recorded += 1; // pending / awaiting: not decided yet
  }
  return [...groups.values()].sort((a, b) => (a.group_id === null) - (b.group_id === null)
    || String(a.group_name).localeCompare(String(b.group_name), undefined, { sensitivity: 'base' }));
}

/** Friday Service attendance for the members of one cell group. */
export function cellGroupAttendanceSummary(cellGroupId, { lastN = 8 } = {}) {
  const contexts = buildFridayContexts({ countingOnly: true, limit: lastN + 12 })
    .filter((c) => c.phase !== 'cancelled')
    .slice(0, lastN)
    .reverse();
  const sessions = contexts.map((c) => c.session);
  const members = query(
    `SELECT id, member_code, first_name, last_name, preferred_name
       FROM members
      WHERE cell_group_id = @id AND status IN (${ROSTER_STATUS_SQL})
      ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE`,
    { id: cellGroupId }
  );
  if (sessions.length === 0 || members.length === 0) {
    return { sessions, members: [], rows: [], averageRate: null };
  }

  const rows = members.map((member) => {
    const cells = contexts.map((ctx) => {
      const r = memberOutcomeAt(ctx, member.id);
      return { sessionId: ctx.id, date: ctx.date, status: r.token, state: r.state, derived: r.derived };
    });
    const present = cells.filter((c) => c.state === 'present').length;
    const excused = cells.filter((c) => c.state === 'vacation').length;
    const measured = memberRate(member.id, contexts);
    return {
      member, cells, present, excused,
      rateDenominator: measured.denominator,
      rateNumerator: measured.numerator,
      rate: measured.rate
    };
  });

  // Weighted across the group: SUM(attended) / SUM(expected - vacation), never a
  // mean of individual percentages. A member with nothing measurable adds nothing.
  const pooled = pooledRate(rows.map((r) => ({ numerator: r.rateNumerator, denominator: r.rateDenominator })));
  return { sessions, members, rows, averageRate: pooled.rate };
}

// ---------------------------------------------------------------------------
// Attendance report
// ---------------------------------------------------------------------------

export const ATTENDANCE_REPORT_SORT_COLUMNS = [
  'name', 'cell_group', 'eligible', 'present', 'excused', 'absent', 'not_recorded', 'rate', 'streak'
];

/**
 * The one place all three surfaces of the Friday Service attendance report
 * (on-screen, PDF, CSV) resolve which member statuses to report against, so
 * they can never disagree with each other. `statuses_submitted` disambiguates
 * "the form has never been touched" (first visit - defaults to the normal
 * expected Friday roster) from "the form was submitted with nothing ticked"
 * (an explicit choice, honoured as no status restriction).
 */
export function parseAttendanceStatusFilter(query = {}) {
  if (query.statuses_submitted !== '1') return [...DEFAULT_ROSTER_STATUSES];
  return normalizeMemberStatuses(query.status);
}

/**
 * Per-member Friday Service attendance across a range.
 *
 * Only SETTLED Fridays produce numbers a member is measured on: a finalized,
 * tracked Friday at which the member was in the historical expected snapshot
 * ("eligible"). On those, `absent` is recorded + derived absence, and
 * `rate` = attended / (eligible - vacation) - null when there is nothing to
 * measure. `not_recorded` is now "pending": expected at a Friday that is not
 * settled yet (open or awaiting finalization). Fridays before tracking are
 * recorded history (`historical`), never absences. Not-taken Fridays carry no
 * roster and no rate; cancelled ones are excluded as before.
 *
 * `bySession` is one consistently-filtered per-Friday breakdown; `overall` is
 * the weighted rate across the finalized ones (sum of attended over sum of
 * expected-minus-vacation, never an average of percentages).
 */
export function attendanceReport({
  from = null, to = null, cellGroupId = null, sort = null, direction = 'asc',
  statuses = null
} = {}) {
  const statusList = statuses === null ? DEFAULT_ROSTER_STATUSES : normalizeMemberStatuses(statuses);
  const statusSql = statusList.length
    ? `m.status IN (${statusList.map((s) => `'${s}'`).join(',')})`
    : '1=1';

  const all = buildFridayContexts({ from, to, countingOnly: true });
  const cancelledSessions = all.filter((c) => c.phase === 'cancelled').map((c) => c.session);
  // Oldest first, cancelled excluded (as before).
  const contexts = all.filter((c) => c.phase !== 'cancelled').reverse();
  const sessions = contexts.map((c) => ({ ...c.session, phase: c.phase }));

  const members = query(
    `SELECT m.id, m.member_code, m.first_name, m.last_name, m.preferred_name, m.date_joined,
            m.status AS member_status, m.date_of_birth, m.age_group, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE ${statusSql}
        AND (@cellGroupId IS NULL OR m.cell_group_id = @cellGroupId)
      ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE`,
    { cellGroupId }
  );

  const sequence = trackedFridayContexts();
  const isUntracked = (c) => c.phase === 'not_started' || c.phase === 'pre_go_live';

  const bySession = contexts.map((ctx) => {
    const part = {
      sessionId: ctx.id, date: ctx.date, phase: ctx.phase,
      present: 0, absent: 0, excused: 0, visitor: 0, notRecorded: 0, eligibleCount: 0,
      unexpected: 0, final: ctx.phase === 'finalized', notTaken: ctx.phase === 'not_taken',
      numerator: 0, denominator: 0, rate: null
    };
    for (const member of members) {
      if (isUntracked(ctx)) {
        if (member.date_joined && ctx.date < member.date_joined) continue;
        const status = ctx.rows.get(member.id);
        if (status === 'present') part.present += 1;
        else if (status === 'absent') part.absent += 1;
        else if (status === 'excused') part.excused += 1;
        else if (status === 'visitor') part.visitor += 1;
        continue;
      }
      const r = memberOutcomeAt(ctx, member.id);
      if (ctx.phase === 'not_taken') {
        if (r.positive) part.present += 1;
        continue;
      }
      if (r.expected) {
        part.eligibleCount += 1;
        if (r.state === 'present') { if (ctx.rows.get(member.id) === 'visitor') part.visitor += 1; else part.present += 1; }
        else if (r.state === 'vacation') part.excused += 1;
        else if (r.state === 'absent') part.absent += 1;
        else part.notRecorded += 1;
        if (part.final) { part.numerator += r.rateNumerator ? 1 : 0; part.denominator += r.rateDenominator ? 1 : 0; }
      } else if (r.positive) {
        part.unexpected += 1;
      }
    }
    if (part.final) part.rate = part.denominator > 0 ? Math.round((part.numerator / part.denominator) * 100) : null;
    return part;
  });

  const rows = members.map((member) => {
    const counts = { present: 0, absent: 0, excused: 0, visitor: 0, not_recorded: 0 };
    const historical = { sessions: 0, attended: 0, excused: 0, absent: 0 };
    let eligible = 0;
    let numerator = 0;
    let denominator = 0;
    for (const ctx of contexts) {
      if (isUntracked(ctx)) {
        if (member.date_joined && ctx.date < member.date_joined) continue;
        historical.sessions += 1;
        const status = ctx.rows.get(member.id);
        if (status === 'present' || status === 'visitor') historical.attended += 1;
        else if (status === 'excused') historical.excused += 1;
        else if (status === 'absent') historical.absent += 1;
        continue;
      }
      if (ctx.phase === 'not_taken') continue;
      const r = memberOutcomeAt(ctx, member.id);
      if (!r.expected) continue;
      if (ctx.phase === 'finalized') {
        eligible += 1;
        if (r.rateNumerator) numerator += 1;
        if (r.rateDenominator) denominator += 1;
        if (r.state === 'present') counts[ctx.rows.get(member.id) === 'visitor' ? 'visitor' : 'present'] += 1;
        else if (r.state === 'vacation') counts.excused += 1;
        else counts.absent += 1;
      } else if (!r.positive) {
        counts.not_recorded += 1; // pending: not settled yet
      }
    }
    return {
      member,
      eligible,
      ...counts,
      attended: counts.present + counts.visitor,
      rate: denominator > 0 ? Math.round((numerator / denominator) * 100) : null,
      rateNumerator: numerator,
      rateDenominator: denominator,
      historical,
      consecutive: consecutiveMissedFridays(member.id, { contexts: sequence })
    };
  });

  if (sort && ATTENDANCE_REPORT_SORT_COLUMNS.includes(sort)) {
    const dirMul = direction === 'desc' ? -1 : 1;
    const valueFor = {
      name: (r) => `${r.member.last_name} ${r.member.first_name}`.toLowerCase(),
      cell_group: (r) => (r.member.cell_group_name || '').toLowerCase(),
      eligible: (r) => r.eligible,
      present: (r) => r.present + r.visitor,
      excused: (r) => r.excused,
      absent: (r) => r.absent,
      not_recorded: (r) => r.not_recorded,
      rate: (r) => (r.rate === null ? -1 : r.rate),
      streak: (r) => r.consecutive.streak
    }[sort];
    rows.sort((a, b) => {
      const av = valueFor(a);
      const bv = valueFor(b);
      if (av < bv) return -1 * dirMul;
      if (av > bv) return 1 * dirMul;
      return 0;
    });
  }

  const finalParts = bySession.filter((p) => p.final);
  const overall = pooledRate(finalParts);
  const countPhase = (phase) => contexts.filter((c) => c.phase === phase).length;
  const lifecycle = {
    finalized: countPhase('finalized'),
    awaiting: countPhase('awaiting_finalization') + countPhase('open') + countPhase('scheduled'),
    notTaken: countPhase('not_taken'),
    beforeTracking: contexts.filter(isUntracked).length,
    cancelled: cancelledSessions.length,
    tracked: contexts.length - contexts.filter(isUntracked).length
  };

  return { sessions, rows, statuses: statusList, bySession, overall, lifecycle, cancelledSessions };
}

export function attendanceReportCsv(options = {}) {
  const { sessions, rows, overall, lifecycle } = attendanceReport(options);
  const cell = csvCell;
  // The same words as the PDF and the screen: Services counted (finalized Friday Services the member was expected at), Attendance %, Absences in a row (the current run).
  const header = ['Member ID', 'Member', 'Cell group', 'Services counted', 'Present', 'Visitor',
    'Vacation', 'Absent', 'Pending (not yet finalized)', 'Attendance %',
    'Absences in a row',
    'Before tracking: services', 'Before tracking: attended'];
  const lines = [header.map(cell).join(',')];

  for (const row of rows) {
    lines.push([
      row.member.member_code,
      displayName(row.member),
      row.member.cell_group_name || '',
      row.eligible, row.present, row.visitor, row.excused, row.absent, row.not_recorded,
      row.rate == null ? '' : row.rate,
      row.consecutive.streak,
      row.historical.sessions, row.historical.attended
    ].map(cell).join(','));
  }

  return {
    csv: `${lines.join('\r\n')}\r\n`,
    sessions: sessions.length,
    members: rows.length,
    overallRate: overall.rate,
    lifecycle
  };
}
