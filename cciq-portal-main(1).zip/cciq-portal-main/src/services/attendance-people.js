import { query } from '../db/index.js';
import { classifySession } from './attendance-tracking.js';
import { computeSessionSummary, expectedRosterForSession } from './attendance-outcomes.js';
import { serviceHeadcount } from './service-headcount.js';
import { congregationFor, AGE_GROUP_LABELS } from './congregations.js';
import { paginateList } from '../lib/paging.js';
import { today } from '../lib/dates.js';

/*
 * WHO is behind an attendance number. The attendance drill-down lists the people for a figure on the Attendance landing chart or a Friday Service tile.
 *
 * It never counts anything of its own. Every list is taken from the structure the number itself came from:
 *   members / first_timers / returning / total   the physical headcount (service-headcount.js): the same people, counted once each;
 *   present_expected / vacation / absent   the expected-member outcomes (computeSessionSummary in attendance-outcomes.js), collected in the same pass that produced the counts.
 * So a list's length IS the number that was clicked, by construction; attendance-drill-down.mjs proves it for every metric.
 *
 * Which figures can be listed depends on the service's lifecycle, exactly as the screens show them: a service before tracking (or with no tracking start) has a headcount and
 * nothing else; Vacation can be listed on a tracked, taken service; Absent only once the Friday is finalized. Nothing is derived that the screens do not show.
 */

export const DRILL_METRICS = {
  members: { label: 'Members present', explain: 'Members with a Present mark at this service, whether or not they were on the expected list.' },
  first_timers: { label: 'First Timers', explain: 'People on their FIRST visit to this service. A First Timer who has since become a member is still counted here, once.' },
  returning: { label: 'Returning', explain: 'People who had visited before and are still to have their membership review: not First Timers any more, not yet members.' },
  total: { label: 'Total present', explain: 'Everyone who was there: members, First Timers and returning visitors, each person counted once.' },
  present_expected: { label: 'Expected members present', explain: 'Members who were expected at this service and were present.' },
  vacation: { label: 'Vacation', explain: 'Expected members recorded on Vacation for this service.' },
  absent: { label: 'Absent', explain: 'Expected members who were absent: marked absent, or with no record on a finalized service.' }
};
export const DRILL_METRIC_KEYS = Object.keys(DRILL_METRICS);
export const DRILL_SORTS = ['name', 'type', 'member_id', 'cell_group', 'congregation', 'classification'];

/** The figures that can be listed for a service, in lifecycle terms. */
export function drillDownMetrics(session) {
  const classification = classifySession(session);
  const keys = ['members', 'first_timers', 'returning', 'total'];
  if (classification.tracked && !['cancelled', 'not_taken'].includes(classification.phase)) {
    keys.push('present_expected', 'vacation');
    if (classification.phase === 'finalized') keys.push('absent');
  }
  return keys;
}

const collator = new Intl.Collator('en', { sensitivity: 'base', numeric: true });
const text = (v) => String(v ?? '').normalize('NFC').trim();

/**
 * The canonical order of a list of people: last name, then first name, then middle name (the structured name fields, never "the last word of a display name"),
 * the same keys the Members list and the First Timers list sort by. A person with no last name sorts first, as in those lists (an empty surname sorts before any other).
 */
export function compareByName(a, b) {
  return collator.compare(text(a.lastName), text(b.lastName))
    || collator.compare(text(a.firstName), text(b.firstName))
    || collator.compare(text(a.middleName), text(b.middleName))
    || (a.kind === b.kind ? a.id - b.id : (a.kind === 'member' ? -1 : 1));
}

function chunk(list, size = 400) {
  const out = [];
  for (let i = 0; i < list.length; i += size) out.push(list.slice(i, i + size));
  return out;
}

function memberRows(ids, classify) {
  const rows = [];
  for (const part of chunk([...new Set(ids)])) {
    const placeholders = part.map((_, i) => `@m${i}`).join(',');
    const params = Object.fromEntries(part.map((id, i) => [`m${i}`, id]));
    rows.push(...query(
      `SELECT m.id, m.member_code, m.first_name, m.middle_name, m.last_name, m.preferred_name, m.age_group, m.date_of_birth, g.name AS cell_group_name
         FROM members m LEFT JOIN cell_groups g ON g.id = m.cell_group_id
        WHERE m.id IN (${placeholders})`, params));
  }
  return rows.map((m) => {
    const congregation = congregationFor(m);
    return {
      kind: 'member', id: m.id, type: 'Member', memberCode: m.member_code || '',
      firstName: m.first_name, middleName: m.middle_name, lastName: m.last_name,
      name: [m.preferred_name || m.first_name, m.last_name].filter(Boolean).join(' '),
      cellGroup: m.cell_group_name || '', congregation: congregation ? AGE_GROUP_LABELS[congregation] : '',
      classification: classify(m.id)
    };
  });
}

function firstTimerRows(ids, { returning = false } = {}) {
  const rows = [];
  for (const part of chunk([...new Set(ids)])) {
    const placeholders = part.map((_, i) => `@v${i}`).join(',');
    const params = Object.fromEntries(part.map((id, i) => [`v${i}`, id]));
    rows.push(...query(
      `SELECT v.id, v.first_name, v.last_name, v.age_group, v.congregation, v.member_id, m.member_code
         FROM visitors v LEFT JOIN members m ON m.id = v.member_id
        WHERE v.id IN (${placeholders})`, params));
  }
  return rows.map((v) => ({
    kind: 'first_timer', id: v.id, type: returning ? 'Returning' : 'First Timer', memberCode: v.member_code || '',
    firstName: v.first_name, middleName: '', lastName: v.last_name || '',
    name: [v.first_name, v.last_name].filter(Boolean).join(' '),
    cellGroup: '', congregation: v.congregation ? (AGE_GROUP_LABELS[v.congregation] || v.congregation) : (v.age_group ? (AGE_GROUP_LABELS[v.age_group] || '') : ''),
    classification: returning
      ? (v.member_id ? 'Returning (since a member)' : 'Returning \u00B7 review pending')
      : (v.member_id ? 'First Timer (since a member)' : 'First Timer')
  }));
}

/**
 * The people behind one figure of one service, filtered, ordered and paged.
 *   options: { search, sort, direction, page, pageSize, paging } - or { all: true } for every matching person in the canonical print order (name), whatever the screen sort.
 * Returns { metric, label, summary (every figure of this service), available (the figures that can be listed), count (people matching), total (people for the figure, before the search),
 *           rows (this page), printRows (all matching, canonical order), window }.
 */
export function attendanceDrillDown(session, metric, { search = '', sort = 'name', direction = 'asc', page = 1, pageSize = 25 } = {}) {
  const available = drillDownMetrics(session);
  if (!DRILL_METRICS[metric] || !available.includes(metric)) return null;

  const classification = classifySession(session);
  const physical = serviceHeadcount(session.id);
  const roster = classification.tracked && !['cancelled', 'not_taken'].includes(classification.phase) ? expectedRosterForSession(session) : null;
  const tracked = roster ? computeSessionSummary(session, roster, classification.phase) : null;
  const expectedSet = roster ? roster.expected : null;

  const summary = { members: physical.members, firstTimers: physical.firstTimers, returning: physical.returning, total: physical.total };
  if (tracked) {
    summary.presentExpected = tracked.presentExpected;
    summary.vacation = tracked.vacation;
    if (classification.phase === 'finalized') summary.absent = tracked.absentTotal;
  }

  const physicalMember = (id) => (expectedSet ? (expectedSet.has(id) ? 'Expected member, present' : 'Present, not on the expected list') : 'Present');
  let people = [];
  if (metric === 'members') people = memberRows(physical.memberIds, physicalMember);
  else if (metric === 'first_timers') people = firstTimerRows(physical.firstTimerIds);
  else if (metric === 'returning') people = firstTimerRows(physical.returningIds, { returning: true });
  else if (metric === 'total') people = [...memberRows(physical.memberIds, physicalMember), ...firstTimerRows(physical.firstTimerIds), ...firstTimerRows(physical.returningIds, { returning: true })];
  else if (metric === 'present_expected') people = memberRows(tracked.presentExpectedIds, () => 'Expected member, present');
  else if (metric === 'vacation') people = memberRows(tracked.vacationIds, () => 'Vacation');
  else if (metric === 'absent') {
    const recorded = new Set(tracked.absentRecordedIds);
    people = memberRows([...tracked.absentRecordedIds, ...tracked.derivedAbsentIds], (id) => (recorded.has(id) ? 'Absent (marked absent)' : 'Absent (no record)'));
  }
  const totalForFigure = people.length;

  const needle = text(search).toLowerCase();
  const matching = needle
    ? people.filter((p) => `${p.name} ${p.firstName} ${p.middleName || ''} ${p.lastName} ${p.memberCode}`.toLowerCase().includes(needle))
    : people;

  const printRows = [...matching].sort(compareByName);
  const sortKey = DRILL_SORTS.includes(sort) ? sort : 'name';
  const sign = direction === 'desc' ? -1 : 1;
  const value = (p) => ({ type: p.type, member_id: p.memberCode, cell_group: p.cellGroup, congregation: p.congregation, classification: p.classification })[sortKey];
  const sorted = sortKey === 'name'
    ? printRows.slice().sort((a, b) => sign * compareByName(a, b))
    : matching.slice().sort((a, b) => sign * collator.compare(text(value(a)), text(value(b))) || compareByName(a, b));
  const window = paginateList(sorted, { page, pageSize });

  return {
    metric, label: DRILL_METRICS[metric].label, explain: DRILL_METRICS[metric].explain,
    summary, available, total: totalForFigure, count: matching.length, rows: window.rows, window, printRows,
    generatedOn: today(),
    phase: classification.phase, tracked: Boolean(classification.tracked)
  };
}
