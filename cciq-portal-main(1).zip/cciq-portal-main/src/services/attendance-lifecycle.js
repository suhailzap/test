import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { today, nowIso, isValidDate, isFriday } from '../lib/dates.js';
import { setSetting } from '../lib/settings.js';
import { recordAudit } from '../lib/audit.js';
import {
  TRACKING_START_SETTING,
  classifySession,
  finalizationStateOf,
  hasExpectedSnapshot,
  getExpectedSnapshot,
  insertExpectedRows,
  trackingStartDate
} from './attendance-tracking.js';
import { getSession, recordAttendance, setSessionStatus, SESSION_STATUSES } from './attendance.js';
import { fullName } from './members.js';
import { outcomeOf, expectedRosterForSession, computeSessionSummary } from './attendance-outcomes.js';

/*
 * Attendance Go-Live & Finalization: the lifecycle of a tracked Friday and
 * the controlled actions that move it - finalize, mark "attendance not
 * taken", reopen, correct - plus the Go-Live date lock and the hardened
 * session status change.
 *
 * Every action here:
 *   - runs in ONE write transaction taken up front (BEGIN IMMEDIATE), so two
 *     callers - two requests, or two processes on the same database file -
 *     are strictly serialized, and moves state with a compare-and-swap
 *     UPDATE ... WHERE finalization_state IS <expected>. Exactly one caller can
 *     win a transition; the other gets a clear refusal, never a second
 *     snapshot, a second transition or a second audit row;
 *   - writes its audit row inside that same transaction;
 *   - checks authorization at the route (the project's existing pattern:
 *     attendance.finalize). The ordinary write paths refuse a finalized or
 *     not-taken Friday regardless of who is asking (assertSessionMutable), so
 *     these functions are the only way to change one.
 *
 * Single-instance assumption: exclusion against ordinary attendance writes (QR
 * check-in, the register, kiosk) relies on CCIQ running as ONE application
 * instance with synchronous better-sqlite3 access - those writers check the
 * session state and then write without sharing this transaction. Two finalizers
 * are serialized by BEGIN IMMEDIATE even across processes, but a check-in racing
 * a finalization from ANOTHER process would need a database-level review first
 * (see the note in qr-checkin.js confirmCheckin()).
 *
 * Derived absence: finalizing never inserts Absent rows. An expected member
 * with no attendance row is Absent BY DEFINITION on a finalized Friday, and
 * the outcome resolver below is the one place that says so.
 */

// ---------------------------------------------------------------------------
// Labels
// ---------------------------------------------------------------------------

export const LIFECYCLE_LABELS = {
  not_applicable: null,
  not_started: 'Attendance tracking has not started',
  pre_go_live: 'Not tracked - before the attendance tracking start date',
  scheduled: 'Scheduled',
  open: 'Open - attendance is being recorded',
  awaiting_finalization: 'Awaiting finalization',
  finalized: 'Finalized',
  not_taken: 'Attendance not taken',
  cancelled: 'Cancelled'
};

/** Operator-facing wording for every refusal the lifecycle can give. */
export const LIFECYCLE_MESSAGES = {
  session_not_found: 'That service could not be found.',
  not_friday_service: 'Only a Friday Service can be finalized.',
  tracking_not_started: 'Attendance tracking has not started. Set the attendance tracking start date first.',
  not_tracked: 'This Friday is before the attendance tracking start date, so it is not tracked.',
  session_cancelled: 'This service was cancelled. Reinstate it first.',
  session_in_future: 'This service has not happened yet.',
  already_finalized: 'Attendance for this service is already finalized.',
  already_not_taken: 'This service is already marked as attendance not taken.',
  not_finalized: 'This service has not been finalized.',
  session_finalized: 'Attendance for this service has been finalized. A Church Admin can correct it or reopen it.',
  session_not_taken: 'Attendance was marked not taken for this service. A Church Admin can reopen it.',
  ambiguous_history: 'Finalization is blocked: for some members the portal cannot tell what their status was on that Friday '
    + '(for example people added to the portal after it). Open the Finalize page to see who, and what to do next.',
  no_attendance_recorded: 'No attendance has been recorded for this service. If attendance was not taken, mark it '
    + '"Attendance not taken" instead - otherwise everyone expected would become absent.',
  note_required: 'Explain why attendance was not taken.',
  reason_required: 'A reason is required.',
  existing_attendance_needs_confirmation: 'Attendance has already been recorded for this service. Confirm to keep it and mark the service not taken.',
  status_locked_by_finalization: 'A finalized or not-taken service cannot be moved back to Scheduled. Reopen it instead.',
  date_locked_by_finalization: 'The date of a finalized service cannot be changed.',
  invalid_change: 'One of the corrections is not allowed.',
  duplicate_member: 'A member appears more than once in the corrections.',
  no_changes: 'No corrections were entered.'
};

// ---------------------------------------------------------------------------
// Post-change hook (a clean service point for Phase 2C)
// ---------------------------------------------------------------------------
//
// Follow-up and reports are derived from attendance, and stored follow-up
// reminders must be reconciled when it changes. This is where that plugs in
// later: register a listener and it is called AFTER the change has committed,
// with { type, sessionId, memberIds, userId }. A failing listener is logged
// and can never undo or fail the attendance change itself.

const changeListeners = new Set();

export function onAttendanceLifecycleChange(listener) {
  changeListeners.add(listener);
  return () => changeListeners.delete(listener);
}

function emitChange(event) {
  for (const listener of changeListeners) {
    try {
      listener(event);
    } catch (err) {
      console.error(`[attendance] a lifecycle change listener failed (${event.type}):`, err.message);
    }
  }
}

// outcomeOf, expectedRosterForSession and computeSessionSummary live in attendance-outcomes.js
// (the one place that interprets attendance for every consumer) and are re-exported here.
export { outcomeOf, expectedRosterForSession, computeSessionSummary };

// ---------------------------------------------------------------------------
// Preconditions shared by finalize / not taken
// ---------------------------------------------------------------------------

/** Every reason this session cannot be finalized or marked not-taken right now, in priority order. */
function transitionBlockers(session, classification, { asOf = today() } = {}) {
  const blockers = [];
  if (!classification.isFriday) return ['not_friday_service'];
  if (!classification.trackingConfigured) blockers.push('tracking_not_started');
  else if (!classification.tracked) blockers.push('not_tracked');
  if (classification.cancelled) blockers.push('session_cancelled');
  if (session.service_date > asOf) blockers.push('session_in_future');
  if (classification.finalizationState === 'finalized') blockers.push('already_finalized');
  if (classification.finalizationState === 'not_taken') blockers.push('already_not_taken');
  return blockers;
}

function nameOf(memberId) {
  const m = queryOne('SELECT first_name, middle_name, last_name FROM members WHERE id = @id', { id: memberId });
  return m ? fullName(m) : `Member ${memberId}`;
}

// What an administrator reads for each member the roster cannot place (the internal code stays on `reason` for tests and logs; it is never shown on a page).
const AMBIGUOUS_REASON_TEXT = {
  created_after_service: 'Created after this service \u2014 historical attendance status cannot be determined.',
  history_inconsistent: 'Their status history does not add up \u2014 their status on this date cannot be determined.'
};
function describeAmbiguous(ambiguous) {
  return ambiguous.map((a) => ({
    ...a, name: nameOf(a.memberId),
    reasonText: AMBIGUOUS_REASON_TEXT[a.reason] || 'Their status on this date cannot be determined from the record.'
  }));
}

// ---------------------------------------------------------------------------
// Preview
// ---------------------------------------------------------------------------

/**
 * What finalizing would do - read-only. Writes no snapshot and touches no
 * attendance. For a Friday whose expected roster is already stored (finalized,
 * or reopened after finalizing) it shows THAT snapshot, never a fresh
 * computation from today's statuses.
 */
export function previewFinalization(sessionId) {
  const session = getSession(sessionId);
  if (!session) return { ok: false, reason: 'session_not_found' };
  const classification = classifySession(session);
  const roster = expectedRosterForSession(session);
  const blockers = transitionBlockers(session, classification);
  if (roster.ambiguous.length > 0) blockers.push('ambiguous_history');
  const summary = computeSessionSummary(session, roster, 'open');
  const noAttendance = summary.presentExpected + summary.unexpectedAttendees + summary.firstTimeVisitors === 0;

  return {
    ok: true,
    session,
    classification,
    phase: classification.phase,
    label: LIFECYCLE_LABELS[classification.phase],
    rosterSource: roster.source,
    usingPreservedSnapshot: roster.source === 'snapshot',
    summary,
    ambiguous: describeAmbiguous(roster.ambiguous),
    blockers,
    canFinalize: blockers.length === 0,
    // Not a hard block: finalizing with nothing recorded needs an explicit confirmation.
    requiresEmptyConfirmation: blockers.length === 0 && noAttendance,
    existingAttendanceRecords: summary.attendanceRecords
  };
}

// ---------------------------------------------------------------------------
// Finalize
// ---------------------------------------------------------------------------

/**
 * Finalizes attendance for a tracked Friday: snapshots (or reuses) the
 * expected roster, moves NULL -> 'finalized', stamps who and when, audits.
 * All or nothing. There is deliberately NO way to proceed past ambiguous
 * history: any member whose status that Friday cannot be established fails
 * finalization closed and lists them, so the underlying record can be fixed.
 */
export function finalizeAttendance(sessionId, { userId = null, req = null, confirmNoAttendance = false } = {}) {
  const result = transaction(() => {
    const session = getSession(sessionId);
    if (!session) return { ok: false, reason: 'session_not_found' };
    const classification = classifySession(session);
    const blockers = transitionBlockers(session, classification);
    if (blockers.length) return { ok: false, reason: blockers[0] };

    const roster = expectedRosterForSession(session);
    if (roster.ambiguous.length > 0) {
      return { ok: false, reason: 'ambiguous_history', ambiguous: describeAmbiguous(roster.ambiguous) };
    }
    const before = computeSessionSummary(session, roster, 'open');
    if (before.presentExpected + before.unexpectedAttendees + before.firstTimeVisitors === 0 && !confirmNoAttendance) {
      return { ok: false, reason: 'no_attendance_recorded' };
    }

    const at = nowIso();
    const moved = execute(
      `UPDATE attendance_sessions
          SET finalization_state = 'finalized', finalized_at = @at, finalized_by = @by, finalization_note = NULL,
              status = CASE WHEN status = 'scheduled' THEN 'held' ELSE status END
        WHERE id = @id AND finalization_state IS NULL AND status != 'cancelled'`,
      { id: session.id, at, by: userId }
    );
    if (moved.changes !== 1) {
      // Someone else moved it between our read and this write.
      const current = getSession(session.id);
      const again = current ? transitionBlockers(current, classifySession(current)) : ['session_not_found'];
      return { ok: false, reason: again[0] || 'already_finalized' };
    }

    let snapshotCreated = false;
    if (roster.source === 'live') {
      insertExpectedRows(session.id, roster.expectedRows);
      snapshotCreated = true;
    }

    const summary = computeSessionSummary(session, expectedRosterForSession(session), 'finalized');
    recordAudit({
      req, userId, action: 'attendance.finalized', entityType: 'attendance_session', entityId: session.id,
      detail: {
        service_date: session.service_date,
        expected: summary.expected,
        present: summary.presentExpected,
        vacation: summary.vacation,
        recorded_absent: summary.absentRecorded,
        derived_absent: summary.derivedAbsent,
        unexpected_attendees: summary.unexpectedAttendees,
        first_time_visitors: summary.firstTimeVisitors,
        snapshot: snapshotCreated ? 'created' : 'reused',
        confirmed_no_attendance: Boolean(confirmNoAttendance) && before.presentExpected + before.unexpectedAttendees + before.firstTimeVisitors === 0
      }
    });
    return { ok: true, sessionId: session.id, snapshotCreated, snapshotReused: !snapshotCreated, summary, finalizedAt: at };
  }).immediate();

  if (result.ok) emitChange({ type: 'finalized', sessionId: result.sessionId, userId });
  return result;
}

// ---------------------------------------------------------------------------
// Attendance not taken
// ---------------------------------------------------------------------------

/**
 * Marks a tracked Friday "attendance not taken": the service generates no
 * derived absence, no rate and no follow-up penalty. No expected snapshot is
 * created. Real attendance rows already recorded are kept untouched. A note
 * explaining why is required; if rows already exist the caller must confirm.
 */
export function markAttendanceNotTaken(sessionId, { userId = null, req = null, note = '', confirmExistingAttendance = false } = {}) {
  const cleanNote = String(note || '').trim();
  if (!cleanNote) return { ok: false, reason: 'note_required' };
  const storedNote = cleanNote.slice(0, 500);

  const result = transaction(() => {
    const session = getSession(sessionId);
    if (!session) return { ok: false, reason: 'session_not_found' };
    const classification = classifySession(session);
    const blockers = transitionBlockers(session, classification);
    if (blockers.length) return { ok: false, reason: blockers[0] };

    const existing = queryOne('SELECT COUNT(*) AS n FROM attendance_records WHERE session_id = @id', { id: session.id }).n;
    if (existing > 0 && !confirmExistingAttendance) {
      return { ok: false, reason: 'existing_attendance_needs_confirmation', existingRecords: existing };
    }

    const at = nowIso();
    const moved = execute(
      `UPDATE attendance_sessions
          SET finalization_state = 'not_taken', finalized_at = @at, finalized_by = @by, finalization_note = @note
        WHERE id = @id AND finalization_state IS NULL AND status != 'cancelled'`,
      { id: session.id, at, by: userId, note: storedNote }
    );
    if (moved.changes !== 1) {
      const current = getSession(session.id);
      const again = current ? transitionBlockers(current, classifySession(current)) : ['session_not_found'];
      return { ok: false, reason: again[0] || 'already_not_taken' };
    }
    recordAudit({
      req, userId, action: 'attendance.not_taken', entityType: 'attendance_session', entityId: session.id,
      detail: { service_date: session.service_date, note: storedNote, existing_attendance_records_kept: existing }
    });
    return { ok: true, sessionId: session.id, existingRecordsKept: existing };
  }).immediate();

  if (result.ok) emitChange({ type: 'not_taken', sessionId: result.sessionId, userId });
  return result;
}

// ---------------------------------------------------------------------------
// Reopen
// ---------------------------------------------------------------------------

/**
 * Returns a finalized or not-taken Friday to open. The expected-roster
 * snapshot and every attendance record are PRESERVED, so re-finalizing reuses
 * the historical snapshot instead of rebuilding history from today's statuses.
 *
 * finalized_at / finalized_by / finalization_note describe the CURRENT
 * finalization, so they are cleared with it; the previous values (and the
 * reason) are kept, permanently, in the audit record.
 */
export function reopenAttendance(sessionId, { userId = null, req = null, reason = '' } = {}) {
  const cleanReason = String(reason || '').trim();
  if (!cleanReason) return { ok: false, reason: 'reason_required' };

  const result = transaction(() => {
    const session = getSession(sessionId);
    if (!session) return { ok: false, reason: 'session_not_found' };
    if (session.status === 'cancelled') return { ok: false, reason: 'session_cancelled' };
    const previousState = finalizationStateOf(session);
    if (!previousState) return { ok: false, reason: 'not_finalized' };

    const moved = execute(
      `UPDATE attendance_sessions
          SET finalization_state = NULL, finalized_at = NULL, finalized_by = NULL, finalization_note = NULL
        WHERE id = @id AND finalization_state IS NOT NULL AND status != 'cancelled'`,
      { id: session.id }
    );
    if (moved.changes !== 1) return { ok: false, reason: 'not_finalized' };
    recordAudit({
      req, userId, action: 'attendance.reopened', entityType: 'attendance_session', entityId: session.id,
      detail: {
        service_date: session.service_date,
        previous_state: previousState,
        previous_finalized_at: session.finalized_at,
        previous_finalized_by: session.finalized_by,
        previous_note: session.finalization_note,
        reason: cleanReason,
        snapshot_preserved: hasExpectedSnapshot(session.id),
        attendance_records_preserved: queryOne('SELECT COUNT(*) AS n FROM attendance_records WHERE session_id = @id', { id: session.id }).n
      }
    });
    return { ok: true, sessionId: session.id, previousState };
  }).immediate();

  if (result.ok) emitChange({ type: 'reopened', sessionId: result.sessionId, userId });
  return result;
}

// ---------------------------------------------------------------------------
// Corrections to finalized attendance
// ---------------------------------------------------------------------------

/** What a correction may set. 'remove' deletes the row: an expected member then reverts to derived Absent. */
export const CORRECTION_TARGETS = ['present', 'excused', 'absent', 'remove'];

function outcomeToken(outcome) {
  return outcome === null ? 'none' : outcome;
}

/**
 * Corrects finalized attendance without reopening it and without ever
 * changing the expected-roster snapshot. `changes` is [{ memberId, to }],
 * `to` one of CORRECTION_TARGETS. A reason is required. All or nothing: any
 * disallowed change refuses the whole request. Someone who was not expected
 * can be corrected only to Present or removed (Vacation/Absent mean nothing
 * outside the expected roster). Writes go through recordAttendance() with
 * `correction: true`, so the existing attendance write rules (including the
 * Temporarily Away return on a confirmed Present) apply unchanged.
 *
 * Audit: one 'attendance.corrected' row per member changed, each with the
 * before and after outcome, the reason, the session and the actor.
 */
export function correctFinalizedAttendance(sessionId, changes, { userId = null, req = null, reason = '' } = {}) {
  const cleanReason = String(reason || '').trim();
  if (!cleanReason) return { ok: false, reason: 'reason_required' };
  if (!Array.isArray(changes) || changes.length === 0) return { ok: false, reason: 'no_changes' };

  const result = transaction(() => {
    const session = getSession(sessionId);
    if (!session) return { ok: false, reason: 'session_not_found' };
    if (session.status === 'cancelled') return { ok: false, reason: 'session_cancelled' };
    const state = finalizationStateOf(session);
    if (state === 'not_taken') return { ok: false, reason: 'session_not_taken' };
    if (state !== 'finalized') return { ok: false, reason: 'not_finalized' };

    const expected = new Map(getExpectedSnapshot(session.id).map((r) => [r.member_id, r.status_at_service]));
    const seen = new Set();
    const rowByMember = new Map(
      query('SELECT member_id, status FROM attendance_records WHERE session_id = @id', { id: session.id }).map((r) => [r.member_id, r.status])
    );

    const effective = [];
    const unchanged = [];
    for (const change of changes) {
      const memberId = Number(change?.memberId);
      const to = String(change?.to || '');
      if (!memberId || !CORRECTION_TARGETS.includes(to)) return { ok: false, reason: 'invalid_change', memberId: memberId || null };
      if (seen.has(memberId)) return { ok: false, reason: 'duplicate_member', memberId };
      seen.add(memberId);
      if (!queryOne('SELECT 1 AS x FROM members WHERE id = @id', { id: memberId })) return { ok: false, reason: 'invalid_change', memberId };
      const isExpected = expected.has(memberId);
      if (!isExpected && to !== 'present' && to !== 'remove') return { ok: false, reason: 'invalid_change', memberId };

      const currentRow = rowByMember.get(memberId) ?? null;
      const fromOutcome = outcomeOf({ phase: 'finalized', expected: isExpected, rowStatus: currentRow });
      const targetRow = to === 'remove' ? null : to;
      if (targetRow === currentRow) { unchanged.push(memberId); continue; }
      const toOutcome = outcomeOf({ phase: 'finalized', expected: isExpected, rowStatus: targetRow });
      effective.push({ memberId, to, isExpected, currentRow, targetRow, fromOutcome, toOutcome });
    }
    if (effective.length === 0) return { ok: true, sessionId: session.id, changed: 0, unchanged, memberIds: [] };

    const written = recordAttendance(
      session.id,
      effective.map((e) => ({ memberId: e.memberId, status: e.targetRow })),
      { userId, correction: true }
    );
    if (!written.ok) return { ok: false, reason: written.reason };

    const batch = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    for (const e of effective) {
      recordAudit({
        req, userId, action: 'attendance.corrected', entityType: 'attendance_session', entityId: session.id,
        detail: {
          service_date: session.service_date,
          member_id: e.memberId,
          member: nameOf(e.memberId),
          expected: e.isExpected,
          from: outcomeToken(e.fromOutcome),
          to: outcomeToken(e.toOutcome),
          from_record: e.currentRow,
          to_record: e.targetRow,
          reason: cleanReason,
          batch
        }
      });
    }
    return { ok: true, sessionId: session.id, changed: effective.length, unchanged, memberIds: effective.map((e) => e.memberId) };
  }).immediate();

  if (result.ok && result.changed > 0) {
    emitChange({ type: 'corrected', sessionId: result.sessionId, memberIds: result.memberIds, userId });
  }
  return result;
}

/**
 * Members an administrator may want to correct on a finalized Friday. With no
 * search term: the expected members currently Absent or on Vacation (the
 * usual corrections). With a term: any member matching it, expected or not,
 * so someone who attended without being expected can be recorded too.
 */
export function correctionCandidates(sessionId, { q = '', limit = 200 } = {}) {
  const term = String(q || '').trim().slice(0, 60);
  const like = likePattern(term);
  const rows = term
    ? query(
      `SELECT m.id, m.first_name, m.middle_name, m.last_name, m.member_code,
              (e.member_id IS NOT NULL) AS expected, r.status AS row_status
         FROM members m
         LEFT JOIN attendance_expected e ON e.session_id = @id AND e.member_id = m.id
         LEFT JOIN attendance_records r ON r.session_id = @id AND r.member_id = m.id
        WHERE m.first_name LIKE @like ESCAPE '\\' OR m.middle_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
           OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\'
        ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE
        LIMIT @limit`,
      { id: sessionId, like, limit }
    )
    : query(
      `SELECT m.id, m.first_name, m.middle_name, m.last_name, m.member_code, 1 AS expected, r.status AS row_status
         FROM attendance_expected e
         JOIN members m ON m.id = e.member_id
         LEFT JOIN attendance_records r ON r.session_id = e.session_id AND r.member_id = e.member_id
        WHERE e.session_id = @id AND (r.status IS NULL OR r.status IN ('absent', 'excused'))
        ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE
        LIMIT @limit`,
      { id: sessionId, limit }
    );
  return rows.map((r) => ({
    id: r.id,
    name: fullName(r),
    memberCode: r.member_code,
    expected: Boolean(r.expected),
    rowStatus: r.row_status,
    outcome: outcomeOf({ phase: 'finalized', expected: Boolean(r.expected), rowStatus: r.row_status })
  }));
}

// ---------------------------------------------------------------------------
// Session status (cancel / reinstate) - hardened
// ---------------------------------------------------------------------------

/**
 * Changes a service's scheduled/held/cancelled status. Status and
 * finalization stay separate: cancelling keeps the finalization state,
 * snapshot and attendance exactly as they are, and reinstating restores them
 * as they were. For a finalized or not-taken service:
 *   - it can never be moved back to 'scheduled' (that would sidestep the
 *     lifecycle - reopening is the way back);
 *   - cancelling it needs a reason.
 * Other services behave as before.
 */
export function changeSessionStatus(sessionId, status, { userId = null, req = null, notes = null } = {}) {
  if (!SESSION_STATUSES.includes(status)) return { ok: false, reason: 'invalid_status' };
  const cleanNotes = notes ? String(notes).trim() : '';

  const result = transaction(() => {
    const session = getSession(sessionId);
    if (!session) return { ok: false, reason: 'session_not_found' };
    const state = finalizationStateOf(session);

    if (state) {
      if (status === 'scheduled') return { ok: false, reason: 'status_locked_by_finalization' };
      if (status === 'cancelled' && session.status !== 'cancelled' && !cleanNotes) return { ok: false, reason: 'reason_required' };
    }

    setSessionStatus(session.id, status, { userId, notes: cleanNotes || null });
    recordAudit({
      req, userId, action: 'attendance.session_status_changed', entityType: 'attendance_session', entityId: session.id,
      detail: { from: session.status, to: status, reason: cleanNotes || null }
    });

    const cancelling = status === 'cancelled' && session.status !== 'cancelled';
    const reinstating = session.status === 'cancelled' && status !== 'cancelled';
    if (state && (cancelling || reinstating)) {
      recordAudit({
        req, userId,
        action: cancelling ? 'attendance.session_cancelled_after_finalization' : 'attendance.session_reinstated_after_finalization',
        entityType: 'attendance_session', entityId: session.id,
        detail: {
          service_date: session.service_date,
          finalization_state: state,
          snapshot_preserved: hasExpectedSnapshot(session.id),
          attendance_records_preserved: queryOne('SELECT COUNT(*) AS n FROM attendance_records WHERE session_id = @id', { id: session.id }).n,
          reason: cleanNotes || null
        }
      });
    }
    return { ok: true, sessionId: session.id, previous: session.status, status, cancelling, reinstating, finalizationState: state };
  }).immediate();

  if (result.ok && (result.cancelling || result.reinstating)) {
    emitChange({ type: result.cancelling ? 'cancelled' : 'reinstated', sessionId: result.sessionId, userId });
  }
  return result;
}

/** A finalized, not-taken or previously-finalized (snapshotted) service must not change date. */
export function isServiceDateLocked(session) {
  return Boolean(finalizationStateOf(session)) || hasExpectedSnapshot(session.id);
}

/** What the check-in screens should say if this session can no longer take check-ins, else null. */
export function checkinClosure(session) {
  const state = session ? finalizationStateOf(session) : null;
  if (state === 'finalized') return { closed: true, reason: 'session_finalized', message: 'Check-in is closed: attendance for this service has been finalized.' };
  if (state === 'not_taken') return { closed: true, reason: 'session_not_taken', message: 'Check-in is closed: attendance was marked not taken for this service.' };
  return null;
}

// ---------------------------------------------------------------------------
// Go-Live date lock
// ---------------------------------------------------------------------------

/**
 * The Go-Live date is locked once any Friday has been finalized or marked
 * not-taken - or has a stored expected-roster snapshot (a finalized Friday
 * that was later reopened). Changing it after that could put finalized
 * history on the wrong side of the tracking start.
 */
export function trackingStartLock() {
  const rows = query(
    `SELECT DISTINCT s.service_date
       FROM attendance_sessions s
      WHERE s.service_type = 'friday_service'
        AND (s.finalization_state IS NOT NULL
             OR EXISTS (SELECT 1 FROM attendance_expected e WHERE e.session_id = s.id))
      ORDER BY s.service_date ASC`
  );
  return { locked: rows.length > 0, earliestFinalizedFriday: rows[0]?.service_date || null, count: rows.length };
}

/**
 * What tracking looks like from a given start date, derived from the sessions as they are (nothing is written, nothing is stored). Used for the compact readiness panel
 * (the current start) and for the preview before a change (a proposed start): the same counts, the same rules as classifySession().
 *
 *   eligibleFinalized      finalized Fridays on or after the start, not cancelled, not in the future  (these are the services that count)
 *   notTaken               "Attendance not taken" Fridays on or after the start (counted as neither present nor absent)
 *   awaitingFinalization   Fridays on or after the start, already past, neither finalized nor marked not taken, not cancelled: they count only once finalized, and none is an absence
 *   latestFinalized        the most recent finalized Friday on or after the start
 *   historicalOnly         Fridays (past, not cancelled) before the start that were finalized or marked not taken: kept as history, never counted
 */
function trackingFigures(start, asOf) {
  const rows = query(
    `SELECT service_date, finalization_state FROM attendance_sessions
      WHERE service_type = 'friday_service' AND status != 'cancelled' AND service_date <= @asOf`,
    { asOf }
  );
  const figures = { eligibleFinalized: 0, notTaken: 0, awaitingFinalization: 0, latestFinalized: null, historicalOnly: 0, earlierFridays: 0 };
  for (const row of rows) {
    if (row.service_date < start) {
      figures.earlierFridays += 1;
      if (row.finalization_state === 'finalized' || row.finalization_state === 'not_taken') figures.historicalOnly += 1;
      continue;
    }
    if (row.finalization_state === 'finalized') {
      figures.eligibleFinalized += 1;
      if (!figures.latestFinalized || row.service_date > figures.latestFinalized) figures.latestFinalized = row.service_date;
    } else if (row.finalization_state === 'not_taken') figures.notTaken += 1;
    else figures.awaitingFinalization += 1;
  }
  return figures;
}

/** The compact readiness summary for System Settings -> Attendance. */
export function trackingReadiness({ asOf = today() } = {}) {
  const start = trackingStartDate();
  if (!start) return { configured: false, start: null, eligibleFinalized: 0, notTaken: 0, awaitingFinalization: 0, latestFinalized: null, historicalOnly: 0 };
  return { configured: true, start, ...trackingFigures(start, asOf) };
}

/**
 * What a proposed start would mean, before anything is saved. Never writes. `ok:false` with a reason when the date cannot be used (not a real date, not a Friday).
 */
export function previewTrackingStart(proposed, { asOf = today() } = {}) {
  const wanted = String(proposed ?? '').trim();
  if (!wanted || !isValidDate(wanted)) return { ok: false, reason: 'invalid_date' };
  if (!isFriday(wanted)) return { ok: false, reason: 'not_friday' };
  const current = trackingStartDate();
  return {
    ok: true, proposed: wanted, current, unchanged: current === wanted, inFuture: wanted > asOf,
    ...trackingFigures(wanted, asOf),
    // How the picture differs from today's, so the change is understood before it is made.
    currentEligibleFinalized: current ? trackingFigures(current, asOf).eligibleFinalized : 0
  };
}

/**
 * The only sanctioned way to change attendance.tracking_start_date. The same mechanism serves UAT and production: there is no separate mode.
 *
 *   - The date must be a real FRIDAY (or blank = tracking not started, only while nothing has been finalized).
 *   - Nothing is ever rewritten: attendance rows, finalization states and expected-roster snapshots stay exactly as they are. The date only decides which Fridays
 *     COUNT (see classifySession()): a Friday before it stays in the history and has no consequence; one on or after it counts once finalized, and never becomes an
 *     absence while it is not.
 *   - Not locked (nothing finalized yet): any Friday (or blank) may be set.
 *   - Locked: refused, unless `override: true` (the route offers that to a Super Admin only) WITH a reason, and then only to a Friday - it can be earlier or later
 *     than the finalized history (later makes those finalized Fridays historical only; earlier makes the Fridays in between tracked and awaiting finalization),
 *     but it can never be cleared. The audit row keeps the old and new date, the reason, and how many Fridays moved either way.
 */
export function setTrackingStartDate(value, { userId = null, req = null, override = false, reason = '' } = {}) {
  const wanted = String(value ?? '').trim();
  if (wanted && !isValidDate(wanted)) return { ok: false, reason: 'invalid_date' };
  if (wanted && !isFriday(wanted)) return { ok: false, reason: 'not_friday' };
  const current = trackingStartDate();
  if ((current || '') === wanted) return { ok: true, changed: false, value: wanted };

  return transaction(() => {
    const lock = trackingStartLock();
    const cleanReason = String(reason || '').trim().slice(0, 500);
    if (lock.locked) {
      if (!override) return { ok: false, reason: 'locked', earliestFinalizedFriday: lock.earliestFinalizedFriday };
      if (!cleanReason) return { ok: false, reason: 'reason_required' };
      if (!wanted) return { ok: false, reason: 'cannot_clear_when_locked' };
    }
    const asOf = today();
    const before = current ? trackingFigures(current, asOf) : null;
    const after = trackingFigures(wanted || '9999-12-31', asOf);
    // Fridays that start counting (moved earlier) and finalized Fridays that stop counting (moved later), derived, never guessed.
    let newlyTracked = 0;
    let newlyHistorical = 0;
    if (wanted && current && wanted < current) {
      newlyTracked = queryOne(
        `SELECT COUNT(*) AS n FROM attendance_sessions
          WHERE service_type = 'friday_service' AND status != 'cancelled'
            AND service_date >= @wanted AND service_date < @current AND service_date <= @today`,
        { wanted, current, today: asOf }
      ).n;
    }
    if (wanted && current && wanted > current) {
      newlyHistorical = queryOne(
        `SELECT COUNT(*) AS n FROM attendance_sessions
          WHERE service_type = 'friday_service' AND status != 'cancelled' AND finalization_state IN ('finalized', 'not_taken')
            AND service_date >= @current AND service_date < @wanted AND service_date <= @today`,
        { wanted, current, today: asOf }
      ).n;
    }
    setSetting(TRACKING_START_SETTING, wanted, userId);
    recordAudit({
      req, userId,
      action: lock.locked ? 'attendance.tracking_start_overridden' : 'attendance.tracking_start_changed',
      entityType: 'system_settings', entityId: TRACKING_START_SETTING,
      detail: {
        from: current, to: wanted || null, reason: cleanReason || null,
        ...(lock.locked ? { earliest_finalized_friday: lock.earliestFinalizedFriday } : {}),
        newly_tracked_past_fridays: newlyTracked, finalized_fridays_now_historical_only: newlyHistorical,
        eligible_finalized_before: before ? before.eligibleFinalized : 0, eligible_finalized_after: wanted ? after.eligibleFinalized : 0
      }
    });
    return { ok: true, changed: true, value: wanted, overridden: lock.locked, newlyTrackedPastFridays: newlyTracked, newlyHistoricalFridays: newlyHistorical };
  }).immediate();
}
