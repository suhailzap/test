import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import db, { query } from '../db/index.js';
import { today, isValidDate, formatDate, formatMonthDay } from '../lib/dates.js';
import { getSetting } from '../lib/settings.js';

/*
 * DATE OF BIRTH DATA QUALITY.
 *
 * A date of birth drives age, congregation (Kids / Teens / Adults), birthday lists, reminders and reports. An imported one can be wrong in ways nobody can see from the value alone
 * (a day-first date read month-first, a month-and-day-only birthday stamped with the year it was typed, a placeholder). This module decides, for every member, whether the stored
 * date of birth can be TRUSTED, and every consumer asks it instead of reading the column directly. It never changes a stored date and never guesses a replacement: a date that cannot
 * be trusted is simply not used until a person verifies it.
 *
 *   state   'none'        no date of birth recorded
 *           'ok'          usable
 *           'invalid'     not a real calendar date (never usable)
 *           'unverified'  a real date that should not be trusted yet (see the reasons), or one a person marked not verified
 *           'month_day_only'  a person confirmed the birthday's month and day; the year is not known
 *   `suppressed` is true for invalid, unverified and month_day_only: the FULL date is not used - no age, no congregation, no age transition. `birthdayOk` says whether the month and day
 *   may be used (a birthday list, reminder, dashboard entry or report line): true for ok and month_day_only, false for invalid and unverified. A person's decision is applied last (see below).
 *
 * REASONS (a date can have several). Each is defensible from the record itself, never from a name or a guess:
 *   not_a_real_date                  the stored text is not a real date (month 26, 31 February...). Category A.
 *   future                           a date of birth after today. Category B.
 *   child_age_adult_details          the date gives a child's age but the record carries adult details (an adult civil status - the church's own list records a child as "Child" -
 *                                    or a wedding date or a spouse). Category B. A child with none of these is NOT flagged merely for being young.
 *   birth_year_is_first_visit_year   born in the same year as the recorded first visit, with adult details: a month-and-day-only birthday stamped with the year it was entered. Category B.
 *   possible_day_month_swap          imported from the sheet whose dates are day-first (see below) and day and month could be the wrong way round. Category C.
 *   import_block_check               same sheet, but the stored value cannot be explained by the swap: shown for checking, still usable. Category C (review only).
 *   dob_after_first_visit            born after the recorded first visit: impossible, so it is not used until a person verifies it. Category B.
 *   source_check_year               the workbook itself says "Check year of birth": the full date is not used (no age, congregation, transition or "turning") until a person decides. Category B.
 *   source_marked_red, source_columns_disagree
 *                                    what the original workbook itself says (src/config/dob-source-evidence.json): for CHECKING only, the date stays usable. Category E.
 *
 * The INACTIVE sheet of the church's master list holds day-first (DD-MM-YYYY) text, and the one-off importer read it month-first. The people from that sheet are the run of
 * consecutive inactive imports that starts where the legacy sequence number restarts; the run counts as the affected sheet only when at least one of its dates is impossible when
 * read month-first (that is the proof). Nothing here depends on a name.
 */

export const CATEGORY_LABELS = {
  A: 'Malformed or import parsing issue',
  B: 'Source date looks wrong: needs church verification',
  C: 'Ambiguous date format: needs checking against the source',
  D: 'Appears valid',
  E: 'Flagged in the original workbook: please check'
};

export const REASON_TEXT = {
  not_a_real_date: 'Not a real calendar date.',
  future: 'The date of birth is in the future.',
  child_age_adult_details: 'The date gives a child’s age, but the record has adult details (an adult civil status, a wedding date or a spouse).',
  birth_year_is_first_visit_year: 'Born in the same year as their first visit, with adult details: possibly a birthday typed without a year.',
  dob_after_first_visit: 'The date of birth is later than the date of the first visit, which cannot be right.',
  possible_day_month_swap: 'Imported from the INACTIVE sheet, whose dates are day-first: the day and month may be the wrong way round.',
  import_block_check: 'Imported from the INACTIVE sheet: check this date against the source.',
  source_marked_red: 'The original workbook shows this date in red, which appears to mean “needs checking” (it is not proof that the date is wrong).',
  source_check_year: 'The original workbook says “Check year of birth”, so the year is not used until someone has checked it.',
  source_columns_disagree: 'The original workbook’s two date-of-birth columns give different dates.'
};

/** Reasons that stop the stored date being used until a person decides. The others are for checking only: the date stays usable. */
const SUPPRESSING_REASONS = ['not_a_real_date', 'future', 'child_age_adult_details', 'birth_year_is_first_visit_year', 'dob_after_first_visit', 'source_check_year', 'possible_day_month_swap'];
const CATEGORY_B_REASONS = ['future', 'child_age_adult_details', 'birth_year_is_first_visit_year', 'dob_after_first_visit', 'source_check_year'];
const SOURCE_REASONS = ['source_marked_red', 'source_check_year', 'source_columns_disagree'];

/*
 * A PERSON'S DECISION (members.dob_review) and WHICH WINS. This is the one place the precedence lives; every consumer asks the functions below and never reads dob_review itself.
 *
 *   verified        a Church Admin / Super Admin confirmed the COMPLETE date. It wins over every automatic SUSPICION: the full date is used (age, congregation, age transitions,
 *                   birthdays, reminders). It does not win over an IMPOSSIBILITY: a stored text that is not a real calendar date, or a date of birth in the future, is never usable,
 *                   whatever anyone clicked (the screen refuses to record it; this guard keeps a hand-edited row safe too).
 *   month_day_only  the birthday's month and day are confirmed, the birth year is not known. The month and day alone are used (birthday list, reminders, calendar, dashboard,
 *                   report); the stored YEAR is never used and never shown: no age, no "turning", no congregation, no age transition. The stored text must still be a real date.
 *   unverified      the stored date is not used for anything (no age, congregation, transition, birthday list, reminder, calendar or report line).
 *   NULL            nobody has decided: the automatic assessment decides.
 *
 * `suppressed` therefore means "the FULL date of birth may not be used" and `birthdayOk` means "the month and day may be used". A month-and-day-only member is suppressed AND birthdayOk.
 */
export const REVIEW_STATES = ['verified', 'unverified', 'month_day_only'];
export const REVIEW_LABELS = {
  verified: 'Verified (full date)',
  unverified: 'Not verified',
  month_day_only: 'Birthday month and day only'
};

const STRONG_ADULT_CIVIL_STATUSES = ['married', 'separated', 'widowed'];

const parts = (text) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(text || ''));
  return m ? { y: Number(m[1]), a: Number(m[2]), b: Number(m[3]) } : null;
};

function ageOn(dob, asOf) {
  const [by, bm, bd] = dob.split('-').map(Number);
  const [ty, tm, td] = asOf.split('-').map(Number);
  let age = ty - by;
  if (tm < bm || (tm === bm && td < bd)) age -= 1;
  return age;
}

/**
 * Adult details on the record. Married, separated, widowed, a wedding date or a spouse are adult details on their own. A civil status of "single" is NOT: the source records some real
 * children as single, so it counts only together with something else that points to an adult (a cell group, bonafide membership, or a birth year equal to the first-visit year).
 */
function hasAdultDetails(m, { sameYearAsFirstVisit = false } = {}) {
  if (STRONG_ADULT_CIVIL_STATUSES.includes(m.marital_status) || m.anniversary_date || m.spouse_member_id || m.spouse_name) return true;
  return m.marital_status === 'single' && (Boolean(m.cell_group_id) || m.status === 'bonafide' || sameYearAsFirstVisit);
}

/** The people from the day-first sheet: see the header. Returns a Set of member ids (empty when there is no proof the sheet was misread). */
function dayFirstSheetPeople(rows) {
  const seq = (m) => { const x = /^SEQ (\d+)(?: \/ #\d+)?$/.exec(m.legacy_reference || ''); return x ? Number(x[1]) : null; };
  let start = -1;
  for (let i = 1; i < rows.length; i += 1) {
    const now = seq(rows[i]); const before = seq(rows[i - 1]);
    if (now !== null && before !== null && now < before - 100) { start = i; break; }
  }
  if (start < 0) return new Set();
  const block = [];
  for (let i = start; i < rows.length; i += 1) {
    const m = rows[i];
    if (!/^SEQ \d+$/.test(m.legacy_reference || '') || m.status !== 'inactive') break;
    block.push(m);
  }
  const proof = block.some((m) => { const p = parts(m.date_of_birth); return m.date_of_birth && (!p || !isValidDate(m.date_of_birth)); });
  return proof ? new Set(block.map((m) => m.id)) : new Set();
}

/** What the original workbook says about each date of birth (evidence only; see src/config/dob-source-evidence.json). Loaded once. */
let evidenceByLegacy = null;
function loadEvidence() {
  if (evidenceByLegacy) return evidenceByLegacy;
  evidenceByLegacy = new Map();
  try {
    const file = fileURLToPath(new URL('../config/dob-source-evidence.json', import.meta.url));
    for (const e of JSON.parse(fs.readFileSync(file, 'utf8')).entries || []) evidenceByLegacy.set(e.legacy, e);
  } catch { /* no evidence file: the automatic checks still work */ }
  return evidenceByLegacy;
}
const squash = (t) => String(t || '').split(/\s+/).filter(Boolean).join(' ').toLowerCase();

/** The workbook's entry for this member, only when BOTH the legacy reference and the name agree (a reference alone could belong to someone else in another database). */
export function sourceEvidenceFor(m) {
  const e = m.legacy_reference ? loadEvidence().get(m.legacy_reference) : null;
  return e && squash(m.first_name) === e.first && squash(m.last_name) === e.last ? e : null;
}

/** The workbook evidence in plain words, for the review screen. */
export function evidenceLines(e) {
  if (!e) return [];
  const lines = [`Main sheet, cell ${e.cell}.`];
  if (e.other) lines.push(`The workbook’s second birthday column (${e.other.cell}) says ${e.other.text}, read day-first as ${e.other.iso}.`);
  return lines;
}

/** Pure: assess one member row. `swapBlock` is the Set from dayFirstSheetPeople(). The member's own review decision (m.dob_review) is applied last, by the precedence above. */
export function assessDob(m, { asOf = today(), childMax = 12, teenMax = 17, swapBlock = new Set(), evidence = undefined } = {}) {
  const stored = m.date_of_birth ?? null;
  const review = REVIEW_STATES.includes(m.dob_review) ? m.dob_review : null;
  const base = {
    memberId: m.id, stored, state: 'none', suppressed: false, birthdayOk: false, reasons: [], category: null, age: null, ageIfValid: null, suggested: null,
    review, reviewedAt: m.dob_reviewed_at ?? null, reviewedBy: m.dob_reviewed_by ?? null, needsReview: false, reviewOnly: false, derivedState: 'none'
  };
  if (stored === null || stored === '') return base;

  const p = parts(stored);
  if (!p || !isValidDate(stored)) {
    const reading = p && p.a > 12 && p.b <= 12 && isValidDate(`${p.y}-${String(p.b).padStart(2, '0')}-${String(p.a).padStart(2, '0')}`) ? `${p.y}-${String(p.b).padStart(2, '0')}-${String(p.a).padStart(2, '0')}` : null;
    // An impossible date: no decision makes it usable (the screen refuses to record one); it stays in the list until it is corrected.
    return { ...base, state: 'invalid', derivedState: 'invalid', suppressed: true, reasons: ['not_a_real_date'], category: 'A', suggested: reading, needsReview: true };
  }

  const reasons = [];
  const age = ageOn(stored, asOf);
  const firstVisit = /Date of first visit: (\d{4})-(\d{2})-(\d{2})/.exec(m.notes || '');
  const sameYear = Boolean(firstVisit) && Number(firstVisit[1]) === p.y;
  if (stored > asOf) reasons.push('future');
  if (age >= 0 && age <= childMax && hasAdultDetails(m, { sameYearAsFirstVisit: sameYear })) reasons.push('child_age_adult_details');
  if (sameYear && age >= 0 && age <= teenMax && hasAdultDetails(m, { sameYearAsFirstVisit: true }) && !reasons.includes('child_age_adult_details')) reasons.push('birth_year_is_first_visit_year');
  // Born after the day they first came: impossible, and strong evidence the date is a placeholder. Suppresses until a person verifies it.
  if (firstVisit && stored > `${firstVisit[1]}-${firstVisit[2]}-${firstVisit[3]}`) reasons.push('dob_after_first_visit');
  let suggested = null;
  if (swapBlock.has(m.id)) {
    if (p.a === p.b) { /* the same either way round */ }
    else if (p.a <= 12 && p.b <= 12) { reasons.push('possible_day_month_swap'); suggested = `${p.y}-${String(p.b).padStart(2, '0')}-${String(p.a).padStart(2, '0')}`; }
    else reasons.push('import_block_check');
  }
  // What the original workbook says. Red and disagreeing columns are for CHECKING only (the date stays usable); "Check year of birth" is the workbook itself doubting the year, so it suppresses (see SUPPRESSING_REASONS).
  const ev = evidence === undefined ? sourceEvidenceFor(m) : evidence;
  if (ev) {
    if (ev.red) reasons.push('source_marked_red');
    if (ev.checkYear) reasons.push('source_check_year');
    if (ev.other && ev.other.iso !== stored) reasons.push('source_columns_disagree');
  }

  const suppressing = reasons.some((r) => SUPPRESSING_REASONS.includes(r));
  const derivedState = suppressing ? 'unverified' : 'ok';
  let category = 'D';
  if (reasons.length) {
    if (reasons.some((r) => CATEGORY_B_REASONS.includes(r))) category = 'B';
    else if (reasons.some((r) => r === 'possible_day_month_swap' || r === 'import_block_check')) category = 'C';
    else category = 'E';
  }
  const flagged = category !== 'D';
  const result = { ...base, derivedState, reasons, category, suggested, ageIfValid: age >= 0 ? age : null };

  // --- the person's decision wins over the automatic suspicion (the precedence in the header) ---
  const impossible = reasons.includes('future');
  if (review === 'verified' && !impossible) return { ...result, state: 'ok', suppressed: false, birthdayOk: true, age: age >= 0 ? age : null };
  if (review === 'month_day_only') return { ...result, state: 'month_day_only', suppressed: true, birthdayOk: true, age: null, ageIfValid: null };
  if (review === 'unverified') return { ...result, state: 'unverified', suppressed: true, birthdayOk: false, age: null };
  return {
    ...result, state: derivedState, suppressed: suppressing, birthdayOk: !suppressing, needsReview: flagged,
    age: !suppressing && age >= 0 ? age : null,
    reviewOnly: !suppressing && flagged
  };
}

// --- the shared, cached assessment of every member ----------------------------------------------------------------------------------------------------------------------------
let cache = null;

/**
 * Cheap and exact enough: total_changes() moves on every write made through this connection (a member, a setting, anything), and data_version moves when another connection writes.
 * Neither scans a table, so asking is nearly free even when a screen asks once per member.
 */
function stamp() {
  return `${today()}|${db.prepare('SELECT total_changes() AS t').get().t}|${db.pragma('data_version', { simple: true })}`;
}

function build() {
  const rows = query('SELECT id, status, first_name, last_name, date_of_birth, marital_status, anniversary_date, spouse_member_id, spouse_name, notes, legacy_reference, cell_group_id, dob_review, dob_reviewed_at, dob_reviewed_by FROM members ORDER BY id');
  const swapBlock = dayFirstSheetPeople(rows);
  const asOf = today();
  const childMax = Number(getSetting('congregation.child_max_age')) || 12;
  const teenMax = Number(getSetting('congregation.teen_max_age')) || 17;
  return new Map(rows.map((m) => [m.id, assessDob(m, { asOf, childMax, teenMax, swapBlock })]));
}

/** Every member's assessment, by member id. Recomputed whenever a member, their date of birth or the congregation boundaries change. */
export function assessments() {
  const key = stamp();
  if (!cache || cache.key !== key) cache = { key, map: build() };
  return cache.map;
}

export function dobAssessment(memberId) {
  return assessments().get(Number(memberId)) || null;
}

const plainValid = (d) => isValidDate(d) && d <= today();

/**
 * The FULL date of birth a consumer may USE (for an age, a congregation, an age transition), or null. A member row without an id (a form being filled in) is judged on the date alone: a
 * real date that is not in the future. A date that needs verification, or whose year is not known (month and day only), is never returned.
 */
export function trustedDob(member) {
  if (!member || !member.date_of_birth) return null;
  if (member.id === undefined || member.id === null) return plainValid(member.date_of_birth) ? member.date_of_birth : null;
  const a = dobAssessment(member.id);
  if (!a) return plainValid(member.date_of_birth) ? member.date_of_birth : null;
  return a.suppressed ? null : member.date_of_birth;
}

/**
 * The stored date a BIRTHDAY consumer may use (a list, a reminder, the calendar, a report) or null. It differs from trustedDob only for a member whose month and day a person confirmed
 * with the year unknown: the caller may use the month and day of what comes back, and must treat the year as unknown (see birthdayYearKnown).
 */
export function birthdayDob(member) {
  if (!member || !member.date_of_birth) return null;
  if (member.id === undefined || member.id === null) return plainValid(member.date_of_birth) ? member.date_of_birth : null;
  const a = dobAssessment(member.id);
  if (!a) return plainValid(member.date_of_birth) ? member.date_of_birth : null;
  return a.birthdayOk ? member.date_of_birth : null;
}

/** True when the birth YEAR may be used (so a "turning N" may be shown); false for a month-and-day-only birthday. */
export const birthdayYearKnown = (member) => trustedDob(member) !== null;

export const dobNeedsVerification = (memberId) => Boolean(dobAssessment(memberId)?.suppressed);

/** What the screens say: null when there is nothing to say. */
export function dobNotice(memberId) {
  const a = dobAssessment(memberId);
  if (!a || a.state === 'none') return null;
  if (a.state === 'month_day_only') {
    return {
      suppressed: true, monthDayOnly: true, state: a.state, stored: a.stored, category: a.category, suggested: null, review: a.review,
      reasons: [], headline: 'Birthday confirmed; birth year not known'
    };
  }
  if (!a.suppressed && !a.reviewOnly) return null;
  const marked = a.review === 'unverified';
  return {
    suppressed: a.suppressed, monthDayOnly: false, state: a.state, stored: a.stored, category: a.category, suggested: a.suggested, review: a.review,
    reasons: [...(marked ? ['A church administrator marked this date of birth as not verified.'] : []), ...a.reasons.map((r) => REASON_TEXT[r])],
    headline: a.suppressed ? 'Date of birth needs verification' : 'Check this date of birth against the source'
  };
}

/** Counts for the review page and the notes on the birthday screens. */
export function dobReviewCounts() {
  const counts = { A: 0, B: 0, C: 0, D: 0, E: 0, none: 0, suppressed: 0, birthdayHidden: 0, needsDecision: 0, verified: 0, unverified: 0, month_day_only: 0, total: 0 };
  for (const a of assessments().values()) {
    counts.total += 1;
    if (a.state === 'none') { counts.none += 1; continue; }
    counts[a.category] += 1;
    if (a.suppressed) counts.suppressed += 1;
    if (!a.birthdayOk) counts.birthdayHidden += 1;
    if (a.needsReview) counts.needsDecision += 1;
    if (a.review) counts[a.review] += 1;
  }
  return counts;
}

/**
 * How a screen that merely SHOWS a date of birth should write it. A date whose year may be used is shown in full; a month-and-day-only birthday is shown without a year; a date that needs
 * verification is shown to staff as stored with a note (so they can correct it) and to the member themselves as "to be confirmed". A screen never prints member.date_of_birth directly.
 */
export function dobDisplay(member, { style = 'long', staff = true } = {}) {
  const stored = member?.date_of_birth;
  if (!stored) return { text: '', note: '' };
  const a = member.id !== undefined && member.id !== null ? dobAssessment(member.id) : null;
  if (!a || !a.suppressed) return { text: formatDate(stored, style) || stored, note: '' };
  if (a.state === 'month_day_only') return { text: formatMonthDay(stored), note: 'Birth year not known' };
  return staff
    ? { text: formatDate(stored, style) || stored, note: 'Needs verification: not used for age, congregation or birthdays' }
    : { text: 'To be confirmed', note: '' };
}
