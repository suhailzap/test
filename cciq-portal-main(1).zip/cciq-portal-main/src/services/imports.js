import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import XLSX from 'xlsx';
import config from '../config/env.js';
import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso, isValidDate, today as nowDate } from '../lib/dates.js';
import {
  createMember, updateMember, listMembers, MEMBER_STATUSES, GENDERS, MARITAL_STATUSES
} from './members.js';
import { assignMemberToGroup, activeGroupOptions, createGroup } from './cell-groups.js';
import { recordAttendance, ATTENDANCE_STATUSES } from './attendance.js';

/**
 * Church spreadsheets are rarely tidy, so nothing here guesses silently: the
 * file is read, columns are proposed, and an administrator confirms the mapping
 * and reviews a preview before a single record is written.
 */

export const MEMBER_FIELDS = [
  { key: 'first_name', label: 'First name', required: true },
  { key: 'middle_name', label: 'Middle name' },
  { key: 'last_name', label: 'Last name', required: true },
  { key: 'full_name', label: 'Full name (split into first and last)' },
  { key: 'preferred_name', label: 'Preferred name' },
  { key: 'member_code', label: 'Existing member ID' },
  { key: 'date_of_birth', label: 'Date of birth' },
  { key: 'gender', label: 'Gender' },
  { key: 'phone', label: 'Contact number' },
  { key: 'email', label: 'Email' },
  { key: 'address', label: 'Address' },
  { key: 'marital_status', label: 'Marital status' },
  { key: 'anniversary_date', label: 'Wedding anniversary' },
  { key: 'date_joined', label: 'Date joined' },
  { key: 'status', label: 'Membership status' },
  { key: 'cell_group', label: 'Cell group' },
  { key: 'emergency_contact_name', label: 'Emergency contact name' },
  { key: 'emergency_contact_phone', label: 'Emergency contact number' },
  { key: 'notes', label: 'Notes' }
];

/** Column headings commonly used in church spreadsheets, for a first guess. */
const HEADER_HINTS = {
  first_name: ['first name', 'firstname', 'given name', 'first'],
  middle_name: ['middle name', 'middlename', 'middle'],
  last_name: ['last name', 'lastname', 'surname', 'family name', 'last'],
  full_name: ['name', 'full name', 'fullname', 'member name', 'complete name'],
  preferred_name: ['preferred name', 'nickname', 'known as', 'goes by'],
  member_code: ['member id', 'member no', 'member number', 'id no', 'id number', 'code'],
  date_of_birth: ['date of birth', 'birthday', 'birth date', 'dob', 'birthdate'],
  gender: ['gender', 'sex'],
  phone: ['contact number', 'mobile', 'phone', 'contact no', 'cell', 'telephone', 'whatsapp'],
  email: ['email', 'e-mail', 'email address'],
  address: ['address', 'residence', 'location', 'home address'],
  marital_status: ['marital status', 'civil status', 'status (marital)'],
  anniversary_date: ['anniversary', 'wedding anniversary', 'wedding date', 'date married'],
  date_joined: ['date joined', 'joined', 'membership date', 'date of membership', 'start date'],
  status: ['membership status', 'member status', 'status', 'active'],
  cell_group: ['cell group', 'group', 'cell', 'life group', 'small group'],
  emergency_contact_name: ['emergency contact', 'emergency contact name', 'next of kin'],
  emergency_contact_phone: ['emergency number', 'emergency contact number', 'emergency phone'],
  notes: ['notes', 'remarks', 'comments']
};

const clean = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();
const normalise = (value) => clean(value).toLowerCase();

// --- Reading the file ------------------------------------------------------

function importDir() {
  const dir = path.join(config.storageDir, 'imports');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

/*
 * A .xlsx file is a ZIP of XML. A small file can be built to expand to gigabytes (a "zip bomb"), and the spreadsheet library inflates everything in
 * memory, which would end the whole portal. The ZIP's own directory states every entry's uncompressed size, so it is read FIRST and a file that
 * claims to expand beyond what any church spreadsheet could is refused before anything is inflated. (The upload size limit is 12 MB; real workbooks
 * expand roughly ten times, so the ceilings below leave a wide margin.)
 */
export const MAX_SPREADSHEET_UNCOMPRESSED_BYTES = 250 * 1024 * 1024;
export const MAX_SPREADSHEET_ENTRIES = 2000;

export function assertSafeSpreadsheet(buffer, filename = '') {
  const refuse = (why) => Object.assign(new Error(`That spreadsheet cannot be opened safely: ${why}.`), { code: 'SPREADSHEET_UNSAFE', status: 400 });
  const extension = String(filename).toLowerCase().match(/\.[a-z0-9]+$/)?.[0] || '';
  const isZip = Buffer.isBuffer(buffer) && buffer.length >= 4 && buffer.readUInt32LE(0) === 0x04034b50;
  const isOle = Buffer.isBuffer(buffer) && buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
  // A file named as a workbook must BE one. (The reader would otherwise take any text, or noise, for a one-column CSV and stage it.)
  if ((extension === '.xlsx' || extension === '.xlsm') && !isZip) throw refuse('it is not a real .xlsx workbook');
  if (extension === '.xls' && !isZip && !isOle) throw refuse('it is not a real .xls workbook');
  if (!Buffer.isBuffer(buffer) || buffer.length < 22) return; // too small to be a zip; the reader will say it is unreadable
  if (!isZip) return;                                          // an old .xls or a .csv: bounded by the file size itself
  // find the end-of-central-directory record (it may be followed by a comment of up to 65,535 bytes)
  let eocd = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 22 - 65535); i -= 1) {
    if (buffer.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw refuse('its zip directory is missing or damaged');
  const entries = buffer.readUInt16LE(eocd + 10);
  const dirSize = buffer.readUInt32LE(eocd + 12);
  const dirStart = buffer.readUInt32LE(eocd + 16);
  if (entries === 0xffff || dirSize === 0xffffffff || dirStart === 0xffffffff) throw refuse('it uses a zip format that is far larger than a spreadsheet needs');
  if (entries > MAX_SPREADSHEET_ENTRIES) throw refuse(`it holds ${entries} parts (a spreadsheet has a few dozen)`);
  if (dirStart + dirSize > buffer.length) throw refuse('its zip directory is damaged');
  let at = dirStart; let total = 0;
  for (let n = 0; n < entries; n += 1) {
    if (at + 46 > buffer.length || buffer.readUInt32LE(at) !== 0x02014b50) throw refuse('its zip directory is damaged');
    const uncompressed = buffer.readUInt32LE(at + 24);
    if (uncompressed === 0xffffffff) throw refuse('one of its parts is larger than a spreadsheet could ever need');
    total += uncompressed;
    if (total > MAX_SPREADSHEET_UNCOMPRESSED_BYTES) throw refuse(`it would expand to more than ${Math.round(MAX_SPREADSHEET_UNCOMPRESSED_BYTES / (1024 * 1024))} MB`);
    at += 46 + buffer.readUInt16LE(at + 28) + buffer.readUInt16LE(at + 30) + buffer.readUInt16LE(at + 32);
  }
}

/** An Excel date serial as YYYY-MM-DD. Pure arithmetic: no JavaScript Date in local time is ever involved. */
export function isoFromSerial(serial) {
  return new Date(Date.UTC(1899, 11, 30) + Math.floor(serial) * 86400000).toISOString().slice(0, 10);
}

/**
 * The cells of one sheet as rows of text. A cell the spreadsheet stores as a DATE (a number with a date format) is turned into ISO text from
 * its serial number, so it can never be misread:
 *   - not from how it is DISPLAYED: a month-first "5/6/24" (Excel's default short date in many locales) would otherwise be read day-first
 *     by parseDate() as 5 June instead of 6 May;
 *   - not through a JavaScript Date: the spreadsheet library builds those in the computer's local time zone (and a few seconds off), so on a
 *     Qatar computer a date came out as the day before.
 * Every other cell is its formatted text, exactly as before.
 */
function sheetGrid(worksheet) {
  if (!worksheet['!ref']) return [];
  const range = XLSX.utils.decode_range(worksheet['!ref']);
  const grid = [];
  for (let r = range.s.r; r <= range.e.r; r += 1) {
    const row = []; let any = false;
    for (let c = range.s.c; c <= range.e.c; c += 1) {
      const cell = worksheet[XLSX.utils.encode_cell({ r, c })];
      let value = '';
      if (cell) {
        if (cell.t === 'n' && cell.z && XLSX.SSF.is_date(cell.z) && Number.isFinite(cell.v) && cell.v >= 1) value = isoFromSerial(cell.v);
        else value = cell.w !== undefined ? cell.w : (cell.v ?? '');
      }
      if (String(value) !== '') any = true;
      row.push(value);
    }
    if (any) grid.push(row);
  }
  return grid;
}

/**
 * Reads every sheet in a workbook. Blank leading rows are common in church
 * files, so the header row is found rather than assumed to be the first.
 */
export function readWorkbook(buffer, filename) {
  assertSafeSpreadsheet(buffer, filename);
  const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false, cellNF: true });
  const sheets = [];

  for (const name of workbook.SheetNames) {
    const grid = sheetGrid(workbook.Sheets[name]);
    if (grid.length === 0) continue;

    // The header is the first row where most cells carry text.
    let headerIndex = 0;
    let bestScore = -1;
    for (let i = 0; i < Math.min(grid.length, 10); i += 1) {
      const filled = grid[i].filter((c) => clean(c) !== '').length;
      const score = filled - i * 0.5;
      if (filled >= 2 && score > bestScore) {
        bestScore = score;
        headerIndex = i;
      }
    }

    const headers = grid[headerIndex].map((h, i) => clean(h) || `Column ${i + 1}`);
    const rows = grid.slice(headerIndex + 1)
      .filter((row) => row.some((cell) => clean(cell) !== ''))
      .map((row) => headers.map((_, i) => clean(row[i])));

    sheets.push({ name, headers, rows, rowCount: rows.length });
  }

  return { filename, sheets };
}

/** Suggests which column holds which member field. */
export function suggestMemberMapping(headers) {
  const mapping = {};
  const used = new Set();

  for (const [field, hints] of Object.entries(HEADER_HINTS)) {
    let matchIndex = headers.findIndex((h, i) => !used.has(i) && hints.includes(normalise(h)));
    if (matchIndex === -1) {
      matchIndex = headers.findIndex((h, i) => (
        !used.has(i) && hints.some((hint) => normalise(h).includes(hint))
      ));
    }
    if (matchIndex !== -1) {
      mapping[field] = matchIndex;
      used.add(matchIndex);
    }
  }

  // A single name column is more useful split than ignored.
  if (mapping.full_name !== undefined && (mapping.first_name !== undefined || mapping.last_name !== undefined)) {
    delete mapping.full_name;
  }
  return mapping;
}

/** Columns whose heading reads as a date are treated as service dates. */
export function detectDateColumns(headers) {
  return headers
    .map((header, index) => ({ index, header, date: parseDate(header) }))
    .filter((entry) => entry.date !== null);
}

// --- Value handling --------------------------------------------------------

const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

/**
 * Accepts the date formats church spreadsheets actually contain. Day-first is
 * assumed for ambiguous numeric dates, which matches usage in Qatar.
 */
export function parseDate(value) {
  const text = clean(value);
  if (!text) return null;

  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return isValidDate(text) ? text : null;

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }

  const slash = text.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})$/);
  if (slash) {
    let [, day, month, year] = slash;
    day = Number(day); month = Number(month); year = Number(year);
    if (year < 100) year += year > 50 ? 1900 : 2000;
    if (month > 12 && day <= 12) [day, month] = [month, day];
    const iso = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return isValidDate(iso) ? iso : null;
  }

  const worded = text.match(/^(\d{1,2})[\s-]*([a-zA-Z]{3,})[\s-]*(\d{2,4})$/)
    || text.match(/^([a-zA-Z]{3,})[\s-]*(\d{1,2}),?[\s-]*(\d{2,4})$/);
  if (worded) {
    const isDayFirst = /^\d/.test(text);
    const day = Number(isDayFirst ? worded[1] : worded[2]);
    const monthName = normalise(isDayFirst ? worded[2] : worded[1]).slice(0, 3);
    let year = Number(worded[3]);
    if (year < 100) year += year > 50 ? 1900 : 2000;
    const month = MONTHS.indexOf(monthName) + 1;
    if (month === 0) return null;
    const iso = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return isValidDate(iso) ? iso : null;
  }

  // Excel serial numbers.
  if (/^\d{5}$/.test(text)) {
    const serial = Number(text);
    const ms = Date.UTC(1899, 11, 30) + serial * 86400000;
    return new Date(ms).toISOString().slice(0, 10);
  }
  return null;
}

const PRESENT_WORDS = ['p', 'present', 'yes', 'y', 'x', '1', 'attended', 'here', '/', 'ok', 'true'];
const ABSENT_WORDS = ['a', 'absent', 'no', 'n', '0', 'x-', 'not present', 'false'];
const EXCUSED_WORDS = ['e', 'excused', 'exc', 'leave', 'travel', 'travelling', 'sick', 'ill'];
const VISITOR_WORDS = ['v', 'visitor', 'guest'];

/** Reads a single attendance cell. Blank means nothing was recorded. */
export function parseAttendance(value) {
  const text = normalise(value);
  if (!text || text === '-' || text === '--') return null;
  if (EXCUSED_WORDS.includes(text)) return 'excused';
  if (VISITOR_WORDS.includes(text)) return 'visitor';
  if (PRESENT_WORDS.includes(text)) return 'present';
  if (ABSENT_WORDS.includes(text)) return 'absent';
  if (ATTENDANCE_STATUSES.includes(text)) return text;
  return null;
}

export function parseGender(value) {
  const text = normalise(value);
  if (['m', 'male', 'brother'].includes(text)) return 'male';
  if (['f', 'female', 'sister'].includes(text)) return 'female';
  return GENDERS.includes(text) ? text : null;
}

export function parseMaritalStatus(value) {
  const text = normalise(value);
  const found = MARITAL_STATUSES.find((s) => s === text || text.startsWith(s.slice(0, 4)));
  return found || null;
}

export function parseStatus(value) {
  const text = normalise(value);
  if (['active', 'a', 'yes', 'y', '1'].includes(text)) return 'active';
  if (['inactive', 'i', 'no', 'n', '0'].includes(text)) return 'inactive';
  if (MEMBER_STATUSES.includes(text)) return text;
  return null;
}

function splitName(full) {
  const parts = clean(full).split(' ').filter(Boolean);
  if (parts.length === 0) return { first: '', last: '' };
  if (parts.length === 1) return { first: parts[0], last: '' };
  // "Last, First" is common in church lists.
  if (clean(full).includes(',')) {
    const [last, rest] = clean(full).split(',');
    const restParts = clean(rest).split(' ').filter(Boolean);
    return { first: restParts[0] || '', middle: restParts.slice(1).join(' '), last: clean(last) };
  }
  return { first: parts[0], middle: parts.slice(1, -1).join(' '), last: parts[parts.length - 1] };
}

// --- Staged imports --------------------------------------------------------

/** Holds a parsed file on the server between the upload and the confirmation. */
export function stageImport(data, { userId }) {
  // A staged file holds a whole spreadsheet of member details. One that was abandoned (the tab closed on the preview screen) must
  // not stay on disk - and in every backup - forever, so each new upload first clears the ones older than six hours.
  try { pruneStagedImports(); } catch { /* clearing old files is best-effort; never block a new upload */ }
  const token = crypto.randomBytes(16).toString('hex');
  const file = path.join(importDir(), `${token}.json`);
  fs.writeFileSync(file, JSON.stringify({ ...data, userId, stagedAt: nowIso() }), { mode: 0o600 });
  return token;
}

export function loadStagedImport(token, { userId }) {
  if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return null;
  const file = path.join(importDir(), `${token}.json`);
  if (!fs.existsSync(file)) return null;
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  // A staged file belongs to the administrator who uploaded it.
  if (Number(data.userId) !== Number(userId)) return null;
  return data;
}

export function discardStagedImport(token) {
  if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return;
  fs.rmSync(path.join(importDir(), `${token}.json`), { force: true });
}

/** Removes staged uploads left behind by an abandoned import. */
export function pruneStagedImports({ olderThanHours = 6 } = {}) {
  const dir = importDir();
  const cutoff = Date.now() - olderThanHours * 3600 * 1000;
  for (const name of fs.readdirSync(dir)) {
    const file = path.join(dir, name);
    if (fs.statSync(file).mtimeMs < cutoff) fs.rmSync(file, { force: true });
  }
}

// --- Members ---------------------------------------------------------------

function existingMemberIndex() {
  const rows = listMembers({ scope: { type: 'all' }, page: 1, pageSize: 100000 }).rows;
  const byCode = new Map();
  const byName = new Map();
  for (const row of rows) {
    if (row.member_code) byCode.set(normalise(row.member_code), row);
    const key = `${normalise(row.first_name)}|${normalise(row.last_name)}|${row.date_of_birth || ''}`;
    if (!byName.has(key)) byName.set(key, row);
  }
  return { byCode, byName };
}

/**
 * Turns mapped rows into what would be written, without writing anything.
 * Every row comes back with its outcome so the administrator sees the effect
 * before confirming.
 */
export function previewMembers({ headers, rows, mapping }) {
  const index = existingMemberIndex();
  const groups = new Map(activeGroupOptions().map((g) => [normalise(g.name), g]));
  const value = (row, field) => (mapping[field] === undefined ? '' : clean(row[mapping[field]]));

  const results = [];
  const seen = new Set();

  rows.forEach((row, i) => {
    const problems = [];
    let first = value(row, 'first_name');
    let middle = value(row, 'middle_name');
    let last = value(row, 'last_name');

    if (mapping.full_name !== undefined && (!first || !last)) {
      const split = splitName(value(row, 'full_name'));
      first = first || split.first;
      middle = middle || split.middle || '';
      last = last || split.last;
    }

    if (!first) problems.push('No first name');
    if (!last) problems.push('No last name');

    const record = {
      first_name: first,
      middle_name: middle || null,
      last_name: last,
      preferred_name: value(row, 'preferred_name') || null,
      member_code: value(row, 'member_code') || null,
      phone: value(row, 'phone') || null,
      email: value(row, 'email') || null,
      address: value(row, 'address') || null,
      notes: value(row, 'notes') || null,
      emergency_contact_name: value(row, 'emergency_contact_name') || null,
      emergency_contact_phone: value(row, 'emergency_contact_phone') || null
    };

    for (const [field, label] of [['date_of_birth', 'date of birth'], ['anniversary_date', 'anniversary'], ['date_joined', 'date joined']]) {
      const raw = value(row, field);
      if (!raw) { record[field] = null; continue; }
      const parsed = parseDate(raw);
      if (!parsed) problems.push(`Could not read the ${label} "${raw}"`);
      // A date of birth is never guessed: a two-digit year would have its century chosen for the person, and a date in the future cannot be a birth date.
      if (field === 'date_of_birth' && parsed) {
        if (/^\s*\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2}\s*$/.test(String(raw))) problems.push(`The date of birth "${raw}" has a two-digit year: write the full year so it is not guessed`);
        else if (parsed > nowDate()) problems.push(`The date of birth "${raw}" is in the future`);
      }
      record[field] = parsed;
    }

    record.gender = value(row, 'gender') ? parseGender(value(row, 'gender')) : null;
    record.marital_status = value(row, 'marital_status') ? parseMaritalStatus(value(row, 'marital_status')) : null;
    const status = value(row, 'status') ? parseStatus(value(row, 'status')) : null;

    const groupName = value(row, 'cell_group');
    const group = groupName ? groups.get(normalise(groupName)) : null;

    // Match an existing record by member ID first, then by name and birth date.
    const codeKey = record.member_code ? normalise(record.member_code) : null;
    const nameKey = `${normalise(first)}|${normalise(last)}|${record.date_of_birth || ''}`;
    const existing = (codeKey && index.byCode.get(codeKey)) || index.byName.get(nameKey) || null;

    let outcome = existing ? 'update' : 'create';
    if (problems.length) outcome = 'skip';
    if (seen.has(nameKey) && !existing) {
      outcome = 'skip';
      problems.push('The same person appears earlier in this file');
    }
    seen.add(nameKey);

    results.push({
      rowNumber: i + 1,
      outcome,
      problems,
      record,
      status: status || 'active',
      groupName: groupName || null,
      groupId: group ? group.id : null,
      groupIsNew: Boolean(groupName && !group),
      existingId: existing ? existing.id : null,
      existingCode: existing ? existing.member_code : null
    });
  });

  return {
    rows: results,
    summary: {
      total: results.length,
      create: results.filter((r) => r.outcome === 'create').length,
      update: results.filter((r) => r.outcome === 'update').length,
      skip: results.filter((r) => r.outcome === 'skip').length,
      newGroups: [...new Set(results.filter((r) => r.groupIsNew).map((r) => r.groupName))]
    }
  };
}

/**
 * Writes a previewed member import. Existing records are only ever added to,
 * never blanked, so an incomplete spreadsheet cannot erase good data.
 */
export function commitMembers(preview, { userId = null, filename = null, createGroups = true, updateExisting = true } = {}) {
  const counts = { created: 0, updated: 0, skipped: 0 };
  const groups = new Map(activeGroupOptions().map((g) => [normalise(g.name), g]));

  transaction(() => {
    for (const row of preview.rows) {
      if (row.outcome === 'skip') { counts.skipped += 1; continue; }
      if (row.outcome === 'update' && !updateExisting) { counts.skipped += 1; continue; }

      let groupId = row.groupId;
      if (!groupId && row.groupName && createGroups) {
        const existingGroup = groups.get(normalise(row.groupName));
        if (existingGroup) {
          groupId = existingGroup.id;
        } else {
          const created = createGroup({ name: row.groupName, status: 'active' }, { userId });
          groups.set(normalise(row.groupName), created);
          groupId = created.id;
        }
      }

      if (row.outcome === 'create') {
        const member = createMember(
          { ...row.record, member_code: undefined },
          { userId, status: row.status, reason: `Imported from ${filename || 'a spreadsheet'}` }
        );
        if (groupId) assignMemberToGroup(member.id, groupId, { userId });
        counts.created += 1;
      } else {
        // Only fill blanks on an existing record. `merged` starts as a full
        // copy of the current row — including every WRITABLE_FIELDS column
        // the spreadsheet never mentions (company, occupation, father_name,
        // is_baptized, baptism_date, cell_group_id, and others) — so a field
        // this import doesn't touch is never passed as `undefined` into
        // updateMember(), which would otherwise write it as NULL. Only the
        // fields the spreadsheet actually mapped are then considered for the
        // fill-blank overlay below.
        const current = queryOne('SELECT * FROM members WHERE id = @id', { id: row.existingId });
        const merged = { ...current };
        for (const [field, incoming] of Object.entries(row.record)) {
          if (field === 'member_code') continue;
          merged[field] = (current[field] === null || current[field] === '') && incoming ? incoming : current[field];
        }
        updateMember(row.existingId, merged, { userId });
        if (groupId && !current.cell_group_id) assignMemberToGroup(row.existingId, groupId, { userId });
        counts.updated += 1;
      }
    }

    execute(
      `INSERT INTO import_batches (kind, filename, row_count, created_count, updated_count, skipped_count, notes, created_at, created_by)
       VALUES ('members', @filename, @rows, @created, @updated, @skipped, @notes, @at, @by)`,
      {
        filename,
        rows: preview.rows.length,
        created: counts.created,
        updated: counts.updated,
        skipped: counts.skipped,
        notes: 'Existing records were only filled in where fields were blank.',
        at: nowIso(),
        by: userId
      }
    );
  })();

  return counts;
}

// --- Attendance ------------------------------------------------------------

/**
 * Previews a register laid out with members down the side and service dates
 * across the top, which is how most church attendance sheets are kept.
 */
export function previewAttendance({ headers, rows, mapping, dateColumns }) {
  const index = existingMemberIndex();
  const value = (row, field) => (mapping[field] === undefined ? '' : clean(row[mapping[field]]));

  const sessions = dateColumns.map((column) => {
    const weekday = new Date(`${column.date}T00:00:00Z`).getUTCDay();
    const serviceType = weekday === 5 ? 'friday_service' : 'special_service';
    const existing = queryOne(
      `SELECT id, status FROM attendance_sessions
        WHERE service_date = @date AND service_type = @serviceType AND cell_group_id = 0`,
      { date: column.date, serviceType }
    );
    return {
      ...column,
      sessionExists: Boolean(existing),
      sessionId: existing ? existing.id : null,
      isFriday: weekday === 5
    };
  });

  const people = [];
  let matched = 0;
  let unmatched = 0;
  let marks = 0;
  let marksSkipped = 0;

  rows.forEach((row, i) => {
    let first = value(row, 'first_name');
    let last = value(row, 'last_name');
    if (mapping.full_name !== undefined && (!first || !last)) {
      const split = splitName(value(row, 'full_name'));
      first = first || split.first;
      last = last || split.last;
    }

    const codeKey = value(row, 'member_code') ? normalise(value(row, 'member_code')) : null;
    const nameKey = `${normalise(first)}|${normalise(last)}|`;
    const existing = (codeKey && index.byCode.get(codeKey))
      || index.byName.get(nameKey)
      || [...index.byName.entries()].find(([key]) => key.startsWith(`${normalise(first)}|${normalise(last)}|`))?.[1]
      || null;

    const entries = [];
    for (const session of sessions) {
      const status = parseAttendance(row[session.index]);
      if (status) {
        entries.push({ date: session.date, status });
        marks += 1;
      }
    }

    if (existing) {
      matched += 1;
    } else {
      unmatched += 1;
      // Marks belonging to nobody on record are counted separately, so the
      // preview never promises more than it will import.
      marksSkipped += entries.length;
      marks -= entries.length;
    }

    people.push({
      rowNumber: i + 1,
      name: [first, last].filter(Boolean).join(' ') || `Row ${i + 1}`,
      memberId: existing ? existing.id : null,
      memberCode: existing ? existing.member_code : null,
      entries
    });
  });

  return {
    sessions,
    people,
    summary: {
      people: people.length,
      matched,
      unmatched,
      marks,
      marksSkipped,
      services: sessions.length,
      nonFriday: sessions.filter((s) => !s.isFriday).length,
      newSessions: sessions.filter((s) => !s.sessionExists).length
    }
  };
}

/**
 * Thrown by commitAttendance() when the shared attendance write service
 * (recordAttendance() in services/attendance.js) refuses to write to one or
 * more of the sessions in the import - a cancelled service, a future-dated
 * one, or one that no longer exists. Thrown from INSIDE the import's
 * transaction, so nothing from the import is committed: no sessions created,
 * no records written, no import_batches row claiming success. `refused` lists
 * each session date and the reason it was refused.
 */
export class AttendanceImportRefusedError extends Error {
  constructor(refused) {
    super(`Attendance import refused: ${refused.map((r) => `${r.date} (${r.reason})`).join(', ')}`);
    this.name = 'AttendanceImportRefusedError';
    this.refused = refused;
  }
}

export function commitAttendance(preview, { userId = null, filename = null, createSessions = true } = {}) {
  const counts = { services: 0, records: 0, skippedPeople: 0 };
  const at = nowIso();

  transaction(() => {
    const sessionIds = new Map();
    for (const session of preview.sessions) {
      if (session.sessionId) {
        sessionIds.set(session.date, session.sessionId);
        continue;
      }
      if (!createSessions) continue;
      /*
       * Only a date that actually falls on a Friday becomes a Friday Service.
       * Anything else is recorded as a separate gathering that does not count
       * toward the consecutive-Friday follow-up rule, so importing a register
       * that includes other days cannot distort it.
       */
      const isFriday = new Date(`${session.date}T00:00:00Z`).getUTCDay() === 5;
      const serviceType = isFriday ? 'friday_service' : 'special_service';

      const result = execute(
        `INSERT INTO attendance_sessions
           (service_date, service_type, title, status, counts_toward_followup, cell_group_id, notes, created_at, created_by)
         VALUES (@date, @serviceType, @title, 'held', @counts, 0, @notes, @at, @by)
         ON CONFLICT(service_date, service_type, cell_group_id) DO NOTHING`,
        {
          date: session.date,
          serviceType,
          counts: isFriday ? 1 : 0,
          title: isFriday ? 'CCIQ Friday Service' : 'Imported gathering',
          notes: `Created by import from ${filename || 'a spreadsheet'}`,
          at,
          by: userId
        }
      );
      const id = Number(result.lastInsertRowid) || queryOne(
        `SELECT id FROM attendance_sessions WHERE service_date = @date AND service_type = @serviceType AND cell_group_id = 0`,
        { date: session.date, serviceType }
      )?.id;
      if (id) {
        sessionIds.set(session.date, id);
        counts.services += 1;
      }
    }

    const byDate = new Map();
    for (const person of preview.people) {
      if (!person.memberId) { counts.skippedPeople += 1; continue; }
      for (const entry of person.entries) {
        const sessionId = sessionIds.get(entry.date);
        if (!sessionId) continue;
        if (!byDate.has(sessionId)) byDate.set(sessionId, []);
        byDate.get(sessionId).push({ memberId: person.memberId, status: entry.status });
      }
    }

    const dateBySessionId = new Map([...sessionIds.entries()].map(([date, sessionId]) => [sessionId, date]));
    const refused = [];
    for (const [sessionId, entries] of byDate.entries()) {
      const result = recordAttendance(sessionId, entries, { userId });
      if (!result.ok) {
        // The shared service refused this write: none of it happened, so none
        // of it may be counted or recorded below as if it had.
        refused.push({ sessionId, date: dateBySessionId.get(sessionId) || null, reason: result.reason });
        continue;
      }
      counts.records += result.saved;
    }
    // All-or-nothing: an import that the shared service partly refused is not
    // a successful import, and leaving the rest committed would leave sessions
    // created and records written for a register the operator was told failed.
    // Throwing inside the transaction rolls all of it back.
    if (refused.length) throw new AttendanceImportRefusedError(refused);

    execute(
      `INSERT INTO import_batches (kind, filename, row_count, created_count, updated_count, skipped_count, notes, created_at, created_by)
       VALUES ('attendance', @filename, @rows, @records, @services, @skipped, @notes, @at, @by)`,
      {
        filename,
        rows: preview.people.length,
        records: counts.records,
        services: counts.services,
        skipped: counts.skippedPeople,
        notes: 'People not matched to a member record were left out.',
        at,
        by: userId
      }
    );
  })();

  return counts;
}

export function listImportBatches({ limit = 30 } = {}) {
  return query(
    `SELECT b.*, u.display_name AS created_by_name
       FROM import_batches b LEFT JOIN users u ON u.id = b.created_by
      ORDER BY b.created_at DESC LIMIT @limit`,
    { limit }
  );
}
