import crypto from 'node:crypto';
import { likePattern } from '../lib/like.js';
import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso } from '../lib/dates.js';
import { hashPassword, checkPasswordPolicy } from '../lib/passwords.js';
import { destroySessionsForUser } from '../lib/session-store.js';
import config from '../config/env.js';
import { displayName as formalMemberName } from './members.js';

/**
 * A fresh, random starting password, shown once to the admin who triggered
 * it (account creation or an admin-generated reset) and required to change
 * at next sign-in. Previously every new account shared one fixed literal —
 * since the username pattern (suggestMemberUsername below) is itself
 * predictable from a member's name, that let anyone who knew a member's
 * name sign in as them before they ever had, completing the forced change
 * and locking the real member out. A random value per account closes that
 * regardless of how guessable the username is.
 *
 * Sized relative to config.auth.passwordMinLength, not a fixed byte count:
 * a fixed-length candidate would fail every retry identically (never
 * succeeding) the moment an owner raises the minimum length past it, since
 * retrying a policy check that fails on length alone can never help.
 * Retries remain useful for the letter+digit checks, which genuinely are
 * probabilistic per attempt.
 */
export function generateInitialPassword({ email } = {}) {
  // Codex/independent verification (R02 P2): sizing by BYTE count (the
  // previous approach) meant the resulting base64url length only ever
  // approximately tracked the configured minimum, and could exceed
  // checkPasswordPolicy()'s fixed maximum once the minimum was raised close
  // to it - config/env.js now refuses a PASSWORD_MIN_LENGTH past that
  // maximum at startup, but generation still needs to land at an EXACT
  // target length within both bounds, not merely somewhere near it.
  //
  // When the caller knows which account the credential is for, `email` makes
  // the check account-aware (checkPasswordPolicy() rejects a password that
  // contains the email's local part) - the SAME policy the account is held
  // to everywhere else. A candidate that happens to violate it is discarded
  // and another drawn.
  const { passwordMinLength: min, passwordMaxLength: max } = config.auth;
  const targetLength = Math.min(Math.max(min, 16), max);
  const bytes = Math.ceil((targetLength * 3) / 4) + 2; // slight overshoot, trimmed to the exact target below
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const candidate = crypto.randomBytes(bytes).toString('base64url').slice(0, targetLength);
    if (checkPasswordPolicy(candidate, { email }).length === 0) return candidate;
  }
  throw new Error(email
    ? 'Could not generate an initial password that satisfies the password policy for this account. '
      + 'Check the account email and PASSWORD_MIN_LENGTH.'
    : 'Could not generate a valid initial password.');
}

/** The roles for which the owner-approved temporary starting password applies: ordinary accounts only. Administrators and the Kiosk are never given a shared, known password. */
const ORDINARY_ROLES = ['member', 'cell_group_leader'];

/**
 * The starting password for a NEW account: an explicitly configured temporary password for an ordinary account, otherwise a fresh random one. Administrative accounts,
 * kiosk accounts, and values that fail the account's password policy always get a random password. Always created with must_change_password, so it is only ever used once.
 */
export function initialPasswordFor(roleKeys, { email } = {}) {
  const roles = [...(roleKeys || [])];
  const ordinary = roles.length > 0 && roles.every((role) => ORDINARY_ROLES.includes(role));
  const configured = config.auth.initialPassword;
  if (ordinary && configured && checkPasswordPolicy(configured, { email }).length === 0) return configured;
  return generateInitialPassword({ email });
}

/**
 * Finds an account from whatever the person typed at sign-in. Some church
 * workers have no email address of their own, so a username is equally valid.
 */
export function findUserByIdentifier(identifier) {
  const value = String(identifier || '').trim().toLowerCase();
  if (!value) return null;
  return queryOne(
    'SELECT * FROM users WHERE email = @value OR LOWER(username) = @value',
    { value }
  ) || null;
}

export function findUserByEmail(email) {
  return queryOne('SELECT * FROM users WHERE email = @email', { email: String(email || '').toLowerCase() }) || null;
}

export function findUserById(id) {
  return queryOne('SELECT * FROM users WHERE id = @id', { id }) || null;
}

/** The single account linked to a member, if one exists. */
export function findUserByMemberId(memberId) {
  return queryOne('SELECT * FROM users WHERE member_id = @memberId', { memberId }) || null;
}

export function rolesForUser(userId) {
  return query(
    `SELECT r.key, r.name, r.rank
       FROM user_roles ur JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = @id
      ORDER BY r.rank`,
    { id: userId }
  );
}

export function permissionsForUser(userId) {
  return query(
    `SELECT DISTINCT p.key
       FROM user_roles ur
       JOIN role_permissions rp ON rp.role_id = ur.role_id
       JOIN permissions p ON p.id = rp.permission_id
      WHERE ur.user_id = @id`,
    { id: userId }
  ).map((r) => r.key);
}

function ledCellGroupIds(memberId) {
  if (!memberId) return [];
  return query(
    `SELECT id FROM cell_groups WHERE leader_member_id = @id OR assistant_member_id = @id`,
    { id: memberId }
  ).map((r) => r.id);
}

/**
 * Builds the authorisation context used by every request. Permissions are read
 * from the database on each request so a revoked role takes effect immediately.
 */
export function loadUserContext(userId) {
  const user = findUserById(userId);
  if (!user || user.status !== 'active') return null;

  const roles = rolesForUser(user.id);
  const permissions = new Set(permissionsForUser(user.id));
  const member = user.member_id
    ? queryOne('SELECT * FROM members WHERE id = @id', { id: user.member_id })
    : null;

  return {
    id: user.id,
    email: user.email,
    displayName: user.display_name,
    memberId: user.member_id,
    member,
    // Not for display - attachUser() compares this against the snapshot
    // taken at login (req.session.securityGeneration) to detect ANY
    // account security event since (a password change/reset, a
    // deactivation, a reactivation), even one that raced a concurrent
    // in-flight request. See middleware/auth.js and R03 in
    // CCIQ_FINAL_BLOCKER_CORRECTION_REPORT.md.
    securityGeneration: user.security_generation,
    mustChangePassword: Boolean(user.must_change_password),
    roles: roles.map((r) => r.key),
    roleNames: roles.map((r) => r.name),
    primaryRole: roles[0]?.key || 'member',
    primaryRoleName: roles[0]?.name || 'Member',
    permissions,
    ledCellGroupIds: ledCellGroupIds(user.member_id),
    can: (permission) => permissions.has(permission),
    canAny: (...list) => list.some((p) => permissions.has(p)),
    hasRole: (role) => roles.some((r) => r.key === role)
  };
}

export function isLocked(user) {
  return Boolean(user.locked_until && new Date(user.locked_until).getTime() > Date.now());
}

export function registerFailedAttempt(user) {
  const attempts = (user.failed_attempts || 0) + 1;
  const shouldLock = attempts >= config.auth.maxFailedAttempts;
  execute(
    `UPDATE users SET failed_attempts = @attempts, locked_until = @locked, updated_at = @at WHERE id = @id`,
    {
      id: user.id,
      attempts,
      locked: shouldLock ? new Date(Date.now() + config.auth.lockoutMinutes * 60000).toISOString() : user.locked_until,
      at: nowIso()
    }
  );
  return { attempts, locked: shouldLock };
}

export function registerSuccessfulLogin(userId) {
  execute(
    `UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = @at, updated_at = @at WHERE id = @id`,
    { id: userId, at: nowIso() }
  );
}

/**
 * The username scheme for a member's own account: cciq_ followed by their
 * first initial and last name, lowercase, with spaces and anything unusual
 * stripped out. A collision gets a number appended, tried upward until one
 * is free — the account it belongs to is never guessed at or reused.
 */
export function suggestMemberUsername(firstName, lastName) {
  const clean = (value) => String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const initial = clean(firstName).charAt(0);
  const surname = clean(lastName);
  const base = `cciq_${initial}${surname}` || 'cciq_member';

  let candidate = base;
  let suffix = 2;
  while (queryOne('SELECT id FROM users WHERE LOWER(username) = @u', { u: candidate })) {
    candidate = `${base}${suffix}`;
    suffix += 1;
  }
  return candidate;
}

/**
 * A username from a person's name or email, tidied and made unique. Church
 * workers sign in with this when they have no email of their own.
 */
export function suggestUsername(seed) {
  const base = String(seed || '').split('@')[0].toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '.').replace(/^[.]+|[.]+$/g, '').slice(0, 30) || 'user';

  let candidate = base;
  let suffix = 1;
  while (queryOne('SELECT id FROM users WHERE LOWER(username) = @u', { u: candidate })) {
    suffix += 1;
    candidate = `${base}${suffix}`;
  }
  return candidate;
}

export async function createUser({
  email, username = null, password, displayName, roleKeys = ['member'], memberId = null,
  mustChangePassword = false, createdBy = null, onCreated = null
}) {
  // onCreated(userId) runs inside the same transaction as the account: the route writes its audit row there, so the account and its audit row commit together.
  const at = nowIso();
  const passwordHash = await hashPassword(password);
  const chosenUsername = username
    ? String(username).trim().toLowerCase()
    : suggestUsername(displayName || email);

  return transaction(() => {
    const result = execute(
      `INSERT INTO users (member_id, email, username, password_hash, display_name, status, must_change_password, created_at, updated_at, created_by)
       VALUES (@member_id, @email, @username, @hash, @name, 'active', @must, @at, @at, @by)`,
      {
        member_id: memberId,
        email: String(email).toLowerCase(),
        username: chosenUsername,
        hash: passwordHash,
        name: displayName,
        must: mustChangePassword ? 1 : 0,
        at,
        by: createdBy
      }
    );
    const userId = result.lastInsertRowid;
    for (const key of roleKeys) {
      const role = queryOne('SELECT id FROM roles WHERE key = @key', { key });
      if (role) {
        execute(
          `INSERT OR IGNORE INTO user_roles (user_id, role_id, assigned_at, assigned_by)
           VALUES (@user_id, @role_id, @at, @by)`,
          { user_id: userId, role_id: role.id, at, by: createdBy }
        );
      }
    }
    if (onCreated) onCreated(userId);
    return userId;
  })();
}

/**
 * Creates the sign-in account that goes with a member record, the moment the
 * member itself is created, so nobody has to remember a second step. A
 * member already linked to an account is left exactly as it is — this never
 * creates a second one, and never re-links an existing account to a
 * different member.
 *
 * The member's own email is used when they have one and it is not already
 * claimed by another account; a shared household email is common enough
 * that this cannot be assumed to belong to only one person. Where there is
 * no usable email, a placeholder under cciq.local takes its place — the
 * portal accepts the username at sign-in either way, so this is never
 * something the member needs to know or use.
 */
export async function provisionMemberAccount(member, { createdBy = null } = {}) {
  const existing = findUserByMemberId(member.id);
  if (existing) return { created: false, user: existing, password: null };

  const username = suggestMemberUsername(member.first_name, member.last_name);

  const ownEmail = String(member.email || '').trim().toLowerCase();
  const email = (ownEmail && !findUserByEmail(ownEmail)) ? ownEmail : `${username}@cciq.local`;
  const password = initialPasswordFor(['member'], { email });

  const displayName = formalMemberName(member) || username;

  const userId = await createUser({
    email,
    username,
    password,
    displayName,
    roleKeys: ['member'],
    memberId: member.id,
    mustChangePassword: true,
    createdBy
  });

  return { created: true, user: findUserById(userId), password };
}

/**
 * A device already signed in under the old password must not keep working
 * once it no longer applies — this closes that gap for both a self-service
 * change and an admin-mediated reset. `exceptSid` (the session performing
 * a self-service change, which already proved the current password) is
 * kept alive rather than signed out along with the rest; an admin reset of
 * someone else's account has none of the target's sessions to except.
 *
 * A password change/reset also advances security_generation (R03) - the
 * one signal attachUser() actually checks now, covering this same
 * credential-change case together with account deactivation/reactivation
 * under a single invariant. Returns the new generation so a caller
 * excepting its own session (a self-service change) can update that
 * session's own securityGeneration snapshot to match — otherwise the very
 * next request would find the excepted session's stale snapshot no longer
 * matching the live value and destroy it anyway, defeating the exception.
 * See attachUser() in middleware/auth.js.
 *
 * `expectedGeneration` (Codex/independent verification, R03 follow-up):
 * self-service change is the one caller that spans real, slow, awaited work
 * (verifyPassword() against the row read at request start, then
 * hashPassword() here) between reading the account's security state and
 * committing this UPDATE - if a concurrent security event (an admin reset,
 * a deactivate/reactivate) advances security_generation anywhere in that
 * window, this UPDATE must not commit against the now-stale state it began
 * under. The check is folded directly into the UPDATE's own WHERE clause
 * (not a preceding SELECT, which a concurrent write could still slip
 * between) so SQLite's own single-statement atomicity is what actually
 * guarantees it: either this UPDATE affects the row because the generation
 * still matches, or affects nothing at all, with no window for a
 * concurrent writer to land in between the check and the commit. Passed as
 * null by admin-mediated resets (unconditional, as before - an admin
 * overwriting the account's OWN just-established state is legitimate by
 * definition, and has no "began under generation N" of its own to protect).
 */
export async function setPassword(userId, password, { mustChange = false, exceptSid = null, expectedGeneration = null, onChanged = null } = {}) {
  const hash = await hashPassword(password);
  // Everything after the (slow) hashing is one synchronous transaction, so the credential change, the signing-out of the other sessions and the
  // caller's audit row (onChanged) commit together or not at all.
  return transaction(() => {
  const result = execute(
    `UPDATE users SET password_hash = @hash, must_change_password = @must, failed_attempts = 0,
                      locked_until = NULL, security_generation = security_generation + 1, updated_at = @at
     WHERE id = @id
       AND (@expectedGeneration IS NULL OR security_generation = @expectedGeneration)`,
    { id: userId, hash, must: mustChange ? 1 : 0, at: nowIso(), expectedGeneration }
  );
  if (expectedGeneration !== null && result.changes === 0) {
    // The account's security state moved since this operation began. The
    // credential update did not commit - the password is unchanged, the
    // generation is unchanged, and (critically) no sessions are touched
    // here: destroySessionsForUser() below must never run for a change
    // that didn't happen, and the caller must never refresh its own
    // session's securityGeneration to a value this stale request has no
    // authority over restoring.
    return { ok: false, reason: 'stale_security_generation' };
  }
  destroySessionsForUser(userId, { exceptSid });
  const securityGeneration = queryOne('SELECT security_generation FROM users WHERE id = @id', { id: userId }).security_generation;
  if (onChanged) onChanged();
  return { ok: true, securityGeneration };
  })();
}

// --- Administration --------------------------------------------------------

/** Users with their roles and linked member, for the administration screen. */
export function listUsersDetailed({ search = '', status = null } = {}) {
  return query(
    `SELECT u.*,
            GROUP_CONCAT(r.name, ', ') AS role_names,
            GROUP_CONCAT(r.key, ',') AS role_keys,
            m.member_code, m.first_name, m.last_name, m.preferred_name
       FROM users u
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       LEFT JOIN members m ON m.id = u.member_id
      WHERE (@search = '' OR u.display_name LIKE @like ESCAPE '\\' OR u.email LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\')
        AND (@status IS NULL OR u.status = @status)
      GROUP BY u.id
      ORDER BY u.display_name COLLATE NOCASE`,
    { search: search || '', like: likePattern(search), status }
  );
}

/** Sort keys the Users screen may use (whitelisted; never taken from the request as SQL). */
export const USER_SORT_COLUMNS = ['name', 'email', 'status', 'last_login', 'role'];
export const USER_STATUS_FILTERS = ['active', 'disabled', 'locked'];
export const USER_LINK_FILTERS = ['linked', 'unlinked'];

/**
 * The Users screen: filtered, sorted and PAGED on the server. Returns { rows, total } for the
 * requested window; every filter is optional. Nothing here changes any account.
 *   status      active | disabled | locked (an active account that is temporarily locked out)
 *   role        a role key
 *   passwordDue only accounts that must change their password
 *   linked      linked | unlinked to a member record
 */
export function searchUsers({
  search = '', status = null, role = null, passwordDue = false, linked = null,
  sort = 'name', direction = 'asc', limit = 25, offset = 0
} = {}) {
  const params = {
    search: search || '', like: likePattern(search), status, role, now: nowIso(),
    passwordDue: passwordDue ? 1 : 0, linked
  };
  const where = `
      WHERE (@search = '' OR u.display_name LIKE @like ESCAPE '\\' OR u.email LIKE @like ESCAPE '\\' OR u.username LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\')
        AND (@status IS NULL
             OR (@status = 'active' AND u.status = 'active' AND (u.locked_until IS NULL OR u.locked_until <= @now))
             OR (@status = 'disabled' AND u.status != 'active')
             OR (@status = 'locked' AND u.status = 'active' AND u.locked_until IS NOT NULL AND u.locked_until > @now))
        AND (@role IS NULL OR EXISTS (
              SELECT 1 FROM user_roles xr JOIN roles r2 ON r2.id = xr.role_id WHERE xr.user_id = u.id AND r2.key = @role))
        AND (@passwordDue = 0 OR u.must_change_password = 1)
        AND (@linked IS NULL OR (@linked = 'linked' AND u.member_id IS NOT NULL) OR (@linked = 'unlinked' AND u.member_id IS NULL))`;
  const total = queryOne(
    `SELECT COUNT(*) AS n FROM users u LEFT JOIN members m ON m.id = u.member_id ${where}`, params
  ).n;
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const order = {
    name: `u.display_name COLLATE NOCASE ${dir}`,
    email: `u.email COLLATE NOCASE ${dir}`,
    status: `u.status ${dir}, u.display_name COLLATE NOCASE`,
    last_login: `u.last_login_at IS NULL, u.last_login_at ${dir}, u.display_name COLLATE NOCASE`,
    role: `role_names COLLATE NOCASE ${dir}, u.display_name COLLATE NOCASE`
  }[USER_SORT_COLUMNS.includes(sort) ? sort : 'name'];
  const rows = query(
    `SELECT u.*,
            GROUP_CONCAT(r.name, ', ') AS role_names,
            GROUP_CONCAT(r.key, ',') AS role_keys,
            m.member_code, m.first_name, m.last_name, m.preferred_name
       FROM users u
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       LEFT JOIN members m ON m.id = u.member_id
       ${where}
      GROUP BY u.id
      ORDER BY ${order}, u.id
      LIMIT @limit OFFSET @offset`,
    { ...params, limit, offset }
  );
  return { rows, total };
}

export function getUserDetailed(id) {
  const user = queryOne(
    `SELECT u.*, m.member_code, m.first_name, m.last_name, m.preferred_name
       FROM users u LEFT JOIN members m ON m.id = u.member_id
      WHERE u.id = @id`,
    { id }
  );
  if (!user) return null;
  return { ...user, roles: rolesForUser(id), permissions: permissionsForUser(id) };
}

export function updateUserProfile(id, { displayName, email, memberId }) {
  execute(
    `UPDATE users SET display_name = @name, email = @email, member_id = @memberId, updated_at = @at
      WHERE id = @id`,
    { id, name: displayName, email: String(email).toLowerCase(), memberId: memberId || null, at: nowIso() }
  );
  return getUserDetailed(id);
}

export function setUserStatus(id, status) {
  if (!['active', 'disabled'].includes(status)) return null;
  execute(
    `UPDATE users SET status = @status, updated_at = @at,
            failed_attempts = CASE WHEN @status = 'active' THEN 0 ELSE failed_attempts END,
            locked_until = CASE WHEN @status = 'active' THEN NULL ELSE locked_until END,
            security_generation = security_generation + 1
      WHERE id = @id`,
    { id, status, at: nowIso() }
  );
  // R03 (Codex/independent verification): both directions advance
  // security_generation, not just disabling. A resurrected session (a
  // stale in-flight save landing after destroySessionsForUser()'s delete
  // below - see lib/session-store.js) captured its snapshot before
  // whichever of these transitions happened; reactivation must never let
  // that snapshot become valid again by leaving the generation where
  // disabling left it, so it advances again here too. The counter only
  // ever increases - reactivation never restores the pre-disable value.
  if (status === 'disabled') {
    // Previously relied entirely on the per-request status check (attachUser
    // treats an inactive account as unauthenticated) - correct, but lazy: a
    // device that makes no request during the disabled window keeps its
    // session row, and reactivating the account later would silently make
    // it valid again with no security event in between ever having touched
    // it. Destroying every session now closes that regardless of whether
    // any of them are ever used again before a possible reactivation.
    destroySessionsForUser(id);
  }
  return getUserDetailed(id);
}

export function unlockUser(id) {
  execute('UPDATE users SET failed_attempts = 0, locked_until = NULL, updated_at = @at WHERE id = @id',
    { id, at: nowIso() });
  return getUserDetailed(id);
}

/** Replaces a user's roles in one step, so nothing is left half-assigned. */
export function setUserRoles(id, roleKeys, { assignedBy = null } = {}) {
  const at = nowIso();
  return transaction(() => {
    execute('DELETE FROM user_roles WHERE user_id = @id', { id });
    for (const key of roleKeys) {
      const role = queryOne('SELECT id FROM roles WHERE key = @key', { key });
      if (!role) continue;
      execute(
        `INSERT OR IGNORE INTO user_roles (user_id, role_id, assigned_at, assigned_by)
         VALUES (@user_id, @role_id, @at, @by)`,
        { user_id: id, role_id: role.id, at, by: assignedBy }
      );
    }
    return rolesForUser(id);
  })();
}

export function countUsersWithPermission(permissionKey, { excludeUserId = null } = {}) {
  return queryOne(
    `SELECT COUNT(DISTINCT u.id) AS n
       FROM users u
       JOIN user_roles ur ON ur.user_id = u.id
       JOIN role_permissions rp ON rp.role_id = ur.role_id
       JOIN permissions p ON p.id = rp.permission_id
      WHERE p.key = @key AND u.status = 'active'
        AND (@exclude IS NULL OR u.id != @exclude)`,
    { key: permissionKey, exclude: excludeUserId }
  ).n;
}

// --- Roles -----------------------------------------------------------------

export function listRoles() {
  return query(
    `SELECT r.*,
            (SELECT COUNT(*) FROM user_roles ur WHERE ur.role_id = r.id) AS user_count,
            (SELECT COUNT(*) FROM role_permissions rp WHERE rp.role_id = r.id) AS permission_count
       FROM roles r
      ORDER BY r.rank, r.name`
  );
}

export function getRole(id) {
  return queryOne('SELECT * FROM roles WHERE id = @id', { id }) || null;
}

export function getRoleByKey(key) {
  return queryOne('SELECT * FROM roles WHERE key = @key', { key }) || null;
}

export function permissionsForRole(roleId) {
  return query(
    `SELECT p.key FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id
      WHERE rp.role_id = @roleId`,
    { roleId }
  ).map((r) => r.key);
}

export function allPermissions() {
  return query('SELECT * FROM permissions ORDER BY category, key');
}

/**
 * Replaces a role's permissions. The Super Admin role is not editable: it must
 * always hold everything, otherwise a mistake here could lock the church out
 * of its own portal.
 */
export function setRolePermissions(roleId, permissionKeys) {
  const role = getRole(roleId);
  if (!role) return null;
  if (role.key === 'super_admin') return { ok: false, reason: 'super_admin_fixed' };

  return transaction(() => {
    execute('DELETE FROM role_permissions WHERE role_id = @roleId', { roleId });
    for (const key of permissionKeys) {
      const permission = queryOne('SELECT id FROM permissions WHERE key = @key', { key });
      if (!permission) continue;
      execute(
        'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)',
        { roleId, permissionId: permission.id }
      );
    }
    return { ok: true, permissions: permissionsForRole(roleId) };
  })();
}
