import { query, queryOne } from '../db/index.js';
import { today } from '../lib/dates.js';
import { getSetting } from '../lib/settings.js';
import {
  classifySession, hasExpectedSnapshot, getExpectedSnapshot, resolveExpectedRoster, trackingStartDate
} from './attendance-tracking.js';
import { serviceHeadcount } from './service-headcount.js';

/*
 * ONE interpretation of "what does attendance mean for this member at this
 * Friday". Every consumer of tracked-Friday attendance - the follow-up list,
 * stored reminders, Long Absence, member history, the register summary, the
 * dashboard, cell-group and congregation figures, reports, CSV and PDF - asks
 * this module instead of deciding for itself what a missing attendance row
 * means. There must be no LEFT JOIN ... IS NULL business rule anywhere that
 * independently decides someone is absent.
 *
 * The inputs are only these:
 *   - the tracking start date (Go-Live);
 *   - the session lifecycle (classifySession);
 *   - the historical expected roster (attendance_expected once finalized,
 *     or the live computation from status history while a Friday is still open);
 *   - the member's attendance row;
 *   - the cancellation state.
 *
 * Non-Friday sessions (cell group meetings, special services) are NOT
 * interpreted here and keep their existing semantics.
 *
 * Nothing in this file writes anything.
 */

// ---------------------------------------------------------------------------
// Canonical states and labels
// ---------------------------------------------------------------------------

/**
 * What a member's attendance IS for one session, as an operator sees it.
 * "Absent" covers a physical Absent row AND a derived one (an expected member
 * with no row on a finalized Friday); operators are never shown the difference
 * (`derived` is metadata for tests and audit).
 */
export const MEMBER_STATES = [
  'not_tracked', 'pending', 'awaiting_finalization', 'present', 'vacation',
  'absent', 'not_expected', 'not_taken', 'cancelled'
];

export const STATE_LABELS = {
  not_tracked: 'Not tracked',
  pending: 'Not checked in',
  awaiting_finalization: 'Awaiting finalization',
  present: 'Present',
  vacation: 'Vacation',
  absent: 'Absent',
  not_expected: 'Not expected',
  not_taken: 'Attendance not taken',
  cancelled: 'Cancelled'
};

/**
 * The key used for display (labels, pill and strip CSS). Existing screens
 * already key on the stored status (present / excused / absent), so the
 * canonical state maps back onto those and only the NEW states add keys.
 */
const DISPLAY_TOKEN = {
  present: 'present',
  vacation: 'excused',
  absent: 'absent',
  pending: 'pending',
  awaiting_finalization: 'awaiting_finalization',
  not_expected: 'not_expected',
  not_taken: 'not_taken',
  cancelled: 'cancelled',
  not_tracked: 'not_tracked'
};

/** Labels for every display key a consumer may render (merged into the shared attendance labels). */
export const OUTCOME_DISPLAY_LABELS = {
  pending: STATE_LABELS.pending,
  awaiting_finalization: STATE_LABELS.awaiting_finalization,
  not_expected: STATE_LABELS.not_expected,
  not_taken: STATE_LABELS.not_taken,
  cancelled: STATE_LABELS.cancelled,
  not_tracked: STATE_LABELS.not_tracked
};

const POSITIVE_ROWS = ['present', 'visitor'];

/**
 * Legacy outcome token, kept because the Phase 2B lifecycle service, its
 * audit records and its tests speak it:
 *
 *   present               expected, Present or member-linked Visitor row
 *   vacation              expected, Vacation
 *   absent_recorded       expected, physical Absent row
 *   absent_derived        expected, NO row, Friday FINALIZED
 *   pending               expected, NO row, Friday not finalized
 *   attended_unexpected   not expected, positive row: headcount only
 *   present_evidence      "not taken" Friday, positive row: evidence only
 *   null                  no outcome
 */
export function outcomeOf({ phase, expected, rowStatus }) {
  const attended = POSITIVE_ROWS.includes(rowStatus);
  if (phase === 'not_taken') return attended ? 'present_evidence' : null;
  if (!expected) return attended ? 'attended_unexpected' : null;
  if (attended) return 'present';
  if (rowStatus === 'excused') return 'vacation';
  if (rowStatus === 'absent') return 'absent_recorded';
  return phase === 'finalized' ? 'absent_derived' : 'pending';
}

/**
 * The full canonical resolution for one member at one session.
 *
 * `expected` is true / false / null (null = cannot be established: an
 * ambiguous status history on a Friday that is not finalized yet, which is
 * never quietly treated as expected OR as safely excluded).
 *
 * Returns:
 *   state        one of MEMBER_STATES
 *   token        display key (see DISPLAY_TOKEN)
 *   outcome      the legacy outcome token from outcomeOf()
 *   derived      true when Absent because no row exists on a finalized Friday
 *   positive     positive attendance evidence (Present or member-linked Visitor row)
 *   unexpected   attended without being expected
 *   headcount    counts toward the actual attendance headcount
 *   rateNumerator / rateDenominator   participation in the expected-member rate;
 *                only ever true on a FINALIZED tracked Friday for an expected member
 *   followUp     how the consecutive-absence traversal treats this Friday:
 *                  'absence'  adds one to the run
 *                  'vacation' the Vacation rule decides (breaks, or counts, per setting)
 *                  'break'    ends the run
 *                  'barrier'  a past tracked Friday that is not settled: the run
 *                             cannot be evaluated across it
 *                  'skip'     neither adds nor breaks (cancelled, not taken, open, scheduled)
 *                  'outside'  not part of the tracked sequence (pre-go-live, tracking not started, non-Friday)
 */
export function resolveOutcome({ phase, expected, rowStatus = null }) {
  const positive = POSITIVE_ROWS.includes(rowStatus);
  const known = expected === true || expected === false;
  const out = (state, extra = {}) => ({
    phase,
    state,
    token: DISPLAY_TOKEN[state],
    outcome: known ? outcomeOf({ phase, expected: expected === true, rowStatus }) : null,
    derived: false,
    positive,
    expected: expected === true,
    unexpected: expected === false && positive && phase !== 'not_taken',
    headcount: positive && phase !== 'cancelled',
    rateNumerator: false,
    rateDenominator: false,
    followUp: 'skip',
    ...extra
  });

  if (phase === 'not_applicable') {
    // Not interpreted here. The row status is passed through untouched.
    return { ...out('not_tracked'), state: 'legacy', token: rowStatus || 'not_recorded', followUp: 'outside' };
  }
  if (phase === 'not_started' || phase === 'pre_go_live') {
    // A historical row is shown as recorded; a MISSING row is simply not tracked - never absent.
    if (rowStatus === 'excused') return out('vacation', { followUp: 'outside' });
    if (rowStatus === 'absent') return out('absent', { followUp: 'outside' });
    if (positive) return out('present', { followUp: 'outside' });
    return out('not_tracked', { followUp: 'outside' });
  }
  if (phase === 'cancelled') return out('cancelled', { followUp: 'skip', headcount: false });

  if (phase === 'not_taken') {
    // No expected roster, no absence, no rate. Real attendance stays as evidence.
    if (positive) return out('present', { followUp: 'break' });
    return out('not_taken', { followUp: 'skip' });
  }

  if (expected === false) {
    // Not expected that Friday: attendance is headcount only, no outcome otherwise.
    // It breaks an eligible-attendance run either way.
    return out(positive ? 'present' : 'not_expected', { followUp: 'break' });
  }

  if (phase === 'finalized') {
    if (expected !== true) return out('not_tracked', { followUp: 'barrier' }); // finalized without a roster: unusable, fail closed
    if (positive) return out('present', { rateNumerator: true, rateDenominator: true, followUp: 'break' });
    if (rowStatus === 'excused') return out('vacation', { followUp: 'vacation' });
    return out('absent', {
      derived: rowStatus !== 'absent',
      rateDenominator: true,
      followUp: 'absence'
    });
  }

  // Tracked, not finalized: scheduled / open / awaiting_finalization.
  if (positive) return out('present', { followUp: 'break' });
  if (phase === 'awaiting_finalization') {
    // A past Friday nobody has settled: a barrier for the consecutive-absence run.
    if (rowStatus === 'excused') return out('vacation', { followUp: 'barrier' });
    if (rowStatus === 'absent') return out('absent', { followUp: 'barrier' });
    return out('awaiting_finalization', { followUp: 'barrier' });
  }
  // scheduled / open: nothing is decided yet, and nothing is absent yet.
  if (rowStatus === 'excused') return out('vacation', { followUp: 'skip' });
  if (rowStatus === 'absent') return out('absent', { followUp: 'skip' });
  return out('pending', { followUp: 'skip' });
}

// ---------------------------------------------------------------------------
// Expected roster and per-session summary
// ---------------------------------------------------------------------------

/**
 * Who is expected at this session. Once a snapshot exists it is the ONLY
 * source (even after a reopen) - today's statuses are never consulted again.
 * Before that, the live computation from status history as of the Friday.
 */
export function expectedRosterForSession(session) {
  if (hasExpectedSnapshot(session.id)) {
    const rows = getExpectedSnapshot(session.id);
    return {
      source: 'snapshot',
      expected: new Map(rows.map((r) => [r.member_id, r.status_at_service])),
      expectedRows: null,
      ambiguous: []
    };
  }
  const live = resolveExpectedRoster(session.service_date);
  return {
    source: 'live',
    expected: new Map(live.expected.map((e) => [e.memberId, e.statusAtService])),
    expectedRows: live.expected,
    ambiguous: live.ambiguous
  };
}

/**
 * The counts an administrator (and the finalization audit record) needs.
 *
 * Rate = expected members Present / (expected - expected on Vacation). People
 * outside the expected roster are counted in the headcount but never enter the
 * rate. `rate` is the number; `finalRate` is what may be PUBLISHED as the
 * session's rate - null unless the Friday is finalized, so an open, unsettled,
 * not-taken or cancelled Friday can never masquerade as a final rate.
 */
export function computeSessionSummary(session, roster = expectedRosterForSession(session), phase = classifySession(session).phase) {
  const rows = query('SELECT member_id, status FROM attendance_records WHERE session_id = @id', { id: session.id });
  const rowByMember = new Map(rows.map((r) => [r.member_id, r.status]));

  let presentExpected = 0;
  let vacation = 0;
  let absentRecorded = 0;
  let noRow = 0;
  // The people behind each count, collected in the same pass, so a list shown for a number (the attendance drill-down) is the number's own members and cannot drift from it.
  const presentExpectedIds = [];
  const vacationIds = [];
  const absentRecordedIds = [];
  const noRowIds = [];
  for (const memberId of roster.expected.keys()) {
    const outcome = outcomeOf({ phase: 'open', expected: true, rowStatus: rowByMember.get(memberId) });
    if (outcome === 'present') { presentExpected += 1; presentExpectedIds.push(memberId); }
    else if (outcome === 'vacation') { vacation += 1; vacationIds.push(memberId); }
    else if (outcome === 'absent_recorded') { absentRecorded += 1; absentRecordedIds.push(memberId); }
    else { noRow += 1; noRowIds.push(memberId); }
  }

  let unexpectedAttendees = 0;
  let unexpectedOtherRecords = 0;
  for (const [memberId, status] of rowByMember) {
    if (roster.expected.has(memberId)) continue;
    if (POSITIVE_ROWS.includes(status)) unexpectedAttendees += 1;
    else unexpectedOtherRecords += 1;
  }
  // First Timers (and people who were First Timers that day and have since become members) count once, through the one headcount definition.
  const physical = serviceHeadcount(session.id);
  // `firstTimeVisitors` is every attendee who is not a member for this service (First Timers on a first visit AND returning visitors): the headcount arithmetic
  // below and in the lifecycle needs all of them. `firstVisits` and `returningVisitors` split it for the screens that name them.
  const firstTimeVisitors = physical.visitors;

  const expected = roster.expected.size;
  const denominator = expected - vacation;
  const rate = denominator > 0 ? Math.round((presentExpected / denominator) * 100) : null;
  const final = phase === 'finalized';
  return {
    expected,
    presentExpected,
    vacation,
    absentRecorded,
    // No row at all: becomes Absent on finalization (derived), Pending while open.
    derivedAbsent: final ? noRow : 0,
    willBecomeAbsent: noRow,
    pending: final ? 0 : noRow,
    absentTotal: final ? absentRecorded + noRow : null,
    presentExpectedIds,
    vacationIds,
    absentRecordedIds,
    // Absent with no record: only a finalized Friday turns "no row" into absence.
    derivedAbsentIds: final ? noRowIds : [],
    unexpectedAttendees,
    unexpectedOtherRecords,
    firstTimeVisitors,
    firstVisits: physical.firstTimers,
    returningVisitors: physical.returning,
    actualHeadcount: physical.total,
    attendanceRecords: rows.length,
    rateNumerator: presentExpected,
    rateDenominator: denominator,
    rate,
    final,
    finalRate: final ? rate : null
  };
}

// ---------------------------------------------------------------------------
// Bulk: one pass over many Fridays, no N+1
// ---------------------------------------------------------------------------

/**
 * A Friday session together with everything needed to resolve any member at
 * it: lifecycle phase, expected roster (snapshot, or live while unsettled) and
 * every attendance row. Built in a few queries for a whole range of Fridays.
 *
 *   ctx = { session, id, date, phase, classification, counts, roster, ambiguous, rows, rosterSource }
 *
 * `roster` is a Map(memberId -> status_at_service) or null when the phase
 * needs none (pre-go-live, cancelled without a snapshot, not taken).
 */
export function buildFridayContexts({ from = null, to = today(), countingOnly = false, limit = null } = {}) {
  const sessions = query(
    `SELECT * FROM attendance_sessions
      WHERE service_type = 'friday_service'
        AND (@from IS NULL OR service_date >= @from)
        AND (@to IS NULL OR service_date <= @to)
        ${countingOnly ? 'AND counts_toward_followup = 1' : ''}
      ORDER BY service_date DESC, id DESC
      ${limit ? 'LIMIT @limit' : ''}`,
    { from, to, limit }
  );
  if (sessions.length === 0) return [];

  const lowest = sessions[sessions.length - 1].service_date;
  const highest = sessions[0].service_date;
  const rowsBySession = new Map();
  for (const r of query(
    `SELECT r.session_id, r.member_id, r.status
       FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id
      WHERE s.service_type = 'friday_service' AND s.service_date >= @lowest AND s.service_date <= @highest`,
    { lowest, highest }
  )) {
    if (!rowsBySession.has(r.session_id)) rowsBySession.set(r.session_id, new Map());
    rowsBySession.get(r.session_id).set(r.member_id, r.status);
  }
  const snapshotBySession = new Map();
  for (const r of query(
    `SELECT e.session_id, e.member_id, e.status_at_service
       FROM attendance_expected e JOIN attendance_sessions s ON s.id = e.session_id
      WHERE s.service_date >= @lowest AND s.service_date <= @highest`,
    { lowest, highest }
  )) {
    if (!snapshotBySession.has(r.session_id)) snapshotBySession.set(r.session_id, new Map());
    snapshotBySession.get(r.session_id).set(r.member_id, r.status_at_service);
  }

  const goLive = trackingStartDate();
  const asOf = today();
  return sessions.map((session) => {
    const classification = classifySession(session, { asOf, goLive });
    const phase = classification.phase;
    let roster = snapshotBySession.get(session.id) || null;
    let ambiguous = new Set();
    let rosterSource = roster ? 'snapshot' : null;
    // A snapshot is authoritative even after a reopen. Otherwise only a tracked,
    // live (open / awaiting) Friday needs a roster, computed from status history.
    if (!roster && (phase === 'open' || phase === 'awaiting_finalization' || phase === 'scheduled')) {
      const live = resolveExpectedRoster(session.service_date);
      roster = new Map(live.expected.map((e) => [e.memberId, e.statusAtService]));
      ambiguous = new Set(live.ambiguous.map((a) => a.memberId));
      rosterSource = 'live';
    }
    return {
      session,
      id: session.id,
      date: session.service_date,
      phase,
      classification,
      counts: session.counts_toward_followup === 1,
      roster,
      ambiguous,
      rosterSource,
      rows: rowsBySession.get(session.id) || new Map()
    };
  });
}

/** The canonical resolution for one member at one prepared Friday. */
export function memberOutcomeAt(ctx, memberId) {
  let expected = false;
  if (ctx.roster) {
    expected = ctx.roster.has(memberId) ? true : (ctx.ambiguous.has(memberId) ? null : false);
  } else if (ctx.phase === 'finalized') {
    expected = null;
  }
  return resolveOutcome({ phase: ctx.phase, expected, rowStatus: ctx.rows.get(memberId) || null });
}

/** A member's outcome at each prepared Friday (same order as `contexts`). */
export function memberTimeline(memberId, contexts) {
  return contexts.map((ctx) => ({
    sessionId: ctx.id,
    date: ctx.date,
    phase: ctx.phase,
    title: ctx.session.title,
    countsTowardFollowUp: ctx.counts,
    ...memberOutcomeAt(ctx, memberId)
  }));
}

/**
 * The member's own attendance rate across prepared Fridays: only FINALIZED
 * tracked Fridays at which they were expected count. Vacation leaves the
 * denominator. Null when nothing measurable exists (never a divide-by-zero).
 */
export function memberRate(memberId, contexts) {
  let numerator = 0;
  let denominator = 0;
  let sessions = 0;
  for (const ctx of contexts) {
    if (ctx.phase !== 'finalized') continue;
    const r = memberOutcomeAt(ctx, memberId);
    if (r.rateDenominator) denominator += 1;
    if (r.rateNumerator) numerator += 1;
    if (r.rateDenominator || r.state === 'vacation') sessions += 1;
  }
  return { numerator, denominator, sessions, rate: denominator > 0 ? Math.round((numerator / denominator) * 100) : null };
}

/**
 * Weighted aggregate: SUM(numerator) / SUM(denominator). Never an average of
 * percentages. Null when the pooled denominator is zero.
 */
export function pooledRate(parts) {
  let numerator = 0;
  let denominator = 0;
  for (const p of parts) {
    numerator += p.numerator || 0;
    denominator += p.denominator || 0;
  }
  return { numerator, denominator, rate: denominator > 0 ? Math.round((numerator / denominator) * 100) : null };
}

// ---------------------------------------------------------------------------
// Consecutive absence
// ---------------------------------------------------------------------------

export function followUpRules() {
  return {
    threshold: Number(getSetting('attendance.followup_threshold')) || 3,
    excusedBreaks: Boolean(getSetting('attendance.excused_counts'))
  };
}

/**
 * The member's CURRENT consecutive-absence run, from the newest Friday
 * backwards, over prepared counting Fridays (newest first).
 *
 * Only a Friday that is a tracked, finalized, non-cancelled, not-taken Friday
 * at which the member was in the expected snapshot, and whose outcome is
 * Absent (recorded or derived), adds to the run. Then:
 *   Present / positive attendance          ends the run
 *   Vacation                               ends it when the Vacation rule says so
 *                                          (attendance.excused_counts), else counts
 *   not expected that Friday               ends the run
 *   past Friday awaiting finalization      a BARRIER: traversal stops and the run is
 *                                          reported as `blocked` - it is never skipped over
 *   cancelled / not taken / open           neither add nor end
 *   pre-go-live or tracking not started    outside the tracked sequence: traversal stops
 */
export function consecutiveAbsenceRun(memberId, contexts, { threshold, excusedBreaks } = {}) {
  const rules = followUpRules();
  const limit = threshold ?? rules.threshold;
  const vacationBreaks = excusedBreaks ?? rules.excusedBreaks;

  let streak = 0;
  const missed = [];
  let blocked = false;
  let blockedOn = null;
  let endedBy = 'no_more_sessions';
  // Every Friday the run passed through (absences AND skipped ones such as a cancelled or
  // not-taken Friday in the middle or at the old end of it) - the span of the episode. Used to
  // recognise the SAME episode when it grows or shrinks at its old end.
  const episode = [];

  for (const ctx of contexts) {
    if (!ctx.counts) continue;
    const r = memberOutcomeAt(ctx, memberId);
    const entry = { sessionId: ctx.id, date: ctx.date, status: r.token, derived: r.derived };
    if (r.followUp === 'skip') { episode.push(ctx.id); continue; }
    if (r.followUp === 'absence') { streak += 1; missed.push(entry); episode.push(ctx.id); continue; }
    if (r.followUp === 'vacation') {
      if (vacationBreaks) { endedBy = 'vacation'; break; }
      streak += 1; missed.push(entry); episode.push(ctx.id); continue;
    }
    if (r.followUp === 'barrier') { blocked = true; blockedOn = { sessionId: ctx.id, date: ctx.date }; endedBy = 'awaiting_finalization'; break; }
    if (r.followUp === 'outside') { endedBy = 'outside_tracking'; break; }
    endedBy = r.positive ? 'attended' : 'not_expected';
    break;
  }

  const oldest = missed[missed.length - 1] || null;
  return {
    streak,
    threshold: limit,
    missed,
    flagged: streak >= limit,
    // A run cut short by an unsettled Friday may be understated: say so, never imply it is complete.
    blocked,
    blockedOn,
    possiblyUnderstated: blocked && streak < limit,
    endedBy,
    runStart: oldest ? { sessionId: oldest.sessionId, date: oldest.date } : null,
    episodeSessionIds: episode
  };
}

/**
 * Whether follow-up can be called complete: false while any past tracked
 * counting Friday is still waiting to be finalized. (Cancelled and not-taken
 * Fridays are settled; open and future ones are not yet in the past.)
 */
export function followUpCompleteness(contexts = buildFridayContexts({ countingOnly: true })) {
  const awaiting = contexts
    .filter((c) => c.counts && c.phase === 'awaiting_finalization')
    .map((c) => ({ id: c.id, date: c.date }))
    .sort((a, b) => a.date.localeCompare(b.date));
  return { complete: awaiting.length === 0, awaitingFridays: awaiting };
}

/**
 * Latest Friday with positive attendance evidence for a member. From any era by default;
 * `since` (a date, normally the tracking start date) limits it to that date onward.
 */
export function lastPositiveAttendance(memberId, { since = null } = {}) {
  return queryOne(
    `SELECT s.service_date, r.status, s.id AS session_id
       FROM attendance_records r JOIN attendance_sessions s ON s.id = r.session_id
      WHERE r.member_id = @id AND s.service_type = 'friday_service'
        AND s.status != 'cancelled'
        AND (@since IS NULL OR s.service_date >= @since)
        AND r.status IN ('present','visitor')
      ORDER BY s.service_date DESC LIMIT 1`,
    { id: memberId, since }
  ) || null;
}
