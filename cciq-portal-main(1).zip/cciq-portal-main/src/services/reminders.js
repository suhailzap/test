import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { getSetting } from '../lib/settings.js';
import { today, nowIso, addDays, formatDate } from '../lib/dates.js';
import { upcomingBirthdays, upcomingAnniversaries, displayName } from './members.js';
import { followUpList } from './attendance.js';
import { onAttendanceLifecycleChange } from './attendance-lifecycle.js';
import { recordAudit } from '../lib/audit.js';
import { assessments } from './dob-quality.js';

/**
 * A birthday reminder made before a date of birth was found to need verification stays on record (nothing is deleted), but it is not shown or counted: it was about a birthday nobody can
 * trust. A birthday whose month and day a person confirmed (year unknown) is trusted, so its reminders show again. Integers only, taken from the assessment, so the fragment is safe to put in the SQL.
 */
function hiddenBirthdayClause(alias = 'r') {
  const ids = [...assessments()].filter(([, a]) => a.state !== 'none' && !a.birthdayOk).map(([id]) => Number(id)).filter(Number.isInteger);
  return ids.length ? `AND NOT (${alias}.reminder_type = 'birthday' AND ${alias}.member_id IN (${ids.join(',')}))` : '';
}


export const REMINDER_STATES = ['new', 'acknowledged', 'completed', 'dismissed'];

export const REMINDER_TYPES = {
  birthday: 'Birthday',
  anniversary: 'Anniversary',
  attendance_followup: 'Friday Service follow-up',
  member_information: 'Member information',
  custom: 'Other'
};

export const STATE_LABELS = {
  new: 'New',
  acknowledged: 'Acknowledged',
  completed: 'Completed',
  dismissed: 'Dismissed'
};

function reminderDays(key, fallback) {
  const value = getSetting(key);
  const list = Array.isArray(value) ? value : fallback;
  return list
    .map((n) => Number(n))
    .filter((n) => Number.isFinite(n) && n >= 0)
    .sort((a, b) => b - a);
}

/**
 * Reminders are keyed so the same occasion never lands twice, however often
 * generation runs. A birthday key includes the year, so it returns next year.
 */
function upsertReminder({ type, memberId = null, title, detail = null, dueDate = null, dedupeKey }) {
  const existing = queryOne('SELECT id, state FROM reminders WHERE dedupe_key = @key', { key: dedupeKey });
  if (existing) return { created: false, id: existing.id };

  const at = nowIso();
  const result = execute(
    `INSERT INTO reminders (reminder_type, member_id, title, detail, due_date, state, dedupe_key, created_at, updated_at)
     VALUES (@type, @memberId, @title, @detail, @dueDate, 'new', @dedupeKey, @at, @at)`,
    { type, memberId, title, detail, dueDate, dedupeKey, at }
  );
  return { created: true, id: Number(result.lastInsertRowid) };
}

/**
 * Builds the reminders that are due today. Safe to run repeatedly: it only
 * ever adds what is missing and never reopens something already handled.
 */
export function generateReminders({ asOf = today() } = {}) {
  const created = { birthday: 0, anniversary: 0, attendance_followup: 0 };

  const birthdayDays = reminderDays('reminders.birthday_days', [7, 3, 0]);
  const anniversaryDays = reminderDays('reminders.anniversary_days', [7, 3, 0]);
  const horizon = Math.max(...birthdayDays, ...anniversaryDays, 0);

  transaction(() => {
    for (const member of upcomingBirthdays({ withinDays: horizon, limit: 1000 })) {
      if (!birthdayDays.includes(member.inDays)) continue;
      const name = displayName(member);
      const when = member.inDays === 0 ? 'today' : `in ${member.inDays} day${member.inDays === 1 ? '' : 's'}`;
      const result = upsertReminder({
        type: 'birthday',
        memberId: member.id,
        title: `${name} has a birthday ${when}`,
        detail: `${formatDate(member.nextDate, 'long')}.`,
        dueDate: member.nextDate,
        dedupeKey: `birthday:${member.id}:${member.nextDate}:${member.inDays}`
      });
      if (result.created) created.birthday += 1;
    }

    for (const member of upcomingAnniversaries({ withinDays: horizon, limit: 1000 })) {
      if (!anniversaryDays.includes(member.inDays)) continue;
      const name = displayName(member);
      const when = member.inDays === 0 ? 'today' : `in ${member.inDays} day${member.inDays === 1 ? '' : 's'}`;
      const result = upsertReminder({
        type: 'anniversary',
        memberId: member.id,
        title: `${name} has a wedding anniversary ${when}`,
        detail: `${formatDate(member.nextDate, 'long')}.`,
        dueDate: member.nextDate,
        dedupeKey: `anniversary:${member.id}:${member.nextDate}:${member.inDays}`
      });
      if (result.created) created.anniversary += 1;
    }

  })();

  // Follow-up reminders are reconciled against the CURRENT lifecycle truth - not
  // merely added to - so a stale one (a correction removed the absences, a Friday
  // was reopened, ...) never lingers. See reconcileFollowUpReminders().
  created.attendance_followup = reconcileFollowUpReminders({ asOf, source: 'generate' }).created;

  return created;
}

// ---------------------------------------------------------------------------
// Follow-up reminder reconciliation
// ---------------------------------------------------------------------------

/**
 * A follow-up reminder belongs to one continuous EPISODE of absence. Its stored
 * key, followup:<member>:run:<sessionId>, is named after the Friday the episode
 * had reached when the reminder was created - but the key is only a label. Whether a
 * later run of absences is "the same episode" is decided by MATCHING, not by
 * recomputing the key: a reminder belongs to the current run when the Friday named
 * in its key lies inside the run's span (see `episodeSessionIds`). So an episode that
 * grows forward, or backward (an older Friday awaiting finalization is finalized as
 * Absent), or that loses a cancelled Friday at its old end, keeps its one reminder; and
 * a run that begins after a streak-breaking Present / Vacation / not-expected Friday does
 * not contain the old key's Friday, so it is a new episode and gets a new reminder even at
 * the same length. (The original key, followup:<member>:<streak>, could not tell those
 * apart. No schema is involved.)
 */
export function followUpRunKey(memberId, sessionId) {
  return `followup:${memberId}:run:${sessionId}`;
}

/**
 * Brings stored attendance_followup reminders in line with who currently
 * qualifies (followUpList - tracked, finalized, expected-roster absences).
 *
 *  - qualifying member, no reminder for their current run  -> one is created
 *    (an open reminder in the old streak-keyed format is re-keyed in place
 *    instead, so nothing is duplicated);
 *  - an unchanged qualifying run                            -> nothing (idempotent);
 *  - a reminder the SYSTEM dismissed earlier whose run qualifies again
 *                                                            -> reopened;
 *  - an open reminder that no longer matches a current run  -> dismissed by
 *    the system (handled_by stays empty, so it is distinguishable from a person
 *    dismissing it) and audited. A reminder a person completed or dismissed is
 *    never touched, and nothing is deleted.
 *
 * `memberIds` limits the pass to those members (a correction knows exactly
 * whom it changed); otherwise everyone is reconciled. Safe to run repeatedly.
 */
export function reconcileFollowUpReminders({ memberIds = null, asOf = today(), source = 'manual' } = {}) {
  const scope = memberIds ? new Set(memberIds.map(Number)) : null;
  const desired = new Map(followUpList({ limit: 100000 }).map((item) => [item.member.id, item]));
  const result = { created: 0, reopened: 0, rekeyed: 0, dismissed: 0 };
  const title = getSetting('service.friday.title') || 'Friday Service';

  transaction(() => {
    const current = new Map(); // member id -> the reminder that represents their current episode
    const sessionOfKey = (key) => Number(/^followup:\d+:run:(\d+)$/.exec(key || '')?.[1]);

    for (const [memberId, item] of desired) {
      if (scope && !scope.has(memberId)) continue;
      const episode = new Set(item.episodeSessionIds);
      const matched = query(
        `SELECT id, state, handled_by, dedupe_key FROM reminders
          WHERE reminder_type = 'attendance_followup' AND member_id = @memberId
            AND dedupe_key LIKE 'followup:%:run:%'
          ORDER BY id DESC`,
        { memberId }
      ).filter((r) => episode.has(sessionOfKey(r.dedupe_key)));
      const at = nowIso();

      const open = matched.find((r) => r.state === 'new' || r.state === 'acknowledged');
      if (open) { current.set(memberId, open.id); continue; }

      // A person already handled this episode: leave their decision alone and raise nothing new.
      const handledByPerson = matched.find((r) => r.handled_by !== null);
      if (handledByPerson) { current.set(memberId, handledByPerson.id); continue; }

      // The SYSTEM closed it earlier and the episode qualifies again: the same reminder comes back.
      const systemClosed = matched.find((r) => r.state === 'dismissed' && r.handled_by === null);
      if (systemClosed) {
        execute(
          `UPDATE reminders SET state = 'new', handled_at = NULL, detail = @detail, updated_at = @at WHERE id = @id`,
          { id: systemClosed.id, detail: item.message, at }
        );
        recordAudit({
          action: 'reminder.followup_reopened', entityType: 'reminder', entityId: systemClosed.id,
          detail: { member_id: memberId, source, reason: 'the member qualifies for follow-up again' }
        });
        current.set(memberId, systemClosed.id);
        result.reopened += 1;
        continue;
      }

      const key = followUpRunKey(memberId, item.runStart.sessionId);
      const legacy = queryOne(
        `SELECT id FROM reminders
          WHERE reminder_type = 'attendance_followup' AND member_id = @memberId
            AND state IN ('new','acknowledged') AND dedupe_key GLOB 'followup:[0-9]*:[0-9]*'
            AND dedupe_key NOT LIKE '%:run:%'
          ORDER BY id DESC LIMIT 1`,
        { memberId }
      );
      if (legacy) {
        execute('UPDATE reminders SET dedupe_key = @key, detail = @detail, updated_at = @at WHERE id = @id',
          { id: legacy.id, key, detail: item.message, at });
        current.set(memberId, legacy.id);
        result.rekeyed += 1;
        continue;
      }
      const made = upsertReminder({
        type: 'attendance_followup',
        memberId,
        title: `${displayName(item.member)} — ${title} follow-up`,
        detail: item.message,
        dueDate: asOf,
        dedupeKey: key
      });
      current.set(memberId, made.id);
      if (made.created) result.created += 1;
    }

    // Anything still open that is not the current episode's reminder is stale.
    const stillOpen = query(
      `SELECT id, member_id FROM reminders
        WHERE reminder_type = 'attendance_followup' AND state IN ('new','acknowledged')`
    );
    for (const row of stillOpen) {
      if (scope && !scope.has(row.member_id)) continue;
      if (current.get(row.member_id) === row.id) continue;
      const at = nowIso();
      execute(
        `UPDATE reminders
            SET state = 'dismissed', handled_by = NULL, handled_at = @at, updated_at = @at,
                detail = COALESCE(detail, '') || ' (Closed automatically: attendance records changed and this member no longer has a current run of absences.)'
          WHERE id = @id AND state IN ('new','acknowledged')`,
        { id: row.id, at }
      );
      recordAudit({
        action: 'reminder.followup_auto_dismissed', entityType: 'reminder', entityId: row.id,
        detail: { member_id: row.member_id, source, reason: 'no longer qualifies for follow-up' }
      });
      result.dismissed += 1;
    }
  })();
  return result;
}

/**
 * The attendance lifecycle's post-commit hook (Phase 2B) drives reconciliation:
 * finalized, not_taken, reopened, corrected, cancelled and reinstated all change
 * what "absent" means. This runs AFTER the change committed, so a failure here
 * can never undo it - it is logged and audited as a failure instead.
 */
export function reconcileForLifecycleEvent(event) {
  try {
    reconcileFollowUpReminders({
      memberIds: event.type === 'corrected' ? event.memberIds : null,
      source: `lifecycle:${event.type}`
    });
  } catch (err) {
    console.error(`[reminders] follow-up reconciliation failed after ${event.type} (session ${event.sessionId}):`, err.message);
    try {
      recordAudit({
        action: 'attendance.followup_reconciliation_failed', entityType: 'attendance_session', entityId: event.sessionId,
        result: 'failure', detail: { event: event.type, error: err.message }
      });
    } catch { /* the audit log is best-effort here; the attendance change itself is already safe */ }
  }
}

onAttendanceLifecycleChange(reconcileForLifecycleEvent);

export const REMINDER_SORT_COLUMNS = ['title', 'type', 'due', 'state'];

export function listReminders({
  state = 'open', type = null, search = '', page = 1, pageSize = 25, sort = null, direction = 'asc'
} = {}) {
  const params = {
    type,
    search: search || '',
    like: likePattern(search),
    limit: pageSize,
    offset: (page - 1) * pageSize
  };

  let stateClause = '';
  if (state === 'open') stateClause = "AND r.state IN ('new','acknowledged')";
  else if (state && state !== 'all') {
    stateClause = 'AND r.state = @state';
    params.state = state;
  }

  const where = `
    WHERE 1 = 1
      ${stateClause}
      ${hiddenBirthdayClause('r')}
      AND (@type IS NULL OR r.reminder_type = @type)
      AND (@search = '' OR r.title LIKE @like ESCAPE '\\' OR r.detail LIKE @like ESCAPE '\\')`;

  // With no explicit column sort, open/new items float to the top and the
  // soonest due date comes first — a header click switches to a plain
  // single-column sort instead.
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const orderBy = {
    title: `r.title COLLATE NOCASE ${dir}`,
    type: `r.reminder_type COLLATE NOCASE ${dir}`,
    due: `r.due_date IS NULL, r.due_date ${dir}`,
    state: `r.state COLLATE NOCASE ${dir}`
  }[sort] || `CASE r.state WHEN 'new' THEN 0 WHEN 'acknowledged' THEN 1 ELSE 2 END,
        r.due_date IS NULL, r.due_date, r.id DESC`;

  const rows = query(
    `SELECT r.*, m.member_code, m.first_name, m.last_name, m.preferred_name, m.status AS member_status,
            u.display_name AS handled_by_name
       FROM reminders r
       LEFT JOIN members m ON m.id = r.member_id
       LEFT JOIN users u ON u.id = r.handled_by
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    params
  );

  const total = queryOne(`SELECT COUNT(*) AS n FROM reminders r ${where}`, params).n;
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

export function reminderCounts() {
  const hidden = hiddenBirthdayClause('reminders');
  const rows = query(`SELECT state, COUNT(*) AS n FROM reminders WHERE 1 = 1 ${hidden} GROUP BY state`);
  const counts = { new: 0, acknowledged: 0, completed: 0, dismissed: 0 };
  for (const row of rows) counts[row.state] = row.n;
  counts.open = counts.new + counts.acknowledged;
  const byType = query(
    `SELECT reminder_type, COUNT(*) AS n FROM reminders
      WHERE state IN ('new','acknowledged') ${hidden} GROUP BY reminder_type`
  );
  counts.byType = Object.fromEntries(byType.map((r) => [r.reminder_type, r.n]));
  return counts;
}

export function getReminder(id) {
  return queryOne(
    `SELECT r.*, m.member_code, m.first_name, m.last_name, m.preferred_name
       FROM reminders r LEFT JOIN members m ON m.id = r.member_id
      WHERE r.id = @id`,
    { id }
  ) || null;
}

export function setReminderState(id, state, { userId = null } = {}) {
  if (!REMINDER_STATES.includes(state)) return null;
  const at = nowIso();
  const handled = state === 'new' ? null : userId;
  execute(
    `UPDATE reminders SET state = @state, handled_by = @handled,
            handled_at = CASE WHEN @state = 'new' THEN NULL ELSE @at END,
            updated_at = @at
      WHERE id = @id`,
    { id, state, handled, at }
  );
  return getReminder(id);
}

/** Reminders raised for one member, for the member profile. */
export function remindersForMember(memberId, { limit = 20 } = {}) {
  return query(
    `SELECT r.*, u.display_name AS handled_by_name
       FROM reminders r LEFT JOIN users u ON u.id = r.handled_by
      WHERE r.member_id = @id ${hiddenBirthdayClause('r')}
      ORDER BY r.created_at DESC
      LIMIT @limit`,
    { id: memberId, limit }
  );
}

// ---------------------------------------------------------------------------
// Internal notifications
// ---------------------------------------------------------------------------

/** Sends to every active user holding the given permission. */
export function notifyUsersWithPermission(permission, { title, body = null, link = null, category = 'general' }) {
  const users = query(
    `SELECT DISTINCT u.id
       FROM users u
       JOIN user_roles ur ON ur.user_id = u.id
       JOIN role_permissions rp ON rp.role_id = ur.role_id
       JOIN permissions p ON p.id = rp.permission_id
      WHERE p.key = @permission AND u.status = 'active'`,
    { permission }
  );
  return notifyUsers(users.map((u) => u.id), { title, body, link, category });
}

export function notifyUsers(userIds, { title, body = null, link = null, category = 'general' }) {
  const at = nowIso();
  let sent = 0;
  transaction(() => {
    for (const userId of userIds) {
      execute(
        `INSERT INTO notifications (user_id, title, body, link, category, created_at)
         VALUES (@userId, @title, @body, @link, @category, @at)`,
        { userId, title, body, link, category, at }
      );
      sent += 1;
    }
  })();
  return sent;
}

export function listNotifications(userId, { unreadOnly = false, limit = 50 } = {}) {
  return query(
    `SELECT * FROM notifications
      WHERE user_id = @userId
        AND (@unreadOnly = 0 OR read_at IS NULL)
      ORDER BY created_at DESC, id DESC
      LIMIT @limit`,
    { userId, unreadOnly: unreadOnly ? 1 : 0, limit }
  );
}

export function unreadNotificationCount(userId) {
  if (!userId) return 0;
  return queryOne(
    'SELECT COUNT(*) AS n FROM notifications WHERE user_id = @userId AND read_at IS NULL',
    { userId }
  ).n;
}

export function markNotificationRead(id, userId) {
  execute(
    'UPDATE notifications SET read_at = @at WHERE id = @id AND user_id = @userId AND read_at IS NULL',
    { id, userId, at: nowIso() }
  );
}

export function markAllNotificationsRead(userId) {
  const result = execute(
    'UPDATE notifications SET read_at = @at WHERE user_id = @userId AND read_at IS NULL',
    { userId, at: nowIso() }
  );
  return result.changes;
}

/**
 * Turns newly raised reminders into notifications for the people allowed to
 * act on them. Called after generation so nobody is told about a reminder
 * their role cannot see.
 */
export function notifyNewReminders(created) {
  const parts = [];
  if (created.birthday) parts.push(`${created.birthday} birthday`);
  if (created.anniversary) parts.push(`${created.anniversary} anniversary`);
  if (created.attendance_followup) parts.push(`${created.attendance_followup} Friday Service follow-up`);
  if (parts.length === 0) return 0;

  return notifyUsersWithPermission('reminders.view', {
    title: 'New reminders in the reminder centre',
    body: `${parts.join(', ')} reminder${parts.length === 1 && Object.values(created).reduce((a, b) => a + b, 0) === 1 ? '' : 's'} raised.`,
    link: '/reminders',
    category: 'reminder'
  });
}

/** Removes read notifications older than the retention window. */
export function pruneNotifications({ keepDays = 60 } = {}) {
  const cutoff = addDays(today(), -keepDays);
  const result = execute(
    'DELETE FROM notifications WHERE read_at IS NOT NULL AND created_at < @cutoff',
    { cutoff: `${cutoff}T00:00:00.000Z` }
  );
  return result.changes;
}
