import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern, escapeLike } from '../lib/like.js';
import { getSetting } from '../lib/settings.js';
import { nowIso, today, nextAnniversaryOf, daysUntil, isValidDate } from '../lib/dates.js';
import { phoneDigitsSql, phoneFragmentLike } from '../lib/phone.js';
import { csvCell } from '../lib/csv.js';
import { recordAudit } from '../lib/audit.js';
import { supersedeBirthdayReminders } from './birthday-reminders.js';
import { birthdayDob, birthdayYearKnown, dobAssessment } from './dob-quality.js';

/*
 * Membership statuses. The first four are the original set and behave exactly
 * as before; the rest describe how someone left, which matters in a church
 * where members regularly return home or move on to another country.
 */
export const MEMBER_STATUSES = [
  'active', 'inactive', 'pending', 'archived',
  'temporarily_away', 'returned_home', 'migrated', 'transferred', 'other',
  'attendee', 'bonafide'
];

/** Statuses that record a move to another country, which needs a destination. */
export const DEPARTURE_STATUSES = ['returned_home', 'migrated'];

/**
 * Someone in one of these statuses is not expected at the Friday Service, so
 * the consecutive-absence follow-up would only produce noise. Their records
 * stay exactly as they are.
 *
 * 'other' was missing from this list until this correction — it was already
 * excluded from DEFAULT_ROSTER_STATUSES below (not on the default sheet,
 * not part of the expected-attendance rate), but without also being here it
 * would still accumulate consecutive-absence follow-up flags, contradicting
 * its own exclusion from "expected." Inspection found no evidence 'other'
 * represents a current/regular participant — it is grouped with the
 * departure-type statuses for departure-notes eligibility in changeStatus(),
 * and it has zero rows in production (nothing has ever needed to distinguish
 * it from the more specific departure statuses) — so it belongs in this list
 * on the same footing as them.
 */
export const NOT_EXPECTED_STATUSES = [
  'temporarily_away', 'returned_home', 'migrated', 'transferred', 'archived', 'other'
];

/**
 * Who is normally expected at the Friday Service — the default roster a
 * session's recording sheet shows without anyone having to search for them.
 * This is a membership *classification* question, not a lifecycle-status
 * one: Attendee and Bonafide are both currently-engaged classifications the
 * church already uses at the same level as Active (see migration 0018 and
 * CCIQ_DECISIONS.md), not a lifecycle status below it. Pending is included
 * for the same reason a brand-new member is already expected to attend.
 * Inactive and every departure-type status (temporarily away, returned
 * home, migrated, transferred, archived, other) stay off the default
 * sheet — they remain fully searchable and recordable, just not part of the
 * population a session's sheet lists automatically. Lives here, not in
 * services/attendance.js, so both attendance.js and congregations.js can use
 * it without an import cycle (attendance.js already depends on
 * services/visitors.js, which depends on services/congregations.js).
 */
export const DEFAULT_ROSTER_STATUSES = ['active', 'pending', 'attendee', 'bonafide'];

/**
 * Everyone still currently associated with CCIQ — a distinct concept from
 * DEFAULT_ROSTER_STATUSES above, which answers a narrower question ("who is
 * physically expected this Friday"). This one answers "how many people does
 * CCIQ currently have," for a Dashboard KPI, a ministry participation
 * denominator, a congregation breakdown, and anywhere else that would
 * otherwise be tempted to reach for `status = 'active'` as a stand-in for
 * "the church."
 *
 * Deliberately DEFAULT_ROSTER_STATUSES plus `temporarily_away`: someone
 * temporarily away is still one of CCIQ's own people (see CCIQ_DECISIONS.md)
 * — they are excluded from the Friday roster specifically because that
 * roster measures who to expect *this week*, not who still belongs. Every
 * other status here (`inactive`, `returned_home`, `migrated`, `transferred`,
 * `archived`, `other`) represents someone who has genuinely left, gone quiet,
 * or moved on, and is deliberately never added to this count merely to make
 * it larger — the same restraint `NOT_EXPECTED_STATUSES` already applies to
 * the Friday roster.
 *
 * Never used for the Friday expected roster itself — that stays exactly
 * DEFAULT_ROSTER_STATUSES, unchanged.
 */
export const CURRENT_POPULATION_STATUSES = [...DEFAULT_ROSTER_STATUSES, 'temporarily_away'];

/** A page size large enough to mean "every row" for an export (SQLite LIMIT; kept an integer so it binds cleanly). */
const EXPORT_ALL = 1_000_000_000;
export const STATUS_LABELS = {
  active: 'Active',
  inactive: 'Inactive',
  pending: 'Pending',
  archived: 'Archived',
  temporarily_away: 'Temporarily away',
  returned_home: 'Returned to home country',
  migrated: 'Migrated to another country',
  transferred: 'Transferred to another church',
  other: 'Other',
  attendee: 'Attendee',
  bonafide: 'Bonafide'
};
export const GENDERS = ['male', 'female', 'unspecified'];
export const MARITAL_STATUSES = ['single', 'married', 'widowed', 'separated', 'unspecified'];

/**
 * The member's authoritative display identity — their formal first and last
 * name, never their nickname. A nickname (`preferred_name`) is a search
 * alias for *finding* a member (see searchMembersForPicker(),
 * searchPeopleForAttendance()) and, separately, its own labelled field on
 * the Member Profile — it must never substitute for the name shown
 * elsewhere, or an usher, report, or audit entry ends up identifying someone
 * by a name that is not their own. See CCIQ_DECISIONS.md.
 */
export function displayName(member) {
  if (!member) return '';
  return [member.first_name, member.last_name].filter(Boolean).join(' ');
}

export function fullName(member) {
  if (!member) return '';
  return [member.first_name, member.middle_name, member.last_name].filter(Boolean).join(' ');
}

const MAX_PICKER_RESULTS = 20;

function pickerCard(m) {
  return {
    id: m.id,
    name: fullName(m),
    memberCode: m.member_code,
    cellGroup: m.cell_group_name || null,
    photoUrl: m.photo_path
      ? `/media/members/${m.id}/photo?v=${encodeURIComponent(m.photo_updated_at || '')}`
      : null
  };
}

const PICKER_ROW_COLUMNS = `m.id, m.first_name, m.middle_name, m.last_name, m.preferred_name, m.member_code,
            m.photo_path, m.photo_updated_at, g.name AS cell_group_name`;

/**
 * The shared searchable member picker's backend — every place in the portal
 * that links to an existing member (spouse, father, mother, guardian, cell
 * group membership, and anywhere else the same picker is used) searches
 * through this one function, rather than each screen inventing its own
 * query. Deliberately status-blind (a relationship can point at any member,
 * whatever their current status) and deliberately minimal: formal name,
 * member code, and cell group only — no phone, email, or status, matching
 * what a relationship-linking control actually needs to distinguish two
 * people safely. A nickname is a search alias only; the name returned is
 * always the formal name (fullName()), so nobody is ever picked or
 * displayed under a name that is not their own.
 *
 * excludeCellGroupId and excludeIds cover the filters callers actually need
 * beyond "not this member themselves": adding someone to a cell group
 * shouldn't offer people already in that same group, and adding someone to
 * serve in a ministry (or similar roster) shouldn't offer people already on
 * it. excludeIds reaches here from the request (the widget echoes back
 * whatever roster ids the page rendered it with), so it is interpolated
 * only after every entry is coerced with Number() and passed through
 * Number.isInteger — a non-numeric value is silently dropped rather than
 * reaching the query string, the same guarantee real parameter binding
 * would give, just done by hand because the list has variable length.
 */
export function searchMembersForPicker(term, { limit = MAX_PICKER_RESULTS, excludeId = null, excludeCellGroupId = null, excludeIds = null } = {}) {
  const clean = String(term || '').trim();
  if (clean.length < 2) return [];
  const like = likePattern(clean);
  const safeExcludeIds = Array.isArray(excludeIds)
    ? excludeIds.map((n) => Number(n)).filter((n) => Number.isInteger(n))
    : [];
  const excludeIdsClause = safeExcludeIds.length ? `AND m.id NOT IN (${safeExcludeIds.join(',')})` : '';

  return query(
    `SELECT ${PICKER_ROW_COLUMNS}
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE (m.first_name LIKE @like ESCAPE '\\' OR m.middle_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\'
             OR m.preferred_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
             OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\'
             OR (m.first_name || ' ' || COALESCE(m.middle_name || ' ', '') || m.last_name) LIKE @like ESCAPE '\\')
        AND (@excludeId IS NULL OR m.id != @excludeId)
        ${excludeIdsClause}
        AND (@excludeCellGroupId IS NULL OR m.cell_group_id IS NULL OR m.cell_group_id != @excludeCellGroupId)
      ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE
      LIMIT @limit`,
    { like, limit, excludeId, excludeCellGroupId }
  ).map(pickerCard);
}

/**
 * Looks up a single member in the exact shape the member-picker partial's
 * `selected` prop expects, so an edit form can pre-populate a picker (e.g.
 * an existing spouse_member_id) without duplicating the picker's row shape.
 * Returns null if the id is empty or no longer resolves to a member —
 * a dangling link should render as "not linked", never throw.
 */
export function pickerCardFor(rawId) {
  // A forged or repeated form value (a list, text, a huge number) is simply "no one chosen", never a database error.
  const id = Number.parseInt(Array.isArray(rawId) ? rawId[0] : rawId, 10);
  if (!Number.isSafeInteger(id) || id <= 0) return null;
  const row = queryOne(
    `SELECT ${PICKER_ROW_COLUMNS}
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.id = @id`,
    { id }
  );
  return row ? pickerCard(row) : null;
}

export function nextMemberCode() {
  const prefix = getSetting('members.code_prefix') || 'CCIQ';
  const row = queryOne(
    `SELECT member_code FROM members WHERE member_code LIKE @like ESCAPE '\\' ORDER BY id DESC LIMIT 1`,
    { like: `${escapeLike(prefix)}-%` }
  );
  const lastNumber = row ? Number.parseInt(String(row.member_code).split('-').pop(), 10) : 0;
  let next = (Number.isFinite(lastNumber) ? lastNumber : 0) + 1;
  // The newest row is not always the highest number (an import can bring older, higher codes); never hand out one that is taken.
  const taken = (n) => queryOne('SELECT 1 AS x FROM members WHERE member_code = @code', { code: `${prefix}-${String(n).padStart(4, '0')}` });
  while (taken(next)) next += 1;
  return `${prefix}-${String(next).padStart(4, '0')}`;
}

/**
 * Restricts what a user may see. Cell group leaders are limited to their own
 * group; members to their own record. Enforced in SQL, not in the view.
 */
export function scopeFor(user) {
  if (!user) return { type: 'none' };
  if (user.can('members.view') && (user.can('cellgroups.view') || user.hasRole('super_admin'))) {
    return { type: 'all' };
  }
  if (user.can('members.view') && user.can('cellgroups.manage_own')) {
    return { type: 'cell_group', cellGroupIds: user.ledCellGroupIds };
  }
  if (user.memberId) return { type: 'self', memberId: user.memberId };
  return { type: 'none' };
}

export function scopeClause(scope) {
  if (scope.type === 'all') return { sql: '1=1', params: {} };
  if (scope.type === 'self') return { sql: 'm.id = @scope_member_id', params: { scope_member_id: scope.memberId } };
  if (scope.type === 'cell_group') {
    const ids = scope.cellGroupIds || [];
    if (ids.length === 0) return { sql: '1=0', params: {} };
    return { sql: `m.cell_group_id IN (${ids.map(Number).join(',')})`, params: {} };
  }
  return { sql: '1=0', params: {} };
}

export const MEMBER_SORT_COLUMNS = ['name', 'newest', 'joined', 'code', 'status', 'cell_group'];

/** Accept legacy single-status callers and repeated query parameters alike. */
export function normalizeMemberStatuses(value) {
  return [...new Set((Array.isArray(value) ? value : [value])
    .filter((status) => typeof status === 'string' && MEMBER_STATUSES.includes(status)))];
}

export function listMembers({
  scope = { type: 'none' },
  search = '',
  status = '',
  cellGroupId = null,
  destinationCountry = null,
  page = 1,
  pageSize = 20,
  sort = 'name',
  direction = 'asc'
} = {}) {
  const clause = scopeClause(scope);
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  // 'newest' has no equivalent column heading in the list (it sorts by when
  // the record was created, not anything shown), so it is reachable only
  // through the sort <select>, always most-recent-first, and ignores
  // direction — a header click never produces this value.
  const orderBy = sort === 'newest'
    ? 'm.created_at DESC, m.id DESC'
    : ({
        name: `m.last_name COLLATE NOCASE ${dir}, m.first_name COLLATE NOCASE ${dir}`,
        joined: `m.date_joined ${dir}`,
        code: `m.member_code ${dir}`,
        status: `m.status ${dir}`,
        cell_group: `g.name COLLATE NOCASE ${dir}`
      }[sort] || `m.last_name COLLATE NOCASE ${dir}, m.first_name COLLATE NOCASE ${dir}`) + `, m.id ${dir}`;

  const selectedStatuses = normalizeMemberStatuses(status);
  const statusParams = Object.fromEntries(selectedStatuses.map((value, index) => [`member_status_${index}`, value]));
  const statusClause = selectedStatuses.length
    ? `m.status IN (${Object.keys(statusParams).map((key) => `@${key}`).join(', ')})`
    : '1=1';
  const where = `
    WHERE ${clause.sql}
      AND ${statusClause}
      AND (@cellGroupId IS NULL OR m.cell_group_id = @cellGroupId)
      AND (@destinationCountry IS NULL OR m.destination_country = @destinationCountry)
      AND (@search = '' OR
           m.first_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\' OR
           m.preferred_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\' OR
           m.email LIKE @like ESCAPE '\\' OR m.phone LIKE @like ESCAPE '\\' OR (@phoneLike IS NOT NULL AND ${phoneDigitsSql('m.phone')} LIKE @phoneLike) OR m.middle_name LIKE @like ESCAPE '\\' OR
           (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\' OR
           (m.first_name || ' ' || COALESCE(m.middle_name || ' ', '') || m.last_name) LIKE @like ESCAPE '\\')`;

  const params = {
    ...clause.params,
    ...statusParams,
    cellGroupId: cellGroupId || null,
    destinationCountry: destinationCountry || null,
    search,
    like: likePattern(search),
    phoneLike: phoneFragmentLike(search)
  };

  const total = queryOne(`SELECT COUNT(*) AS n FROM members m ${where}`, params).n;
  const rows = query(
    `SELECT m.*, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    { ...params, limit: pageSize, offset: (page - 1) * pageSize }
  );

  return { rows, total, page, pageSize, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

export function getMember(id, scope = { type: 'all' }) {
  const clause = scopeClause(scope);
  return queryOne(
    `SELECT m.*, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.id = @id AND ${clause.sql}`,
    { id, ...clause.params }
  ) || null;
}

export function statusCounts(scope = { type: 'all' }) {
  const clause = scopeClause(scope);
  const rows = query(
    `SELECT status, COUNT(*) AS n FROM members m WHERE ${clause.sql} GROUP BY status`,
    clause.params
  );
  const counts = { active: 0, inactive: 0, pending: 0, archived: 0, total: 0 };
  for (const row of rows) {
    counts[row.status] = row.n;
    counts.total += row.n;
  }
  return counts;
}

/**
 * How many people are currently associated with CCIQ (see
 * CURRENT_POPULATION_STATUSES) — the number a Dashboard KPI or a
 * participation denominator should use, not `counts.active` alone.
 * `counts.total` (from statusCounts()) remains the separate, larger "every
 * record ever, including departed/historical" figure.
 */
export function currentPopulationCount(scope = { type: 'all' }) {
  const counts = statusCounts(scope);
  return CURRENT_POPULATION_STATUSES.reduce((sum, status) => sum + (counts[status] || 0), 0);
}

export function statusHistory(memberId) {
  return query(
    `SELECT h.*, u.display_name AS changed_by_name
       FROM member_status_history h
       LEFT JOIN users u ON u.id = h.changed_by
      WHERE h.member_id = @id
      ORDER BY h.changed_at DESC`,
    { id: memberId }
  );
}

const WRITABLE_FIELDS = [
  // Identity
  'first_name', 'middle_name', 'last_name', 'preferred_name', 'date_of_birth',
  'gender', 'marital_status',
  // Spouse and family. spouse_member_id is deliberately NOT here — a spouse
  // link is symmetrical and needs a reciprocal write on the other member's
  // own row, which the generic per-field UPDATE below cannot do. See
  // setSpouse() and its callers in routes/members.js.
  'spouse_name', 'anniversary_date',
  'father_name', 'mother_name', 'father_member_id', 'mother_member_id', 'parents_attend_cciq',
  'guardian_relation',
  // Contact, here and at home
  'phone', 'email', 'address', 'home_country', 'home_country_address',
  // Work in Qatar
  'company', 'occupation',
  // Church life
  'date_joined', 'cell_group_id', 'is_baptized', 'baptism_date', 'baptism_place',
  // Emergency and notes
  'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation', 'notes'
];

/** Written only by the status change, never by the ordinary edit form. */
const DEPARTURE_FIELDS = ['destination_country', 'departure_notes'];

/** How the parents of a young member relate to the church. */
export const PARENTS_ATTEND_OPTIONS = ['both', 'one', 'neither', 'unknown'];
export const PARENTS_ATTEND_LABELS = {
  both: 'Both parents attend CCIQ',
  one: 'One parent attends CCIQ',
  neither: 'Neither parent attends CCIQ',
  unknown: 'Not known'
};

export function createMember(data, { userId = null, status = 'pending', reason = null } = {}) {
  /*
   * Two administrators adding a member at the same moment would otherwise
   * compute the same member ID and one insert would fail on the unique
   * constraint. The constraint stays as the guarantee; this simply takes the
   * next free code and tries again.
   */
  let attempt = 0;
  for (;;) {
    try {
      return insertMember(data, { userId, status, reason });
    } catch (err) {
      attempt += 1;
      if (attempt >= 5 || !String(err.message).includes('UNIQUE') || data.member_code) throw err;
    }
  }
}

/**
 * Fields that must always hold a value rather than being left null, so an
 * unticked checkbox is stored as "no" instead of failing the constraint.
 */
const BOOLEAN_FIELDS = new Set(['is_baptized']);

function normaliseField(field, value) {
  if (!BOOLEAN_FIELDS.has(field)) return value ?? null;
  return value === 1 || value === '1' || value === true || value === 'on' ? 1 : 0;
}

/**
 * ONE authoritative identity per relative. A parent who is linked to a CCIQ member record IS that
 * member: their name is always shown from the linked record, so a second, typed name is dropped
 * rather than kept beside it where it could contradict it. A relative who is not a member has only
 * the typed name. (The spouse link is symmetrical and handled by setSpouse(), which applies the
 * same rule.) Existing typed names for NON-members are never touched.
 */
function applyRelationshipIdentity(payload) {
  if (payload.father_member_id) payload.father_name = null;
  if (payload.mother_member_id) payload.mother_name = null;
  return payload;
}

function insertMember(data, { userId = null, status = 'pending', reason = null } = {}) {
  const at = nowIso();
  const code = data.member_code || nextMemberCode();
  const payload = { member_code: code, status, created_at: at, updated_at: at, created_by: userId, updated_by: userId };
  for (const field of WRITABLE_FIELDS) payload[field] = normaliseField(field, data[field]);
  applyRelationshipIdentity(payload);

  const columns = Object.keys(payload);
  const memberId = transaction(() => {
    const result = execute(
      `INSERT INTO members (${columns.join(', ')})
       VALUES (${columns.map((c) => `@${c}`).join(', ')})`,
      payload
    );
    const id = result.lastInsertRowid;
    execute(
      `INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at, changed_by)
       VALUES (@id, NULL, @status, @reason, @at, @by)`,
      { id, status, reason: reason || 'Record created', at, by: userId }
    );
    return id;
  })();

  return getMember(memberId);
}

export function updateMember(id, data, { userId = null, dobReviewAudited = false } = {}) {
  const payload = { id, updated_at: nowIso(), updated_by: userId };
  for (const field of WRITABLE_FIELDS) payload[field] = normaliseField(field, data[field]);
  applyRelationshipIdentity(payload);
  /*
   * A person's date-of-birth review decision (members.dob_review) is about the date that was on the record when they made it. Change the date and the decision no longer applies, so it is
   * cleared in the same write (the automatic checks decide again until someone reviews the new date). The Date of birth review screen records its own audit entry; any other edit gets one here.
   */
  const before = queryOne('SELECT date_of_birth, dob_review FROM members WHERE id = @id', { id });
  const clearsReview = Boolean(before && before.dob_review && (before.date_of_birth || null) !== (payload.date_of_birth || null));
  execute(
    `UPDATE members SET
       ${WRITABLE_FIELDS.map((f) => `${f} = @${f}`).join(', ')},
       ${clearsReview ? 'dob_review = NULL, dob_reviewed_at = NULL, dob_reviewed_by = NULL,' : ''}
       updated_at = @updated_at, updated_by = @updated_by
     WHERE id = @id`,
    payload
  );
  // A corrected date of birth makes an open birthday reminder about the old one wrong: it is dismissed (kept, audited), never deleted.
  if (before && before.date_of_birth && (before.date_of_birth || null) !== (payload.date_of_birth || null)) {
    supersedeBirthdayReminders(id, { userId, previousDob: before.date_of_birth, newDob: payload.date_of_birth || null });
  }
  if (clearsReview && !dobReviewAudited) {
    recordAudit({
      userId, action: 'member.dob_review_reset', entityType: 'member', entityId: id,
      detail: { previous_dob: before.date_of_birth || null, new_dob: payload.date_of_birth || null, previous_review: before.dob_review, new_review: null, note: 'The date of birth was edited, so the earlier review decision no longer applies.' }
    });
  }
  return getMember(id);
}

/**
 * Is `candidateId` already an ancestor of `memberId` via the explicit
 * father_member_id/mother_member_id links? Used before saving a new
 * father/mother link, to refuse one that would close a loop (e.g. setting
 * your own grandchild as your father) — the explicit link is the only
 * signal used; nothing here is inferred from name, age or gender. Bounded
 * to 200 members visited so a pre-existing bad cycle in the data can never
 * turn this into an infinite loop.
 */
export function isAncestor(candidateId, memberId) {
  const queue = [memberId];
  const visited = new Set();
  while (queue.length && visited.size < 200) {
    const current = queue.shift();
    if (visited.has(current)) continue;
    visited.add(current);
    const row = queryOne('SELECT father_member_id, mother_member_id FROM members WHERE id = @id', { id: current });
    if (!row) continue;
    if (row.father_member_id === candidateId || row.mother_member_id === candidateId) return true;
    if (row.father_member_id) queue.push(row.father_member_id);
    if (row.mother_member_id) queue.push(row.mother_member_id);
  }
  return false;
}

/**
 * Spouse is symmetrical: setting A's spouse to B means B's spouse is A, and
 * an administrator should only ever have to record that once. This is the
 * one relationship on `members` that needs a write to the *other* row, so
 * it lives in its own function rather than the generic field loop above.
 *
 * - Clearing (newSpouseId falsy) removes the link on both sides, but only
 *   clears the other member's spouse_member_id if it still points back
 *   here — never overwrites a link that has since changed to someone else.
 * - Setting to someone already recorded as married to a different member is
 *   a conflict this refuses outright rather than silently replacing —
 *   { ok: false, reason: 'conflict' } — so a real conflict always reaches a
 *   person to resolve deliberately, per the explicit instruction not to
 *   silently overwrite one.
 * - Re-saving the same value heals a one-way link if the reciprocal side
 *   was never set (the exact shape existing production data can be in).
 */
export function setSpouse(memberId, newSpouseId, { userId = null } = {}) {
  const id = Number(memberId);
  const nextId = newSpouseId ? Number(newSpouseId) : null;
  if (nextId === id) return { ok: false, reason: 'self' };

  return transaction(() => {
    const member = queryOne('SELECT id, spouse_member_id FROM members WHERE id = @id', { id });
    if (!member) return { ok: false, reason: 'not_found' };

    const at = nowIso();
    const previousSpouseId = member.spouse_member_id || null;

    if (!nextId) {
      if (previousSpouseId) {
        execute(
          `UPDATE members SET spouse_member_id = NULL, updated_at = @at, updated_by = @by
            WHERE id = @prev AND spouse_member_id = @id`,
          { prev: previousSpouseId, id, at, by: userId }
        );
      }
      execute('UPDATE members SET spouse_member_id = NULL, updated_at = @at, updated_by = @by WHERE id = @id',
        { id, at, by: userId });
      return { ok: true };
    }

    const target = queryOne('SELECT id, spouse_member_id FROM members WHERE id = @id', { id: nextId });
    if (!target) return { ok: false, reason: 'not_found' };
    if (target.spouse_member_id && target.spouse_member_id !== id) {
      return { ok: false, reason: 'conflict', conflictMemberId: target.spouse_member_id };
    }

    if (previousSpouseId && previousSpouseId !== nextId) {
      execute(
        `UPDATE members SET spouse_member_id = NULL, updated_at = @at, updated_by = @by
          WHERE id = @prev AND spouse_member_id = @id`,
        { prev: previousSpouseId, id, at, by: userId }
      );
    }

    // A linked spouse IS that member: the typed spouse name on either record is dropped so it can
    // never sit beside (and contradict) the linked identity.
    execute('UPDATE members SET spouse_member_id = @spouse, spouse_name = NULL, updated_at = @at, updated_by = @by WHERE id = @id',
      { id, spouse: nextId, at, by: userId });
    execute('UPDATE members SET spouse_member_id = @spouse, spouse_name = NULL, updated_at = @at, updated_by = @by WHERE id = @id',
      { id: nextId, spouse: id, at, by: userId });

    return { ok: true };
  })();
}

/** Status changes are appended to history; the previous status is preserved. */
export function changeStatus(id, newStatus, {
  userId = null, reason = null, destinationCountry = null, departureNotes = null
} = {}) {
  const member = queryOne(
    'SELECT status, destination_country, departure_notes FROM members WHERE id = @id', { id }
  );
  if (!member) return null;

  // Destination country and departure notes apply to exactly the same two
  // statuses — a genuine relocation (returned home, or migrated abroad).
  // Every other status, including Transferred and Other, is not a
  // relocation in the sense these two fields describe, and Temporarily Away
  // is a short-term absence, not a move at all — none of them carry either
  // field. Submitting a value for either field alongside any other status is
  // ignored here regardless of what the client sent, so a value entered
  // while "Migrated" was selected can never be saved under a later status
  // change to something else in the same request.
  const movesAbroad = DEPARTURE_STATUSES.includes(newStatus);
  const country = movesAbroad ? (destinationCountry || null) : null;
  const notes = movesAbroad ? (departureNotes || null) : null;

  const unchanged = member.status === newStatus
    && (member.destination_country || null) === country
    && (member.departure_notes || null) === notes;
  if (unchanged) return { previous: member.status, next: newStatus, member: getMember(id) };

  const at = nowIso();
  transaction(() => {
    /*
     * Only the status and its departure details change. Attendance, cell group
     * history, activities and documents are untouched: someone who leaves
     * Qatar stays in the records as part of the church's history.
     */
    execute(
      `UPDATE members SET status = @status, destination_country = @country,
              departure_notes = @notes, updated_at = @at, updated_by = @by
        WHERE id = @id`,
      { id, status: newStatus, country, notes, at, by: userId }
    );
    execute(
      `INSERT INTO member_status_history (member_id, previous_status, new_status, reason, changed_at, changed_by)
       VALUES (@id, @previous, @new, @reason, @at, @by)`,
      {
        id,
        previous: member.status,
        new: newStatus,
        reason: [reason, country ? `Destination: ${country}` : null].filter(Boolean).join(' · ') || null,
        at,
        by: userId
      }
    );
  })();
  return { previous: member.status, next: newStatus, member: getMember(id) };
}

/** How a status reads on screen, with the destination where there is one. */
export function describeStatus(member) {
  if (!member) return { label: 'Unknown', detail: null, key: null };
  return {
    key: member.status,
    label: STATUS_LABELS[member.status] || member.status,
    detail: DEPARTURE_STATUSES.includes(member.status) ? member.destination_country || null : null,
    notes: member.departure_notes || null,
    expected: !NOT_EXPECTED_STATUSES.includes(member.status)
  };
}

/** Destination countries actually in use, for the directory filter. */
export function destinationCountries() {
  return query(
    `SELECT destination_country AS country, COUNT(*) AS members
       FROM members
      WHERE destination_country IS NOT NULL AND TRIM(destination_country) != ''
      GROUP BY destination_country
      ORDER BY destination_country COLLATE NOCASE`
  );
}

// --- Configurable extra fields -------------------------------------------

export function customFields({ activeOnly = true } = {}) {
  return query(
    `SELECT * FROM member_custom_fields
      WHERE (@activeOnly = 0 OR is_active = 1)
      ORDER BY sort_order, label`,
    { activeOnly: activeOnly ? 1 : 0 }
  ).map((field) => ({ ...field, choices: field.options ? field.options.split('|').map((s) => s.trim()).filter(Boolean) : [] }));
}

export function customFieldValues(memberId, { audience = 'staff' } = {}) {
  const rows = query(
    `SELECT f.id, f.field_key, f.label, f.field_type, f.visibility, v.value
       FROM member_custom_fields f
       LEFT JOIN member_field_values v ON v.field_id = f.id AND v.member_id = @id
      WHERE f.is_active = 1
      ORDER BY f.sort_order, f.label`,
    { id: memberId }
  );
  // A field marked for administrators is never shown to the member themselves.
  const allowed = { member: ['member'], leader: ['member', 'leader'], staff: ['member', 'leader', 'staff'] };
  const visible = allowed[audience] || allowed.staff;
  return rows.filter((row) => visible.includes(row.visibility || 'staff'));
}

export function saveCustomFieldValues(memberId, values = {}) {
  const at = nowIso();
  const fields = customFields();
  transaction(() => {
    for (const field of fields) {
      const value = values[`custom_${field.field_key}`];
      if (value === undefined) continue;
      execute(
        `INSERT INTO member_field_values (member_id, field_id, value, updated_at)
         VALUES (@member_id, @field_id, @value, @at)
         ON CONFLICT(member_id, field_id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
        { member_id: memberId, field_id: field.id, value: value === '' ? null : String(value).slice(0, 2000), at }
      );
    }
  })();
}

export function addCustomField({ label, fieldKey, fieldType = 'text', options = null, visibility = 'staff', helpText = null }) {
  return execute(
    `INSERT INTO member_custom_fields (field_key, label, field_type, options, help_text, visibility, is_active, sort_order, created_at)
     VALUES (@key, @label, @type, @options, @help, @visibility, 1,
             (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM member_custom_fields), @at)`,
    { key: fieldKey, label, type: fieldType, options, help: helpText, visibility, at: nowIso() }
  );
}

export function setCustomFieldActive(id, active) {
  execute('UPDATE member_custom_fields SET is_active = @active WHERE id = @id', { id, active: active ? 1 : 0 });
}

// --- Dates of interest ----------------------------------------------------

export function upcomingBirthdays({ withinDays = 30, limit = 20 } = {}) {
  const excluded = NOT_EXPECTED_STATUSES.map((_, i) => `@x${i}`).join(',');
  const rows = query(
    `SELECT m.id, m.member_code, m.first_name, m.last_name, m.preferred_name, m.date_of_birth,
            g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.status NOT IN (${excluded}) AND m.date_of_birth IS NOT NULL`,
    Object.fromEntries(NOT_EXPECTED_STATUSES.map((s, i) => [`x${i}`, s]))
  );
  // A date of birth that is invalid or needs verification (dob-quality.js) is never listed: no birthday, no reminder, no dashboard greeting, no age. A birthday whose month and day a person
  // confirmed with the year unknown IS listed, with no "turning" age.
  return rows
    .filter((m) => birthdayDob(m))
    .map((m) => {
      const next = nextAnniversaryOf(m.date_of_birth, today());
      const turningAge = next && birthdayYearKnown(m) ? Number(next.slice(0, 4)) - Number(m.date_of_birth.slice(0, 4)) : null;
      return { ...m, nextDate: next, inDays: next ? daysUntil(next) : null, turningAge };
    })
    .filter((m) => m.inDays !== null && m.inDays <= withinDays)
    .sort((a, b) => a.inDays - b.inDays)
    .slice(0, limit);
}

export function upcomingAnniversaries({ withinDays = 30, limit = 20 } = {}) {
  const excluded = NOT_EXPECTED_STATUSES.map((_, i) => `@x${i}`).join(',');
  const rows = query(
    `SELECT m.id, m.member_code, m.first_name, m.last_name, m.preferred_name, m.anniversary_date,
            g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.status NOT IN (${excluded}) AND m.anniversary_date IS NOT NULL`,
    Object.fromEntries(NOT_EXPECTED_STATUSES.map((s, i) => [`x${i}`, s]))
  );
  return rows
    .map((m) => {
      const next = nextAnniversaryOf(m.anniversary_date, today());
      return { ...m, nextDate: next, inDays: next ? daysUntil(next) : null };
    })
    .filter((m) => m.inDays !== null && m.inDays <= withinDays)
    .sort((a, b) => a.inDays - b.inDays)
    .slice(0, limit);
}

// --- Photo -----------------------------------------------------------------

export function setMemberPhoto(memberId, photoPath, { userId = null } = {}) {
  const at = nowIso();
  execute(
    `UPDATE members SET photo_path = @path, photo_updated_at = @at, updated_at = @at, updated_by = @by
      WHERE id = @id`,
    { id: memberId, path: photoPath, at, by: userId }
  );
  return getMember(memberId);
}

// --- Member self-service ---------------------------------------------------

/**
 * The only fields a member may change on their own record. Anything affecting
 * membership, status, cell group or notes stays with administrators.
 */
export const SELF_EDITABLE_FIELDS = [
  'preferred_name', 'phone', 'email', 'address',
  'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation'
];

export function updateOwnDetails(memberId, data, { userId = null } = {}) {
  const payload = { id: memberId, at: nowIso(), by: userId };
  for (const field of SELF_EDITABLE_FIELDS) payload[field] = data[field] ?? null;
  execute(
    `UPDATE members SET
       ${SELF_EDITABLE_FIELDS.map((f) => `${f} = @${f}`).join(', ')},
       updated_at = @at, updated_by = @by
     WHERE id = @id`,
    payload
  );
  return getMember(memberId);
}

// --- Combined member history ----------------------------------------------

/**
 * One timeline per member, drawn from the records that already exist rather
 * than a separate log: the record itself, status changes, cell group moves,
 * recorded Friday Service attendance, and audited administrative edits.
 */
export function memberTimeline(memberId, { attendanceLimit = 10, auditLimit = 20 } = {}) {
  const member = queryOne(
    'SELECT id, created_at, date_joined, member_code FROM members WHERE id = @id',
    { id: memberId }
  );
  if (!member) return [];

  const events = [];

  events.push({
    at: member.created_at,
    kind: 'record',
    title: 'Member record created',
    detail: `Member ID ${member.member_code}`
  });

  if (member.date_joined) {
    events.push({
      at: `${member.date_joined}T00:00:00.000Z`,
      kind: 'record',
      title: 'Joined the church',
      detail: null,
      dateOnly: member.date_joined
    });
  }

  for (const entry of statusHistory(memberId)) {
    events.push({
      at: entry.changed_at,
      kind: 'status',
      title: entry.previous_status
        ? `Status changed from ${STATUS_LABELS[entry.previous_status]} to ${STATUS_LABELS[entry.new_status]}`
        : `Status set to ${STATUS_LABELS[entry.new_status]}`,
      detail: entry.reason,
      by: entry.changed_by_name
    });
  }

  const memberships = query(
    `SELECT gm.joined_at, gm.left_at, gm.role_in_group, g.name AS group_name
       FROM cell_group_members gm JOIN cell_groups g ON g.id = gm.cell_group_id
      WHERE gm.member_id = @id`,
    { id: memberId }
  );
  for (const m of memberships) {
    events.push({
      at: m.joined_at,
      kind: 'group',
      title: `Joined ${m.group_name}`,
      detail: m.role_in_group === 'member' ? null : `As ${m.role_in_group}`
    });
    if (m.left_at) {
      events.push({ at: m.left_at, kind: 'group', title: `Left ${m.group_name}`, detail: null });
    }
  }

  const attendance = query(
    `SELECT r.status, r.recorded_at, s.service_date, s.title, s.service_type
       FROM attendance_records r
       JOIN attendance_sessions s ON s.id = r.session_id
      WHERE r.member_id = @id
      ORDER BY s.service_date DESC
      LIMIT @limit`,
    { id: memberId, limit: attendanceLimit }
  );
  for (const record of attendance) {
    events.push({
      at: record.recorded_at,
      kind: 'attendance',
      title: `${record.title || 'Service'} — ${record.status}`,
      detail: null,
      dateOnly: record.service_date
    });
  }

  const audits = query(
    `SELECT a.action, a.created_at, a.detail, u.display_name AS user_name
       FROM audit_logs a
       LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'member' AND a.entity_id = @id
        AND a.action IN ('member.updated', 'member.photo_updated', 'member.self_updated', 'member.group_changed', 'member.dob_review', 'member.dob_corrected', 'member.dob_review_reset')
      ORDER BY a.created_at DESC
      LIMIT @limit`,
    { id: String(memberId), limit: auditLimit }
  );
  const AUDIT_TITLES = {
    'member.updated': 'Record updated',
    'member.photo_updated': 'Profile photo updated',
    'member.self_updated': 'Member updated their own details',
    'member.group_changed': 'Cell group changed',
    'member.dob_review': 'Date of birth review decision',
    'member.dob_corrected': 'Date of birth corrected',
    'member.dob_review_reset': 'Date of birth review cleared (the date was edited)'
  };
  for (const entry of audits) {
    events.push({
      at: entry.created_at,
      kind: 'edit',
      title: AUDIT_TITLES[entry.action] || entry.action,
      detail: null,
      by: entry.user_name
    });
  }

  return events
    .filter((e) => e.at)
    .sort((a, b) => String(b.at).localeCompare(String(a.at)));
}

// --- Export ----------------------------------------------------------------

/** The export is the record, so a date that needs verification is exported as stored; a birthday whose year a person said is NOT known is exported without the stored (placeholder) year. */
function csvDateOfBirth(m) {
  const a = m.date_of_birth ? dobAssessment(m.id) : null;
  return a && a.state === 'month_day_only' ? `${m.date_of_birth.slice(5)} (year not known)` : m.date_of_birth;
}

export function membersCsv({ scope = { type: 'none' }, includeContact = false, filters = {} } = {}) {
  // Every matching member, not one page of them and not a round-number cap: the export is the record.
  const { rows } = listMembers({ ...filters, scope, page: 1, pageSize: EXPORT_ALL });
  const headers = ['Member ID', 'First name', 'Middle name', 'Last name', 'Preferred name',
    'Status', 'Cell group', 'Date of birth', 'Anniversary', 'Date joined'];
  if (includeContact) headers.push('Contact number', 'Email', 'Address');

  const lines = [headers.map(csvCell).join(',')];
  for (const m of rows) {
    const cells = [
      m.member_code, m.first_name, m.middle_name, m.last_name, m.preferred_name,
      STATUS_LABELS[m.status] || m.status, m.cell_group_name, csvDateOfBirth(m),
      m.anniversary_date, m.date_joined
    ];
    if (includeContact) cells.push(m.phone, m.email, m.address);
    lines.push(cells.map(csvCell).join(','));
  }
  return { csv: `${lines.join('\r\n')}\r\n`, count: rows.length };
}

/**
 * Birthdays and wedding anniversaries falling inside a date range.
 *
 * These recur every year, so only the day and month matter. A range that
 * crosses the new year — 15 December to 15 January, say — is handled by
 * checking whether each occasion falls inside the span rather than comparing
 * whole dates.
 *
 * A stored date that is not a real calendar date (an imported "1976-26-07", day and month swapped) can never be an occasion: a text comparison would
 * otherwise place month 26 between October and January, and the report would fail on it. Such a date is skipped and COUNTED (`unusable`) so the report
 * can say that some records need correcting rather than silently leaving people out.
 */
export function occasionsInRange({ from, to, statuses = ['active'] } = {}) {
  const rows = query(
    `SELECT m.*, g.name AS cell_group_name,
            sp.first_name AS spouse_first, sp.middle_name AS spouse_middle, sp.last_name AS spouse_last
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
       LEFT JOIN members sp ON sp.id = m.spouse_member_id
      WHERE m.status IN (${statuses.map((_, i) => `@s${i}`).join(',')})
        AND (m.date_of_birth IS NOT NULL OR m.anniversary_date IS NOT NULL)`,
    Object.fromEntries(statuses.map((s, i) => [`s${i}`, s]))
  );

  const startYear = Number(from.slice(0, 4));
  const spansNewYear = to.slice(0, 4) > from.slice(0, 4);

  /** The date this occasion next falls on within the range, or null. */
  const unusable = { birthdays: 0, anniversaries: 0 };
  const unverified = { birthdays: 0 }; // real dates of birth that need verification: left out, and counted so the report can say so
  const occurrenceIn = (dateStr, kind) => {
    if (!dateStr) return null;
    if (!isValidDate(dateStr)) { unusable[kind] += 1; return null; }
    const monthDay = dateStr.slice(5);
    if (monthDay === '02-29') {
      // 29 February exists only in a leap year; it is reported on 28 February
      // in other years so it is never quietly skipped.
      const inLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
      for (const year of [startYear, startYear + 1]) {
        const candidate = `${year}-${inLeap(year) ? '02-29' : '02-28'}`;
        if (candidate >= from && candidate <= to) return candidate;
      }
      return null;
    }

    for (const year of [startYear, startYear + 1]) {
      const candidate = `${year}-${monthDay}`;
      if (candidate >= from && candidate <= to) return candidate;
    }
    return null;
  };

  const yearsAt = (dateStr, occurrence) => {
    if (!dateStr || !occurrence) return null;
    const years = Number(occurrence.slice(0, 4)) - Number(dateStr.slice(0, 4));
    return years >= 0 ? years : null;
  };

  const birthdays = [];
  const anniversaries = [];

  for (const member of rows) {
    const dobState = member.date_of_birth ? dobAssessment(member.id) : null;
    if (dobState && dobState.state === 'unverified') unverified.birthdays += 1;
    const birthday = dobState && dobState.state === 'unverified' ? null : occurrenceIn(member.date_of_birth, 'birthdays');
    if (birthday) {
      const yearKnown = !(dobState && dobState.state === 'month_day_only');
      birthdays.push({
        member,
        date: birthday,
        // A month-and-day-only birthday never carries the stored year, so no age can be worked out from it downstream.
        original: yearKnown ? member.date_of_birth : null,
        turning: yearKnown ? yearsAt(member.date_of_birth, birthday) : null,
        yearKnown
      });
    }

    // Only a married member's wedding date is reported as an anniversary.
    const anniversary = occurrenceIn(member.anniversary_date, 'anniversaries');
    if (anniversary) {
      anniversaries.push({
        member,
        date: anniversary,
        original: member.anniversary_date,
        years: yearsAt(member.anniversary_date, anniversary),
        // A linked spouse's name comes from their own record; a typed name is only for a non-member.
        spouse: member.spouse_first
          ? fullName({ first_name: member.spouse_first, middle_name: member.spouse_middle, last_name: member.spouse_last })
          : member.spouse_name
      });
    }
  }

  const byDate = (a, b) => a.date.localeCompare(b.date);
  return {
    from,
    to,
    spansNewYear,
    unusable,
    unverified,
    birthdays: birthdays.sort(byDate),
    anniversaries: anniversaries.sort(byDate)
  };
}

// ===========================================================================
// Duplicate detection
// ===========================================================================
//
// A warning system, not a gate: two real people can share a name, so nothing
// here ever blocks a save on its own — it only surfaces a possible match for
// a person to look at and decide. Matching is a small, explainable points
// score built from name/DOB/contact agreement, not a fuzzy/AI similarity
// search, so every warning can be explained in plain language (see
// `reasons` below) and the threshold behaviour can be reasoned about and
// tested exactly, the same way the rest of this codebase favours explicit,
// traceable rules over an opaque one.

/** Case, spacing and punctuation are not identity — this only touches those. */
function normalizeNameText(value) {
  return String(value || '')
    .toUpperCase()
    .replace(/\./g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizePhone(value) {
  return String(value || '').replace(/\D/g, '');
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

/**
 * A middle name is the field most likely to be recorded inconsistently —
 * an initial one time, spelled out another, left blank a third — so it
 * gets its own lenient comparison rather than a flat equal/not-equal.
 * Returns a point contribution, never a hard pass/fail on its own.
 */
function compareMiddleNames(a, b) {
  const na = normalizeNameText(a);
  const nb = normalizeNameText(b);
  if (!na && !nb) return { points: 0, note: null };
  if (!na || !nb) return { points: 0.5, note: 'one record has no middle name on file' };
  if (na === nb) return { points: 2, note: 'middle name matches' };
  const initialOf = (s) => s.charAt(0);
  const isInitialMatch = (na.length === 1 && initialOf(nb) === na) || (nb.length === 1 && initialOf(na) === nb);
  if (isInitialMatch) return { points: 1.5, note: 'middle initial matches the other record’s middle name' };
  return { points: -1, note: 'middle names on file do not match' };
}

/**
 * Scores one existing member against a candidate's identity fields. Higher
 * is a stronger possible match; see findPossibleDuplicates() for the
 * thresholds this feeds into. Every contribution is named in `reasons` so a
 * warning can always say exactly why it was raised.
 */
function scoreDuplicateCandidate(candidate, existing) {
  let points = 0;
  const reasons = [];

  const firstA = normalizeNameText(candidate.first_name);
  const firstB = normalizeNameText(existing.first_name);
  const lastA = normalizeNameText(candidate.last_name);
  const lastB = normalizeNameText(existing.last_name);

  if (!lastA || lastA !== lastB) return { points: -Infinity, reasons: [] };
  points += 3;
  reasons.push('last name matches');

  if (firstA && firstA === firstB) {
    points += 3;
    reasons.push('first name matches');
  } else {
    // A last-name-only match is exactly the case explicitly called out as
    // never being enough on its own — stop scoring this pair here.
    return { points: -Infinity, reasons: [] };
  }

  const middle = compareMiddleNames(candidate.middle_name, existing.middle_name);
  points += middle.points;
  if (middle.note) reasons.push(middle.note);

  const dobA = candidate.date_of_birth || null;
  const dobB = existing.date_of_birth || null;
  if (dobA && dobB) {
    if (dobA === dobB) {
      points += 4;
      reasons.push('date of birth matches');
    } else {
      // Same name, different recorded birth date: the explicit instruction
      // is that this must never be treated as an automatic match. Contact
      // signals below can still raise a low-confidence warning, but the
      // strong name-based score is discarded here rather than merely
      // reduced, so two people who happen to share a name never rank as a
      // strong duplicate purely because of it.
      points -= 6;
      reasons.push('recorded dates of birth are different');
    }
  }

  const phoneA = normalizePhone(candidate.phone);
  const phoneB = normalizePhone(existing.phone);
  if (phoneA && phoneA.length >= 7 && phoneA === phoneB) {
    points += 1;
    reasons.push('phone number matches');
  }

  const emailA = normalizeEmail(candidate.email);
  const emailB = normalizeEmail(existing.email);
  if (emailA && emailA === emailB) {
    points += 1;
    reasons.push('email address matches');
  }

  return { points, reasons };
}

export const DUPLICATE_MATCH_LEVELS = {
  STRONG: 'strong',
  MODERATE: 'moderate'
};

const STRONG_MATCH_THRESHOLD = 8;
const MODERATE_MATCH_THRESHOLD = 5;

/**
 * Finds existing members who could plausibly be the same person as
 * `candidate` (an object with first_name/middle_name/last_name/
 * date_of_birth/phone/email — exactly the fields a member form already
 * collects). Never used to block a save; only to warn. `excludeId` leaves
 * out the record currently being edited, so editing a member never flags
 * them against their own unchanged data.
 */
export function findPossibleDuplicates(candidate, { excludeId = null, limit = 5 } = {}) {
  const lastName = normalizeNameText(candidate.last_name);
  if (!lastName) return [];

  // A SQL LIKE pre-filter on last name keeps this to a handful of candidate
  // rows to score in JS, rather than a full-table scan of every comparison
  // for every save — the exact normalized comparison still happens in JS
  // below, this only narrows what reaches it.
  const rows = query(
    `SELECT id, first_name, middle_name, last_name, date_of_birth, phone, email, member_code, status
       FROM members
      WHERE UPPER(REPLACE(last_name, '.', '')) LIKE @like ESCAPE '\\'
        AND (@excludeId IS NULL OR id != @excludeId)`,
    { like: likePattern(lastName), excludeId }
  );

  const scored = rows
    .map((row) => ({ member: row, ...scoreDuplicateCandidate(candidate, row) }))
    .filter((r) => r.points >= MODERATE_MATCH_THRESHOLD)
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);

  return scored.map((r) => ({
    member: {
      id: r.member.id,
      name: fullName(r.member),
      memberCode: r.member.member_code,
      dateOfBirth: r.member.date_of_birth
    },
    level: r.points >= STRONG_MATCH_THRESHOLD ? DUPLICATE_MATCH_LEVELS.STRONG : DUPLICATE_MATCH_LEVELS.MODERATE,
    reasons: r.reasons
  }));
}

// ===========================================================================
// Safe member deletion
// ===========================================================================
//
// Archive (an existing member status) is the normal action for someone who
// is no longer active — it keeps every historical record exactly as it is.
// Permanent deletion is reserved for a record that should never have
// existed at all (a duplicate, a mistake, a test entry) and is refused
// outright the moment it would remove anything a church would actually want
// kept, rather than relying on the database's own ON DELETE behaviour
// (a mix of CASCADE/SET NULL/RESTRICT already defined on the schema for
// every table below) to decide what happens to that history.

/**
 * Every place a member's id is referenced, grouped the way an administrator
 * would think about "does this person have history" rather than by table
 * name. Read-only — this never changes anything, so it is also what powers
 * the confirmation screen's dependency summary.
 */
export function memberDependencySummary(memberId) {
  const id = Number(memberId);
  const count = (sql, params = { id }) => queryOne(sql, params).n;

  // attendance_expected is the historical record of who was EXPECTED at a
  // finalized Friday. A member who was expected and never attended has no
  // attendance_records row at all, yet is part of that Friday's history (and
  // its attendance rate) - so it blocks permanent deletion exactly as
  // attendance and QR records do. (The table's member_id is also ON DELETE
  // RESTRICT, as a database-level backstop behind this check.)
  const attendanceRecords = count('SELECT COUNT(*) AS n FROM attendance_records WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM qr_checkins WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM attendance_expected WHERE member_id = @id');

  const cellGroupRecords = count('SELECT COUNT(*) AS n FROM cell_group_members WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM cell_groups WHERE leader_member_id = @id OR assistant_member_id = @id');

  const ministryRecords = count('SELECT COUNT(*) AS n FROM ministry_members WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM ministries WHERE leader_member_id = @id OR assistant_member_id = @id');

  const campaignCommitments = count('SELECT COUNT(*) AS n FROM ecaq_giving_board_claims WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM ecaq_faith_promise_commitments WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM ecaq_custom_submissions WHERE member_id = @id');

  // document_relationships is a polymorphic link (related_type/related_id)
  // with no declared foreign key — a plain schema inspection would miss it.
  const documents = count(
    "SELECT COUNT(*) AS n FROM document_relationships WHERE related_type = 'member' AND related_id = @id"
  );

  // Both directions: this member's own spouse/father/mother/guardian links,
  // and any other member whose own link points back at this one — deleting
  // this record would otherwise silently clear either side.
  const ownFamilyLinks = count(
    `SELECT COUNT(*) AS n FROM members
      WHERE id = @id AND (spouse_member_id IS NOT NULL OR father_member_id IS NOT NULL
                           OR mother_member_id IS NOT NULL OR guardian_member_id IS NOT NULL)`
  );
  const reverseFamilyLinks = count(
    `SELECT COUNT(*) AS n FROM members
      WHERE spouse_member_id = @id OR father_member_id = @id
         OR mother_member_id = @id OR guardian_member_id = @id`
  );
  const familyRelationships = ownFamilyLinks + reverseFamilyLinks;

  const visitorHistory = count('SELECT COUNT(*) AS n FROM visitors WHERE member_id = @id')
    + count('SELECT COUNT(*) AS n FROM visitors WHERE invited_by_member_id = @id');

  const linkedUser = queryOne('SELECT id, username, display_name FROM users WHERE member_id = @id', { id });

  return {
    attendanceRecords,
    familyRelationships,
    cellGroupRecords,
    ministryRecords,
    campaignCommitments,
    documents,
    visitorHistory,
    linkedUserAccount: linkedUser ? { id: linkedUser.id, username: linkedUser.username } : null
  };
}

/**
 * Whether `memberId` can be permanently deleted without losing anything a
 * church would consider real history. Every category in the summary above
 * that is genuinely historical must be zero; a linked user account also
 * blocks, since that is a live sign-in credential, not a record of the
 * past. member_status_history and member_field_values are deliberately not
 * checked here — the former always holds at least the one "record created"
 * entry for every member and carries no information worth keeping once the
 * record itself is gone, and the latter is arbitrary optional data, not the
 * church-history categories this check exists to protect.
 */
export function canDeleteMember(memberId) {
  const summary = memberDependencySummary(memberId);
  const blockingCategories = [
    'attendanceRecords', 'familyRelationships', 'cellGroupRecords',
    'ministryRecords', 'campaignCommitments', 'documents', 'visitorHistory'
  ];
  const blocked = blockingCategories.some((key) => summary[key] > 0) || Boolean(summary.linkedUserAccount);
  return { safe: !blocked, summary };
}

export const DELETE_REASONS = ['duplicate', 'mistake', 'test', 'other'];
export const DELETE_REASON_LABELS = {
  duplicate: 'Duplicate record',
  mistake: 'Created by mistake',
  test: 'Test record',
  other: 'Other'
};

/**
 * Permanently removes a member record. Refuses outright — never cascades
 * through history to force success — if canDeleteMember() finds anything
 * blocking; the caller is expected to have already shown that result to an
 * administrator rather than relying on this as the first check. The audit
 * entry is written by the caller (routes/members.js), which has the request
 * context (who, from where) this service layer does not.
 */
export function deleteMemberRecord(memberId, { userId = null } = {}) {
  const id = Number(memberId);
  const member = getMember(id, { type: 'all' });
  if (!member) return { ok: false, reason: 'not_found' };

  const check = canDeleteMember(id);
  if (!check.safe) return { ok: false, reason: 'has_dependencies', summary: check.summary };

  // The remaining rows that reference this member at this point are exactly
  // the two categories deliberately excluded from canDeleteMember() above
  // (the creation entry in member_status_history, and any custom field
  // values) — both harmless to remove, and both already have the correct
  // ON DELETE CASCADE defined on the schema, so a plain delete here is
  // enough; nothing further needs to be deleted by hand.
  transaction(() => {
    execute('DELETE FROM members WHERE id = @id', { id });
  })();

  return { ok: true, member };
}
