import { query } from '../db/index.js';

/*
 * THE definition of "how many people were physically at this service". Every screen, report, export and check that shows a service headcount asks here, so
 * two of them cannot disagree.
 *
 *   members      people with a member record who have a POSITIVE attendance row at this service (Present, or a member-linked Visitor row).
 *                Expected or not, member of today or not: a person who was there was there. One row per member per service, so each counts once.
 *   firstTimers  people recorded as First Timers whose visit belongs to this service, on their FIRST actual visit, and who are NOT already counted in `members` for it.
 *   returning    the same kind of person (a First Timer record, not a member for this service) on a LATER visit: someone who attended before and whose Membership Review
 *                is still to be done. One person, one record: they are never a First Timer twice and are never promoted to a member by attending again.
 *   visitors     firstTimers + returning: everyone at the service who is not counted as a member.
 *   total        members + firstTimers + returning: everyone who was at church. This is the answer to "how many people were there?".
 *
 * Why a First Timer who later becomes a member still counts once, on the same Friday they came:
 *   - a visit belongs to the service for good (visitor_visits is never rewritten), and a person is identified by WHO they are, not by whether a member
 *     record exists today: a First Timer converted or linked since is the member record they became. If that member also has their own Present row for the
 *     service the two are the same human and count once (as a member); if not, the visit is the only evidence and counts once (as a First Timer).
 *   - so converting or linking a First Timer moves nobody in or out of a past headcount.
 *
 * Which visits belong to a service: the visit names the service (session_id), or - for a visit recorded by hand with only a date - the Friday Service held on
 * that date. (The Membership Review already matches visits to Fridays the same way: by service or by date.) A visit is never matched to a cell group meeting
 * or special service by date.
 *
 * What this is NOT: it is not attendance for the expected-member arithmetic. Who was expected, who is absent and every rate stay in attendance-outcomes.js;
 * First Timers never enter the expected count or the rate. Nothing here depends on the tracking start date, a service's lifecycle phase, or anyone's status
 * today, and nothing here writes anything.
 */

export const POSITIVE_ATTENDANCE_ROWS = ['present', 'visitor'];
const POSITIVE_SQL = POSITIVE_ATTENDANCE_ROWS.map((s) => `'${s}'`).join(',');

function placeholders(ids, prefix) {
  return { sql: ids.map((_, i) => `@${prefix}${i}`).join(','), params: Object.fromEntries(ids.map((id, i) => [`${prefix}${i}`, id])) };
}

/**
 * Headcounts for many services in two queries (no per-service queries).
 * Returns Map(sessionId -> { members, firstTimers, total, memberIds, firstTimerIds }). `memberIds` and `firstTimerIds` list the people counted, so a caller (the attendance drill-down) can name exactly them.
 */
export function serviceHeadcounts(sessionIds) {
  const ids = [...new Set(sessionIds.map(Number).filter(Boolean))];
  const result = new Map(ids.map((id) => [id, { members: 0, firstTimers: 0, returning: 0, visitors: 0, total: 0, memberIds: [], firstTimerIds: [], returningIds: [] }]));
  if (ids.length === 0) return result;
  const chunkSize = 400; // well under SQLite's variable limit

  for (let i = 0; i < ids.length; i += chunkSize) {
    const chunk = ids.slice(i, i + chunkSize);
    const { sql, params } = placeholders(chunk, 's');

    const memberRows = query(
      `SELECT session_id, member_id FROM attendance_records WHERE status IN (${POSITIVE_SQL}) AND session_id IN (${sql})`,
      params
    );
    const present = new Map(chunk.map((id) => [id, new Set()]));
    for (const row of memberRows) present.get(row.session_id).add(row.member_id);

    const visitRows = query(
      `SELECT s.id AS session_id, v.id AS visitor_id, v.member_id AS member_id,
              EXISTS (SELECT 1 FROM visitor_visits e WHERE e.visitor_id = v.id AND e.visit_date < s.service_date) AS earlier
         FROM attendance_sessions s
         JOIN visitor_visits vv
           ON vv.session_id = s.id
           OR (vv.session_id IS NULL AND s.service_type = 'friday_service' AND s.cell_group_id = 0 AND vv.visit_date = s.service_date)
         JOIN visitors v ON v.id = vv.visitor_id
        WHERE s.id IN (${sql})`,
      params
    );
    const counted = new Map(chunk.map((id) => [id, new Set()]));
    const visitorIds = new Map(chunk.map((id) => [id, []]));
    const returningIds = new Map(chunk.map((id) => [id, []]));
    for (const row of visitRows) {
      const people = present.get(row.session_id);
      // The human: the member record they became, or (still a First Timer) the First Timer record.
      const key = row.member_id ? `m${row.member_id}` : `v${row.visitor_id}`;
      if (row.member_id && people.has(row.member_id)) continue; // already counted as a member of this service
      if (counted.get(row.session_id).has(key)) continue; // one human, one count
      counted.get(row.session_id).add(key);
      // A visit is a FIRST visit when the person has no earlier visit; any later one is a returning visit (the same record, never a second First Timer).
      (row.earlier ? returningIds : visitorIds).get(row.session_id).push(row.visitor_id);
    }

    for (const id of chunk) {
      const members = present.get(id).size;
      const firstTimers = visitorIds.get(id).length;
      const returning = returningIds.get(id).length;
      result.set(id, {
        members, firstTimers, returning, visitors: firstTimers + returning, total: members + firstTimers + returning,
        memberIds: [...present.get(id)], firstTimerIds: visitorIds.get(id), returningIds: returningIds.get(id)
      });
    }
  }
  return result;
}

/** Headcount for one service. */
export function serviceHeadcount(sessionId) {
  return serviceHeadcounts([sessionId]).get(Number(sessionId)) || { members: 0, firstTimers: 0, returning: 0, visitors: 0, total: 0, memberIds: [], firstTimerIds: [], returningIds: [] };
}
