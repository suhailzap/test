import {
  createDocument, finishDocument, heading, paragraph, summaryCards, table,
  barChart, breakdownChart, progressBar, note, INK
} from '../lib/pdf.js';
import { getSetting } from '../lib/settings.js';
import { formatDate, today, qatarDateOf } from '../lib/dates.js';

import {
  listMembers, statusCounts, displayName, fullName, occasionsInRange, STATUS_LABELS,
  MEMBER_STATUSES, NOT_EXPECTED_STATUSES, DEFAULT_ROSTER_STATUSES, normalizeMemberStatuses
} from './members.js';
import { listGroups, groupMembers } from './cell-groups.js';
import {
  attendanceReport,
  cellGroupAttendanceSummary,
  cellGroupMeetingSummary,
  consecutiveMissedFridays,
  lastAttendedFriday,
  longAbsenceReview,
  trackedFridayContexts
} from './attendance.js';
import { congregationFor, AGE_GROUP_LABELS } from './congregations.js';
import { firstTimersReportData, FOLLOW_UP_LABELS } from './visitors.js';
import {
  reportData as faithPromiseData, amendedCommitmentIds as fpAmendedIds, FREQUENCY_LABELS as FP_FREQUENCY_LABELS,
  STATUS_LABELS as FP_STATUS_LABELS
} from './faith-promise.js';
import {
  currentCampaign,
  getCampaign,
  campaignProgress, campaignWindow,
  allCampaignsProgress,
  campaignPayments,
  outstandingClaims,
  allClaimsWithBalance,
  formatMoney,
  PAYMENT_LABELS
} from './ecaq.js';

const CONGREGATION_COLOURS = { child: INK.sky, teen: INK.gold, adult: INK.navySoft, unknown: INK.line };

function churchMeta() {
  const address = getSetting('church.address');
  const note_ = getSetting('church.location_note');
  return [address, note_].filter(Boolean).join(' · ');
}

/**
 * Congregation breakdown for an already-resolved list of member objects —
 * used instead of congregationCounts() wherever a report has its own
 * status/cell-group filter, since congregationCounts() always describes the
 * whole current population and has no way to know about a report's own
 * selection. Every caller here must pass the exact same filtered list its
 * other figures already use, never re-derive its own.
 */
function congregationBreakdownFor(members) {
  const counts = { child: 0, teen: 0, adult: 0, unknown: 0 };
  for (const m of members) {
    const group = congregationFor(m);
    counts[group || 'unknown'] += 1;
  }
  return counts;
}

export const REPORTS = {
  attendance: { label: 'Friday Service attendance', permission: 'reports.view' },
  directory: { label: 'Member directory', permission: 'members.view' },
  occasions: { label: 'Birthdays and anniversaries', permission: 'members.view' },
  'cell-groups': { label: 'Cell group report', permission: 'reports.view' },
  giving: { label: 'Giving Board statement', permission: 'giving.manage' },
  'first-timers': { label: 'First Timers report', permission: 'members.view' },
  'faith-promise': { label: 'Faith Promise report', permission: 'giving.manage' },
  'long-absence': { label: 'Long absence review', permission: 'attendance.followup' }
};

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

// --- Birthdays and anniversaries -------------------------------------------

export function occasionsPdf({ from, to, include = 'both', status = 'connected' }) {
  const statuses = status === 'all'
    ? MEMBER_STATUSES
    : status === 'connected'
      ? MEMBER_STATUSES.filter((s) => !NOT_EXPECTED_STATUSES.includes(s))
      : [status];
  const occasions = occasionsInRange({ from, to, statuses });
  const showBirthdays = include !== 'anniversaries';
  const showAnniversaries = include !== 'birthdays';

  const doc = createDocument({
    title: 'Birthdays and anniversaries',
    subtitle: `${formatDate(from, 'long')} to ${formatDate(to, 'long')}`,
    meta: [churchMeta()]
  });

  summaryCards(doc, [
    { label: 'Birthdays', value: showBirthdays ? occasions.birthdays.length : '—' },
    { label: 'Anniversaries', value: showAnniversaries ? occasions.anniversaries.length : '—' },
    {
      label: 'Occasions in all',
      value: (showBirthdays ? occasions.birthdays.length : 0)
        + (showAnniversaries ? occasions.anniversaries.length : 0)
    },
    {
      label: 'Members covered',
      value: status === 'all' ? 'All statuses' : status === 'connected' ? 'Everyone still with us' : STATUS_LABELS[status] || status
    }
  ]);

  // How the occasions fall across the months in the range.
  const monthly = new Map();
  const collect = (list) => {
    for (const item of list) {
      const key = item.date.slice(0, 7);
      monthly.set(key, (monthly.get(key) || 0) + 1);
    }
  };
  if (showBirthdays) collect(occasions.birthdays);
  if (showAnniversaries) collect(occasions.anniversaries);

  if (monthly.size > 1) {
    barChart(doc, {
      title: 'Occasions by month',
      series: [...monthly.entries()].sort().map(([key, value]) => ({
        label: `${MONTH_NAMES[Number(key.slice(5, 7)) - 1].slice(0, 3)} ${key.slice(2, 4)}`,
        value
      })),
      valueLabel: 'Birthdays and anniversaries falling in each month.'
    });
  }

  const unusableCount = (showBirthdays ? occasions.unusable.birthdays : 0) + (showAnniversaries ? occasions.unusable.anniversaries : 0);
  if (unusableCount > 0) {
    note(doc, `${unusableCount} stored ${unusableCount === 1 ? 'date is' : 'dates are'} not a real calendar date (for example a day and month entered the wrong way round), so `
      + `${unusableCount === 1 ? 'that record is' : 'those records are'} not listed. Correct them on the member records and run the report again.`);
  }

  const unverifiedCount = showBirthdays ? occasions.unverified.birthdays : 0;
  if (unverifiedCount > 0) {
    note(doc, `${unverifiedCount} ${unverifiedCount === 1 ? 'date of birth needs' : 'dates of birth need'} verification, so ${unverifiedCount === 1 ? 'that birthday is' : 'those birthdays are'} not listed. They are on the Date of birth review page, where an administrator can see why.`);
  }

  if (occasions.spansNewYear) {
    note(doc, 'This range crosses the new year, so occasions are listed in the order they '
      + 'fall rather than by calendar year.');
  }

  if (showBirthdays) {
    heading(doc, 'Birthdays');
    if (occasions.birthdays.length === 0) {
      paragraph(doc, 'No birthdays fall in this range.', { color: INK.muted, size: 8 });
    } else {
      table(doc, {
        caption: 'In the order they fall. Someone born on 29 February is listed on 28 February '
          + 'in a year that has no 29th.',
        columns: [
          { label: 'Date', weight: 1.3, bold: true, value: (r) => formatDate(r.date, 'medium') },
          { label: 'Member', weight: 2.2, value: (r) => displayName(r.member) },
          { label: 'Turning', weight: 0.8, align: 'right', value: (r) => (r.turning ?? '—') },
          { label: 'Congregation', weight: 1.2, value: (r) => AGE_GROUP_LABELS[congregationFor(r.member)] || '—' },
          { label: 'Cell group', weight: 1.4, value: (r) => r.member.cell_group_name || '—' },
          { label: 'Contact', weight: 1.5, value: (r) => r.member.phone || '—' }
        ],
        rows: occasions.birthdays
      });
    }
  }

  if (showAnniversaries) {
    heading(doc, 'Wedding anniversaries');
    if (occasions.anniversaries.length === 0) {
      paragraph(doc, 'No anniversaries fall in this range.', { color: INK.muted, size: 8 });
    } else {
      table(doc, {
        caption: 'In the order they fall.',
        columns: [
          { label: 'Date', weight: 1.3, bold: true, value: (r) => formatDate(r.date, 'medium') },
          { label: 'Member', weight: 2.2, value: (r) => displayName(r.member) },
          { label: 'Spouse', weight: 1.8, value: (r) => r.spouse || '—' },
          { label: 'Years', weight: 0.8, align: 'right', value: (r) => (r.years ?? '—') },
          { label: 'Cell group', weight: 1.4, value: (r) => r.member.cell_group_name || '—' },
          { label: 'Contact', weight: 1.5, value: (r) => r.member.phone || '—' }
        ],
        rows: occasions.anniversaries
      });
    }
  }

  note(doc, 'This list contains members\u2019 contact details and dates of birth. Keep it with '
    + 'the same care as any other member record.');

  finishDocument(doc);
  return doc;
}

// --- Long absence review ----------------------------------------------------

/**
 * The PDF companion to the on-screen `/attendance/long-absence` page — same
 * data, same sort, same "this is an occasional review, not a weekly alert"
 * framing. Members who have gone longer than the recent-engagement window
 * without a recorded Friday Service, or who have never attended one at all.
 */
export function longAbsencePdf({ sort = 'days_away', direction = 'desc' } = {}) {
  const review = longAbsenceReview({ limit: 1000, sort, direction });
  const list = review.rows;

  const doc = createDocument({
    title: 'Long Absence Review',
    subtitle: 'Members not recently engaged with the Friday Service — an occasional review, not a weekly alert',
    meta: [churchMeta()]
  });

  // Before the review can run there is nothing to count: no summary figures, so the document cannot
  // be read as "members were checked and none qualified".
  if (review.status === 'not_started') {
    paragraph(doc, 'Not available: attendance tracking has not started, so this review has not been run and no member has been assessed.', { color: INK.muted, size: 8 });
    finishDocument(doc);
    return doc;
  }
  if (review.status === 'insufficient_history') {
    paragraph(doc, `Not enough tracked history yet: attendance tracking began ${formatDate(review.goLive, 'medium')} (${review.trackedDays} days ago) and this review needs ${review.requiredDays}. It has not been run and no member has been assessed.`,
      { color: INK.muted, size: 8 });
    finishDocument(doc);
    return doc;
  }

  summaryCards(doc, [
    { label: 'Members on this list', value: String(list.length) },
    { label: 'No tracked attendance', value: String(list.filter((r) => r.neverAttended).length) }
  ]);
  if (!review.complete) {
    note(doc, `${review.awaitingFridays.length} Friday Service(s) in the review window have not been finalized, so this list may be incomplete.`);
  }
  if (list.length === 0) {
    paragraph(doc, 'Nobody meets this yet.', { color: INK.muted, size: 8 });
    finishDocument(doc);
    return doc;
  }

  heading(doc, 'Members');
  table(doc, {
    columns: [
      { label: 'Member ID', weight: 0.9, value: (r) => r.member.member_code },
      { label: 'Name', weight: 1.8, bold: true, value: (r) => displayName(r.member) },
      { label: 'Cell group', weight: 1.3, value: (r) => r.member.cell_group_name || '—' },
      {
        label: 'Last attended Friday Service', weight: 1.6,
        value: (r) => (r.lastAttended ? formatDate(r.lastAttended.service_date, 'long') : 'No attended service on record')
      },
      {
        label: 'How long ago', weight: 1, align: 'right',
        value: (r) => (r.neverAttended ? 'No tracked attendance' : `${r.daysAway} day${r.daysAway === 1 ? '' : 's'}`)
      }
    ],
    rows: list
  });

  note(doc, 'This is not a weekly alert. It is meant for an occasional look — monthly or quarterly — at '
    + 'members who have gone quiet for longer than usual. Nothing here changes a membership status automatically.');

  finishDocument(doc);
  return doc;
}

// --- Friday Service attendance ---------------------------------------------

/** What the member attendance columns mean (one wording for the PDF, the screen and the notes beside them). The figures themselves come from the unchanged attendance calculations. */
const ATTENDANCE_LEGEND = 'Services counted: the finalized Friday Services in these dates that the member was expected at '
  + '(services before Attendance tracking began, cancelled services and "Attendance not taken" are never counted). '
  + 'Present, Vacation and Absent are what happened at those services. Pending: expected at a service that is not finalized yet - not counted, and not absent. '
  + 'Attendance % = Present divided by (Services counted minus Vacation).';

export function attendancePdf({ from, to, cellGroupId = null, statuses = null }) {
  const report = attendanceReport({ from, to, cellGroupId, statuses });
  const fridayTitle = getSetting('service.friday.title') || 'CCIQ Friday Service';
  const threshold = Number(getSetting('attendance.followup_threshold')) || 3;

  const isDefaultRoster = report.statuses.length === DEFAULT_ROSTER_STATUSES.length
    && DEFAULT_ROSTER_STATUSES.every((s) => report.statuses.includes(s));
  const populationNote = isDefaultRoster
    ? 'Normal expected Friday roster'
    : report.statuses.length === 0
      ? 'Every member status, including historical'
      : report.statuses.map((s) => STATUS_LABELS[s] || s).join(', ');

  const doc = createDocument({
    title: `${fridayTitle} attendance`,
    subtitle: `${formatDate(from, 'medium')} to ${formatDate(to, 'medium')} — ${populationNote}`,
    meta: [churchMeta()]
  });

  // Numbers come only from FINALIZED Fridays (see attendanceReport): the average
  // present and the overall rate are across those, and the overall rate is weighted
  // (sum attended over sum expected-minus-Vacation), never an average of percentages.
  const finalized = report.bySession.filter((s) => s.final);
  const services = report.sessions.length;
  const averagePresent = finalized.length
    ? Math.round(finalized.reduce((sum, s) => sum + s.present + s.visitor, 0) / finalized.length)
    : 0;
  const flagged = report.rows.filter((r) => r.consecutive.streak >= threshold);

  summaryCards(doc, [
    { label: 'Services in range', value: services, note: `${finalized.length} finalized and counted` },
    { label: 'Average present', value: finalized.length ? averagePresent : '—', note: 'per counted service' },
    { label: 'Overall attendance %', value: report.overall.rate === null ? '—' : `${report.overall.rate}%`, note: 'across counted services' },
    { label: 'Members listed', value: report.rows.length },
    {
      label: 'Follow-up may apply',
      value: flagged.length,
      note: `${threshold} or more absences in a row`,
      highlight: flagged.length > 0
    }
  ]);

  if (report.sessions.length) {
    // report.bySession is derived from the exact same status/cell-group
    // filtered population as every other figure on this page — never
    // sessionSummary(), which answers present-count-across-the-whole-roster
    // regardless of the population this report was asked to describe.
    barChart(doc, {
      title: 'Members present at each service',
      series: report.bySession
        .filter((session) => session.final || session.phase === 'pre_go_live' || session.phase === 'not_started')
        .map((session) => ({
          label: formatDate(session.date, 'short').slice(0, 5),
          value: session.present + session.visitor
        })),
      valueLabel: 'Each column is one finalized Friday Service (or earlier history); open and unfinalized services are not shown.'
    });
  }

  // No finalized service in these dates means there are no figures to print: say so plainly rather than page after page of zero rows (the screen says the same).
  if (finalized.length === 0) {
    heading(doc, 'Attendance by member');
    paragraph(doc, 'No finalized Friday Service falls in these dates, so there are no attendance figures to show. Member figures, attendance % and absences in a row appear once the dates include finalized services that were counted. '
      + 'Services before Attendance tracking began, cancelled services and services where attendance was not taken are never counted. Earlier attendance is on Attendance history in the portal.',
    { color: INK.muted });
    finishDocument(doc, { confidential: true });
    return doc;
  }

  const congregations = congregationBreakdownFor(report.rows.map((r) => r.member));
  breakdownChart(doc, {
    title: 'Selected members by congregation',
    rows: ['child', 'teen', 'adult', 'unknown']
      .filter((key) => congregations[key] > 0)
      .map((key) => ({
        label: key === 'unknown' ? 'Not yet placed' : AGE_GROUP_LABELS[key],
        value: congregations[key],
        colour: CONGREGATION_COLOURS[key]
      }))
  });

  heading(doc, 'Attendance by member');
  // The legend says what each column means, in the words used on the screen and in the CSV (the calculations are unchanged).
  const vacationEndsRun = Boolean(getSetting('attendance.excused_counts'));
  note(doc, `${ATTENDANCE_LEGEND} Absences in a row: the member's current run of finalized services missed one after another, counting back from the latest; a Vacation ${vacationEndsRun ? 'ends the run' : 'counts as missed in the run'}.`);
  table(doc, {
    columns: [
      { label: 'Member', weight: 2, value: (r) => displayName(r.member) },
      { label: 'Cell group', weight: 1.4, value: (r) => r.member.cell_group_name || '—' },
      { label: 'Services counted', weight: 1.1, align: 'right', value: (r) => r.eligible },
      { label: 'Present', weight: 0.9, align: 'right', value: (r) => r.present + r.visitor },
      { label: 'Vacation', weight: 0.95, align: 'right', value: (r) => r.excused },
      { label: 'Absent', weight: 0.9, align: 'right', value: (r) => r.absent },
      { label: 'Pending', weight: 0.9, align: 'right', value: (r) => r.not_recorded },
      { label: 'Attendance %', weight: 1.05, align: 'right', value: (r) => (r.rate === null ? '—' : `${r.rate}%`) },
      {
        label: 'Absences in a row',
        weight: 1.15,
        align: 'right',
        bold: true,
        value: (r) => r.consecutive.streak,
        color: (r) => (r.consecutive.streak >= threshold ? INK.red : INK.text)
      }
    ],
    rows: report.rows
  });

  if (flagged.length) {
    heading(doc, 'Members where follow-up may be appropriate');
    note(doc,
      `The figure below counts consecutive finalized ${fridayTitle}s the member was expected at and did not attend. `
      + 'It reports only what the records show; it does not assume a reason, and no membership '
      + 'status has been changed.');
    table(doc, {
      columns: [
        { label: 'Member', weight: 2.4, value: (r) => displayName(r.member) },
        { label: 'Cell group', weight: 1.6, value: (r) => r.member.cell_group_name || '—' },
        { label: 'Absences in a row', weight: 1.3, align: 'right', value: (r) => r.consecutive.streak },
        {
          label: 'Last attended',
          weight: 1.4,
          value: (r) => {
            const last = lastAttendedFriday(r.member.id);
            return last ? formatDate(last.service_date, 'medium') : 'No record';
          }
        }
      ],
      rows: flagged
    });
  }

  finishDocument(doc);
  return doc;
}

// --- Member directory ------------------------------------------------------

export function directoryPdf({ statuses = ['active'], includeContact = true, congregation = null }) {
  const selected = normalizeMemberStatuses(statuses);
  const { rows } = listMembers({
    scope: { type: 'all' },
    status: selected,
    page: 1,
    pageSize: 1_000_000_000, // every matching member
    sort: 'name'
  });

  const members = congregation
    ? rows.filter((m) => congregationFor(m) === congregation)
    : rows;

  const doc = createDocument({
    title: 'Member directory',
    subtitle: selected.length === 0
      ? 'All member records, every status'
      : `${selected.map((s) => STATUS_LABELS[s] || s).join(', ')} members`,
    meta: [churchMeta()],
    landscape: includeContact
  });

  const counts = statusCounts({ type: 'all' });
  summaryCards(doc, [
    { label: 'In this directory', value: members.length },
    { label: 'Active', value: counts.active },
    { label: 'Baptized', value: members.filter((m) => m.is_baptized).length },
    { label: 'In a cell group', value: members.filter((m) => m.cell_group_id).length }
  ]);

  // Found alongside the same bug in attendancePdf(): this must describe the
  // directory's own filtered `members` list, not congregationCounts()'s
  // unfiltered whole-church figure, which silently ignored the status
  // filter added to this report entirely.
  const congregations = congregationBreakdownFor(members);
  breakdownChart(doc, {
    title: 'Selected members by congregation',
    rows: ['child', 'teen', 'adult', 'unknown']
      .filter((key) => congregations[key] > 0)
      .map((key) => ({
        label: key === 'unknown' ? 'Not yet placed' : AGE_GROUP_LABELS[key],
        value: congregations[key],
        colour: CONGREGATION_COLOURS[key]
      }))
  });

  const columns = [
    { label: 'Member ID', weight: 0.9, value: (m) => m.member_code },
    { label: 'Name', weight: 2, bold: true, value: (m) => fullName(m) },
    { label: 'Congregation', weight: 1, value: (m) => AGE_GROUP_LABELS[congregationFor(m)] || '—' },
    { label: 'Cell group', weight: 1.3, value: (m) => m.cell_group_name || '—' },
    { label: 'Status', weight: 0.8, value: (m) => STATUS_LABELS[m.status] || m.status },
    { label: 'Baptized', weight: 0.7, align: 'center', value: (m) => (m.is_baptized ? 'Yes' : '—') }
  ];

  if (includeContact) {
    columns.push(
      { label: 'Contact number', weight: 1.3, value: (m) => m.phone || '—' },
      { label: 'Email', weight: 1.8, value: (m) => m.email || '—' }
    );
  }

  heading(doc, 'Members');
  table(doc, { columns, rows: members });

  if (includeContact) {
    note(doc, 'This directory contains members\u2019 contact details. Handle and store it accordingly, '
      + 'and share it only with those whose role permits access to member contact information.');
  }

  finishDocument(doc);
  return doc;
}

// --- Cell group report -----------------------------------------------------

export function cellGroupsPdf({ groupIds = [], includeInactive = false, rostersOnly = false } = {}) {
  const chosen = (groupIds || []).map(Number).filter(Boolean);
  const all = listGroups({ includeInactive });
  const groups = chosen.length ? all.filter((g) => chosen.includes(g.id)) : all;

  const doc = createDocument({
    title: groups.length === 1 ? `${groups[0].name} — cell group report` : 'Cell group report',
    subtitle: chosen.length
      ? `${groups.length} selected group${groups.length === 1 ? '' : 's'}`
      : `All ${groups.length} group${groups.length === 1 ? '' : 's'}`,
    meta: [churchMeta()]
  });

  const threshold = Number(getSetting('attendance.followup_threshold')) || 3;
  const totalMembers = groups.reduce((sum, g) => sum + g.member_count, 0);

  summaryCards(doc, [
    { label: 'Cell groups', value: groups.length },
    { label: 'Members in groups', value: totalMembers },
    {
      label: 'Average group size',
      value: groups.length ? Math.round(totalMembers / groups.length) : 0
    },
    { label: 'Groups with a leader', value: groups.filter((g) => g.leader_member_id).length }
  ]);

  breakdownChart(doc, {
    title: 'Members per group',
    rows: groups.map((g) => ({ label: g.name, value: g.member_count, colour: INK.navySoft }))
  });

  // An overview first, so the reader sees the shape of the whole church before
  // the individual rosters.
  if (groups.length > 1) {
    heading(doc, 'All groups at a glance');
    table(doc, {
      columns: [
        { label: 'Cell group', weight: 2, bold: true, value: (g) => g.name },
        {
          label: 'Leader',
          weight: 1.8,
          value: (g) => (g.leader_first
            ? `${g.leader_preferred || g.leader_first} ${g.leader_last || ''}`.trim()
            : 'Not named')
        },
        {
          label: 'Assistant',
          weight: 1.6,
          value: (g) => (g.assistant_first
            ? `${g.assistant_preferred || g.assistant_first} ${g.assistant_last || ''}`.trim()
            : '—')
        },
        { label: 'Meets', weight: 1.5, value: (g) => [g.meeting_day, g.meeting_time].filter(Boolean).join(' ') || '—' },
        { label: 'Where', weight: 1.5, value: (g) => g.meeting_location || '—' },
        { label: 'Members', weight: 1.1, align: 'right', bold: true, value: (g) => g.member_count },
        { label: 'Status', weight: 0.9, value: (g) => g.status }
      ],
      rows: groups
    });
  }

  if (rostersOnly && groups.length > 1) {
    finishDocument(doc);
    return doc;
  }

  const sequence = trackedFridayContexts();
  for (const group of groups) {
    heading(doc, group.name);

    const leader = group.leader_first
      ? `${group.leader_preferred || group.leader_first} ${group.leader_last || ''}`.trim()
      : 'No leader named';
    const meeting = [group.meeting_day, group.meeting_time, group.meeting_location]
      .filter(Boolean).join(' · ') || 'Meeting details not set';
    paragraph(doc, `Leader: ${leader}    ·    ${meeting}`, { color: INK.muted, size: 8 });

    const members = groupMembers(group.id);
    const attendance = cellGroupAttendanceSummary(group.id, { lastN: 8 });
    const rateByMember = new Map(attendance.rows.map((r) => [r.member.id, r]));
    const meetings = cellGroupMeetingSummary(group.id, { lastN: 8 });
    const meetingByMember = new Map(meetings.rows.map((r) => [r.member.id, r]));

    // The two kinds of attendance are named, so the columns are never confused.
    paragraph(doc,
      `Friday attendance covers the last ${attendance.sessions.length} finalized Friday Service${attendance.sessions.length === 1 ? '' : 's'} counted. `
      + `Group meetings recorded: ${meetings.meetings.length}.`,
      { color: INK.muted, size: 7.5 });

    if (members.length === 0) {
      paragraph(doc, 'No members are assigned to this group yet.', { color: INK.muted, size: 8 });
      continue;
    }

    table(doc, {
      columns: [
        { label: 'Member', weight: 2.2, value: (m) => displayName(m) },
        { label: 'Role', weight: 0.9, value: (m) => m.role_in_group || 'member' },
        { label: 'Status', weight: 0.9, value: (m) => STATUS_LABELS[m.status] || m.status },
        {
          label: 'Friday attendance',
          weight: 1.3,
          align: 'right',
          value: (m) => {
            const row = rateByMember.get(m.id);
            if (!row) return '—';
            // Finalized Fridays only: present out of the services counted (Vacation taken out), then the percentage.
            if (row.rateDenominator === 0) return '—';
            return `${row.rateNumerator}/${row.rateDenominator} (${row.rate}%)`;
          }
        },
        {
          label: 'Group meetings',
          weight: 1.2,
          align: 'right',
          value: (m) => {
            const row = meetingByMember.get(m.id);
            return row ? `${row.present}/${row.cells.length} (${row.rate}%)` : '—';
          }
        },
        {
          label: 'Absences in a row',
          weight: 1.2,
          align: 'right',
          bold: true,
          value: (m) => consecutiveMissedFridays(m.id, { contexts: sequence }).streak,
          color: (m) => (consecutiveMissedFridays(m.id, { contexts: sequence }).streak >= threshold
            ? INK.red : INK.text)
        }
      ],
      rows: members
    });
  }

  if (groups.length > 0) {
    note(doc, 'Friday attendance: present/counted (percentage): the finalized Friday Services the member was expected at (cancelled services, "Attendance not taken" and services before tracking began are not counted), '
      + 'with Vacation taken out of the count. Absences in a row: the current run of finalized Friday Services missed one after another, counting back from the latest. '
      + 'Group meetings: group meetings attended out of those recorded; they are separate from Friday Service and never count as an absence.');
  }

  finishDocument(doc);
  return doc;
}

// --- Giving Board statement ------------------------------------------------

/**
 * All the boards on one page: each year on its own line, then the totals.
 *
 * Several years run at once, so the church needs to see both what each year has
 * raised and what the whole commitment stands at, without the two being
 * confused for one another.
 */
export function allYearsGivingPdf() {
  const { years, totals, mixedCurrency, currency } = allCampaignsProgress();

  const doc = createDocument({
    title: 'CCIQ Giving Board',
    subtitle: 'Every year, side by side',
    meta: [churchMeta()]
  });

  if (years.length === 0) {
    paragraph(doc, 'No Giving Board has been set up, so there is nothing to report yet.');
    finishDocument(doc);
    return doc;
  }

  summaryCards(doc, [
    { label: 'Days taken', value: `${totals.claimed} of ${totals.days}` },
    { label: 'Committed', value: formatMoney(totals.committed, currency) },
    { label: 'Collected', value: formatMoney(totals.collected, currency) },
    { label: 'Still owing', value: formatMoney(totals.outstanding, currency) }
  ]);

  if (mixedCurrency) {
    note(doc, 'These boards are not all in the same currency, so the totals below cover only '
      + 'the boards held in ' + currency + '. Read each year on its own line.');
  }

  heading(doc, 'Each year');
  table(doc, {
    columns: [
      { key: 'year', label: 'Year', weight: 0.7 },
      { key: 'status', label: 'Status', weight: 1 },
      { key: 'taken', label: 'Days taken', weight: 1, align: 'right' },
      { key: 'committed', label: 'Committed', weight: 1.1, align: 'right' },
      { key: 'collected', label: 'Collected', weight: 1.1, align: 'right' },
      { key: 'owing', label: 'Still owing', weight: 1.1, align: 'right' },
      { key: 'progress', label: 'Collected', weight: 0.8, align: 'right' }
    ],
    rows: years.map((y) => ({
      year: campaignWindow(y.campaign).whole ? String(y.year) : `${y.year} (${formatDate(campaignWindow(y.campaign).from, 'medium')} to ${formatDate(campaignWindow(y.campaign).to, 'medium')})`,
      status: y.status === 'active' ? 'Open' : y.status === 'draft' ? 'Not open yet' : 'Closed',
      taken: `${y.claimed} of ${y.totalDates}`,
      committed: formatMoney(y.committed, y.currency),
      collected: formatMoney(y.collected, y.currency),
      owing: formatMoney(y.committed - y.collected, y.currency),
      progress: y.committed ? `${Math.round((y.collected / y.committed) * 100)}%` : '—'
    })),
    totals: {
      year: 'All years',
      taken: `${totals.claimed} of ${totals.days}`,
      committed: formatMoney(totals.committed, currency),
      collected: formatMoney(totals.collected, currency),
      owing: formatMoney(totals.outstanding, currency),
      progress: `${totals.collectedPercent}%`
    }
  });

  note(doc, 'A day is counted against the year it belongs to. Taking a day is a commitment; '
    + 'the money is only counted once it has been received.');

  finishDocument(doc, { confidential: true });
  return doc;
}

export function givingPdf({ campaignId = null } = {}) {
  let campaign = campaignId ? getCampaign(Number(campaignId)) : currentCampaign();
  // A Giving Board statement is only for a Giving Board campaign: any other kind of campaign is never presented as a board.
  if (campaign && campaign.type !== 'giving_board') campaign = null;

  const window = campaign ? campaignWindow(campaign) : null;
  const doc = createDocument({
    title: 'CCIQ Giving Board statement',
    // The campaign's own dates, so a board that does not run the whole year says so.
    subtitle: campaign ? `${campaign.name} · ${window.whole ? campaign.year : `${formatDate(window.from, 'medium')} to ${formatDate(window.to, 'medium')}`}` : 'No campaign',
    meta: [churchMeta()]
  });

  if (!campaign) {
    paragraph(doc, 'No Giving Board campaign has been set up, so there is nothing to report yet.');
    finishDocument(doc);
    return doc;
  }

  const progress = campaignProgress(campaign);
  const payments = campaignPayments(campaign.id, { limit: 2000 });
  const outstanding = outstandingClaims(campaign.id);
  const currency = campaign.currency;

  summaryCards(doc, [
    { label: 'Dates claimed', value: `${progress.claimed} / ${progress.totalDates}` },
    { label: 'Members taking part', value: progress.participants },
    { label: 'Committed', value: formatMoney(progress.committed, currency) || '—' },
    { label: 'Collected', value: formatMoney(progress.collected, currency) || '—' }
  ]);

  progressBar(doc, {
    label: 'Dates claimed on the board',
    value: progress.claimed,
    total: progress.totalDates,
    note: `${progress.percentClaimed}% of ${progress.totalDates} dates · ${progress.available} still available`
  });

  if (progress.committed > 0) {
    progressBar(doc, {
      label: 'Collected against commitments',
      value: progress.collected,
      total: progress.committed,
      note: `${formatMoney(progress.collected, currency)} of ${formatMoney(progress.committed, currency)}`
        + ` · ${formatMoney(Math.max(progress.committed - progress.collected, 0), currency)} outstanding`
    });
  }

  breakdownChart(doc, {
    title: 'Commitments by payment status',
    rows: Object.entries(progress.byPayment).map(([status, count]) => ({
      label: PAYMENT_LABELS[status] || status,
      value: count,
      colour: status === 'paid' ? INK.green : status === 'not_paid' ? INK.red : INK.gold
    }))
  });

  note(doc, 'A claimed date records a commitment towards CCIQ\u2019s participation. It is not a '
    + 'payment. Amounts collected are recorded separately as they are received.');

  /*
   * Every commitment on this board, whatever its balance. A day that has
   * already been paid in full is still a real Giving Board record and belongs
   * here alongside the ones still owing — dropping it once its balance
   * reaches zero would understate how much of the board is actually settled.
   */
  const allClaims = allClaimsWithBalance(campaign.id);
  if (allClaims.length) {
    heading(doc, 'All commitments');
    table(doc, {
      columns: [
        { label: 'Board date', weight: 0.9, value: (c) => formatDate(c.claim_date, 'medium') },
        {
          label: 'Member',
          weight: 1.7,
          value: (c) => [c.preferred_name || c.first_name, c.last_name].filter(Boolean).join(' ') || '—'
        },
        { label: 'Member ID', weight: 0.9, value: (c) => c.member_code || '—' },
        { label: 'Committed', weight: 1, align: 'right', value: (c) => formatMoney(c.commitment_amount, currency) || '—' },
        { label: 'Paid', weight: 0.9, align: 'right', value: (c) => formatMoney(c.paid, currency) },
        { label: 'Balance', weight: 1, align: 'right', bold: true, value: (c) => formatMoney(c.outstanding, currency) },
        { label: 'Status', weight: 1.1, value: (c) => PAYMENT_LABELS[c.payment_status] || c.payment_status },
        { label: 'Claimed on', weight: 0.9, value: (c) => formatDate(c.claimed_at ? qatarDateOf(c.claimed_at) : null, 'medium') || '—' },
        { label: 'Claimed by', weight: 1.2, value: (c) => c.claimed_by_name || '—' }
      ],
      rows: allClaims
    });
    note(doc, `${allClaims.length} commitment${allClaims.length === 1 ? '' : 's'} on this board in total, `
      + `including ${allClaims.length - outstanding.length} already settled in full.`);
  }

  if (payments.length) {
    heading(doc, 'Payments received');
    table(doc, {
      caption: 'Every payment recorded against this campaign, most recent first.',
      columns: [
        { label: 'Received', weight: 1, value: (p) => formatDate(p.paid_on, 'medium') },
        {
          label: 'Member',
          weight: 1.8,
          value: (p) => [p.preferred_name || p.first_name, p.last_name].filter(Boolean).join(' ') || '—'
        },
        { label: 'For date', weight: 1, value: (p) => formatDate(p.claim_date, 'medium') },
        { label: 'Amount', weight: 1, align: 'right', bold: true, value: (p) => formatMoney(p.amount, currency) },
        { label: 'Method', weight: 1, value: (p) => (p.method || '').replace('_', ' ') },
        { label: 'Reference', weight: 1.2, value: (p) => p.reference || '—' },
        { label: 'Received by', weight: 1.3, value: (p) => p.received_by_name || p.recorded_by_name || '—' }
      ],
      rows: payments
    });
  }

  finishDocument(doc);
  return doc;
}

/**
 * Everything church leadership actually asks about First Timers: how many
 * came, how many are still coming, how many joined, how many did not
 * continue, who invited them, and how each person's own invitees are doing —
 * paid and unpaid outcomes together, not only the ones needing attention.
 */
export function firstTimersPdf({ from = null, to = null, state = null, inviterId = null } = {}) {
  const graceDays = Number(getSetting('visitors.follow_up_days')) || 21;
  const report = firstTimersReportData({ from, to, state, inviterId, graceDays });

  const rangeLabel = from || to
    ? `${from ? formatDate(from, 'medium') : 'the start'} to ${to ? formatDate(to, 'medium') : 'today'}`
    : 'All time';

  const doc = createDocument({
    title: 'First Timers Report',
    subtitle: rangeLabel,
    meta: [churchMeta()]
  });

  if (report.total === 0) {
    paragraph(doc, 'No First Timers match these filters.');
    finishDocument(doc);
    return doc;
  }

  summaryCards(doc, [
    { label: 'Total First Timers', value: String(report.total) },
    { label: 'Still visiting', value: String(report.stillVisiting) },
    { label: 'Became members', value: String(report.joined) },
    { label: 'Needing follow-up', value: String(report.needsFollowUp) }
  ]);

  progressBar(doc, {
    value: report.joined, total: report.total, label: 'Conversion — became members',
    note: `${report.joined} of ${report.total} (${report.conversionRate}%)`
  });
  progressBar(doc, {
    value: report.stillVisiting + report.joined, total: report.total, label: 'Retention — still visiting or joined',
    note: `${report.stillVisiting + report.joined} of ${report.total} (${report.retentionRate}%)`
  });

  heading(doc, 'What happened');
  breakdownChart(doc, {
    total: report.total,
    rows: [
      { label: 'Still visiting', value: report.stillVisiting, color: INK.sky },
      { label: 'Became members', value: report.joined, color: INK.navySoft },
      { label: 'Did not continue', value: report.didNotContinue, color: INK.line },
      { label: 'Needing follow-up', value: report.needsFollowUp, color: INK.gold }
    ]
  });

  heading(doc, 'Follow-up status');
  table(doc, {
    columns: [
      { key: 'label', label: 'Status', weight: 1.4 },
      { key: 'n', label: 'First Timers', weight: 1, align: 'right' }
    ],
    rows: Object.entries(report.byFollowUp).map(([key, n]) => ({ label: FOLLOW_UP_LABELS[key] || key, n: String(n) }))
  });

  if (report.inviters.length) {
    heading(doc, 'Who is inviting people');
    table(doc, {
      columns: [
        { key: 'name', label: 'Member', weight: 1.6 },
        { key: 'invited', label: 'Invited', weight: 0.8, align: 'right' },
        { key: 'stillVisiting', label: 'Still visiting', weight: 1, align: 'right' },
        { key: 'joined', label: 'Became members', weight: 1, align: 'right' },
        { key: 'lapsed', label: 'Did not continue', weight: 1, align: 'right' }
      ],
      rows: report.inviters.map((r) => ({
        name: r.name,
        invited: String(r.invited),
        stillVisiting: String(r.stillVisiting),
        joined: String(r.joined),
        lapsed: String(r.lapsed)
      })),
      totals: {
        name: 'All inviters',
        invited: String(report.inviters.reduce((a, r) => a + r.invited, 0)),
        stillVisiting: String(report.inviters.reduce((a, r) => a + r.stillVisiting, 0)),
        joined: String(report.inviters.reduce((a, r) => a + r.joined, 0)),
        lapsed: String(report.inviters.reduce((a, r) => a + r.lapsed, 0))
      }
    });
    note(doc, 'This is a record of hospitality, not a performance measure.');
  }

  finishDocument(doc, { confidential: true });
  return doc;
}
/**
 * Every commitment for the campaign, completed ones included — the point of
 * this report is to show what the whole campaign has actually raised, not
 * only who still owes something.
 */
export function faithPromisePdf({ campaignId, status = null } = {}) {
  const campaign = getCampaign(campaignId);
  if (!campaign) throw Object.assign(new Error('No Faith Promise campaign found.'), { status: 404 });

  const report = faithPromiseData(campaignId, { status });

  const doc = createDocument({
    title: campaign.name,
    // The campaign's own months, and the status filter when one is chosen, so a filtered page is never read as the whole campaign.
    subtitle: `${formatDate(campaign.start_date, 'month')} to ${formatDate(campaign.end_date, 'month')}${status ? ` · ${FP_STATUS_LABELS[status] || status} commitments only` : ''}`,
    meta: [churchMeta()]
  });

  if (report.totalMembers === 0) {
    paragraph(doc, status
      ? `No ${(FP_STATUS_LABELS[status] || status).toLowerCase()} commitments in this campaign.`
      : 'No commitments have been submitted yet.');
    finishDocument(doc);
    return doc;
  }

  summaryCards(doc, [
    { label: 'Members committed', value: String(report.totalMembers) },
    { label: 'Total committed', value: formatMoney(report.totalCommitted, campaign.currency) },
    { label: 'Total received', value: formatMoney(report.totalReceived, campaign.currency) },
    { label: 'Total outstanding', value: formatMoney(report.totalOutstanding, campaign.currency) }
  ]);

  progressBar(doc, {
    value: report.totalReceived, total: report.totalCommitted, label: 'Received against what was committed',
    note: `${formatMoney(report.totalReceived, campaign.currency)} of ${formatMoney(report.totalCommitted, campaign.currency)}`
  });

  heading(doc, 'Completed vs outstanding');
  breakdownChart(doc, {
    total: report.totalMembers,
    rows: [
      { label: 'Completed', value: report.completedCount, color: INK.navySoft },
      { label: 'Outstanding', value: report.outstandingCount, color: INK.gold }
    ]
  });

  heading(doc, 'Every commitment');
  // The figures are the CURRENT commitments. A commitment an administrator amended is marked, and says so once, so the report is never read as "what was first promised".
  const amended = fpAmendedIds(campaignId);
  if (amended.size > 0) {
    note(doc, `${amended.size} commitment${amended.size === 1 ? ' was' : 's were'} amended by the Church Administration after ${amended.size === 1 ? 'it was' : 'they were'} first made and ${amended.size === 1 ? 'is' : 'are'} marked "amended". Every figure here is the current commitment; payments received are unchanged, and each commitment's page keeps what it was and why it changed.`);
  }
  table(doc, {
    columns: [
      { key: 'name', label: 'Member', weight: 1.5 },
      { key: 'committed', label: 'Commitment', weight: 1, align: 'right' },
      { key: 'frequency', label: 'Frequency', weight: 0.9 },
      { key: 'paid', label: 'Paid', weight: 1, align: 'right' },
      { key: 'balance', label: 'Balance', weight: 1, align: 'right' },
      { key: 'status', label: 'Status', weight: 0.9 }
    ],
    rows: report.rows.map((r) => ({
      name: amended.has(r.id) ? `${r.name} (amended)` : r.name,
      committed: formatMoney(r.expected_total, campaign.currency),
      frequency: FP_FREQUENCY_LABELS[r.frequency] || r.frequency,
      paid: formatMoney(r.amount_collected, campaign.currency),
      balance: formatMoney(Math.max(r.expected_total - r.amount_collected, 0), campaign.currency),
      status: FP_STATUS_LABELS[r.status] || r.status
    })),
    totals: {
      name: 'All commitments',
      committed: formatMoney(report.totalCommitted, campaign.currency),
      frequency: '',
      paid: formatMoney(report.totalReceived, campaign.currency),
      balance: formatMoney(report.totalOutstanding, campaign.currency),
      status: ''
    }
  });

  finishDocument(doc, { confidential: true });
  return doc;
}
