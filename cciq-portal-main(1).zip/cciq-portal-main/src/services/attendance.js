import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { looksLikePhone, maskPhone, phoneKey, phoneMatches } from '../lib/phone.js';
import { today, nowIso, lastFridayOnOrBefore, qatarDateOf } from '../lib/dates.js';
import { fullName, DEFAULT_ROSTER_STATUSES, changeStatus } from './members.js';
import { recordVisit } from './visitors.js';
import { serviceHeadcounts } from './service-headcount.js';
import { familyGroupForMember, getFamilyGroup } from './family-groups.js';
import { getCurrentOperationalFridayService } from './friday-service.js';
import { recordAudit } from '../lib/audit.js';
import { isFridayService, finalizationStateOf, classifySession, hasExpectedSnapshot } from './attendance-tracking.js';
import { OUTCOME_DISPLAY_LABELS, resolveOutcome, expectedRosterForSession } from './attendance-outcomes.js';

export { DEFAULT_ROSTER_STATUSES };

export const ATTENDANCE_STATUSES = ['present', 'absent', 'excused', 'visitor'];

/**
 * The one gate every attendance-mutating entry point must pass before
 * writing anything - recordAttendance(), recordAttendanceForPeople(), and
 * confirmCheckin() all call this, rather than each re-deriving its own
 * notion of "is this session writable." A red-team review found several
 * alternate routes (the search-and-add screen, the QR front-door confirm
 * step reached with a raw client-supplied session_id) writing into
 * cancelled sessions, and confirm specifically writing into sessions that
 * were never even Friday Service at all. Centralizing this here means a
 * future entry point inherits the same protection automatically instead
 * of needing to remember to re-check it - the specific route/UI a
 * mutation arrived through must never be what makes it safe.
 *
 * Session-type and actor/member-scope authorization are NOT here - those
 * vary by entry point (a Cell Group Leader's own-group restriction only
 * applies to some of them) and stay in the route layer. This is strictly
 * about whether the *session itself* is in a state that can ever be
 * legitimately mutated, independent of who is asking.
 */
export function assertSessionMutable(session, { correction = false } = {}) {
  if (!session) return { ok: false, reason: 'session_not_found' };
  if (session.status === 'cancelled') return { ok: false, reason: 'session_cancelled' };
  if (session.service_date > today()) return { ok: false, reason: 'session_in_future' };

  /*
   * The finalization lifecycle (Attendance Go-Live & Finalization). Once a
   * Friday has been finalized or marked "attendance not taken", NO ordinary
   * entry point may write to it - not the register, not search-and-add, not
   * the kiosk, QR or family flow, not a spreadsheet import - whoever is asking
   * and however the request arrived. Only a controlled correction (a
   * finalized Friday, `correction: true`, reached solely through
   * correctFinalizedAttendance() in attendance-lifecycle.js, which requires
   * attendance.finalize and a reason) may change a finalized Friday, and
   * only reopening restores ordinary writes. This is enforced here, centrally,
   * so a future entry point inherits it; hiding a button is never the guard.
   *
   * A Friday that is not tracked (before the Go-Live date, or tracking not
   * started) has no finalization state and behaves exactly as it always did.
   */
  if (isFridayService(session)) {
    if (session.finalization_state === undefined) {
      // Fail closed: judging finalization from a partial row would silently
      // let a write through. Callers must pass the whole attendance_sessions row.
      throw new Error('assertSessionMutable needs the full attendance_sessions row (finalization_state is missing)');
    }
    const state = finalizationStateOf(session);
    if (state === 'not_taken') return { ok: false, reason: 'session_not_taken' };
    if (state === 'finalized' && !correction) return { ok: false, reason: 'session_finalized' };
    if (correction && state !== 'finalized') return { ok: false, reason: 'not_finalized' };
  } else if (correction) {
    return { ok: false, reason: 'not_finalized' };
  }
  return { ok: true };
}

/**
 * Whether `session` is THIS week's operational Friday Service, for
 * decisions (specifically Temporarily Away auto-return) that must never
 * silently reach back into an arbitrary earlier week. Deliberately
 * different from getLatestFridayService()'s own "most recent non-cancelled"
 * fallback — that one is used by the live check-in flow, which has its own
 * reason to keep working against a real past Friday if this week's was
 * merely cancelled. Here, if this week's own Friday is missing or
 * cancelled, the answer is simply "no" — never "fall back further." A
 * red-team review found the unbounded fallback let a cancelled current
 * Friday cause an auto-return to fire against a session weeks old.
 */
export function isOperationalFridaySession(session) {
  if (!session || session.service_type !== 'friday_service') return false;
  if (session.status === 'cancelled') return false;
  return session.service_date === lastFridayOnOrBefore(today());
}

/*
 * "Vacation" is the label the church actually uses for this outcome; the
 * stored value stays 'excused' everywhere — the database column, the CHECK
 * constraint, every historical row — so nothing here required a migration or
 * a rewrite of existing attendance history. Only this one label changed.
 */
export const ATTENDANCE_LABELS = {
  present: 'Present',
  absent: 'Absent',
  excused: 'Vacation',
  visitor: 'Visitor',
  not_recorded: 'Not recorded',
  // Tracked-Friday display states (see attendance-outcomes.js)
  ...OUTCOME_DISPLAY_LABELS
};

/**
 * A stable one-letter abbreviation for a compact attendance grid cell —
 * deliberately its own map, not simply the label's first letter: "Vacation"
 * and "Visitor" now share a first letter, which label.charAt(0) would
 * silently collide on the moment either label's wording changes again.
 */
export const ATTENDANCE_GLYPHS = {
  present: 'P',
  absent: 'A',
  excused: 'E',
  visitor: 'V',
  not_recorded: 'N',
  pending: '…',
  awaiting_finalization: 'W',
  not_expected: '–',
  not_taken: 'X',
  cancelled: 'C',
  not_tracked: '–'
};

// DEFAULT_ROSTER_STATUSES itself lives in services/members.js (see the
// comment there) — re-exported above so existing imports from this file
// keep working. Excluding Attendee/Bonafide from it was the bug behind
// A member going missing from the Friday Service sheet.
const ROSTER_STATUS_SQL = DEFAULT_ROSTER_STATUSES.map((s) => `'${s}'`).join(',');


/*
 * The attendance READ MODELS (follow-up, Long Absence, member history, session
 * and cell-group summaries, the attendance report) live in
 * attendance-consumers.js, which resolves what attendance means through
 * attendance-outcomes.js. They are re-exported here so every existing import
 * keeps working. The WRITE path (recording, the session gate, session status)
 * stays in this file.
 */
export {
  consecutiveMissedFridays, lastAttendedFriday, trackedFridayContexts, memberAttendanceSummary,
  memberAttendanceHistory, sessionSummary, FOLLOWUP_SORT_COLUMNS, followUpList, followUpStatus,
  LONG_ABSENCE_SORT_COLUMNS, longAbsenceList, longAbsenceReview, latestServiceOverview, attendanceTrend,
  awaitingFinalizationFridays, attendanceOverview, pendingFridayServices, cellGroupBreakdown,
  cellGroupAttendanceSummary, ATTENDANCE_REPORT_SORT_COLUMNS, parseAttendanceStatusFilter,
  attendanceReport, attendanceReportCsv
} from './attendance-consumers.js';


// ===========================================================================
// Recording, sessions and reporting
// ===========================================================================

export const SESSION_STATUSES = ['scheduled', 'held', 'cancelled'];

/**
 * A session only ever flips from 'scheduled' to 'held' in the database once
 * at least one attendance record has actually been saved through the normal
 * recording form (see the UPDATE ... SET status = 'held' near the bottom of
 * this file). That leaves a real gap: a past Friday Service nobody has
 * opened yet still reads 'scheduled' in the database, which looks like a
 * service that hasn't happened, not one that's overdue for its register to
 * be filled in.
 *
 * Rather than adding a fourth stored status (the two-value scheduled/held
 * distinction is sufficient for the data model, and every place that reads
 * or writes attendance_sessions.status keeps working exactly as it does
 * today), this derives an accurate *display* state from data already on
 * hand: the session's own status/date plus its already-computed summary.
 * `summary.recorded` alone decides "held" here — more robust than trusting
 * the stored status flipped correctly, and correct even for a record that
 * reached the database some other way than the main recording form.
 */
export function sessionDisplayStatus(session, summary) {
  if (session.status === 'cancelled') {
    return { key: 'cancelled', label: 'Cancelled', pill: 'archived' };
  }
  // A tracked Friday shows its lifecycle, never "attendance pending" merely
  // because nobody has recorded anything.
  const phase = summary && summary.phase;
  if (phase === 'finalized') return { key: 'finalized', label: 'Finalized', pill: 'active' };
  if (phase === 'not_taken') return { key: 'not_taken', label: 'Attendance not taken', pill: 'archived' };
  if (phase === 'awaiting_finalization') return { key: 'awaiting', label: 'Awaiting finalization', pill: 'pending' };
  if (phase === 'open') return { key: 'open', label: 'Open', pill: 'pending' };
  if (phase === 'pre_go_live' || phase === 'not_started') {
    return { key: 'not_tracked', label: session.service_date > today() ? 'Scheduled' : 'Not tracked', pill: 'inactive' };
  }
  if (session.status === 'held' || (summary && summary.recorded > 0)) {
    return { key: 'held', label: 'Held', pill: 'active' };
  }
  if (session.service_date < today()) {
    return { key: 'pending', label: 'Attendance pending', pill: 'pending' };
  }
  return { key: 'scheduled', label: 'Scheduled', pill: 'pending' };
}

/**
 * The roster for a session: every member who should be considered, with the
 * status already recorded for them. Members with nothing recorded come back as
 * 'not_recorded', which is deliberately distinct from 'absent'.
 *
 * For a Friday whose expected-roster snapshot exists (finalized, or reopened
 * after finalizing) the snapshot IS the default roster - today's member
 * statuses are never consulted again, so later status changes cannot rewrite
 * that Friday's sheet. For a tracked Friday each row also carries the
 * canonical outcome (attendance-outcomes.js): `expected`, `outcome` (state),
 * `displayStatus` (a key attendanceLabels understands), `derived`. The raw
 * `status` field is unchanged - it is what the recording form edits.
 */
export function sessionRoster(sessionId, { cellGroupId = null, search = '', restrictToGroupIds = null } = {}) {
  const session = getSession(sessionId);
  if (!session) return [];
  const groupFilter = cellGroupId ?? session.cell_group_id ?? null;

  // A leader sees only the members of the groups they lead, whatever filter
  // they ask for. An empty list of groups means an empty sheet.
  let restrictClause = '';
  const restrictParams = {};
  if (Array.isArray(restrictToGroupIds)) {
    if (restrictToGroupIds.length === 0) return [];
    const ids = restrictToGroupIds.map((id, i) => {
      restrictParams[`grp${i}`] = Number(id);
      return `@grp${i}`;
    });
    restrictClause = ` AND m.cell_group_id IN (${ids.join(',')})`;
  }

  const classification = classifySession(session);
  const useSnapshot = classification.isFriday && hasExpectedSnapshot(sessionId);
  const defaultRoster = useSnapshot
    // The historical expected roster, exactly as it was when the Friday was finalized.
    ? `m.id IN (SELECT member_id FROM attendance_expected WHERE session_id = @sessionId)`
    // The current normal roster, old enough a member to be expected at this service.
    : `(m.status IN (${ROSTER_STATUS_SQL}) AND (m.date_joined IS NULL OR m.date_joined <= @serviceDate))`;

  const rows = query(
    `SELECT m.id, m.member_code, m.first_name, m.last_name, m.preferred_name, m.status AS member_status,
            m.photo_path, m.photo_updated_at, m.date_joined, m.date_of_birth, m.age_group, m.cell_group_id,
            g.name AS cell_group_name,
            r.status AS attendance_status, r.notes AS attendance_notes, r.recorded_at
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
       LEFT JOIN attendance_records r ON r.member_id = m.id AND r.session_id = @sessionId
      WHERE (
        -- The default roster (see above).
        ${defaultRoster}
        -- Plus anyone already recorded for this specific session, whatever
        -- their status or join date — someone added through the status-blind
        -- search stays visible on this session's sheet from then on, without
        -- ever being added to every other session's default roster.
        OR EXISTS (
          SELECT 1 FROM attendance_records r2
           WHERE r2.session_id = @sessionId AND r2.member_id = m.id
        )
      )
        AND (@groupFilter IS NULL OR @groupFilter = 0 OR m.cell_group_id = @groupFilter)
        AND (@search = '' OR m.first_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\'
             OR m.preferred_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
             OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\')
        ${restrictClause}
      ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE`,
    {
      sessionId,
      groupFilter,
      search: search || '',
      like: likePattern(search),
      serviceDate: session.service_date,
      ...restrictParams
    }
  );

  let roster = null;
  if (classification.tracked && !['cancelled', 'not_taken'].includes(classification.phase)) {
    roster = expectedRosterForSession(session);
  }
  return rows.map((row) => {
    const base = { ...row, status: row.attendance_status || 'not_recorded' };
    if (!roster) return base;
    const expected = roster.expected.has(row.id) ? true : (roster.ambiguous.some((a) => a.memberId === row.id) ? null : false);
    const resolved = resolveOutcome({ phase: classification.phase, expected, rowStatus: row.attendance_status || null });
    return { ...base, expected: resolved.expected, outcome: resolved.state, displayStatus: resolved.token, derived: resolved.derived };
  });
}

export function getSession(sessionId) {
  return queryOne(
    `SELECT s.*, g.name AS cell_group_name
       FROM attendance_sessions s
       LEFT JOIN cell_groups g ON g.id = s.cell_group_id
      WHERE s.id = @id`,
    { id: sessionId }
  ) || null;
}

/**
 * "Temporarily Away" means still associated with CCIQ, just temporarily
 * absent — so a confirmed Friday Service Present is direct operational
 * confirmation the person is back. Called from every place that can write a
 * confirmed Present (the recording sheet, QR/confirmCheckin, and the shared
 * search/family/kiosk recorder), inside their existing transaction, so
 * attendance and the lifecycle restoration commit or roll back together.
 *
 * `sessionDate` is the service_date of the session being confirmed, and is
 * required: a red-team review found that a member who went Temporarily
 * Away partway through the current operational week could still have an
 * *earlier* Friday within that same still-current week corrected to
 * Present, incorrectly restoring them - the correction is stale evidence
 * from before they left, not confirmation they're back. Requiring the
 * session to be on or after the member's most recent transition into
 * Temporarily Away closes that regardless of which entry point the
 * confirmation came through.
 *
 * Never guesses: the status restored is whatever `member_status_history`
 * shows immediately preceded this Temporarily Away period, and only when
 * that previous status is one of the ordinary "currently engaged"
 * statuses (DEFAULT_ROSTER_STATUSES — active/pending/attendee/bonafide).
 * Anything else — no history found, or a previous status this rule was
 * never meant to restore into (inactive, returned home, migrated,
 * transferred, archived, other) — leaves the member exactly as Temporarily
 * Away and records an audit entry instead, for a person to review, rather
 * than assign a status nobody actually confirmed. See CCIQ_DECISIONS.md.
 *
 * Naturally idempotent: it only acts when the member's *current* status is
 * still `temporarily_away`, so a duplicate scan, a repeated save, or two
 * concurrent confirmations for the same person after the first one already
 * restored them simply find nothing left to do.
 */
export function maybeReturnFromTemporarilyAway(memberId, sessionDate, { userId = null } = {}) {
  const member = queryOne('SELECT id, status FROM members WHERE id = @id', { id: memberId });
  if (!member || member.status !== 'temporarily_away') return { restored: false };

  const lastTransition = queryOne(
    `SELECT previous_status, changed_at FROM member_status_history
      WHERE member_id = @id AND new_status = 'temporarily_away'
      ORDER BY changed_at DESC, id DESC LIMIT 1`,
    { id: memberId }
  );
  const candidate = lastTransition ? lastTransition.previous_status : null;
  // Codex/independent verification: changed_at is a UTC timestamp
  // (nowIso()). Qatar is UTC+3 with no DST, so any change from roughly
  // 21:00 UTC onward already falls on the NEXT day in Qatar - slicing the
  // raw ISO string's first 10 characters silently used the wrong calendar
  // for this comparison, undercounting exactly that window. qatarDateOf()
  // converts to the calendar that actually governs "which Friday this
  // happened relative to," matching how service_date itself is generated.
  const transitionDate = lastTransition ? qatarDateOf(lastTransition.changed_at) : null;

  if (transitionDate && sessionDate < transitionDate) {
    // Stale evidence: this session happened before the member's most
    // recent move to Temporarily Away, so confirming it now says nothing
    // about whether they're back - leave them exactly as they are, no
    // audit noise, since this is an ordinary historical correction, not an
    // ambiguous or suspicious case.
    return { restored: false, staleEvidence: true };
  }

  if (transitionDate && sessionDate === transitionDate) {
    // Same Qatar calendar day: service_date carries no time of day, so
    // there is no way to tell whether the Friday service actually happened
    // before or after the moment the member was marked Temporarily Away
    // that same day - equal dates alone are not evidence of a return, only
    // evidence that we can't order these two events. Flagged for a human to
    // review, the same as the "previous status unknown" case below, rather
    // than either silently returning them (which could be reinstating
    // someone who went Away BEFORE that Friday's service) or silently doing
    // nothing (which could miss a genuine same-day return).
    recordAudit({
      userId,
      action: 'member.temporarily_away_return_ambiguous',
      entityType: 'member',
      entityId: memberId,
      detail: {
        note: 'Confirmed Friday Present while Temporarily Away, on the same Qatar calendar date as the '
          + 'Temporarily Away transition - order of events could not be determined, so this was left as '
          + 'Temporarily Away for manual review.',
        session_date: sessionDate,
        transition_date: transitionDate
      }
    });
    return { restored: false, sameDayAmbiguous: true };
  }

  if (!candidate || !DEFAULT_ROSTER_STATUSES.includes(candidate)) {
    recordAudit({
      userId,
      action: 'member.temporarily_away_return_ambiguous',
      entityType: 'member',
      entityId: memberId,
      detail: {
        note: 'Confirmed Friday Present while Temporarily Away, but the status before '
          + 'Temporarily Away could not be safely determined — left as Temporarily Away.',
        found_previous_status: candidate
      }
    });
    return { restored: false, ambiguous: true };
  }

  changeStatus(memberId, candidate, {
    userId,
    reason: 'Automatically returned from Temporarily Away after confirmed Friday Service attendance.'
  });
  recordAudit({
    userId,
    action: 'member.temporarily_away_auto_returned',
    entityType: 'member',
    entityId: memberId,
    detail: { restored_to: candidate }
  });
  return { restored: true, status: candidate };
}

/**
 * Saves a set of outcomes for one session. Choosing 'not_recorded' removes the
 * record rather than storing an outcome, so the difference between "absent"
 * and "nobody recorded this" is never lost.
 */
export function recordAttendance(sessionId, entries, { userId = null, correction = false } = {}) {
  const at = nowIso();
  let saved = 0;
  let cleared = 0;

  // Temporarily Away auto-return is a Friday Service rule specifically — a
  // Cell Group meeting uses this exact same function and table (only
  // `service_type` differs), and must never be able to satisfy it. It is
  // also a *bounded operational-week* rule, not literally today's calendar
  // date: this week's Friday Service stays current through the following
  // Thursday even though its service_date is a few days in the past by
  // then, which is what keeps an admin entering Friday's attendance on the
  // following Monday able to trigger this rule. But it never falls back to
  // an *older* week — if this week's own Friday is missing or cancelled,
  // nothing is current, full stop; see isOperationalFridaySession(), which
  // deliberately does not share getLatestFridayService()'s unbounded
  // "most recent non-cancelled" fallback. See CCIQ_DECISIONS.md.
  const session = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
  const mutable = assertSessionMutable(session, { correction });
  if (!mutable.ok) return { ok: false, reason: mutable.reason, saved: 0, cleared: 0 };

  const isCurrentFridayService = isOperationalFridaySession(session);

  let refusedLate = null;
  transaction(() => {
    // The gate above was read before this write lock was taken. A finalization (or "attendance not taken") committed by another process in between must
    // still stop this write, so the session is read again HERE, inside the immediate transaction, and refused if it is no longer writable.
    const fresh = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
    const again = assertSessionMutable(fresh, { correction });
    if (!again.ok) { refusedLate = again.reason; return; }
    for (const entry of entries) {
      const memberId = Number(entry.memberId);
      if (!memberId) continue;

      if (!ATTENDANCE_STATUSES.includes(entry.status)) {
        const result = execute(
          'DELETE FROM attendance_records WHERE session_id = @sessionId AND member_id = @memberId',
          { sessionId, memberId }
        );
        cleared += result.changes;
        continue;
      }

      // `source` is only ever stamped by a controlled correction; an ordinary
      // edit of an existing row keeps whatever source it already had.
      execute(
        `INSERT INTO attendance_records (session_id, member_id, status, notes, recorded_at, recorded_by, source)
         VALUES (@sessionId, @memberId, @status, @notes, @at, @by, @source)
         ON CONFLICT(session_id, member_id) DO UPDATE SET
           status = excluded.status, notes = excluded.notes,
           recorded_at = excluded.recorded_at, recorded_by = excluded.recorded_by,
           source = CASE WHEN @isCorrection = 1 THEN excluded.source ELSE attendance_records.source END`,
        {
          sessionId, memberId, status: entry.status, notes: entry.notes || null, at, by: userId,
          source: correction ? 'correction' : 'manual', isCorrection: correction ? 1 : 0
        }
      );
      saved += 1;

      if (isCurrentFridayService && entry.status === 'present') {
        maybeReturnFromTemporarilyAway(memberId, session.service_date, { userId });
      }
    }

    // Recording attendance means the service happened.
    execute(
      `UPDATE attendance_sessions SET status = 'held'
        WHERE id = @id AND status = 'scheduled' AND @saved > 0`,
      { id: sessionId, saved }
    );
  })();
  if (refusedLate) return { ok: false, reason: refusedLate, saved: 0, cleared: 0 };

  return { ok: true, saved, cleared };
}

export function setSessionStatus(sessionId, status, { userId = null, notes = null } = {}) {
  if (!SESSION_STATUSES.includes(status)) return null;
  execute(
    'UPDATE attendance_sessions SET status = @status, notes = COALESCE(@notes, notes) WHERE id = @id',
    { id: sessionId, status, notes }
  );
  return getSession(sessionId);
}

export function updateSession(sessionId, data) {
  execute(
    `UPDATE attendance_sessions SET
       service_date = COALESCE(@service_date, service_date),
       start_time = @start_time,
       location = @location,
       title = COALESCE(@title, title),
       counts_toward_followup = @counts_toward_followup,
       notes = @notes
     WHERE id = @id`,
    {
      id: sessionId,
      service_date: data.service_date || null,
      start_time: data.start_time || null,
      location: data.location || null,
      title: data.title || null,
      counts_toward_followup: data.counts_toward_followup ? 1 : 0,
      notes: data.notes || null
    }
  );
  return getSession(sessionId);
}

/**
 * Sessions other than the weekly Friday Service: cell group meetings and
 * special events. These never affect the Friday Service follow-up count.
 */
export function createSession(data, { userId = null } = {}) {
  const result = execute(
    `INSERT INTO attendance_sessions
       (service_date, service_type, title, start_time, location, cell_group_id, status,
        counts_toward_followup, notes, created_at, created_by)
     VALUES (@service_date, @service_type, @title, @start_time, @location, @cell_group_id, 'scheduled',
             @counts, @notes, @at, @by)`,
    {
      service_date: data.service_date,
      service_type: data.service_type || 'special_service',
      title: data.title,
      start_time: data.start_time || null,
      location: data.location || null,
      cell_group_id: data.cell_group_id || 0,
      counts: 0,
      notes: data.notes || null,
      at: nowIso(),
      by: userId
    }
  );
  return getSession(Number(result.lastInsertRowid));
}

/** What the History table may be sorted by, and the SQL each one maps to. */
export const SESSION_SORT_COLUMNS = {
  date: 's.service_date',
  session: 's.title COLLATE NOCASE',
  type: 's.service_type',
  status: 's.status',
  present: 'present',
  recorded: 'recorded'
};

/**
 * Columns that come from the one headcount definition (service-headcount.js) rather than from a query of their own. Sorting by one means working out
 * every matching service's headcount first (two queries, however many services), then ordering and paging here.
 */
const HEADCOUNT_SORTS = { members: 'members', first_timers: 'firstTimers', returning: 'returning', total: 'total' };
export const SESSION_SORT_KEYS = [...Object.keys(SESSION_SORT_COLUMNS), ...Object.keys(HEADCOUNT_SORTS)];

export function listSessions({
  serviceType = null, from = null, to = null, cellGroupId = null,
  status = null, page = 1, pageSize = 20, sort = 'date', direction = 'desc'
} = {}) {
  const params = {
    serviceType, from, to,
    cellGroupId: cellGroupId ?? null,
    status,
    limit: pageSize,
    offset: (page - 1) * pageSize
  };
  const where = `
    WHERE (@serviceType IS NULL OR s.service_type = @serviceType)
      AND (@from IS NULL OR s.service_date >= @from)
      AND (@to IS NULL OR s.service_date <= @to)
      AND (@cellGroupId IS NULL OR s.cell_group_id = @cellGroupId)
      AND (@status IS NULL OR s.status = @status)`;

  /*
   * The column and direction come from a fixed lookup rather than being
   * dropped straight into the query, so a request can never inject SQL through
   * the sort parameter. The date is always the tie-breaker, so two sessions
   * sorted by, say, status still fall back to date order within each group.
   */
  if (HEADCOUNT_SORTS[sort]) return listSessionsByHeadcount({ where, params, sort, direction, page, pageSize });
  const column = SESSION_SORT_COLUMNS[sort] || SESSION_SORT_COLUMNS.date;
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  const tieBreakDir = direction === 'asc' ? 'ASC' : 'DESC';
  const orderBy = column === SESSION_SORT_COLUMNS.date
    ? `s.service_date ${dir}, s.id ${dir}`
    : `${column} ${dir}, s.service_date ${tieBreakDir}, s.id ${tieBreakDir}`;

  const rows = query(
    `SELECT s.*, g.name AS cell_group_name,
            (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) AS recorded,
            (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status IN ('present','visitor')) AS present
       FROM attendance_sessions s
       LEFT JOIN cell_groups g ON g.id = s.cell_group_id
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    params
  );
  const total = queryOne(
    `SELECT COUNT(*) AS n FROM attendance_sessions s ${where}`,
    params
  ).n;

  return { rows: withHeadcounts(rows), total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/**
 * Adds the physical headcount to history rows: `members_present` (members with a Present row), `first_timers` and `total_present` - everyone who was there.
 * `present` and `recorded` keep their old meaning (marks on the register: Present or Visitor rows / every mark of any kind); they are not headcounts.
 */
function withHeadcounts(rows) {
  const counts = serviceHeadcounts(rows.map((r) => r.id));
  return rows.map((row) => {
    const c = counts.get(row.id) || { members: 0, firstTimers: 0, returning: 0, total: 0 };
    return { ...row, phase: classifySession(row).phase, members_present: c.members, first_timers: c.firstTimers, returning_visitors: c.returning, total_present: c.total };
  });
}

function listSessionsByHeadcount({ where, params, sort, direction, page, pageSize }) {
  const all = query(
    `SELECT s.*, g.name AS cell_group_name,
            (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) AS recorded,
            (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id AND r.status IN ('present','visitor')) AS present
       FROM attendance_sessions s
       LEFT JOIN cell_groups g ON g.id = s.cell_group_id
       ${where}`,
    { ...params, limit: -1, offset: 0 }
  );
  const counts = serviceHeadcounts(all.map((r) => r.id));
  const key = HEADCOUNT_SORTS[sort];
  const sign = direction === 'asc' ? 1 : -1;
  all.sort((a, b) => {
    const diff = (counts.get(a.id)?.[key] || 0) - (counts.get(b.id)?.[key] || 0);
    if (diff) return sign * diff;
    return sign * (a.service_date.localeCompare(b.service_date) || a.id - b.id);
  });
  const rows = all.slice((page - 1) * pageSize, page * pageSize);
  return { rows: withHeadcounts(rows), total: all.length, page, pages: Math.max(Math.ceil(all.length / pageSize), 1) };
}


// ---------------------------------------------------------------------------
// Cell group meetings
// ---------------------------------------------------------------------------

export const CELL_GROUP_MEETING = 'cell_group';

/**
 * A cell group meeting is recorded separately from the Friday Service. It has
 * its own session, its own register, and deliberately does not count towards
 * the consecutive-Friday follow-up rule: missing a midweek meeting is not the
 * same as being absent from the church gathering.
 */
export function createCellGroupMeeting(cellGroupId, { date, title = null, notes = null, startTime = null, location = null, userId = null }) {
  const existing = queryOne(
    `SELECT id FROM attendance_sessions
      WHERE service_type = @type AND service_date = @date AND cell_group_id = @groupId`,
    { type: CELL_GROUP_MEETING, date, groupId: cellGroupId }
  );
  if (existing) return { ok: false, reason: 'already_exists', sessionId: existing.id };

  const at = nowIso();
  const result = execute(
    `INSERT INTO attendance_sessions
       (service_date, service_type, title, start_time, location, cell_group_id, status,
        counts_toward_followup, notes, created_at, created_by)
     VALUES (@date, @type, @title, @startTime, @location, @groupId, 'held', 0, @notes, @at, @by)`,
    {
      date,
      type: CELL_GROUP_MEETING,
      title: title || 'Cell group meeting',
      startTime,
      location,
      groupId: cellGroupId,
      notes,
      at,
      by: userId
    }
  );
  return { ok: true, sessionId: Number(result.lastInsertRowid) };
}

export function cellGroupMeetings(cellGroupId, { limit = 20 } = {}) {
  return query(
    `SELECT s.*,
            (SELECT COUNT(*) FROM attendance_records r
              WHERE r.session_id = s.id AND r.status IN ('present','visitor')) AS present_count,
            (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id = s.id) AS recorded_count
       FROM attendance_sessions s
      WHERE s.service_type = @type AND s.cell_group_id = @groupId
      ORDER BY s.service_date DESC
      LIMIT @limit`,
    { type: CELL_GROUP_MEETING, groupId: cellGroupId, limit }
  );
}

/** Attendance at the group's own meetings, per member. */
export function cellGroupMeetingSummary(cellGroupId, { lastN = 8 } = {}) {
  const meetings = query(
    `SELECT id, service_date, title FROM attendance_sessions
      WHERE service_type = @type AND cell_group_id = @groupId AND status != 'cancelled'
      ORDER BY service_date DESC
      LIMIT @limit`,
    { type: CELL_GROUP_MEETING, groupId: cellGroupId, limit: lastN }
  ).reverse();

  const members = query(
    `SELECT id, member_code, first_name, last_name, preferred_name
       FROM members
      WHERE cell_group_id = @id AND status IN (${ROSTER_STATUS_SQL})
      ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE`,
    { id: cellGroupId }
  );

  if (meetings.length === 0 || members.length === 0) {
    return { meetings, rows: [], averageRate: null, totalPresent: 0 };
  }

  const records = query(
    `SELECT r.session_id, r.member_id, r.status
       FROM attendance_records r
      WHERE r.session_id IN (${meetings.map((_, i) => `@m${i}`).join(',')})`,
    Object.fromEntries(meetings.map((m, i) => [`m${i}`, m.id]))
  );

  const byMember = new Map();
  for (const record of records) {
    if (!byMember.has(record.member_id)) byMember.set(record.member_id, new Map());
    byMember.get(record.member_id).set(record.session_id, record.status);
  }

  let totalPresent = 0;
  const rows = members.map((member) => {
    const own = byMember.get(member.id) || new Map();
    const cells = meetings.map((meeting) => ({
      date: meeting.service_date,
      status: own.get(meeting.id) || 'not_recorded'
    }));
    const present = cells.filter((c) => c.status === 'present' || c.status === 'visitor').length;
    totalPresent += present;
    return {
      member,
      cells,
      present,
      rate: meetings.length ? Math.round((present / meetings.length) * 100) : null
    };
  });

  return {
    meetings,
    rows,
    totalPresent,
    averageRate: rows.length
      ? Math.round(rows.reduce((sum, r) => sum + (r.rate || 0), 0) / rows.length)
      : null
  };
}


// ===========================================================================
// Person search & quick-record attendance — the shared foundation behind the
// entrance check-in page (QR scan and search-by-name alike) and, later, a
// dedicated kiosk. Deliberately separate from sessionRoster() above:
// sessionRoster() manages the current active/pending congregation for a
// specific session's recording sheet, an existing workflow left exactly as
// it was. This search exists for a different question — "who is this
// person, whatever their current status" — so someone who moved away years
// ago and returns can still be found and recorded. See CCIQ_DECISIONS.md.
// ===========================================================================

const MAX_ATTENDANCE_SEARCH_RESULTS = 20;

/**
 * Finds a person to record attendance for — a member of any status, or a
 * visitor not yet converted to a member record — by formal first name,
 * middle name, surname, full formal name, nickname, or Member ID. Every
 * existing status is searched (active, inactive, pending, returned home,
 * migrated, and every other supported status): none is treated as
 * ineligible to attend again. Membership status itself is deliberately
 * never selected or returned here — this search identifies a person to
 * record attendance for, not a place to review their standing with the
 * church. A nickname only ever works as a way to *find* the right result;
 * the name shown back is always the member's formal recorded name
 * (fullName() in services/members.js), never the nickname, so nobody is
 * ever displayed under a name that is not their own.
 */
export function searchPeopleForAttendance(term, { limit = MAX_ATTENDANCE_SEARCH_RESULTS } = {}) {
  const clean = String(term || '').trim();
  if (clean.length < 2) return [];

  // A person is also found by their mobile number, but only by the WHOLE number, never by a fragment: members of any status and First Timers not yet linked to a member.
  // The number is compared through the one canonical phone key (lib/phone.js), so +974 7701 7992, 97477017992 and 77017992 are the same number. A number can be shared
  // by a household, so every match is returned. A phone-shaped term is never used as a name or code search, and the stored number is never returned: the desk sees only
  // the last four digits.
  if (looksLikePhone(clean)) return searchPeopleByPhone(clean, limit);

  const like = likePattern(clean);
  const visitorRows = query(
    `SELECT v.id, v.first_name, v.last_name, v.phone
       FROM visitors v
      WHERE v.member_id IS NULL
        AND (v.first_name LIKE @like ESCAPE '\\' OR v.last_name LIKE @like ESCAPE '\\'
             OR (v.first_name || ' ' || COALESCE(v.last_name, '')) LIKE @like ESCAPE '\\')
      ORDER BY v.last_name COLLATE NOCASE, v.first_name COLLATE NOCASE, v.id
      LIMIT @limit`,
    { like, limit }
  );

  // Members and First Timers share one list of at most `limit`. A First Timer is never crowded out by a full page of member matches:
  // up to VISITOR_RESERVED_SLOTS places are held for them, and any slot members leave unused goes to them too.
  const visitorQuota = Math.min(visitorRows.length, Math.max(VISITOR_RESERVED_SLOTS, 0), limit);
  const memberRows = query(
    `SELECT m.id, m.first_name, m.middle_name, m.last_name, m.preferred_name, m.member_code,
            m.photo_path, m.photo_updated_at, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.first_name LIKE @like ESCAPE '\\' OR m.middle_name LIKE @like ESCAPE '\\' OR m.last_name LIKE @like ESCAPE '\\'
         OR m.preferred_name LIKE @like ESCAPE '\\' OR m.member_code LIKE @like ESCAPE '\\'
         OR (m.first_name || ' ' || m.last_name) LIKE @like ESCAPE '\\'
         OR (m.first_name || ' ' || COALESCE(m.middle_name || ' ', '') || m.last_name) LIKE @like ESCAPE '\\'
      ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE, m.id
      LIMIT @limit`,
    { like, limit: limit - visitorQuota }
  );
  const visitorSlots = Math.min(visitorRows.length, limit - memberRows.length);

  const members = memberRows.map((m) => ({
    type: 'member',
    id: m.id,
    name: fullName(m),
    photoUrl: m.photo_path
      ? `/media/members/${m.id}/photo?v=${encodeURIComponent(m.photo_updated_at || '')}`
      : null,
    detail: [m.member_code, m.cell_group_name].filter(Boolean).join(' · ')
  }));

  // A First Timer who has not yet been converted to a member record — once
  // converted, they are found through the member search above instead, so
  // the same person never appears twice under two different identities.
  return [...members, ...visitorResults(visitorRows.slice(0, visitorSlots))];
}

/** Places in a search result list held for First Timers so a page of member matches cannot hide them. */
const VISITOR_RESERVED_SLOTS = 5;

/**
 * What a First Timer record is called at the desk. On their FIRST actual visit: "First Timer". Once they have visited before: "Returning \u00B7 Review pending" - the
 * same person, the same record, still waiting for the administrator's membership review (it ends only when that review converts, links or declines them, or an
 * administrator chose to continue them as a visitor). Never promoted to a member by attending again.
 * One query for the whole result list: ids of those with an earlier visit than the service they would be checked in to.
 */
function returningVisitorIds(visitorIds) {
  if (visitorIds.length === 0) return new Map();
  const service = getCurrentOperationalFridayService();
  const before = service ? service.service_date : today();
  const placeholders = visitorIds.map((_, i) => `@v${i}`).join(',');
  const params = Object.fromEntries(visitorIds.map((id, i) => [`v${i}`, id]));
  const rows = query(
    `SELECT v.id, v.state,
            (SELECT COUNT(*) FROM visitor_visits e WHERE e.visitor_id = v.id AND e.visit_date < @before) AS earlier,
            (SELECT COUNT(*) FROM visitor_membership_reviews r WHERE r.visitor_id = v.id AND r.status = 'continued') AS continued
       FROM visitors v WHERE v.id IN (${placeholders})`,
    { ...params, before }
  );
  return new Map(rows.filter((r) => r.earlier > 0).map((r) => [r.id, { reviewPending: r.state !== 'declined' && r.continued === 0 }]));
}

function visitorResult(v, returning = null) {
  const label = !returning ? 'First Timer' : (returning.reviewPending ? 'Returning \u00B7 Review pending' : 'Returning');
  return {
    type: 'visitor',
    id: v.id,
    name: [v.first_name, v.last_name].filter(Boolean).join(' '),
    photoUrl: null,
    returning: Boolean(returning),
    // The result carries the masked tail only; the full number is never selected into anything the desk screen can render.
    detail: [label, maskPhone(v.phone)].filter(Boolean).join(' · ')
  };
}

function visitorResults(rows) {
  const returning = returningVisitorIds(rows.map((r) => r.id));
  return rows.map((r) => visitorResult(r, returning.get(r.id) || null));
}

function searchPeopleByPhone(typed, limit) {
  if (phoneKey(typed).length < 6) return [];
  const tail = maskPhone(typed);
  // Stored numbers come in many shapes (and a field may hold two), so the whole-number comparison is made on the canonical key in code; only rows that have a number are read.
  const memberRows = query(
    `SELECT m.id, m.first_name, m.middle_name, m.last_name, m.preferred_name, m.member_code, m.phone,
            m.photo_path, m.photo_updated_at, g.name AS cell_group_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
      WHERE m.phone IS NOT NULL AND TRIM(m.phone) <> ''
      ORDER BY m.last_name COLLATE NOCASE, m.first_name COLLATE NOCASE, m.id`
  ).filter((m) => phoneMatches(m.phone, typed));
  const visitorRows = query(
    `SELECT v.id, v.first_name, v.last_name, v.phone
       FROM visitors v
      WHERE v.member_id IS NULL AND v.phone IS NOT NULL AND TRIM(v.phone) <> ''
      ORDER BY v.last_name COLLATE NOCASE, v.first_name COLLATE NOCASE, v.id`
  ).filter((v) => phoneMatches(v.phone, typed));

  const visitorQuota = Math.min(visitorRows.length, Math.max(VISITOR_RESERVED_SLOTS, 0), limit);
  const members = memberRows.slice(0, limit - visitorQuota).map((m) => ({
    type: 'member',
    id: m.id,
    name: fullName(m),
    photoUrl: m.photo_path ? `/media/members/${m.id}/photo?v=${encodeURIComponent(m.photo_updated_at || '')}` : null,
    // The member code and cell group are what a name search shows too; the number itself is only ever its last four digits (what the person typed).
    detail: [m.member_code, m.cell_group_name, tail].filter(Boolean).join(' · ')
  }));
  return [...members, ...visitorResults(visitorRows.slice(0, Math.min(visitorRows.length, limit - members.length)))];
}

/** The stored attendance status of one member at one session (present, visitor, excused, absent), or null when nothing is recorded. */
export function existingAttendanceStatus(sessionId, memberId) {
  const row = queryOne('SELECT status FROM attendance_records WHERE session_id = @sessionId AND member_id = @memberId', { sessionId, memberId });
  return row ? row.status : null;
}

/**
 * Resolves a list of { type, id } selections (as returned by
 * searchPeopleForAttendance, or by a future QR scan) back into their current
 * name — used to render a review step before anything is written.
 */
export function resolvePeopleForReview(people, sessionId = null) {
  const rows = [];
  // With a session, each person also says whether they are ALREADY checked in for it (a Present or member-linked Visitor row; a First Timer's visit that
  // Friday), so the review screen never offers to "confirm" someone who is already recorded. Without one, nobody is flagged.
  const session = sessionId ? queryOne('SELECT id, service_date FROM attendance_sessions WHERE id = @id', { id: sessionId }) : null;
  for (const person of Array.isArray(people) ? people : []) {
    const id = Number(person?.id);
    if (!id) continue;

    if (person.type === 'member') {
      const member = queryOne(
        'SELECT id, first_name, middle_name, last_name, photo_path, photo_updated_at FROM members WHERE id = @id',
        { id }
      );
      if (!member) continue;
      const existing = session
        ? queryOne('SELECT status FROM attendance_records WHERE session_id = @sessionId AND member_id = @id', { sessionId: session.id, id })
        : null;
      rows.push({
        type: 'member',
        id,
        name: fullName(member),
        existingStatus: existing ? existing.status : null,
        alreadyCheckedIn: Boolean(existing && (existing.status === 'present' || existing.status === 'visitor')),
        photoUrl: member.photo_path
          ? `/media/members/${member.id}/photo?v=${encodeURIComponent(member.photo_updated_at || '')}`
          : null
      });
    } else if (person.type === 'visitor') {
      const visitor = queryOne(
        'SELECT id, first_name, last_name FROM visitors WHERE id = @id AND member_id IS NULL',
        { id }
      );
      if (!visitor) continue;
      const visited = session
        ? queryOne('SELECT 1 AS x FROM visitor_visits WHERE visitor_id = @id AND visit_date = @date', { id, date: session.service_date })
        : null;
      rows.push({
        type: 'visitor',
        id,
        name: [visitor.first_name, visitor.last_name].filter(Boolean).join(' '),
        photoUrl: null,
        existingStatus: visited ? 'present' : null,
        alreadyCheckedIn: Boolean(visited)
      });
    }
  }
  return rows;
}

/**
 * Records attendance for a reviewed selection of people against one
 * session. A member is recorded through attendance_records, exactly like
 * the existing recording sheet; a visitor is recorded through their own
 * recordVisit() in services/visitors.js — never through attendance_records,
 * and never by creating a member record on their behalf. Neither path ever
 * touches a member's status: attendance is recorded independently of
 * membership standing, and reactivating a returning member's status remains
 * a separate, explicit administrative action.
 *
 * Safe to call with a mix of people who already have attendance recorded and
 * people who do not — each person is judged on their own existing record, so
 * one person already checked in never blocks the rest of the selection from
 * being saved, and nobody already marked present has their original
 * recorded_at/recorded_by overwritten by a repeat scan or search.
 */
export function recordAttendanceForPeople(sessionId, people, { userId = null, status = 'present' } = {}) {
  const session = getSession(sessionId);
  const mutable = assertSessionMutable(session);
  if (!mutable.ok) return { ok: false, reason: mutable.reason, newly: [], already: [], invalid: [] };

  const newly = [];
  const already = [];
  const invalid = [];
  const at = nowIso();

  let refusedLate = null;
  transaction(() => {
    // The gate above was read before this write lock was taken. A finalization (or "attendance not taken") committed by another process in between must
    // still stop this write, so the session is read again HERE, inside the immediate transaction, and refused if it is no longer writable.
    const fresh = queryOne('SELECT * FROM attendance_sessions WHERE id = @id', { id: sessionId });
    const again = assertSessionMutable(fresh);
    if (!again.ok) { refusedLate = again.reason; return; }
    for (const person of Array.isArray(people) ? people : []) {
      const id = Number(person?.id);
      if (!id || (person.type !== 'member' && person.type !== 'visitor')) {
        invalid.push(person);
        continue;
      }

      if (person.type === 'member') {
        const member = queryOne(
          'SELECT id, first_name, middle_name, last_name FROM members WHERE id = @id',
          { id }
        );
        if (!member) { invalid.push(person); continue; }

        const existing = queryOne(
          'SELECT status FROM attendance_records WHERE session_id = @sessionId AND member_id = @memberId',
          { sessionId, memberId: id }
        );
        if (existing && (existing.status === 'present' || existing.status === 'visitor')) {
          already.push({ type: 'member', id, name: fullName(member) });
          continue;
        }

        execute(
          `INSERT INTO attendance_records (session_id, member_id, status, source, recorded_at, recorded_by)
           VALUES (@sessionId, @memberId, @status, 'manual_search', @at, @by)
           ON CONFLICT(session_id, member_id) DO UPDATE SET
             status = excluded.status, source = excluded.source,
             recorded_at = excluded.recorded_at, recorded_by = excluded.recorded_by`,
          { sessionId, memberId: id, status, at, by: userId }
        );
        newly.push({ type: 'member', id, name: fullName(member) });

        // Search, Smart Family Attendance and the Kiosk all funnel through
        // here — the operational-Friday-only auto-return rule applies once,
        // centrally, rather than being reimplemented in each of those entry
        // points. See isOperationalFridaySession() and CCIQ_DECISIONS.md.
        if (status === 'present' && isOperationalFridaySession(session)) {
          maybeReturnFromTemporarilyAway(id, session.service_date, { userId });
        }
      } else {
        const visitor = queryOne(
          'SELECT id, first_name, last_name FROM visitors WHERE id = @id AND member_id IS NULL',
          { id }
        );
        if (!visitor) { invalid.push(person); continue; }

        const name = [visitor.first_name, visitor.last_name].filter(Boolean).join(' ');
        const result = recordVisit(id, { date: session.service_date, sessionId, userId });
        if (result.ok) newly.push({ type: 'visitor', id, name });
        else already.push({ type: 'visitor', id, name });
      }
    }

    // Recording attendance means the service happened — the same rule
    // recordAttendance() above already applies to the recording sheet.
    if (newly.length > 0) {
      execute(
        `UPDATE attendance_sessions SET status = 'held' WHERE id = @id AND status = 'scheduled'`,
        { id: sessionId }
      );
    }
  })();
  if (refusedLate) return { ok: false, reason: refusedLate, newly: [], already: [], invalid: [] };

  return { ok: true, session, newly, already, invalid };
}

// --- Smart Family Attendance -------------------------------------------------

/**
 * Household members of a scanned/searched member, for a specific session,
 * each tagged with their existing attendance status for that session (if
 * any) so the caller can decide how to offer them — never automatically
 * marking anyone Present. Family membership is a selection convenience
 * only, never evidence of attendance: nothing here writes anything.
 *
 * Deliberately status-blind about *membership* status, matching
 * searchPeopleForAttendance()/CCIQ_DECISIONS.md — only the session's own
 * attendance_records status is surfaced, never members.status.
 *
 * Returns null when the member has no Family Group, or when their
 * household has no one else in it (nothing useful to suggest).
 */
export function familyCheckinContext(memberId, sessionId) {
  const familyGroup = familyGroupForMember(memberId);
  if (!familyGroup) return null;

  const group = getFamilyGroup(familyGroup.id);
  if (!group || group.members.length < 2) return null;

  const members = group.members.map((m) => {
    const existing = queryOne(
      'SELECT status FROM attendance_records WHERE session_id = @sessionId AND member_id = @id',
      { sessionId, id: m.id }
    );
    return {
      id: m.id,
      name: fullName(m),
      memberCode: m.member_code,
      photoUrl: m.photo_path
        ? `/media/members/${m.id}/photo?v=${encodeURIComponent(m.photo_updated_at || '')}`
        : null,
      existingStatus: existing ? existing.status : null
    };
  });

  return { id: group.id, name: group.name, members };
}

/**
 * Other household members worth offering alongside people already selected
 * for a review screen — used by both the QR and manual-search paths, since
 * "found through QR, search, or an appropriate usher workflow" all funnel
 * into the same review step. Only offers people who are: not already in the
 * selection, not a visitor entry (visitors have no Family Group), and not
 * already checked in for this session (present/visitor) — someone already
 * recorded needs no suggestion to add them again.
 */
export function suggestedFamilyMembersForReview(selectedPeople, sessionId) {
  const selectedIds = new Set(
    (Array.isArray(selectedPeople) ? selectedPeople : [])
      .filter((p) => p.type === 'member')
      .map((p) => Number(p.id))
  );
  if (selectedIds.size === 0) return [];

  const suggestions = new Map();
  for (const memberId of selectedIds) {
    const context = familyCheckinContext(memberId, sessionId);
    if (!context) continue;
    for (const m of context.members) {
      if (selectedIds.has(m.id) || suggestions.has(m.id)) continue;
      if (m.existingStatus === 'present' || m.existingStatus === 'visitor') continue;
      suggestions.set(m.id, { ...m, familyGroupName: context.name });
    }
  }
  return [...suggestions.values()];
}
