import { query, queryOne, execute, transaction } from '../db/index.js';
import { today, nowIso, isValidDate } from '../lib/dates.js';
import { recordAudit } from '../lib/audit.js';
import {
  assessments, dobAssessment, REASON_TEXT, REVIEW_LABELS, sourceEvidenceFor, evidenceLines
} from './dob-quality.js';
import { AGE_GROUP_LABELS, congregationFor } from './congregations.js';
import { STATUS_LABELS, displayName, getMember, updateMember } from './members.js';
import { openBirthdayReminders } from './birthday-reminders.js';

/*
 * The Date of birth review: every member whose date of birth is invalid, needs verification, should be checked against the source, or already has a person's decision on it; and the four
 * things an administrator can do about one:
 *
 *   verify      confirm the COMPLETE date (year included). The date is then used for age, congregation, birthdays and reminders.
 *   unverify    the date cannot be trusted. It is not used for anything.
 *   month_day   confirm the birthday's month and day only; the birth year is not known. The birthday is listed; no age, congregation or "turning" comes from it.
 *   correct     replace the date with a date the administrator has confirmed (through the ordinary member update, so it is audited like any edit).
 *
 * Nothing here ever decides by itself, guesses a date, or changes a date in bulk. Who may do it (Church Admin / Super Admin) is enforced by the routes; the checks below are the data rules.
 * Which state wins over the automatic checks is decided in one place, dob-quality.js.
 */

export const DECISIONS = ['verify', 'unverify', 'month_day', 'correct'];
export const DECISION_STATE = { verify: 'verified', unverify: 'unverified', month_day: 'month_day_only' };

export const DECISION_LABELS = {
  verify: 'Confirm the full date of birth',
  unverify: 'Mark the date of birth as not verified',
  month_day: 'Confirm the birthday’s month and day only',
  correct: 'Correct the date of birth'
};

const CATEGORY_ORDER = { A: 0, B: 1, C: 2, E: 3, D: 4 };
const REASON_KEYS = Object.keys(REASON_TEXT);

/**
 * The rows of the review list. `category` is '', 'A', 'B', 'C' or 'E'; `state` is '' (all), 'undecided' (nobody has decided and something is flagged), 'verified', 'unverified' or
 * 'month_day_only'; `reason` is one reason key; `search` matches a name or member ID.
 */
export function dobReviewRows({ category = '', state = '', reason = '', search = '' } = {}) {
  const map = assessments();
  const members = query(
    `SELECT m.id, m.member_code, m.first_name, m.middle_name, m.last_name, m.preferred_name, m.status, m.date_of_birth, m.age_group, m.legacy_reference,
            g.name AS cell_group_name, u.display_name AS reviewed_by_name
       FROM members m
       LEFT JOIN cell_groups g ON g.id = m.cell_group_id
       LEFT JOIN users u ON u.id = m.dob_reviewed_by`
  );
  const needle = String(search || '').trim().toLowerCase();
  const rows = [];
  for (const m of members) {
    const a = map.get(m.id);
    if (!a || a.state === 'none') continue;
    if (a.category === 'D' && !a.review) continue; // appears valid and nobody has touched it
    if (category && a.category !== category) continue;
    if (state === 'undecided' && !a.needsReview) continue;
    if (state && state !== 'undecided' && a.review !== state) continue;
    if (reason && !a.reasons.includes(reason)) continue;
    const name = displayName(m);
    if (needle && !`${name} ${m.first_name} ${m.last_name} ${m.member_code}`.toLowerCase().includes(needle)) continue;
    const congregation = congregationFor(m);
    rows.push({
      id: m.id,
      code: m.member_code,
      name,
      stored: a.stored,
      validDate: a.state !== 'invalid',
      // An age only when the date is safe to use: never from a date that needs verification or whose year is unknown.
      age: a.age,
      category: a.category,
      reasonKeys: a.reasons,
      reasons: a.reasons.map((r) => REASON_TEXT[r]),
      suggested: a.suggested,
      suppressed: a.suppressed,
      birthdayOk: a.birthdayOk,
      review: a.review,
      reviewLabel: a.review ? REVIEW_LABELS[a.review] : (a.needsReview ? 'Not reviewed yet' : 'Not reviewed'),
      reviewedAt: a.reviewedAt,
      reviewedBy: m.reviewed_by_name || '',
      usage: a.state === 'month_day_only' ? 'Birthday month and day used; year not used'
        : a.suppressed ? 'Not used' : (a.reviewOnly ? 'Used: please check' : 'Used'),
      evidence: evidenceLines(sourceEvidenceFor(m)),
      status: STATUS_LABELS[m.status] || m.status,
      congregation: congregation ? AGE_GROUP_LABELS[congregation] : 'Not set',
      cellGroup: m.cell_group_name || ''
    });
  }
  rows.sort((x, y) => (CATEGORY_ORDER[x.category] - CATEGORY_ORDER[y.category]) || x.name.localeCompare(y.name, undefined, { sensitivity: 'base' }));
  return rows;
}

/** Everything the single-member review page shows. Null when there is no such member or nothing recorded to review. */
export function dobReviewContext(memberId) {
  const member = getMember(memberId);
  if (!member) return null;
  const a = dobAssessment(member.id);
  const history = query(
    `SELECT a.action, a.created_at, a.detail, u.display_name AS user_name
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'member' AND a.entity_id = @id AND a.action IN ('member.dob_review', 'member.dob_corrected', 'member.dob_review_reset')
      ORDER BY a.created_at DESC, a.id DESC LIMIT 20`,
    { id: String(member.id) }
  ).map((h) => { let d = {}; try { d = JSON.parse(h.detail || '{}'); } catch { d = {}; } return { ...h, d }; });
  const reviewer = member.dob_reviewed_by ? queryOne('SELECT display_name FROM users WHERE id = @id', { id: member.dob_reviewed_by }) : null;
  const congregation = congregationFor(member);
  return {
    member,
    name: displayName(member),
    assessment: a,
    reasons: (a?.reasons || []).map((r) => REASON_TEXT[r]),
    evidence: evidenceLines(sourceEvidenceFor(member)),
    reviewLabel: member.dob_review ? REVIEW_LABELS[member.dob_review] : 'No decision yet',
    reviewedBy: reviewer?.display_name || '',
    status: STATUS_LABELS[member.status] || member.status,
    congregation: congregation ? AGE_GROUP_LABELS[congregation] : 'Not set',
    history
  };
}

const MAX_REASON = 300;

/** The words the confirmation page uses for what a decision will do. */
export function describeDecision(decision, { stored = null, newDob = null, markVerified = false } = {}) {
  if (decision === 'verify') return `Confirm ${stored} as the complete, correct date of birth. It will be used for age, congregation, birthdays and reminders.`;
  if (decision === 'unverify') return `Mark ${stored} as not verified. It will not be used for age, congregation, birthdays, reminders or reports until someone verifies or corrects it.`;
  if (decision === 'month_day') return 'Confirm only the birthday’s month and day. The birthday will appear in birthday lists, reminders, the calendar and reports. The birth year is treated as unknown: no age, no congregation and no “turning” will come from it.';
  if (decision === 'correct') return `Change the date of birth from ${stored} to ${newDob}.${markVerified ? ' The new date will be marked verified.' : ' The new date will not be marked verified; the automatic checks will decide whether it is used.'}`;
  return '';
}

/** Checks a decision against the data rules without writing anything. Returns { ok: true, ... } or { ok: false, reason, message }. */
export function checkDecision(memberId, { decision, newDob = null, expectedDob, expectedReview } = {}) {
  const member = getMember(memberId);
  if (!member) return { ok: false, reason: 'not_found', message: 'That member could not be found.' };
  if (!DECISIONS.includes(decision)) return { ok: false, reason: 'bad_decision', message: 'Choose what to do with this date of birth.' };
  const stored = member.date_of_birth || null;
  // The page was built from a particular date and decision; if either has changed since (another administrator, or an edit), nothing is written.
  if (expectedDob !== undefined && (expectedDob || null) !== stored) return { ok: false, reason: 'changed', message: 'This date of birth was changed after you opened the page. Please look at it again.' };
  if (expectedReview !== undefined && (expectedReview || null) !== (member.dob_review || null)) return { ok: false, reason: 'changed', message: 'This date of birth was reviewed after you opened the page. Please look at it again.' };

  if (decision === 'correct') {
    const value = String(newDob || '').trim();
    if (!value) return { ok: false, reason: 'bad_new_dob', message: 'Enter the corrected date of birth.' };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !isValidDate(value)) return { ok: false, reason: 'bad_new_dob', message: 'The corrected date of birth is not a real calendar date.' };
    if (value > today()) return { ok: false, reason: 'bad_new_dob', message: 'A date of birth cannot be in the future.' };
    if (value < '1900-01-01') return { ok: false, reason: 'bad_new_dob', message: 'That date of birth is too far in the past.' };
    if (value === stored) return { ok: false, reason: 'same_dob', message: 'That is the date already on the record. To confirm it, choose “Confirm the full date of birth”.' };
    return { ok: true, member, stored, newDob: value };
  }

  if (!stored) return { ok: false, reason: 'no_dob', message: 'This member has no date of birth recorded.' };
  const real = /^\d{4}-\d{2}-\d{2}$/.test(stored) && isValidDate(stored);
  if (decision === 'verify') {
    if (!real) return { ok: false, reason: 'not_real_date', message: `${stored} is not a real calendar date, so it cannot be confirmed. Correct it instead.` };
    if (stored > today()) return { ok: false, reason: 'future', message: `${stored} is in the future, so it cannot be confirmed. Correct it instead.` };
  }
  if (decision === 'month_day' && !real) return { ok: false, reason: 'not_real_date', message: `${stored} is not a real calendar date, so its month and day cannot be confirmed. Correct it instead.` };
  if (decision === 'unverify' && member.dob_review === 'unverified') return { ok: false, reason: 'already', message: 'This date of birth is already marked as not verified.' };
  if (decision === 'verify' && member.dob_review === 'verified') return { ok: false, reason: 'already', message: 'This date of birth is already verified.' };
  if (decision === 'month_day' && member.dob_review === 'month_day_only') return { ok: false, reason: 'already', message: 'This birthday is already confirmed as month and day only.' };
  return { ok: true, member, stored, newDob: null };
}

/**
 * Records a decision. One unit: the member row and its audit entry are written together or not at all. Returns { ok: true, member, previous } or the refusal from checkDecision().
 * Every decision is audited with the member, the previous and new date and review state, who, and an optional reason; the time is the audit entry's own.
 */
export function applyDobDecision(memberId, { decision, newDob = null, markVerified = false, reason = '', expectedDob, expectedReview } = {}, { userId, req = null } = {}) {
  const check = checkDecision(memberId, { decision, newDob, expectedDob, expectedReview });
  if (!check.ok) return check;
  const { member, stored } = check;
  const why = String(reason || '').trim().slice(0, MAX_REASON) || null;
  const at = nowIso();
  const previous = { dob: stored, review: member.dob_review || null, reviewed_at: member.dob_reviewed_at || null, reviewed_by: member.dob_reviewed_by || null };

  let remindersDismissed = 0;
  transaction(() => {
    if (decision === 'correct') {
      // updateMember() dismisses (never deletes) the open birthday reminders about the old date; they are counted here for the audit entry.
      remindersDismissed = openBirthdayReminders(member.id).length;
      updateMember(member.id, { ...member, date_of_birth: check.newDob }, { userId, dobReviewAudited: true });
      if (markVerified) {
        execute('UPDATE members SET dob_review = \'verified\', dob_reviewed_at = @at, dob_reviewed_by = @by WHERE id = @id', { id: member.id, at, by: userId });
      }
      recordAudit({
        req, userId, action: 'member.dob_corrected', entityType: 'member', entityId: member.id,
        detail: {
          decision, previous_dob: stored, new_dob: check.newDob, previous_review: previous.review, new_review: markVerified ? 'verified' : null,
          previous_reviewed_at: previous.reviewed_at, reviewed_at: markVerified ? at : null, reason: why, birthday_reminders_dismissed: remindersDismissed
        }
      });
    } else {
      const state = DECISION_STATE[decision];
      execute(
        'UPDATE members SET dob_review = @state, dob_reviewed_at = @at, dob_reviewed_by = @by, updated_at = @at, updated_by = @by WHERE id = @id',
        { id: member.id, state, at, by: userId }
      );
      recordAudit({
        req, userId, action: 'member.dob_review', entityType: 'member', entityId: member.id,
        detail: {
          decision, previous_dob: stored, new_dob: stored, previous_review: previous.review, new_review: state,
          previous_reviewed_at: previous.reviewed_at, reviewed_at: at, reason: why
        }
      });
    }
  })();

  return { ok: true, member: getMember(member.id), previous };
}
