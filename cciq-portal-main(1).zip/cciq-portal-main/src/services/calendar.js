import { query } from '../db/index.js';
import { today, addDays, formatDate } from '../lib/dates.js';
import { getSetting } from '../lib/settings.js';
import { activitiesInRange } from './activities.js';
import { upcomingBirthdays, upcomingAnniversaries, displayName } from './members.js';

export const EVENT_KINDS = {
  friday_service: { label: 'Friday Service', className: 'is-service' },
  church_activity: { label: 'Church activity', className: 'is-church' },
  group_activity: { label: 'Cell group activity', className: 'is-group' },
  other_service: { label: 'Other service', className: 'is-service' },
  birthday: { label: 'Birthday', className: 'is-birthday' },
  anniversary: { label: 'Anniversary', className: 'is-anniversary' }
};

function monthBounds(year, month) {
  const first = new Date(Date.UTC(year, month - 1, 1));
  const last = new Date(Date.UTC(year, month, 0));
  return { from: first.toISOString().slice(0, 10), to: last.toISOString().slice(0, 10) };
}

/**
 * Everything a user may see between two dates, in one list. Each source keeps
 * its own permission rules; nothing is widened to fill the calendar.
 */
export function eventsInRange(user, { from, to }) {
  const events = [];

  // Scheduled services. The Friday Service recurs weekly from configuration,
  // so its sessions already exist as rows; cancelled ones are shown struck out
  // rather than hidden, so it is clear the week was not missed by accident.
  if (user.can('attendance.view') || user.can('calendar.view')) {
    const sessions = query(
      `SELECT s.*, g.name AS cell_group_name
         FROM attendance_sessions s
         LEFT JOIN cell_groups g ON g.id = s.cell_group_id
        WHERE s.service_date BETWEEN @from AND @to
        ORDER BY s.service_date, s.start_time`,
      { from, to }
    );

    const ledIds = user.ledCellGroupIds.map(Number);
    const ownGroup = Number(user.member?.cell_group_id) || null;
    const seesAllGroups = user.can('cellgroups.view') || user.can('cellgroups.manage');

    for (const session of sessions) {
      // A cell group meeting is only shown to that group.
      if (session.cell_group_id) {
        const id = Number(session.cell_group_id);
        if (!seesAllGroups && !ledIds.includes(id) && ownGroup !== id) continue;
      }
      events.push({
        kind: session.service_type === 'friday_service' ? 'friday_service' : 'other_service',
        date: session.service_date,
        time: session.start_time,
        title: session.title || (session.service_type === 'friday_service'
          ? getSetting('service.friday.title') || 'Friday Service'
          : 'Service'),
        detail: session.location,
        cancelled: session.status === 'cancelled',
        href: user.can('attendance.view') ? `/attendance/sessions/${session.id}` : null
      });
    }
  }

  // Activities, already filtered to what this user may see.
  if (user.can('activities.view')) {
    for (const activity of activitiesInRange(user, { from, to })) {
      if (!activity.activity_date) continue;
      events.push({
        kind: activity.scope === 'church' ? 'church_activity' : 'group_activity',
        date: activity.activity_date,
        time: activity.start_time,
        title: activity.title,
        detail: activity.cell_group_name || activity.location,
        draft: activity.status !== 'published',
        href: `/activities/${activity.id}`
      });
    }
  }

  // Birthdays and anniversaries, only where the calendar is configured to show
  // them and the user may see member records.
  if (user.can('members.view') && getSetting('calendar.show_personal_dates')) {
    const span = Math.max(1, Math.min(370, daysBetween(from, to) + 1));
    for (const member of upcomingBirthdays({ withinDays: span, limit: 500 })) {
      if (member.nextDate < from || member.nextDate > to) continue;
      events.push({
        kind: 'birthday',
        date: member.nextDate,
        time: null,
        title: `${displayName(member)} — birthday`,
        detail: null,
        href: `/members/${member.id}`
      });
    }
    for (const member of upcomingAnniversaries({ withinDays: span, limit: 500 })) {
      if (member.nextDate < from || member.nextDate > to) continue;
      events.push({
        kind: 'anniversary',
        date: member.nextDate,
        time: null,
        title: `${displayName(member)} — anniversary`,
        detail: null,
        href: `/members/${member.id}`
      });
    }
  }

  return events.sort((a, b) => (
    a.date === b.date
      ? String(a.time || '').localeCompare(String(b.time || ''))
      : a.date.localeCompare(b.date)
  ));
}

function daysBetween(from, to) {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000);
}

/**
 * A month as weeks of days, each carrying its events. Weeks start on Sunday,
 * which puts the Friday Service in the same column every week.
 */
export function monthGrid(user, { year, month }) {
  const { from, to } = monthBounds(year, month);
  const firstWeekday = new Date(`${from}T00:00:00Z`).getUTCDay();
  const gridStart = addDays(from, -firstWeekday);
  const lastWeekday = new Date(`${to}T00:00:00Z`).getUTCDay();
  const gridEnd = addDays(to, 6 - lastWeekday);

  const events = eventsInRange(user, { from: gridStart, to: gridEnd });
  const byDate = new Map();
  for (const event of events) {
    if (!byDate.has(event.date)) byDate.set(event.date, []);
    byDate.get(event.date).push(event);
  }

  const weeks = [];
  let cursor = gridStart;
  const now = today();
  while (cursor <= gridEnd) {
    const week = [];
    for (let i = 0; i < 7; i += 1) {
      week.push({
        date: cursor,
        day: Number(cursor.slice(8, 10)),
        inMonth: cursor >= from && cursor <= to,
        isToday: cursor === now,
        events: byDate.get(cursor) || []
      });
      cursor = addDays(cursor, 1);
    }
    weeks.push(week);
  }

  return {
    year,
    month,
    label: formatDate(from, 'month'),
    from,
    to,
    weeks,
    events,
    previous: month === 1 ? { year: year - 1, month: 12 } : { year, month: month - 1 },
    next: month === 12 ? { year: year + 1, month: 1 } : { year, month: month + 1 }
  };
}

export function agenda(user, { from = today(), days = 30 } = {}) {
  return eventsInRange(user, { from, to: addDays(from, days) });
}
