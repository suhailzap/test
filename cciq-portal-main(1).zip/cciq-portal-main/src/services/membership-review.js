import { query, queryOne, execute, transaction } from '../db/index.js';
import { nowIso, today } from '../lib/dates.js';
import { recordAudit } from '../lib/audit.js';
import { buildFridayContexts } from './attendance-outcomes.js';
import { isTrackingConfigured, trackingStartDate } from './attendance-tracking.js';
import { onAttendanceLifecycleChange } from './attendance-lifecycle.js';
import { notifyUsersWithPermission } from './reminders.js';

/*
 * Membership Review Suggested.
 *
 * APPROVED RULE: a First Timer becomes eligible for a review when they have recorded visits on at least 3 of the last 4 ELIGIBLE
 * Friday services. Reaching it creates a review for an administrator to look at. It never creates a member, never links anyone and
 * never issues a QR code.
 *
 * "Eligible" is taken from the Attendance lifecycle (services/attendance-outcomes.js buildFridayContexts, the same sequence the
 * follow-up list uses) - this file defines no Friday rules of its own and Attendance does not know this file exists:
 *   - only FINALIZED tracked Fridays that count toward follow-up are eligible;
 *   - cancelled and "Attendance not taken" Fridays are neutral: they neither count nor consume one of the four;
 *   - an unsettled Friday (open, awaiting finalization, reopened) that is NEWER than every finalized one is simply not eligible yet;
 *   - an unsettled Friday that sits INSIDE the sequence is a BARRIER: the evaluation waits. It never skips it to reach further back
 *     and manufacture four finalized Fridays (the same conservative stance as the follow-up list);
 *   - until Attendance tracking has started there are no eligible Fridays, so nothing is evaluated.
 * A visit counts for a Friday if it is linked to that session OR is dated on that Friday; one visit per visitor per Friday at most.
 *
 * Declined ("Not continuing") First Timers are not evaluated, and neither are joined ones: that preserves current declined semantics
 * until the owner decides otherwise (docs/WORKFLOW-INTEGRITY-AUDIT.md, owner decisions).
 *
 * The visitor_membership_reviews row is the source of truth. A notification is only a courtesy: it is sent once, when a review is
 * first opened, and never because a review is still open.
 */

const CANDIDATE_CHUNK = 500; // bound parameters per statement
export const WINDOW_SIZE = 4;
export const THRESHOLD = 3;
export const SUPPRESS_FRIDAYS = WINDOW_SIZE;
export const REVIEW_STATUSES = ['open', 'continued', 'converted', 'linked'];

/**
 * The four Friday Services the rule looks at, newest first, or the reason there are not four yet.
 * { status: 'tracking_not_started' | 'insufficient' | 'blocked' | 'ready', window, barrierDate? }
 */
export function eligibleFridayWindow({ contexts = null } = {}) {
  if (!isTrackingConfigured()) return { status: 'tracking_not_started', window: [] };
  const sequence = contexts || buildFridayContexts({ from: trackingStartDate(), to: today(), countingOnly: true }); // newest first
  const window = [];
  let leading = true;
  for (const ctx of sequence) {
    if (ctx.phase === 'cancelled' || ctx.phase === 'not_taken') continue; // neutral
    if (ctx.phase === 'finalized') {
      window.push(ctx);
      leading = false;
      if (window.length === WINDOW_SIZE) break;
      continue;
    }
    if (leading) continue; // newer than every finalized Friday: not eligible yet, and nothing older is being skipped
    return { status: 'blocked', window, barrierDate: ctx.date, barrierPhase: ctx.phase };
  }
  return { status: window.length === WINDOW_SIZE ? 'ready' : 'insufficient', window };
}

/**
 * What the rule can see RIGHT NOW, for the screens that explain it (it changes nothing). The review only ever works from FINALIZED Friday Services on or after the Attendance tracking start,
 * so before tracking has started - or before four such Fridays exist, or while one inside the last four is unsettled - no First Timer can be suggested, however often they visit.
 *   status  'tracking_not_started' | 'insufficient' | 'blocked' | 'ready'
 *   fridays the eligible Fridays found so far, newest first: [{ id, date }]
 */
export function reviewEvaluation() {
  const found = eligibleFridayWindow();
  return {
    status: found.status,
    needed: WINDOW_SIZE,
    threshold: THRESHOLD,
    trackingStart: trackingStartDate(),
    fridays: found.window.map((c) => ({ id: c.id, date: c.date })),
    barrierDate: found.barrierDate || null,
    barrierPhase: found.barrierPhase || null
  };
}

/**
 * Where one First Timer stands against the rule, for their profile: the Fridays the rule looks at and on how many of them they have a visit. Read-only. Applies only to a First Timer who is
 * not a member and has not declined (the same people the evaluation considers); `qualifies` is the arithmetic only (an open review, or a Continue as Visitor suppression, is reported separately).
 */
export function visitorStanding(visitorId) {
  const visitor = queryOne('SELECT id, state, member_id FROM visitors WHERE id = @id', { id: visitorId });
  const evaluation = reviewEvaluation();
  if (!visitor || visitor.member_id || ['joined', 'declined'].includes(visitor.state)) return { applies: false, evaluation };
  const window = eligibleFridayWindow().window;
  const visited = window.length ? (visitsInWindow(window).get(visitorId) || new Set()) : new Set();
  const anchor = queryOne("SELECT MAX(suppress_after_date) AS anchor FROM visitor_membership_reviews WHERE visitor_id = @id AND status = 'continued'", { id: visitorId }).anchor || null;
  return {
    applies: true,
    evaluation,
    fridays: window.map((c, i) => ({ date: c.date, visited: visited.has(i) })),
    visits: visited.size,
    qualifies: evaluation.status === 'ready' && visited.size >= THRESHOLD,
    suppressedUntilAfter: anchor && window.length && window[window.length - 1].date <= anchor ? anchor : null
  };
}

/** Which of the window's Fridays each visitor has a visit on: Map(visitorId -> Set(index into window)). */
function visitsInWindow(window) {
  const ids = window.map((c) => c.id);
  const dates = window.map((c) => c.date);
  const rows = query(
    `SELECT visitor_id, visit_date, session_id FROM visitor_visits
      WHERE session_id IN (${ids.map((_, i) => `@s${i}`).join(',')}) OR visit_date IN (${dates.map((_, i) => `@d${i}`).join(',')})`,
    { ...Object.fromEntries(ids.map((v, i) => [`s${i}`, v])), ...Object.fromEntries(dates.map((v, i) => [`d${i}`, v])) }
  );
  const byVisitor = new Map();
  for (const row of rows) {
    const index = window.findIndex((c) => c.id === row.session_id || c.date === row.visit_date);
    if (index < 0) continue;
    if (!byVisitor.has(row.visitor_id)) byVisitor.set(row.visitor_id, new Set());
    byVisitor.get(row.visitor_id).add(index);
  }
  return byVisitor;
}

/**
 * Opens a review for every First Timer who now meets the rule and has none open and is not inside a Continue-as-Visitor
 * suppression. Idempotent: running it twice, or from two events at once, opens each review once and notifies once.
 * Returns { status, opened: [reviewId, ...] }.
 */
export function evaluateMembershipReviews({ source = 'manual', notify = true } = {}) {
  const found = eligibleFridayWindow();
  if (found.status !== 'ready') return { status: found.status, opened: [], barrierDate: found.barrierDate || null };
  const { window } = found;
  const byVisitor = visitsInWindow(window);
  const qualifying = [...byVisitor].filter(([, set]) => set.size >= THRESHOLD).map(([visitorId]) => visitorId);
  if (qualifying.length === 0) return { status: 'ready', opened: [] };

  const oldestDate = window[window.length - 1].date;
  const newest = window[0];
  const opened = [];
  transaction(() => {
    // One read for everything the decision needs about every candidate (state, link, an open review, the latest suppression anchor), so
    // the loop below runs in memory: the cost does not grow with the number of candidates who already have a review. The transaction is
    // immediate, so these values cannot change underneath the loop.
    const info = new Map();
    for (let i = 0; i < qualifying.length; i += CANDIDATE_CHUNK) {
      const chunk = qualifying.slice(i, i + CANDIDATE_CHUNK);
      const marks = chunk.map((_, n) => `@v${n}`).join(',');
      const rows = query(
        `SELECT v.id, v.state, v.member_id,
                EXISTS (SELECT 1 FROM visitor_membership_reviews r WHERE r.visitor_id = v.id AND r.status = 'open') AS has_open,
                (SELECT MAX(r.suppress_after_date) FROM visitor_membership_reviews r WHERE r.visitor_id = v.id AND r.status = 'continued') AS anchor
           FROM visitors v WHERE v.id IN (${marks})`,
        Object.fromEntries(chunk.map((id, n) => [`v${n}`, id]))
      );
      for (const row of rows) info.set(row.id, row);
    }
    for (const visitorId of qualifying) {
      const visitor = info.get(visitorId);
      if (!visitor || visitor.member_id || ['joined', 'declined'].includes(visitor.state)) continue;
      if (visitor.has_open) continue; // one open review per First Timer (the unique index would refuse a second anyway)
      if (visitor.anchor && oldestDate <= visitor.anchor) continue; // still inside the four Fridays after Continue as Visitor
      const set = byVisitor.get(visitorId);
      const evidence = {
        rule: `${THRESHOLD} of the last ${WINDOW_SIZE} eligible Fridays`,
        fridays: window.map((c, i) => ({ session_id: c.id, service_date: c.date, visited: set.has(i) })),
        visits: set.size,
        source
      };
      const result = execute(
        `INSERT OR IGNORE INTO visitor_membership_reviews (visitor_id, status, opened_at, trigger_session_id, trigger_service_date, window_json)
         VALUES (@visitorId, 'open', @at, @sessionId, @date, @json)`,
        { visitorId, at: nowIso(), sessionId: newest.id, date: newest.date, json: JSON.stringify(evidence) }
      );
      if (result.changes === 1) {
        const reviewId = Number(result.lastInsertRowid);
        opened.push(reviewId);
        recordAudit({
          actorLabel: 'system', action: 'visitor.membership_review_opened', entityType: 'visitor', entityId: visitorId,
          detail: { membership_review_id: reviewId, trigger_service_date: newest.date, visits: set.size, source }
        });
      }
    }
  }).immediate();

  if (opened.length && notify) {
    try {
      notifyUsersWithPermission('members.edit', {
        title: opened.length === 1 ? 'Membership Review suggested for a First Timer' : `Membership Review suggested for ${opened.length} First Timers`,
        body: 'They have visited on at least 3 of the last 4 Friday Services. Nothing has been changed: an administrator decides.',
        link: '/visitors/reviews',
        category: 'membership_review'
      });
    } catch (err) {
      console.error('[membership-review] could not send the notification:', err.message);
    }
  }
  return { status: 'ready', opened };
}

/** Runs the evaluation for an event without ever letting a failure undo or block the thing that caused it. */
export function evaluateSafely(source) {
  try {
    return evaluateMembershipReviews({ source });
  } catch (err) {
    console.error(`[membership-review] evaluation failed after ${source}:`, err.message);
    try {
      recordAudit({ actorLabel: 'system', action: 'visitor.membership_review_evaluation_failed', entityType: 'visitor', result: 'failure', detail: { source, error: err.message } });
    } catch { /* the audit log is best-effort here */ }
    return { status: 'error', opened: [] };
  }
}

// Attendance announces what it did; this listens. The dependency points one way only.
onAttendanceLifecycleChange((event) => { evaluateSafely(`lifecycle:${event.type}`); });

// ---------------------------------------------------------------------------------------------------------------------------------
// Reading
// ---------------------------------------------------------------------------------------------------------------------------------

export const REVIEW_SORT_COLUMNS = {
  opened: 'r.opened_at', visitor: 'v.last_name COLLATE NOCASE, v.first_name COLLATE NOCASE', status: 'r.status', friday: 'r.trigger_service_date'
};

export function openReviewCount() {
  return queryOne("SELECT COUNT(*) AS n FROM visitor_membership_reviews WHERE status = 'open'").n;
}

export function listReviews({ status = 'open', page = 1, pageSize = 25, sort = 'opened', direction = 'desc' } = {}) {
  const dir = direction === 'asc' ? 'ASC' : 'DESC';
  const column = REVIEW_SORT_COLUMNS[sort] || REVIEW_SORT_COLUMNS.opened;
  const order = column.split(',').map((part) => `${part.trim()} ${dir}`).join(', ');
  const where = REVIEW_STATUSES.includes(status) ? 'WHERE r.status = @status' : '';
  const params = { status: REVIEW_STATUSES.includes(status) ? status : null };
  const total = queryOne(`SELECT COUNT(*) AS n FROM visitor_membership_reviews r ${where}`, params).n;
  const rows = query(
    `SELECT r.*, v.first_name, v.last_name, v.phone, v.state AS visitor_state, v.first_visit_date,
            (SELECT COUNT(*) FROM visitor_visits vv WHERE vv.visitor_id = v.id) AS visit_count
       FROM visitor_membership_reviews r JOIN visitors v ON v.id = r.visitor_id
       ${where}
      ORDER BY ${order}, r.id ${dir}
      LIMIT @limit OFFSET @offset`,
    { ...params, limit: pageSize, offset: (page - 1) * pageSize }
  ).map((row) => ({ ...row, evidence: safeJson(row.window_json) }));
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

export function getReview(id) {
  const row = queryOne(
    `SELECT r.*, v.first_name, v.last_name, v.phone, v.email, v.state AS visitor_state, v.member_id AS visitor_member_id, v.first_visit_date
       FROM visitor_membership_reviews r JOIN visitors v ON v.id = r.visitor_id WHERE r.id = @id`,
    { id }
  );
  if (!row) return null;
  return {
    ...row,
    evidence: safeJson(row.window_json),
    visits: query(
      `SELECT vv.visit_date, vv.session_id, s.title FROM visitor_visits vv LEFT JOIN attendance_sessions s ON s.id = vv.session_id
        WHERE vv.visitor_id = @id ORDER BY vv.visit_date DESC, vv.id DESC`, { id: row.visitor_id }
    )
  };
}

export function openReviewForVisitor(visitorId) {
  return queryOne("SELECT id, opened_at, trigger_service_date FROM visitor_membership_reviews WHERE visitor_id = @visitorId AND status = 'open'", { visitorId }) || null;
}

function safeJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Acting
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * Continue as Visitor: closes the review and suppresses the next evaluation until four further eligible Fridays have been finalized
 * (suppress_after_date is the latest finalized eligible Friday at this moment, never earlier than the Friday that triggered the review).
 * Review Later has no function here on purpose: it changes nothing, so it writes nothing.
 */
export function continueAsVisitor(reviewId, { userId = null, req = null, note = null } = {}) {
  return transaction(() => {
    const review = queryOne('SELECT id, visitor_id, status, trigger_service_date FROM visitor_membership_reviews WHERE id = @id', { id: reviewId });
    if (!review) return { ok: false, reason: 'not_found' };
    if (review.status !== 'open') return { ok: false, reason: 'not_open' };
    const latest = eligibleFridayWindow().window[0]?.date || null;
    const anchor = [latest, review.trigger_service_date].filter(Boolean).sort().pop();
    const closed = execute(
      `UPDATE visitor_membership_reviews
          SET status = 'continued', closed_at = @at, closed_by = @by, note = @note, suppress_after_date = @anchor
        WHERE id = @id AND status = 'open'`,
      { id: reviewId, at: nowIso(), by: userId, note: note ? String(note).slice(0, 500) : null, anchor }
    );
    if (closed.changes !== 1) return { ok: false, reason: 'not_open' };
    recordAudit({
      req, userId, action: 'visitor.membership_review_continued', entityType: 'visitor', entityId: review.visitor_id,
      detail: { membership_review_id: reviewId, suppress_after_date: anchor, eligible_fridays_suppressed: SUPPRESS_FRIDAYS }
    });
    return { ok: true, suppressAfterDate: anchor, visitorId: review.visitor_id };
  }).immediate();
}
