import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso, today } from '../lib/dates.js';
import { getCampaign } from './ecaq.js';

/**
 * A Faith Promise campaign is a pledge, not a board of individual dates: one
 * member makes one commitment for the campaign period, gives towards it on
 * whatever schedule they chose, and the portal tracks what has come in
 * against what they said they would give. Nothing here touches the Giving
 * Board's own tables — the two campaign types share a parent campaign row
 * and nothing else.
 */

export const GIVING_FREQUENCIES = ['monthly', 'quarterly', 'annual', 'one_time'];
export const FREQUENCY_LABELS = {
  monthly: 'Monthly',
  quarterly: 'Quarterly',
  annual: 'Yearly',
  one_time: 'One-time'
};

export const COMMITMENT_STATUSES = ['not_started', 'in_progress', 'completed'];
export const STATUS_LABELS = {
  not_started: 'Not started',
  in_progress: 'In progress',
  completed: 'Completed'
};

export const PAYMENT_METHODS = ['cash', 'bank_transfer', 'cheque', 'card', 'other'];

/** How many instalments the campaign period holds at a given frequency. */
function instalmentCount(frequency, periodStart, periodEnd) {
  const [startYear, startMonth] = periodStart.split('-').map(Number);
  const [endYear, endMonth] = periodEnd.split('-').map(Number);
  // Calendar months spanned, inclusive of both ends: Feb 2026 to Jan 2027 is
  // 12 months, not 11 and not 13 — counted from the year/month components
  // directly rather than approximated from a day count, which drifts by a
  // month depending on where in each month the period happens to start or end.
  const months = Math.max(1, (endYear - startYear) * 12 + (endMonth - startMonth) + 1);
  if (frequency === 'monthly') return months;
  if (frequency === 'quarterly') return Math.max(1, Math.round(months / 3));
  return 1; // annual (yearly) or one_time — one instalment for the whole period
}

/**
 * What the member is expected to give across the whole campaign period,
 * from the amount they named per instalment and how often they chose to
 * give it. An annual pledge is already the whole-period figure.
 */
export function expectedTotal({ amount, frequency, campaign }) {
  const perInstalment = Number(amount) || 0;
  if (frequency === 'annual') return perInstalment;
  const count = instalmentCount(frequency, campaign.start_date, campaign.end_date);
  return Math.round(perInstalment * count * 100) / 100;
}

function statusFor(expected, collected) {
  if (collected <= 0) return 'not_started';
  if (expected > 0 && collected >= expected) return 'completed';
  return 'in_progress';
}

export function getCommitment(id) {
  return queryOne(
    `SELECT c.*, m.first_name AS member_first, m.last_name AS member_last, m.preferred_name AS member_preferred
       FROM ecaq_faith_promise_commitments c
       LEFT JOIN members m ON m.id = c.member_id
      WHERE c.id = @id`,
    { id }
  ) || null;
}

/** One member may only have one commitment per campaign — a correction edits it, not duplicates it. */
export function commitmentForMember(campaignId, memberId) {
  return queryOne(
    'SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = @campaignId AND member_id = @memberId',
    { campaignId, memberId }
  ) || null;
}

/**
 * Every Faith Promise commitment a member holds, across every campaign year —
 * the Faith Promise half of "My Commitments", mirroring claimsForMember() in
 * services/ecaq.js so a future year's campaign appears here automatically,
 * the same way a future Giving Board year already does.
 */
export function commitmentsForMember(memberId) {
  return query(
    `SELECT c.*, camp.name AS campaign_name, camp.year, camp.currency, camp.start_date, camp.end_date
       FROM ecaq_faith_promise_commitments c
       JOIN ecaq_campaigns camp ON camp.id = c.campaign_id
      WHERE c.member_id = @memberId
      ORDER BY camp.year DESC`,
    { memberId }
  );
}

export const COMMITMENT_SORT_COLUMNS = ['name', 'committed', 'frequency', 'received', 'status'];

export function listCommitments({
  campaignId, status = null, search = '', page = 1, pageSize = 50, sort = 'name', direction = 'asc'
} = {}) {
  const params = {
    campaignId, status, search: search || '', like: likePattern(search),
    limit: pageSize, offset: (page - 1) * pageSize
  };
  const where = `
    WHERE c.campaign_id = @campaignId
      AND (@status IS NULL OR c.status = @status)
      AND (@search = '' OR c.name LIKE @like ESCAPE '\\' OR c.phone LIKE @like ESCAPE '\\' OR c.email LIKE @like ESCAPE '\\')`;

  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  const orderBy = {
    name: `c.name COLLATE NOCASE ${dir}`,
    committed: `c.expected_total ${dir}`,
    frequency: `c.frequency COLLATE NOCASE ${dir}`,
    received: `c.amount_collected ${dir}`,
    status: `c.status COLLATE NOCASE ${dir}`
  }[sort] || `c.name COLLATE NOCASE ${dir}`;

  const rows = query(
    `SELECT c.*, m.first_name AS member_first, m.last_name AS member_last, m.preferred_name AS member_preferred
       FROM ecaq_faith_promise_commitments c
       LEFT JOIN members m ON m.id = c.member_id
       ${where}
      ORDER BY ${orderBy}
      LIMIT @limit OFFSET @offset`,
    params
  );
  const total = queryOne(`SELECT COUNT(*) AS n FROM ecaq_faith_promise_commitments c ${where}`, params).n;
  return { rows, total, page, pages: Math.max(Math.ceil(total / pageSize), 1) };
}

/**
 * The commitment a SUBMITTER already holds in a campaign: their member record's, or - for a sign-in with no member record - the one that account created.
 * Used to refuse a second submission (a Member submits once).
 */
export function commitmentForSubmitter(campaignId, { memberId = null, userId = null } = {}) {
  if (memberId) return commitmentForMember(campaignId, memberId);
  if (!userId) return null;
  return queryOne(
    'SELECT * FROM ecaq_faith_promise_commitments WHERE campaign_id = @campaignId AND member_id IS NULL AND created_by = @userId',
    { campaignId, userId }
  ) || null;
}

/**
 * A Faith Promise is submitted ONCE. This records a NEW commitment and nothing else: if the person (or the member being recorded for) already holds one in the
 * campaign it is left exactly as it is and { ok: false, reason: 'already_submitted' } is returned. Changing an existing commitment is an amendment
 * (amendCommitment below), which only an administrator may make, with a reason, and which keeps what it replaced.
 */
export function submitCommitment(campaignId, data, { userId = null, requireActive = false } = {}) {
  const campaign = getCampaign(campaignId);
  if (!campaign || campaign.type !== 'faith_promise') return { ok: false, reason: 'not_a_faith_promise_campaign' };
  // A member's own submission is only ever accepted by the ACTIVE campaign. A draft, closed or archived one stays readable but takes no new or changed
  // commitment from a member (an administrator recording one for a member passes requireActive: false and may still enter one for any campaign).
  if (requireActive && campaign.status !== 'active') return { ok: false, reason: 'campaign_not_active' };

  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };
  if (!GIVING_FREQUENCIES.includes(data.frequency)) return { ok: false, reason: 'invalid_frequency' };
  if (!data.name || !String(data.name).trim()) return { ok: false, reason: 'missing_name' };

  const total = expectedTotal({ amount, frequency: data.frequency, campaign });
  const at = nowIso();
  const existing = commitmentForSubmitter(campaignId, { memberId: data.member_id || null, userId: data.member_id ? null : userId });
  if (existing) return { ok: false, reason: 'already_submitted', commitment: existing };

  const result = execute(
    `INSERT INTO ecaq_faith_promise_commitments
       (campaign_id, member_id, name, phone, email, commitment_amount, frequency, expected_total,
        amount_collected, status, notes, submitted_at, created_at, updated_at, created_by)
     VALUES (@campaignId, @memberId, @name, @phone, @email, @amount, @frequency, @total,
             0, 'not_started', @notes, @at, @at, @at, @by)`,
    {
      campaignId, memberId: data.member_id || null, name: String(data.name).trim(),
      phone: data.phone || null, email: data.email || null, amount, frequency: data.frequency,
      total, notes: data.notes || null, at, by: userId
    }
  );
  return { ok: true, created: true, commitment: getCommitment(Number(result.lastInsertRowid)) };
}

/**
 * An administrator's amendment of an EXISTING commitment (amount and/or frequency; the expected total is derived the same way as at submission). The reason is
 * required. Payments are never touched: Received is still the sum of the payments, and Outstanding follows from the new commitment (status is recalculated
 * by the same function every payment uses). The caller writes the audit row (who, when, why, before, after) in the same transaction; this returns the figures for it.
 */
export function amendCommitment(commitmentId, data, { userId = null } = {}) {
  const commitment = getCommitment(commitmentId);
  if (!commitment) return { ok: false, reason: 'not_found' };
  const campaign = getCampaign(commitment.campaign_id);
  if (!campaign || campaign.type !== 'faith_promise') return { ok: false, reason: 'not_a_faith_promise_campaign' };
  const reason = String(data.reason || '').trim();
  if (!reason) return { ok: false, reason: 'reason_required' };
  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };
  if (!GIVING_FREQUENCIES.includes(data.frequency)) return { ok: false, reason: 'invalid_frequency' };

  const total = expectedTotal({ amount, frequency: data.frequency, campaign });
  const before = { amount: Number(commitment.commitment_amount), frequency: commitment.frequency, expected_total: Number(commitment.expected_total) };
  const after = { amount, frequency: data.frequency, expected_total: total };
  if (before.amount === after.amount && before.frequency === after.frequency && before.expected_total === after.expected_total) return { ok: false, reason: 'no_change' };

  return transaction(() => {
    execute(
      `UPDATE ecaq_faith_promise_commitments
          SET commitment_amount = @amount, frequency = @frequency, expected_total = @total, updated_at = @at, updated_by = @by
        WHERE id = @id`,
      { id: commitmentId, amount, frequency: data.frequency, total, at: nowIso(), by: userId }
    );
    const totals = recalculateCommitment(commitmentId);
    return { ok: true, before, after, reason, totals, received: totals.collected, commitment: getCommitment(commitmentId) };
  })();
}

const HISTORY_ACTIONS = ['ecaq.faith_promise_submitted', 'ecaq.faith_promise_submitted_for_member', 'ecaq.faith_promise_updated', 'ecaq.faith_promise_updated_for_member', 'ecaq.faith_promise_amended'];

/**
 * A commitment's recorded history, oldest first, read from the audit log (immutable, with who and when). `amended` entries carry the reason and the before / after
 * figures. Entries from before amendments were recorded ("updated") carry no figures and are shown as such, never invented. `original` is what the member first
 * promised: the "before" of the first amendment, else the current commitment (nothing has changed it).
 */
export function commitmentHistory(commitment) {
  const rows = query(
    `SELECT a.id, a.action, a.detail, a.created_at, u.display_name AS by_name
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'faith_promise_commitment' AND a.entity_id = @id AND a.action IN (${HISTORY_ACTIONS.map((_, i) => `@a${i}`).join(',')})
      ORDER BY a.id`,
    { id: String(commitment.id), ...Object.fromEntries(HISTORY_ACTIONS.map((a, i) => [`a${i}`, a])) }
  ).map((r) => {
    let detail = null; try { detail = r.detail ? JSON.parse(r.detail) : null; } catch { detail = null; }
    return { id: r.id, action: r.action, at: r.created_at, by: r.by_name || 'system', detail };
  });
  const entries = rows.map((r) => ({
    kind: r.action === 'ecaq.faith_promise_amended' ? 'amended' : /submitted/.test(r.action) ? 'submitted' : 'updated',
    at: r.at, by: r.by,
    reason: r.detail?.reason || null,
    before: r.detail?.before || null,
    after: r.detail?.after || (r.detail?.amount ? { amount: r.detail.amount, frequency: r.detail.frequency, expected_total: r.detail.expected_total } : null),
    received: r.detail?.received ?? null
  }));
  const firstAmendment = entries.find((e) => e.kind === 'amended');
  const current = { amount: Number(commitment.commitment_amount), frequency: commitment.frequency, expected_total: Number(commitment.expected_total) };
  return { entries, amended: Boolean(firstAmendment), amendments: entries.filter((e) => e.kind === 'amended').length, original: firstAmendment ? firstAmendment.before : current, current };
}

/** Ids of the commitments in a campaign that have been amended (for a plain "Amended" marker on the list and a note on the report). */
export function amendedCommitmentIds(campaignId) {
  return new Set(query(
    `SELECT DISTINCT CAST(a.entity_id AS INTEGER) AS id
       FROM audit_logs a JOIN ecaq_faith_promise_commitments c ON c.id = CAST(a.entity_id AS INTEGER)
      WHERE a.action = 'ecaq.faith_promise_amended' AND a.entity_type = 'faith_promise_commitment' AND c.campaign_id = @campaignId`,
    { campaignId }
  ).map((r) => r.id));
}

/** Recalculates a commitment's collected total and status from its payments — never trusts a typed-in total. */
export function recalculateCommitment(commitmentId) {
  const commitment = getCommitment(commitmentId);
  if (!commitment) return null;

  // Held to whole cents: ten payments of 0.10 must total 1.00, not 0.9999999999999999.
  const collected = Math.round((Number(queryOne(
    'SELECT COALESCE(SUM(amount), 0) AS paid FROM ecaq_faith_promise_payments WHERE commitment_id = @id',
    { id: commitmentId }
  ).paid) || 0) * 100) / 100;

  const status = statusFor(commitment.expected_total, collected);
  execute(
    `UPDATE ecaq_faith_promise_commitments SET amount_collected = @collected, status = @status, updated_at = @at WHERE id = @id`,
    { id: commitmentId, collected, status, at: nowIso() }
  );
  return { collected, status, expected: commitment.expected_total, outstanding: Math.max(commitment.expected_total - collected, 0) };
}

export function listPayments(commitmentId) {
  return query(
    `SELECT p.*, u.display_name AS recorded_by_name
       FROM ecaq_faith_promise_payments p
       LEFT JOIN users u ON u.id = p.created_by
      WHERE p.commitment_id = @commitmentId
      ORDER BY p.paid_on, p.id`,
    { commitmentId }
  );
}

export function getPayment(id) {
  return queryOne('SELECT * FROM ecaq_faith_promise_payments WHERE id = @id', { id }) || null;
}

export const RECEIVED_BY_MAX = 120;
/** "Received by" as a clean, human-readable name: trimmed, inner spaces collapsed, never longer than RECEIVED_BY_MAX; null when nothing was given. */
export function cleanReceivedBy(value) {
  if (typeof value !== 'string') return null;
  const text = value.replace(/\s+/g, ' ').trim();
  return text ? text.slice(0, RECEIVED_BY_MAX) : null;
}

/** Names already written as "Received by" on this campaign type's payments, most used first, to offer as suggestions (a name is still typed or accepted as written). */
export function knownReceivers({ limit = 30 } = {}) {
  return query(
    `SELECT received_by AS name, COUNT(*) AS uses FROM ecaq_faith_promise_payments
      WHERE received_by IS NOT NULL AND received_by <> '' GROUP BY received_by ORDER BY uses DESC, received_by COLLATE NOCASE LIMIT @limit`,
    { limit }
  ).map((r) => r.name);
}

export function addPayment(commitmentId, data, { userId = null } = {}) {
  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };
  // A NEW payment must say who received it (older payments, from before this existed, simply have no value).
  const receivedBy = cleanReceivedBy(data.received_by);
  if (!receivedBy) return { ok: false, reason: 'received_by_required' };
  const commitment = getCommitment(commitmentId);
  if (!commitment) return { ok: false, reason: 'not_found' };

  const at = nowIso();
  // The payment row and the recalculated commitment are one unit.
  return transaction(() => {
    const result = execute(
      `INSERT INTO ecaq_faith_promise_payments (commitment_id, amount, paid_on, method, reference, notes, received_by, created_at, created_by)
       VALUES (@commitmentId, @amount, @paidOn, @method, @reference, @notes, @receivedBy, @at, @by)`,
      {
        commitmentId, receivedBy, amount, paidOn: data.paid_on || today(),
        method: PAYMENT_METHODS.includes(data.method) ? data.method : 'cash',
        reference: data.reference || null, notes: data.notes || null, at, by: userId
      }
    );
    const totals = recalculateCommitment(commitmentId);
    return { ok: true, payment: getPayment(Number(result.lastInsertRowid)), totals };
  })();
}

/**
 * Corrects a payment already on file — most often its actual date, since the
 * date it was entered into the portal and the date the member actually gave
 * are not always the same day. Every edit is left for the audit log to
 * record who changed what and when; this function only ever changes the
 * payment and its commitment's recalculated total.
 */
export function updatePayment(id, data, { userId = null } = {}) {
  const payment = getPayment(id);
  if (!payment) return { ok: false, reason: 'not_found' };

  const amount = data.amount !== undefined ? Number(data.amount) : payment.amount;
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };
  // Received by: left as it is when not supplied. When supplied it is cleaned; it may only be left blank on a payment that never had one (history is never invented, and a
  // value that was recorded cannot be erased by a correction).
  let receivedBy = payment.received_by ?? null;
  if (data.received_by !== undefined) {
    const next = cleanReceivedBy(data.received_by);
    if (!next && payment.received_by) return { ok: false, reason: 'received_by_required' };
    receivedBy = next ?? payment.received_by ?? null;
  }

  const at = nowIso();
  return transaction(() => {
    execute(
      `UPDATE ecaq_faith_promise_payments
          SET amount = @amount, paid_on = @paidOn, method = @method, reference = @reference,
              notes = @notes, received_by = @receivedBy, updated_at = @at, updated_by = @by
        WHERE id = @id`,
      {
        id, amount, receivedBy, paidOn: data.paid_on || payment.paid_on,
        method: PAYMENT_METHODS.includes(data.method) ? data.method : payment.method,
        reference: data.reference !== undefined ? data.reference : payment.reference,
        notes: data.notes !== undefined ? data.notes : payment.notes,
        at, by: userId
      }
    );
    const totals = recalculateCommitment(payment.commitment_id);
    return { ok: true, payment: getPayment(id), totals };
  })();
}

export function deletePayment(id) {
  const payment = getPayment(id);
  if (!payment) return null;
  return transaction(() => {
    execute('DELETE FROM ecaq_faith_promise_payments WHERE id = @id', { id });
    const totals = recalculateCommitment(payment.commitment_id);
    return { payment, totals };
  })();
}

/**
 * Everything the Faith Promise report needs, all completed and outstanding
 * commitments included — this is a record of the whole campaign, not just
 * the people who still owe something.
 */
export function reportData(campaignId, { status = null } = {}) {
  const rows = query(
    `SELECT c.*, m.first_name AS member_first, m.last_name AS member_last, m.preferred_name AS member_preferred
       FROM ecaq_faith_promise_commitments c
       LEFT JOIN members m ON m.id = c.member_id
      WHERE c.campaign_id = @campaignId AND (@status IS NULL OR c.status = @status)
      ORDER BY c.name COLLATE NOCASE`,
    { campaignId, status }
  );

  const totals = rows.reduce((acc, r) => ({
    committed: acc.committed + Number(r.expected_total),
    received: acc.received + Number(r.amount_collected),
    completed: acc.completed + (r.status === 'completed' ? 1 : 0),
    outstanding: acc.outstanding + (r.status !== 'completed' ? 1 : 0)
  }), { committed: 0, received: 0, completed: 0, outstanding: 0 });

  return {
    rows,
    totalMembers: rows.length,
    totalCommitted: totals.committed,
    totalReceived: totals.received,
    totalOutstanding: Math.max(totals.committed - totals.received, 0),
    completedCount: totals.completed,
    outstandingCount: totals.outstanding
  };
}
