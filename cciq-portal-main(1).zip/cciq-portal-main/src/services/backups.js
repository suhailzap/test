import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { createGunzip } from 'node:zlib';
import { pipeline } from 'node:stream/promises';
import db, { query, queryOne, execute } from '../db/index.js';
import config from '../config/env.js';
import * as tar from 'tar';
import { nowIso } from '../lib/dates.js';
import { writeRecoveryInterlock } from '../lib/recovery-interlock.js';
import { checkSchemaCompatibility } from '../db/migrate.js';
import { checkFreeSpace, describeSpace, treeBytes } from '../lib/disk-space.js';
import { findMissingReferences, unknownStorageFolders, describeMissing } from '../lib/storage-references.js';

/**
 * Backups are real files written by SQLite's own online backup, taken while
 * the application keeps running and consistent at the point they are taken.
 * Nothing here depends on the browser: the file lives on the server, and the
 * directory can be pointed at mounted or synchronised storage for off-site
 * copies without changing this code.
 */

function backupDir() {
  fs.mkdirSync(config.backupDir, { recursive: true, mode: 0o700 });
  return config.backupDir;
}

/** SHA-256 of a file, read in 1 MB pieces so a large archive (videos, documents) never has to fit in memory at once. */
function checksumOf(filePath) {
  const hash = crypto.createHash('sha256');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  const fd = fs.openSync(filePath, 'r');
  try {
    let read;
    do {
      read = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (read > 0) hash.update(buffer.subarray(0, read));
    } while (read > 0);
  } finally {
    fs.closeSync(fd);
  }
  return hash.digest('hex');
}

/** Only ever resolves inside the backup directory. */
export function resolveBackupFile(storedName) {
  if (!storedName || typeof storedName !== 'string') return null;
  if (storedName.includes('/') || storedName.includes('\\') || storedName.includes('..')) return null;
  const base = path.resolve(backupDir());
  const full = path.resolve(base, storedName);
  if (!full.startsWith(base + path.sep)) return null;
  if (!fs.existsSync(full) || !fs.statSync(full).isFile()) return null;
  return full;
}

export function listBackups({ limit = 100 } = {}) {
  return query(
    `SELECT b.*, u.display_name AS created_by_name
       FROM backups b
       LEFT JOIN users u ON u.id = b.created_by
      ORDER BY b.created_at DESC, b.id DESC
      LIMIT @limit`,
    { limit }
  );
}

export function getBackup(id) {
  return queryOne(
    `SELECT b.*, u.display_name AS created_by_name
       FROM backups b LEFT JOIN users u ON u.id = b.created_by
      WHERE b.id = @id`,
    { id }
  ) || null;
}

export function listRestores({ limit = 50 } = {}) {
  return query(
    `SELECT r.*, u.display_name AS restored_by_name, b.filename
       FROM backup_restores r
       LEFT JOIN users u ON u.id = r.restored_by
       LEFT JOIN backups b ON b.id = r.backup_id
      ORDER BY r.restored_at DESC, r.id DESC
      LIMIT @limit`,
    { limit }
  );
}

/**
 * Takes a consistent copy of the database, then compresses it. The row is
 * written first as pending so a failure halfway leaves a visible record rather
 * than silence.
 */
/**
 * Everything under storage except the backups themselves, so a backup never
 * contains earlier backups.
 */
function storageEntries() {
  const base = path.resolve(config.storageDir);
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base).filter((entry) => entry !== 'backups');
}

function countFiles(dir) {
  if (!fs.existsSync(dir)) return 0;
  // A storage entry can itself be a plain file (storageEntries() lists
  // everything under storage/ except backups/), not only a directory.
  if (!fs.statSync(dir).isDirectory()) return 1;
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    total += entry.isDirectory() ? countFiles(full) : 1;
  }
  return total;
}

/**
 * Copies a file or a folder tree. A plain recursive copy rather than fs.cpSync: on Node 22.23 (Windows) fs.cpSync ends the whole process,
 * with no error, when a path contains an accented or other non-ASCII character (a Windows user name such as "Zoë" is enough). A link is
 * never followed or reproduced, so nothing outside the storage folder can be pulled into a backup.
 */
function copyTree(source, target) {
  const stat = fs.lstatSync(source);
  if (stat.isSymbolicLink()) return;
  if (stat.isDirectory()) {
    fs.mkdirSync(target, { recursive: true });
    for (const entry of fs.readdirSync(source)) copyTree(path.join(source, entry), path.join(target, entry));
  } else if (stat.isFile()) {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
}

/**
 * Takes a complete copy of the portal: the database and every uploaded file —
 * member photos, activity media, documents and finance attachments.
 *
 * A database-only backup would restore the records without their evidence: a
 * document row pointing at a file that is no longer there. Restoring one of
 * these puts the portal back exactly as it was.
 */
/**
 * What the portal's data weighs right now: the database and everything under storage/ except the backups themselves. A backup stages one
 * uncompressed copy of this and then writes the archive (at worst about the same size again), so twice this is the working estimate.
 */
function dataBytes() {
  const storageBase = path.resolve(config.storageDir);
  return treeBytes(path.resolve(config.databaseFile)) + storageEntries().reduce((sum, entry) => sum + treeBytes(path.join(storageBase, entry)), 0);
}

const NO_SPACE_MESSAGE = (space) => `There is not enough free disk space for this: ${describeSpace(space)}. Free up space on the drive that holds the backups and try again. Nothing was changed.`;

export async function createBackup({ userId = null, note = null, kind = 'manual' } = {}) {
  const dir = backupDir();
  // The time alone is not unique: two backups started in the same millisecond (a scheduled run and a button press, two clicks) would have
  // shared one file name and one staging folder, and the second would have silently overwritten the first.
  const stamp = `${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomBytes(3).toString('hex')}`;
  const filename = `cciq-${stamp}.tar.gz`;
  const target = path.join(dir, filename);
  const work = path.join(dir, `.${stamp}.staging`);
  const temp = path.join(work, 'database.sqlite');

  const at = nowIso();
  const inserted = execute(
    `INSERT INTO backups (filename, file_path, file_size, checksum, status, kind, notes, created_at, created_by)
     VALUES (@filename, @filename, NULL, NULL, 'pending', @kind, @note, @at, @by)`,
    { filename, kind, note, at, by: userId }
  );
  const id = Number(inserted.lastInsertRowid);

  // Refuse up front rather than fail half way with a truncated archive and a staging folder left behind.
  const space = checkFreeSpace(dir, dataBytes() * 2);
  if (!space.ok) {
    const message = NO_SPACE_MESSAGE(space);
    execute("UPDATE backups SET status = 'failed', notes = @note WHERE id = @id", { id, note: `Failed: not enough free disk space (${describeSpace(space)})`.slice(0, 300) });
    return { ok: false, reason: 'insufficient_disk_space', message, backup: getBackup(id) };
  }

  try {
    fs.mkdirSync(work, { recursive: true, mode: 0o700 });

    // SQLite's online backup: safe to run while the application is serving.
    await db.backup(temp);

    const storageBase = path.resolve(config.storageDir);
    const folders = storageEntries();
    const fileCount = folders.reduce((sum, entry) => sum + countFiles(path.join(storageBase, entry)), 0);

    // What the database points at versus what is in storage right now. Recorded, never hidden: a backup is faithful to a live system that may already be missing a file.
    const references = findMissingReferences(db, storageBase);
    const manifest = {
      format: 'cciq-portal-archive',
      version: 1,
      created_at: at,
      database: 'database.sqlite',
      storage_folders: folders,
      storage_file_count: fileCount,
      referenced_files: references.checked,
      missing_references: references.missing.length
    };
    fs.writeFileSync(path.join(work, 'manifest.json'), JSON.stringify(manifest, null, 2), { mode: 0o600 });

    /*
     * Everything is staged in one folder and written as a single compressed
     * archive. A gzipped archive cannot be appended to afterwards, so the
     * uploaded files are copied in first rather than added in a second pass.
     */
    for (const folder of folders) {
      copyTree(path.join(storageBase, folder), path.join(work, 'storage', folder));
    }

    await tar.create(
      { gzip: { level: 9 }, file: target, cwd: work, portable: true },
      ['manifest.json', 'database.sqlite', ...(folders.length ? ['storage'] : [])]
    );

    fs.rmSync(work, { recursive: true, force: true });
    fs.chmodSync(target, 0o600);

    const size = fs.statSync(target).size;
    const checksum = checksumOf(target);
    // The checksum also goes beside the archive (the usual "<hash>  <file>" form): the database row that holds it is the one thing a replacement computer does not have.
    fs.writeFileSync(`${target}.sha256`, `${checksum}  ${filename}\n`, { mode: 0o600 });
    const warning = references.missing.length ? ` WARNING: ${describeMissing(references.missing)}.` : '';
    execute(
      `UPDATE backups SET file_size = @size, checksum = @checksum, status = 'completed',
              notes = @note WHERE id = @id`,
      { id, size, checksum, note: `${note || `Database and ${fileCount} uploaded file(s).`}${warning}`.slice(0, 600) }
    );
    return { ok: true, backup: getBackup(id) };
  } catch (err) {
    fs.rmSync(work, { recursive: true, force: true });
    fs.rmSync(target, { force: true });
    fs.rmSync(`${target}.sha256`, { force: true });
    execute("UPDATE backups SET status = 'failed', notes = @note WHERE id = @id",
      { id, note: `Failed: ${err.message}`.slice(0, 300) });
    return { ok: false, reason: err.message, backup: getBackup(id) };
  }
}

/** Confirms the file on disk still matches what was recorded when it was made. */
export function verifyBackup(backup) {
  const file = resolveBackupFile(backup.filename);
  if (!file) return { ok: false, reason: 'missing' };
  if (!backup.checksum) return { ok: false, reason: 'no_checksum' };
  return checksumOf(file) === backup.checksum
    ? { ok: true }
    : { ok: false, reason: 'checksum_mismatch' };
}

/**
 * A thorough, read-only check beyond verifyBackup()'s checksum comparison —
 * the one an automated schedule needs, since nobody is watching to notice a
 * silently-corrupt archive. Extracts into a disposable temp directory (never
 * storage/, never the live database), opens the extracted copy read-only,
 * and confirms: SQLite's own integrity check passes; schema_migrations is
 * readable with a real version; and every storage folder the manifest
 * claims to have included is actually present in the extraction. Always
 * cleans up its own temp directory, on every exit path.
 */
export async function deepVerifyBackup(backup) {
  const file = resolveBackupFile(backup.filename);
  if (!file) return { ok: false, reason: 'missing' };
  if (!backup.filename.endsWith('.tar.gz')) return { ok: false, reason: 'unsupported_format' };

  const extractDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cciq-backup-verify-'));
  try {
    await tar.extract({ file, cwd: extractDir });

    const manifestPath = path.join(extractDir, 'manifest.json');
    if (!fs.existsSync(manifestPath)) return { ok: false, reason: 'no_manifest' };
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

    const dbPath = path.join(extractDir, manifest.database || 'database.sqlite');
    if (!fs.existsSync(dbPath)) return { ok: false, reason: 'no_database' };

    const Database = (await import('better-sqlite3')).default;
    const check = new Database(dbPath, { readonly: true });
    let integrity;
    let migrationVersion;
    try {
      integrity = check.pragma('integrity_check', { simple: true });
      const row = check.prepare('SELECT MAX(version) AS v, COUNT(*) AS c FROM schema_migrations').get();
      migrationVersion = row.v;
      if (!row.v || row.c === 0) return { ok: false, reason: 'no_migration_metadata' };
    } finally {
      check.close();
    }
    if (integrity !== 'ok') return { ok: false, reason: `integrity_check:${integrity}` };

    const missingFolders = (manifest.storage_folders || []).filter(
      (folder) => !fs.existsSync(path.join(extractDir, 'storage', folder))
    );
    if (missingFolders.length) return { ok: false, reason: `missing_storage_folders:${missingFolders.join(',')}` };

    // The archive is internally sound. Is it COMPLETE for what its own database says? Every stored file the database points at must be in the archive's storage. A missing one is a
    // WARNING (the archive is faithful to a system that was already missing it), reported, never ignored; and a folder the portal does not know is named so it is noticed.
    const warnings = [];
    const refCheck = new Database(dbPath, { readonly: true });
    let references;
    try { references = findMissingReferences(refCheck, path.join(extractDir, 'storage')); } finally { refCheck.close(); }
    if (references.missing.length) warnings.push(describeMissing(references.missing));
    const unknown = unknownStorageFolders(path.join(extractDir, 'storage'));
    if (unknown.length) warnings.push(`storage holds folder(s) the portal does not know: ${unknown.join(', ')}`);

    return { ok: true, migrationVersion, storageFolders: manifest.storage_folders || [], referencedFiles: references.checked, missingReferences: references.missing, warnings };
  } catch (err) {
    return { ok: false, reason: err.message };
  } finally {
    fs.rmSync(extractDir, { recursive: true, force: true });
  }
}

/** Suffix given to the live file a cutover step renames aside, never deleted until full success. */
const RESTORE_ORIGINAL_SUFFIX = '.pre-restore-original';

/**
 * A restore that crashed, was killed, or hit a bug before reaching its own
 * cleanup can leave shadow originals (name + RESTORE_ORIGINAL_SUFFIX) sitting
 * on disk. Their mere presence means an earlier attempt's on-disk outcome
 * was never confirmed complete - proceeding with a NEW restore anyway risks
 * that attempt's own rollback later renaming a STALE shadow (left by the
 * unrelated, earlier incident) back over the CURRENT live file, silently
 * restoring the wrong generation of data. Detected deterministically and
 * refused rather than guessed at.
 */
function staleShadowArtifacts(target, storageBase) {
  const candidates = [
    `${target}${RESTORE_ORIGINAL_SUFFIX}`,
    `${target}-wal${RESTORE_ORIGINAL_SUFFIX}`,
    `${target}-shm${RESTORE_ORIGINAL_SUFFIX}`
  ];
  if (fs.existsSync(storageBase)) {
    for (const entry of fs.readdirSync(storageBase)) {
      if (entry.endsWith(RESTORE_ORIGINAL_SUFFIX)) candidates.push(path.join(storageBase, entry));
    }
  }
  return candidates.filter((p) => fs.existsSync(p));
}

/**
 * Confirms `file` is a real, openable, genuine copy of this portal's
 * database - never merely "a file exists at that path". fileMustExist is
 * load-bearing here: without it, better-sqlite3 silently creates a brand
 * new, empty database at a missing path instead of failing, which is
 * exactly wrong when the whole point of this call is to prove a real file
 * survived a rollback.
 */
async function verifyRestoredDatabase(file) {
  try {
    const Database = (await import('better-sqlite3')).default;
    const conn = new Database(file, { readonly: true, fileMustExist: true });
    try {
      const integrity = conn.pragma('integrity_check', { simple: true });
      const hasUsers = conn.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table' AND name='users'").get().n > 0;
      return integrity === 'ok' && hasUsers;
    } finally {
      conn.close();
    }
  } catch {
    return false;
  }
}

/**
 * Replaces the live database with a backup. A safety copy of the current
 * database is taken first, so a restore can itself be undone even after the
 * fact. Everything is staged and verified before anything live is touched;
 * the cutover itself is a sequence of renames (the fastest, most atomic
 * operation a filesystem offers) that shadow the original file/folder aside
 * rather than deleting it, so a failure partway through can roll back
 * everything already done and leave the original state exactly as it was.
 * There is no OS primitive for a true multi-file atomic transaction across
 * a database file and several storage folders — this shadow-and-swap-with-
 * rollback sequence is the standard substitute. Storage is cut over before
 * the database specifically because the database swap requires closing the
 * shared connection (irreversible in this running process regardless of
 * outcome), so every earlier failure can still log through it normally; the
 * one step that cannot roll back to a *live* database in-process is the
 * final one. Restoring needs the application to reopen the database, so a
 * successful restore exits the process afterwards and the supervisor
 * restarts it — the same is now true of a restore that fails after the
 * database file was actually touched (see processRestartRequired below).
 */
/** True while a restore is running in this process; a second request must not start another (see restoreBackup). */
let restoreInProgress = false;

/**
 * Restores one backup. Only one restore may run at a time: two requests (a double click, two tabs) would otherwise both pass the
 * "earlier restore left files behind" check, both take a safety copy and both unpack into the same staging folder before either
 * has created a shadow file. The second is refused untouched.
 */
export async function restoreBackup(id, options = {}) {
  if (restoreInProgress) return { ok: false, reason: 'restore_in_progress' };
  restoreInProgress = true;
  try {
    return await performRestore(id, options);
  } finally {
    restoreInProgress = false;
  }
}

async function performRestore(id, { userId = null, reason = null } = {}) {
  const backup = getBackup(id);
  if (!backup) return { ok: false, reason: 'not_found' };
  if (backup.status !== 'completed') return { ok: false, reason: 'not_complete' };

  const file = resolveBackupFile(backup.filename);
  if (!file) return { ok: false, reason: 'missing' };

  const target = path.resolve(config.databaseFile);
  const storageBase = path.resolve(config.storageDir);

  const stale = staleShadowArtifacts(target, storageBase);
  if (stale.length) {
    recordRestore({
      backupId: id, status: 'failed', userId,
      note: `Refused: unresolved file(s) from an earlier interrupted restore: ${stale.join(', ')}`.slice(0, 300)
    });
    return { ok: false, reason: 'stale_shadow_artifacts', staleArtifacts: stale };
  }

  const verified = verifyBackup(backup);
  if (!verified.ok) {
    recordRestore({ backupId: id, status: 'failed', userId, note: `Verification failed: ${verified.reason}` });
    return { ok: false, reason: verified.reason };
  }

  // The restore takes a safety backup (about twice the data), unpacks the chosen archive (about its uncompressed size, estimated from the
  // archive generously) and stages a database copy beside the live file. Check all of that before anything is started.
  const restoreSpace = checkFreeSpace(backupDir(), dataBytes() * 2 + (Number(backup.file_size) || 0) * 4);
  if (!restoreSpace.ok) {
    recordRestore({ backupId: id, status: 'failed', userId, note: `Refused: not enough free disk space (${describeSpace(restoreSpace)})`.slice(0, 300) });
    return { ok: false, reason: 'insufficient_disk_space', message: NO_SPACE_MESSAGE(restoreSpace) };
  }
  const dbSpace = checkFreeSpace(path.dirname(target), treeBytes(target));
  if (!dbSpace.ok) {
    recordRestore({ backupId: id, status: 'failed', userId, note: `Refused: not enough free disk space beside the database (${describeSpace(dbSpace)})`.slice(0, 300) });
    return { ok: false, reason: 'insufficient_disk_space', message: NO_SPACE_MESSAGE(dbSpace) };
  }

  const safety = await createBackup({ userId, kind: 'pre_restore', note: `Taken before restoring ${backup.filename}` });
  if (!safety.ok) {
    recordRestore({ backupId: id, status: 'failed', userId, note: 'Could not take a safety copy first' });
    return { ok: false, reason: 'safety_backup_failed' };
  }

  const staged = `${target}.restore-staged`;
  const extractDir = path.join(backupDir(), '.restore-extract');

  /*
   * Logs a failed restore using whichever database connection is actually
   * usable right now. Before the database file is touched, that is the
   * normal shared connection; once it has been closed (dbClosed: true) it
   * can never be reopened in this process, so a fresh, short-lived
   * connection against `target` is used instead — by the time this is ever
   * called with dbClosed: true, the rollback below has already guaranteed
   * `target` is the original, working database again.
   */
  async function logFailure(message, dbClosed, { fatal = false } = {}) {
    const note = `Failed: ${message}${fatal ? ' [FATAL: rollback not fully verified]' : ''}`.slice(0, 300);
    if (!dbClosed) {
      recordRestore({ backupId: id, status: 'failed', userId, note });
      return true;
    }
    try {
      // fileMustExist: never silently create a fresh, empty database merely
      // to log a failure message into it. If `target` cannot be opened as a
      // real, pre-existing file, that is itself proof the rollback did not
      // truly restore it - masking that with a brand-new empty database at
      // the live path would be catastrophically worse than the original
      // failure, and this insert must fail rather than do that.
      const Database = (await import('better-sqlite3')).default;
      const conn = new Database(target, { fileMustExist: true });
      try {
        conn.prepare(
          `INSERT INTO backup_restores (backup_id, status, notes, restored_at, restored_by)
           VALUES (?, 'failed', ?, ?, ?)`
        ).run(id, note, nowIso(), userId);
      } finally {
        conn.close();
      }
      return true;
    } catch (logErr) {
      console.error('[backup] restore failed and the failure could not be logged:', logErr.message);
      return false;
    }
  }

  // Lifecycle flags. `databaseClosed` flips the instant the shared connection
  // is closed (irreversible in this process); `replaced` flips only once the
  // restored database is actually in place at the live path. Everything that
  // runs after either must not depend on the closed connection, and after
  // `replaced` must never be able to change the outcome from "restored".
  let databaseClosed = false;
  let replaced = false;

  try {
    fs.rmSync(extractDir, { recursive: true, force: true });
    fs.mkdirSync(extractDir, { recursive: true, mode: 0o700 });

    /*
     * Backups made before the archive format are a gzipped database on its own.
     * Those still restore, they simply carry no uploaded files.
     */
    const isArchive = backup.filename.endsWith('.tar.gz');
    if (isArchive) {
      await tar.extract({ file, cwd: extractDir });
      const extractedDb = path.join(extractDir, 'database.sqlite');
      if (!fs.existsSync(extractedDb)) {
        fs.rmSync(extractDir, { recursive: true, force: true });
        await logFailure('Archive contains no database', false);
        return { ok: false, reason: 'invalid_backup' };
      }
      fs.renameSync(extractedDb, staged);
    } else {
      await pipeline(fs.createReadStream(file), createGunzip(), fs.createWriteStream(staged));
    }

    // Stage and verify everything before anything live is touched: the
    // database must be a readable, genuine copy of this portal's schema,
    // and every storage folder the archive carries must actually be
    // present and readable in the extract.
    const check = await import('better-sqlite3').then((m) => new m.default(staged, { readonly: true, fileMustExist: true }));
    let integrity;
    let hasUsers;
    let schemaCompatibility;
    try {
      integrity = check.pragma('integrity_check', { simple: true });
      hasUsers = check.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table' AND name='users'").get().n;
      // Migration-history compatibility is established HERE, on the staged
      // copy, before anything live is touched: the same exact-set check the
      // application itself uses at startup (see checkSchemaCompatibility()
      // in db/migrate.js), run against the staged file rather than the live
      // connection. Never migrates the backup - an incompatible one is
      // refused, and the operator decides what to do about it explicitly.
      if (integrity === 'ok' && hasUsers > 0) schemaCompatibility = checkSchemaCompatibility(check);
    } finally {
      check.close();
    }

    if (integrity !== 'ok' || hasUsers === 0) {
      fs.rmSync(staged, { force: true });
      fs.rmSync(extractDir, { recursive: true, force: true });
      await logFailure(`Staged file rejected: ${integrity}`, false);
      return { ok: false, reason: 'invalid_backup' };
    }

    if (!schemaCompatibility.ok) {
      fs.rmSync(staged, { force: true });
      fs.rmSync(extractDir, { recursive: true, force: true });
      const detail = schemaCompatibility.reason === 'behind'
        ? `missing migration(s): ${schemaCompatibility.missing.join(', ')}`
        : schemaCompatibility.reason === 'ahead'
          ? `unrecognized migration(s): ${schemaCompatibility.unexpected.join(', ')}`
          : 'no migration history';
      await logFailure(`Backup schema is not compatible with this version of the application (${schemaCompatibility.reason}: ${detail}). Nothing was changed.`, false);
      return {
        ok: false, reason: 'incompatible_backup_schema',
        schemaReason: schemaCompatibility.reason,
        missing: schemaCompatibility.missing || [],
        unexpected: schemaCompatibility.unexpected || []
      };
    }

    const extractedStorage = path.join(extractDir, 'storage');
    const storageFolders = fs.existsSync(extractedStorage)
      ? fs.readdirSync(extractedStorage).filter((folder) => folder !== 'backups')
      : [];
    for (const folder of storageFolders) {
      // Fails now, before anything live is touched, rather than partway through the cutover below.
      fs.accessSync(path.join(extractedStorage, folder), fs.constants.R_OK);
    }

    // Codex/independent verification: the checks above only ever validated
    // whatever folders HAPPENED to be present in the extraction. An archive
    // truncated or partially written mid-transfer, missing one of the
    // folders its own manifest declares, would silently restore just the
    // folders that DID make it, leaving whichever one didn't untouched at
    // its old LIVE content - a restore that ends up part archive, part live
    // state, with nothing in the result to say so. The manifest (written at
    // backup time, see createBackup()) is this backup's own declaration of
    // what it is supposed to contain; every folder it declares must
    // actually be present here before anything live is touched.
    if (isArchive) {
      const manifestPath = path.join(extractDir, 'manifest.json');
      if (!fs.existsSync(manifestPath)) {
        fs.rmSync(staged, { force: true });
        fs.rmSync(extractDir, { recursive: true, force: true });
        await logFailure('Archive contains no manifest', false);
        return { ok: false, reason: 'invalid_backup' };
      }
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      const declaredFolders = manifest.storage_folders || [];
      const missingFolders = declaredFolders.filter((folder) => !storageFolders.includes(folder));
      if (missingFolders.length) {
        fs.rmSync(staged, { force: true });
        fs.rmSync(extractDir, { recursive: true, force: true });
        await logFailure(`Archive is missing storage folder(s) its own manifest declares: ${missingFolders.join(', ')}`, false);
        return { ok: false, reason: 'incomplete_archive', missingFolders };
      }
    }

    const note = `Restored ${backup.filename}. Safety copy: ${safety.backup.filename}.${reason ? ` Reason: ${reason}` : ''}`;

    /*
     * A restore rewinds the database, including its own audit log, so the
     * record of the restore is written into the staged copy before it is
     * swapped in. Without this, the restored portal would carry no trace of
     * having been restored.
     */
    const staging = await import('better-sqlite3').then((m) => new m.default(staged));
    const at = nowIso();
    try {
      staging.prepare(
        `INSERT INTO backup_restores (backup_id, status, notes, restored_at, restored_by)
         VALUES (?, 'complete', ?, ?, ?)`
      ).run(null, note, at, userId);
      staging.prepare(
        `INSERT INTO audit_logs (user_id, actor_label, action, entity_type, entity_id, result, detail, created_at)
         VALUES (?, ?, 'admin.backup_restored', 'backup', ?, 'success', ?, ?)`
      ).run(userId, null, String(id), JSON.stringify({
        filename: backup.filename,
        safety_copy: safety.backup.filename,
        reason
      }), at);
    } catch (writeErr) {
      // The restore itself is still valid; note that the record could not be carried over.
      console.error('[backup] could not write the restore record into the restored database:', writeErr.message);
    } finally {
      staging.close();
    }

    // Recorded into any recovery interlock this restore might have to write,
    // so tools/clear-recovery-interlock.mjs can later tell a folder that was
    // legitimately empty from one whose restored content has gone missing.
    // Counted now, from the staged extract, before anything moves.
    const storageFolderFileCounts = {};
    for (const folder of storageFolders) {
      try {
        storageFolderFileCounts[folder] = countFiles(path.join(extractedStorage, folder));
      } catch { /* unknown count: the clear tool then checks existence only for this folder */ }
    }

    // --- Cutover: storage first, database last (see the function comment). ---
    fs.mkdirSync(storageBase, { recursive: true });
    const swapped = [];

    // Returns true only if every folder was verifiably put back - never
    // assumed from "the rename calls didn't throw" alone being reported
    // elsewhere. A caller that ignored this return value could tell an
    // operator storage was safely rolled back when it was not.
    function rollbackStorage() {
      let allOk = true;
      for (const { folder, hadOriginal } of swapped.reverse()) {
        const destination = path.join(storageBase, folder);
        const original = `${destination}${RESTORE_ORIGINAL_SUFFIX}`;
        try {
          fs.rmSync(destination, { recursive: true, force: true });
          if (hadOriginal) fs.renameSync(original, destination);
          if (hadOriginal && !fs.existsSync(destination)) allOk = false;
        } catch (rollbackErr) {
          console.error(`[backup] could not roll back storage folder "${folder}" after a failed restore:`, rollbackErr.message);
          allOk = false;
        }
      }
      return allOk;
    }

    // Cleanup of the working files is always best-effort against the RESULT
    // already decided by the caller - a secondary fs error here (e.g. a
    // locked handle) must never be allowed to propagate up and replace the
    // primary failure/fatal state with an uncaught exception.
    function cleanupWorkingFiles() {
      try { fs.rmSync(staged, { force: true }); } catch (e) { console.error('[backup] could not remove the staged database after a failed restore:', e.message); }
      try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (e) { console.error('[backup] could not remove the extract directory after a failed restore:', e.message); }
    }

    try {
      for (const folder of storageFolders) {
        const destination = path.join(storageBase, folder);
        const original = `${destination}${RESTORE_ORIGINAL_SUFFIX}`;
        const hadOriginal = fs.existsSync(destination);
        if (hadOriginal) fs.renameSync(destination, original);
        // Tracked immediately after the aside-rename, not after the whole
        // two-step swap: if the forward rename just below throws, this
        // folder's original has already moved aside with nothing back in
        // its place yet, and rollbackStorage() must still know to put it
        // back — rmSync-then-rename-original-back is a correct no-op for
        // "aside-only" (nothing to remove) and a correct undo for "fully
        // swapped" alike, so one rollback path handles both.
        swapped.push({ folder, hadOriginal });
        fs.renameSync(path.join(extractedStorage, folder), destination);
      }
    } catch (storageErr) {
      // The database connection is still open at this point (storage is cut
      // over before the database - see the function comment), so a storage
      // rollback failure here doesn't require a restart, but it does mean
      // storage itself may be left inconsistent even though the database
      // never moved - that must be surfaced, not silently swallowed.
      const storageRolledBack = rollbackStorage();
      cleanupWorkingFiles();
      const fatal = !storageRolledBack;
      await logFailure(`Storage cutover failed: ${storageErr.message}`, false, { fatal });
      if (fatal) {
        // Storage in an unverified state is dangerous to keep serving from
        // even though the database connection itself is untouched - a
        // member photo, document, or upload could be silently missing or
        // wrong. The interlock stops the NEXT start; processRestartRequired
        // makes THIS running process stop serving normally right now too,
        // the same as a fatal database rollback already does.
        writeRecoveryInterlock({
          kind: 'storage',
          reason: storageErr.message,
          safetyBackupFilename: safety.backup.filename,
          detail: { backupId: id, storageFolders, storageFolderFileCounts }
        });
      }
      return {
        ok: false,
        reason: storageErr.message,
        ...(fatal
          ? {
            fatal: true,
            processRestartRequired: true,
            state: 'fatal_unrecovered',
            recoveryHint: `Storage could not be fully rolled back. A safety copy taken immediately before this restore is available as ${safety.backup.filename}. The portal will not start normally again until this is manually recovered - see tools/clear-recovery-interlock.mjs.`
          }
          : { state: 'rolled_back' })
      };
    }

    // Database swap — last, and the one step whose failure the running
    // process cannot fully recover from (the shared connection, once
    // closed, stays closed) even though the *files* can still be rolled
    // back for the next process start.
    const dbOriginal = `${target}${RESTORE_ORIGINAL_SUFFIX}`;
    const walOriginal = `${target}-wal${RESTORE_ORIGINAL_SUFFIX}`;
    const shmOriginal = `${target}-shm${RESTORE_ORIGINAL_SUFFIX}`;
    try {
      databaseClosed = true;
      db.close();
      if (fs.existsSync(`${target}-wal`)) fs.renameSync(`${target}-wal`, walOriginal);
      if (fs.existsSync(`${target}-shm`)) fs.renameSync(`${target}-shm`, shmOriginal);
      fs.renameSync(target, dbOriginal);
      fs.renameSync(staged, target);
      replaced = true;
    } catch (dbErr) {
      // Each rename below is best-effort against the OTHERS, but whether the
      // original database is truly back must be VERIFIED afterward - never
      // assumed merely because the rename call itself didn't throw. A path
      // existing at `target` could otherwise be a stale leftover or (via the
      // logFailure reconnect below, without fileMustExist) a freshly-created
      // empty database, either of which would make "rollback succeeded" a
      // dangerous lie.
      let dbRolledBack = false;
      try {
        if (fs.existsSync(dbOriginal)) fs.renameSync(dbOriginal, target);
        dbRolledBack = await verifyRestoredDatabase(target);
      } catch (e) {
        console.error('[backup] could not restore the original database file:', e.message);
      }
      try { if (fs.existsSync(walOriginal)) fs.renameSync(walOriginal, `${target}-wal`); } catch { /* best-effort */ }
      try { if (fs.existsSync(shmOriginal)) fs.renameSync(shmOriginal, `${target}-shm`); } catch { /* best-effort */ }
      const storageRolledBack = rollbackStorage();
      cleanupWorkingFiles();

      const fatal = !dbRolledBack || !storageRolledBack;
      await logFailure(`Database cutover failed: ${dbErr.message}`, true, { fatal });
      if (fatal) {
        // Written BEFORE this function returns (and well before the route's
        // own process.exit()), so the interlock exists no matter how soon
        // the process actually terminates - the very next ordinary startup,
        // by the supervisor or anyone else, must see it before it can ever
        // reach db/index.js's own new Database(config.databaseFile) call.
        writeRecoveryInterlock({
          kind: !dbRolledBack ? 'database' : 'storage',
          reason: dbErr.message,
          safetyBackupFilename: safety.backup.filename,
          detail: { backupId: id, dbRolledBack, storageRolledBack, storageFolders, storageFolderFileCounts }
        });
      }
      return {
        ok: false,
        reason: dbErr.message,
        processRestartRequired: true,
        fatal,
        state: fatal ? 'fatal_unrecovered' : 'restart_required',
        ...(fatal ? {
          recoveryHint: `The original database could not be verified as restored. A safety copy taken immediately before this restore is available as ${safety.backup.filename} - do not assume normal recovery on restart; this needs manual attention before the portal is used again. See tools/clear-recovery-interlock.mjs.`
        } : {})
      };
    }

    // Full success — the shadow originals are no longer needed. Each
    // removal is independently best-effort: the cutover itself already
    // succeeded (verified) above, so a failure removing a now-unneeded
    // shadow file must never be conflated with the restore itself failing,
    // and must never fall through to the generic outer catch below, which
    // assumes the shared connection is still open (dbClosed: false) - it is
    // not, at this point. Left behind, one of these would also silently
    // block the NEXT restore attempt via staleShadowArtifacts() without
    // this restore's own result ever saying so - reported as
    // cleanupIncomplete instead of silently ignored.
    //
    // Post-replacement safety: from here the restored database IS the live
    // database and the shared connection is closed, so nothing below may
    // (a) touch that connection, (b) throw out of this section into the
    // generic catch at the bottom of this function, or (c) turn a completed
    // replacement into a reported failure. Every step is independently
    // guarded; any problem is reported through postReplacementWarnings and
    // the process log only - never through the database.
    const postReplacementWarnings = [];
    let shadowCleanupFailed = false;
    let filesRestored = null;
    try {
      const shadowPaths = [
        dbOriginal, walOriginal, shmOriginal,
        // The storage-folder shadows (${destination}${RESTORE_ORIGINAL_SUFFIX}
        // for each swapped folder) were never cleaned up here at all before
        // this fix - every successful restore left them behind permanently,
        // which staleShadowArtifacts() (checked at the START of the next
        // restore attempt) would then always find and refuse against,
        // mistaking this restore's own normal leftovers for evidence of an
        // earlier interrupted one.
        ...swapped.map(({ folder }) => `${path.join(storageBase, folder)}${RESTORE_ORIGINAL_SUFFIX}`)
      ];
      for (const shadowPath of shadowPaths) {
        try {
          fs.rmSync(shadowPath, { recursive: true, force: true });
        } catch (e) {
          console.error(`[backup] could not remove leftover shadow file "${shadowPath}" after a successful restore:`, e.message);
          postReplacementWarnings.push(`could not remove leftover shadow file: ${shadowPath}`);
          shadowCleanupFailed = true;
        }
      }

      // Reporting only: a failure counting restored files (a permissions
      // error, a locked handle) says nothing about whether the restore
      // worked, so it must not be able to fail it.
      try {
        filesRestored = 0;
        for (const { folder } of swapped) {
          filesRestored += countFiles(path.join(storageBase, folder));
        }
      } catch (e) {
        filesRestored = null;
        console.error('[backup] restore succeeded but the restored file count could not be determined:', e.message);
        postReplacementWarnings.push(`restored file count unavailable: ${e.message}`);
      }

      try {
        fs.rmSync(extractDir, { recursive: true, force: true });
      } catch (e) {
        console.error('[backup] could not remove the extract directory after a successful restore:', e.message);
        postReplacementWarnings.push('could not remove the extract directory');
      }
    } catch (unexpected) {
      // Nothing above should reach here; if something does, the replacement
      // has still happened and the outcome stays "restored".
      console.error('[backup] unexpected error after a successful restore replacement:', unexpected.message);
      postReplacementWarnings.push(`unexpected post-replacement error: ${unexpected.message}`);
    }

    return {
      ok: true, backup, safety: safety.backup, filesRestored,
      // The shared connection is closed and the file replaced: the running
      // process must restart to serve the restored data.
      processRestartRequired: true,
      ...(postReplacementWarnings.length ? { postReplacementWarnings } : {}),
      ...(shadowCleanupFailed ? {
        cleanupIncomplete: true,
        recoveryHint: 'The restore itself succeeded, but a leftover file from the cutover could not be removed automatically and must be deleted by hand before the next restore can run.'
      } : {})
    };
  } catch (err) {
    try { fs.rmSync(staged, { force: true }); } catch (e) { console.error('[backup] could not remove the staged database after a failed restore:', e.message); }
    try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (e) { console.error('[backup] could not remove the extract directory after a failed restore:', e.message); }
    // Logs through whichever connection is actually usable: once the shared
    // one has been closed (databaseClosed) a fresh, fileMustExist connection
    // is used instead - never the closed one - and the result still tells the
    // caller a restart is required, so that state is never lost.
    await logFailure(err.message, databaseClosed);
    return {
      ok: false,
      reason: err.message,
      ...(databaseClosed
        ? { processRestartRequired: true, fatal: false, state: replaced ? 'restored_restart_required' : 'restart_required' }
        : {})
    };
  }
}

function recordRestore({ backupId, status, userId, note }) {
  execute(
    `INSERT INTO backup_restores (backup_id, status, notes, restored_at, restored_by)
     VALUES (@backupId, @status, @note, @at, @by)`,
    { backupId, status, note, at: nowIso(), by: userId }
  );
}

export function deleteBackup(id) {
  const backup = getBackup(id);
  if (!backup) return null;
  const file = resolveBackupFile(backup.filename);
  if (file) { fs.rmSync(file, { force: true }); fs.rmSync(`${file}.sha256`, { force: true }); }
  execute('DELETE FROM backups WHERE id = @id', { id });
  return backup;
}

export function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Keeps the newest few backups and removes older ones beyond the limit. */
export function pruneBackups({ keep = 20 } = {}) {
  const all = listBackups({ limit: 1000 }).filter((b) => b.kind !== 'pre_restore');
  const removed = [];
  for (const backup of all.slice(keep)) {
    deleteBackup(backup.id);
    removed.push(backup.filename);
  }
  return removed;
}
