import { query, queryOne, execute, transaction } from '../db/index.js';
import { likePattern } from '../lib/like.js';
import { nowIso } from '../lib/dates.js';
import { fullName, displayName } from './members.js';
import { childrenOf, dependantsOf, guardianOf } from './congregations.js';

/**
 * A family group (household) is who should be grouped together
 * operationally — distinct from the explicit spouse/father/mother/guardian
 * relationships already on `members`, which describe how two people are
 * related. Nothing here duplicates a relationship column: membership is the
 * only thing stored, and every relationship label shown to an administrator
 * is computed from the existing columns at read time. A member belongs to at
 * most one family group at a time (enforced by a UNIQUE constraint on
 * `family_group_members.member_id`, not just application logic).
 */

export const FAMILY_GROUP_SORT_COLUMNS = ['name', 'members', 'newest'];

function orderClause(sort, direction) {
  const dir = direction === 'desc' ? 'DESC' : 'ASC';
  switch (sort) {
    case 'members': return `member_count ${dir}, fg.name COLLATE NOCASE ASC, fg.id ASC`;
    case 'newest': return `fg.created_at ${dir}, fg.id ${dir}`;
    default: return `fg.name COLLATE NOCASE ${dir}, fg.id ${dir}`;
  }
}

export function listFamilyGroups({ search = '', sort = 'name', direction = 'asc', page = 1, pageSize = 20 } = {}) {
  const term = String(search || '').trim();
  const where = term ? "WHERE fg.name LIKE @term ESCAPE '\\'" : '';
  const params = term ? { term: likePattern(term) } : {};

  const total = queryOne(
    `SELECT COUNT(*) AS n FROM family_groups fg ${where}`,
    params
  ).n;

  const pages = Math.max(Math.ceil(total / pageSize), 1);
  const currentPage = Math.min(Math.max(page, 1), pages);
  const offset = (currentPage - 1) * pageSize;

  const rows = query(
    `SELECT fg.*,
            (SELECT COUNT(*) FROM family_group_members WHERE family_group_id = fg.id) AS member_count,
            p.first_name AS primary_first, p.last_name AS primary_last, p.preferred_name AS primary_preferred
       FROM family_groups fg
       LEFT JOIN members p ON p.id = fg.primary_member_id
       ${where}
      ORDER BY ${orderClause(sort, direction)}
      LIMIT @limit OFFSET @offset`,
    { ...params, limit: pageSize, offset }
  ).map((row) => ({
    ...row,
    primaryName: row.primary_member_id
      ? displayName({ first_name: row.primary_first, last_name: row.primary_last, preferred_name: row.primary_preferred })
      : null
  }));

  return { rows, total, page: currentPage, pages };
}

export function getFamilyGroup(id) {
  const group = queryOne('SELECT * FROM family_groups WHERE id = @id', { id });
  if (!group) return null;

  const members = query(
    `SELECT m.*, fgm.joined_at AS family_joined_at
       FROM family_group_members fgm
       JOIN members m ON m.id = fgm.member_id
      WHERE fgm.family_group_id = @id
      ORDER BY m.date_of_birth ASC, m.last_name COLLATE NOCASE`,
    { id }
  );

  const primary = group.primary_member_id
    ? members.find((m) => m.id === group.primary_member_id) || queryOne('SELECT * FROM members WHERE id = @id', { id: group.primary_member_id })
    : null;

  return { ...group, members, primary };
}

/** Which family group (if any) a member currently belongs to. */
export function familyGroupForMember(memberId) {
  return queryOne(
    `SELECT fg.* FROM family_group_members fgm
       JOIN family_groups fg ON fg.id = fgm.family_group_id
      WHERE fgm.member_id = @memberId`,
    { memberId }
  ) || null;
}

export function createFamilyGroup({ name, primaryMemberId = null }, { userId = null } = {}) {
  const at = nowIso();
  // The group and its first member are one unit: no group is left behind without the member it was created for.
  const id = transaction(() => {
    const result = execute(
      `INSERT INTO family_groups (name, primary_member_id, created_at, updated_at, created_by)
       VALUES (@name, @primaryMemberId, @at, @at, @by)`,
      { name: String(name).trim(), primaryMemberId: primaryMemberId || null, at, by: userId }
    );
    const newId = Number(result.lastInsertRowid);

    if (primaryMemberId) {
      const conflict = familyGroupForMember(primaryMemberId);
      if (!conflict) {
        execute(
          'INSERT INTO family_group_members (family_group_id, member_id, joined_at) VALUES (@id, @memberId, @at)',
          { id: newId, memberId: primaryMemberId, at }
        );
      }
    }
    return newId;
  })();

  return getFamilyGroup(id);
}

export function renameFamilyGroup(id, name) {
  execute(
    'UPDATE family_groups SET name = @name, updated_at = @at WHERE id = @id',
    { id, name: String(name).trim(), at: nowIso() }
  );
  return getFamilyGroup(id);
}

/** The primary/contact member must already belong to this family group. */
export function setPrimaryMember(familyGroupId, memberId) {
  if (memberId) {
    const belongs = queryOne(
      'SELECT 1 AS found FROM family_group_members WHERE family_group_id = @familyGroupId AND member_id = @memberId',
      { familyGroupId, memberId }
    );
    if (!belongs) return { ok: false, reason: 'not_a_member' };
  }
  execute(
    'UPDATE family_groups SET primary_member_id = @memberId, updated_at = @at WHERE id = @id',
    { id: familyGroupId, memberId: memberId || null, at: nowIso() }
  );
  return { ok: true, group: getFamilyGroup(familyGroupId) };
}

/**
 * Adds an existing member to a family group. If the member already belongs
 * to a different family group, nothing is changed — the caller must confirm
 * a move via moveMemberToFamilyGroup() instead, so membership is never
 * silently duplicated or silently reassigned.
 */
export function addMemberToFamilyGroup(familyGroupId, memberId) {
  const existing = familyGroupForMember(memberId);
  if (existing && existing.id !== familyGroupId) {
    return { ok: false, reason: 'already_in_family', existingFamilyGroup: existing };
  }
  if (existing && existing.id === familyGroupId) {
    return { ok: true, alreadyMember: true };
  }
  execute(
    'INSERT INTO family_group_members (family_group_id, member_id, joined_at) VALUES (@familyGroupId, @memberId, @at)',
    { familyGroupId, memberId, at: nowIso() }
  );
  return { ok: true, alreadyMember: false };
}

/** Removes a member from a family group. The member record is untouched. */
export function removeMemberFromFamilyGroup(familyGroupId, memberId) {
  execute(
    'DELETE FROM family_group_members WHERE family_group_id = @familyGroupId AND member_id = @memberId',
    { familyGroupId, memberId }
  );
}

/**
 * Moves a member from whichever family group they are currently in (if any)
 * into a different one, in a single transaction. Used only after an
 * administrator has explicitly confirmed the move on a conflict screen.
 */
export function moveMemberToFamilyGroup(familyGroupId, memberId) {
  return transaction(() => {
    execute('DELETE FROM family_group_members WHERE member_id = @memberId', { memberId });
    execute(
      'INSERT INTO family_group_members (family_group_id, member_id, joined_at) VALUES (@familyGroupId, @memberId, @at)',
      { familyGroupId, memberId, at: nowIso() }
    );
  })();
}

/** An empty family group can be deleted outright; a populated one cannot. */
export function deleteFamilyGroup(id) {
  const group = getFamilyGroup(id);
  if (!group) return { ok: false, reason: 'not_found' };
  if (group.members.length > 0) return { ok: false, reason: 'not_empty', group };
  execute('DELETE FROM family_groups WHERE id = @id', { id });
  return { ok: true, group };
}

/**
 * A short, human-readable label for how a member relates to the other people
 * already in the same family group — computed from the existing explicit
 * relationship columns, never stored. A member with no explicit relationship
 * to anyone else in the group is labelled a plain "Household member", never
 * left blank and never guessed at.
 */
export function relationshipLabelsFor(member, groupMembers) {
  const byId = new Map(groupMembers.map((m) => [m.id, m]));
  const labels = [];

  if (member.spouse_member_id && byId.has(member.spouse_member_id)) {
    labels.push(`Spouse of ${fullName(byId.get(member.spouse_member_id))}`);
  }

  const parentNames = [];
  if (member.father_member_id && byId.has(member.father_member_id)) parentNames.push(fullName(byId.get(member.father_member_id)));
  if (member.mother_member_id && byId.has(member.mother_member_id)) parentNames.push(fullName(byId.get(member.mother_member_id)));
  if (parentNames.length) labels.push(`Child of ${parentNames.join(' and ')}`);

  if (member.guardian_member_id && byId.has(member.guardian_member_id)) {
    const guardianName = fullName(byId.get(member.guardian_member_id));
    labels.push(member.guardian_relation ? `Guardian: ${guardianName} (${member.guardian_relation})` : `Guardian: ${guardianName}`);
  }

  const wards = groupMembers.filter((m) => m.guardian_member_id === member.id);
  if (wards.length) labels.push(`Guardian of ${wards.map((w) => fullName(w)).join(', ')}`);

  const otherChildren = groupMembers.filter((m) => m.id !== member.id && (m.father_member_id === member.id || m.mother_member_id === member.id));
  if (otherChildren.length) labels.push(`Parent of ${otherChildren.map((c) => fullName(c)).join(', ')}`);

  if (!labels.length) labels.push('Household member');
  return labels;
}

/**
 * Possible family members suggested purely from explicit relationships
 * already recorded for the members currently in this family group — never
 * from surname, address, phone, email, cell group, or any other soft
 * signal. Anyone already belonging to any family group (this one or another)
 * is left out, since adding them immediately requires the same confirm-a-
 * move flow as the manual picker. Suggestions are informational only; the
 * administrator must still add each one deliberately.
 */
export function suggestFamilyMembers(familyGroupId) {
  const group = getFamilyGroup(familyGroupId);
  if (!group) return [];

  const currentIds = new Set(group.members.map((m) => m.id));
  const suggestions = new Map();

  function offer(candidate, reason) {
    if (!candidate || currentIds.has(candidate.id) || suggestions.has(candidate.id)) return;
    if (familyGroupForMember(candidate.id)) return;
    suggestions.set(candidate.id, { member: candidate, reason });
  }

  for (const member of group.members) {
    if (member.spouse_member_id) {
      const spouse = queryOne('SELECT * FROM members WHERE id = @id', { id: member.spouse_member_id });
      offer(spouse, `Spouse of ${fullName(member)}`);
    }
    if (member.father_member_id) {
      const father = queryOne('SELECT * FROM members WHERE id = @id', { id: member.father_member_id });
      offer(father, `Father of ${fullName(member)}`);
    }
    if (member.mother_member_id) {
      const mother = queryOne('SELECT * FROM members WHERE id = @id', { id: member.mother_member_id });
      offer(mother, `Mother of ${fullName(member)}`);
    }
    if (member.guardian_member_id) {
      const guardian = guardianOf(member.id);
      offer(guardian, `Guardian of ${fullName(member)}`);
    }
    for (const child of childrenOf(member.id)) {
      offer(child, `Child of ${fullName(member)}`);
    }
    for (const ward of dependantsOf(member.id)) {
      offer(ward, `${fullName(member)} is their guardian`);
    }
  }

  return [...suggestions.values()];
}
