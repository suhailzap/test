import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import express from 'express';
import session from 'express-session';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

import config, { ROOT } from './config/env.js';
import { ensureSchemaCompatible } from './db/migrate.js';
import { execute, queryOne } from './db/index.js';
import { recordAudit } from './lib/audit.js';
import { ensureSettings, getSetting } from './lib/settings.js';
import { pruneStagedImports } from './services/imports.js';
import { evaluateSafely as evaluateMembershipReviews } from './services/membership-review.js';
import { SqliteSessionStore } from './lib/session-store.js';
import { csrfProtection } from './lib/csrf.js';
import { attachUser } from './middleware/auth.js';
import { flashMessages, notFound, errorHandler } from './middleware/errors.js';
import { collapseRepeatedFields } from './middleware/body-fields.js';
import { buildNavigation } from './lib/navigation.js';
import * as dates from './lib/dates.js';
import { dobDisplay } from './services/dob-quality.js';
import { verseOfTheDay } from './lib/verse-of-the-day.js';
import { displayName, scopeFor, STATUS_LABELS } from './services/members.js';
import { ATTENDANCE_LABELS, ATTENDANCE_GLYPHS, sessionDisplayStatus } from './services/attendance.js';
import { ensureFridaySessions } from './services/friday-service.js';
import { generateReminders, notifyNewReminders, unreadNotificationCount, pruneNotifications } from './services/reminders.js';

import authRoutes from './routes/auth.js';
import dashboardRoutes from './routes/dashboard.js';
import memberRoutes from './routes/members.js';
import adminRoutes from './routes/admin.js';
import cellGroupRoutes from './routes/cell-groups.js';
import attendanceRoutes from './routes/attendance.js';
import accountRoutes from './routes/account.js';
import reminderRoutes from './routes/reminders.js';
import activityRoutes from './routes/activities.js';
import announcementRoutes from './routes/announcements.js';
import ecaqRoutes from './routes/ecaq.js';
import { DEFAULT_BOARD_BACKGROUND } from './services/ecaq.js';
import adminUserRoutes from './routes/admin-users.js';
import reportRoutes from './routes/reports.js';
import churchRoutes from './routes/church.js';
import visitorRoutes from './routes/visitors.js';
import searchRoutes from './routes/search.js';
import ministryRoutes from './routes/ministries.js';
import familyGroupRoutes from './routes/family-groups.js';
import kioskRoutes from './routes/kiosk.js';
import quickAccessRoutes from './routes/quick-access.js';
import helpRoutes from './routes/help.js';
import documentRoutes from './routes/documents.js';

/*
 * Migration execution safety (Codex/independent verification): normal
 * startup used to call migrate() directly, silently advancing the schema
 * as a side effect of simply starting the portal - exactly how migration
 * 0028 ended up applied without an intentional deployment. Startup now
 * only ever CHECKS that the schema is exactly what this code expects
 * (never applies anything) and refuses to start at all - not partially,
 * not with a warning - if it isn't. The only sanctioned way to advance the
 * schema is the explicit `npm run db:migrate` command. See
 * ensureSchemaCompatible() in db/migrate.js.
 */
try {
  ensureSchemaCompatible();
} catch (err) {
  console.error('');
  console.error('  CCIQ Portal cannot start:');
  console.error(`  ${err.message}`);
  console.error('');
  process.exit(1);
}
ensureSettings();

/*
 * Sessions are kept in the database so a restart does not normally sign
 * everyone out — but on a shared church computer that is exactly the problem:
 * the portal runs from a batch file, and stopping and restarting it must not
 * leave the previous person's session usable by whoever starts it next. Every
 * server start clears every session, with no exception, so a fresh sign-in is
 * always required afterwards.
 */
const clearedSessionCount = queryOne('SELECT COUNT(*) AS n FROM sessions').n;
execute('DELETE FROM sessions');
if (clearedSessionCount > 0) {
  recordAudit({
    action: 'system.sessions_cleared_on_startup',
    actorLabel: 'System',
    detail: { count: clearedSessionCount }
  });
}

const app = express();
const viewsDir = path.join(ROOT, 'src', 'views');
const publicDir = path.join(ROOT, 'src', 'public');

/*
 * Static assets are cached for a week in production (see below), so a fixed
 * filename means a fix can sit in an already-visited browser's cache for that
 * whole week. Every <link>/<script> tag appends the file's own content hash
 * as ?v= — the URL itself changes whenever the file does, without giving up
 * the caching benefit for anyone whose copy is still current.
 *
 * The hash is recomputed per request rather than once at startup, because a
 * file can change while the process keeps running — a CSS/JS edit deployed
 * without a server restart used to keep serving the *previous* restart's
 * hash indefinitely, meaning a browser that had already cached the old file
 * under that unchanging URL had no reason to ever ask for the new one. A raw
 * per-request file read would waste work on every page view, so this only
 * re-hashes when the file's own mtime has actually moved since the last
 * check — an `fs.statSync` is cheap enough to do unconditionally.
 */
const assetHashCache = new Map();
function hashAsset(relativePath) {
  const fullPath = path.join(publicDir, relativePath);
  let mtimeMs;
  try {
    mtimeMs = fs.statSync(fullPath).mtimeMs;
  } catch {
    return 'dev';
  }
  const cached = assetHashCache.get(relativePath);
  if (cached && cached.mtimeMs === mtimeMs) return cached.hash;

  const bytes = fs.readFileSync(fullPath);
  const hash = crypto.createHash('sha256').update(bytes).digest('hex').slice(0, 10);
  assetHashCache.set(relativePath, { mtimeMs, hash });
  return hash;
}
function currentAssetVersion() {
  return hashAsset('css/cciq.css') + hashAsset('js/app.js') + hashAsset('js/kiosk.js');
}

if (config.session.trustProxy) app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', viewsDir);
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      /*
       * Helmet adds this directive by default, and it is right for a portal
       * reached over a real domain with a certificate. This one is also
       * meant to run in plain http:// on a church's own network — that is
       * the whole point of the portable, one-PC setup — and this directive
       * tells the browser to silently rewrite every stylesheet, script and
       * image request to https:// first. Over localhost the browser lets
       * that slide; over a real address like a LAN IP it does not, nothing
       * is listening on https, and every asset on the page fails at once
       * with no visible error — exactly what an unstyled, brokenimage page
       * looks like. Left null here to turn the directive off entirely.
       */
      upgradeInsecureRequests: null
    }
  },
  referrerPolicy: { policy: 'same-origin' },
  crossOriginResourcePolicy: { policy: 'same-origin' }
}));

app.use(rateLimit({
  windowMs: 60 * 1000,
  limit: config.rateLimitPerMinute,
  standardHeaders: 'draft-7',
  legacyHeaders: false
}));

app.use(express.urlencoded({ extended: false, limit: '256kb' }));
app.use(express.json({ limit: '256kb' }));
app.use(collapseRepeatedFields);

app.use(express.static(publicDir, {
  maxAge: config.isProduction ? '7d' : 0,
  dotfiles: 'ignore'
}));

app.use(session({
  name: config.session.name,
  secret: config.session.secret,
  store: new SqliteSessionStore(),
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.secureCookies,
    // Browser-session cookie by default; only freshly verified kiosk-only
    // accounts opt into persistence at login and on authenticated requests.
    maxAge: null
  }
}));

app.use(flashMessages);
app.use(csrfProtection);
app.use(attachUser);

/*
 * A shared reception/office computer must not let the browser's own history
 * cache (or the back button after sign-out) redisplay an authenticated
 * page's content — the login-check itself is skipped for a cached page, not
 * bypassed, but the content would still be visible on screen for a moment.
 * Static assets are unaffected: express.static already returned its own
 * response, with its own 7-day cache header, before a request reaches this
 * point. A route that genuinely wants different caching (the document
 * download route's own `private, max-age=300`, for one) sets its own header
 * later in the chain, which naturally wins.
 */
app.use((req, res, next) => {
  if (res.locals.user) res.set('Cache-Control', 'no-store');
  next();
});

// Layout support: a view renders into layouts/<name>.ejs.
app.use((req, res, next) => {
  const original = res.render.bind(res);
  res.render = (view, options = {}, callback) => {
    if (typeof options === 'function') return original(view, {}, options);
    const layout = options.layout === null || options.layout === false ? null : options.layout || 'app';

    // A caller that passes a callback handles its own failures, which is how
    // the error page avoids failing while reporting a failure.
    const done = (err, html) => {
      if (callback) return callback(err, html);
      if (err) return next(err);
      return res.send(html);
    };

    return original(view, options, (err, html) => {
      if (err) return done(err);
      if (!layout) return done(null, html);
      return original(`layouts/${layout}`, { ...options, body: html }, (layoutErr, page) => (
        layoutErr ? done(layoutErr) : done(null, page)
      ));
    });
  };
  next();
});

// Values every template can rely on.
app.use((req, res, next) => {
  res.locals.church = {
    name: getSetting('church.display_name'),
    shortName: getSetting('church.short_name'),
    logo: getSetting('branding.logo_path'),
    // A small file for the header and the icon, so a phone is not made to
    // download a large image to draw a 36-pixel mark.
    logoSmall: getSetting('branding.logo_small_path') || getSetting('branding.logo_path')
  };
  res.locals.fridayTitle = getSetting('service.friday.title') || 'CCIQ Friday Service';
  // One NIV verse per Qatar day, from the local list: no request, no database, the same on the portal and the Kiosk.
  res.locals.verseOfTheDay = verseOfTheDay();
  res.locals.navigation = req.user ? buildNavigation(req.user, req.path) : [];
  res.locals.dates = dates;
  res.locals.dobDisplay = dobDisplay;
  res.locals.memberName = displayName;
  // Whether the signed-in person may OPEN a member's page. A name is only turned into a link when it would open: a Member (no members.view) or a
  // Cell Group Leader looking at someone outside their own groups would otherwise be offered a link that ends in a 403 or a 404.
  const openableMembers = new Map();
  res.locals.canOpenMember = (memberOrId) => {
    if (!req.user || !req.user.can('members.view')) return false;
    const scope = scopeFor(req.user);
    if (scope.type === 'all') return true;
    const id = Number(memberOrId && typeof memberOrId === 'object' ? memberOrId.id : memberOrId);
    if (!Number.isInteger(id)) return false;
    if (scope.type === 'self') return id === scope.memberId;
    if (scope.type !== 'cell_group') return false;
    if (!openableMembers.has(id)) {
      const row = queryOne('SELECT cell_group_id FROM members WHERE id = @id', { id });
      openableMembers.set(id, Boolean(row) && (scope.cellGroupIds || []).map(Number).includes(Number(row.cell_group_id)));
    }
    return openableMembers.get(id);
  };
  res.locals.statusLabels = STATUS_LABELS;
  res.locals.attendanceLabels = ATTENDANCE_LABELS;
  res.locals.attendanceGlyphs = ATTENDANCE_GLYPHS;
  res.locals.sessionDisplayStatus = sessionDisplayStatus;
  res.locals.query = req.query;
  res.locals.unreadNotifications = req.user ? unreadNotificationCount(req.user.id) : 0;
  res.locals.serviceEndTime = getSetting('service.friday.end_time') || null;
  res.locals.defaultBackground = DEFAULT_BOARD_BACKGROUND;
  res.locals.assetVersion = currentAssetVersion();
  res.locals.title = '';
  next();
});

app.use(authRoutes);
app.use(quickAccessRoutes);
app.use(helpRoutes);
app.use(dashboardRoutes);
app.use(memberRoutes);
app.use(cellGroupRoutes);
app.use(attendanceRoutes);
app.use(activityRoutes);
app.use(announcementRoutes);
app.use(ecaqRoutes);
app.use(adminUserRoutes);
app.use(reportRoutes);
app.use(churchRoutes);
app.use(visitorRoutes);
app.use(searchRoutes);
app.use(ministryRoutes);
app.use(familyGroupRoutes);
app.use(kioskRoutes);
app.use(documentRoutes);
app.use(reminderRoutes);
app.use(accountRoutes);
app.use(adminRoutes);

/*
 * `assetVersion` alone is enough to tell whether this running process has
 * picked up a given source change: it now reflects the current file on
 * every request (see currentAssetVersion above), while `startedAt` is fixed
 * for the process's whole lifetime. If a template or route change doesn't
 * seem to be taking effect, comparing `startedAt` against when that change
 * was made settles it immediately — a code/template change only ever takes
 * effect after the next restart, which is expected, ordinary behaviour, not
 * a defect; this exists so that fact is checkable in seconds rather than
 * discovered again on a physical device. See CCIQ_DECISIONS.md.
 */
const startedAt = new Date().toISOString();
app.get('/healthz', (req, res) => {
  // A liveness check alone (process is running) can't tell a locked,
  // corrupted, or disk-full database from a healthy one — the process stays
  // up and would keep reporting "ok" while every real request fails.
  // `SELECT 1` alone is a pure literal SQLite never touches storage to
  // answer, so it would pass even against a corrupted file; reading a
  // schema_migrations row forces an actual page read off disk.
  try {
    queryOne('SELECT version FROM schema_migrations LIMIT 1');
  } catch (err) {
    return res.status(503).json({ status: 'error', reason: 'database unavailable', startedAt });
  }
  res.json({
    status: 'ok',
    startedAt,
    assetVersion: currentAssetVersion()
  });
});

app.use(notFound);
app.use(errorHandler);

fs.mkdirSync(config.storageDir, { recursive: true });
fs.mkdirSync(config.backupDir, { recursive: true });

// Keep the Friday Service schedule filled in, and raise the reminders that
// fall due. Both are safe to repeat: they only ever add what is missing.
function runScheduledWork() {
  try {
    ensureFridaySessions();
  } catch (err) {
    console.error('[schedule] could not extend the Friday Service schedule:', err.message);
  }
  try {
    const created = generateReminders();
    const total = Object.values(created).reduce((a, b) => a + b, 0);
    if (total > 0) {
      notifyNewReminders(created);
      console.log(`[reminders] ${total} reminder(s) raised.`);
    }
    pruneNotifications();
  } catch (err) {
    console.error('[reminders] could not raise reminders:', err.message);
  }
  evaluateMembershipReviews('scheduled'); // a safety net behind the Attendance lifecycle hook; idempotent, never throws
  try {
    pruneStagedImports(); // abandoned spreadsheet previews hold member details; they do not outlive six hours
  } catch (err) {
    console.error('[imports] could not clear old staged uploads:', err.message);
  }
}

runScheduledWork();
setInterval(runScheduledWork, 6 * 60 * 60 * 1000).unref();

const server = app.listen(config.port, config.host, () => {
  const reach = config.host === '127.0.0.1' || config.host === 'localhost'
    ? 'this computer only'
    : 'this computer and the church network';
  console.log('');
  console.log('  CCIQ Portal is running.');
  console.log('');
  console.log(`  Open:      http://localhost:${config.port}`);
  console.log(`  Reachable: ${reach}`);
  console.log('');
  console.log('  Leave this window open while the portal is in use.');
  console.log('  Closing it stops the portal. Nothing is lost.');
  console.log('');
});

const shutdown = () => server.close(() => process.exit(0));
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

/*
 * Without these, an unhandled promise rejection anywhere (a scheduled job,
 * a route handler that forgot to catch) silently kills the whole process —
 * Node 15+ treats an unhandled rejection as fatal by default — with nothing
 * but a bare stack trace to whatever stream stderr happened to be attached
 * to, easy to lose depending on how the process was started. Node's own
 * guidance is that it is not safe to keep serving requests after either of
 * these fires (state may be inconsistent), so this logs clearly with the
 * same reference-code convention as errorHandler, then exits non-zero — a
 * process manager or the person who started it can restart it, but this
 * process itself must not pretend to keep working.
 */
function fatal(label, err) {
  const reference = crypto.randomBytes(4).toString('hex');
  console.error(`[fatal ${reference}] ${label} — the process will exit`, err instanceof Error ? err.stack : err);
  const forceExit = setTimeout(() => process.exit(1), 3000).unref();
  server.close(() => { clearTimeout(forceExit); process.exit(1); });
}
process.on('unhandledRejection', (reason) => fatal('unhandled promise rejection', reason));
process.on('uncaughtException', (err) => fatal('uncaught exception', err));

export default app;
