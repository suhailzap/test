import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(here, '..', '..');

function int(value, fallback) {
  const n = Number.parseInt(value ?? '', 10);
  return Number.isFinite(n) ? n : fallback;
}

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';

let sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret) {
  if (isProduction) {
    throw new Error('SESSION_SECRET must be set in production. See .env.example.');
  }
  sessionSecret = crypto.randomBytes(32).toString('hex');
  console.warn('[config] SESSION_SECRET not set - using a temporary development secret. Sessions reset on restart.');
}

export const config = {
  env: NODE_ENV,
  isProduction,
  /*
   * Which machines may reach the portal. 127.0.0.1 means this computer only,
   * which is what a church wants when the portal lives on one office PC.
   * Setting it to 0.0.0.0 opens it to the church network, so phones and other
   * computers on the same WiFi can sign in.
   */
  host: process.env.HOST || '127.0.0.1',
  /*
   * Whether sign-in cookies are restricted to HTTPS. On a church computer the
   * portal is opened over plain http://localhost, where an HTTPS-only cookie is
   * never stored and nobody can sign in at all. It is switched on by setting
   * SECURE_COOKIES=true, which is right once the portal sits behind a
   * certificate on a real server.
   */
  secureCookies: String(process.env.SECURE_COOKIES || '').toLowerCase() === 'true',
  port: int(process.env.PORT, 3000),
  /* Requests per minute per address. The default is the production value; only automated tests that crawl every screen raise it. Never below 60. */
  rateLimitPerMinute: Math.max(int(process.env.RATE_LIMIT_PER_MINUTE, 300), 60),
  timezone: process.env.TZ_NAME || 'Asia/Qatar',
  databaseFile: process.env.DATABASE_FILE
    ? path.resolve(ROOT, process.env.DATABASE_FILE)
    : path.join(ROOT, 'data', 'cciq.sqlite'),
  storageDir: process.env.STORAGE_DIR
    ? path.resolve(ROOT, process.env.STORAGE_DIR)
    : path.join(ROOT, 'storage'),
  backupDir: process.env.BACKUP_DIR
    ? path.resolve(ROOT, process.env.BACKUP_DIR)
    : path.join(ROOT, 'storage', 'backups'),
  session: {
    secret: sessionSecret,
    name: process.env.SESSION_COOKIE_NAME || 'cciq.sid',
    idleTimeoutMinutes: int(process.env.SESSION_IDLE_TIMEOUT_MINUTES, 45),
    trustProxy: process.env.TRUST_PROXY === 'true',
    /*
     * A dedicated Attendance Kiosk terminal sits at reception all day; the
     * normal idle timeout would sign it out mid-service for no security
     * benefit, since nothing it can do needs protecting from a shared-terminal
     * risk beyond what recording attendance already is. It still is not
     * sessionless: this is the outer bound a kiosk-only session is allowed to
     * live for, from its own login, regardless of activity — see
     * middleware/auth.js and CCIQ_DECISIONS.md.
     */
    kioskAbsoluteDays: int(process.env.KIOSK_SESSION_ABSOLUTE_DAYS, 30)
  },
  auth: {
    maxFailedAttempts: int(process.env.AUTH_MAX_FAILED_ATTEMPTS, 8),
    lockoutMinutes: int(process.env.AUTH_LOCKOUT_MINUTES, 15),
    passwordMinLength: int(process.env.PASSWORD_MIN_LENGTH, 12),
    // A fixed policy ceiling (not owner-configurable, unlike the minimum
    // above) - lib/passwords.js's checkPasswordPolicy() enforces it on every
    // password, generated or user-chosen. Defined here rather than in
    // passwords.js so the two can be validated against each other at
    // startup without a circular import (passwords.js already imports this
    // config module).
    passwordMaxLength: 200,
    /*
     * The TEMPORARY starting password for a newly created ordinary account (a Member or a Cell Group leader), an owner-approved onboarding choice so a church volunteer can hand a
     * new person something simple to type. It is only ever a starting point: the account is created with must_change_password, so the first sign-in can do nothing but change it,
     * and the change refuses to keep it. It is NEVER used for the bootstrap/Super Admin account, the Church Admin, the dedicated Kiosk account, or a password reset, and it is
     * hashed like every other password (never stored, logged or audited in plain text). An owner can replace it with INITIAL_ACCOUNT_PASSWORD in .env; a value that does not
     * satisfy the password policy is ignored and a random one is generated instead.
     */
    // No shared default. When unset, each new account receives its own random one-time password.
    initialPassword: process.env.INITIAL_ACCOUNT_PASSWORD || '',
    resetTokenMinutes: int(process.env.RESET_TOKEN_MINUTES, 60)
  },
  uploads: {
    maxFileBytes: int(process.env.MAX_UPLOAD_BYTES, 8 * 1024 * 1024),
    maxMediaBytes: int(process.env.MAX_MEDIA_UPLOAD_BYTES, 64 * 1024 * 1024),
    allowedImageTypes: ['image/jpeg', 'image/png', 'image/webp'],
    allowedVideoTypes: ['video/mp4'],
    allowedDocumentTypes: ['application/pdf']
  },
  bootstrap: {
    email: process.env.BOOTSTRAP_ADMIN_EMAIL || '',
    password: process.env.BOOTSTRAP_ADMIN_PASSWORD || '',
    name: process.env.BOOTSTRAP_ADMIN_NAME || 'System Administrator'
  }
};

/*
 * Codex/independent verification (R02 P2): PASSWORD_MIN_LENGTH set above
 * checkPasswordPolicy()'s fixed policy maximum made EVERY password this
 * portal generates (new member accounts, admin-generated resets) fail its
 * own policy check every single time - generateInitialPassword()'s retry
 * loop is powerless against this, since a fixed target length either always
 * passes or always fails. The failure only ever surfaced as a generic
 * "Could not generate a valid initial password" at the moment someone tried
 * to create a user, potentially well after this contradictory value was
 * deployed. Caught here instead, at startup, with a message that actually
 * names the contradiction.
 */
if (config.auth.passwordMinLength > config.auth.passwordMaxLength) {
  throw new Error(
    `PASSWORD_MIN_LENGTH (${config.auth.passwordMinLength}) cannot exceed the portal's fixed password policy maximum `
    + `of ${config.auth.passwordMaxLength} characters. Lower PASSWORD_MIN_LENGTH in .env.`
  );
}
if (config.auth.passwordMinLength < 1) {
  throw new Error(`PASSWORD_MIN_LENGTH (${config.auth.passwordMinLength}) must be at least 1.`);
}

// Marks that the application configuration has been read in this process. A test must create its isolated environment BEFORE any application code is imported (see
// tests/lib/test-env.mjs, which refuses to proceed otherwise): importing first means the test would run against whatever .env names, i.e. the development database.
globalThis.__cciqConfigLoadedFrom = config.databaseFile;

export default config;
