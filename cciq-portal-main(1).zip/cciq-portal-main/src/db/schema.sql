-- CCIQ Church Management Portal - relational schema
-- SQLite dialect. Column types and constraints are kept portable so the same
-- structure can be migrated to PostgreSQL without redesign.

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- Access control
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS roles (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  key          TEXT NOT NULL UNIQUE,
  name         TEXT NOT NULL,
  description  TEXT,
  rank         INTEGER NOT NULL DEFAULT 100,
  is_system    INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS permissions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  key          TEXT NOT NULL UNIQUE,
  category     TEXT NOT NULL,
  description  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id       INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS users (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id            INTEGER REFERENCES members(id) ON DELETE SET NULL,
  email                TEXT NOT NULL UNIQUE,
  password_hash        TEXT NOT NULL,
  display_name         TEXT NOT NULL,
  status               TEXT NOT NULL DEFAULT 'active'
                         CHECK (status IN ('active','disabled')),
  must_change_password INTEGER NOT NULL DEFAULT 0,
  failed_attempts      INTEGER NOT NULL DEFAULT 0,
  locked_until         TEXT,
  last_login_at        TEXT,
  created_at           TEXT NOT NULL,
  updated_at           TEXT NOT NULL,
  created_by           INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id     INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  assigned_at TEXT NOT NULL,
  assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS password_resets (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at    TEXT,
  created_at TEXT NOT NULL,
  request_ip TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  sid     TEXT PRIMARY KEY,
  sess    TEXT NOT NULL,
  expires INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);

-- ---------------------------------------------------------------------------
-- Members
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS members (
  id                           INTEGER PRIMARY KEY AUTOINCREMENT,
  member_code                  TEXT NOT NULL UNIQUE,
  first_name                   TEXT NOT NULL,
  middle_name                  TEXT,
  last_name                    TEXT NOT NULL,
  preferred_name               TEXT,
  date_of_birth                TEXT,
  gender                       TEXT CHECK (gender IN ('male','female','unspecified') OR gender IS NULL),
  phone                        TEXT,
  email                        TEXT,
  address                      TEXT,
  marital_status               TEXT CHECK (marital_status IN ('single','married','widowed','separated','unspecified') OR marital_status IS NULL),
  anniversary_date             TEXT,
  date_joined                  TEXT,
  status                       TEXT NOT NULL DEFAULT 'pending'
                                 CHECK (status IN ('active','inactive','pending','archived',
                                                   'temporarily_away','returned_home','migrated',
                                                   'transferred','other')),
  cell_group_id                INTEGER REFERENCES cell_groups(id) ON DELETE SET NULL,
  emergency_contact_name       TEXT,
  emergency_contact_phone      TEXT,
  emergency_contact_relation   TEXT,
  notes                        TEXT,
  photo_path                   TEXT,
  created_at                   TEXT NOT NULL,
  updated_at                   TEXT NOT NULL,
  created_by                   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_by                   INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);
CREATE INDEX IF NOT EXISTS idx_members_cell_group ON members(cell_group_id);
CREATE INDEX IF NOT EXISTS idx_members_last_name ON members(last_name, first_name);

CREATE TABLE IF NOT EXISTS member_status_history (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id       INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  previous_status TEXT,
  new_status      TEXT NOT NULL,
  reason          TEXT,
  changed_at      TEXT NOT NULL,
  changed_by      INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_status_history_member ON member_status_history(member_id, changed_at);

-- Additional member fields are configured by administrators, not hard-coded.
CREATE TABLE IF NOT EXISTS member_custom_fields (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  field_key   TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  field_type  TEXT NOT NULL DEFAULT 'text'
                CHECK (field_type IN ('text','textarea','number','date','select','checkbox')),
  options     TEXT,
  help_text   TEXT,
  visibility  TEXT NOT NULL DEFAULT 'staff'
                CHECK (visibility IN ('staff','leader','member')),
  is_active   INTEGER NOT NULL DEFAULT 1,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS member_field_values (
  member_id  INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  field_id   INTEGER NOT NULL REFERENCES member_custom_fields(id) ON DELETE CASCADE,
  value      TEXT,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (member_id, field_id)
);

-- ---------------------------------------------------------------------------
-- Cell groups
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cell_groups (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  name               TEXT NOT NULL UNIQUE,
  description        TEXT,
  leader_member_id   INTEGER REFERENCES members(id) ON DELETE SET NULL,
  assistant_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
  meeting_day        TEXT,
  meeting_time       TEXT,
  meeting_location   TEXT,
  photo_path         TEXT,
  status             TEXT NOT NULL DEFAULT 'active'
                       CHECK (status IN ('active','inactive','archived')),
  created_at         TEXT NOT NULL,
  updated_at         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cell_group_members (
  cell_group_id INTEGER NOT NULL REFERENCES cell_groups(id) ON DELETE CASCADE,
  member_id     INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  role_in_group TEXT NOT NULL DEFAULT 'member'
                  CHECK (role_in_group IN ('leader','assistant','member')),
  joined_at     TEXT NOT NULL,
  PRIMARY KEY (cell_group_id, member_id)
);

-- ---------------------------------------------------------------------------
-- Attendance - Friday Service is the primary recurring weekly service
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS attendance_sessions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  service_date  TEXT NOT NULL,
  service_type  TEXT NOT NULL DEFAULT 'friday_service'
                  CHECK (service_type IN ('friday_service','special_service','church_activity','cell_group')),
  title         TEXT,
  start_time    TEXT,
  location      TEXT,
  cell_group_id INTEGER NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'scheduled'
                  CHECK (status IN ('scheduled','held','cancelled')),
  counts_toward_followup INTEGER NOT NULL DEFAULT 1,
  notes         TEXT,
  created_at    TEXT NOT NULL,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  UNIQUE (service_date, service_type, cell_group_id)
);
CREATE INDEX IF NOT EXISTS idx_sessions_date ON attendance_sessions(service_date);

CREATE TABLE IF NOT EXISTS attendance_records (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  status      TEXT NOT NULL CHECK (status IN ('present','absent','excused','visitor')),
  notes       TEXT,
  recorded_at TEXT NOT NULL,
  recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  UNIQUE (session_id, member_id)
);
CREATE INDEX IF NOT EXISTS idx_attendance_member ON attendance_records(member_id);

-- ---------------------------------------------------------------------------
-- Activities, calendar, announcements
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS activities (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  scope         TEXT NOT NULL DEFAULT 'church'
                  CHECK (scope IN ('church','cell_group')),
  cell_group_id INTEGER REFERENCES cell_groups(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  description   TEXT,
  category      TEXT,
  activity_date TEXT,
  start_time    TEXT,
  end_time      TEXT,
  location      TEXT,
  cover_image   TEXT,
  status        TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft','published','archived')),
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS activity_media (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  activity_id  INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  album        TEXT,
  media_type   TEXT NOT NULL CHECK (media_type IN ('image','video','document')),
  file_path    TEXT NOT NULL,
  thumb_path   TEXT,
  caption      TEXT,
  file_size    INTEGER,
  mime_type    TEXT,
  uploaded_at  TEXT NOT NULL,
  uploaded_by  INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS announcements (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  body         TEXT NOT NULL,
  priority     TEXT NOT NULL DEFAULT 'normal'
                 CHECK (priority IN ('low','normal','high')),
  audience     TEXT NOT NULL DEFAULT 'all',
  image_path   TEXT,
  attachment_path TEXT,
  publish_at   TEXT,
  expires_at   TEXT,
  status       TEXT NOT NULL DEFAULT 'draft'
                 CHECK (status IN ('draft','published','archived')),
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL,
  created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------------------
-- Reminders and notifications
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reminders (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  reminder_type TEXT NOT NULL,
  member_id    INTEGER REFERENCES members(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  detail       TEXT,
  due_date     TEXT,
  state        TEXT NOT NULL DEFAULT 'new'
                 CHECK (state IN ('new','acknowledged','completed','dismissed')),
  dedupe_key   TEXT UNIQUE,
  handled_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  handled_at   TEXT,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  body        TEXT,
  link        TEXT,
  category    TEXT,
  read_at     TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read_at);

-- ---------------------------------------------------------------------------
-- Administration
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS system_settings (
  key         TEXT PRIMARY KEY,
  value       TEXT,
  value_type  TEXT NOT NULL DEFAULT 'string'
                CHECK (value_type IN ('string','number','boolean','json')),
  category    TEXT NOT NULL DEFAULT 'general',
  label       TEXT NOT NULL,
  help_text   TEXT,
  updated_at  TEXT NOT NULL,
  updated_by  INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS backups (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  filename    TEXT NOT NULL,
  file_path   TEXT NOT NULL,
  file_size   INTEGER,
  checksum    TEXT,
  status      TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','completed','failed')),
  notes       TEXT,
  created_at  TEXT NOT NULL,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  restored_at TEXT,
  restored_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_label  TEXT,
  action       TEXT NOT NULL,
  entity_type  TEXT,
  entity_id    TEXT,
  result       TEXT NOT NULL DEFAULT 'success'
                 CHECK (result IN ('success','failure','denied')),
  detail       TEXT,
  ip_address   TEXT,
  user_agent   TEXT,
  created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);

-- ---------------------------------------------------------------------------
-- ECAQ Worship Centre project and CCIQ Giving Board
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ecaq_campaigns (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT NOT NULL,
  year             INTEGER NOT NULL,
  description      TEXT,
  target_amount    REAL,
  amount_per_date  REAL,
  currency         TEXT NOT NULL DEFAULT 'QAR',
  background_image TEXT,
  privacy_mode     TEXT NOT NULL DEFAULT 'first_name'
                     CHECK (privacy_mode IN ('full_name','first_name','claimed','private')),
  status           TEXT NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','active','closed')),
  start_date       TEXT,
  end_date         TEXT,
  created_at       TEXT NOT NULL,
  updated_at       TEXT NOT NULL,
  UNIQUE (year, name)
);

CREATE TABLE IF NOT EXISTS ecaq_giving_board_claims (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id       INTEGER NOT NULL REFERENCES ecaq_campaigns(id) ON DELETE CASCADE,
  claim_date        TEXT NOT NULL,
  year              INTEGER NOT NULL,
  member_id         INTEGER NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
  claimed_at        TEXT NOT NULL,
  commitment_amount REAL,
  amount_collected  REAL NOT NULL DEFAULT 0,
  payment_status    TEXT NOT NULL DEFAULT 'not_paid'
                      CHECK (payment_status IN ('not_paid','partially_paid','paid','waived','pending_verification')),
  status            TEXT NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','released','cancelled')),
  notes             TEXT,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  created_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_by        INTEGER REFERENCES users(id) ON DELETE SET NULL
);
-- A date can only be claimed once within the same campaign.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_claim_per_date
  ON ecaq_giving_board_claims(campaign_id, claim_date);

CREATE TABLE IF NOT EXISTS ecaq_project_updates (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  update_date TEXT,
  source      TEXT,
  status      TEXT NOT NULL DEFAULT 'draft'
                CHECK (status IN ('draft','published','archived')),
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS ecaq_project_media (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  media_type  TEXT NOT NULL CHECK (media_type IN ('image','video','document')),
  file_path   TEXT NOT NULL,
  thumb_path  TEXT,
  caption     TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  uploaded_at TEXT NOT NULL,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS schema_migrations (
  version    TEXT PRIMARY KEY,
  applied_at TEXT NOT NULL
);
