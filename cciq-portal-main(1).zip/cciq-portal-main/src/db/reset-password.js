import db, { query } from './index.js';
import { checkSchemaCompatibility } from './migrate.js';
import { setPassword, generateInitialPassword } from '../services/users.js';
import { checkPasswordPolicy } from '../lib/passwords.js';
import { canPresentGeneratedCredential } from '../lib/credential-output.js';

/**
 * Sets a new password for an account from the church computer, for when the
 * first password was missed or nobody can sign in any more.
 *
 * Run it from the portal folder:
 *
 *   npm run account:password
 *   npm run account:password -- admin@example.org
 *   npm run account:password -- pastor.rio
 *
 * With no account given it lists the accounts and picks the Super Admin if
 * there is only one. The new password is printed once and must be changed at
 * the next sign-in.
 */
function listAccounts() {
  return query(
    `SELECT u.id, u.username, u.email, u.display_name, u.status,
            GROUP_CONCAT(r.name, ', ') AS roles
       FROM users u
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
      GROUP BY u.id
      ORDER BY u.id`
  );
}

async function run() {
  // Migration execution safety (Codex/independent verification): an
  // operational utility like this one must never silently advance the
  // schema as a side effect of resetting a password. Checks compatibility
  // only; never applies anything - including the "never initialized"
  // case, which would otherwise surface as a raw "no such table: users"
  // SQL error from listAccounts() below instead of a clear message.
  const compatibility = checkSchemaCompatibility();
  if (!compatibility.ok) {
    console.log(compatibility.reason === 'uninitialized'
      ? 'There are no accounts yet. Run "npm run db:seed" first.'
      : compatibility.reason === 'behind'
        ? `This database needs an update before a password can be reset (missing: ${compatibility.missing.join(', ')}).`
        : `This database has changes this copy of the portal does not recognize (${compatibility.unexpected.join(', ')}).`);
    if (compatibility.reason !== 'uninitialized') {
      console.log('Run "npm run db:migrate" (or contact your technical person) before trying again.');
    }
    process.exitCode = compatibility.reason === 'uninitialized' ? 0 : 1;
    return;
  }

  const wanted = String(process.argv[2] || '').trim().toLowerCase();
  const accounts = listAccounts();

  if (accounts.length === 0) {
    console.log('There are no accounts yet. Run "npm run db:seed" first.');
    return;
  }

  let account = null;
  if (wanted) {
    account = accounts.find(
      (a) => String(a.email).toLowerCase() === wanted || String(a.username).toLowerCase() === wanted
    );
    if (!account) {
      console.log(`No account matches "${process.argv[2]}".\n`);
    }
  }

  if (!account) {
    const admins = accounts.filter((a) => (a.roles || '').includes('Super Admin'));
    if (!wanted && admins.length === 1) {
      account = admins[0];
    } else {
      console.log('Accounts on this portal:\n');
      for (const a of accounts) {
        console.log(`  ${String(a.username || '').padEnd(24)} ${String(a.email).padEnd(32)} ${a.roles || 'no roles'}`);
      }
      console.log('\nRun the command again with the username or email, for example:');
      console.log(`  npm run account:password -- ${accounts[0].username}`);
      return;
    }
  }

  // A new password is generated and shown once, on this screen - so it may
  // only be generated at all when this screen is one a person is actually
  // watching. Redirected or captured output (a scheduled task, a wrapper
  // writing to a log) would persist it in the clear, so refuse BEFORE
  // changing anything rather than reset a password and then print it there.
  if (!canPresentGeneratedCredential()) {
    console.log('A new password can only be shown safely in a console window you are watching, never saved to a file or a log.');
    console.log('Run `node src/db/reset-password.js` from an ordinary console window. Nothing was changed.');
    process.exitCode = 1;
    return;
  }

  // R02 (Codex/independent verification): this used to be a fixed 12-character
  // value that never went through the password policy at all, so a configured
  // PASSWORD_MIN_LENGTH above 12 was silently ignored for exactly the
  // recovery path people use when they are locked out. It now uses the shared
  // policy-aware generator, checked against this account's own identity, and
  // is validated again before it is applied - never applied unless it passes.
  let password;
  try {
    password = generateInitialPassword({ email: account.email });
  } catch (err) {
    console.log(`Could not generate a password that satisfies this portal's password rules: ${err.message}`);
    console.log('Nothing was changed.');
    process.exitCode = 1;
    return;
  }
  const problems = checkPasswordPolicy(password, { email: account.email });
  if (problems.length) {
    console.log(`The generated password did not satisfy the password rules (${problems.join(' ')}). Nothing was changed.`);
    process.exitCode = 1;
    return;
  }
  await setPassword(account.id, password, { mustChange: true });

  console.log('\nPassword reset.\n');
  console.log(`  Account:  ${account.display_name}`);
  console.log(`  Username: ${account.username}`);
  console.log(`  Email:    ${account.email}`);
  console.log(`  Password: ${password}`);
  console.log('\nSign in with either the username or the email address.');
  console.log('This password is shown once, and must be changed at the next sign-in.');

  if (account.status !== 'active') {
    console.log(`\nNote: this account is "${account.status}", so it cannot sign in until an administrator reactivates it.`);
  }
}

run()
  .catch((err) => {
    console.error(`\nThe password could not be reset: ${err.message}`);
    process.exitCode = 1;
  })
  .finally(() => db.close());
