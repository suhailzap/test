import fs from 'node:fs';
import config from '../config/env.js';

/**
 * Deletes the local database so it can be rebuilt from scratch.
 * Requires --force so it cannot be run by accident.
 */
if (!process.argv.includes('--force')) {
  console.error('This deletes the database. Re-run with --force to confirm.');
  process.exit(1);
}

for (const suffix of ['', '-wal', '-shm']) {
  const file = `${config.databaseFile}${suffix}`;
  if (fs.existsSync(file)) {
    fs.rmSync(file);
    console.log(`Removed ${file}`);
  }
}
console.log('Run `npm run db:seed` to rebuild.');
