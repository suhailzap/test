import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import config from '../config/env.js';
import { checkRecoveryInterlock } from '../lib/recovery-interlock.js';

/*
 * The primary, defense-in-depth guard: whatever imports this module (the
 * real server, a migration script, a REPL, anything), the configured
 * database is never opened - and never silently created fresh by
 * better-sqlite3 - while a fatal, unrecovered restore interlock is active.
 * server.js checks this same interlock even earlier, before importing
 * anything that would reach this file at all, so it can degrade gracefully
 * instead of crashing; this check is what makes that enforceable rather
 * than advisory for every other entry point too. See lib/recovery-interlock.js.
 */
const interlock = checkRecoveryInterlock();
if (interlock) {
  throw new Error(
    `Startup refused: a recovery interlock is active (${interlock.kind}, recorded ${interlock.createdAt}). `
    + 'Run tools/clear-recovery-interlock.mjs after manual recovery before starting the portal again.'
  );
}

fs.mkdirSync(path.dirname(config.databaseFile), { recursive: true });

const db = new Database(config.databaseFile);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

/**
 * All data access goes through these helpers. Every call uses parameter
 * binding, so user input is never concatenated into SQL.
 */
export const query = (sql, params = {}) => db.prepare(sql).all(params);
export const queryOne = (sql, params = {}) => db.prepare(sql).get(params);
export const execute = (sql, params = {}) => db.prepare(sql).run(params);
/**
 * A transaction that takes the write lock when it BEGINS. better-sqlite3's default is a deferred transaction, which starts as a reader and
 * is upgraded to a writer at its first write; if another process commits in between, SQLite cannot upgrade a stale snapshot and fails
 * at once with "database is locked" - busy_timeout does not help. Nearly every transaction in this portal reads before it writes
 * (find, check, then insert), so each one starts immediate: a second process (a maintenance script, a second tool) waits up to the
 * busy timeout for its turn instead of failing. For the single portal process this changes nothing - it already serialises itself.
 * The deferred / immediate / exclusive variants remain available on the returned function.
 */
export const transaction = (fn) => {
  const wrapped = db.transaction(fn);
  const run = (...args) => wrapped.immediate(...args);
  run.default = run;
  run.immediate = wrapped.immediate;
  run.deferred = wrapped.deferred;
  run.exclusive = wrapped.exclusive;
  return run;
};

export { db };
export default db;
