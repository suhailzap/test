import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import db from './index.js';
import { findFirstTimerLinkProblems, describeFirstTimerLinkProblems } from '../lib/first-timer-links.js';

/**
 * Thrown by a migration that refuses to run because the data is not in a state it may safely proceed from. Nothing has been
 * changed when this is thrown; the diagnostic says what to look at. A migration never repairs data it does not understand.
 */
export class MigrationRefusedError extends Error {
  constructor(version, diagnostic) {
    super(`Migration ${version} refused: ${diagnostic}`);
    this.name = 'MigrationRefusedError';
    this.version = version;
    this.diagnostic = diagnostic;
  }
}

const here = path.dirname(fileURLToPath(import.meta.url));

function columnExists(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column);
}

/**
 * Additive changes made after the initial schema. Each step checks the current
 * shape of the database first, so migrating is safe to re-run and never
 * destroys existing data.
 */
const STEPS = [
  {
    version: '0033_member_dob_review',
    apply() {
      /*
       * A person's decision about a member's date of birth, kept beside the date and never instead of it.
       *
       *   members.dob_review          NULL = nobody has decided (the automatic data-quality checks apply);
       *                               'verified' = a Church Admin / Super Admin confirmed the COMPLETE date, year included;
       *                               'unverified' = the stored date cannot be trusted and is not used;
       *                               'month_day_only' = the birthday's month and day are confirmed, the birth year is not known.
       *   members.dob_reviewed_at     when that decision was made (ISO timestamp), NULL while there is none;
       *   members.dob_reviewed_by     who made it (a user; NULL if that account is later removed).
       *
       * ADDITIVE ONLY: three nullable columns. Every member keeps NULL: nothing is backfilled, nothing is marked verified or unverified automatically, and no stored date of birth is
       * touched. Which state wins over the automatic checks is decided in one place (src/services/dob-quality.js).
       *
       * ROLLBACK NOTE: code that only knows through 0032 refuses a 0033 database as "ahead"; the way back is the pre-migration backup. The columns are ignored by older queries.
       */
      db.transaction(() => {
        if (!columnExists('members', 'dob_review')) {
          db.exec("ALTER TABLE members ADD COLUMN dob_review TEXT CHECK (dob_review IS NULL OR dob_review IN ('verified','unverified','month_day_only'))");
        }
        if (!columnExists('members', 'dob_reviewed_at')) db.exec('ALTER TABLE members ADD COLUMN dob_reviewed_at TEXT');
        if (!columnExists('members', 'dob_reviewed_by')) db.exec('ALTER TABLE members ADD COLUMN dob_reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL');
      })();
    }
  },
  {
    version: '0032_faith_promise_received_by',
    apply() {
      /*
       * "Received by" on a Faith Promise payment: the person who physically received or handled the money. It is NOT "recorded by" (created_by, the signed-in administrator who
       * entered it in the portal); the two are different facts and both are kept.
       *
       * ADDITIVE ONLY: one nullable text column. Every existing payment keeps NULL ("not recorded"): nothing is backfilled or guessed from the administrator who entered it.
       * It is free text on purpose (the receiver is often not a portal user or even a member, and the name written then must stay as written even if someone's account or member
       * record changes later). New payments require it in the application (the column itself stays nullable so history stays valid).
       *
       * ROLLBACK NOTE: code that only knows through 0031 refuses a 0032 database as "ahead"; the way back is the pre-migration backup. The column is ignored by older queries.
       */
      if (!columnExists('ecaq_faith_promise_payments', 'received_by')) {
        db.exec('ALTER TABLE ecaq_faith_promise_payments ADD COLUMN received_by TEXT');
      }
    }
  },
  {
    version: '0031_document_audience',
    apply() {
      /*
       * Per-document "Who can view this?". ADDITIVE ONLY: one column with a default, one new table. Nothing existing is rewritten, backfilled or removed, so every document
       * that exists keeps exactly the visibility it has today.
       *
       *   documents.audience_mode        'category' (the default, and what every existing row gets) = the category's audience decides, exactly as before;
       *                                  'roles'    = the document is narrowed to the roles listed in document_audience_roles.
       *   document_audience_roles        (document_id, role_key): the roles a 'roles' document is limited to. Only the four portal roles that can open documents are allowed.
       *
       * STRICTER ONLY (the owner's rule): the category is the MAXIMUM audience and a document can only narrow it. This is enforced in the query that decides visibility
       * (category audience AND the document's roles), not only when the form is saved, so a row written by hand or a category changed later can never widen anything.
       *
       * ROLLBACK NOTE: code that only knows through 0030 refuses a 0031 database as "ahead" (the schema compatibility check); the way back is the pre-migration backup. The
       * column and table are ignored by older queries, so restoring the backup (or dropping them) returns the previous behaviour exactly.
       */
      db.transaction(() => {
        if (!columnExists('documents', 'audience_mode')) {
          db.exec("ALTER TABLE documents ADD COLUMN audience_mode TEXT NOT NULL DEFAULT 'category' CHECK (audience_mode IN ('category','roles'))");
        }
        db.exec(`
          CREATE TABLE IF NOT EXISTS document_audience_roles (
            document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
            role_key    TEXT    NOT NULL CHECK (role_key IN ('super_admin','church_admin','cell_group_leader','member')),
            PRIMARY KEY (document_id, role_key)
          )`);
        db.exec('CREATE INDEX IF NOT EXISTS idx_document_audience_roles_role ON document_audience_roles(role_key)');
      })();
    }
  },
  {
    version: '0030_first_timer_membership_review',
    apply() {
      /*
       * First Timer lifecycle foundation. Additive: one new table, one new permission, one unique index and three triggers.
       * Nothing existing is rewritten, backfilled or removed.
       *
       * PRE-FLIGHT GATE. The new rules say "a First Timer is 'joined' if and only if it has a member record, and one member
       * belongs to at most one First Timer". Earlier releases let the Outcome form set 'joined' by hand and set an outcome
       * back after a conversion, so a real database MAY contain rows that break those rules. This migration never guesses a
       * repair (no member matching, no state rewriting): if any such row exists it refuses, changes nothing, and names the
       * rows. Run tools/check-first-timer-links.mjs on a copy of the database first.
       *
       * visitor_membership_reviews is the source of truth for "Membership Review Suggested". It is deliberately NOT a visitors
       * state: a review is a decision an administrator takes, with its own history.
       *   status      open | continued | converted | linked   (CHECKs tie status to closed_at / suppress_after_date)
       *   opened_at, trigger_session_id (the Friday that completed the rule; SET NULL if the session is ever deleted),
       *   trigger_service_date, window_json (the four Fridays and which had a visit - the evidence)
       *   closed_at, closed_by, note
       *   suppress_after_date  set when an administrator chooses Continue as Visitor: no new review is raised until four
       *                        further eligible Fridays after this date have been finalized
       *   member_id            the member a review ended in (converted / linked); SET NULL if the member row is ever removed
       * A partial unique index allows at most ONE open review per visitor, which is what makes opening a review idempotent.
       *
       * Defence in depth for the 'joined' rule, in the database as well as in the code:
       *   idx_visitors_member_unique          one member, at most one First Timer
       *   trg_visitors_joined_iff_member_*    INSERT, and UPDATE OF state / member_id, abort unless
       *                                       (state = 'joined') <=> (member_id IS NOT NULL). UPDATE OF means an ordinary
       *                                       update of any other column (follow-up, updated_at) never fires them.
       *   trg_members_delete_has_visitor      a member who is linked from a First Timer cannot be deleted from underneath it
       *                                       (the application already refuses this; the trigger is the backstop)
       *
       * New permission visitors.express_register (register a First Timer at the check-in desk and check them in): granted to
       * the kiosk role and to church_admin (super_admin receives every permission). The kiosk gains nothing else.
       *
       * ROLLBACK NOTE: as with 0029, a release that only knows through 0029 refuses a 0030 database as "ahead"; rolling back
       * after deploying 0030 means the approved database + release rollback from the pre-migration backup.
       */
      const problems = findFirstTimerLinkProblems(db);
      if (problems.total > 0) {
        throw new MigrationRefusedError('0030_first_timer_membership_review',
          `First Timer records break the "joined means linked to one member" rule, so nothing was changed.\n${describeFirstTimerLinkProblems(problems)}\n`
          + 'Review these records with an administrator (tools/check-first-timer-links.mjs lists them); this migration does not repair them.');
      }

      db.transaction(() => {
        db.exec(`
          CREATE TABLE IF NOT EXISTS visitor_membership_reviews (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            visitor_id           INTEGER NOT NULL REFERENCES visitors(id) ON DELETE CASCADE,
            status               TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','continued','converted','linked')),
            opened_at            TEXT NOT NULL,
            trigger_session_id   INTEGER REFERENCES attendance_sessions(id) ON DELETE SET NULL,
            trigger_service_date TEXT NOT NULL,
            window_json          TEXT NOT NULL,
            closed_at            TEXT,
            closed_by            INTEGER REFERENCES users(id) ON DELETE SET NULL,
            note                 TEXT,
            suppress_after_date  TEXT,
            member_id            INTEGER REFERENCES members(id) ON DELETE SET NULL,
            CHECK ((status = 'open' AND closed_at IS NULL) OR (status != 'open' AND closed_at IS NOT NULL)),
            CHECK (status != 'continued' OR suppress_after_date IS NOT NULL)
          )`);
        db.exec("CREATE UNIQUE INDEX IF NOT EXISTS uniq_open_review_per_visitor ON visitor_membership_reviews(visitor_id) WHERE status = 'open'");
        db.exec('CREATE INDEX IF NOT EXISTS idx_membership_reviews_status ON visitor_membership_reviews(status, opened_at)');
        db.exec('CREATE INDEX IF NOT EXISTS idx_membership_reviews_visitor ON visitor_membership_reviews(visitor_id)');

        db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_visitors_member_unique ON visitors(member_id) WHERE member_id IS NOT NULL');
        db.exec(`
          CREATE TRIGGER IF NOT EXISTS trg_visitors_joined_iff_member_insert
          BEFORE INSERT ON visitors
          WHEN (NEW.state = 'joined') <> (NEW.member_id IS NOT NULL)
          BEGIN
            SELECT RAISE(ABORT, 'A First Timer is "joined" if and only if it is linked to a member record');
          END`);
        db.exec(`
          CREATE TRIGGER IF NOT EXISTS trg_visitors_joined_iff_member_update
          BEFORE UPDATE OF state, member_id ON visitors
          WHEN (NEW.state = 'joined') <> (NEW.member_id IS NOT NULL)
          BEGIN
            SELECT RAISE(ABORT, 'A First Timer is "joined" if and only if it is linked to a member record');
          END`);
        db.exec(`
          CREATE TRIGGER IF NOT EXISTS trg_members_delete_has_visitor
          BEFORE DELETE ON members
          WHEN EXISTS (SELECT 1 FROM visitors WHERE member_id = OLD.id)
          BEGIN
            SELECT RAISE(ABORT, 'This member is linked from a First Timer record and cannot be deleted');
          END`);

        if (!db.prepare("SELECT id FROM permissions WHERE key = 'visitors.express_register'").get()) {
          db.prepare(
            `INSERT INTO permissions (key, category, description)
             VALUES ('visitors.express_register', 'Attendance',
                     'Register a First Timer at the check-in desk and check them in (kiosk-safe; nothing else about First Timers)')`
          ).run();
        }
        const permissionId = db.prepare("SELECT id FROM permissions WHERE key = 'visitors.express_register'").get().id;
        const grant = db.prepare('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)');
        for (const roleKey of ['super_admin', 'church_admin', 'kiosk']) {
          const role = db.prepare('SELECT id FROM roles WHERE key = @key').get({ key: roleKey });
          if (role) grant.run({ roleId: role.id, permissionId });
        }
      })();
    }
  },
  {
    version: '0029_attendance_finalization',
    apply() {
      /*
       * Attendance Go-Live & Finalization, schema foundation. Purely additive:
       * nothing existing is rewritten, backfilled or removed. Every existing
       * attendance_sessions row simply gains four NULL columns
       * (finalization_state NULL = "not finalized"), every existing
       * attendance_records row is untouched, and attendance_expected starts
       * empty. Nothing reads any of it until later phases.
       *
       * attendance_sessions gains:
       *   finalization_state  NULL | 'finalized' | 'not_taken' - orthogonal to
       *                       `status` (scheduled/held/cancelled); a cancelled
       *                       service keeps whatever finalization it had.
       *   finalized_at, finalized_by (ON DELETE SET NULL, like every other
       *   actor column), finalization_note (the reason, for "not taken").
       *
       * attendance_expected is the historical expected-roster snapshot: one
       * row per member expected at one finalized Friday, written once at
       * finalization and never rebuilt from today's member statuses.
       *   session_id  ON DELETE CASCADE - the snapshot belongs to its session,
       *               exactly as attendance_records does.
       *   member_id   ON DELETE RESTRICT, deliberately NOT cascade. The
       *               snapshot is historical evidence of who was expected, and
       *               a member's deletion must never silently erase it (and so
       *               silently change a past attendance rate). Permanent member
       *               deletion is already refused for anyone with attendance
       *               history (memberDependencySummary); the snapshot now takes
       *               part in that check, and RESTRICT is the database-level
       *               backstop behind it.
       *   status_at_service  the status that made them expected. No CHECK
       *               constraint: the expected-status set is enforced in code
       *               (services/attendance-tracking.js), and a CHECK here would
       *               force a table rebuild - the kind this project has had to do
       *               for members.status - if the set ever changes.
       * Cell group is deliberately not snapshotted.
       *
       * Also adds the attendance.finalize permission (finalize / mark not
       * taken / reopen / correct finalized attendance), granted to church_admin
       * and super_admin only - the same reference-data insert pattern as 0024
       * and 0025. Cell Group Leaders, members and the kiosk do not receive it.
       *
       * ROLLBACK NOTE: once a real database has been migrated to 0029, a
       * release that only knows through 0028 will refuse it at startup as
       * "ahead" (correctly - see checkSchemaCompatibility). Rolling back after
       * deploying 0029 therefore means the approved database + release
       * rollback procedure, from the pre-migration backup.
       */
      if (!columnExists('attendance_sessions', 'finalization_state')) {
        db.exec("ALTER TABLE attendance_sessions ADD COLUMN finalization_state TEXT CHECK (finalization_state IN ('finalized','not_taken'))");
      }
      if (!columnExists('attendance_sessions', 'finalized_at')) {
        db.exec('ALTER TABLE attendance_sessions ADD COLUMN finalized_at TEXT');
      }
      if (!columnExists('attendance_sessions', 'finalized_by')) {
        db.exec('ALTER TABLE attendance_sessions ADD COLUMN finalized_by INTEGER REFERENCES users(id) ON DELETE SET NULL');
      }
      if (!columnExists('attendance_sessions', 'finalization_note')) {
        db.exec('ALTER TABLE attendance_sessions ADD COLUMN finalization_note TEXT');
      }

      db.exec(`
        CREATE TABLE IF NOT EXISTS attendance_expected (
          session_id        INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
          member_id         INTEGER NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
          status_at_service TEXT NOT NULL,
          PRIMARY KEY (session_id, member_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_attendance_expected_member ON attendance_expected(member_id)');

      if (!db.prepare("SELECT id FROM permissions WHERE key = 'attendance.finalize'").get()) {
        db.prepare(
          `INSERT INTO permissions (key, category, description)
           VALUES ('attendance.finalize', 'Attendance',
                   'Finalize attendance, mark it not taken, reopen it and correct finalized attendance')`
        ).run();
      }
      const permissionId = db.prepare("SELECT id FROM permissions WHERE key = 'attendance.finalize'").get().id;
      const insertRolePermission = db.prepare(
        'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)'
      );
      for (const roleKey of ['super_admin', 'church_admin']) {
        const role = db.prepare('SELECT id FROM roles WHERE key = @key').get({ key: roleKey });
        if (role) insertRolePermission.run({ roleId: role.id, permissionId });
      }
    }
  },
  {
    version: '0028_security_generation',
    apply() {
      /*
       * R03 (Codex/independent verification): reusing password_hash as an
       * "auth version" stamp only ever caught a CREDENTIAL change - it left
       * no trace of an account STATE transition (deactivate/reactivate), so
       * a session resurrected by a stale in-flight save (express-session's
       * store.set() is an upsert; see lib/session-store.js) could become
       * valid again after a deactivate-then-reactivate cycle, since
       * password_hash never moved. A login whose slow verifyPassword() call
       * straddled a deactivate-then-reactivate entirely within that window
       * was equally undetectable, since re-checking password_hash/status
       * alone only ever sees whichever values happen to be current when the
       * check runs, not whether a security event occurred in between.
       *
       * A single monotonic counter, independent of password_hash and never
       * decremented (not even by reactivation), closes both: any account
       * security event - not just a credential change - advances it, and a
       * session (or an in-flight login) that captured an OLDER value can
       * never match again, no matter how many times its row is written
       * back or how the account's status moves around in between.
       *
       * Purely additive: one column, a constant default, no data
       * transformation, no existing account/role/permission/password data
       * touched. NOT NULL DEFAULT 1 backfills every existing row with 1 in
       * the same ALTER TABLE statement - every current user starts at the
       * same baseline generation. Every session issued before this column
       * existed carries no captured generation, and attachUser() in
       * middleware/auth.js (as corrected by the R03 final legacy-session
       * fix) does NOT accept such a session: an authenticated session
       * without a securityGeneration matching the user's current one is
       * destroyed and must sign in again, which captures the current value.
       * Deploying this migration therefore signs out every session that
       * predates it, once.
       */
      if (!columnExists('users', 'security_generation')) {
        db.exec('ALTER TABLE users ADD COLUMN security_generation INTEGER NOT NULL DEFAULT 1');
      }
    }
  },
  {
    version: '0027_kiosk_role',
    apply() {
      /*
       * A church-entrance terminal is its own identity, not a Cell Group
       * Leader or Church Admin account with the sidebar hidden — it needs
       * exactly search/QR-resolve/record-attendance and nothing a member
       * record, a report, or a settings screen would expose. `attendance.
       * checkin` (migration 0024) already exists for precisely this; this
       * step only adds the role itself, granted that one permission and no
       * other, matching src/lib/permissions.js's `kiosk` entry so a normal
       * seed run and this migration agree.
       */
      const existing = db.prepare("SELECT id FROM roles WHERE key = 'kiosk'").get();
      if (!existing) {
        db.prepare(
          `INSERT INTO roles (key, name, description, rank, is_system, created_at, updated_at)
           VALUES ('kiosk', 'Attendance Kiosk',
                   'Restricted entrance-terminal identity: search, scan a QR code and record attendance only.',
                   50, 1, @at, @at)`
        ).run({ at: new Date().toISOString() });
      }

      const role = db.prepare("SELECT id FROM roles WHERE key = 'kiosk'").get();
      const permission = db.prepare("SELECT id FROM permissions WHERE key = 'attendance.checkin'").get();
      if (role && permission) {
        db.prepare(
          'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)'
        ).run({ roleId: role.id, permissionId: permission.id });
      }
    }
  },
  {
    version: '0026_family_groups',
    apply() {
      /*
       * A family group (household) is a distinct concept from the explicit
       * spouse/father/mother/guardian relationships already on `members` —
       * those describe how two people are related; this describes who should
       * be grouped together operationally (for a future Smart Family
       * Attendance lookup, among other things). Nothing here duplicates a
       * relationship column: the join table stores only membership, and every
       * relationship label shown in the UI is computed at read time from the
       * existing spouse/father/mother/guardian columns.
       *
       * `member_id` carries its own UNIQUE constraint (in addition to being
       * half of the composite primary key) so a member can appear in at most
       * one row across the whole table — one active household per member,
       * enforced by the database itself rather than application code, so a
       * race between two requests can't silently create two memberships.
       *
       * `primary_member_id` lives on `family_groups` (not a flag on the join
       * table), the same shape `cell_groups.leader_member_id` already uses —
       * it is a plain administrative "who to contact first" pointer, never
       * assumed to be a father, husband, or any particular relationship.
       */
      db.exec(`
        CREATE TABLE IF NOT EXISTS family_groups (
          id                INTEGER PRIMARY KEY AUTOINCREMENT,
          name              TEXT NOT NULL,
          primary_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
          created_at        TEXT NOT NULL,
          updated_at        TEXT NOT NULL,
          created_by        INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS family_group_members (
          family_group_id INTEGER NOT NULL REFERENCES family_groups(id) ON DELETE CASCADE,
          member_id       INTEGER NOT NULL UNIQUE REFERENCES members(id) ON DELETE CASCADE,
          joined_at       TEXT NOT NULL,
          PRIMARY KEY (family_group_id, member_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_family_group_members_group ON family_group_members(family_group_id)');

      /*
       * Two permissions, matching the existing Cell groups / Ministries
       * shape (a broad `view` plus a broad `manage` — no finer CRUD verbs,
       * since nothing about family-group management is as sensitive as a
       * permanent member deletion). Granted to Super Admin and Church Admin
       * only, per explicit instruction that Cell Group Leader and Member
       * should not automatically receive family-group administration rights.
       */
      const permissions = [
        ['family_groups.view', 'Family groups', 'View family groups (households) and their members'],
        ['family_groups.manage', 'Family groups', 'Create family groups and manage their membership']
      ];
      const roleKeys = ['super_admin', 'church_admin'];
      const insertRolePermission = db.prepare(
        'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)'
      );

      for (const [key, category, description] of permissions) {
        let permission = db.prepare('SELECT id FROM permissions WHERE key = @key').get({ key });
        if (!permission) {
          db.prepare(
            'INSERT INTO permissions (key, category, description) VALUES (@key, @category, @description)'
          ).run({ key, category, description });
          permission = db.prepare('SELECT id FROM permissions WHERE key = @key').get({ key });
        }
        for (const roleKey of roleKeys) {
          const role = db.prepare('SELECT id FROM roles WHERE key = @key').get({ key: roleKey });
          if (role) insertRolePermission.run({ roleId: role.id, permissionId: permission.id });
        }
      }
    }
  },
  {
    version: '0025_member_delete_permission',
    apply() {
      /*
       * A permanent-delete capability for a member record needs its own
       * permission, deliberately separate from members.archive (the normal,
       * reversible action for someone who is no longer active). Reserved for
       * Super Admin only, matching the one other "delete" permission already
       * in this catalogue (documents.delete, also Super Admin only) — a
       * permanent action gets a narrower grant than the "manage" permissions
       * around it, not a new tier of its own.
       */
      const existing = db.prepare("SELECT id FROM permissions WHERE key = 'members.delete'").get();
      if (existing) return;

      db.prepare(
        `INSERT INTO permissions (key, category, description)
         VALUES ('members.delete', 'Members', 'Permanently delete a member record with no meaningful history')`
      ).run();

      const permissionId = db.prepare("SELECT id FROM permissions WHERE key = 'members.delete'").get().id;
      const role = db.prepare("SELECT id FROM roles WHERE key = 'super_admin'").get();
      if (role) {
        db.prepare(
          'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)'
        ).run({ roleId: role.id, permissionId });
      }
    }
  },
  {
    version: '0024_attendance_checkin_permission',
    apply() {
      /*
       * A permission narrow enough to hand to a future restricted kiosk
       * identity: search people, resolve a QR code, and record attendance —
       * nothing else. It is deliberately separate from attendance.record,
       * which also opens the general session/roster management screens
       * (cell group filters, congregation breakdown, session editing) that a
       * wall-mounted entrance terminal has no business reaching. Existing
       * ushers are unaffected: every route this permission covers already
       * accepts attendance.record as an alternative, so nothing that worked
       * before requires this new permission to keep working. Granted here to
       * the same three roles that already hold attendance.record, so the
       * permission is real and assignable today even though no restricted
       * kiosk account exists yet — see CCIQ_DECISIONS.md.
       */
      const existing = db.prepare("SELECT id FROM permissions WHERE key = 'attendance.checkin'").get();
      if (existing) return;

      db.prepare(
        `INSERT INTO permissions (key, category, description)
         VALUES ('attendance.checkin', 'Attendance', 'Search people, scan a QR code and record attendance (kiosk-safe)')`
      ).run();

      const permissionId = db.prepare("SELECT id FROM permissions WHERE key = 'attendance.checkin'").get().id;
      const roleKeys = ['super_admin', 'church_admin', 'cell_group_leader'];
      const insertRolePermission = db.prepare(
        'INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@roleId, @permissionId)'
      );
      for (const roleKey of roleKeys) {
        const role = db.prepare('SELECT id FROM roles WHERE key = @key').get({ key: roleKey });
        if (role) insertRolePermission.run({ roleId: role.id, permissionId });
      }
    }
  },
  {
    version: '0023_guardian_relation',
    apply() {
      // What the guardian actually is to the member, for the common case
      // where it is not a parent (grandparent, aunt/uncle, family friend).
      // Free text, not a fixed list — a church encounters more shapes of
      // family than a short enum could name — and purely descriptive: it
      // carries no behaviour of its own, unlike guardian_member_id.
      if (!columnExists('members', 'guardian_relation')) {
        db.exec('ALTER TABLE members ADD COLUMN guardian_relation TEXT');
      }
    }
  },
  {
    version: '0022_faith_promise_one_time_frequency',
    apply() {
      /*
       * "Annual" originally meant both "a yearly pledge" and "a single
       * one-time gift" at once (its label even said so: "Annual (one-time
       * payment)"). The church's requirements distinguish the two, so this
       * adds a genuinely new 'one_time' value rather than repurposing
       * 'annual' — an existing or future row already stored as 'annual'
       * keeps that exact meaning; only its on-screen label changes, from
       * "Annual (one-time payment)" to "Yearly". Same table-rebuild
       * approach as the members.status and ecaq_campaigns.status
       * migrations above, since SQLite cannot widen a CHECK constraint
       * in place.
       */
      const current = db.prepare(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='ecaq_faith_promise_commitments'"
      ).get();
      if (!current) return;
      if (current.sql.includes("'one_time'")) return;

      const rebuilt = current.sql
        .replace(/CREATE TABLE "?ecaq_faith_promise_commitments"?/i, 'CREATE TABLE ecaq_faith_promise_commitments_rebuilt')
        .replace(/CHECK \(frequency IN \([^)]*\)\)/, "CHECK (frequency IN ('monthly','quarterly','annual','one_time'))");

      if (rebuilt === current.sql) return;

      const columns = db.prepare('PRAGMA table_info(ecaq_faith_promise_commitments)').all().map((c) => c.name);
      const indexes = db.prepare(
        "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='ecaq_faith_promise_commitments' AND sql IS NOT NULL"
      ).all().map((row) => row.sql);

      const wasEnforcing = db.pragma('foreign_keys', { simple: true });
      db.pragma('foreign_keys = OFF');
      try {
        db.exec('BEGIN');
        db.exec(rebuilt);
        db.exec(
          `INSERT INTO ecaq_faith_promise_commitments_rebuilt (${columns.join(', ')}) `
          + `SELECT ${columns.join(', ')} FROM ecaq_faith_promise_commitments`
        );
        db.exec('DROP TABLE ecaq_faith_promise_commitments');
        db.exec('ALTER TABLE ecaq_faith_promise_commitments_rebuilt RENAME TO ecaq_faith_promise_commitments');
        for (const indexSql of indexes) db.exec(indexSql);
        db.exec('COMMIT');
      } catch (err) {
        db.exec('ROLLBACK');
        throw err;
      } finally {
        if (wasEnforcing) db.pragma('foreign_keys = ON');
      }

      const violations = db.pragma('foreign_key_check');
      if (violations.length > 0) {
        throw new Error(`Rebuilding the ecaq_faith_promise_commitments table left ${violations.length} broken reference(s).`);
      }
    }
  },
  {
    version: '0021_qr_token_history',
    apply() {
      // When a code is replaced, the old value is kept here (never the new
      // one) purely so a scan of it can say "this was replaced" instead of
      // the misleading "not found" a typo would also produce — without
      // ever naming whose code it was, which the scan itself does not need
      // to know to tell someone their code is out of date.
      db.exec(`
        CREATE TABLE IF NOT EXISTS qr_token_history (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
          old_token   TEXT NOT NULL,
          retired_at  TEXT NOT NULL
        )`);
      db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_qr_token_history_token ON qr_token_history(old_token)');
    }
  },
  {
    version: '0020_member_qr_checkin',
    apply() {
      // Every member gets a random, unguessable token their QR code encodes
      // — never their member ID or record number, so a code can't be
      // forged or guessed by trying nearby values. Regenerating it (a lost
      // or compromised printout) is just replacing this value; the member
      // themselves is never affected.
      if (!columnExists('members', 'qr_token')) {
        db.exec('ALTER TABLE members ADD COLUMN qr_token TEXT');
        db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_members_qr_token ON members(qr_token) WHERE qr_token IS NOT NULL');
      }
      // Lets a self-service scan at the door be told apart from a leader
      // marking attendance by hand, without adding a new attendance status.
      if (!columnExists('attendance_records', 'source')) {
        db.exec("ALTER TABLE attendance_records ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'");
      }
      db.exec(`
        CREATE TABLE IF NOT EXISTS qr_checkins (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
          session_id  INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
          checked_in_at TEXT NOT NULL,
          confirmed_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
          UNIQUE(member_id, session_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_qr_checkins_session ON qr_checkins(session_id)');
    }
  },
  {
    version: '0010_documents',
    apply() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS document_categories (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          name        TEXT NOT NULL UNIQUE,
          slug        TEXT NOT NULL UNIQUE,
          description TEXT,
          audience    TEXT NOT NULL DEFAULT 'staff'
                        CHECK (audience IN ('staff','leaders','members')),
          sort_order  INTEGER NOT NULL DEFAULT 0,
          status      TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active','archived')),
          created_at  TEXT NOT NULL,
          updated_at  TEXT NOT NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS documents (
          id                INTEGER PRIMARY KEY AUTOINCREMENT,
          title             TEXT NOT NULL,
          description       TEXT,
          category_id       INTEGER REFERENCES document_categories(id) ON DELETE RESTRICT,
          original_filename TEXT NOT NULL,
          stored_path       TEXT NOT NULL,
          mime_type         TEXT NOT NULL,
          file_extension    TEXT,
          file_size         INTEGER NOT NULL DEFAULT 0,
          document_date     TEXT,
          expiry_date       TEXT,
          notes             TEXT,
          amount            REAL,
          currency          TEXT,
          vendor            TEXT,
          status            TEXT NOT NULL DEFAULT 'active'
                              CHECK (status IN ('active','archived','deleted')),
          version           INTEGER NOT NULL DEFAULT 1,
          uploaded_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
          created_at        TEXT NOT NULL,
          updated_at        TEXT NOT NULL,
          archived_at       TEXT,
          deleted_at        TEXT
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_documents_uploader ON documents(uploaded_by)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_documents_date ON documents(document_date)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_documents_expiry ON documents(expiry_date)');

      db.exec(`
        CREATE TABLE IF NOT EXISTS document_tags (
          id         INTEGER PRIMARY KEY AUTOINCREMENT,
          name       TEXT NOT NULL,
          slug       TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS document_tag_links (
          document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          tag_id      INTEGER NOT NULL REFERENCES document_tags(id) ON DELETE CASCADE,
          PRIMARY KEY (document_id, tag_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_document_tag_links_tag ON document_tag_links(tag_id)');

      // Replacing a file keeps what it replaced, so nothing is silently lost.
      db.exec(`
        CREATE TABLE IF NOT EXISTS document_versions (
          id                INTEGER PRIMARY KEY AUTOINCREMENT,
          document_id       INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          version           INTEGER NOT NULL,
          original_filename TEXT NOT NULL,
          stored_path       TEXT NOT NULL,
          mime_type         TEXT NOT NULL,
          file_size         INTEGER NOT NULL DEFAULT 0,
          note              TEXT,
          created_at        TEXT NOT NULL,
          created_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
          UNIQUE (document_id, version)
        )`);

      // A document can point at a member, cell group, activity or project
      // without duplicating any of their details.
      db.exec(`
        CREATE TABLE IF NOT EXISTS document_relationships (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          document_id   INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          related_type  TEXT NOT NULL
                          CHECK (related_type IN ('member','cell_group','activity','ministry','project')),
          related_id    INTEGER,
          created_at    TEXT NOT NULL,
          UNIQUE (document_id, related_type, related_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_document_rel_target ON document_relationships(related_type, related_id)');
    }
  },
  {
    version: '0011_member_departure_statuses',
    apply() {
      // Departure details sit alongside the status rather than replacing it.
      if (!columnExists('members', 'destination_country')) {
        db.exec('ALTER TABLE members ADD COLUMN destination_country TEXT');
      }
      if (!columnExists('members', 'departure_notes')) {
        db.exec('ALTER TABLE members ADD COLUMN departure_notes TEXT');
      }

      /*
       * The status column carries a CHECK constraint, and SQLite cannot alter
       * one in place. The table is rebuilt from its own definition with only
       * the allowed list widened, so the columns cannot drift from what is
       * already there, and every existing record keeps its status.
       */
      const current = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='members'").get();
      if (!current || !/CHECK \(status IN \(/.test(current.sql)) return;

      const allowed = "'active','inactive','pending','archived','temporarily_away',"
        + "'returned_home','migrated','transferred','other'";
      const rebuilt = current.sql
        .replace(/CREATE TABLE "?members"?/i, 'CREATE TABLE members_rebuilt')
        .replace(/CHECK \(status IN \([^)]*\)\)/, `CHECK (status IN (${allowed}))`);

      if (rebuilt === current.sql) return;

      const columns = db.prepare('PRAGMA table_info(members)').all().map((c) => c.name);
      const indexes = db.prepare(
        "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='members' AND sql IS NOT NULL"
      ).all().map((row) => row.sql);

      const wasEnforcing = db.pragma('foreign_keys', { simple: true });
      db.pragma('foreign_keys = OFF');
      try {
        db.exec('BEGIN');
        db.exec(rebuilt);
        db.exec(`INSERT INTO members_rebuilt (${columns.join(', ')}) SELECT ${columns.join(', ')} FROM members`);
        db.exec('DROP TABLE members');
        db.exec('ALTER TABLE members_rebuilt RENAME TO members');
        for (const indexSql of indexes) db.exec(indexSql);
        db.exec('COMMIT');
      } catch (err) {
        db.exec('ROLLBACK');
        throw err;
      } finally {
        if (wasEnforcing) db.pragma('foreign_keys = ON');
      }

      const violations = db.pragma('foreign_key_check');
      if (violations.length > 0) {
        throw new Error(`Rebuilding the members table left ${violations.length} broken reference(s).`);
      }
    }
  },
  {
    version: '0012_ministry_photo',
    apply() {
      // A ministry can carry a photo, as a cell group already could.
      if (!columnExists('ministries', 'photo_path')) {
        db.exec('ALTER TABLE ministries ADD COLUMN photo_path TEXT');
      }
    }
  },
  {
    version: '0013_finance_foundation',
    apply() {
      /*
       * Money is stored in minor units as integers — fils for QAR, cents for
       * USD. Floating point would drift, and a church's books should not.
       */

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_currencies (
          code        TEXT PRIMARY KEY,
          name        TEXT NOT NULL,
          minor_units INTEGER NOT NULL DEFAULT 2,
          is_base     INTEGER NOT NULL DEFAULT 0,
          is_active   INTEGER NOT NULL DEFAULT 1,
          sort_order  INTEGER NOT NULL DEFAULT 0
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_exchange_rates (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          from_currency  TEXT NOT NULL REFERENCES finance_currencies(code),
          to_currency    TEXT NOT NULL REFERENCES finance_currencies(code),
          rate           REAL NOT NULL CHECK (rate > 0),
          effective_date TEXT NOT NULL,
          source         TEXT,
          note           TEXT,
          created_at     TEXT NOT NULL,
          created_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
          UNIQUE (from_currency, to_currency, effective_date)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fx_lookup ON finance_exchange_rates(from_currency, to_currency, effective_date)');

      // The chart of accounts, including the bank and cash accounts a balance
      // is proved against.
      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_accounts (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          code          TEXT NOT NULL UNIQUE,
          name          TEXT NOT NULL,
          type          TEXT NOT NULL
                          CHECK (type IN ('asset','liability','income','expense','equity')),
          subtype       TEXT
                          CHECK (subtype IN ('bank','cash','investment','receivable','payable',
                                             'general') OR subtype IS NULL),
          currency      TEXT REFERENCES finance_currencies(code),
          institution   TEXT,
          reference     TEXT,
          description   TEXT,
          is_active     INTEGER NOT NULL DEFAULT 1,
          sort_order    INTEGER NOT NULL DEFAULT 0,
          created_at    TEXT NOT NULL,
          updated_at    TEXT NOT NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_funds (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          name        TEXT NOT NULL UNIQUE,
          description TEXT,
          is_restricted INTEGER NOT NULL DEFAULT 0,
          is_active   INTEGER NOT NULL DEFAULT 1,
          sort_order  INTEGER NOT NULL DEFAULT 0,
          created_at  TEXT NOT NULL,
          updated_at  TEXT NOT NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_categories (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          name        TEXT NOT NULL,
          kind        TEXT NOT NULL CHECK (kind IN ('income','expense')),
          account_id  INTEGER NOT NULL REFERENCES finance_accounts(id) ON DELETE RESTRICT,
          description TEXT,
          is_active   INTEGER NOT NULL DEFAULT 1,
          sort_order  INTEGER NOT NULL DEFAULT 0,
          created_at  TEXT NOT NULL,
          updated_at  TEXT NOT NULL,
          UNIQUE (name, kind)
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_payment_methods (
          id         INTEGER PRIMARY KEY AUTOINCREMENT,
          name       TEXT NOT NULL UNIQUE,
          is_active  INTEGER NOT NULL DEFAULT 1,
          sort_order INTEGER NOT NULL DEFAULT 0
        )`);

      /*
       * The transaction header carries what the Finance Team typed; the lines
       * carry the double entry the system derived from it. Reports read the
       * lines, so the two can never disagree.
       */
      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_transactions (
          id                INTEGER PRIMARY KEY AUTOINCREMENT,
          reference         TEXT NOT NULL UNIQUE,
          kind              TEXT NOT NULL CHECK (kind IN ('income','expense','transfer')),
          txn_date          TEXT NOT NULL,
          description       TEXT NOT NULL,
          notes             TEXT,
          currency          TEXT NOT NULL REFERENCES finance_currencies(code),
          rate              REAL NOT NULL DEFAULT 1 CHECK (rate > 0),
          rate_date         TEXT,
          amount_minor      INTEGER NOT NULL CHECK (amount_minor > 0),
          base_amount_minor INTEGER NOT NULL CHECK (base_amount_minor > 0),
          category_id       INTEGER REFERENCES finance_categories(id) ON DELETE RESTRICT,
          fund_id           INTEGER REFERENCES finance_funds(id) ON DELETE RESTRICT,
          project_id        INTEGER REFERENCES ecaq_campaigns(id) ON DELETE SET NULL,
          account_id        INTEGER REFERENCES finance_accounts(id) ON DELETE RESTRICT,
          counter_account_id INTEGER REFERENCES finance_accounts(id) ON DELETE RESTRICT,
          payment_method_id INTEGER REFERENCES finance_payment_methods(id) ON DELETE SET NULL,
          payee             TEXT,
          status            TEXT NOT NULL DEFAULT 'draft'
                              CHECK (status IN ('draft','pending_review','reviewed',
                                                'pending_approval','approved','posted',
                                                'returned','rejected','cancelled','reversed')),
          required_level    INTEGER NOT NULL DEFAULT 1,
          reverses_id       INTEGER REFERENCES finance_transactions(id) ON DELETE SET NULL,
          entered_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
          reviewed_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
          approved_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
          posted_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
          created_at        TEXT NOT NULL,
          updated_at        TEXT NOT NULL,
          submitted_at      TEXT,
          reviewed_at       TEXT,
          approved_at       TEXT,
          posted_at         TEXT
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_txn_status_date ON finance_transactions(status, txn_date)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_txn_fund ON finance_transactions(fund_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_txn_category ON finance_transactions(category_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_txn_project ON finance_transactions(project_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_txn_entered ON finance_transactions(entered_by)');

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_transaction_lines (
          id                INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id    INTEGER NOT NULL REFERENCES finance_transactions(id) ON DELETE CASCADE,
          account_id        INTEGER NOT NULL REFERENCES finance_accounts(id) ON DELETE RESTRICT,
          direction         TEXT NOT NULL CHECK (direction IN ('debit','credit')),
          amount_minor      INTEGER NOT NULL CHECK (amount_minor > 0),
          base_amount_minor INTEGER NOT NULL CHECK (base_amount_minor > 0),
          currency          TEXT NOT NULL REFERENCES finance_currencies(code),
          fund_id           INTEGER REFERENCES finance_funds(id) ON DELETE RESTRICT,
          category_id       INTEGER REFERENCES finance_categories(id) ON DELETE RESTRICT,
          memo              TEXT
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_lines_txn ON finance_transaction_lines(transaction_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_lines_account ON finance_transaction_lines(account_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_lines_fund ON finance_transaction_lines(fund_id)');

      // Insert-only: the record of who did what to a transaction.
      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_workflow_history (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER NOT NULL REFERENCES finance_transactions(id) ON DELETE CASCADE,
          action         TEXT NOT NULL,
          from_status    TEXT,
          to_status      TEXT,
          comment        TEXT,
          actor_id       INTEGER REFERENCES users(id) ON DELETE SET NULL,
          actor_label    TEXT,
          created_at     TEXT NOT NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_history_txn ON finance_workflow_history(transaction_id)');

      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_attachments (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER REFERENCES finance_transactions(id) ON DELETE CASCADE,
          title          TEXT NOT NULL,
          doc_category   TEXT,
          document_date  TEXT,
          original_filename TEXT NOT NULL,
          stored_path    TEXT NOT NULL,
          mime_type      TEXT NOT NULL,
          file_size      INTEGER NOT NULL DEFAULT 0,
          notes          TEXT,
          uploaded_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
          created_at     TEXT NOT NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fin_attach_txn ON finance_attachments(transaction_id)');

      // Thresholds live here so they can be changed without touching code.
      db.exec(`
        CREATE TABLE IF NOT EXISTS finance_approval_rules (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          name           TEXT NOT NULL,
          applies_to     TEXT NOT NULL DEFAULT 'any'
                           CHECK (applies_to IN ('any','income','expense','transfer',
                                                 'investment','reversal','foreign_currency')),
          min_base_minor INTEGER,
          required_level INTEGER NOT NULL CHECK (required_level IN (1,2,3)),
          is_active      INTEGER NOT NULL DEFAULT 1,
          sort_order     INTEGER NOT NULL DEFAULT 0,
          created_at     TEXT NOT NULL,
          updated_at     TEXT NOT NULL
        )`);
    }
  },
  {
    version: '0014_remove_finance',
    apply() {
      /*
       * The Finance module was removed at the church's request. Its tables are
       * dropped rather than left behind, so a backup does not carry structures
       * nothing uses.
       */
      for (const table of [
        'finance_attachments', 'finance_workflow_history', 'finance_transaction_lines',
        'finance_transactions', 'finance_approval_rules', 'finance_categories',
        'finance_payment_methods', 'finance_funds', 'finance_exchange_rates',
        'finance_accounts', 'finance_currencies'
      ]) {
        db.exec(`DROP TABLE IF EXISTS ${table}`);
      }

      db.exec("DELETE FROM role_permissions WHERE permission_id IN (SELECT id FROM permissions WHERE key LIKE 'finance.%')");
      db.exec("DELETE FROM user_roles WHERE role_id IN (SELECT id FROM roles WHERE key LIKE 'finance_%')");
      db.exec("DELETE FROM permissions WHERE key LIKE 'finance.%'");
      db.exec("DELETE FROM roles WHERE key LIKE 'finance_%'");
      db.exec("DELETE FROM system_settings WHERE key LIKE 'finance.%'");
    }
  },
  {
    version: '0015_usernames',
    apply() {
      /*
       * People sign in with a username or an email address. A church worker
       * without an email of their own still needs an account, so the username
       * is what the account is really identified by.
       */
      if (!columnExists('users', 'username')) {
        db.exec('ALTER TABLE users ADD COLUMN username TEXT');
        db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username)');

        // Existing accounts keep working: their username is the part of their
        // email before the @, unless that is already taken.
        const users = db.prepare('SELECT id, email FROM users').all();
        const taken = new Set();
        for (const user of users) {
          let candidate = String(user.email || '').split('@')[0].toLowerCase()
            .replace(/[^a-z0-9._-]/g, '') || `user${user.id}`;
          while (taken.has(candidate)) candidate = `${candidate}${user.id}`;
          taken.add(candidate);
          db.prepare('UPDATE users SET username = @username WHERE id = @id')
            .run({ id: user.id, username: candidate });
        }
      }
    }
  },
  {
    version: '0002_cell_group_membership_history',
    apply() {
      if (!columnExists('cell_group_members', 'left_at')) {
        db.exec('ALTER TABLE cell_group_members ADD COLUMN left_at TEXT');
      }
      db.exec('CREATE INDEX IF NOT EXISTS idx_group_members_member ON cell_group_members(member_id)');
    }
  },
  {
    version: '0009_leadership_groups',
    apply() {
      // The church groups its leadership as a Board of Elders and a Council of
      // Deacons, so the About page can show them under those headings.
      if (!columnExists('church_leaders', 'group_label')) {
        db.exec('ALTER TABLE church_leaders ADD COLUMN group_label TEXT');
      }
    }
  },
  {
    version: '0008_ministries',
    apply() {
      // A ministry is a team serving the church. Unlike a cell group, a member
      // may serve in several at once, so membership is its own table.
      db.exec(`
        CREATE TABLE IF NOT EXISTS ministries (
          id                  INTEGER PRIMARY KEY AUTOINCREMENT,
          name                TEXT NOT NULL UNIQUE,
          description         TEXT,
          leader_member_id    INTEGER REFERENCES members(id) ON DELETE SET NULL,
          assistant_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
          meets               TEXT,
          contact             TEXT,
          status              TEXT NOT NULL DEFAULT 'active'
                                CHECK (status IN ('active','inactive','archived')),
          sort_order          INTEGER NOT NULL DEFAULT 0,
          created_at          TEXT NOT NULL,
          updated_at          TEXT NOT NULL,
          created_by          INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);

      db.exec(`
        CREATE TABLE IF NOT EXISTS ministry_members (
          ministry_id INTEGER NOT NULL REFERENCES ministries(id) ON DELETE CASCADE,
          member_id   INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
          role        TEXT NOT NULL DEFAULT 'member',
          joined_at   TEXT NOT NULL,
          left_at     TEXT,
          notes       TEXT,
          PRIMARY KEY (ministry_id, member_id)
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_ministry_members_member ON ministry_members(member_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_ministry_members_active ON ministry_members(ministry_id, left_at)');
    }
  },
  {
    version: '0017_leadership_group_names',
    apply() {
      /*
       * The exact wording changed from "Board of Elders" to "Board of Elders
       * (Pastors)", to make clear these are the same people, not two
       * separate leadership groups. Anyone already recorded under the old
       * name is moved to the new one so their place in the fixed Elders,
       * then Deacons ordering is not lost.
       */
      db.exec(`
        UPDATE church_leaders SET group_label = 'Board of Elders (Pastors)'
         WHERE group_label = 'Board of Elders'
      `);
    }
  },
  {
    version: '0019_campaign_types_and_faith_promise',
    apply() {
      /*
       * Every campaign has always been shaped like a Giving Board, because
       * that was the only kind that existed. The church's projects change
       * from year to year — 2026 is a pledge campaign, not a board of dates
       * — so a campaign now carries its own type, and only a Giving Board
       * campaign is expected to have board-specific fields like
       * background_image or amount_per_date.
       */
      if (!columnExists('ecaq_campaigns', 'type')) {
        db.exec("ALTER TABLE ecaq_campaigns ADD COLUMN type TEXT NOT NULL DEFAULT 'giving_board'");
      }

      // The status column gains "archived", alongside draft/active/closed —
      // a campaign's status has never been tied to its year, and this just
      // widens the set of states an administrator can choose from.
      const current = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='ecaq_campaigns'").get();
      if (current && /CHECK \(status IN \(/.test(current.sql) && !current.sql.includes("'archived'")) {
        const rebuilt = current.sql
          .replace(/CREATE TABLE "?ecaq_campaigns"?/i, 'CREATE TABLE ecaq_campaigns_rebuilt')
          .replace(/CHECK \(status IN \([^)]*\)\)/, "CHECK (status IN ('draft','active','closed','archived'))");
        if (rebuilt !== current.sql) {
          const columns = db.prepare('PRAGMA table_info(ecaq_campaigns)').all().map((c) => c.name);
          const indexes = db.prepare(
            "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='ecaq_campaigns' AND sql IS NOT NULL"
          ).all().map((row) => row.sql);
          const wasEnforcing = db.pragma('foreign_keys', { simple: true });
          db.pragma('foreign_keys = OFF');
          try {
            db.exec('BEGIN');
            db.exec(rebuilt);
            db.exec(`INSERT INTO ecaq_campaigns_rebuilt (${columns.join(', ')}) SELECT ${columns.join(', ')} FROM ecaq_campaigns`);
            db.exec('DROP TABLE ecaq_campaigns');
            db.exec('ALTER TABLE ecaq_campaigns_rebuilt RENAME TO ecaq_campaigns');
            for (const indexSql of indexes) db.exec(indexSql);
            db.exec('COMMIT');
          } catch (err) {
            db.exec('ROLLBACK');
            throw err;
          } finally {
            if (wasEnforcing) db.pragma('foreign_keys = ON');
          }
        }
      }

      // The 2025 board keeps every claim and payment exactly as it is; only
      // its name and type are being made explicit, since it is still an
      // active campaign in every sense that matters.
      db.exec(`
        UPDATE ecaq_campaigns SET type = 'giving_board',
               name = '2025 Thanksgiving Project (Giving Board)'
         WHERE year = 2025 AND type = 'giving_board'
      `);

      // Faith Promise: a pledge campaign, not a board of individual dates.
      // Its own commitments and payments, so nothing about the Giving Board
      // tables needs to change to support a completely different kind of
      // project existing alongside it.
      db.exec(`
        CREATE TABLE IF NOT EXISTS ecaq_faith_promise_commitments (
          id                 INTEGER PRIMARY KEY AUTOINCREMENT,
          campaign_id        INTEGER NOT NULL REFERENCES ecaq_campaigns(id) ON DELETE CASCADE,
          member_id          INTEGER REFERENCES members(id) ON DELETE SET NULL,
          name               TEXT NOT NULL,
          phone              TEXT,
          email              TEXT,
          commitment_amount  REAL NOT NULL,
          frequency          TEXT NOT NULL CHECK (frequency IN ('monthly','quarterly','annual')),
          expected_total     REAL NOT NULL,
          amount_collected   REAL NOT NULL DEFAULT 0,
          status             TEXT NOT NULL DEFAULT 'not_started'
                               CHECK (status IN ('not_started','in_progress','completed')),
          notes              TEXT,
          submitted_at       TEXT NOT NULL,
          created_at         TEXT NOT NULL,
          updated_at         TEXT NOT NULL,
          created_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
          updated_by         INTEGER REFERENCES users(id) ON DELETE SET NULL
        )
      `);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fp_commitments_campaign ON ecaq_faith_promise_commitments(campaign_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_fp_commitments_member ON ecaq_faith_promise_commitments(member_id)');

      db.exec(`
        CREATE TABLE IF NOT EXISTS ecaq_faith_promise_payments (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          commitment_id INTEGER NOT NULL REFERENCES ecaq_faith_promise_commitments(id) ON DELETE CASCADE,
          amount        REAL NOT NULL,
          paid_on       TEXT NOT NULL,
          method        TEXT,
          reference     TEXT,
          notes         TEXT,
          created_at    TEXT NOT NULL,
          created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
          updated_at    TEXT,
          updated_by    INTEGER REFERENCES users(id) ON DELETE SET NULL
        )
      `);
      db.exec('CREATE INDEX IF NOT EXISTS idx_fp_payments_commitment ON ecaq_faith_promise_payments(commitment_id)');

      // A simple, church-administrator-buildable custom campaign: a list of
      // fields it asks for, and one flexible submission per person that
      // stores their answers against those fields. Not a full form builder,
      // but enough to stand up a genuinely different project in 2027 without
      // asking anyone to change code.
      db.exec(`
        CREATE TABLE IF NOT EXISTS ecaq_custom_fields (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          campaign_id   INTEGER NOT NULL REFERENCES ecaq_campaigns(id) ON DELETE CASCADE,
          field_key     TEXT NOT NULL,
          label         TEXT NOT NULL,
          field_type    TEXT NOT NULL DEFAULT 'text'
                          CHECK (field_type IN ('text','long_text','number','currency','date',
                                                 'checkbox','dropdown','yes_no','phone','email')),
          options       TEXT,
          required      INTEGER NOT NULL DEFAULT 0,
          display_order INTEGER NOT NULL DEFAULT 0,
          admin_only    INTEGER NOT NULL DEFAULT 0,
          created_at    TEXT NOT NULL,
          UNIQUE (campaign_id, field_key)
        )
      `);

      db.exec(`
        CREATE TABLE IF NOT EXISTS ecaq_custom_submissions (
          id            INTEGER PRIMARY KEY AUTOINCREMENT,
          campaign_id   INTEGER NOT NULL REFERENCES ecaq_campaigns(id) ON DELETE CASCADE,
          member_id     INTEGER REFERENCES members(id) ON DELETE SET NULL,
          values_json   TEXT NOT NULL DEFAULT '{}',
          submitted_at  TEXT NOT NULL,
          updated_at    TEXT NOT NULL,
          created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
          updated_by    INTEGER REFERENCES users(id) ON DELETE SET NULL
        )
      `);
      db.exec('CREATE INDEX IF NOT EXISTS idx_custom_submissions_campaign ON ecaq_custom_submissions(campaign_id)');

      // Correcting a payment's actual date later needs somewhere to show
      // that it changed, and by whom — the Giving Board's own payments table
      // never needed this until a date could be edited after the fact.
      if (!columnExists('ecaq_payments', 'updated_at')) {
        db.exec('ALTER TABLE ecaq_payments ADD COLUMN updated_at TEXT');
        db.exec('ALTER TABLE ecaq_payments ADD COLUMN updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL');
      }
    }
  },
  {
    version: '0018_member_attendee_bonafide_statuses',
    apply() {
      /*
       * Two more membership classifications the church actually uses:
       * Attendee (attends but has not yet gone through membership) and
       * Bonafide (a fully recognised member) — each its own status, at the
       * same level as Active or Inactive, not a tier above or below either.
       * Same table-rebuild approach as the departure statuses migration,
       * since SQLite cannot widen a CHECK constraint in place.
       */
      const current = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='members'").get();
      if (!current || !/CHECK \(status IN \(/.test(current.sql)) return;
      if (current.sql.includes("'bonafide'")) return;

      const allowed = "'active','inactive','pending','archived','temporarily_away',"
        + "'returned_home','migrated','transferred','other','attendee','bonafide'";
      const rebuilt = current.sql
        .replace(/CREATE TABLE "?members"?/i, 'CREATE TABLE members_rebuilt')
        .replace(/CHECK \(status IN \([^)]*\)\)/, `CHECK (status IN (${allowed}))`);

      if (rebuilt === current.sql) return;

      const columns = db.prepare('PRAGMA table_info(members)').all().map((c) => c.name);
      const indexes = db.prepare(
        "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='members' AND sql IS NOT NULL"
      ).all().map((row) => row.sql);

      const wasEnforcing = db.pragma('foreign_keys', { simple: true });
      db.pragma('foreign_keys = OFF');
      try {
        db.exec('BEGIN');
        db.exec(rebuilt);
        db.exec(`INSERT INTO members_rebuilt (${columns.join(', ')}) SELECT ${columns.join(', ')} FROM members`);
        db.exec('DROP TABLE members');
        db.exec('ALTER TABLE members_rebuilt RENAME TO members');
        for (const indexSql of indexes) db.exec(indexSql);
        db.exec('COMMIT');
      } catch (err) {
        db.exec('ROLLBACK');
        throw err;
      } finally {
        if (wasEnforcing) db.pragma('foreign_keys = ON');
      }

      const violations = db.pragma('foreign_key_check');
      if (violations.length > 0) {
        throw new Error(`Rebuilding the members table left ${violations.length} broken reference(s).`);
      }

      // The legacy import brings in a "SEQ" reference number from the old
      // spreadsheet, kept alongside the member rather than replacing the
      // portal's own member code.
      if (!columnExists('members', 'legacy_reference')) {
        db.exec('ALTER TABLE members ADD COLUMN legacy_reference TEXT');
      }
    }
  },
  {
    version: '0016_document_category_financial_flag',
    apply() {
      /*
       * Receipt fields (amount, currency, vendor) only make sense for a
       * financial document. Which categories count as financial is a church
       * decision, made per category rather than guessed from a document's
       * title, so the flag lives on the category itself.
       */
      if (!columnExists('document_categories', 'is_financial')) {
        db.exec('ALTER TABLE document_categories ADD COLUMN is_financial INTEGER NOT NULL DEFAULT 0');

        // A category a church already named for this purpose is switched on
        // automatically; anything else stays off until set by hand.
        db.exec(`
          UPDATE document_categories
             SET is_financial = 1
           WHERE is_financial = 0
             AND (
               lower(name) LIKE '%financ%' OR lower(name) LIKE '%receipt%' OR
               lower(name) LIKE '%invoice%' OR lower(name) LIKE '%donation%' OR
               lower(name) LIKE '%payment%' OR lower(name) LIKE '%expense%'
             )
        `);
      }
    }
  },
  {
    version: '0007_member_detail_and_claim_names',
    apply() {
      const add = (table, column, definition) => {
        if (!columnExists(table, column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
      };

      // Family and household
      add('members', 'spouse_name', 'TEXT');
      add('members', 'spouse_member_id', 'INTEGER REFERENCES members(id) ON DELETE SET NULL');
      add('members', 'father_name', 'TEXT');
      add('members', 'mother_name', 'TEXT');
      add('members', 'father_member_id', 'INTEGER REFERENCES members(id) ON DELETE SET NULL');
      add('members', 'mother_member_id', 'INTEGER REFERENCES members(id) ON DELETE SET NULL');
      add('members', 'parents_attend_cciq', 'TEXT');

      // Addresses here and at home
      add('members', 'home_country', 'TEXT');
      add('members', 'home_country_address', 'TEXT');

      // Baptism
      add('members', 'is_baptized', 'INTEGER NOT NULL DEFAULT 0');
      add('members', 'baptism_date', 'TEXT');
      add('members', 'baptism_place', 'TEXT');

      // Work in Qatar
      add('members', 'company', 'TEXT');
      add('members', 'occupation', 'TEXT');

      db.exec('CREATE INDEX IF NOT EXISTS idx_members_baptized ON members(is_baptized)');

      // A giving board claim can carry the name the member wants shown, which
      // may be initials or something other than their record name.
      add('ecaq_giving_board_claims', 'display_as', 'TEXT');
    }
  },
  {
    version: '0006_congregations_visitors_payments',
    apply() {
      // A member's congregation follows their age, but can be set by hand where
      // the birth date is unknown or the church decides otherwise.
      if (!columnExists('members', 'age_group')) {
        db.exec("ALTER TABLE members ADD COLUMN age_group TEXT");
      }
      // Children are linked to the parent or guardian who brings them.
      if (!columnExists('members', 'guardian_member_id')) {
        db.exec('ALTER TABLE members ADD COLUMN guardian_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL');
      }
      db.exec('CREATE INDEX IF NOT EXISTS idx_members_age_group ON members(age_group)');

      // People visiting for the first time are not member records yet.
      db.exec(`
        CREATE TABLE IF NOT EXISTS visitors (
          id                  INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name          TEXT NOT NULL,
          last_name           TEXT,
          phone               TEXT,
          email               TEXT,
          age_group           TEXT,
          first_visit_date    TEXT NOT NULL,
          congregation        TEXT,
          invited_by_member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
          invited_by_name     TEXT,
          how_heard           TEXT,
          notes               TEXT,
          state               TEXT NOT NULL DEFAULT 'new',
          follow_up_state     TEXT NOT NULL DEFAULT 'new',
          follow_up_notes     TEXT,
          member_id           INTEGER REFERENCES members(id) ON DELETE SET NULL,
          created_at          TEXT NOT NULL,
          updated_at          TEXT NOT NULL,
          created_by          INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_visitors_first_visit ON visitors(first_visit_date)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_visitors_inviter ON visitors(invited_by_member_id)');

      db.exec(`
        CREATE TABLE IF NOT EXISTS visitor_visits (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          visitor_id  INTEGER NOT NULL REFERENCES visitors(id) ON DELETE CASCADE,
          visit_date  TEXT NOT NULL,
          session_id  INTEGER REFERENCES attendance_sessions(id) ON DELETE SET NULL,
          notes       TEXT,
          recorded_at TEXT NOT NULL,
          recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
          UNIQUE (visitor_id, visit_date)
        )`);

      // Each payment against a Giving Board commitment is its own record, so a
      // commitment paid monthly is a list of receipts rather than one figure.
      db.exec(`
        CREATE TABLE IF NOT EXISTS ecaq_payments (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          claim_id    INTEGER NOT NULL REFERENCES ecaq_giving_board_claims(id) ON DELETE CASCADE,
          amount      REAL NOT NULL,
          paid_on     TEXT NOT NULL,
          method      TEXT,
          reference   TEXT,
          notes       TEXT,
          received_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
          received_by_name TEXT,
          created_at  TEXT NOT NULL,
          created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_payments_claim ON ecaq_payments(claim_id)');
      db.exec('CREATE INDEX IF NOT EXISTS idx_payments_date ON ecaq_payments(paid_on)');
    }
  },
  {
    version: '0005_church_profile_and_imports',
    apply() {
      // Church background, mission and vision are content the church edits,
      // never facts written into the code.
      db.exec(`
        CREATE TABLE IF NOT EXISTS church_pages (
          key        TEXT PRIMARY KEY,
          title      TEXT NOT NULL,
          body       TEXT,
          sort_order INTEGER NOT NULL DEFAULT 0,
          is_visible INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL,
          updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);
      db.exec(`
        CREATE TABLE IF NOT EXISTS church_leaders (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          name        TEXT NOT NULL,
          role_title  TEXT,
          description TEXT,
          email       TEXT,
          phone       TEXT,
          photo_path  TEXT,
          sort_order  INTEGER NOT NULL DEFAULT 0,
          is_visible  INTEGER NOT NULL DEFAULT 1,
          created_at  TEXT NOT NULL,
          updated_at  TEXT NOT NULL
        )`);
      // A record of every spreadsheet import, so an import can be explained later.
      db.exec(`
        CREATE TABLE IF NOT EXISTS import_batches (
          id           INTEGER PRIMARY KEY AUTOINCREMENT,
          kind         TEXT NOT NULL,
          filename     TEXT,
          row_count    INTEGER NOT NULL DEFAULT 0,
          created_count INTEGER NOT NULL DEFAULT 0,
          updated_count INTEGER NOT NULL DEFAULT 0,
          skipped_count INTEGER NOT NULL DEFAULT 0,
          notes        TEXT,
          created_at   TEXT NOT NULL,
          created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_import_time ON import_batches(created_at)');
    }
  },
  {
    version: '0004_backup_history',
    apply() {
      // Backups gain a kind so a copy taken automatically before a restore is
      // distinguishable from one an administrator asked for.
      if (!columnExists('backups', 'kind')) {
        db.exec("ALTER TABLE backups ADD COLUMN kind TEXT NOT NULL DEFAULT 'manual'");
      }
      db.exec(`
        CREATE TABLE IF NOT EXISTS backup_restores (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          backup_id   INTEGER REFERENCES backups(id) ON DELETE SET NULL,
          status      TEXT NOT NULL CHECK (status IN ('complete','failed')),
          notes       TEXT,
          restored_at TEXT NOT NULL,
          restored_by INTEGER REFERENCES users(id) ON DELETE SET NULL
        )`);
      db.exec('CREATE INDEX IF NOT EXISTS idx_restores_time ON backup_restores(restored_at)');
    }
  },
  {
    version: '0003_member_photo_metadata',
    apply() {
      if (!columnExists('members', 'photo_updated_at')) {
        db.exec('ALTER TABLE members ADD COLUMN photo_updated_at TEXT');
      }
    }
  }
];

export function migrate() {
  const sql = fs.readFileSync(path.join(here, 'schema.sql'), 'utf8');
  db.exec(sql);

  const record = db.prepare(
    'INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (@version, @applied_at)'
  );
  record.run({ version: '0001_initial', applied_at: new Date().toISOString() });

  const applied = new Set(db.prepare('SELECT version FROM schema_migrations').all().map((r) => r.version));

  /*
   * Steps are applied in version order regardless of how they are written in
   * this file. A later step often alters a table an earlier one created, so
   * the order must come from the version number, not the source.
   */
  const ordered = [...STEPS].sort((a, b) => a.version.localeCompare(b.version));

  for (const step of ordered) {
    if (applied.has(step.version)) continue;
    step.apply();
    record.run({ version: step.version, applied_at: new Date().toISOString() });
  }
  return true;
}

/*
 * Migration execution safety (Codex/independent verification): migrate()
 * above used to be reachable from at least seven independent entry points -
 * normal server startup, the daily scheduled backup, the manual backup
 * button, first-run setup, the reset-password utility, and the seed/setup
 * scripts - every one of them able to silently advance schema_migrations
 * as a side effect of doing something else entirely. That is exactly how
 * migration 0028 was applied without an intentional deployment: an
 * unrelated scheduled task called migrate() on its own, ordinary schedule.
 *
 * From here on, migrate() itself is only ever called from two places:
 * this file's own `npm run db:migrate` entry point below (the one,
 * explicit, intentional way to advance a database that already exists),
 * and bootstrapIfNewOrEnsureCompatible() below (for the small set of
 * setup utilities that must also work the very first time, against a
 * database that does not exist yet at all - see that function's own
 * comment for why a brand-new database is a different case from an
 * existing one that is merely behind).
 *
 * Every other caller now uses ensureSchemaCompatible() (or checks
 * checkSchemaCompatibility() itself, for callers that want to log their
 * own message rather than let an exception propagate) - read-only,
 * never mutates schema_migrations, and refuses clearly rather than ever
 * silently upgrading anything.
 */

/**
 * The full, ordered, authoritative set of migration versions this exact
 * code understands: '0001_initial' (the baseline schema.sql itself) plus
 * every STEPS entry. Exported so the compatibility check below and its
 * tests share one single source of truth, rather than comparing a mere
 * COUNT (two entirely different migration histories could coincidentally
 * have the same row count) - see requirement 7.
 */
export const EXPECTED_MIGRATIONS = ['0001_initial', ...STEPS.map((s) => s.version)]
  .sort((a, b) => a.localeCompare(b));

/**
 * True if this database has never been through migrate() at all - the
 * schema_migrations table itself does not exist. Distinct from "exists but
 * behind": a genuinely new, empty database is a bootstrap case (see
 * bootstrapIfNewOrEnsureCompatible below), not an upgrade case, and must
 * never be confused with an existing production database that merely
 * hasn't been migrated to the latest version yet.
 */
export function isDatabaseUninitialized(conn = db) {
  return !conn.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'schema_migrations'").get();
}

/**
 * Read-only - never applies anything, never mutates schema_migrations.
 * Compares the EXACT set of applied versions against EXPECTED_MIGRATIONS,
 * in both directions: `missing` (this code expects a migration the
 * database doesn't have - the database is behind) and `unexpected` (the
 * database has a migration this code doesn't recognize - most likely an
 * older release running against a database a newer release already
 * migrated). Either direction means this code cannot be sure it
 * understands the schema shape it would be operating on, so either one is
 * treated as incompatible - never merely "probably fine."
 *
 * `conn` defaults to the shared application connection; a caller may pass
 * any other better-sqlite3 connection (e.g. a read-only handle on a staged
 * restore candidate) to ask the same question of a database that is NOT
 * the live one, without migrating it.
 */
export function checkSchemaCompatibility(conn = db) {
  if (isDatabaseUninitialized(conn)) {
    return { ok: false, reason: 'uninitialized' };
  }
  const applied = new Set(conn.prepare('SELECT version FROM schema_migrations').all().map((r) => r.version));
  const missing = EXPECTED_MIGRATIONS.filter((v) => !applied.has(v));
  if (missing.length) return { ok: false, reason: 'behind', missing };
  const expected = new Set(EXPECTED_MIGRATIONS);
  const unexpected = [...applied].filter((v) => !expected.has(v)).sort((a, b) => a.localeCompare(b));
  if (unexpected.length) return { ok: false, reason: 'ahead', unexpected };
  return { ok: true };
}

function formatIncompatibilityMessage(result) {
  if (result.reason === 'uninitialized') {
    return 'This database has not been initialized. Run "npm run db:migrate" (or the portal\'s first-time setup) before starting.';
  }
  if (result.reason === 'behind') {
    return `This database is behind what this version of the application requires (missing: ${result.missing.join(', ')}). `
      + 'Run "npm run db:migrate" before starting - the application will not start against an out-of-date schema.';
  }
  return `This database has migration(s) this version of the application does not recognize (${result.unexpected.join(', ')}). `
    + 'This usually means an older release is running against a database a newer release already migrated. '
    + 'Do not proceed without confirming compatibility.';
}

/** Thrown by ensureSchemaCompatible() - carries the same structured reason/
 * missing/unexpected fields as checkSchemaCompatibility()'s own return
 * value, for a caller that wants to inspect it programmatically, alongside
 * a clear, operator-facing message for one that doesn't. */
export class SchemaCompatibilityError extends Error {
  constructor(result) {
    super(formatIncompatibilityMessage(result));
    this.name = 'SchemaCompatibilityError';
    this.reason = result.reason;
    this.missing = result.missing;
    this.unexpected = result.unexpected;
  }
}

/**
 * The one check normal application startup and every operational utility
 * (scheduled/manual backup, reset-password) use INSTEAD of migrate().
 * Never applies anything; throws a clear SchemaCompatibilityError - never
 * partially starts, never silently proceeds - if the schema is not
 * exactly what this code expects, including the "never initialized at
 * all" case.
 */
export function ensureSchemaCompatible() {
  const result = checkSchemaCompatibility();
  if (!result.ok) throw new SchemaCompatibilityError(result);
}

/**
 * For the small set of EXPLICIT setup utilities (first-run, `npm run
 * db:seed`, `npm run db:setup-cciq`) that must also work the very first
 * time, against a database that does not exist yet at all - each is
 * documented as "safe to re-run", which has always meant "safe to re-run
 * against an existing, already-current database", never "safe to use as a
 * way to upgrade one that's behind." A brand-new, empty database is
 * bootstrapped directly to the current schema here (there is no partial
 * upgrade path to protect for something that never existed). An EXISTING
 * database - current or behind - is never silently advanced: this refuses
 * exactly like ensureSchemaCompatible() does for a behind database,
 * pointing at the same explicit `npm run db:migrate` step. Besides
 * migrate() itself (and its own CLI entry point below), this is the only
 * function permitted to call migrate().
 */
export function bootstrapIfNewOrEnsureCompatible() {
  if (isDatabaseUninitialized()) {
    migrate();
    return { bootstrapped: true };
  }
  ensureSchemaCompatible();
  return { bootstrapped: false };
}

/*
 * process.argv[1] is whatever path was typed on the command line (often
 * relative, e.g. "src/db/migrate.js" from `npm run db:migrate`), while
 * import.meta.url is always the fully-resolved file:// URL — comparing them
 * directly, as `file://${process.argv[1]}`, never matched on this project
 * (confirmed live: running this file directly silently did nothing, with no
 * error, because migrate() was simply never called). pathToFileURL()
 * resolves the relative argv path the same way Node resolved this module,
 * so the comparison actually works regardless of how the script was invoked.
 */
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    migrate();
    console.log('Schema up to date.');
  } catch (err) {
    if (err instanceof MigrationRefusedError) {
      console.error(`\nMigration ${err.version} was REFUSED. Nothing was changed.\n\n${err.diagnostic}\n`);
      process.exitCode = 1;
    } else {
      throw err;
    }
  }
}
