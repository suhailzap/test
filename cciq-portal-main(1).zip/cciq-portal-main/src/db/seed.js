import { pathToFileURL } from 'node:url';
import db, { query, queryOne, execute, transaction } from './index.js';
import { bootstrapIfNewOrEnsureCompatible } from './migrate.js';
import { ROLES, PERMISSIONS, DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions.js';
import { ensureSettings } from '../lib/settings.js';
import { ensureFridaySessions } from '../services/friday-service.js';
import { createUser, generateInitialPassword } from '../services/users.js';
import { checkPasswordPolicy } from '../lib/passwords.js';
import { canPresentGeneratedCredential } from '../lib/credential-output.js';
import { nowIso } from '../lib/dates.js';
import config from '../config/env.js';

/**
 * Seeding is idempotent: it can be re-run after an upgrade to pick up new
 * permissions without disturbing existing accounts or role customisations.
 */
export function seedRolesAndPermissions() {
  const at = nowIso();

  transaction(() => {
    for (const role of ROLES) {
      execute(
        `INSERT INTO roles (key, name, description, rank, is_system, created_at, updated_at)
         VALUES (@key, @name, @description, @rank, 1, @at, @at)
         ON CONFLICT(key) DO UPDATE SET name = excluded.name, description = excluded.description,
                                        rank = excluded.rank, updated_at = excluded.updated_at`,
        { ...role, at }
      );
    }

    for (const permission of PERMISSIONS) {
      execute(
        `INSERT INTO permissions (key, category, description)
         VALUES (@key, @category, @description)
         ON CONFLICT(key) DO UPDATE SET category = excluded.category, description = excluded.description`,
        permission
      );
    }

    const roleIds = new Map(query('SELECT id, key FROM roles').map((r) => [r.key, r.id]));
    const permissionIds = new Map(query('SELECT id, key FROM permissions').map((p) => [p.key, p.id]));

    for (const [roleKey, permissionKeys] of Object.entries(DEFAULT_ROLE_PERMISSIONS)) {
      const roleId = roleIds.get(roleKey);
      if (!roleId) continue;
      for (const permissionKey of permissionKeys) {
        const permissionId = permissionIds.get(permissionKey);
        if (!permissionId) continue;
        execute(
          `INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (@role_id, @permission_id)`,
          { role_id: roleId, permission_id: permissionId }
        );
      }
    }

    // The Super Admin role always holds every permission, including new ones.
    const superAdminId = roleIds.get('super_admin');
    if (superAdminId) {
      for (const id of permissionIds.values()) {
        execute('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [superAdminId, id]);
      }
    }
  })();
}

/**
 * Creates the first Super Admin. Credentials come from the environment, never
 * from source. With no password supplied, a strong one is generated and shown
 * once so it can be changed at first sign-in.
 *
 * Always resolves (never throws for an expected refusal) with either
 * `created: true`, or `created: false` plus a machine-readable `code` and a
 * human `reason` that never contains any password:
 *   users_exist                 - an account already exists; nothing to do (not a failure)
 *   email_missing               - BOOTSTRAP_ADMIN_EMAIL is not set
 *   no_safe_channel             - a password would have to be generated, but the caller
 *                                 did not assert an interactive channel to show it on
 *   password_generation_failed  - no candidate satisfying the policy could be generated
 *   weak_password               - the operator-supplied BOOTSTRAP_ADMIN_PASSWORD fails policy
 *   generated_password_invalid  - defensive: a generated credential failed the final policy check
 *
 * `interactiveOutput` must be true only when the caller will show a generated
 * password once, on an interactive terminal (see lib/credential-output.js).
 * It defaults to false, so no caller can accidentally generate a plaintext
 * credential it has no safe way to present.
 */
export async function seedBootstrapAdmin({ interactiveOutput = false } = {}) {
  const existing = queryOne('SELECT COUNT(*) AS n FROM users').n;
  if (existing > 0) return { created: false, code: 'users_exist', reason: 'users already exist' };

  const email = (config.bootstrap.email || '').trim().toLowerCase();
  if (!email) {
    return { created: false, code: 'email_missing', reason: 'BOOTSTRAP_ADMIN_EMAIL is not set' };
  }

  let password = config.bootstrap.password;
  let generated = false;
  if (!password) {
    // R02 (Codex/independent verification): a generated administrator
    // password may only ever be shown once, on an interactive terminal -
    // never printed to a pipe, a log, or a redirected file. This check lives
    // HERE, not in any one script, so every executable path that reaches
    // this function (npm run db:seed, first-run.mjs, anything else) is held
    // to it.
    if (!interactiveOutput) {
      return {
        created: false,
        code: 'no_safe_channel',
        reason: 'no administrator account exists yet, so a new password would have to be generated - but it can '
          + 'only be shown safely once, in a terminal window you are watching, never saved to a file or a log. '
          + 'Run this from an ordinary console window, or set BOOTSTRAP_ADMIN_PASSWORD first and run it again'
      };
    }
    // The same policy-aware generator every other account uses: sized to the
    // effective min/max, validated against the account's own email, retried
    // safely, and failing (rather than returning a violating value) when no
    // valid candidate exists for the configured policy.
    try {
      password = generateInitialPassword({ email });
    } catch (err) {
      return { created: false, code: 'password_generation_failed', reason: err.message };
    }
    generated = true;
  }

  // ONE policy check for both origins, against the actual account identity.
  // A generated credential is not exempt from it.
  const problems = checkPasswordPolicy(password, { email });
  if (problems.length) {
    return generated
      ? { created: false, code: 'generated_password_invalid', reason: `the generated administrator password failed the password policy: ${problems.join(' ')}` }
      : { created: false, code: 'weak_password', reason: `BOOTSTRAP_ADMIN_PASSWORD is too weak: ${problems.join(' ')}` };
  }

  await createUser({
    email,
    password,
    displayName: config.bootstrap.name || 'System Administrator',
    roleKeys: ['super_admin'],
    mustChangePassword: true
  });

  const account = queryOne('SELECT username FROM users WHERE email = @email', { email });
  return { created: true, email, username: account ? account.username : null, password: generated ? password : null };
}

export async function seedAll({ interactiveOutput = false } = {}) {
  // Migration execution safety (Codex/independent verification): `npm run
  // db:seed` (this function's own CLI entry point below) and first-run.mjs
  // are explicit setup utilities, so a genuinely new, empty database is
  // still bootstrapped directly here - but an EXISTING database that is
  // behind is never silently upgraded, even by an explicit setup command.
  // See bootstrapIfNewOrEnsureCompatible() in db/migrate.js.
  bootstrapIfNewOrEnsureCompatible();
  seedRolesAndPermissions();
  ensureSettings();
  const admin = await seedBootstrapAdmin({ interactiveOutput });
  const schedule = ensureFridaySessions();
  return { admin, schedule };
}

async function run() {
  const { admin, schedule } = await seedAll({ interactiveOutput: canPresentGeneratedCredential() });

  console.log('Roles, permissions and settings are in place.');
  console.log(`Friday Services scheduled: ${schedule.created} new session(s).`);

  if (admin.created) {
    console.log('\nSuper Admin account created:');
    console.log(`  Username: ${admin.username}`);
    console.log(`  Email:    ${admin.email}`);
    if (admin.password) {
      console.log(`  Password: ${admin.password}`);
      console.log('  This password is shown once. It must be changed at first sign-in.');
    } else {
      console.log('  Password: as supplied in BOOTSTRAP_ADMIN_PASSWORD (change it at first sign-in).');
    }
  } else {
    console.log(`\nNo administrator created (${admin.reason}).`);
    // "An account already exists" is the normal re-run case; anything else
    // means the administrator this setup exists to create was NOT created,
    // which must not look like success to whoever (or whatever) ran it.
    if (admin.code !== 'users_exist') process.exitCode = 1;
  }
  db.close();
}

// pathToFileURL, not `file://${argv[1]}`: on Windows the latter never equals import.meta.url
// (a drive-letter path needs file:///C:/...), so this block silently never ran.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  run().catch((err) => {
    console.error('Seeding failed:', err.message);
    process.exit(1);
  });
}
