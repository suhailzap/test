/* Reception-only behavior. Authentication remains entirely server-side. */
(function () {
  'use strict';
  var counter = document.querySelector('[data-kiosk-counter]');
  if (!counter) return;
  var value = counter.querySelector('[data-kiosk-count]');
  var note = counter.querySelector('[data-kiosk-count-note]');
  var initialSession = counter.dataset.sessionId;
  var timer, controller, running = false, stopped = false, refreshAgain = false;

  async function refresh() {
    if (stopped) return;
    if (running) { refreshAgain = true; return; }
    clearTimeout(timer);
    running = true;
    controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 8000);
    try {
      var response = await fetch('/kiosk/count', {
        headers: { Accept: 'application/json' }, cache: 'no-store',
        signal: controller.signal
      });
      if (!response.ok || !String(response.headers.get('content-type')).includes('application/json')) throw new Error('unavailable');
      var data = await response.json();
      if (!data.ok || (data.count !== null && (!Number.isInteger(data.count) || data.count < 0))) throw new Error('invalid');
      value.textContent = data.count === null ? '—' : String(data.count);
      // Only this small area changes. Never reset a scan, search or household.
      note.textContent = !data.sessionId ? 'No applicable Friday Service.'
        : String(data.sessionId) !== initialSession
          ? 'Service changed to ' + data.serviceDate + '. Finish or cancel the current selection, then reopen the kiosk.' : '';
    } catch (_) {
      if (!stopped) note.textContent = 'Count update unavailable. Retrying automatically.';
    } finally {
      clearTimeout(timeout);
      running = false;
      if (!stopped) {
        timer = setTimeout(refresh, refreshAgain ? 0 : 15000);
        refreshAgain = false;
      }
    }
  }

  document.addEventListener('cciq:checkin', refresh);
  window.addEventListener('pagehide', function () {
    stopped = true;
    clearTimeout(timer);
    if (controller) controller.abort();
  });
  window.addEventListener('pageshow', function () { stopped = false; refresh(); });

  document.querySelectorAll('form[data-kiosk-record]').forEach(function (form) {
    var submitting = false;
    var feedback = document.createElement('p');
    feedback.className = 'kiosk__record-feedback';
    feedback.setAttribute('role', 'status');
    feedback.setAttribute('aria-live', 'polite');
    form.after(feedback);
    form.addEventListener('submit', async function (event) {
      if (event.defaultPrevented) return;
      event.preventDefault();
      if (submitting) return;
      submitting = true;
      var body = new URLSearchParams(new FormData(form));
      var button = form.querySelector('button[type="submit"]');
      if (button) button.disabled = true;
      feedback.textContent = 'Recording attendance…';
      try {
        var response = await fetch(form.action, { method: 'POST',
          headers: { Accept: 'application/json' }, body: body });
        if (!response.ok || !String(response.headers.get('content-type')).includes('application/json')) throw new Error('Save could not be confirmed. Check your connection and sign-in, then retry.');
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || 'Attendance could not be confirmed.');
        var count = data.newly.length;
        var message = count ? 'Attendance recorded for ' + count + (count === 1 ? ' person' : ' people') + ': ' + data.newly.join(', ') + '.' : '';
        if (data.already.length) message += (message ? ' ' : '') + 'Already checked in: ' + data.already.join(', ') + '.';
        feedback.textContent = message || 'No attendance changes were needed.';
        refresh();
        // The review page: replace it with a clear success state and one way on. The form is gone, so a second tap or a refresh cannot record anything again;
        // the next screen is the scanner, which takes focus on arrival. (It returns there by itself after a few seconds as well.)
        var recorded = document.getElementById('kiosk-record-done');
        if (recorded && form.id !== 'checkin-family-form') {
          document.querySelectorAll('[data-review-hide]').forEach(function (el) { el.classList.add('is-hidden'); });
          feedback.textContent = '';
          document.getElementById('kiosk-record-message').textContent = message || 'No attendance changes were needed.';
          recorded.classList.remove('is-hidden');
          var next = document.getElementById('checkin-next-review');
          if (next) next.focus();
          window.setTimeout(function () { window.location.assign(recorded.getAttribute('data-next-href') || '/kiosk'); }, 8000);
        }
        var success = document.getElementById('checkin-success-view');
        if (success && form.id === 'checkin-family-form') {
          document.getElementById('checkin-family-view').classList.add('is-hidden');
          document.getElementById('checkin-success-message').textContent = feedback.textContent;
          success.classList.remove('is-hidden');
        }
      } catch (error) {
        feedback.textContent = error.message;
      } finally {
        submitting = false;
        if (button) button.disabled = false;
      }
    });
  });
})();
