/*
 * Status disclosure: selection stays local until the user applies it.
 * Reused wherever a multi-status filter appears (Members, and each of Print
 * a report's own status selectors) — each `[data-member-status-filter]` on
 * the page gets its own independent copy of this behaviour, scoped to its
 * own checkboxes, so more than one can exist on the same page at once.
 */
(function () {
  var controls = Array.from(document.querySelectorAll('[data-member-status-filter]'));
  controls.forEach(function (control) {
    var boxes = Array.from(control.querySelectorAll('input[name="status"]'));
    var summary = control.querySelector('[data-member-status-summary]');
    var clear = control.querySelector('[data-member-status-clear]');
    if (!summary || !clear) return;
    function update() {
      var labels = boxes.filter(function (box) { return box.checked; })
        .map(function (box) { return box.dataset.statusLabel; });
      summary.textContent = labels.length === 0 ? 'All statuses'
        : labels.length <= 2 ? labels.join(', ') : labels.length + ' statuses';
    }
    control.addEventListener('change', update);
    clear.hidden = false;
    clear.addEventListener('click', function () {
      boxes.forEach(function (box) { box.checked = false; });
      update();
    });
    window.addEventListener('pageshow', update);
    update();
  });
})();

/**
 * The sidebar's own vertical scroll position, remembered across page loads.
 * Deliberately separate from the main content area's scroll (which is never
 * touched here) and from the manual submenu-collapse feature below (which
 * remembers *which sections* are open, not *where the sidebar is scrolled*
 * — the two are independent state, stored independently, so neither can
 * fight the other). sessionStorage rather than localStorage: this is
 * where-you-were-in-this-visit state, not a standing preference, and it is
 * naturally cleared when the tab's session ends.
 *
 * This runs first, and as plainly as possible (no animation, no deferred
 * rAF), specifically to land before the user has a chance to see the
 * sidebar at its default position — app.js loads with `defer`, so this is
 * about as early as a CSP build without inline scripts allows.
 */
(function () {
  var KEY = 'cciq.nav.scrollTop';
  var nav = document.getElementById('sidenav');
  if (!nav) return;

  try {
    var saved = window.sessionStorage.getItem(KEY);
    if (saved !== null) {
      // Setting scrollTop past the element's actual range clamps to it
      // natively — nothing extra needed for a shorter sidebar or a shorter
      // viewport than when the position was saved.
      nav.scrollTop = parseInt(saved, 10) || 0;
    }
  } catch (err) {
    // Storage unavailable (private window, blocked site data) — the
    // sidebar simply starts at its default position.
  }

  var saveTimer = null;
  nav.addEventListener('scroll', function () {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      try {
        window.sessionStorage.setItem(KEY, String(nav.scrollTop));
      } catch (err) {
        // Nothing to persist to — the position just won't survive navigation.
      }
    }, 100);
  }, { passive: true });
})();

(function () {
  'use strict';

  // Mobile navigation drawer
  var toggle = document.querySelector('[data-drawer-toggle]');
  var scrim = document.querySelector('[data-drawer-close]');

  function setDrawer(open) {
    document.body.classList.toggle('drawer-open', open);
    if (toggle) toggle.setAttribute('aria-expanded', String(open));
    if (scrim) scrim.hidden = !open;
  }

  if (toggle) {
    toggle.addEventListener('click', function () {
      setDrawer(!document.body.classList.contains('drawer-open'));
    });
  }
  if (scrim) scrim.addEventListener('click', function () { setDrawer(false); });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') setDrawer(false);
  });

  /*
   * Narrow-screen search: below the header's icon-only breakpoint (see
   * .topbar__search-toggle in cciq.css), the field itself only exists as a
   * full-width overlay while actively in use, so it never has to compete
   * with the hamburger, brand, bell and Sign out for the same row.
   */
  (function () {
    var topbar = document.querySelector('.topbar');
    var searchToggle = document.querySelector('[data-search-toggle]');
    var searchClose = document.querySelector('[data-search-close]');
    var searchInput = document.getElementById('topbar-search');
    if (!topbar || !searchToggle || !searchInput) return;

    function openSearch() {
      topbar.classList.add('is-searching');
      searchToggle.setAttribute('aria-expanded', 'true');
      searchInput.focus();
    }

    function closeSearch() {
      topbar.classList.remove('is-searching');
      searchToggle.setAttribute('aria-expanded', 'false');
      searchToggle.focus();
    }

    searchToggle.addEventListener('click', openSearch);
    if (searchClose) searchClose.addEventListener('click', closeSearch);

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && topbar.classList.contains('is-searching')) closeSearch();
    });
  })();

  /*
   * Manual submenu collapse. A submenu is expanded by default whenever its
   * parent section is the one the user is in (see buildNavigation in
   * navigation.js) — this only lets someone collapse it back, remembered as a
   * personal, per-browser convenience, never sent to the server.
   */
  (function () {
    var STORAGE_KEY = 'cciq.nav.collapsed';
    var collapsed;
    try {
      collapsed = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '[]');
    } catch (err) {
      collapsed = [];
    }

    document.querySelectorAll('[data-nav-toggle]').forEach(function (btn) {
      var key = btn.getAttribute('data-nav-toggle');
      var sub = document.querySelector('[data-nav-sub="' + CSS.escape(key) + '"]');
      if (!sub) return;

      var isCollapsed = collapsed.indexOf(key) !== -1;
      sub.hidden = isCollapsed;
      btn.setAttribute('aria-expanded', String(!isCollapsed));

      btn.addEventListener('click', function () {
        var nowCollapsed = !sub.hidden;
        sub.hidden = nowCollapsed;
        btn.setAttribute('aria-expanded', String(!nowCollapsed));

        var index = collapsed.indexOf(key);
        if (nowCollapsed && index === -1) collapsed.push(key);
        if (!nowCollapsed && index !== -1) collapsed.splice(index, 1);
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(collapsed));
        } catch (err) {
          // A private window or blocked storage just means this is not
          // remembered next time — the submenu itself still works.
        }
      });
    });
  })();

  // Confirmation before destructive or irreversible actions
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!window.confirm(form.getAttribute('data-confirm'))) event.preventDefault();
    });
  });

  // Warn before leaving a form with unsaved edits
  document.querySelectorAll('form[data-guard]').forEach(function (form) {
    var dirty = false;
    form.addEventListener('input', function () { dirty = true; });
    form.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (event) {
      if (!dirty) return undefined;
      event.preventDefault();
      event.returnValue = '';
      return '';
    });
  });

  // Filter forms submit on change so results stay one tap away on mobile
  document.querySelectorAll('[data-autosubmit]').forEach(function (control) {
    control.addEventListener('change', function () {
      if (control.form) control.form.submit();
    });
  });

  // Prevent duplicate submissions, and always acknowledge the click.
  document.querySelectorAll('form').forEach(function (form) {
    var submitting = false;
    var lockedButtons = [];
    window.addEventListener('pageshow', function () {
      submitting = false;
      lockedButtons.forEach(function (saved) { saved.button.disabled = saved.disabled; saved.button.textContent = saved.label; });
      lockedButtons = [];
    });
    form.addEventListener('submit', function (event) {
      if (event.defaultPrevented) return;
      if (submitting) { event.preventDefault(); return; }
      var button = event.submitter || form.querySelector('button[type="submit"]') ||
        document.activeElement;
      if (!button || button.tagName !== 'BUTTON' || form.hasAttribute('data-no-lock')) return;

      /*
       * A form opening a new tab never navigates this page, so locking its
       * button would strand it. Those are acknowledged and released instead.
       */
      if (form.getAttribute('target') === '_blank') {
        var original = button.textContent;
        button.disabled = true;
        button.textContent = button.getAttribute('data-busy') || 'Preparing…';
        toast('Your report is being prepared and will open in a new tab.');
        window.setTimeout(function () {
          button.disabled = false;
          button.textContent = original;
        }, 2500);
        return;
      }

      submitting = true;
      window.setTimeout(function () {
        // Later validators/confirmation handlers may cancel this same event.
        if (event.defaultPrevented) { submitting = false; return; }
        form.querySelectorAll('button[type="submit"]').forEach(function (submitButton) {
          lockedButtons.push({ button: submitButton, disabled: submitButton.disabled, label: submitButton.textContent });
          submitButton.disabled = true;
        });
        button.textContent = button.getAttribute('data-busy') || 'Working…';
      }, 0);
    });
  });

  /**
   * Checks a form before it is sent, so a mistake is pointed out immediately
   * rather than after a round trip. The server checks everything again; this
   * only saves the person a wasted submit.
   */
  document.querySelectorAll('form[novalidate]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      var invalid = [];
      form.querySelectorAll('input, select, textarea').forEach(function (field) {
        if (field.type === 'hidden' || field.disabled) return;
        clearFieldError(field);
        if (!field.checkValidity()) invalid.push(field);
      });

      if (invalid.length === 0) {
        removeSummary(form);
        return;
      }

      event.preventDefault();
      invalid.forEach(function (field) { showFieldError(field, field.validationMessage); });
      showSummary(form, invalid);
      invalid[0].focus();
      invalid[0].scrollIntoView({ block: 'center', behavior: 'smooth' });
    });

    // Clear a message as soon as the person puts it right.
    form.addEventListener('input', function (event) {
      if (event.target.checkValidity && event.target.checkValidity()) clearFieldError(event.target);
    });
  });

  function fieldWrapper(field) {
    return field.closest('.field') || field.parentElement;
  }

  function showFieldError(field, message) {
    var wrapper = fieldWrapper(field);
    if (!wrapper) return;
    field.setAttribute('aria-invalid', 'true');
    var existing = wrapper.querySelector('.field__error[data-live]');
    if (!existing) {
      existing = document.createElement('span');
      existing.className = 'field__error';
      existing.setAttribute('data-live', 'true');
      wrapper.appendChild(existing);
    }
    existing.textContent = message;
    if (field.id) {
      existing.id = field.id + '-live-error';
      var describedBy = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
      if (describedBy.indexOf(existing.id) === -1) describedBy.push(existing.id);
      field.setAttribute('aria-describedby', describedBy.join(' '));
    }
  }

  function clearFieldError(field) {
    var wrapper = fieldWrapper(field);
    if (!wrapper) return;
    field.removeAttribute('aria-invalid');
    var existing = wrapper.querySelector('.field__error[data-live]');
    if (existing) {
      var remaining = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) { return id && id !== existing.id; });
      if (remaining.length) field.setAttribute('aria-describedby', remaining.join(' '));
      else field.removeAttribute('aria-describedby');
      existing.remove();
    }
  }

  function removeSummary(form) {
    var existing = form.querySelector('.alert[data-live]');
    if (existing) existing.remove();
  }

  function showSummary(form, invalid) {
    removeSummary(form);
    var alert = document.createElement('div');
    alert.className = 'alert alert--error';
    alert.setAttribute('role', 'alert');
    alert.setAttribute('data-live', 'true');
    var count = invalid.length;
    var content = document.createElement('div');
    content.innerHTML = '<p>' + count + (count === 1
      ? ' field needs attention before this can be saved.'
      : ' fields need attention before this can be saved.') + '</p>';
    var list = document.createElement('ul');
    invalid.forEach(function (field) {
      var item = document.createElement('li');
      var link = document.createElement('a');
      var label = field.labels && field.labels[0] ? field.labels[0].textContent.trim() : field.name;
      link.textContent = label + ': ' + field.validationMessage;
      link.href = '#' + field.id;
      link.addEventListener('click', function (event) { event.preventDefault(); field.focus(); field.scrollIntoView({ block: 'center' }); });
      item.appendChild(link); list.appendChild(item);
    });
    content.appendChild(list);
    alert.appendChild(content);
    form.insertBefore(alert, form.firstChild);
  }

  /** A brief message that does not interrupt what the person is doing. */
  function toast(message) {
    var host = document.querySelector('.toast-host');
    if (!host) {
      host = document.createElement('div');
      host.className = 'toast-host';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }

    var item = document.createElement('div');
    item.className = 'toast';
    item.textContent = message;
    host.appendChild(item);

    window.setTimeout(function () { item.classList.add('is-leaving'); }, 3200);
    window.setTimeout(function () { item.remove(); }, 3700);
  }

  window.cciqToast = toast;
}());

/*
 * A section-tab strip (member profile, cell group) scrolls horizontally
 * rather than wrapping or overflowing the page on a narrow screen — but
 * that means the active tab can load already scrolled out of view, with
 * nothing on screen to show which section is actually showing. This brings
 * it into view without moving the page itself vertically.
 */
// (The strip is scrolled directly, NOT with scrollIntoView(): scrollIntoView moves the browser's "where Tab continues from" point to the active
// tab, so a keyboard user's first Tab skipped the skip link, the header and the whole menu and landed in the middle of the page.)
document.querySelectorAll('.tabs .is-active').forEach(function (tab) {
  var strip = tab.closest('.tabs');
  if (!strip || strip.scrollWidth <= strip.clientWidth) return;
  var stripBox = strip.getBoundingClientRect();
  var tabBox = tab.getBoundingClientRect();
  strip.scrollLeft += (tabBox.left - stripBox.left) - (strip.clientWidth - tabBox.width) / 2;
});

// Bulk marking on the attendance sheet. Without JavaScript every row still
// works on its own, so this only saves taps.
document.querySelectorAll('[data-mark-all]').forEach(function (button) {
  button.addEventListener('click', function () {
    var value = button.getAttribute('data-mark-all');
    var form = button.closest('form') || document;
    form.querySelectorAll('fieldset.choices:not([disabled])').forEach(function (group) {
      var target = group.querySelector('input[value="' + value + '"]');
      if (target) target.checked = true;
    });
  });
});

/* Photo lightbox: opens on click, closes on Escape, restores focus. */
(function () {
  var links = document.querySelectorAll('[data-lightbox]');
  if (links.length === 0) return;

  var box = document.createElement('div');
  box.className = 'lightbox';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-modal', 'true');
  box.setAttribute('aria-label', 'Photo');
  box.hidden = true;

  var close = document.createElement('button');
  close.type = 'button';
  close.className = 'lightbox__close';
  close.setAttribute('aria-label', 'Close photo');
  close.textContent = '\u2715';

  var image = document.createElement('img');
  image.alt = '';

  var caption = document.createElement('p');
  caption.className = 'lightbox__caption';

  box.appendChild(close);
  box.appendChild(image);
  box.appendChild(caption);
  document.body.appendChild(box);

  var opener = null;

  function open(href, text, alt) {
    image.src = href;
    image.alt = alt || text || 'Photo';
    caption.textContent = text || '';
    box.hidden = false;
    close.focus();
  }

  function hide() {
    box.hidden = true;
    image.removeAttribute('src');
    if (opener) opener.focus();
  }

  links.forEach(function (link) {
    link.addEventListener('click', function (event) {
      event.preventDefault();
      opener = link;
      var img = link.querySelector('img');
      open(link.getAttribute('href'), link.getAttribute('data-caption'), img ? img.alt : '');
    });
  });

  close.addEventListener('click', hide);
  box.addEventListener('click', function (event) { if (event.target === box) hide(); });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && !box.hidden) hide();
  });
})();

/* Fields that only apply after an earlier answer stay hidden until they do. */
(function () {
  var triggers = document.querySelectorAll('[data-reveal]');
  if (triggers.length === 0) return;

  triggers.forEach(function (trigger) {
    var name = trigger.getAttribute('data-reveal');
    var wanted = trigger.getAttribute('data-reveal-value');
    var targets = document.querySelectorAll('[data-reveal-target="' + name + '"]');

    function apply() {
      var shown = wanted === 'checked' ? trigger.checked : trigger.value === wanted;
      targets.forEach(function (target) { target.classList.toggle('is-hidden', !shown); });
    }

    trigger.addEventListener('change', apply);
    apply();
  });
})();

/* A relative is either a CCIQ member (picker) or a typed name - only the chosen one is shown. */
(function () {
  document.querySelectorAll('[data-relative]').forEach(function (box) {
    var radios = box.querySelectorAll('[data-relative-mode]');
    var panes = box.querySelectorAll('[data-relative-pane]');
    function apply() {
      var mode = 'manual';
      radios.forEach(function (r) { if (r.checked) mode = r.value; });
      panes.forEach(function (p) { p.classList.toggle('is-hidden', p.getAttribute('data-relative-pane') !== mode); });
    }
    radios.forEach(function (r) { r.addEventListener('change', apply); });
    apply();
  });
})();

/* Shows the leader of the chosen cell group, so it need not be looked up. */
(function () {
  var select = document.querySelector('[data-cell-group]');
  var note = document.querySelector('[data-cell-leader]');
  if (!select || !note) return;

  var original = note.textContent;
  function show() {
    var option = select.options[select.selectedIndex];
    var leader = option ? option.getAttribute('data-leader') : null;
    note.textContent = select.value && leader ? 'Cell group leader: ' + leader : original;
  }
  select.addEventListener('change', show);
  show();
})();

/**
 * The upload box: drag and drop, a preview of what was chosen, and gentle
 * suggestions taken from the file name that the person can change.
 */
(function () {
  var zone = document.querySelector('[data-dropzone]');
  if (!zone) return;

  var input = zone.querySelector('[data-file-input]');
  var preview = zone.querySelector('[data-preview]');
  var image = zone.querySelector('[data-preview-image]');
  var nameEl = zone.querySelector('[data-preview-name]');
  var sizeEl = zone.querySelector('[data-preview-size]');
  var titleField = document.querySelector('[data-title-field]');
  var categoryField = document.querySelector('[data-category-field]');
  var tagsField = document.querySelector('[data-tags-field]');

  function readableSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return Math.round(bytes / 1024) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  function suggest(filename) {
    var token = document.querySelector('input[name="_csrf"]');
    if (!token || (titleField && titleField.value.trim())) return;

    fetch('/documents/suggest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token.value },
      body: JSON.stringify({ filename: filename })
    }).then(function (res) {
      return res.ok ? res.json() : null;
    }).then(function (data) {
      if (!data) return;
      if (titleField && !titleField.value.trim() && data.title) titleField.value = data.title;
      if (categoryField && !categoryField.value && data.categoryId) categoryField.value = String(data.categoryId);
      if (tagsField && !tagsField.value.trim() && data.tags && data.tags.length) {
        tagsField.value = data.tags.join(', ');
      }
    }).catch(function () { /* a failed suggestion must never block the upload */ });
  }

  function show(file) {
    if (!file) return;
    nameEl.textContent = file.name;
    sizeEl.textContent = readableSize(file.size);
    preview.hidden = false;

    if (file.type.indexOf('image/') === 0) {
      image.src = URL.createObjectURL(file);
      image.hidden = false;
    } else {
      image.hidden = true;
    }
    suggest(file.name);
  }

  input.addEventListener('change', function () { show(input.files[0]); });

  ['dragenter', 'dragover'].forEach(function (name) {
    zone.addEventListener(name, function (event) {
      event.preventDefault();
      zone.classList.add('is-over');
    });
  });

  ['dragleave', 'drop'].forEach(function (name) {
    zone.addEventListener(name, function (event) {
      event.preventDefault();
      zone.classList.remove('is-over');
    });
  });

  zone.addEventListener('drop', function (event) {
    if (!event.dataTransfer || !event.dataTransfer.files.length) return;
    input.files = event.dataTransfer.files;
    show(input.files[0]);
  });

  /*
   * The form uses novalidate so this page can show its own error styling
   * instead of the browser's default tooltip — but that means nothing stops
   * a submission with no file chosen from reaching the server at all unless
   * something checks first. This catches it immediately, in place, with no
   * page reload, rather than sending the person on a round trip only to land
   * back on the same empty form with a banner at the top.
   */
  var form = zone.closest('form');
  if (form) {
    form.addEventListener('submit', function (event) {
      if (input.files && input.files.length) return;
      event.preventDefault();
      zone.classList.add('has-error');
      var message = zone.querySelector('[data-dropzone-error]');
      if (!message) {
        message = document.createElement('p');
        message.className = 'field-error';
        message.setAttribute('data-dropzone-error', '');
        message.textContent = 'Choose a file before uploading.';
        zone.appendChild(message);
      }
      input.focus();
    });
    input.addEventListener('change', function () {
      zone.classList.remove('has-error');
      var message = zone.querySelector('[data-dropzone-error]');
      if (message) message.remove();
    });
  }
})();

/**
 * The "recently attending only" day count only means anything when that mode
 * is actually chosen — disabled (not merely visually dimmed) so a stray value
 * left over from switching modes is never submitted as if it still applied.
 */
(function () {
  var wrap = document.querySelector('[data-recent-engagement]');
  if (!wrap) return;
  var recentRadio = wrap.querySelector('[data-recent-mode-recent]');
  var daysInput = wrap.querySelector('[data-recent-days]');
  if (!recentRadio || !daysInput) return;

  function apply() {
    daysInput.disabled = !recentRadio.checked;
  }
  wrap.querySelectorAll('input[type="radio"]').forEach(function (radio) {
    radio.addEventListener('change', apply);
  });
  apply();
})();

/**
 * Destination country and departure notes only apply to a genuine
 * relocation — Returned to home country, or Migrated to another country.
 * Every other status, Temporarily Away included (a short-term absence, not
 * a move), hides both fields. This only controls what is shown; the server
 * independently ignores any submitted value for either field unless the
 * status being saved is actually one of these two (see changeStatus() in
 * services/members.js), so this being client-side JS is not itself a
 * trust boundary.
 */
(function () {
  var select = document.querySelector('form[action$="/status"] select[name="status"]');
  if (!select) return;

  var country = document.querySelector('[data-departure-country]');
  var notes = document.querySelector('[data-departure-notes]');
  var note = document.querySelector('[data-departure-note]');
  var relocated = ['returned_home', 'migrated'];

  function apply() {
    var value = select.value;
    var shown = relocated.indexOf(value) !== -1;
    if (country) {
      country.hidden = !shown;
      var input = country.querySelector('input');
      if (input) input.required = shown;
    }
    if (notes) notes.hidden = !shown;
    if (note) {
      note.hidden = ['returned_home', 'migrated', 'transferred', 'temporarily_away'].indexOf(value) === -1;
    }
  }

  select.addEventListener('change', apply);
  apply();
})();

/**
 * The Roles section on an existing user's account page: read-only by
 * default (so the account's current role(s) are never mistaken for "no
 * role"), with an explicit "Update roles" step before the checkboxes
 * become interactive. Disabled checked roles have hidden mirrors so saving
 * other account fields preserves them. Mirrors are rebuilt when editing
 * starts/cancels, including roles the actor cannot change. Server-side
 * authorization, the Super Admin grant/revoke rule and the last-admin
 * safeguard are unaffected by any of this — see routes/admin-users.js.
 */
(function () {
  var fieldgroup = document.querySelector('[data-roles-fieldgroup]');
  var editBtn = document.querySelector('[data-roles-edit]');
  if (!fieldgroup || !editBtn) return;

  var cancelBtn = document.querySelector('[data-roles-cancel]');
  var viewActions = document.querySelector('[data-roles-view-actions]');
  var editActions = document.querySelector('[data-roles-edit-actions]');
  var checkboxes = Array.prototype.slice.call(fieldgroup.querySelectorAll('input[type="checkbox"]'));
  var originalChecked = checkboxes.map(function (cb) { return cb.hasAttribute('data-role-original'); });
  var permissionDisabled = checkboxes.map(function (cb) { return cb.disabled; });

  function preserveDisabledRoles() {
    fieldgroup.querySelectorAll('[data-role-preserved]').forEach(function (input) { input.remove(); });
    checkboxes.forEach(function (cb) {
      if (!cb.disabled || !cb.checked) return;
      var mirror = document.createElement('input');
      mirror.type = 'hidden'; mirror.name = cb.name; mirror.value = cb.value;
      mirror.setAttribute('data-role-preserved', ''); fieldgroup.appendChild(mirror);
    });
  }

  function lock() {
    fieldgroup.classList.add('is-locked');
    checkboxes.forEach(function (cb) {
      cb.disabled = true;
      cb.setAttribute('tabindex', '-1');
      cb.setAttribute('aria-disabled', 'true');
    });
    preserveDisabledRoles();
    if (viewActions) viewActions.hidden = false;
    if (editActions) editActions.hidden = true;
  }

  function unlock() {
    fieldgroup.classList.remove('is-locked');
    checkboxes.forEach(function (cb, i) {
      cb.disabled = permissionDisabled[i];
      cb.removeAttribute('tabindex');
      cb.removeAttribute('aria-disabled');
    });
    preserveDisabledRoles();
    if (viewActions) viewActions.hidden = true;
    if (editActions) editActions.hidden = false;
  }

  lock();
  editBtn.addEventListener('click', unlock);
  if (cancelBtn) {
    cancelBtn.addEventListener('click', function () {
      checkboxes.forEach(function (cb, i) { cb.checked = originalChecked[i]; });
      lock();
    });
  }
})();

// "Close this tab" / "Cancel" on the First Timer registration tab. Browsers only let a page close a tab that was opened from another page, so
// the attempt is made and, if the tab is still here a moment later, the page says so (or, for a link, follows it) instead of doing nothing.
document.querySelectorAll('[data-close-tab]').forEach(function (control) {
  control.addEventListener('click', function (event) {
    event.preventDefault();
    window.close();
    window.setTimeout(function () {
      var hint = document.getElementById('ft-close-hint');
      if (hint) hint.classList.remove('is-hidden');
      else if (control.getAttribute('href')) window.location.href = control.getAttribute('href');
    }, 300);
  });
});

// "Who is inviting people": every inviter's invitee list is open when scripting is off. With scripting, it starts folded away and the arrow
// beside the name opens it.
document.querySelectorAll('[data-inviter-toggle]').forEach(function (toggle) {
  var detail = document.getElementById(toggle.getAttribute('aria-controls'));
  if (!detail) return;
  toggle.hidden = false;
  detail.hidden = true;
  toggle.setAttribute('aria-expanded', 'false');
  toggle.addEventListener('click', function () {
    var open = detail.hidden;
    detail.hidden = !open;
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
});

// A form the server refused shows its error summary (partials/error-summary.ejs): it takes focus on load, so a keyboard or screen-reader
// user lands on it and an error further down the page is never missed.
(function () {
  var summary = document.querySelector('[data-error-summary]');
  if (!summary) return;
  summary.focus();
  summary.scrollIntoView({ block: 'start' });
})();

// A summary link goes to its field: by the id it names, or (a field whose control has a different id, or a picker's hidden value) by the
// field's name. The page and the drawer both use it.
document.addEventListener('click', function (event) {
  var link = event.target.closest && event.target.closest('[data-error-summary] a[data-field]');
  if (!link) return;
  var scope = link.closest('.quick') || document.querySelector('main') || document;
  var target = document.getElementById((link.getAttribute('href') || '').slice(1));
  if (!target) {
    var named = scope.querySelector('[name="' + link.getAttribute('data-field') + '"]');
    target = named && named.type === 'hidden' && named.closest('[data-member-picker]') ? named.closest('[data-member-picker]').querySelector('[data-picker-input]') : named;
  }
  if (!target || !target.focus) return;
  event.preventDefault();
  target.focus();
  target.scrollIntoView({ block: 'center' });
});

// Server-side account validation returns a new page: focus its first error.
(function () {
  var form = document.querySelector('[data-user-account-form]');
  if (!form) return;
  var invalid = form.querySelector('[aria-invalid="true"]:not(:disabled)');
  if (invalid) { invalid.focus(); invalid.scrollIntoView({ block: 'center' }); }
  else if (form.querySelector('#roles-error')) form.querySelector('[data-roles-edit]')?.focus();
})();

/**
 * Opens a member's profile beside the attendance sheet instead of navigating
 * away, so the register, its filters and the reader's place in the list are
 * all still there when the profile closes. Without JavaScript the same links
 * simply open the full member page.
 */
(function () {
  var drawer = document.querySelector('[data-quick-drawer]');
  if (!drawer) return;

  var panel = drawer.querySelector('.quick-drawer__panel');
  var body = drawer.querySelector('[data-quick-body]');
  var lastFocused = null;

  function open() {
    if (!drawer.hidden) return;
    lastFocused = document.activeElement;
    drawer.hidden = false;
    document.body.style.overflow = 'hidden';
    panel.focus();
  }

  function close() {
    if (drawer.hidden) return;
    drawer.hidden = true;
    document.body.style.overflow = '';
    body.innerHTML = '';
    if (lastFocused && lastFocused.focus) lastFocused.focus();
  }

  function load(url, options) {
    body.setAttribute('aria-busy', 'true');
    return fetch(url, Object.assign({ headers: { 'X-Requested-With': 'fetch' } }, options || {}))
      .then(function (res) { return res.text().then(function (html) { return { ok: res.ok, html: html }; }); })
      .then(function (result) {
        body.innerHTML = result.html;
        body.removeAttribute('aria-busy');
        syncQuickCountry();
        var focusable = body.querySelector('input, select, button, a[href]');
        if (focusable && result.ok === false) focusable.focus();
      })
      .catch(function () {
        body.removeAttribute('aria-busy');
        body.innerHTML = '<p class="quick__note">That profile could not be opened. '
          + 'Try the full member page instead.</p>';
      });
  }

  var titleEl = drawer.querySelector('[data-quick-title]');
  var contextEl = drawer.querySelector('[data-quick-context]');

  function label(trigger) {
    if (titleEl) titleEl.textContent = trigger.getAttribute('data-quick-title') || 'Details';
    if (contextEl) {
      var context = trigger.getAttribute('data-quick-context');
      contextEl.textContent = context || '';
      contextEl.hidden = !context;
    }
  }

  document.addEventListener('click', function (event) {
    var trigger = event.target.closest('[data-quick-open]');
    if (trigger) {
      // A modifier click still opens the full page in a new tab.
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return;
      event.preventDefault();
      label(trigger);
      open();
      body.innerHTML = '<p class="quick__note">Loading…</p>';
      load(trigger.getAttribute('data-quick-open'));
      return;
    }

    if (event.target.closest('[data-quick-close]')) {
      event.preventDefault();
      close();
      return;
    }

    var edit = event.target.closest('[data-quick-edit]');
    if (edit && drawer.contains(edit)) {
      event.preventDefault();
      load(edit.getAttribute('data-quick-edit'));
      return;
    }

    var cancel = event.target.closest('[data-quick-cancel]');
    if (cancel && drawer.contains(cancel)) {
      event.preventDefault();
      load(cancel.getAttribute('data-quick-cancel'));
    }
  });

  // Saving happens in place: the server validates and returns the fragment.
  drawer.addEventListener('submit', function (event) {
    var form = event.target.closest('[data-quick-form]');
    if (!form) return;
    event.preventDefault();

    var button = form.querySelector('button[type="submit"]');
    if (button) {
      button.disabled = true;
      button.textContent = button.getAttribute('data-busy') || 'Saving…';
    }

    load(form.getAttribute('action'), { method: 'POST', body: new FormData(form) });
  });

  drawer.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') close();
  });

  // The destination country belongs only to the statuses that need it —
  // matches must stay identical to the full profile's equivalent field
  // (see the departure-country IIFE below) so both forms behave the same
  // way for the same two statuses.
  function syncQuickCountry() {
    var select = drawer.querySelector('[data-quick-status]');
    var country = drawer.querySelector('[data-quick-country]');
    if (!select || !country) return;
    country.hidden = ['returned_home', 'migrated'].indexOf(select.value) === -1;
  }

  drawer.addEventListener('change', function (event) {
    if (event.target.closest('[data-quick-status]')) syncQuickCountry();
  });
})();



/**
 * On the Giving Board a slip that has been taken shows who took it. A mouse
 * hovers; a finger taps. This makes tapping work and closes the last one when
 * another is opened.
 */
(function () {
  var wall = document.querySelector('.board-wall__months');
  if (!wall) return;

  var open = null;

  // The card of a slip that has focus stays up for a keyboard user only. After a mouse click the slip keeps focus, and its card must not stay on screen covering the slips beside it.
  document.addEventListener('keydown', function () { wall.classList.add('is-keyboard'); }, true);
  ['pointerdown', 'mousemove'].forEach(function (name) { document.addEventListener(name, function () { wall.classList.remove('is-keyboard'); }, true); });

  function close() {
    if (open) { open.classList.remove('is-open'); open.classList.add('is-dismissed'); }
    open = null;
  }

  // A card closed with Escape or Close stays closed while focus is still on its date; leaving the date and its card makes it available again.
  wall.addEventListener('focusout', function (event) {
    var stub = event.target.closest('.stub');
    if (stub && !(event.relatedTarget && stub.contains(event.relatedTarget))) stub.classList.remove('is-dismissed');
  });

  function setExpanded(stub, value) {
    var control = stub && stub.querySelector('[aria-controls]');
    if (control) control.setAttribute('aria-expanded', value ? 'true' : 'false');
  }

  wall.addEventListener('click', function (event) {
    if (event.target.closest('[data-stub-close]')) {
      var openStub = open;
      close();
      setExpanded(openStub, false);
      var back = openStub && openStub.querySelector('button.stub__paper, button.stub__reveal');
      if (back) back.focus();
      return;
    }
    // A day that has been taken shows its details on a tap, whether it has been
    // paid, part paid or not paid at all. A slip that leads somewhere — a free
    // day, or a claim an administrator may open — is left to follow its link.
    // Only a plain button is intercepted for the tooltip. A day an administrator
    // may open is a real link and is left to navigate normally.
    var target = event.target.closest('.stub--gone button.stub__reveal, .stub--taken button.stub__paper');
    if (!target) return;
    event.preventDefault();

    var stub = target.closest('.stub');
    if (stub === open) { close(); setExpanded(stub, false); return; }
    var previous = open;
    close();
    setExpanded(previous, false);
    stub.classList.remove('is-dismissed');
    stub.classList.add('is-open');
    setExpanded(stub, true);
    open = stub;
  });

  document.addEventListener('click', function (event) {
    if (open && !event.target.closest('.stub--gone, .stub--taken')) close();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') { var was = open; close(); setExpanded(was, false); }
  });
})();

/**
 * Receipt fields only make sense for a financial document category. Whether
 * to show them is decided by the category itself, marked by an administrator
 * under Document categories, not guessed from the title or the file.
 */
(function () {
  var select = document.querySelector('[data-financial-toggle]');
  var section = document.querySelector('[data-financial-section]');
  if (!select || !section) return;

  function apply() {
    var option = select.options[select.selectedIndex];
    var financial = option && option.getAttribute('data-financial') === '1';
    section.hidden = !financial;
  }

  select.addEventListener('change', apply);
  apply();
})();

/**
 * "Who can view this?" on the document form: a compact summary that opens a short checklist. "Everyone allowed by this category" and the individual roles are
 * mutually exclusive (ticking one clears the other, and with nothing chosen it is ticked again), and only the roles the chosen CATEGORY can reach are offered. The
 * server holds the same rules; this only keeps the form from offering a contradiction.
 */
(function () {
  var picker = document.querySelector('[data-audience-picker]');
  if (!picker) return;
  var select = document.querySelector('[data-category-field]');
  var map = {};
  try { map = JSON.parse(picker.getAttribute('data-category-roles') || '{}'); } catch (e) { map = {}; }
  var everyone = picker.querySelector('[data-audience-all]');
  var labels = Array.prototype.slice.call(picker.querySelectorAll('[data-audience-role]'));
  var summary = picker.querySelector('[data-audience-summary]');
  var EVERYONE = 'Everyone allowed by this category';
  function box(label) { return label.querySelector('input'); }

  function render() {
    var allowed = select && select.value && map[select.value] ? map[select.value] : null;
    labels.forEach(function (label) {
      var offered = !allowed || allowed.indexOf(label.getAttribute('data-audience-role')) !== -1;
      label.hidden = !offered;
      if (!offered) box(label).checked = false;
    });
    var chosen = labels.filter(function (l) { return !l.hidden && box(l).checked; });
    if (everyone.checked || chosen.length === 0) {
      everyone.checked = true;
      labels.forEach(function (l) { box(l).checked = false; });
      summary.textContent = EVERYONE;
    } else {
      summary.textContent = chosen.map(function (l) { return l.textContent.trim(); }).join(', ');
    }
  }

  everyone.addEventListener('change', render);
  labels.forEach(function (label) {
    box(label).addEventListener('change', function () { if (box(label).checked) everyone.checked = false; render(); });
  });
  if (select) select.addEventListener('change', render);
  render();
})();

/**
 * The attendance roster: select a subset of members by checkbox and mark
 * them present or absent in one action, and sort the sheet by any column.
 * This sits alongside the existing per-row buttons and "mark all" controls
 * rather than replacing them — Excused and Visitor still need a single row
 * at a time, and this is for the common case of a mostly-present or
 * mostly-absent group.
 */
(function () {
  var table = document.querySelector('[data-sortable-roster]');
  if (!table) return;

  var selectAll = document.querySelector('[data-select-all-visible]');
  var countLabel = document.querySelector('[data-roster-count]');
  var bulkButtons = document.querySelectorAll('[data-mark-selected]');

  function visibleRows() {
    return Array.prototype.filter.call(
      table.querySelectorAll('tr[data-roster-row]'),
      function (row) { return row.style.display !== 'none'; }
    );
  }

  function selectedRows() {
    return visibleRows().filter(function (row) {
      var box = row.querySelector('[data-select-row]');
      return box && box.checked;
    });
  }

  function refreshBulkState() {
    var n = selectedRows().length;
    if (countLabel) countLabel.textContent = n + ' selected';
    bulkButtons.forEach(function (button) { button.disabled = n === 0; });
  }

  table.addEventListener('change', function (event) {
    if (event.target.matches('[data-select-row]')) refreshBulkState();
    // The status shown by the filter below follows what the person has
    // actually marked, not just what the sheet loaded with.
    if (event.target.matches('fieldset.choices input')) {
      var row = event.target.closest('tr[data-roster-row]');
      if (row) row.setAttribute('data-status', event.target.value || 'not_recorded');
    }
  });

  var statusFilter = document.querySelector('[data-status-filter]');
  if (statusFilter) {
    statusFilter.addEventListener('change', function () {
      var want = statusFilter.value;
      table.querySelectorAll('tr[data-roster-row]').forEach(function (row) {
        row.style.display = (!want || row.getAttribute('data-status') === want) ? '' : 'none';
      });
      if (selectAll) selectAll.checked = false;
      refreshBulkState();
    });
  }

  if (selectAll) {
    selectAll.addEventListener('change', function () {
      visibleRows().forEach(function (row) {
        var box = row.querySelector('[data-select-row]');
        if (box) box.checked = selectAll.checked;
      });
      refreshBulkState();
    });
  }

  bulkButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      var value = button.getAttribute('data-mark-selected');
      var rows = selectedRows();
      if (rows.length === 0) return;

      if (rows.length > 10) {
        var verb = value === 'present' ? 'present' : 'absent';
        if (!window.confirm('Mark ' + rows.length + ' members as ' + verb + '?')) return;
      }

      rows.forEach(function (row) {
        var target = row.querySelector('fieldset.choices input[value="' + value + '"]');
        if (target) target.checked = true;
      });
    });
  });

  /* Sorting: reorders the actual rows, which is safe here because every
     input's name already carries the member's id, not its position. */
  var sortState = { key: null, dir: 1 };
  var collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

  table.querySelectorAll('[data-sort-key]').forEach(function (header) {
    header.addEventListener('click', function () {
      var key = header.getAttribute('data-sort-key');
      var dir = sortState.key === key ? sortState.dir * -1 : 1;
      sortState = { key: key, dir: dir };

      table.querySelectorAll('[data-sort-key]').forEach(function (h) {
        h.classList.toggle('is-active', h === header);
        h.setAttribute('data-arrow', dir === 1 ? ' \u2191' : ' \u2193');
      });

      var tbody = table.querySelector('tbody');
      var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr[data-roster-row]'));
      var attr = { member: 'data-member', member_id: 'data-member-id', cell_group: 'data-cell-group', status: 'data-status' }[key];

      rows.sort(function (a, b) {
        return dir * collator.compare(a.getAttribute(attr) || '', b.getAttribute(attr) || '');
      });
      rows.forEach(function (row) { tbody.appendChild(row); });
    });
  });
})();

/**
 * The campaign builder: fields that only make sense for a Giving Board
 * (amounts per date, the board picture, how claims are shown) hide
 * themselves when a different campaign type is chosen, so creating a Faith
 * Promise or custom campaign is not cluttered with controls for a board it
 * will never have.
 */
(function () {
  var typeSelect = document.querySelector('[data-campaign-type]');
  if (!typeSelect) return;

  function apply() {
    var sections = document.querySelectorAll('[data-show-for-type]');
    sections.forEach(function (section) {
      var wanted = section.getAttribute('data-show-for-type');
      section.style.display = (typeSelect.value === wanted) ? '' : 'none';
    });
  }

  typeSelect.addEventListener('change', apply);
  apply();
})();

/**
 * The entrance check-in kiosk: a scanned or typed code is looked up and
 * shown back — name and photo — before anything is written, so a wrong or
 * stale scan never silently marks the wrong person present. This lives in
 * app.js rather than an inline <script> in the page itself because the
 * portal's Content Security Policy only allows scripts loaded from this
 * file, not inline ones.
 */
(function () {
  var kiosk = document.querySelector('[data-checkin-kiosk]');
  if (!kiosk) return;

  var input = document.getElementById('checkin-input');
  var scanView = document.getElementById('checkin-scan-view');
  var confirmView = document.getElementById('checkin-confirm-view');
  var familyView = document.getElementById('checkin-family-view');
  var successView = document.getElementById('checkin-success-view');
  var errorBox = document.getElementById('checkin-error');
  var csrfToken = kiosk.getAttribute('data-csrf');
  var pending = null;
  var lookupPending = false;
  var successTimer;
  var familyForm = document.getElementById('checkin-family-form');

  function show(el) { el.classList.remove('is-hidden'); }
  function hide(el) { el.classList.add('is-hidden'); }

  function resetInput() {
    input.value = '';
    input.focus();
  }

  function showError(message) {
    errorBox.textContent = message;
    show(errorBox);
    resetInput();
  }

  function showScanView() {
    window.clearTimeout(successTimer);
    show(scanView);
    hide(confirmView);
    hide(familyView);
    hide(successView);
    resetInput();
  }

  function showConfirmView(member, session) {
    hide(errorBox);
    pending = { memberId: member.id, sessionId: session.id };
    document.getElementById('checkin-name').textContent = member.name;
    document.getElementById('checkin-code').textContent = member.memberCode;
    var photo = document.getElementById('checkin-photo');
    var initial = document.getElementById('checkin-initial');
    if (member.photoUrl) {
      photo.src = member.photoUrl;
      photo.alt = 'Photo of ' + member.name;
      show(photo);
      hide(initial);
    } else {
      hide(photo);
      initial.textContent = member.name.charAt(0);
      show(initial);
    }
    hide(scanView);
    hide(familyView);
    show(confirmView);
  }

  /**
   * A household of two or more takes over the confirm step instead of the
   * plain single-person card. Nothing here is ever pre-submitted: every row
   * is a real checkbox the usher can change, and the scanned member is the
   * only one guaranteed to start checked. Someone already recorded present
   * or as a visitor today is shown as a plain status line, not a checkbox,
   * so re-confirming them is not offered as if it were a new arrival.
   * Someone with an existing Absent/Vacation record starts UNCHECKED
   * deliberately — checking that box is the explicit, visible action
   * required to change it, so it is never overwritten "merely because
   * another family member checks in."
   */
  function showFamilyView(member, family) {
    hide(errorBox);
    pending = null;
    document.getElementById('checkin-family-title').textContent = 'Welcome, ' + member.name.split(' ')[0];
    var list = document.getElementById('checkin-family-list');
    list.innerHTML = '';

    family.members.forEach(function (person) {
      var li = document.createElement('li');
      var identity = document.createElement('span');
      identity.className = 'identity identity--row';

      if (person.photoUrl) {
        var img = document.createElement('img');
        img.className = 'avatar';
        img.src = person.photoUrl;
        img.alt = '';
        identity.appendChild(img);
      } else {
        var avatar = document.createElement('span');
        avatar.className = 'avatar avatar--empty';
        avatar.setAttribute('aria-hidden', 'true');
        avatar.textContent = (person.name || '?').charAt(0);
        identity.appendChild(avatar);
      }

      var nameWrap = document.createElement('span');
      var nameLine = document.createElement('span');
      nameLine.className = 'list__name';
      nameLine.textContent = person.name;
      nameWrap.appendChild(nameLine);

      if (person.existingStatus === 'present' || person.existingStatus === 'visitor') {
        var already = document.createElement('span');
        already.className = 'list__meta';
        already.textContent = 'Already checked in';
        nameWrap.appendChild(already);
      } else if (person.existingStatus === 'excused' || person.existingStatus === 'absent') {
        var note = document.createElement('span');
        note.className = 'list__meta';
        note.textContent = (person.existingStatus === 'excused' ? 'Vacation' : 'Absent') + ' recorded — check to change to Present';
        nameWrap.appendChild(note);
      }
      identity.appendChild(nameWrap);
      li.appendChild(identity);

      if (person.existingStatus !== 'present' && person.existingStatus !== 'visitor') {
        var label = document.createElement('label');
        label.className = 'checkbox';
        var box = document.createElement('input');
        box.type = 'checkbox';
        box.name = 'person';
        box.value = 'member:' + person.id;
        // The scanned member, and anyone with no record yet, start checked;
        // an existing Absent/Vacation record starts unchecked (see above).
        box.checked = person.id === member.id || (person.existingStatus !== 'excused' && person.existingStatus !== 'absent');
        label.appendChild(box);
        li.appendChild(label);
      }

      list.appendChild(li);
    });

    hide(scanView);
    hide(confirmView);
    show(familyView);
    updateFamilyAction(member);
  }

  /**
   * The family action counts NEW check-ins only. Someone already recorded has no checkbox and is never submitted again; if nobody new is ticked there
   * is nothing to confirm, so Confirm gives way to "Next check-in" (and when the whole household is already in, that is said plainly).
   */
  function updateFamilyAction() {
    var submit = document.getElementById('checkin-family-submit');
    var done = document.getElementById('checkin-family-done');
    var subtitle = document.getElementById('checkin-family-subtitle');
    var boxes = familyForm ? familyForm.querySelectorAll('input[name="person"]') : [];
    var ticked = familyForm ? familyForm.querySelectorAll('input[name="person"]:checked').length : 0;
    var everyoneRecorded = boxes.length === 0;
    if (subtitle && everyoneRecorded) subtitle.textContent = 'Everyone in this household is already checked in.';
    if (ticked > 0) {
      submit.textContent = 'Confirm attendance for ' + ticked + (ticked === 1 ? ' person' : ' people');
      submit.disabled = false;
      show(submit);
      if (done) hide(done);
    } else {
      hide(submit);
      if (done) show(done);
    }
  }

  function showSuccess(name, alreadyCheckedIn, customMessage) {
    kiosk.dispatchEvent(new CustomEvent('cciq:checkin', { bubbles: true }));
    hide(scanView);
    hide(confirmView);
    hide(familyView);
    show(successView);
    document.getElementById('checkin-success-message').textContent = customMessage || (alreadyCheckedIn
      ? name + ' is already checked in.'
      : name + ' is confirmed present.');
    if (window.cciqToast) window.cciqToast(name + (alreadyCheckedIn ? ' is already checked in.' : ' checked in.'));
    window.clearTimeout(successTimer);
    // An "already checked in" answer stays a little longer: it is information, and the next person can be scanned the moment it clears.
    successTimer = window.setTimeout(showScanView, alreadyCheckedIn ? 4000 : 2200);
  }

  function isRecorded(status) { return status === 'present' || status === 'visitor'; }

  function submitScan() {
    var token = input.value.trim();
    if (!token || lookupPending) return;
    lookupPending = true;
    clearManualOnScan();

    fetch('/attendance/checkin/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: '_csrf=' + encodeURIComponent(csrfToken) + '&token=' + encodeURIComponent(token)
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (!data.ok) { showError(data.error || 'That code could not be read.'); return; }
        if (data.family && data.family.members && data.family.members.length > 1) {
          showFamilyView(data.member, data.family);
        } else if (isRecorded(data.member.existingStatus)) {
          // Already checked in: say so, offer only the way on. Nothing to confirm, nothing to cancel.
          showSuccess(data.member.name, true);
        } else {
          showConfirmView(data.member, data.session);
        }
      })
      .catch(function () { showError('Could not reach the portal. Check the connection and try again.'); })
      .finally(function () { lookupPending = false; });
  }

  input.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    if (event.repeat) return;
    submitScan();
  });

  /*
   * A SCAN IS AUTHORITATIVE. A USB scanner is a keyboard: it types the code, very fast, into whatever has focus, then presses Enter. If focus is in the manual name/mobile
   * search box (someone tapped it earlier and walked away, with text still in it), the code used to be typed INTO that box after the stale text and Enter submitted a name
   * search for "stale text + code": a confusing result, and no QR lookup at all. So a burst of fast keystrokes anywhere on this screen is treated as a scan: whatever the burst
   * put into the manual box is taken back out (the box returns to exactly what it held before), the characters go to the scan field, and the scan field takes focus so the
   * scanner's Enter looks the code up. Nothing about the manual box is ever sent with a scan (the lookup posts only the code), and a person typing at normal speed, pasting, or
   * pressing Search on purpose is not affected.
   */
  var manualSearch = document.getElementById('checkin-search-input');
  var BURST_GAP_MS = 40; // a scanner sends characters a few milliseconds apart; nobody types at 25 characters a second
  var BURST_MIN = 4;
  var burst = null;
  document.addEventListener('keydown', function (event) {
    if (event.target === input || event.repeat || event.isComposing || event.ctrlKey || event.metaKey || event.altKey) return;
    if (scanView.classList.contains('is-hidden')) return;
    if (event.key.length !== 1) return;
    var now = event.timeStamp;
    var target = event.target;
    var inManual = manualSearch && target === manualSearch;
    // Only the manual box, a button, a link or the page itself can be where a stray scan lands; any other field is a person filling something in.
    if (!inManual && target.closest && target.closest('input, textarea, select, [contenteditable]')) { burst = null; return; }
    if (!burst || now - burst.last > BURST_GAP_MS) {
      burst = { last: now, chars: '', before: inManual ? manualSearch.value : null, diverted: false };
    }
    burst.last = now;
    burst.chars += event.key;
    if (burst.diverted) return; // the scan field has focus now; this character goes there
    if (burst.chars.length >= BURST_MIN) {
      burst.diverted = true;
      // Characters typed before the burst was recognised: out of the manual box (it goes back to what it held), into the scan field.
      if (inManual) manualSearch.value = burst.before;
      input.value = burst.chars.slice(0, -1);
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }, true);
  // The scanner's Enter, when the burst was recognised, must not press whatever had focus (the Search button, a link): it belongs to the scan field.
  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || !burst || !burst.diverted || event.target === input) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  // A fresh scan starts clean: whatever was left in the manual box (a stale search) is not part of this check-in.
  var clearManualOnScan = function () { if (manualSearch && manualSearch.value) manualSearch.value = ''; burst = null; };

  var lookupButton = document.getElementById('checkin-lookup');
  if (lookupButton) lookupButton.addEventListener('click', submitScan);

  // First Timer registration opens in a new tab: this tab keeps its scan field focused, so a scan made after coming back goes where it should.
  var firstTimerLink = document.querySelector('[data-first-timer-link]');
  if (firstTimerLink) firstTimerLink.addEventListener('click', function () { window.setTimeout(function () { input.focus(); }, 0); });

  document.getElementById('checkin-cancel').addEventListener('click', function () {
    pending = null;
    showScanView();
  });

  var familyCancel = document.getElementById('checkin-family-cancel');
  if (familyCancel) familyCancel.addEventListener('click', showScanView);

  // The success view already returns to the ready screen on its own after a
  // short pause; this lets an usher move to the next person immediately
  // instead of waiting for it.
  var nextButton = document.getElementById('checkin-next');
  if (nextButton) nextButton.addEventListener('click', showScanView);

  if (familyForm) {
    familyForm.addEventListener('change', function () { updateFamilyAction(); });
    var familyDone = document.getElementById('checkin-family-done');
    if (familyDone) familyDone.addEventListener('click', showScanView);
  }
  if (familyForm) {
    familyForm.addEventListener('submit', function (event) {
      if (!familyForm.querySelector('input[name="person"]:checked')) {
        event.preventDefault();
        showError('Choose at least one person before confirming.');
        /*
         * The page-wide "lock the button while the form submits" listener
         * (near the top of this file) runs before this one and defers
         * disabling the submit button via setTimeout(fn, 0) — which fires
         * AFTER this handler returns, so resetting the button here directly
         * would just be overwritten a moment later. Scheduling this reset
         * the same way puts it second in that same queue, so it always runs
         * after the disable it is undoing.
         */
        var submitButton = document.getElementById('checkin-family-submit');
        window.setTimeout(function () {
          if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = 'Confirm attendance';
          }
        }, 0);
      }
    });
  }

  document.getElementById('checkin-confirm').addEventListener('click', function () {
    if (!pending) return;
    var name = document.getElementById('checkin-name').textContent;
    fetch('/attendance/checkin/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: '_csrf=' + encodeURIComponent(csrfToken) + '&member_id=' + pending.memberId + '&session_id=' + pending.sessionId
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        pending = null;
        if (!data.ok) { showError(data.error || 'That could not be confirmed. Try again.'); return; }
        showSuccess(data.name, data.alreadyCheckedIn);
      })
      .catch(function () { showError('Could not reach the portal. Check the connection and try again.'); });
  });

  input.focus();

  /*
   * First Timer registration opens in its own tab (the registration screen has a "Close this tab" button), so this tab stays exactly as it
   * was. When the person comes back to it, the scan field must have focus again or the next scan would go nowhere.
   */
  function restoreScanFocus() {
    if (scanView.classList.contains('is-hidden')) return;
    // Coming back after the registration tab, the focus may be on the link that opened it (or nowhere): put it on the scan field, unless the
    // person is typing in another field here.
    var active = document.activeElement;
    if (!active || !/^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) input.focus();
  }
  window.addEventListener('focus', restoreScanFocus);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) restoreScanFocus(); });

  /*
   * A USB QR scanner behaves as a keyboard typing into whatever field
   * currently has focus, so losing focus (an accidental tap elsewhere on a
   * touchscreen, a stray click) would send the next scan into the wrong
   * place or nowhere at all. While the ready-to-scan screen is showing,
   * clicking anywhere on it that is not the search box or a button sends
   * focus back to the scan field, without interfering with someone
   * actually typing a name search.
   */
  scanView.addEventListener('click', function (event) {
    var target = event.target;
    if (target === input || target.closest('input, button, a, form')) return;
    input.focus();
  });
})();

/** Any button marked data-print just opens the browser's print dialog. */
document.querySelectorAll('[data-print]').forEach(function (button) {
  button.addEventListener('click', function () { window.print(); });
});

/**
 * The Faith Promise pledge form's live total: as the amount or frequency
 * changes, the year's total recalculates immediately, before the form is
 * ever submitted. This lives here rather than inline in the page because
 * the portal's Content Security Policy does not allow inline <script>
 * blocks — only scripts loaded from a file like this one.
 */
(function () {
  var form = document.querySelector('[data-pledge-form]');
  if (!form) return;

  var amountInput = document.getElementById('pf-amount');
  var totalDisplay = document.getElementById('pf-total');
  var periodMonths = Number(form.getAttribute('data-period-months')) || 12;

  function currentFrequency() {
    var checked = form.querySelector('input[name="frequency"]:checked');
    return checked ? checked.value : 'monthly';
  }

  function recalc() {
    var amount = Number(amountInput.value) || 0;
    var freq = currentFrequency();
    var count = freq === 'monthly' ? periodMonths : freq === 'quarterly' ? Math.max(1, Math.round(periodMonths / 3)) : 1;
    var total = amount * count;
    totalDisplay.textContent = 'QAR ' + total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  amountInput.addEventListener('input', recalc);
  form.querySelectorAll('input[name="frequency"]').forEach(function (r) {
    r.addEventListener('change', recalc);
  });
  recalc();
})();

/**
 * Bar and progress-fill widths/heights are data-driven percentages
 * computed per render (chart bars, Giving Board reveal, claim progress).
 * They're applied here via .style rather than as an inline style="" in the
 * markup, since the portal's Content Security Policy blocks the latter
 * regardless of whether the value is static or computed by the template.
 */
document.querySelectorAll('[data-bar-height]').forEach(function (el) {
  el.style.height = el.getAttribute('data-bar-height') + '%';
});
document.querySelectorAll('[data-bar-width]').forEach(function (el) {
  el.style.width = el.getAttribute('data-bar-width') + '%';
});

/** The Giving Board's reveal picture, and anywhere else a background image is data-driven. */
document.querySelectorAll('[data-bg-image]').forEach(function (el) {
  var url = el.getAttribute('data-bg-image');
  if (url) el.style.backgroundImage = "url('" + url + "')";
});

/**
 * The shared searchable member picker (partials/member-picker.ejs). A few
 * letters, a short list of matches — name, Member ID, cell group, never
 * status — and the hidden field the surrounding form actually submits is set
 * to that member's id. Every relationship-linking control in the portal uses
 * this same widget, so a future one only needs the partial, not new JS.
 * Built from plain DOM methods (never innerHTML with a name/code), so a
 * member's own name can never be interpreted as markup.
 */
(function () {
  var pickers = document.querySelectorAll('[data-member-picker]');
  if (!pickers.length) return;

  pickers.forEach(function (picker) {
    var endpoint = picker.getAttribute('data-picker-endpoint');
    var excludeId = picker.getAttribute('data-picker-exclude') || '';
    var minChars = Number(picker.getAttribute('data-picker-min')) || 2;
    var extraParams = {};
    try {
      extraParams = JSON.parse(picker.getAttribute('data-picker-extra') || '{}');
    } catch (e) {
      // A malformed data-picker-extra just means no extra filters — never
      // breaks the picker itself.
    }
    var hidden = picker.querySelector('[data-picker-value]');
    var selectedBox = picker.querySelector('[data-picker-selected]');
    var selectedName = picker.querySelector('[data-picker-selected-name]');
    var selectedDetail = picker.querySelector('[data-picker-selected-detail]');
    var selectedInitial = picker.querySelector('[data-picker-selected-initial]');
    var searchArea = picker.querySelector('[data-picker-search-area]');
    var input = picker.querySelector('[data-picker-input]');
    var results = picker.querySelector('[data-picker-results]');
    var changeBtn = picker.querySelector('[data-picker-change]');
    var clearBtn = picker.querySelector('[data-picker-clear]');
    if (!hidden || !input || !results) return;
    var debounceTimer = null;
    var activeRequest = 0;

    function closeResults() {
      results.hidden = true;
      results.innerHTML = '';
      input.setAttribute('aria-expanded', 'false');
    }

    function showSelected(name, detail) {
      selectedName.textContent = '✓ ' + name;
      if (selectedDetail) selectedDetail.textContent = detail || '';
      if (selectedInitial) selectedInitial.textContent = (name || '?').charAt(0);
      selectedBox.hidden = false;
      searchArea.hidden = true;
      closeResults();
    }

    function showSearch() {
      selectedBox.hidden = true;
      searchArea.hidden = false;
      input.value = '';
      closeResults();
      input.focus();
    }

    function select(person) {
      hidden.value = person.id;
      var detail = [person.memberCode, person.cellGroup].filter(Boolean).join(' · ');
      showSelected(person.name, detail);
      hidden.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function clearSelection() {
      hidden.value = '';
      showSearch();
      hidden.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function renderResults(people) {
      results.innerHTML = '';
      if (people.length === 0) {
        var empty = document.createElement('div');
        empty.className = 'member-picker__empty';
        empty.textContent = 'No one found.';
        results.appendChild(empty);
        results.hidden = false;
        input.setAttribute('aria-expanded', 'true');
        return;
      }
      people.forEach(function (person) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'member-picker__result';
        btn.setAttribute('role', 'option');

        var avatar;
        if (person.photoUrl) {
          avatar = document.createElement('img');
          avatar.className = 'avatar';
          avatar.src = person.photoUrl;
          avatar.alt = '';
        } else {
          avatar = document.createElement('span');
          avatar.className = 'avatar avatar--empty';
          avatar.setAttribute('aria-hidden', 'true');
          avatar.textContent = (person.name || '?').charAt(0);
        }

        var textWrap = document.createElement('span');
        var nameEl = document.createElement('span');
        nameEl.className = 'list__name';
        nameEl.textContent = person.name;
        textWrap.appendChild(nameEl);

        var detail = [person.memberCode, person.cellGroup].filter(Boolean).join(' · ');
        if (detail) {
          var detailEl = document.createElement('span');
          detailEl.className = 'list__meta';
          detailEl.textContent = detail;
          textWrap.appendChild(detailEl);
        }

        btn.appendChild(avatar);
        btn.appendChild(textWrap);
        btn.addEventListener('click', function () { select(person); });
        results.appendChild(btn);
      });
      results.hidden = false;
      input.setAttribute('aria-expanded', 'true');
    }

    function runSearch(term) {
      if (term.length < minChars) { closeResults(); return; }
      var requestId = ++activeRequest;
      var url = endpoint + '?q=' + encodeURIComponent(term)
        + (excludeId ? '&exclude=' + encodeURIComponent(excludeId) : '');
      Object.keys(extraParams).forEach(function (key) {
        url += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(extraParams[key]);
      });
      fetch(url, { headers: { Accept: 'application/json' } })
        .then(function (res) { return res.ok ? res.json() : []; })
        .then(function (people) {
          // A slower earlier request resolving after a newer one must never
          // overwrite what the person can already see.
          if (requestId === activeRequest) renderResults(Array.isArray(people) ? people : []);
        })
        .catch(function () {
          // A failed search just shows no results — it never breaks the form
          // or blocks typing a value in some other way.
        });
    }

    input.addEventListener('input', function () {
      clearTimeout(debounceTimer);
      var term = input.value.trim();
      debounceTimer = setTimeout(function () { runSearch(term); }, 250);
    });

    input.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { closeResults(); return; }
      // Enter in a picker searches; it must not implicitly create/save the account.
      if (event.key === 'Enter') {
        event.preventDefault(); clearTimeout(debounceTimer); runSearch(input.value.trim()); return;
      }
      if (event.key === 'ArrowDown' && !results.hidden) {
        var first = results.querySelector('.member-picker__result');
        if (first) { first.focus(); event.preventDefault(); }
      }
    });

    results.addEventListener('keydown', function (event) {
      var items = Array.prototype.slice.call(results.querySelectorAll('.member-picker__result'));
      var index = items.indexOf(document.activeElement);
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        (items[index + 1] || items[0]).focus();
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        (items[index - 1] || items[items.length - 1]).focus();
      } else if (event.key === 'Escape') {
        closeResults();
        input.focus();
      }
    });

    document.addEventListener('click', function (event) {
      if (!picker.contains(event.target)) closeResults();
    });

    if (changeBtn) changeBtn.addEventListener('click', showSearch);
    if (clearBtn) clearBtn.addEventListener('click', clearSelection);
  });
})();

/**
 * Quick Access fetches the public portal URL and a fresh branded card.
 * Cache busting keeps branding and the generation date current.
 *
 * Shared by two places that never duplicate the actual portal-address
 * logic (that lives entirely server-side, in GET /quick-access/info and
 * GET /quick-access/card.png): the login screen's on-demand dialog, and the
 * Attendance Kiosk's always-visible lobby panel. Only how the result is
 * presented differs (`showDownload`), never where the address comes from.
 */
function cciqRenderQuickAccess(content, data, options) {
  options = options || {};

  if (!data.ok) {
    content.innerHTML = '';
    var p = document.createElement('p');
    p.className = 'quick-access__hint';
    p.textContent = 'Quick Access is not available right now. Please try again.';
    var actions = document.createElement('div');
    actions.className = 'quick-access__actions';
    var retry = document.createElement('button');
    retry.type = 'button';
    retry.className = 'btn btn--secondary btn--small';
    retry.textContent = 'Try Again';
    retry.addEventListener('click', function () { cciqLoadQuickAccess(content, options); });
    actions.appendChild(retry);
    content.appendChild(p);
    content.appendChild(actions);
    return;
  }

  var bust = Date.now();
  content.innerHTML = '';

  var img = document.createElement('img');
  img.className = 'quick-access__image';
  img.src = '/quick-access/card.png?t=' + bust;
  img.alt = 'Quick Access QR code';
  content.appendChild(img);

  var url = document.createElement('p');
  url.className = 'quick-access__url';
  url.textContent = data.url;
  content.appendChild(url);

  var dateP = document.createElement('p');
  dateP.className = 'quick-access__date';
  dateP.textContent = 'Generated: ' + data.dateLabel;
  content.appendChild(dateP);

  var notice = document.createElement('p');
  notice.className = 'quick-access__notice';
  notice.textContent = 'Portal sign-in required';
  content.appendChild(notice);

  var hint = document.createElement('p');
  hint.className = 'quick-access__hint';
  hint.textContent = 'Scan using Wi-Fi or mobile data. This QR opens the portal; it does not record attendance.';
  content.appendChild(hint);

  var actions = document.createElement('div');
  actions.className = 'quick-access__actions';

  if (options.showDownload !== false) {
    var download = document.createElement('a');
    download.className = 'btn btn--small';
    download.href = '/quick-access/card.png?t=' + bust;
    download.setAttribute('download', data.filename || 'CCIQ-Quick-Access.png');
    download.textContent = 'Download QR';
    actions.appendChild(download);
  }

  var refresh = document.createElement('button');
  refresh.type = 'button';
  refresh.className = 'btn btn--secondary btn--small';
  refresh.textContent = 'Refresh QR';
  refresh.addEventListener('click', function () { cciqLoadQuickAccess(content, options); });
  actions.appendChild(refresh);

  content.appendChild(actions);
}

function cciqLoadQuickAccess(content, options) {
  content.innerHTML = '<p class="quick-access__hint">Loading&hellip;</p>';
  fetch('/quick-access/info', { headers: { Accept: 'application/json' } })
    .then(function (res) { return res.json(); })
    .then(function (data) { cciqRenderQuickAccess(content, data, options); })
    .catch(function () { cciqRenderQuickAccess(content, { ok: false }, options); });
}

/** Login screen: opened on demand, so nothing is fetched until asked for. */
(function () {
  var openButton = document.querySelector('[data-quick-access-open]');
  var dialog = document.getElementById('quick-access-dialog');
  if (!openButton || !dialog) return;

  var content = document.getElementById('quick-access-content');

  openButton.addEventListener('click', function () {
    dialog.showModal();
    cciqLoadQuickAccess(content);
  });

  // Clicking the backdrop (outside the card) closes the dialog, matching
  // the close button and Escape (which <dialog> already handles natively).
  dialog.addEventListener('click', function (event) {
    if (event.target === dialog) dialog.close();
  });
})();

/**
 * Attendance Kiosk lobby panel: always visible on the Kiosk's own screen (no
 * button needed to reveal it), so someone waiting near reception can scan it
 * themselves without interrupting whoever is being checked in. Loads once
 * when the Kiosk screen itself loads — a separate DOM subtree from the
 * check-in state machine above, so refreshing the address here never
 * touches an attendance flow already in progress.
 */
(function () {
  var content = document.getElementById('lobby-quick-access-content');
  if (!content) return;
  cciqLoadQuickAccess(content, { showDownload: false });
})();

/* Paginated attendance register. The draft is independent of rendered rows. */
(function () {
  'use strict';
  var form = document.querySelector('[data-attendance-register]');
  var payload = document.getElementById('attendance-register-data');
  if (!form || !payload) return;
  var data = JSON.parse(payload.textContent);
  var members = data.members;
  var byId = new Map(members.map(function (m) { return [m.id, m]; }));
  var draft = new Map();
  var selected = new Set();
  var filterForm = document.querySelector('[data-register-filters]');
  var search = filterForm.querySelector('[name="q"]');
  var group = filterForm.querySelector('[name="cell_group_id"]');
  var congregation = filterForm.querySelector('[name="congregation"]');
  var statusFilter = document.querySelector('[data-register-status]');
  var sizeControl = form.querySelector('[data-register-page-size]');
  var tbody = form.querySelector('[data-register-body]');
  var range = form.querySelector('[data-register-range]');
  var pages = form.querySelector('[data-register-pages]');
  var pending = form.querySelector('[data-register-pending]');
  var save = form.querySelector('[data-register-save]');
  var message = form.querySelector('[data-register-message]');
  var selectPage = form.querySelector('[data-register-select-page]');
  var scope = form.querySelector('[data-register-bulk-scope]');
  var params = new URLSearchParams(window.location.search);
  var page = Math.max(1, parseInt(params.get('page'), 10) || 1);
  var size = [25, 50, 100].includes(Number(params.get('page_size'))) ? Number(params.get('page_size')) : 25;
  sizeControl.value = String(size);
  statusFilter.value = params.get('attendance_status') || '';
  var sort = { key: '', direction: 1 };
  var collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  var filtered = [], visible = [], saving = false;

  function element(tag, text, className) {
    var e = document.createElement(tag);
    if (text !== undefined && text !== null) e.textContent = text;
    if (className) e.className = className;
    return e;
  }
  function status(m) { return draft.has(m.id) ? draft.get(m.id) : m.status; }
  function remember(m, value) {
    if (value === m.status) draft.delete(m.id);
    else draft.set(m.id, value);
  }
  function updatePending() {
    pending.textContent = draft.size ? draft.size + ' pending change' + (draft.size === 1 ? '' : 's') : 'No pending changes';
    if (save) save.disabled = saving || draft.size === 0;
    if (save) save.textContent = saving ? 'Saving…' : 'Save attendance';
    tbody.querySelectorAll('[data-register-member]').forEach(function (row) {
      var changed = draft.has(Number(row.dataset.registerMember));
      row.dataset.pending = String(changed);
      row.querySelector('[data-pending-label]').textContent = changed ? 'Unsaved change' : '';
    });
  }
  function updateSelection() {
    var count = visible.filter(function (m) { return selected.has(m.id); }).length;
    var label = form.querySelector('[data-register-selected]');
    if (label) label.textContent = count + ' selected on this page';
    if (selectPage) {
      selectPage.checked = visible.length > 0 && count === visible.length;
      selectPage.indeterminate = count > 0 && count < visible.length;
      selectPage.disabled = saving || visible.length === 0;
    }
    var total = scope && scope.value === 'filtered' ? filtered.length : scope && scope.value === 'page' ? visible.length : count;
    form.querySelectorAll('[data-register-bulk]').forEach(function (button) { button.disabled = saving || !total; });
  }
  function rememberView() {
    var url = new URL(window.location.href);
    [['q', search.value], ['cell_group_id', group.value], ['congregation', congregation.value],
      ['attendance_status', statusFilter.value], ['page_size', String(size)], ['page', String(page)]].forEach(function (entry) {
      if (entry[1]) url.searchParams.set(entry[0], entry[1]); else url.searchParams.delete(entry[0]);
    });
    // replaceState stays on the same page and never triggers a leave warning.
    window.history.replaceState(null, '', url);
  }
  function rowFor(m) {
    var row = element('tr'); row.dataset.registerMember = String(m.id);
    function cell(label) { var td = element('td'); td.dataset.label = label; row.appendChild(td); return td; }
    if (data.canRecord) {
      var box = element('input'); box.type = 'checkbox'; box.dataset.registerSelect = String(m.id);
      box.setAttribute('aria-label', 'Select ' + m.name); box.checked = selected.has(m.id); box.disabled = saving;
      cell('Select').appendChild(box);
    }
    var identity = element('span', null, 'identity identity--row');
    if (m.photo) { var image = element('img', null, 'avatar'); image.src = m.photo; image.alt = ''; image.loading = 'lazy'; identity.appendChild(image); }
    else { var avatar = element('span', m.initial, 'avatar avatar--empty'); avatar.setAttribute('aria-hidden', 'true'); identity.appendChild(avatar); }
    var info = element('span'); var link = element('a', m.name); link.href = '/members/' + m.id;
    link.dataset.quickOpen = '/members/' + m.id + '/quick'; link.dataset.quickTitle = 'Member profile'; link.dataset.quickContext = data.context;
    info.appendChild(link); var changed = element('span'); changed.setAttribute('data-pending-label', ''); info.appendChild(changed);
    identity.appendChild(info); cell('Member').appendChild(identity);
    cell('Member ID').textContent = m.code;
    cell('Cell group').textContent = m.group || '—';
    var choices = element('fieldset', null, 'choices'); choices.disabled = !data.canRecord || saving;
    choices.appendChild(element('legend', 'Attendance for ' + m.name, 'sr-only'));
    data.statuses.forEach(function (s) {
      var label = element('label', null, 'choice choice--' + (s.value || 'not_recorded'));
      var input = element('input'); input.type = 'radio'; input.name = 'status_' + m.id; input.value = s.value;
      input.checked = status(m) === s.value; input.dataset.registerChoice = String(m.id);
      label.appendChild(input); label.appendChild(element('span', s.label)); choices.appendChild(label);
    });
    cell('Attendance').appendChild(choices);
    return row;
  }
  function render(resetSelection) {
    if (resetSelection) selected.clear();
    var term = search.value.trim().toLocaleLowerCase();
    filtered = members.filter(function (m) {
      var searchable = [m.name, m.firstName, m.lastName, m.preferredName, m.code].join(' ').toLocaleLowerCase();
      return (!term || searchable.includes(term)) && (!group.value || String(m.groupId) === group.value)
        && (!congregation.value || m.congregation === congregation.value)
        && (!statusFilter.value || (status(m) || 'not_recorded') === statusFilter.value);
    });
    if (sort.key) filtered.sort(function (a, b) {
      var aValue = sort.key === 'status' ? status(a) || 'not_recorded' : a[sort.key];
      var bValue = sort.key === 'status' ? status(b) || 'not_recorded' : b[sort.key];
      return sort.direction * collator.compare(aValue || '', bValue || '') || a.id - b.id;
    });
    var count = Math.max(1, Math.ceil(filtered.length / size)); page = Math.min(page, count);
    visible = filtered.slice((page - 1) * size, page * size);
    var fragment = document.createDocumentFragment(); visible.forEach(function (m) { fragment.appendChild(rowFor(m)); });
    tbody.replaceChildren(fragment);
    range.textContent = filtered.length ? 'Showing ' + ((page - 1) * size + 1) + '–' + Math.min(page * size, filtered.length) + ' of ' + filtered.length + ' matching members (' + members.length + ' total)' : '0 matching members (' + members.length + ' total)';
    form.querySelector('[data-register-empty]').hidden = filtered.length !== 0;
    pages.replaceChildren();
    function pageButton(label, number, disabled, current) {
      var button = element('button', label, 'btn btn--secondary btn--small'); button.type = 'button'; button.disabled = disabled || saving;
      if (current) button.setAttribute('aria-current', 'page');
      button.setAttribute('aria-label', /^\d+$/.test(String(label)) ? 'Page ' + label : label);
      button.addEventListener('click', function () { page = number; render(true); pages.querySelector('[aria-current="page"]')?.focus(); });
      pages.appendChild(button);
    }
    pageButton('Previous', page - 1, page === 1, false);
    var wanted = new Set([1, count]); for (var n = Math.max(1, page - 2); n <= Math.min(count, page + 2); n++) wanted.add(n);
    var previous = 0; Array.from(wanted).sort(function (a, b) { return a - b; }).forEach(function (number) {
      if (previous && number > previous + 1) pages.appendChild(element('span', '…'));
      pageButton(String(number), number, false, number === page); previous = number;
    });
    pageButton('Next', page + 1, page === count, false);
    updatePending(); updateSelection(); rememberView();
  }
  filterForm.addEventListener('submit', function (event) { event.preventDefault(); if (saving) return; page = 1; render(true); });
  search.addEventListener('input', function () { if (saving) return; page = 1; render(true); });
  [group, congregation, statusFilter].forEach(function (control) { control.addEventListener('change', function () { if (saving) return; page = 1; render(true); }); });
  sizeControl.addEventListener('change', function () { if (saving) return; size = Number(sizeControl.value); page = 1; render(true); });
  if (scope) scope.addEventListener('change', updateSelection);
  if (selectPage) selectPage.addEventListener('change', function () {
    visible.forEach(function (m) { if (selectPage.checked) selected.add(m.id); else selected.delete(m.id); });
    tbody.querySelectorAll('[data-register-select]').forEach(function (box) { box.checked = selected.has(Number(box.dataset.registerSelect)); }); updateSelection();
  });
  tbody.addEventListener('change', function (event) {
    if (saving || !data.canRecord) return;
    if (event.target.hasAttribute('data-register-select')) {
      var selectedId = Number(event.target.dataset.registerSelect);
      if (event.target.checked) selected.add(selectedId); else selected.delete(selectedId); updateSelection();
    } else if (event.target.hasAttribute('data-register-choice')) {
      remember(byId.get(Number(event.target.dataset.registerChoice)), event.target.value);
      if (statusFilter.value) render(true); else updatePending();
    }
  });
  form.querySelectorAll('[data-register-sort]').forEach(function (button) {
    button.addEventListener('click', function () {
      sort = { key: button.dataset.registerSort, direction: sort.key === button.dataset.registerSort ? -sort.direction : 1 };
      form.querySelectorAll('[data-register-sort]').forEach(function (b) { b.closest('th').removeAttribute('aria-sort'); });
      button.closest('th').setAttribute('aria-sort', sort.direction === 1 ? 'ascending' : 'descending'); page = 1; render(true);
    });
  });
  form.querySelectorAll('[data-register-bulk]').forEach(function (button) {
    button.addEventListener('click', function () {
      if (saving || !data.canRecord) return;
      var targets = scope.value === 'filtered' ? filtered.slice() : scope.value === 'page' ? visible.slice() : visible.filter(function (m) { return selected.has(m.id); });
      if (!targets.length) return;
      var value = button.dataset.registerBulk;
      if (targets.length > 10 || value === '') {
        var label = data.statuses.find(function (s) { return s.value === value; }).label;
        if (!window.confirm('Set ' + targets.length + ' members to ' + label + ' (' + scope.options[scope.selectedIndex].text + ')? Changes will remain unsaved until you save attendance.')) return;
      }
      targets.forEach(function (m) { remember(m, value); }); render(false);
    });
  });
  window.addEventListener('beforeunload', function (event) {
    if (!draft.size) return;
    event.preventDefault(); event.returnValue = '';
  });
  window.addEventListener('pageshow', function () { saving = false; updatePending(); });
  form.addEventListener('submit', async function (event) {
    event.preventDefault(); if (saving || !data.canRecord || !draft.size) return;
    var submitted = new Map(draft);
    var body = { _csrf: form.querySelector('[name="_csrf"]').value };
    // Submit the complete draft, including hidden pages, and never untouched rows.
    // Existing notes travel with edited records; blank/Not recorded retains delete semantics.
    submitted.forEach(function (value, id) { body['status_' + id] = value; body['notes_' + id] = byId.get(id).notes; });
    saving = true; message.hidden = true;
    [search, group, congregation, statusFilter, sizeControl].forEach(function (c) { c.disabled = true; });
    render(false);
    try {
      var response = await fetch(form.action, { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!response.ok || !String(response.headers.get('content-type')).includes('application/json')) throw new Error('Save was not confirmed. Your draft is still here. Check your connection and sign-in before retrying.');
      var result = await response.json();
      if (!result.ok || result.skipped) throw new Error('Some changes could not be saved with your current permissions. Your draft is retained for review.');
      submitted.forEach(function (value, id) { byId.get(id).status = value; draft.delete(id); });
      updatePending(); window.location.reload();
    } catch (error) {
      message.textContent = error.message || 'Unable to confirm the save. Your draft is still here.'; message.hidden = false;
    } finally {
      saving = false; [search, group, congregation, statusFilter, sizeControl].forEach(function (c) { c.disabled = false; }); render(false);
    }
  });
  render(true);
})();

/*
 * A photo that cannot be loaded (the file is missing, access was withdrawn) degrades to the same
 * initial avatar used when there is no photo - the browser's broken-image box, with its alt text
 * drawn inside the circle, is never what a person sees. The alt text stays for assistive technology.
 */
(function () {
  function isAvatarImage(img) {
    return img && img.tagName === 'IMG' && (img.classList.contains('avatar') || !!img.closest('.avatar'));
  }

  function initialOf(img, holder) {
    var text = img.getAttribute('data-initial') || (holder && holder.getAttribute('data-initial')) || '';
    return text.charAt(0);
  }

  function degrade(img) {
    if (!isAvatarImage(img) || img.getAttribute('data-avatar-failed')) return;
    img.setAttribute('data-avatar-failed', '1');

    var holder = img.classList.contains('avatar') ? null : img.closest('.avatar');
    if (holder) {
      holder.classList.add('avatar--empty');
      holder.setAttribute('aria-hidden', 'true');
      // A portrait that opened a larger view is no longer a link to a picture that is not there.
      holder.classList.remove('avatar--clickable');
      holder.removeAttribute('data-lightbox');
      holder.removeAttribute('href');
      holder.textContent = initialOf(img, holder);
      return;
    }

    var parent = img.parentNode;
    var target = parent && parent.matches && parent.matches('a[data-lightbox]') ? parent : img;
    var replacement = document.createElement('span');
    replacement.className = img.className.replace(/\bavatar--clickable\b/g, '').replace(/\s+/g, ' ').trim() + ' avatar--empty';
    replacement.setAttribute('aria-hidden', 'true');
    replacement.textContent = initialOf(img, null);
    target.parentNode.replaceChild(replacement, target);
  }

  document.addEventListener('error', function (event) { degrade(event.target); coverFallback(event.target); }, true);

  // A cover photo that cannot be loaded (the file is damaged, or was removed after the page was built) falls back, once, to the shared default cover.
  function coverFallback(img) {
    if (!img || img.tagName !== 'IMG') return;
    var fallback = img.getAttribute('data-cover-fallback');
    if (!fallback || img.getAttribute('data-cover-failed')) return;
    img.setAttribute('data-cover-failed', '1');
    img.removeAttribute('srcset');
    img.src = fallback;
    img.closest('.group-cover') && img.closest('.group-cover').classList.remove('group-cover--custom');
  }

  // Images that had already failed before this script ran.
  document.querySelectorAll('img.avatar, .avatar img').forEach(function (img) {
    if (img.getAttribute('src') && img.complete && img.naturalWidth === 0) degrade(img);
  });
  // A cover photo that had already failed before this script ran (the error event is gone by then) is swapped for the shared default cover too.
  document.querySelectorAll('img[data-cover-fallback]').forEach(function (img) {
    if (img.complete && img.naturalWidth === 0) coverFallback(img);
  });
})();

/* "Select all (N)" for the people shown by a check-in search. It ticks only the checkboxes named "person" in its own form (the people on screen), never checks anybody in
   (the operator still presses "Review selected"), and sits in the mixed state when only some are ticked. Attendance stays person-based: nothing here knows about families. */
(function () {
  'use strict';
  document.querySelectorAll('[data-select-all]').forEach(function (master) {
    var form = master.closest('form');
    if (!form) return;
    var status = form.querySelector('[data-select-all-status]');
    var countEl = form.querySelector('[data-select-all-count]');
    function boxes() {
      return Array.prototype.slice.call(form.querySelectorAll('input[type="checkbox"][name="person"]')).filter(function (b) {
        return !b.disabled && !b.closest('[hidden]');
      });
    }
    function refresh() {
      var all = boxes();
      var ticked = all.filter(function (b) { return b.checked; }).length;
      if (countEl) countEl.textContent = String(all.length);
      master.disabled = all.length === 0;
      master.checked = all.length > 0 && ticked === all.length;
      master.indeterminate = ticked > 0 && ticked < all.length;
      master.setAttribute('aria-checked', master.indeterminate ? 'mixed' : (master.checked ? 'true' : 'false'));
      if (status) status.textContent = ticked === 0 ? '' : (ticked + ' of ' + all.length + ' selected');
    }
    master.addEventListener('change', function () {
      var on = master.checked;
      boxes().forEach(function (b) { b.checked = on; });
      refresh();
    });
    form.addEventListener('change', function (event) {
      if (event.target !== master && event.target.name === 'person') refresh();
    });
    refresh();
  });
})();

/* Verse of the Day: the compact line opens the whole verse and the NIV notice in a small panel (native <details>, so Enter / Space / a tap work with no script). This only adds the
   comforts: Escape closes it and returns focus to the line, a click elsewhere closes it, only one is open, and the panel is nudged so it never leaves the screen. */
(function () {
  'use strict';
  var all = Array.prototype.slice.call(document.querySelectorAll('[data-votd] details'));
  if (!all.length) return;
  function place(details) {
    var panel = details.querySelector('.votd__panel');
    if (!panel) return;
    panel.style.left = '0px';
    var r = panel.getBoundingClientRect();
    var margin = 8;
    var shift = 0;
    if (r.right > window.innerWidth - margin) shift = (window.innerWidth - margin) - r.right;
    if (r.left + shift < margin) shift = margin - r.left;
    panel.style.left = shift + 'px';
  }
  all.forEach(function (details) {
    details.addEventListener('toggle', function () { if (details.open) place(details); });
  });
  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;
    all.forEach(function (details) {
      if (!details.open) return;
      details.open = false;
      var summary = details.querySelector('summary');
      if (summary) summary.focus();
    });
  });
  document.addEventListener('click', function (event) {
    all.forEach(function (details) { if (details.open && !details.contains(event.target)) details.open = false; });
  });
  window.addEventListener('resize', function () { all.forEach(function (d) { if (d.open) place(d); }); });
})();
