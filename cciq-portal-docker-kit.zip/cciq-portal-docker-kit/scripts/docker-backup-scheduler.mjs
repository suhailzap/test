/*
 * Container replacement for Task Scheduler / cron. Runs scripts/scheduled-backup.mjs once a day at BACKUP_AT
 * (HH:MM, church time = TZ_NAME) and, if BACKUP_ON_START=true, once at startup. It only schedules: the backup,
 * its verification and the 60-backup retention are all done by scheduled-backup.mjs itself.
 * Runs as its own container from the same image, sharing the /data volume (the portal supports a second process
 * on the same database file; it waits on the busy timeout instead of failing).
 */
import { spawn } from 'node:child_process';

const tz = process.env.TZ_NAME || 'Asia/Qatar';
const [hh, mm] = (process.env.BACKUP_AT || '02:30').split(':').map(Number);
if (!Number.isInteger(hh) || !Number.isInteger(mm) || hh > 23 || mm > 59) {
  console.error(`BACKUP_AT must be HH:MM (24h), got "${process.env.BACKUP_AT}"`);
  process.exit(2);
}
const fmt = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false, year: 'numeric', month: '2-digit', day: '2-digit' });
const nowParts = () => Object.fromEntries(fmt.formatToParts(new Date()).map((p) => [p.type, p.value]));

let running = false;
function runBackup(reason) {
  if (running) return;
  running = true;
  console.log(`[backup-scheduler] starting backup (${reason})`);
  const child = spawn(process.execPath, ['scripts/scheduled-backup.mjs'], { stdio: 'inherit' });
  child.on('exit', (code) => {
    running = false;
    console.log(`[backup-scheduler] backup finished with exit code ${code}`);
  });
}

if (process.env.BACKUP_ON_START === 'true') runBackup('startup');

let lastDay = '';
setInterval(() => {
  const p = nowParts();
  const day = `${p.year}-${p.month}-${p.day}`;
  if (day !== lastDay && Number(p.hour) === hh && Number(p.minute) >= mm) {
    lastDay = day;
    runBackup('daily schedule');
  }
}, 30 * 1000);

console.log(`[backup-scheduler] daily backup at ${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${tz}`);
const stop = () => process.exit(0);
process.on('SIGTERM', stop);
process.on('SIGINT', stop);
