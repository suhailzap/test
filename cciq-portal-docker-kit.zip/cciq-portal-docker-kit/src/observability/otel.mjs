/*
 * Observability bootstrap. Loaded with `node --import ./src/observability/otel.mjs`
 * BEFORE the portal, so nothing in src/ has to change.
 *
 *   traces + metrics -> OTLP (OTEL_EXPORTER_OTLP_ENDPOINT, e.g. an OpenTelemetry Collector)
 *   logs             -> one JSON object per line on stdout/stderr (LOG_FORMAT=json), carrying
 *                       trace_id / span_id when the line is written inside a request
 *
 * OTEL_SDK_DISABLED=true turns tracing/metrics off (logs stay JSON). LOG_FORMAT=text keeps plain console output.
 * Everything else (service name, endpoint, protocol, sampler) is the standard OTEL_* environment variables.
 */
import { register } from 'node:module';
import { format } from 'node:util';
import { trace } from '@opentelemetry/api';

const service = process.env.OTEL_SERVICE_NAME || 'cciq-portal';
let sdk;

if (process.env.OTEL_SDK_DISABLED !== 'true') {
  // ESM needs the loader hook, and the instrumentations must be imported AFTER it is registered.
  register('@opentelemetry/instrumentation/hook.mjs', import.meta.url);
  const [{ NodeSDK }, { HttpInstrumentation }, { ExpressInstrumentation }, { RuntimeNodeInstrumentation }] = await Promise.all([
    import('@opentelemetry/sdk-node'),
    import('@opentelemetry/instrumentation-http'),
    import('@opentelemetry/instrumentation-express'),
    import('@opentelemetry/instrumentation-runtime-node')
  ]);

  // Health probes and static assets would drown real traffic in the trace store.
  const noise = /^\/(healthz|css\/|js\/|branding\/|favicon)/;
  sdk = new NodeSDK({
    instrumentations: [
      new HttpInstrumentation({ ignoreIncomingRequestHook: (req) => noise.test(req.url || '') }),
      // One span per request handler (named by its route, e.g. "GET /members/:id"), not one per middleware layer.
      new ExpressInstrumentation({ ignoreLayersType: ['middleware', 'router'] }),
      new RuntimeNodeInstrumentation()
    ]
  });
  sdk.start();
}

if ((process.env.LOG_FORMAT || 'json') === 'json') {
  const levels = { log: 'info', info: 'info', debug: 'debug', warn: 'warn', error: 'error' };
  for (const [method, level] of Object.entries(levels)) {
    const out = level === 'warn' || level === 'error' ? process.stderr : process.stdout;
    console[method] = (...args) => {
      const msg = format(...args).trimEnd();
      if (!msg) return; // the portal prints blank spacer lines in its banner
      const sc = trace.getActiveSpan()?.spanContext();
      out.write(`${JSON.stringify({
        ts: new Date().toISOString(),
        level,
        service,
        msg,
        ...(sc && { trace_id: sc.traceId, span_id: sc.spanId })
      })}\n`);
    };
  }
}

// The portal has no shutdown handler of its own. Flush telemetry, then exit (SQLite runs in WAL mode, so this is safe).
let stopping = false;
const stop = () => {
  if (stopping) return;
  stopping = true;
  const done = () => process.exit(0);
  (sdk ? sdk.shutdown() : Promise.resolve()).then(done, done);
  setTimeout(done, 5000).unref();
};
process.once('SIGTERM', stop);
process.once('SIGINT', stop);
