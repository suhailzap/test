# CCIQ Portal - Docker runbook

Unzip this kit over the project root (it adds files and replaces `package.json` / `package-lock.json`).

## First run
```bash
cp .env.docker.example .env
echo "SESSION_SECRET=$(openssl rand -hex 32)" >> .env   # then delete the empty SESSION_SECRET= line
docker compose build
docker compose run --rm -it migrate src/db/seed.js      # migrates + creates the first Super Admin (password is shown ONCE, in this terminal)
docker compose up -d                                     # migrate -> portal + daily backup
curl localhost:3000/healthz
```
Open http://localhost:3000.

## With observability (logs, metrics, traces)
```bash
echo "GRAFANA_ADMIN_PASSWORD=$(openssl rand -hex 16)" >> .env
docker compose -f docker-compose.yml -f docker-compose.observability.yml up -d --build
```
Grafana http://localhost:3001 (user `admin`) -> dashboard "CCIQ Portal - overview". Prometheus http://localhost:9090
(check Status -> Targets, Alerts). Remote access: SSH tunnel (`ssh -L 3001:localhost:3001 host`) or a TLS proxy.

## Upgrade
```bash
git pull && docker compose build && docker compose up -d   # `migrate` runs first, then the portal restarts
```
Everyone is signed out on each portal restart (the portal clears all sessions at startup by design).

## Backups and restore
Daily verified backup at `BACKUP_AT` (church time) into the `/data/backups` volume, 60 kept. Set `BACKUP_HOST_DIR` to a path on
another disk. Run one now: `exec` has no shell to use here, so run
`docker compose run --rm migrate scripts/backup-now.mjs`.
Restore: `docker compose stop cciq-portal backup`, then
`docker compose run --rm -it migrate scripts/restore-backup.mjs --archive /data/backups/<file>` (add `--dry-run` first).

## Useful
- Logs: `docker compose logs -f cciq-portal` (JSON, one object per line). In Grafana Explore (Loki): `{service="cciq-portal"} | json`.
- Image size / contents: `docker image ls cciq-portal`; `docker run --rm --entrypoint /nodejs/bin/node cciq-portal:0.1.0 -v`.
- Scan + SBOM: `trivy image --severity HIGH,CRITICAL cciq-portal:0.1.0`; build with `docker buildx build --sbom=true --provenance=mode=max .`
- TLS in front: set `SECURE_COOKIES=true`, `TRUST_PROXY=true`, `PORTAL_DOMAIN=portal.example.org` and `docker compose --profile proxy up -d`.
- Debug shell: the image has none. Use `docker compose run --rm --entrypoint /busybox/sh` only on a `:debug` distroless base if you must.
